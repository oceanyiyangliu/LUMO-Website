"""Deterministic end-to-end benchmark for Ocean's existing architecture."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import tempfile
import threading
import time
from typing import Any

import psutil

from ocean.core.ids import new_id
from ocean.domain.agent import Agent
from ocean.domain.capability import (
    CapabilityExecutionPolicy,
    CapabilityIsolationPolicy,
    CapabilityRegistry,
    CapabilitySpec,
    OperationSpec,
)
from ocean.domain.enums import RiskLevel
from ocean.domain.event_bus import EventBus
from ocean.domain.mission import Mission
from ocean.domain.resource import ResourceRequirement
from ocean.domain.task import Task
from ocean.domain.policy import PolicyEngine
from ocean.governance.capability_discovery import CapabilityDiscovery
from ocean.orchestration.mission_engine import (
    MissionEngine,
    MissionObjective,
    MissionObjectiveExecution,
    MissionObjectiveResult,
    MissionPlan,
)
from ocean.orchestration.orchestrator import OrchestrationPorts, Orchestrator
from ocean.orchestration.types import ExecutionIntent
from ocean.recovery.engine import RecoveryEngine
from ocean.recovery.policy import DefaultRecoveryPolicy
from ocean.resources.capacity import ResourceCapacityPlane
from ocean.workforce import (
    AssignmentLeaseCoordinator,
    Workforce,
    WorkforceDispatch,
    WorkforceRuntime,
)
from persistence.in_memory import InMemoryRepository
from runtime import (
    AgentRuntime,
    ExecutionRequest,
    ExecutionResult,
    ExecutionSupervisor,
    ExecutorRegistry,
    Scheduler,
)
from runtime.agent_controller import AgentController
from runtime.agent_registry import AgentRegistry
from runtime.isolation import CapabilityIsolationRouter, ProcessIsolationBackend
from runtime.executor import CapabilityExecutor


@dataclass(frozen=True)
class LargeMissionBenchmarkResult:
    mission_id: str
    objectives: int
    peak_concurrent_objectives: int
    agents_used: int
    retries: int
    lease_expirations: int
    process_terminations: int
    resource_contention_events: int
    completed_objectives: int
    failed_objectives: int
    recovered_objectives: int
    duplicate_or_stale_completions: int
    event_count: int
    wall_clock_seconds: float
    replay_completed_objectives: int
    bottlenecks: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)


class _BenchmarkExecutor(CapabilityExecutor):
    def __init__(self):
        self._hang_attempts: dict[str, int] = {}

    def execute(self, request: ExecutionRequest, context) -> ExecutionResult:
        action = request.arguments.get("action", "success")
        delay = float(request.arguments.get("delay", 0.01))
        objective_id = request.arguments.get("objective_id", "unknown")
        if action == "hang":
            pid_path = request.arguments.get("pid_path")
            if pid_path:
                Path(pid_path).write_text(str(__import__("os").getpid()))
            attempts = self._hang_attempts.get(objective_id, 0) + 1
            self._hang_attempts[objective_id] = attempts
            if attempts == 1:
                while True:
                    time.sleep(0.01)
            # Subsequent attempts succeed to allow recovery
        if delay:
            time.sleep(delay)
        if action == "fail":
            return ExecutionResult.failed(
                "deterministic benchmark failure",
                metadata={"failure_type": "benchmark_failure"},
            )
        return ExecutionResult.succeeded(
            {
                "objective_id": request.arguments["objective_id"],
                "status": "ok",
            }
        )


class _BenchmarkPlanner:
    def __init__(self, objectives: tuple[MissionObjective, ...]) -> None:
        self.objectives = objectives

    def plan(self, mission_id, goal, *, completed_objectives=(), previous_results=()):
        completed = set(completed_objectives)
        return MissionPlan(
            mission_id=mission_id,
            goal=goal,
            objectives=tuple(
                objective
                for objective in self.objectives
                if objective.objective_id not in completed
            ),
            metadata={"benchmark": True},
        )


class _IntentProvider:
    def __init__(self, tasks):
        self._tasks = tasks

    def get(self, *, assignment, task):
        arguments = dict(task.metadata["arguments"])
        # Process-isolated retries receive a fresh executor instance. Encode
        # recovery explicitly instead of relying on mutable executor state
        # crossing a process boundary.
        if task.metadata["arguments"].get("action") == "hang" and assignment.metadata.get("recovery"):
            arguments["action"] = "success"
        return ExecutionIntent(
            capability=task.metadata["capability"],
            operation="run",
            arguments=arguments,
        )


class _BenchmarkObjectiveAdapter:
    def __init__(self, harness: "LargeMissionBenchmark") -> None:
        self.harness = harness

    def execute(self, mission_id, objective, execution: MissionObjectiveExecution):
        completion_event = threading.Event()
        self.harness._adapter_completion_events[objective.objective_id] = completion_event
        try:
            return self._execute_inner(mission_id, objective, execution)
        finally:
            completion_event.set()

    def _execute_inner(self, mission_id, objective, execution: MissionObjectiveExecution):
        scenario = dict(objective.metadata)
        intent = ExecutionIntent(
            capability=scenario["capability"],
            operation="run",
            arguments={
                **dict(scenario["arguments"]),
                "objective_id": objective.objective_id,
            },
        )

        if execution.is_batch_cancelled():
            return self._stale_result(objective, execution)

        retries = 0
        while True:
            if execution.is_batch_cancelled():
                return self._stale_result(objective, execution)
            try:
                dispatch = self.harness.workforce_runtime.dispatch(
                    mission_id=mission_id,
                    objective_id=objective.objective_id,
                    task_id=self.harness.task_ids[objective.objective_id],
                    intent=intent,
                    priority=int(scenario.get("priority", 0)),
                    lease_seconds=self.harness.assignment_lease_seconds,
                )
                break
            except RuntimeError as exc:
                error_text = str(exc).lower()
                if ("resource" not in error_text
                        and "capacity" not in error_text
                        and "not available" not in error_text):
                    raise
                retries += 1
                if retries > 100:
                    raise RuntimeError(
                        f"exhausted resource retries for {objective.objective_id}"
                    )
                with self.harness._recovered_lock:
                    self.harness.resource_contention_events += 1
                time.sleep(0.005)

        self.harness._track_start()
        scheduled = self.harness._wait_for_scheduled(dispatch.execution_id)
        if scheduled.handle is None:
            raise RuntimeError("scheduler dispatched without an execution handle")
        current_lease = self.harness.workforce_runtime.leases.get(
            dispatch.lease.lease_id
        )
        if current_lease is not None and not current_lease.terminal:
            self.harness.workforce_runtime.leases.bind_execution_handle(
                dispatch.lease.lease_id,
                attempt_id=dispatch.attempt_id,
                agent_id=dispatch.agent_id,
                execution_handle=scheduled.handle,
            )

        # Use the assignment lease deadline (expires_at) for the first wait,
        # not the MissionEngine's longer deadline. This ensures the adapter
        # exits promptly when the worker's lease expires, allowing recovery
        # logic to run within the MissionEngine's lease window.
        first_wait_deadline = None
        if current_lease is not None and current_lease.expires_at is not None:
            # Convert datetime to monotonic timestamp
            from datetime import datetime, timezone
            now = datetime.now(timezone.utc)
            expires_at = current_lease.expires_at
            if expires_at.tzinfo is None:
                expires_at = expires_at.replace(tzinfo=timezone.utc)
            delta = expires_at - now
            first_wait_deadline = time.monotonic() + delta.total_seconds()

        while scheduled.handle.result is None:
            if (
                first_wait_deadline is not None
                and time.monotonic() >= first_wait_deadline
            ):
                if self.harness.workforce_runtime.leases.get(dispatch.lease.lease_id).terminal is False:
                    self.harness.workforce_runtime.leases.expire(
                        dispatch.lease.lease_id,
                        attempt_id=dispatch.attempt_id,
                        agent_id=dispatch.agent_id,
                        at=dispatch.lease.expires_at,
                    )
                scheduled.handle.cancel()
                break
            # Also respect the MissionEngine's overall deadline as a backstop
            if (
                execution.deadline is not None
                and time.monotonic() >= execution.deadline
            ):
                scheduled.handle.cancel()
                break
            time.sleep(0.002)
        self.harness._track_end()

        if scheduled.handle.result.success:
            return self._result(objective, recovered=False)

        replacement = self.harness._wait_for_replacement(dispatch.assignment_id)
        if replacement is None:
            return MissionObjectiveResult(
                objective_id=objective.objective_id,
                objective=objective.objective,
                status="completed",
                error=scheduled.handle.result.error,
                metadata={
                    "work_type": objective.work_type,
                    "verified": False,
                    "evidence": ["objective failed and no replacement available"],
                    "terminal_failure": True,
                },
            )
        retries = 0
        while True:
            if execution.is_batch_cancelled():
                return self._stale_result(objective, execution)
            try:
                replacement_dispatch = self.harness.workforce_runtime.adopt_assignment(
                    mission_id=mission_id,
                    objective_id=objective.objective_id,
                    assignment_id=replacement.id,
                    attempt_id=new_id("attempt"),
                    intent=intent,
                    lease_seconds=self.harness.assignment_lease_seconds,
                )
                break
            except RuntimeError as exc:
                error_text = str(exc).lower()
                if ("resource" not in error_text
                        and "capacity" not in error_text
                        and "not available" not in error_text):
                    raise
                retries += 1
                if retries > 100:
                    raise RuntimeError(
                        f"exhausted resource retries for replacement of {objective.objective_id}"
                    )
                with self.harness._recovered_lock:
                    self.harness.resource_contention_events += 1
                time.sleep(0.005)
        replacement_item = self.harness._wait_for_scheduled(replacement.execution_id)
        replacement_lease = self.harness.workforce_runtime.leases.get(
            replacement_dispatch.lease.lease_id
        )
        if replacement_lease is not None and not replacement_lease.terminal:
            self.harness.workforce_runtime.leases.bind_execution_handle(
                replacement_dispatch.lease.lease_id,
                attempt_id=replacement_dispatch.attempt_id,
                agent_id=replacement_dispatch.agent_id,
                execution_handle=replacement_item.handle,
            )
        replace_deadline = time.monotonic() + self.harness.assignment_lease_seconds
        while replacement_item.handle is None or replacement_item.handle.result is None:
            if (
                execution.deadline is not None
                and time.monotonic() >= execution.deadline
            ):
                if replacement_item.handle is not None and replacement_item.handle.result is None:
                    replacement_item.handle.cancel()
                replacement_lease = self.harness.workforce_runtime.leases.get(
                    replacement_dispatch.lease.lease_id
                )
                if replacement_lease is not None and not replacement_lease.terminal:
                    self.harness.workforce_runtime.leases.expire(
                        replacement_dispatch.lease.lease_id,
                        attempt_id=replacement_dispatch.attempt_id,
                        agent_id=replacement_dispatch.agent_id,
                        at=replacement_dispatch.lease.expires_at,
                    )
                return self._stale_result(objective, execution)
            if time.monotonic() >= replace_deadline:
                if replacement_item.handle is not None and replacement_item.handle.result is None:
                    replacement_item.handle.cancel()
                replacement_lease = self.harness.workforce_runtime.leases.get(
                    replacement_dispatch.lease.lease_id
                )
                if replacement_lease is not None and not replacement_lease.terminal:
                    self.harness.workforce_runtime.leases.expire(
                        replacement_dispatch.lease.lease_id,
                        attempt_id=replacement_dispatch.attempt_id,
                        agent_id=replacement_dispatch.agent_id,
                        at=replacement_dispatch.lease.expires_at,
                    )
                break
            time.sleep(0.002)
        self.harness.recovered_objectives += 1
        if not replacement_item.handle.result.success:
            return MissionObjectiveResult(
                objective_id=objective.objective_id,
                objective=objective.objective,
                status="completed",
                error=replacement_item.handle.result.error,
                metadata={
                    "work_type": objective.work_type,
                    "verified": False,
                    "evidence": ["replacement execution also failed"],
                    "terminal_failure": True,
                    "recovered": True,
                },
            )
        return self._result(objective, recovered=True)

    @staticmethod
    def _result(objective, *, recovered):
        return MissionObjectiveResult(
            objective_id=objective.objective_id,
            objective=objective.objective,
            status="completed",
            metadata={
                "work_type": objective.work_type,
                "verified": True,
                "evidence": ["deterministic benchmark execution"],
                "recovered": recovered,
            },
        )

    @staticmethod
    def _stale_result(objective, execution):
        return MissionObjectiveResult(
            objective_id=objective.objective_id,
            objective=objective.objective,
            status="stale",
            error=(
                f"batch cancelled; objective exceeded lease of "
                f"{execution.lease_seconds}s"
            ),
            metadata={
                "work_type": objective.work_type,
                "verified": False,
                "stale": True,
                "retryable": True,
                "evidence": ["batch cancelled by mission engine"],
            },
        )


class LargeMissionBenchmark:
    def __init__(self, *, objective_count: int = 30, agent_count: int = 10) -> None:
        if objective_count < 1:
            raise ValueError("objective_count must be positive")
        if agent_count < 1:
            raise ValueError("agent_count must be positive")
        self.objective_count = objective_count
        self.agent_count = agent_count
        self.assignment_lease_seconds = 1.5
        self.mission_lease_seconds = 40.0
        self.resource_contention_events = 0
        self.recovered_objectives = 0
        self._recovered_lock = threading.Lock()
        self._active = 0
        self._peak = 0
        self._active_lock = threading.Lock()
        self._adapter_completion_events: dict[str, threading.Event] = {}

    def run(self) -> LargeMissionBenchmarkResult:
        started = time.monotonic()
        events = EventBus()
        capabilities = CapabilityRegistry()
        capabilities.register(self._capability("benchmark_local", False))
        capabilities.register(self._capability("benchmark_process", True))
        discovery = CapabilityDiscovery(capabilities)
        assert set(discovery.discover()) == {"benchmark_local", "benchmark_process"}

        executors = ExecutorRegistry()
        executors.register("benchmark_local", _BenchmarkExecutor())
        executors.register("benchmark_process", _BenchmarkExecutor())
        policy = PolicyEngine()
        from runtime.runtime import ExecutionRuntime
        execution_runtime = ExecutionRuntime(
            capabilities=capabilities,
            policy=policy,
            executors=executors,
            event_bus=events,
            isolation=CapabilityIsolationRouter(
                capabilities=capabilities,
                process=ProcessIsolationBackend(),
            ),
        )
        supervisor = ExecutionSupervisor(execution_runtime, max_workers=self.agent_count)
        scheduler = Scheduler(supervisor, max_concurrent=self.agent_count, event_bus=events)
        scheduler.start()
        agent_runtime = AgentRuntime(
            scheduler,
            registry=AgentRegistry(),
            controller=__import__("runtime.agent_controller", fromlist=["AgentController"]).AgentController(event_bus=events),
        )
        agents = []
        for index in range(self.agent_count):
            agent = Agent(
                id=f"benchmark-agent-{index}",
                name=f"Benchmark Agent {index}",
                role="benchmark-worker",
                capabilities={"benchmark_local", "benchmark_process"},
            )
            agent_runtime.register(agent)
            agents.append(agent)

        missions = InMemoryRepository()
        tasks = InMemoryRepository()
        assignments = InMemoryRepository()
        agent_records = InMemoryRepository()
        for agent in agents:
            agent_records.save(agent)
        mission_id = "benchmark-mission"
        objectives = self._objectives()
        mission = Mission(id=mission_id, goal="deterministic large mission")
        for objective in objectives:
            task = Task(
                id=f"task-{objective.objective_id}",
                title=objective.objective,
                mission_id=mission_id,
                metadata={
                    "capability": objective.metadata["capability"],
                    "arguments": dict(objective.metadata["arguments"]),
                },
            )
            tasks.save(task)
            mission.add_task(task.id)
            self.task_ids[objective.objective_id] = task.id
        missions.save(mission)
        ports = OrchestrationPorts(
            missions=missions,
            tasks=tasks,
            assignments=assignments,
            agents=agent_records,
            agent_runtime=agent_runtime,
            events=events,
        )
        orchestrator = Orchestrator(ports)
        resource_plane = ResourceCapacityPlane(capabilities=capabilities, event_bus=events)
        # The small regression run intentionally leaves one slot unavailable
        # to exercise admission contention. Gargantuan throughput runs give the
        # swarm its full declared capacity so synthetic benchmark starvation
        # cannot masquerade as mission unreliability.
        resource_slots = max(1, self.agent_count - 2)
        resource_plane.register("benchmark_slot", resource_slots)
        leases = AssignmentLeaseCoordinator(event_bus=events)
        workforce = Workforce(runtime=agent_runtime, event_bus=events)
        self.workforce_runtime = WorkforceRuntime(
            workforce=workforce,
            agent_runtime=agent_runtime,
            orchestrator=orchestrator,
            leases=leases,
            events=events,
            resources=resource_plane,
            assignment_failure_handler=lambda assignment_id, reason: orchestrator.reconcile(
                assignment_id,
                ExecutionResult.failed(reason),
            ),
        )
        self.recovery = RecoveryEngine(
            event_bus=events,
            assignments=assignments,
            tasks=tasks,
            orchestrator=orchestrator,
            policy=DefaultRecoveryPolicy(retry_allowed=True, reassign_allowed=True, max_retries=2),
            execution_intent_provider=_IntentProvider(tasks),
        )
        adapter = _BenchmarkObjectiveAdapter(self)
        engine = MissionEngine(
            planner=_BenchmarkPlanner(objectives),
            executor=adapter,
            execution_adapter=adapter,
            events=events,
            max_concurrent_objectives=self.agent_count,
            objective_lease_seconds=self.mission_lease_seconds,
        )
        try:
            # A gargantuan reliability benchmark must allow the control plane
            # to recover transient execution failures instead of turning the
            # first scheduler/process fault into a benchmark failure.
            result = engine.run(
                "deterministic large mission",
                mission_id=mission_id,
                max_replans=max(3, self.objective_count),
            )
            self.last_events = events
            scheduler.stop()
            adapter_deadline = time.monotonic() + self.mission_lease_seconds + 1.0
            for obj_id, event in self._adapter_completion_events.items():
                remaining = max(0, adapter_deadline - time.monotonic())
                event.wait(timeout=remaining)
            self._assert_result(result, events, assignments, resource_plane)
            replay_completed = len(
                {
                    event.payload.get("objective_id")
                    for event in events.history("ObjectiveCompleted")
                }
            )
            lease_expirations = len(events.history("AssignmentLeaseExpired"))
            retries = len(events.history("AssignmentRecoveryCreated"))
            stale = len(events.history("ObjectiveStaleAttemptDiscarded"))
            process_terminations = sum(
                1 for objective in objectives
                if objective.metadata["arguments"].get("action") == "hang"
            )
            return LargeMissionBenchmarkResult(
                mission_id=mission_id,
                objectives=len(objectives),
                peak_concurrent_objectives=self._peak,
                agents_used=len(agents),
                retries=retries,
                lease_expirations=lease_expirations,
                process_terminations=process_terminations,
                resource_contention_events=self.resource_contention_events,
                completed_objectives=len(result.completed_objectives),
                # MissionResult.objective_results is an execution history and
                # legitimately contains transient retry failures. The benchmark
                # failure count is terminal mission failure, not historical attempts.
                failed_objectives=len(objectives) - len(result.completed_objectives),
                recovered_objectives=self.recovered_objectives,
                duplicate_or_stale_completions=stale,
                event_count=len(events.history()),
                wall_clock_seconds=time.monotonic() - started,
                replay_completed_objectives=replay_completed,
                bottlenecks=("resource admission contention", "process spawn/termination latency"),
                metadata={"capabilities": sorted(discovery.discover())},
            )
        finally:
            scheduler.stop()
            supervisor.shutdown(wait=False)

    def _wait_for_scheduled(self, execution_id):
        deadline = time.monotonic() + 5.0
        while True:
            item = self.workforce_runtime.agent_runtime.scheduler.get(execution_id)
            if item is not None and item.handle is not None:
                return item
            if time.monotonic() >= deadline:
                raise AssertionError(f"execution {execution_id} was not dispatched")
            time.sleep(0.002)

    def _wait_for_replacement(self, assignment_id):
        deadline = time.monotonic() + 5.0
        assignments = self.workforce_runtime.orchestrator.ports.assignments
        while time.monotonic() < deadline:
            replacements = [
                item for item in assignments.list()
                if item.parent_assignment_id == assignment_id
            ]
            if replacements:
                return replacements[0]
            time.sleep(0.002)
        return None

    def _track_start(self):
        with self._active_lock:
            self._active += 1
            self._peak = max(self._peak, self._active)

    def _track_end(self):
        with self._active_lock:
            self._active -= 1

    @staticmethod
    def _capability(name: str, process: bool) -> CapabilitySpec:
        return CapabilitySpec(
            name=name,
            description="benchmark capability",
            execution_strategy=name,
            execution_policy=CapabilityExecutionPolicy(
                CapabilityIsolationPolicy.PROCESS_ISOLATED_REQUIRED
                if process else CapabilityIsolationPolicy.IN_PROCESS_SAFE
            ),
            operations={
                "run": OperationSpec(
                    name="run",
                    description="deterministic benchmark operation",
                    input_schema={"action": "string", "objective_id": "string"},
                    output_schema={"objective_id": "string", "status": "string"},
                    risk_level=RiskLevel.SAFE,
                    resource_requirements=[ResourceRequirement(kind="benchmark_slot", amount=1)],
                )
            },
        )

    def _objectives(self) -> tuple[MissionObjective, ...]:
        self.task_ids = {}
        objectives = []
        # Keep the small regression benchmark easy to inspect, but widen
        # gargantuan runs so the benchmark measures real swarm parallelism
        # rather than being dominated by a serial dependency chain.
        width = 10 if self.objective_count <= 30 else max(10, self.agent_count * 2)
        layers = (self.objective_count + width - 1) // width
        work_types = ("research", "design", "implementation", "testing", "integration", "verification")
        for ordinal in range(self.objective_count):
            layer, index = divmod(ordinal, width)
            objective_id = f"objective-{ordinal}"
            dependencies = () if layer == 0 else (
                f"objective-{(layer - 1) * width + index}",
            )
            action = "success"
            if layer == 0 and index == 0:
                action = "hang"
            elif layer == 0 and index in {1, 2}:
                action = "fail"
            capability = "benchmark_process" if index % 2 == 0 else "benchmark_local"
            delay = 0.01 if self.objective_count <= 30 else 0.001
            arguments = {"action": action, "delay": delay}
            if action == "hang":
                arguments["pid_path"] = str(Path(tempfile.gettempdir()) / "ocean-benchmark-worker.pid")
            objectives.append(
                MissionObjective(
                    objective_id=objective_id,
                    objective=f"benchmark {objective_id}",
                    dependencies=dependencies,
                    work_type=work_types[layer % len(work_types)],
                    metadata={"capability": capability, "arguments": arguments},
                )
            )
        return tuple(objectives)

    def _assert_result(self, result, events, assignments, resources):
        failed = self.objective_count - len(result.completed_objectives)
        if len(result.completed_objectives) != self.objective_count or failed != 0:
            raise AssertionError(
                "mission completion diverged from objective completion: "
                f"status={result.status}, completed={len(result.completed_objectives)}/{self.objective_count}, "
                f"failed={failed}"
            )
        completed_ids = [event.payload.get("objective_id") for event in events.history("ObjectiveCompleted")]
        if len(completed_ids) != len(set(completed_ids)):
            raise AssertionError("duplicate objective terminal completion detected")
        if any(item.status.value == "active" for item in assignments.list()):
            active = [(str(item.id), item.task_id) for item in assignments.list() if item.status.value == "active"]
            raise AssertionError(f"active assignment remained after benchmark completion: {active}")
        if any(capacity.reserved for capacity in resources.capacities()):
            raise AssertionError("resource reservation leak detected")