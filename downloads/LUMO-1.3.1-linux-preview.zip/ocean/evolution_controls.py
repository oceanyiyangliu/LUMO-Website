"""Deterministic release controls for self-improvement candidates."""
from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class CanaryPolicy:
    traffic_percent: int = 5
    min_samples: int = 20
    max_failure_rate: float = 0.05
    def __post_init__(self):
        if not 1 <= self.traffic_percent <= 100: raise ValueError("traffic_percent must be 1..100")
        if self.min_samples <= 0: raise ValueError("min_samples must be positive")
        if not 0 <= self.max_failure_rate <= 1: raise ValueError("max_failure_rate must be 0..1")

@dataclass(frozen=True)
class CanaryDecision:
    enabled: bool
    promote: bool
    rollback: bool
    reason: str

class CanaryController:
    def __init__(self, policy: CanaryPolicy | None = None): self.policy=policy or CanaryPolicy()
    def assign(self, stable_id: str) -> bool:
        if not stable_id: raise ValueError("stable_id is required")
        return int.from_bytes(__import__('hashlib').sha256(stable_id.encode()).digest()[:4],'big') % 100 < self.policy.traffic_percent
    def evaluate(self, *, samples: int, failures: int) -> CanaryDecision:
        if samples < 0 or failures < 0 or failures > samples: raise ValueError("invalid canary sample counts")
        if samples < self.policy.min_samples: return CanaryDecision(True,False,False,"insufficient samples")
        rate=failures/samples
        if rate > self.policy.max_failure_rate: return CanaryDecision(True,False,True,"failure rate exceeded canary threshold")
        return CanaryDecision(True,True,False,"canary quality gate passed")
