"""Signed LUMO release manifests and deterministic release gates."""
from __future__ import annotations

import base64
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Sequence

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey


@dataclass(frozen=True)
class ReleaseManifest:
    version: str
    channel: str
    artifact_sha256: str
    artifact_size: int
    min_version: str = "0.0.0"
    rollout_percent: int = 100
    schema_version: int = 1
    migration_id: str | None = None
    created_at: str = ""

    def __post_init__(self):
        if not self.version or not self.channel or len(self.artifact_sha256) != 64:
            raise ValueError("invalid release manifest")
        if self.artifact_size < 0 or not 0 <= self.rollout_percent <= 100:
            raise ValueError("invalid release bounds")
        int(self.artifact_sha256, 16)

    def canonical(self) -> bytes:
        return json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":")).encode()

    def to_dict(self) -> dict[str, object]:
        return {k: v for k, v in self.__dict__.items() if v is not None}

    @classmethod
    def from_dict(cls, data: Mapping[str, object]) -> "ReleaseManifest":
        return cls(**{k: data[k] for k in cls.__dataclass_fields__ if k in data})
class ReleaseSigner:
    """Ed25519 signer; private material never belongs in a client installation."""

    def __init__(self, private_key: Ed25519PrivateKey | None = None):
        self._private_key = private_key or Ed25519PrivateKey.generate()

    @property
    def public_key_bytes(self) -> bytes:
        return self._private_key.public_key().public_bytes_raw()

    def sign(self, manifest: ReleaseManifest) -> str:
        return base64.b64encode(self._private_key.sign(manifest.canonical())).decode()


class ReleaseVerifier:
    def __init__(self, public_key_bytes: bytes):
        self._key = Ed25519PublicKey.from_public_bytes(public_key_bytes)

    def verify(self, manifest: ReleaseManifest, signature: str) -> bool:
        try:
            self._key.verify(base64.b64decode(signature, validate=True), manifest.canonical())
            return True
        except (InvalidSignature, ValueError):
            return False


def artifact_digest(path: Path) -> tuple[str, int]:
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            size += len(chunk)
            digest.update(chunk)
    return digest.hexdigest(), size


def verify_artifact(path: Path, manifest: ReleaseManifest) -> bool:
    digest, size = artifact_digest(path)
    return digest == manifest.artifact_sha256 and size == manifest.artifact_size
@dataclass(frozen=True)
class ReleaseGate:
    """Independent release evidence required before promotion."""
    regression_pass: bool
    security_pass: bool
    invariants_pass: bool
    benchmark_pass: bool
    migration_pass: bool
    rollback_pass: bool
    verified: bool = False

    @property
    def promotable(self) -> bool:
        return all((
            self.regression_pass,
            self.security_pass,
            self.invariants_pass,
            self.benchmark_pass,
            self.migration_pass,
            self.rollback_pass,
            self.verified,
        ))

    def failures(self) -> tuple[str, ...]:
        names = (
            "regression", "security", "invariants", "benchmark",
            "migration", "rollback", "verification",
        )
        values = (
            self.regression_pass, self.security_pass, self.invariants_pass,
            self.benchmark_pass, self.migration_pass, self.rollback_pass,
            self.verified,
        )
        return tuple(name for name, value in zip(names, values) if not value)


@dataclass(frozen=True)
class ReleaseDecision:
    version: str
    promoted: bool
    reason: str
    gate_failures: tuple[str, ...] = ()
