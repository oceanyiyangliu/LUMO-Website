from __future__ import annotations

import html
import re
import urllib.parse
import urllib.request
from dataclasses import dataclass


@dataclass(frozen=True)
class WebResult:
    title: str
    url: str
    snippet: str


class WebSearch:
    """Dependency-free web search adapter for conversational grounding."""

    def __init__(self, timeout: float = 8.0) -> None:
        self.timeout = timeout

    def search(self, query: str, limit: int = 5) -> list[WebResult]:
        q = urllib.parse.quote_plus(query.strip())
        url = f"https://lite.duckduckgo.com/lite/?q={q}"
        request = urllib.request.Request(
            url,
            headers={
                "User-Agent": "LUMO/1.0 (+local AI assistant)",
                "Accept": "text/html,application/xhtml+xml",
            },
        )
        with urllib.request.urlopen(request, timeout=self.timeout) as response:
            body = response.read().decode("utf-8", errors="replace")

        results: list[WebResult] = []
        pattern = r'<a[^>]*href=[\'"]([^\'"]+)[\'"][^>]*class=[\'"]result-link[\'"][^>]*>(.*?)</a>'
        for match in re.finditer(pattern, body, re.S):
            raw_url = html.unescape(match.group(1))
            title = re.sub(r"<[^>]+>", "", html.unescape(match.group(2))).strip()
            if raw_url.startswith("//"):
                raw_url = "https:" + raw_url
            if "duckduckgo.com/l/?uddg=" in raw_url:
                raw_url = urllib.parse.unquote(
                    urllib.parse.parse_qs(urllib.parse.urlparse(raw_url).query).get("uddg", [raw_url])[0]
                )
            tail = body[match.end():match.end() + 1800]
            snippet_match = re.search(r'class=[\'"]result-snippet[\'"]>(.*?)</td>', tail, re.S)
            snippet = ""
            if snippet_match:
                snippet = re.sub(r"<[^>]+>", " ", html.unescape(snippet_match.group(1)))
                snippet = re.sub(r"\s+", " ", snippet).strip()
            if title and raw_url.startswith(("http://", "https://")):
                results.append(WebResult(title=title, url=raw_url, snippet=snippet))
            if len(results) >= limit:
                break
        return results
