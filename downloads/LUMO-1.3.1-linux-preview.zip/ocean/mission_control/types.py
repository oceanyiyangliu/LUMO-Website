"""Contracts for the mission-level control plane."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Optional, Tuple

from ocean.domain.enums import AssignmentStatus, MissionStatus, TaskStatus


@dataclass(frozen=True)
class MissionProgress:
    """Durably reconstructed mission progress.

    This is a derived operational view. It is never authoritative state.
    """

    mission_id: str
    mission_status: MissionStatus
    total_tasks: int
    pending_tasks: int
    completed_tasks: int
    failed_tasks: int
    cancelled_tasks: int
    active_assignments: int
    queued_assignments: int
    failed_assignments: int
    completed_assignments: int
    all_tasks_completed: bool
    has_failed_tasks: bool

    @property
    def terminal_success(self) -> bool:
        return self.all_tasks_completed and not self.has_failed_tasks

    @property
    def semantic_fraction(self) -> float:
        total = self.total_tasks
        return 0.0 if total <= 0 else min(1.0, max(0.0, self.completed_tasks / total))

    @property
    def semantic_terminal(self) -> bool:
        return self.completed_tasks + self.pending_tasks + self.failed_tasks + self.cancelled_tasks >= self.total_tasks


@dataclass(frozen=True)
class MissionControlResult:
    """Result returned by mission-control operations."""

    success: bool
    mission_id: Optional[str] = None
    plan_revision_id: Optional[str] = None
    assignment_ids: Tuple[str, ...] = ()
    execution_ids: Tuple[str, ...] = ()
    error: Optional[str] = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
