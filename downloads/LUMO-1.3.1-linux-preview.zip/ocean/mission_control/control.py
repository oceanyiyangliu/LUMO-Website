"""Mission-level control plane.

MissionControl is deliberately a coordination boundary rather than a god
object. It owns mission-level lifecycle decisions and composes the already
established planning and execution boundaries.

Authoritative state remains in repositories and the canonical event stream.
Operational progress is reconstructed from durable entities rather than
stored in mutable in-memory coordination state.
"""

from __future__ import annotations

from typing import Any, Iterable, Mapping, Optional

from ocean.domain.assignment import Assignment
from ocean.domain.enums import AssignmentStatus, MissionStatus, TaskStatus
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.domain.mission import Mission
from ocean.domain.plan import PlanRevision, PlanStatus
from ocean.domain.task import Task
from ocean.planning.planner import Planner, PlanningContext, PlanningRequest
from ocean.planning.service import PlanningService
from ocean.orchestration.execution_plan_provider import ExecutionPlanProvider
from ocean.orchestration.execution_plan_runner import (
    ExecutionAgentResolver,
    ExecutionPlanRunResult,
    ExecutionPlanRunner,
)
from persistence.repository import Repository

from .types import MissionControlResult, MissionProgress
from ocean.advanced_capabilities import progress_semantics


class MissionControl:
    """Mission-level lifecycle and execution control plane.

    The class intentionally delegates:
      * planning -> PlanningService
      * executable-plan reconstruction -> ExecutionPlanProvider
      * frontier execution -> ExecutionPlanRunner
      * execution scheduling -> Scheduler/runtime
      * objective verification -> Verification subsystem
      * agent lifecycle -> AgentExecutionLifecycle / AgentController

    MissionControl coordinates those boundaries and persists mission facts.
    """

    def __init__(
        self,
        *,
        missions: Repository[Mission],
        tasks: Repository[Task],
        assignments: Repository[Assignment],
        plan_revisions: Repository[PlanRevision],
        planning: PlanningService,
        execution_plans: ExecutionPlanProvider,
        execution_runner: ExecutionPlanRunner,
        agent_resolver: ExecutionAgentResolver,
        events: EventBus,
    ) -> None:
        self._missions = missions
        self._tasks = tasks
        self._assignments = assignments
        self._plan_revisions = plan_revisions
        self._planning = planning
        self._execution_plans = execution_plans
        self._execution_runner = execution_runner
        self._agent_resolver = agent_resolver
        self._events = events

        self._events.subscribe(
            "TaskAssignmentCompleted",
            self._handle_assignment_completed,
        )
        self._events.subscribe(
            "TaskAssignmentFailed",
            self._handle_assignment_failed,
        )

    # ------------------------------------------------------------------
    # Mission creation
    # ------------------------------------------------------------------

    def create(
        self,
        *,
        goal: str,
        task_ids: Iterable[str] = (),
        metadata: Optional[Mapping[str, Any]] = None,
        mission_id: Optional[str] = None,
    ) -> Mission:
        if not goal or not goal.strip():
            raise ValueError("mission goal is required")

        task_ids = list(dict.fromkeys(task_ids))

        for task_id in task_ids:
            if self._tasks.get(task_id) is None:
                raise ValueError(f"unknown task: {task_id!r}")

        mission = Mission(
            goal=goal,
            task_ids=task_ids,
            metadata=dict(metadata or {}),
            **({"id": mission_id} if mission_id is not None else {}),
        )

        if self._missions.get(mission.id) is not None:
            raise ValueError(f"mission already exists: {mission.id!r}")

        for task_id in task_ids:
            task = self._tasks.get(task_id)
            if task is None:
                raise ValueError(f"unknown task: {task_id!r}")
            if task.mission_id not in (None, mission.id):
                raise ValueError(
                    f"task {task_id!r} belongs to mission "
                    f"{task.mission_id!r}, not {mission.id!r}"
                )

        self._missions.save(mission)

        self._publish(
            Event(
                type="MissionCreated",
                payload={
                    "id": mission.id,
                    "goal": mission.goal,
                    "task_ids": list(mission.task_ids),
                    "metadata": dict(mission.metadata),
                },
                aggregate_type="mission",
                aggregate_id=mission.id,
                correlation_id=mission.id,
                source="mission_control",
            )
        )
        return mission

    # ------------------------------------------------------------------
    # Planning
    # ------------------------------------------------------------------

    def plan(
        self,
        mission_id: str,
        *,
        objective: Optional[str] = None,
        planner: Planner,
        revision_reason: Optional[str] = None,
        metadata: Optional[Mapping[str, Any]] = None,
    ) -> tuple[PlanRevision, Any]:
        mission = self._require_mission(mission_id)

        request = PlanningRequest(
            mission_id=mission.id,
            objective=objective or mission.goal,
            context=PlanningContext(mission=mission),
            revision_reason=revision_reason,
            metadata=dict(metadata or {}),
        )

        return self._planning.plan(
            request,
            planner,
        )

    def propose_plan(
        self,
        plan_revision_id: str,
        *,
        reason: Optional[str] = None,
    ) -> PlanRevision:
        return self._planning.propose(
            plan_revision_id,
            reason=reason,
        )

    def activate_plan(
        self,
        plan_revision_id: str,
        *,
        reason: Optional[str] = None,
    ) -> PlanRevision:
        return self._planning.activate(
            plan_revision_id,
            reason=reason,
        )

    # ------------------------------------------------------------------
    # Mission lifecycle
    # ------------------------------------------------------------------

    def activate(
        self,
        mission_id: str,
        *,
        reason: Optional[str] = None,
    ) -> Mission:
        mission = self._require_mission(mission_id)
        mission.transition(MissionStatus.ACTIVE)
        self._missions.save(mission)

        self._publish(
            self._mission_event(
                "MissionActivated",
                mission,
                reason=reason,
            )
        )
        return mission

    def pause(
        self,
        mission_id: str,
        *,
        reason: Optional[str] = None,
    ) -> Mission:
        mission = self._require_mission(mission_id)
        mission.transition(MissionStatus.PAUSED)
        self._missions.save(mission)

        self._publish(
            self._mission_event(
                "MissionPaused",
                mission,
                reason=reason,
            )
        )
        return mission

    def resume(
        self,
        mission_id: str,
        *,
        reason: Optional[str] = None,
    ) -> Mission:
        mission = self._require_mission(mission_id)
        mission.transition(MissionStatus.ACTIVE)
        self._missions.save(mission)

        self._publish(
            self._mission_event(
                "MissionResumed",
                mission,
                reason=reason,
            )
        )
        return mission

    def cancel(
        self,
        mission_id: str,
        *,
        reason: Optional[str] = None,
    ) -> Mission:
        mission = self._require_mission(mission_id)
        mission.transition(MissionStatus.CANCELLED)
        self._missions.save(mission)

        self._publish(
            self._mission_event(
                "MissionCancelled",
                mission,
                reason=reason,
            )
        )
        return mission

    def replan(
        self,
        mission_id: str,
        *,
        goal: Optional[str] = None,
        task_ids: Optional[Iterable[str]] = None,
        metadata: Optional[Mapping[str, Any]] = None,
        reason: Optional[str] = None,
    ) -> Mission:
        mission = self._require_mission(mission_id)

        new_goal = mission.goal if goal is None else goal
        if not new_goal or not new_goal.strip():
            raise ValueError("mission goal is required")

        new_task_ids = (
            list(mission.task_ids)
            if task_ids is None
            else list(dict.fromkeys(task_ids))
        )

        for task_id in new_task_ids:
            task = self._tasks.get(task_id)
            if task is None:
                raise ValueError(f"unknown task: {task_id!r}")
            if task.mission_id not in (None, mission.id):
                raise ValueError(
                    f"task {task_id!r} belongs to mission "
                    f"{task.mission_id!r}, not {mission.id!r}"
                )

        mission.goal = new_goal
        mission.task_ids = new_task_ids

        if metadata is not None:
            mission.metadata = dict(metadata)

        self._missions.save(mission)

        self._publish(
            Event(
                type="MissionReplanned",
                payload={
                    "id": mission.id,
                    "goal": mission.goal,
                    "task_ids": list(mission.task_ids),
                    "metadata": dict(mission.metadata),
                    "reason": reason,
                },
                aggregate_type="mission",
                aggregate_id=mission.id,
                correlation_id=mission.id,
                source="mission_control",
            )
        )
        return mission

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def start_plan(
        self,
        plan_revision_id: str,
        *,
        mode=None,
        priority: int = 0,
    ) -> ExecutionPlanRunResult:
        plan = self._plan_revisions.get(plan_revision_id)
        if plan is None:
            raise ValueError(
                f"unknown plan revision: {plan_revision_id!r}"
            )

        if plan.status is not PlanStatus.ACTIVE:
            raise ValueError(
                f"plan {plan_revision_id!r} must be active before execution; "
                f"current status is {plan.status.value!r}"
            )

        mission = self._require_mission(plan.mission_id)

        if mission.status is not MissionStatus.ACTIVE:
            raise ValueError(
                f"mission {mission.id!r} must be active before execution; "
                f"current status is {mission.status.value!r}"
            )

        executable_plan = self._execution_plans.get(plan_revision_id)

        return self._execution_runner.start(
            executable_plan,
            mode=mode,
            priority=priority,
        )

    # ------------------------------------------------------------------
    # Durable progress
    # ------------------------------------------------------------------

    def progress(self, mission_id: str) -> MissionProgress:
        mission = self._require_mission(mission_id)

        tasks = [
            task
            for task in self._tasks.list()
            if task.mission_id == mission.id
            or task.id in mission.task_ids
        ]

        task_by_id = {task.id: task for task in tasks}

        completed_tasks = sum(
            task.status is TaskStatus.COMPLETED
            for task in tasks
        )
        failed_tasks = sum(
            task.status is TaskStatus.FAILED
            for task in tasks
        )
        cancelled_tasks = sum(
            task.status is TaskStatus.CANCELLED
            for task in tasks
        )
        pending_tasks = len(tasks) - (
            completed_tasks + failed_tasks + cancelled_tasks
        )

        assignments = [
            assignment
            for assignment in self._assignments.list()
            if assignment.mission_id == mission.id
            and assignment.task_id in task_by_id
        ]

        active_assignments = sum(
            assignment.status is AssignmentStatus.ACTIVE
            for assignment in assignments
        )
        queued_assignments = sum(
            assignment.status is AssignmentStatus.QUEUED
            for assignment in assignments
        )
        failed_assignments = sum(
            assignment.status is AssignmentStatus.FAILED
            for assignment in assignments
        )
        completed_assignments = sum(
            assignment.status is AssignmentStatus.COMPLETED
            for assignment in assignments
        )

        semantic = progress_semantics(
            completed=completed_tasks,
            total=len(tasks),
            blocked=pending_tasks,
            failed=failed_tasks + cancelled_tasks,
        )
        # Cross-check the operational view against the semantic progress
        # invariant so derived state cannot silently drift from task state.
        if semantic.fraction != (0.0 if not tasks else completed_tasks / len(tasks)):
            raise RuntimeError("mission progress semantic fraction drift")
        if semantic.terminal != (completed_tasks + pending_tasks + failed_tasks + cancelled_tasks >= len(tasks)):
            raise RuntimeError("mission progress semantic terminal drift")
        return MissionProgress(
            mission_id=mission.id,
            mission_status=mission.status,
            total_tasks=len(tasks),
            pending_tasks=pending_tasks,
            completed_tasks=completed_tasks,
            failed_tasks=failed_tasks,
            cancelled_tasks=cancelled_tasks,
            active_assignments=active_assignments,
            queued_assignments=queued_assignments,
            failed_assignments=failed_assignments,
            completed_assignments=completed_assignments,
            all_tasks_completed=(
                bool(tasks)
                and completed_tasks == len(tasks)
            ),
            has_failed_tasks=failed_tasks > 0,
        )

    def reconcile_completion(self, mission_id: str) -> MissionControlResult:
        mission = self._require_mission(mission_id)
        progress = self.progress(mission_id)

        if progress.terminal_success:
            if mission.status is MissionStatus.ACTIVE:
                mission.transition(MissionStatus.COMPLETED)
                self._missions.save(mission)

                self._publish(
                    self._mission_event(
                        "MissionCompleted",
                        mission,
                    )
                )

            return MissionControlResult(
                success=True,
                mission_id=mission.id,
                metadata={
                    "status": MissionStatus.COMPLETED.value,
                    "completed_tasks": progress.completed_tasks,
                },
            )

        if progress.has_failed_tasks:
            return MissionControlResult(
                success=False,
                mission_id=mission.id,
                error="mission contains failed tasks; recovery is required",
                metadata={
                    "status": mission.status.value,
                    "failed_tasks": progress.failed_tasks,
                },
            )

        return MissionControlResult(
            success=False,
            mission_id=mission.id,
            error="mission is not yet complete",
            metadata={
                "status": mission.status.value,
                "pending_tasks": progress.pending_tasks,
                "active_assignments": progress.active_assignments,
                "queued_assignments": progress.queued_assignments,
            },
        )

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    def _handle_assignment_completed(self, event: Event) -> None:
        assignment_id = (
            event.payload.get("assignment_id")
            or event.causation_id
            or event.aggregate_id
        )

        if not assignment_id:
            raise ValueError(
                "TaskAssignmentCompleted event is missing assignment identity"
            )

        assignment = self._assignments.get(str(assignment_id))
        if assignment is None:
            raise ValueError(
                f"unknown assignment: {assignment_id!r}"
            )

        if not assignment.mission_id:
            return

        # Execution success does NOT complete the Task. Verification must
        # first move the Task into COMPLETED. Therefore this handler only
        # performs a durable mission-level observation.
        self.reconcile_completion(assignment.mission_id)

    def _handle_assignment_failed(self, event: Event) -> None:
        assignment_id = (
            event.payload.get("assignment_id")
            or event.causation_id
            or event.aggregate_id
        )

        if not assignment_id:
            raise ValueError(
                "TaskAssignmentFailed event is missing assignment identity"
            )

        assignment = self._assignments.get(str(assignment_id))
        if assignment is None:
            raise ValueError(
                f"unknown assignment: {assignment_id!r}"
            )

        if not assignment.mission_id:
            return

        # Recovery is intentionally a separate future control-plane
        # capability. A failed execution is observed here but does not
        # automatically retry/reassign/replan yet.
        return

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _require_mission(self, mission_id: str) -> Mission:
        if not mission_id:
            raise ValueError("mission_id is required")

        mission = self._missions.get(mission_id)
        if mission is None:
            raise ValueError(f"unknown mission: {mission_id!r}")
        return mission

    def _mission_event(
        self,
        event_type: str,
        mission: Mission,
        *,
        reason: Optional[str] = None,
    ) -> Event:
        payload = {
            "id": mission.id,
            "goal": mission.goal,
            "task_ids": list(mission.task_ids),
            "metadata": dict(mission.metadata),
            "status": mission.status.value,
        }
        if reason is not None:
            payload["reason"] = reason

        return Event(
            type=event_type,
            payload=payload,
            aggregate_type="mission",
            aggregate_id=mission.id,
            correlation_id=mission.id,
            source="mission_control",
        )

    def _publish(self, event: Event) -> None:
        failures = self._events.publish(event)
        if failures:
            raise RuntimeError(
                f"event handlers failed for {event.type!r}: "
                + "; ".join(str(failure.error) for failure in failures)
            )
