"""Durable local account profiles and per-account adaptive state."""
from __future__ import annotations

import hashlib
import json
import math
import secrets
import sqlite3
import threading
from datetime import datetime, timezone
from typing import Any

from ocean.core.ids import new_id


class AccountStore:
    """Small SQLite-backed account boundary for the local LUMO control plane."""

    def __init__(self, path):
        self.path = str(path)
        self._lock = threading.RLock()
        self._connection = sqlite3.connect(self.path, check_same_thread=False)
        self._connection.execute("PRAGMA journal_mode=WAL")
        self._connection.execute("PRAGMA synchronous=NORMAL")
        self._connection.execute("PRAGMA busy_timeout=30000")
        self._connection.executescript("""
        CREATE TABLE IF NOT EXISTS accounts (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            email TEXT,
            password_hash TEXT,
            email_verified INTEGER NOT NULL DEFAULT 0,
            profile_picture_ref TEXT,
            verification_token_hash TEXT,
            verification_expires_at TEXT,
            reset_token_hash TEXT,
            reset_expires_at TEXT,
            password_changed_at TEXT,
            last_login_at TEXT,
            root_id TEXT
        );
        CREATE TABLE IF NOT EXISTS adaptive_state (
            account_id TEXT NOT NULL,
            key TEXT NOT NULL,
            value TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            PRIMARY KEY (account_id, key),
            FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE
        );
        """)
        existing = {row[1] for row in self._connection.execute("PRAGMA table_info(accounts)").fetchall()}
        migrations = {
            "email": "TEXT",
            "password_hash": "TEXT",
            "email_verified": "INTEGER NOT NULL DEFAULT 0",
            "profile_picture_ref": "TEXT",
            "verification_token_hash": "TEXT",
            "verification_expires_at": "TEXT",
            "reset_token_hash": "TEXT",
            "reset_expires_at": "TEXT",
            "password_changed_at": "TEXT",
            "last_login_at": "TEXT",
            "root_id": "TEXT",
        }
        for column, definition in migrations.items():
            if column not in existing:
                self._connection.execute(f"ALTER TABLE accounts ADD COLUMN {column} {definition}")
        self._connection.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_accounts_email ON accounts(email) WHERE email IS NOT NULL")
        self._connection.commit()

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    def ensure_default(self, name: str = "Ocean") -> dict[str, Any]:
        with self._lock:
            row = self._connection.execute(
                "SELECT id,name,created_at,updated_at FROM accounts ORDER BY created_at LIMIT 1"
            ).fetchone()
            if row:
                return self._account(row)
            account_id = new_id("account")
            now = self._now()
            self._connection.execute(
                "INSERT INTO accounts(id,name,created_at,updated_at) VALUES(?,?,?,?)",
                (account_id, name.strip() or "Ocean", now, now),
            )
            self._connection.commit()
            return {"id": account_id, "name": name.strip() or "Ocean", "created_at": now, "updated_at": now}

    @staticmethod
    def _account(row) -> dict[str, Any]:
        keys = ("id", "name", "created_at", "updated_at", "email", "password_hash", "email_verified", "profile_picture_ref", "verification_token_hash", "verification_expires_at", "reset_token_hash", "reset_expires_at", "password_changed_at", "last_login_at", "root_id")
        values = list(row) + [None] * (len(keys) - len(row))
        return {
            "id": values[0], "name": values[1], "created_at": values[2], "updated_at": values[3],
            "email": values[4], "password_hash": values[5], "email_verified": bool(values[6]),
            "profile_picture_ref": values[7], "password_changed_at": values[12], "last_login_at": values[13],
            "root_id": values[14],
        }

    def get(self, account_id: str) -> dict[str, Any]:
        with self._lock:
            row = self._connection.execute(
                "SELECT * FROM accounts WHERE id=?", (account_id,)
            ).fetchone()
            if row is None:
                raise KeyError(account_id)
            return self._account(row)

    def delete(self, account_id: str) -> dict[str, Any]:
        with self._lock:
            row = self._connection.execute("SELECT id FROM accounts WHERE id=?", (account_id,)).fetchone()
            if row is None:
                raise KeyError(account_id)
            self._connection.execute("DELETE FROM adaptive_state WHERE account_id=?", (account_id,))
            self._connection.execute("DELETE FROM accounts WHERE id=?", (account_id,))
            self._connection.commit()
            return {"account_id": account_id, "deleted": True}

    def list(self) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._connection.execute(
                "SELECT * FROM accounts ORDER BY created_at"
            ).fetchall()
            return [self._account(row) for row in rows]

    def create(self, name: str) -> dict[str, Any]:
        clean = str(name).strip()
        if not clean or len(clean) > 80:
            raise ValueError("account name must be between 1 and 80 characters")
        with self._lock:
            account_id = new_id("account")
            now = self._now()
            self._connection.execute(
                "INSERT INTO accounts(id,name,created_at,updated_at) VALUES(?,?,?,?)",
                (account_id, clean, now, now),
            )
            self._connection.commit()
            return {"id": account_id, "name": clean, "created_at": now, "updated_at": now}

    def get_adaptive(self, account_id: str) -> dict[str, Any]:
        self.get(account_id)
        with self._lock:
            rows = self._connection.execute(
                "SELECT key,value FROM adaptive_state WHERE account_id=? ORDER BY key", (account_id,)
            ).fetchall()
            return {key: json.loads(value) for key, value in rows}

    def set_adaptive(self, account_id: str, key: str, value: Any) -> dict[str, Any]:
        self.get(account_id)
        clean_key = str(key).strip()
        if not clean_key or len(clean_key) > 120:
            raise ValueError("adaptive state key must be between 1 and 120 characters")
        encoded = json.dumps(value, separators=(",", ":"))
        now = self._now()
        with self._lock:
            self._connection.execute(
                "INSERT INTO adaptive_state(account_id,key,value,updated_at) VALUES(?,?,?,?) "
                "ON CONFLICT(account_id,key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at",
                (account_id, clean_key, encoded, now),
            )
            self._connection.execute("UPDATE accounts SET updated_at=? WHERE id=?", (now, account_id))
            self._connection.commit()
        return {"key": clean_key, "value": value, "updated_at": now}

    def increment_adaptive_number(self, account_id: str, key: str, delta: float) -> dict[str, Any]:
        """Atomically add to a numeric adaptive value."""
        self.get(account_id)
        clean_key = str(key).strip()
        if not clean_key or len(clean_key) > 120:
            raise ValueError("adaptive state key must be between 1 and 120 characters")
        try:
            amount = float(delta)
        except (TypeError, ValueError) as exc:
            raise ValueError("adaptive increment must be numeric") from exc
        if not math.isfinite(amount) or amount < 0 or amount > 3600:
            raise ValueError("adaptive increment must be between 0 and 3600 seconds")
        now = self._now()
        with self._lock:
            row = self._connection.execute(
                "SELECT value FROM adaptive_state WHERE account_id=? AND key=?",
                (account_id, clean_key),
            ).fetchone()
            current = 0.0
            if row is not None:
                try:
                    current = float(json.loads(row[0]))
                except (TypeError, ValueError, json.JSONDecodeError):
                    current = 0.0
            value = current + amount
            encoded = json.dumps(value, separators=(",", ":"))
            self._connection.execute(
                "INSERT INTO adaptive_state(account_id,key,value,updated_at) VALUES(?,?,?,?) "
                "ON CONFLICT(account_id,key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at",
                (account_id, clean_key, encoded, now),
            )
            self._connection.execute("UPDATE accounts SET updated_at=? WHERE id=?", (now, account_id))
            self._connection.commit()
        return {"key": clean_key, "value": value, "updated_at": now}

    @staticmethod
    def _normalize_email(email: str) -> str:
        clean = str(email).strip().casefold()
        if len(clean) > 320 or "@" not in clean or any(c.isspace() for c in clean):
            raise ValueError("valid email is required")
        return clean

    @staticmethod
    def _password_hash(password: str, salt: bytes | None = None) -> str:
        if not isinstance(password, str) or len(password) > 1024 or "\x00" in password:
            raise ValueError("password must be between 0 and 1024 characters and may not contain NUL")
        salt = salt or secrets.token_bytes(16)
        digest = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1, maxmem=64 * 1024 * 1024)
        return "scrypt$16384$8$1$" + salt.hex() + "$" + digest.hex()

    @staticmethod
    def _password_matches(password: str, encoded: str | None) -> bool:
        try:
            if not encoded or not encoded.startswith("scrypt$"):
                return False
            _, n, r, p, salt_hex, digest_hex = encoded.split("$", 5)
            digest = hashlib.scrypt(password.encode("utf-8"), salt=bytes.fromhex(salt_hex), n=int(n), r=int(r), p=int(p), maxmem=64 * 1024 * 1024)
            return secrets.compare_digest(digest.hex(), digest_hex)
        except (ValueError, TypeError):
            return False

    def create_user(self, name: str, email: str, password: str) -> dict[str, Any]:
        email = self._normalize_email(email)
        clean = str(name).strip()
        if not clean or len(clean) > 80:
            raise ValueError("account name must be between 1 and 80 characters")
        password_hash = self._password_hash(password)
        with self._lock:
            if self._connection.execute("SELECT 1 FROM accounts WHERE email=?", (email,)).fetchone():
                raise ValueError("email is already registered")
            account_id = new_id("account")
            now = self._now()
            self._connection.execute("INSERT INTO accounts(id,name,created_at,updated_at,email,password_hash) VALUES(?,?,?,?,?,?)", (account_id, clean, now, now, email, password_hash))
            self._connection.commit()
        return self.get(account_id)

    def authenticate(self, email: str, password: str) -> dict[str, Any]:
        email = self._normalize_email(email)
        with self._lock:
            row = self._connection.execute("SELECT * FROM accounts WHERE email=?", (email,)).fetchone()
            if row is None:
                raise PermissionError("invalid email or password")
            account = self._account(row)
            if not self._password_matches(password, account.get("password_hash")):
                raise PermissionError("invalid email or password")
            now = self._now()
            self._connection.execute("UPDATE accounts SET last_login_at=?,updated_at=? WHERE id=?", (now, now, account["id"]))
            self._connection.commit()
        return self.get(account["id"])

    def set_password(self, account_id: str, password: str) -> None:
        encoded = self._password_hash(password)
        now = self._now()
        with self._lock:
            self.get(account_id)
            self._connection.execute("UPDATE accounts SET password_hash=?,password_changed_at=?,updated_at=?,reset_token_hash=NULL,reset_expires_at=NULL WHERE id=?", (encoded, now, now, account_id))
            self._connection.commit()

    def update_profile(self, account_id: str, *, name: str | None = None, email: str | None = None, profile_picture_ref: str | None = None) -> dict[str, Any]:
        current = self.get(account_id)
        clean_name = current["name"] if name is None else str(name).strip()
        if not clean_name or len(clean_name) > 80:
            raise ValueError("account name must be between 1 and 80 characters")
        clean_email = current.get("email") if email is None else self._normalize_email(email)
        with self._lock:
            if clean_email and self._connection.execute("SELECT 1 FROM accounts WHERE email=? AND id<>?", (clean_email, account_id)).fetchone():
                raise ValueError("email is already registered")
            now = self._now()
            email_changed = clean_email != current.get("email")
            self._connection.execute("UPDATE accounts SET name=?,email=?,email_verified=?,verification_token_hash=?,verification_expires_at=?,profile_picture_ref=?,updated_at=? WHERE id=?", (clean_name, clean_email, 0 if email_changed and clean_email else int(bool(current.get("email_verified"))), None if email_changed else current.get("verification_token_hash"), None if email_changed else current.get("verification_expires_at"), profile_picture_ref if profile_picture_ref is not None else current.get("profile_picture_ref"), now, account_id))
            self._connection.commit()
        return self.get(account_id)

    def begin_email_verification(self, account_id: str, *, ttl_seconds: int = 86400) -> str:
        token = secrets.token_urlsafe(32)
        digest = hashlib.sha256(token.encode()).hexdigest()
        expires = datetime.now(timezone.utc).timestamp() + ttl_seconds
        with self._lock:
            self.get(account_id)
            self._connection.execute("UPDATE accounts SET verification_token_hash=?,verification_expires_at=? WHERE id=?", (digest, datetime.fromtimestamp(expires, timezone.utc).isoformat(), account_id))
            self._connection.commit()
        return token

    def verify_email(self, token: str) -> dict[str, Any]:
        digest = hashlib.sha256(str(token).encode()).hexdigest()
        now = datetime.now(timezone.utc)
        with self._lock:
            row = self._connection.execute("SELECT * FROM accounts WHERE verification_token_hash=?", (digest,)).fetchone()
            if row is None or not row[9] or now >= datetime.fromisoformat(row[9]):
                raise PermissionError("invalid or expired verification token")
            self._connection.execute("UPDATE accounts SET email_verified=1,verification_token_hash=NULL,verification_expires_at=NULL,updated_at=? WHERE id=?", (now.isoformat(), row[0]))
            self._connection.commit()
        return self.get(row[0])

    def begin_password_reset(self, email: str, *, ttl_seconds: int = 3600) -> tuple[str, str] | None:
        email = self._normalize_email(email)
        token = secrets.token_urlsafe(32)
        digest = hashlib.sha256(token.encode()).hexdigest()
        expires = datetime.now(timezone.utc).timestamp() + ttl_seconds
        with self._lock:
            row = self._connection.execute("SELECT id FROM accounts WHERE email=?", (email,)).fetchone()
            if row is None:
                return None
            self._connection.execute("UPDATE accounts SET reset_token_hash=?,reset_expires_at=? WHERE id=?", (digest, datetime.fromtimestamp(expires, timezone.utc).isoformat(), row[0]))
            self._connection.commit()
            return str(row[0]), token

    def reset_password(self, token: str, password: str) -> dict[str, Any]:
        encoded = self._password_hash(password)
        digest = hashlib.sha256(str(token).encode()).hexdigest()
        now = datetime.now(timezone.utc)
        with self._lock:
            row = self._connection.execute("SELECT id,reset_expires_at FROM accounts WHERE reset_token_hash=?", (digest,)).fetchone()
            if row is None or not row[1] or now >= datetime.fromisoformat(row[1]):
                raise PermissionError("invalid or expired password reset token")
            self._connection.execute("UPDATE accounts SET password_hash=?,password_changed_at=?,reset_token_hash=NULL,reset_expires_at=NULL,updated_at=? WHERE id=?", (encoded, now.isoformat(), now.isoformat(), row[0]))
            self._connection.commit()
        return self.get(row[0])

    def bind_root(self, account_id: str, root_id: str) -> dict[str, Any]:
        if not str(root_id).strip():
            raise ValueError("root_id is required")
        now = self._now()
        with self._lock:
            self.get(account_id)
            self._connection.execute("UPDATE accounts SET root_id=?,updated_at=? WHERE id=?", (str(root_id), now, account_id))
            self._connection.commit()
        return self.get(account_id)

    def close(self) -> None:
        with self._lock:
            self._connection.close()
