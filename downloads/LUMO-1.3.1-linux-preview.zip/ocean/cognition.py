from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import re
from typing import Any, Mapping

from ocean.domain.enums import OrchestrationMode


class CognitionMode(str, Enum):
    REFLEX = "reflex"
    TACTICAL = "tactical"
    STRATEGIC = "strategic"
    CRITICAL = "critical"


@dataclass(frozen=True)
class CognitionDecision:
    mode: CognitionMode
    effort: str
    reason: str
    confidence_target: float


@dataclass(frozen=True)
class MissionIntelligenceDecision:
    """Cheap, explicit control decision for how LUMO should think and execute."""

    cognition: CognitionDecision
    orchestration: OrchestrationMode
    max_parallelism: int
    autonomous_swarm: bool
    reason: str


class MissionIntelligenceRouter:
    """Select cognition, orchestration, and parallelism without asking a model.

    The important product behavior is that users request outcomes, not internal
    machinery. LUMO decides when a mission deserves parallel workers/swarm
    execution and records that decision for observability.
    """

    def __init__(self, *, max_parallelism: int = 16) -> None:
        if max_parallelism <= 0:
            raise ValueError("max_parallelism must be positive")
        self._max_parallelism = max_parallelism
        self._cognition = CognitiveRouter()

    def decide(self, objective: str, *, ready_count: int = 1, total_count: int = 1,
               failures: int = 0, uncertainty: float = 0.0) -> MissionIntelligenceDecision:
        cognition = self._cognition.route(
            objective, failures=failures, uncertainty=uncertainty,
            action_risk="high" if uncertainty >= 0.65 else "low",
        )
        # Breadth/dependency structure, not the presence of the word "swarm",
        # determines whether a mission should fan out.
        broad = ready_count >= 4 or total_count >= 8
        parallel = ready_count >= 2
        if broad:
            mode = OrchestrationMode.SWARM
            width = min(self._max_parallelism, max(ready_count, 4))
            reason = "mission has enough independent work to benefit from autonomous swarm execution"
        elif parallel:
            mode = OrchestrationMode.PARALLEL
            width = min(self._max_parallelism, max(ready_count, 2))
            reason = "mission has independent ready work; execute it concurrently"
        else:
            mode = OrchestrationMode.STANDARD
            width = 1
            reason = "mission has no useful parallel frontier"
        return MissionIntelligenceDecision(
            cognition=cognition, orchestration=mode, max_parallelism=width,
            autonomous_swarm=mode is OrchestrationMode.SWARM, reason=reason,
        )


@dataclass(frozen=True)
class WorldContext:
    application: str = ""
    window: str = ""
    image_width: int = 0
    image_height: int = 0
    origin_x: int = 0
    origin_y: int = 0


class CognitiveRouter:
    """Route cognition by ambiguity and consequence, not by one fixed model.

    The router is intentionally deterministic and cheap. Expensive model
    reasoning is reserved for tasks that actually need it.
    """

    _complex = re.compile(r"\b(create|design|build|research|debug|troubleshoot|compare|analy[sz]e|plan|organize|multiple|presentation|slides)\b", re.I)
    _critical = re.compile(r"\b(delete|purchase|pay|send|publish|transfer|password|security|account|permission)\b", re.I)

    def route(
        self,
        objective: str,
        *,
        failures: int = 0,
        uncertainty: float = 0.0,
        action_risk: str = "low",
    ) -> CognitionDecision:
        text = objective.strip()
        if not text:
            raise ValueError("objective must not be empty")
        if failures >= 2 or uncertainty >= 0.65:
            return CognitionDecision(CognitionMode.CRITICAL, "high", "repeated failure or high uncertainty", 0.92)
        if action_risk == "high" and self._critical.search(text):
            return CognitionDecision(CognitionMode.CRITICAL, "high", "high-consequence action requires deep review", 0.98)
        if self._complex.search(text) or len(text.split()) > 40:
            return CognitionDecision(CognitionMode.STRATEGIC, "high", "complex mission requires strategic reasoning", 0.90)
        if action_risk == "high":
            return CognitionDecision(CognitionMode.TACTICAL, "low", "high-risk action with bounded reasoning", 0.88)
        return CognitionDecision(CognitionMode.REFLEX, "low", "clear low-risk action", 0.97)


class ActionBoundary:
    """Cheap, deterministic preflight checks for computer actions."""

    _navigation_keys = {"return", "enter", "tab", "escape", "esc", "left", "right", "up", "down", "home", "end", "pageup", "pagedown"}

    def validate(self, name: str, arguments: Mapping[str, Any], *, world: WorldContext, objective: str) -> tuple[bool, str]:
        if not objective.strip():
            return False, "empty mission boundary"
        if name in {"click", "double_click", "move"}:
            try:
                x, y = float(arguments["x"]), float(arguments["y"])
            except (KeyError, TypeError, ValueError):
                return False, "invalid coordinates"
            if x < 0 or y < 0:
                return False, "negative coordinates"
            if world.image_width and world.image_height and (x > world.image_width or y > world.image_height):
                return False, "coordinate lies outside the observed screenshot"
        if name == "drag" and world.image_width and world.image_height:
            for point in arguments.get("path", []):
                if float(point.get("x", -1)) > world.image_width or float(point.get("y", -1)) > world.image_height:
                    return False, "drag point lies outside the observed screenshot"
        return True, "ok"


@dataclass(frozen=True)
class CompletionContract:
    """Infer minimal evidence required to accept a computer objective.

    This is a conservative guardrail, not a substitute for model judgment:
    objectives that explicitly request an action cannot complete from a stale
    pre-existing screen alone.
    """

    required_families: frozenset[str] = frozenset()

    @classmethod
    def from_objective(cls, objective: str) -> "CompletionContract":
        text = objective.lower()
        families: set[str] = set()
        if re.search(r"\b(open|launch|start|go to|navigate)\b", text):
            families.add("navigation")
        if re.search(r"\b(calculate|type|write|enter|input|fill|search|find)\b", text):
            families.add("interaction")
        if re.search(r"\b(create|design|build|make|edit|modify|update)\b", text):
            families.add("mutation")
        if re.search(r"\b(delete|remove|send|publish|submit|transfer|purchase|pay)\b", text):
            families.add("consequential")
        return cls(frozenset(families))

    @staticmethod
    def family(operation: str) -> str | None:
        if operation in {"open_url", "launch_app"}:
            return "navigation"
        if operation in {"click", "double_click", "drag", "move", "type_text", "key_press", "hotkey", "scroll"}:
            return "interaction"
        return None

    def satisfied(self, operations: list[str]) -> bool:
        if not self.required_families:
            return True
        observed = {family for operation in operations if (family := self.family(operation))}
        if "mutation" in self.required_families and "interaction" not in observed:
            return False
        if "consequential" in self.required_families and "interaction" not in observed:
            return False
        required = {item for item in self.required_families if item in {"navigation", "interaction"}}
        return required.issubset(observed)
