"""Reliability primitives for LUMO Active Assistant computer missions.

These deterministic structures keep autonomy bounded, auditable, resumable, and independent of any model.
"""
from __future__ import annotations

import hashlib
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping

from ocean.advanced_capabilities import RecoveryLearningStore, RecoveryStrategyRegistry, verify_retry_allowed


class ActionRisk(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


@dataclass(frozen=True)
class ActionBudget:
    max_actions: int = 160
    max_runtime_seconds: float = 900.0
    max_retries: int = 4
    max_replans: int = 8
    max_keystrokes: int = 20000
    max_scrolls: int = 80


@dataclass
class BudgetState:
    started_at: float = field(default_factory=time.monotonic)
    actions: int = 0
    retries: int = 0
    replans: int = 0
    keystrokes: int = 0
    scrolls: int = 0

    def allow(self, operation: str, budget: ActionBudget) -> tuple[bool, str]:
        if self.actions >= budget.max_actions: return False, "action budget exhausted"
        if time.monotonic() - self.started_at >= budget.max_runtime_seconds: return False, "runtime budget exhausted"
        if operation in {"key_press", "hotkey", "type_text"} and self.keystrokes >= budget.max_keystrokes: return False, "keystroke budget exhausted"
        if operation == "scroll" and self.scrolls >= budget.max_scrolls: return False, "scroll budget exhausted"
        return True, "ok"

    def record(self, operation: str, *, retry: bool = False, replan: bool = False, key_count: int = 0) -> None:
        self.actions += 1; self.keystrokes += max(0, key_count)
        if operation == "scroll": self.scrolls += 1
        if retry: self.retries += 1
        if replan: self.replans += 1


@dataclass(frozen=True)
class Observation:
    sequence: int
    timestamp: float
    screenshot: str
    application: str = ""
    window: str = ""
    digest: str = ""
    state_summary: str = ""


@dataclass(frozen=True)
class ActionRecord:
    action_id: str
    operation: str
    arguments: Mapping[str, Any]
    success: bool
    timestamp: float
    evidence_digest: str = ""
    error: str | None = None
    risk: ActionRisk = ActionRisk.LOW


@dataclass(frozen=True)
class Evidence:
    evidence_id: str
    kind: str
    value: Any
    source: str
    timestamp: float
    confidence: float


class EvidenceLedger:
    def __init__(self) -> None:
        self.items: list[Evidence] = []

    def add(self, kind: str, value: Any, *, source: str, confidence: float) -> Evidence:
        raw = f"{kind}|{source}|{value}|{time.time_ns()}".encode()
        item = Evidence(hashlib.sha256(raw).hexdigest()[:20], kind, value, source, time.time(), max(0.0, min(1.0, confidence)))
        self.items.append(item); return item

    def has(self, kind: str, predicate: Any = None, minimum_confidence: float = 0.0) -> bool:
        for item in self.items:
            if item.kind != kind or item.confidence < minimum_confidence: continue
            if predicate is None or predicate(item.value): return True
        return False

    def snapshot(self) -> list[dict[str, Any]]:
        return [item.__dict__.copy() for item in self.items]


class LoopDetector:
    def __init__(self, window: int = 8) -> None:
        self.window = max(3, window); self._states: list[str] = []; self._actions: list[str] = []

    @staticmethod
    def state_key(application: str, window: str, screenshot: str) -> str:
        return hashlib.sha256(f"{application}|{window}|{screenshot}".encode()).hexdigest()

    def observe(self, state: str, operation: str) -> tuple[bool, str]:
        self._states.append(state); self._actions.append(operation)
        self._states = self._states[-self.window:]; self._actions = self._actions[-self.window:]
        if len(self._states) >= 4 and len(set(self._states[-4:])) == 1:
            return True, "identical visual state repeated"
        if len(self._actions) >= 4 and len(set(self._actions[-4:])) == 1 and self._actions[-1] not in {"wait", "screenshot"}:
            return True, "identical action repeated"
        if len(self._actions) >= 4 and self._actions[-4:-2] == self._actions[-2:]:
            return True, "action cycle detected"
        return False, "ok"


_SECRET_KEYS = re.compile(r"password|passwd|secret|token|api[_-]?key|authorization|cookie|session|credential|private[_-]?key", re.I)


def redact_arguments(value: Any) -> Any:
    """Remove secrets from durable action telemetry while retaining useful shape."""
    if isinstance(value, Mapping):
        return {str(k): ("[REDACTED]" if _SECRET_KEYS.search(str(k)) else redact_arguments(v)) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [redact_arguments(v) for v in value]
    if isinstance(value, str) and len(value) > 0:
        return value if len(value) <= 2048 else value[:2048] + "…[TRUNCATED]"
    return value


def redact_error(error: str | None) -> str | None:
    if not error:
        return error
    text = str(error)
    text = re.sub(r"(?i)(password|token|api[_-]?key|authorization|cookie|secret)\s*[:=]\s*\S+", r"\1=[REDACTED]", text)
    return text[:1000]


class ActionClassifier:
    _high = re.compile(r"delete|remove|send|publish|submit|purchase|pay|transfer|password|security|account|permission|login", re.I)
    _medium = re.compile(r"close|overwrite|rename|move|save|export|download|upload", re.I)

    @classmethod
    def classify(cls, operation: str, arguments: Mapping[str, Any]) -> ActionRisk:
        text = f"{operation} {arguments}".lower()
        if cls._high.search(text): return ActionRisk.HIGH
        if cls._medium.search(text): return ActionRisk.MEDIUM
        return ActionRisk.LOW


@dataclass(frozen=True)
class PlanNode:
    node_id: str
    goal: str
    status: str = "pending"
    depends_on: tuple[str, ...] = ()
    attempts: int = 0


class PlanLedger:
    def __init__(self, objective: str) -> None:
        self.objective = objective.strip()
        self.nodes: dict[str, PlanNode] = {}
        self.revision = 0
        self.add("root", self.objective)

    def add(self, node_id: str, goal: str, depends_on: tuple[str, ...] = ()) -> PlanNode:
        node = PlanNode(node_id, goal.strip(), "pending", tuple(depends_on), 0); self.nodes[node_id] = node; self.revision += 1; return node

    def update(self, node_id: str, **changes: Any) -> PlanNode:
        old = self.nodes[node_id]; node = PlanNode(node_id, str(changes.get("goal", old.goal)), str(changes.get("status", old.status)), tuple(changes.get("depends_on", old.depends_on)), int(changes.get("attempts", old.attempts))); self.nodes[node_id] = node; self.revision += 1; return node

    def ready(self) -> list[PlanNode]:
        return [n for n in self.nodes.values() if n.status == "pending" and all(self.nodes.get(d, PlanNode(d, "", "failed")).status == "completed" for d in n.depends_on)]

    def snapshot(self) -> dict[str, Any]:
        return {"objective": self.objective, "revision": self.revision, "nodes": [n.__dict__.copy() for n in self.nodes.values()]}


@dataclass(frozen=True)
class Checkpoint:
    task_id: str
    created_at: float
    plan: dict[str, Any]
    observations: list[dict[str, Any]]
    actions: list[dict[str, Any]]
    evidence: list[dict[str, Any]]


class MissionVerifier:
    """Independent completion gate; model claims never suffice.

    Completion requires an evidenced successful action and a post-action screen
    observation. This prevents a stale pre-existing UI state from being treated
    as proof that the current mission performed its requested work.
    """
    @staticmethod
    def verify(contract: Any, observed_operations: list[str], ledger: EvidenceLedger) -> tuple[bool, list[str]]:
        missing: list[str] = []
        if not contract.satisfied(observed_operations):
            missing.append("required action family not executed")
        action_items = [item for item in ledger.items if item.kind == "action" and item.confidence >= 1.0]
        screen_items = [item for item in ledger.items if item.kind == "screen" and item.confidence >= 0.9]
        if getattr(contract, "required_families", None) and not action_items:
            missing.append("no successful action evidence")
        if getattr(contract, "required_families", None):
            latest_action = max(action_items, key=lambda item: item.timestamp, default=None)
            if latest_action is None or not any(item.timestamp > latest_action.timestamp for item in screen_items):
                missing.append("no post-action screen evidence")
        return not missing, missing


def checkpoint(task_id: str, plan: PlanLedger, observations: list[Observation], actions: list[ActionRecord], evidence: EvidenceLedger) -> Checkpoint:
    return Checkpoint(task_id, time.time(), plan.snapshot(), [o.__dict__.copy() for o in observations], [a.__dict__.copy() for a in actions], evidence.snapshot())


# Conservative risk gate used by the execution boundary.
def requires_human_confirmation(operation: str, arguments: Mapping[str, Any]) -> bool:
    return ActionClassifier.classify(operation, arguments) is ActionRisk.HIGH


def semantic_target_hint(application: str, window: str, operation: str) -> str:
    """Return a stable semantic description for logs without pretending pixel coordinates are semantic."""
    return f"{application or 'unknown-app'}::{window or 'unknown-window'}::{operation}"


def summarize_failure(error: str | None) -> str:
    text = (error or "unknown failure").strip().replace("\
", " ")
    return text[:240]

class RecoveryController:
    """Bounded deterministic recovery policy for GUI failures."""
    def __init__(self, max_retries: int = 4, max_replans: int = 8) -> None:
        self.max_retries = max_retries
        self.max_replans = max_replans
        self.retries = 0
        self.replans = 0
        self.strategies = RecoveryStrategyRegistry()
        self.learning = RecoveryLearningStore()
        self.strategies.register("handoff", lambda: "handoff")
        self.strategies.register("retry", lambda: "retry")
        self.strategies.register("replan", lambda: "replan")
        self.strategies.register("abort", lambda: "abort")

    def failure(self, error: str | None) -> str:
        message = (error or "").lower()
        if any(x in message for x in ("user input", "permission", "requires explicit", "denied")):
            decision = self.strategies.execute("handoff")
            self.learning.record("authority", decision, True)
            return decision
        if any(x in message for x in ("timeout", "timed out", "unreachable", "connection")):
            if verify_retry_allowed(verification_passed=False, evidence_count=0, attempt=self.retries, max_attempts=self.max_retries):
                self.retries += 1
                decision = self.strategies.execute("retry")
                self.learning.record("transient", decision, True)
                return decision
        if self.replans < self.max_replans:
            self.replans += 1
            decision = self.strategies.execute("replan")
            self.learning.record("planning", decision, True)
            return decision
        decision = self.strategies.execute("abort")
        self.learning.record("terminal", decision, False)
        return decision

    def snapshot(self) -> dict[str, int]:
        return {"retries": self.retries, "replans": self.replans}


class ProgressTracker:
    def __init__(self) -> None:
        self.completed: set[str] = set()
        self.failed: dict[str, int] = {}

    def record(self, operation: str, success: bool) -> None:
        if success:
            self.completed.add(operation)
        else:
            self.failed[operation] = self.failed.get(operation, 0) + 1

    def snapshot(self) -> dict[str, Any]:
        return {"completed": sorted(self.completed), "failed": dict(self.failed)}
