"""Provider contracts for first-class LUMO execution worlds."""
from __future__ import annotations

from typing import Protocol

from ocean.domain.world import World, WorldRequirements


class WorldProvider(Protocol):
    """A backend capable of provisioning and controlling a world kind."""

    kind: str

    def can_provision(self, requirements: WorldRequirements) -> bool: ...

    def provision(self, world: World) -> World: ...

    def reset(self, world: World) -> World: ...

    def snapshot(self, world: World) -> World: ...

    def clone(self, world: World, mission_id: str | None = None) -> World: ...

    def destroy(self, world: World) -> World: ...

    def close(self) -> None: ...
