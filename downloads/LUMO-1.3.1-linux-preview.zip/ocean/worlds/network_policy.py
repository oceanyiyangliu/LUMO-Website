"""World network egress/DNS policy decisions."""
from __future__ import annotations
import ipaddress, socket
from dataclasses import dataclass
from urllib.parse import urlparse

@dataclass(frozen=True)
class WorldNetworkPolicy:
    allow_network: bool = False
    allowed_domains: frozenset[str] = frozenset()
    block_private_ips: bool = True
    block_local_names: bool = True

    def allows_url(self,url:str)->bool:
        p=urlparse(url); host=(p.hostname or "").rstrip(".").lower()
        if p.scheme not in {"http","https"} or not host or not self.allow_network: return False
        if self.allowed_domains and not any(host==d or host.endswith("."+d) for d in self.allowed_domains): return False
        if self.block_local_names and (host=="localhost" or host.endswith(".localhost") or host.endswith(".local")): return False
        try: addresses={x[4][0] for x in socket.getaddrinfo(host,p.port or (443 if p.scheme=="https" else 80),type=socket.SOCK_STREAM)}
        except OSError: return False
        return bool(addresses) and (not self.block_private_ips or all(ipaddress.ip_address(a).is_global for a in addresses))

    def dns_allowed(self,host:str)->bool:
        if not self.allow_network: return False
        try: addresses={x[4][0] for x in socket.getaddrinfo(host,None,type=socket.SOCK_STREAM)}
        except OSError: return False
        return bool(addresses) and (not self.block_private_ips or all(ipaddress.ip_address(a).is_global for a in addresses))
