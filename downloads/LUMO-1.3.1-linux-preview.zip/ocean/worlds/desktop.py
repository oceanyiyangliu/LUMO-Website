"""Isolated desktop execution world backed by a local QEMU ARM64 VM."""
from __future__ import annotations

import hashlib
import os
import shutil
import socket
import subprocess
import tempfile
import threading
import time
from pathlib import Path
from typing import Any

from ocean.domain.enums import WorldStatus
from ocean.domain.world import World, WorldRequirements
from runtime.types import ExecutionResult


class DesktopWorldExecutor:
    """Computer capability that talks only to a LUMO-owned VM display."""

    def __init__(self, world: World, instance_dir: Path, vnc_port: int):
        self.world = world
        self.instance_dir = instance_dir
        self.vnc_port = vnc_port
        self._lock = threading.RLock()
        self._client = None

    def _connect(self):
        if self._client is not None:
            return self._client
        from vncdotool import api
        client = api.connect(f"127.0.0.1::{self.vnc_port}", timeout=20)
        time.sleep(0.5)
        self._client = client
        return client

    def close(self) -> None:
        with self._lock:
            if self._client is not None:
                try:
                    self._client.disconnect()
                except Exception:
                    pass
                self._client = None

    def _type_text(self, client: Any, text: str) -> None:
        if any(ord(ch) > 127 for ch in text):
            raise ValueError("desktop world type_text supports ASCII only")
        shifted = {
            "!": "1", "@": "2", "#": "3", "$": "4", "%": "5", "^": "6",
            "&": "7", "*": "8", "(": "9", ")": "0", "_": "-", "+": "=",
            ":": ";", "\"": "'", "<": ",", ">": ".", "?": "/",
            "{": "[", "}": "]", "|": "\\", "~": "`",
        }
        for ch in text:
            if ch == "\n":
                client.keyPress("enter")
            elif ch == " ":
                client.keyPress("space")
            elif ch.isupper():
                client.keyDown("shift")
                client.keyPress(ch.lower())
                client.keyUp("shift")
            elif ch in shifted:
                client.keyDown("shift")
                client.keyPress(shifted[ch])
                client.keyUp("shift")
            else:
                client.keyPress(ch)

    def _screenshot(self, args: dict[str, Any]):
        evidence_root = (self.instance_dir / "evidence").resolve()
        requested = args.get("path")
        if requested:
            path = Path(str(requested)).expanduser().resolve()
            if evidence_root not in path.parents:
                raise ValueError("desktop World screenshots must be stored inside the World evidence directory")
        else:
            evidence_root.mkdir(parents=True, exist_ok=True)
            fd, generated = tempfile.mkstemp(prefix="world-", suffix=".png", dir=str(evidence_root))
            os.close(fd)
            path = Path(generated)
        path.parent.mkdir(parents=True, exist_ok=True)
        client = self._connect()
        client.captureScreen(str(path))
        from PIL import Image
        with Image.open(path) as image:
            width, height = image.size
        return ExecutionResult.succeeded({
            "path": path, "width": width, "height": height,
            "capture_width": width, "capture_height": height,
            "origin_x": 0, "origin_y": 0,
            "application": "LUMO World", "window": self.world.id,
        })

    @staticmethod
    def _assert_application_allowed(application: str, metadata: dict[str, Any]) -> None:
        allowed=metadata.get("allowed_applications")
        if allowed is None: return
        if not isinstance(allowed,(list,tuple,set)) or any(not isinstance(x,str) for x in allowed):
            raise PermissionError("allowed_applications must be a list of names")
        if application not in set(allowed):
            raise PermissionError(f"desktop application is not permitted: {application}")

    def execute(self, request: Any, context: Any = None):
        args = dict(request.arguments or {})
        operation = request.operation
        metadata = getattr(request, "metadata", {}) or {}
        try:
            with self._lock:
                if operation in {"clipboard_read", "clipboard_write", "copy", "paste"}:
                    return ExecutionResult.failed("desktop World clipboard is isolated and unavailable")
                if operation == "screenshot":
                    return self._screenshot(args)
                client = self._connect()
                self._assert_application_allowed(str(self.world.metadata.get("application", "LUMO World")), metadata)
                if operation == "click":
                    client.mouseMove(int(args["x"]), int(args["y"]))
                    client.mousePress(1)
                    return ExecutionResult.succeeded({"x": args["x"], "y": args["y"]})
                if operation == "double_click":
                    client.mouseMove(int(args["x"]), int(args["y"]))
                    client.mousePress(1)
                    client.mousePress(1)
                    return ExecutionResult.succeeded({"x": args["x"], "y": args["y"]})
                if operation == "move":
                    client.mouseMove(int(args["x"]), int(args["y"]))
                    return ExecutionResult.succeeded(dict(args))
                if operation == "drag":
                    points = args.get("path", [])
                    if not points:
                        raise ValueError("drag path is required")
                    client.mouseMove(int(points[0]["x"]), int(points[0]["y"]))
                    client.mouseDown(1)
                    for point in points[1:]:
                        client.mouseMove(int(point["x"]), int(point["y"]))
                    client.mouseUp(1)
                    return ExecutionResult.succeeded({"points": len(points)})
                if operation == "type_text":
                    text = str(args["text"])
                    self._type_text(client, text)
                    return ExecutionResult.succeeded({"length": len(text)})
                if operation == "key_press":
                    key = str(args["key"]).lower()
                    client.keyPress(key)
                    return ExecutionResult.succeeded({"key": key})
                if operation == "hotkey":
                    keys = list(args.get("keys", []))
                    keys = [str(key).lower() for key in keys]
                    for key in keys:
                        client.keyDown(key)
                    for key in reversed(keys):
                        client.keyUp(key)
                    return ExecutionResult.succeeded({"keys": keys})
                if operation == "scroll":
                    amount = int(args["amount"])
                    client.keyPress("pagedown" if amount < 0 else "pageup")
                    return ExecutionResult.succeeded({"amount": amount})
                if operation == "wait":
                    seconds = min(float(args.get("seconds", 0)), 10.0)
                    time.sleep(max(0.0, seconds))
                    return ExecutionResult.succeeded({"seconds": seconds})
                if operation == "open_url":
                    client.keyPress("ctrl-l")
                    self._type_text(client, str(args["url"]))
                    client.keyPress("enter")
                    return ExecutionResult.succeeded({"url": args["url"]})
                if operation == "launch_app":
                    client.keyPress("CTRL-ALT-T")
                    self._type_text(client, str(args["app"]))
                    client.keyPress("enter")
                    return ExecutionResult.succeeded({"app": args["app"]})
                return ExecutionResult.failed(f"unsupported desktop world operation: {operation}")
        except Exception as exc:
            return ExecutionResult.failed(str(exc))


class DesktopWorldProvider:
    """Provision one independent Linux desktop per LUMO World."""

    kind = "desktop"

    def __init__(self, *, root=None, memory_mb: int = 4096, cpus: int = 4, max_worlds: int = 4):
        if memory_mb <= 0 or cpus <= 0 or max_worlds <= 0:
            raise ValueError("desktop World resource limits must be positive")
        self.root = Path(root or Path.cwd() / ".lumo-worlds").expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.memory_mb = memory_mb
        self.cpus = cpus
        self.max_worlds = max_worlds
        self._executors: dict[str, DesktopWorldExecutor] = {}
        self._procs: dict[str, int] = {}
        self._quota_lock = threading.RLock()
        self._quota_reservations: set[str] = set()
        self._vnc_ports: dict[str, int] = {}
        # A custom World root should still be able to use the installation's
        # prepared base image. Previously, changing ``root`` made provisioning
        # fail even though a valid base image existed in the default store.
        # Keep the published image path under the custom root when present,
        # otherwise fall back to the provider's installation image. The guest
        # disk remains copy-on-write, so Worlds never share writable state.
        requested_base = self.root / "images" / "lumo-desktop-base.qcow2"
        default_base = Path.cwd().resolve() / ".lumo-worlds" / "images" / "lumo-desktop-base.qcow2"
        self._base = requested_base if requested_base.exists() else default_base
        self._firmware = Path("/opt/homebrew/share/qemu/edk2-aarch64-code.fd")
        self._vars_firmware = Path("/opt/homebrew/share/qemu/edk2-arm-vars.fd")

    def can_provision(self, requirements: WorldRequirements) -> bool:
        if requirements.capabilities and not {"computer", "desktop"}.intersection(requirements.capabilities):
            return False
        resources = requirements.resources
        try:
            requested_memory = float(resources.get("memory_mb", self.memory_mb))
            requested_cpus = float(resources.get("cpus", self.cpus))
        except (TypeError, ValueError):
            return False
        return requested_memory <= self.memory_mb and requested_cpus <= self.cpus

    def _admit_resources(self, world: World) -> None:
        requested_memory = float(world.requirements.resources.get("memory_mb", self.memory_mb))
        requested_cpus = float(world.requirements.resources.get("cpus", self.cpus))
        if requested_memory <= 0 or requested_cpus <= 0:
            raise RuntimeError("desktop World resource requests must be positive")
        if requested_memory > self.memory_mb or requested_cpus > self.cpus:
            raise RuntimeError("desktop World resource quota exceeded")
        with self._quota_lock:
            active = sum(1 for existing in self._executors.values() if existing.world.status not in {WorldStatus.DESTROYED, WorldStatus.FAILED})
            if world.id not in self._quota_reservations and active + len(self._quota_reservations) >= self.max_worlds:
                raise RuntimeError("desktop World resource quota exhausted: max_worlds")
            self._quota_reservations.add(world.id)
        world.resources = {"memory_mb": requested_memory, "cpus": requested_cpus}

    def _commit_resource_reservation(self, world_id: str) -> None:
        with self._quota_lock:
            self._quota_reservations.discard(world_id)

    def _release_resource_reservation(self, world_id: str) -> None:
        """Release a failed provisioning reservation without affecting live Worlds."""
        with self._quota_lock:
            self._quota_reservations.discard(world_id)

    @staticmethod
    def _assert_no_host_device_passthrough(command: list[str]) -> None:
        """Reject QEMU arguments that could attach a host USB/device directly."""
        forbidden = {"usb-host", "vfio-pci", "host-device", "-usbdevice"}
        rendered = " ".join(command).lower()
        if any(token in rendered for token in forbidden):
            raise PermissionError("desktop World forbids host-device/USB passthrough")

    @staticmethod
    def _run_tool(command: list[str], *, timeout: float = 120.0) -> subprocess.CompletedProcess[str]:
        """Run provider-owned image tooling with bounded execution and output."""
        if timeout <= 0 or timeout > 300:
            raise ValueError("tool timeout must be greater than 0 and at most 300 seconds")
        DesktopWorldProvider._assert_no_host_device_passthrough(command)
        env = os.environ.copy()
        env["PATH"] = ":".join(["/opt/homebrew/bin", "/usr/local/bin", env.get("PATH", "")])
        resolved = list(command)
        if resolved and resolved[0] in {"qemu-img", "qemu-system-aarch64"}:
            tool = shutil.which(resolved[0], path=env["PATH"])
            if tool:
                resolved[0] = tool
        return subprocess.run(
            resolved, check=True, capture_output=True, text=True, timeout=timeout, env=env,
        )


    def _allocate_vnc_port(self) -> int:
        for port in range(5901, 6001):
            if port in self._vnc_ports.values():
                continue
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(("127.0.0.1", port))
            except OSError:
                continue
            finally:
                sock.close()
            return port
        raise RuntimeError("no free VNC port available for desktop world")

    def _seed(self, world: World, instance: Path) -> Path:
        seed = instance / "seed"
        seed.mkdir(parents=True, exist_ok=True)
        (seed / "meta-data").write_text(
            f"instance-id: {world.id}\nlocal-hostname: lumo-{world.id}\n"
        )
        (seed / "user-data").write_text("""#cloud-config
users:
  - name: lumo
    groups: [audio, video, input]
    shell: /bin/bash
    lock_passwd: true
package_update: true
packages:
  - xfce4
  - xfce4-goodies
  - lightdm
  - firefox-esr
  - xterm
  - dbus-x11
  - policykit-1
  - xdotool
  - curl
  - ca-certificates
write_files:
  - path: /etc/lightdm/lightdm.conf.d/50-lumo.conf
    permissions: '0644'
    content: |
      [Seat:*]
      autologin-user=lumo
      autologin-user-timeout=0
      user-session=xfce
runcmd:
  - systemctl set-default graphical.target
  - systemctl enable lightdm
  - systemctl restart lightdm || true
""")
        iso = instance / "seed.iso"
        # hdiutil refuses to overwrite an existing output. Use a unique
        # provider-owned temporary path, then atomically replace the published
        # seed so restart/reprovision is idempotent after partial failures.
        fd, temp_name = tempfile.mkstemp(prefix="seed-", suffix=".iso", dir=str(instance))
        os.close(fd)
        temp_iso = Path(temp_name)
        try:
            temp_iso.unlink()
            self._run_tool([
                "hdiutil", "makehybrid", "-o", str(temp_iso), "-hfs", "-joliet",
                "-iso", "-default-volume-name", "cidata", str(seed)
            ], timeout=120.0)
            os.replace(temp_iso, iso)
        finally:
            try:
                temp_iso.unlink()
            except FileNotFoundError:
                pass
        return iso

    def provision(self, world: World) -> World:
        self._admit_resources(world)
        if not self._base.exists():
            raise RuntimeError(f"desktop world base image missing: {self._base}")
        if not self._firmware.exists():
            raise RuntimeError(f"QEMU firmware missing: {self._firmware}")
        if not self._vars_firmware.exists():
            raise RuntimeError(f"QEMU variable firmware missing: {self._vars_firmware}")
        instance = self.root / "instances" / world.id
        instance.mkdir(parents=True, exist_ok=True)
        code = instance / "code.fd"
        vars_file = instance / "vars.fd"
        if not code.exists():
            shutil.copyfile(self._firmware, code)
        if not vars_file.exists():
            shutil.copyfile(self._vars_firmware, vars_file)
        disk = instance / "disk.qcow2"
        if not disk.exists():
            self._run_tool([
                "qemu-img", "create", "-f", "qcow2", "-b", str(self._base),
                "-F", "qcow2", str(disk), "32G"
            ], timeout=120.0)
        seed = self._seed(world, instance)
        vnc_port = self._allocate_vnc_port()
        pidfile = instance / "qemu.pid"
        serial = instance / "serial.log"
        cmd = [
            "qemu-system-aarch64", "-accel", "hvf", "-M", "virt", "-cpu", "host",
            "-smp", str(self.cpus), "-m", str(self.memory_mb),
            "-drive", f"if=pflash,format=raw,readonly=on,file={code}",
            "-drive", f"if=pflash,format=raw,file={vars_file}",
            "-drive", f"if=virtio,format=qcow2,file={disk}",
            "-drive", f"if=virtio,format=raw,file={seed},readonly=on",
            "-display", "none",
            "-vnc", f"127.0.0.1:{vnc_port - 5900}",
            "-serial", f"file:{serial}", "-pidfile", str(pidfile), "-daemonize",
        ]
        if world.requirements.network:
            cmd[cmd.index("-display"):cmd.index("-display")] = ["-nic", "user,model=virtio-net-pci,restrict=on"]
        self._assert_no_host_device_passthrough(cmd)
        env = os.environ.copy()
        env["PATH"] = ":".join(["/opt/homebrew/bin", "/usr/local/bin", env.get("PATH", "")])
        subprocess.run(cmd, check=True, capture_output=True, env=env)
        deadline = time.monotonic() + 30.0
        while True:
            try:
                with socket.create_connection(("127.0.0.1", vnc_port), timeout=1.0):
                    break
            except OSError:
                if time.monotonic() >= deadline:
                    pid = int(pidfile.read_text().strip()) if pidfile.exists() else None
                    if pid:
                        try:
                            os.kill(pid, 15)
                        except ProcessLookupError:
                            pass
                    raise RuntimeError(f"desktop world VNC did not become ready: {vnc_port}")
                time.sleep(0.25)
        self._procs[world.id] = int(pidfile.read_text().strip())
        self._vnc_ports[world.id] = vnc_port
        self._executors[world.id] = DesktopWorldExecutor(world, instance, vnc_port)
        self._commit_resource_reservation(world.id)
        world.metadata.update({
            "backend": "qemu", "isolated": True, "display": "vnc",
        })
        world.capabilities = tuple(dict.fromkeys((*world.capabilities, "computer", "desktop")))
        world.transition(WorldStatus.READY)
        return world

    def executor(self, world_id: str):
        return self._executors[world_id]

    def _reattach_existing(self, world: World) -> bool:
        """Reattach to a surviving QEMU after a control-plane restart.

        Provisioning is not transactional with process creation: QEMU can
        survive a crashed/aborted API startup. Reusing that VM is safer than
        launching a second QEMU against the same disk image.
        """
        instance = self.root / "instances" / world.id
        pidfile = instance / "qemu.pid"
        if not pidfile.is_file():
            return False
        try:
            pid = int(pidfile.read_text().strip())
        except (OSError, ValueError):
            return False
        try:
            os.kill(pid, 0)
        except (OSError, ProcessLookupError):
            try:
                pidfile.unlink()
            except FileNotFoundError:
                pass
            return False
        try:
            result = subprocess.run(
                ["ps", "-p", str(pid), "-o", "command="],
                check=True, capture_output=True, text=True, timeout=5.0,
            )
            command = result.stdout.strip()
        except (OSError, subprocess.SubprocessError):
            return False
        if "qemu-system-aarch64" not in command or str(instance) not in command:
            return False
        parts = command.split()
        try:
            vnc_arg = parts[parts.index("-vnc") + 1]
            host, display = vnc_arg.rsplit(":", 1)
            if host != "127.0.0.1":
                return False
            vnc_port = 5900 + int(display)
        except (ValueError, IndexError):
            return False
        try:
            with socket.create_connection(("127.0.0.1", vnc_port), timeout=1.0):
                pass
        except OSError:
            return False
        self._procs[world.id] = pid
        self._vnc_ports[world.id] = vnc_port
        self._executors[world.id] = DesktopWorldExecutor(world, instance, vnc_port)
        return True

    def restore(self, world: World) -> World:
        if world.id in self._executors:
            return world
        if world.status is WorldStatus.DESTROYED:
            raise RuntimeError(f"cannot restore destroyed desktop world: {world.id}")
        if self._reattach_existing(world):
            if world.status is not WorldStatus.PROVISIONING:
                world.transition(WorldStatus.PROVISIONING)
            world.transition(WorldStatus.READY)
            return world
        if world.status is not WorldStatus.PROVISIONING:
            world.transition(WorldStatus.PROVISIONING)
        return self.provision(world)

    def reset(self, world: World) -> World:
        self.destroy(world)
        instance = self.root / "instances" / world.id
        for filename in ("disk.qcow2", "vars.fd", "seed.iso", "qemu.pid", "serial.log"):
            path = instance / filename
            try:
                path.unlink()
            except FileNotFoundError:
                pass
        world.snapshot_id = None
        world.metadata.pop("snapshot_path", None)
        world.status = WorldStatus.PROVISIONING
        return self.provision(world)

    def snapshot(self, world: World) -> World:
        if world.id not in self._executors:
            raise RuntimeError(f"desktop World is not provisioned: {world.id}")
        source = self.root / "instances" / world.id / "disk.qcow2"
        destination = self.root / "snapshots" / f"{world.id}-{int(time.time())}.qcow2"
        destination.parent.mkdir(parents=True, exist_ok=True)
        self._run_tool(["qemu-img", "convert", "-O", "qcow2", str(source), str(destination)], timeout=300.0)
        digest = hashlib.sha256()
        with destination.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        world.snapshot_id = destination.name
        world.metadata["snapshot_sha256"] = digest.hexdigest()
        return world

    def clone(self, world: World, mission_id: str | None = None) -> World:
        self.snapshot(world)
        snapshot = self.root / "snapshots" / str(world.snapshot_id)
        if not snapshot.is_file():
            raise RuntimeError(f"desktop World snapshot is unavailable: {world.snapshot_id}")
        expected_hash = world.metadata.get("snapshot_sha256")
        if not isinstance(expected_hash, str) or len(expected_hash) != 64:
            raise RuntimeError("desktop World snapshot integrity metadata is missing")
        digest = hashlib.sha256()
        with snapshot.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        if digest.hexdigest() != expected_hash:
            raise RuntimeError("desktop World snapshot integrity check failed")
        clone = World(
            kind=self.kind, mission_id=mission_id, account_id=world.account_id, requirements=world.requirements,
            capabilities=world.capabilities, resources=world.resources,
            metadata={"cloned_from": world.id},
        )
        self._admit_resources(clone)
        # Provision from the provider-owned snapshot without exposing its host path.
        instance = self.root / "instances" / clone.id
        instance.mkdir(parents=True, exist_ok=True)
        code = instance / "code.fd"
        vars_file = instance / "vars.fd"
        if not code.exists(): shutil.copyfile(self._firmware, code)
        if not vars_file.exists(): shutil.copyfile(self._vars_firmware, vars_file)
        disk = instance / "disk.qcow2"
        self._run_tool(["qemu-img", "create", "-f", "qcow2", "-b", str(snapshot), "-F", "qcow2", str(disk), "32G"], timeout=120.0)
        # Reuse the normal provisioning path after replacing the base disk.
        # The existing provision path only creates a disk when absent, so the
        # snapshot-derived disk remains authoritative.
        seed = self._seed(clone, instance)
        vnc_port = self._allocate_vnc_port()
        pidfile = instance / "qemu.pid"
        serial = instance / "serial.log"
        cmd = [
            "qemu-system-aarch64", "-accel", "hvf", "-M", "virt", "-cpu", "host",
            "-smp", str(self.cpus), "-m", str(self.memory_mb),
            "-drive", f"if=pflash,format=raw,readonly=on,file={code}",
            "-drive", f"if=pflash,format=raw,file={vars_file}",
            "-drive", f"if=virtio,format=qcow2,file={disk}",
            "-drive", f"if=virtio,format=raw,file={seed},readonly=on",
            "-display", "none", "-vnc", f"127.0.0.1:{vnc_port - 5900}",
            "-serial", f"file:{serial}", "-pidfile", str(pidfile), "-daemonize",
        ]
        if clone.requirements.network:
            cmd[cmd.index("-display"):cmd.index("-display")] = ["-nic", "user,model=virtio-net-pci,restrict=on"]
        self._assert_no_host_device_passthrough(cmd)
        env = os.environ.copy()
        env["PATH"] = ":".join(["/opt/homebrew/bin", "/usr/local/bin", env.get("PATH", "")])
        subprocess.run(cmd, check=True, capture_output=True, env=env)
        deadline = time.monotonic() + 30.0
        while True:
            try:
                with socket.create_connection(("127.0.0.1", vnc_port), timeout=1.0): break
            except OSError:
                if time.monotonic() >= deadline:
                    pid = int(pidfile.read_text().strip()) if pidfile.exists() else None
                    if pid:
                        try: os.kill(pid, 15)
                        except ProcessLookupError: pass
                    raise RuntimeError(f"desktop world VNC did not become ready: {vnc_port}")
                time.sleep(0.25)
        self._procs[clone.id] = int(pidfile.read_text().strip())
        self._vnc_ports[clone.id] = vnc_port
        self._executors[clone.id] = DesktopWorldExecutor(clone, instance, vnc_port)
        self._commit_resource_reservation(clone.id)
        clone.metadata.update({"backend": "qemu", "isolated": True, "display": "vnc"})
        clone.capabilities = tuple(dict.fromkeys((*clone.capabilities, "computer", "desktop")))
        clone.transition(WorldStatus.READY)
        return clone

    def destroy(self, world: World) -> World:
        self._release_resource_reservation(world.id)
        executor = self._executors.pop(world.id, None)
        if executor:
            executor.close()
        pid = self._procs.pop(world.id, None)
        self._vnc_ports.pop(world.id, None)
        if pid:
            try:
                os.kill(pid, 15)
            except ProcessLookupError:
                pass
            deadline = time.monotonic() + 5.0
            while time.monotonic() < deadline:
                try:
                    os.kill(pid, 0)
                except ProcessLookupError:
                    break
                time.sleep(0.1)
            else:
                try:
                    os.kill(pid, 9)
                except ProcessLookupError:
                    pass
        if world.status is not WorldStatus.DESTROYED:
            if world.status in {WorldStatus.READY, WorldStatus.RUNNING, WorldStatus.PAUSED}:
                world.transition(WorldStatus.DESTROYING)
            if world.status is WorldStatus.DESTROYING:
                world.transition(WorldStatus.DESTROYED)
        return world

    def close(self):
        pids = list(self._procs.items())
        for _, pid in pids:
            try:
                os.kill(pid, 15)
            except ProcessLookupError:
                pass
        deadline = time.monotonic() + 5.0
        remaining = dict(pids)
        while remaining and time.monotonic() < deadline:
            remaining = {
                world_id: pid for world_id, pid in remaining.items()
                if self._pid_alive(pid)
            }
            if remaining:
                time.sleep(0.1)
        for _, pid in remaining.items():
            try:
                os.kill(pid, 9)
            except ProcessLookupError:
                pass
        self._procs.clear()
        for executor in self._executors.values():
            executor.close()
        self._executors.clear()
        self._vnc_ports.clear()

    @staticmethod
    def _pid_alive(pid: int) -> bool:
        try:
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False
