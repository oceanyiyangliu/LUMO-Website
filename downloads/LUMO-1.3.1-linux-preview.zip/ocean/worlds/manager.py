"""Lifecycle manager for isolated LUMO execution worlds."""
from __future__ import annotations

import threading
from typing import Any, Callable, Iterable

from ocean.domain.event import Event

from ocean.domain.enums import WorldStatus
from ocean.domain.world import World, WorldRequirements
from ocean.domain.policy import PolicyContext, PolicyEngine
from ocean.domain.capability import CapabilityRegistry
from ocean.domain.enums import ApprovalDecision
from ocean.capabilities.browser import browser_spec
from ocean.capabilities.computer import computer_spec
from .provider import WorldProvider


class WorldManager:
    """Select providers and own the in-memory authoritative world registry.

    Persistence is deliberately delegated to the surrounding event/durable
    state layers; this manager is the lifecycle boundary, not a second source
    of truth.
    """

    def __init__(self, providers: Iterable[WorldProvider] = (), event_sink: Callable[[Event], Any] | None = None) -> None:
        self._providers: dict[str, WorldProvider] = {}
        self._worlds: dict[str, World] = {}
        self._execution_locks: dict[str, threading.RLock] = {}
        self._lock = threading.RLock()
        self._event_sink = event_sink
        for provider in providers:
            self.register_provider(provider)

    def set_event_sink(self, event_sink: Callable[[Event], Any] | None) -> None:
        self._event_sink = event_sink

    def register_hydrated(self, world: World) -> None:
        """Install a replayed world without provisioning a second runtime.

        Hydration is deliberately explicit so event replay never needs to reach
        into manager internals or accidentally create external resources.
        """
        with self._lock:
            if world.id in self._worlds:
                return
            self._worlds[world.id] = world
            self._execution_locks.setdefault(world.id, threading.RLock())

    def _emit(self, event_type: str, world: World, **extra: Any) -> None:
        if self._event_sink is None:
            return
        self._event_sink(Event(
            type=event_type,
            payload={
                "world_id": world.id, "mission_id": world.mission_id,
                "account_id": world.account_id,
                "kind": world.kind, "status": world.status.value,
                "capabilities": list(world.capabilities),
                "resources": dict(world.resources),
                "requirements": {
                    "capabilities": list(world.requirements.capabilities),
                    "resources": dict(world.requirements.resources),
                    "persistent": world.requirements.persistent,
                    "network": world.requirements.network,
                },
                "metadata": {
                    key: value for key, value in dict(world.metadata).items()
                    if key not in {"vnc_port", "instance_dir", "snapshot_path", "executor", "base_snapshot"}
                },
                "snapshot_id": world.snapshot_id,
                **extra,
            },
            aggregate_type="world", aggregate_id=world.id,
            correlation_id=world.mission_id, source="world_manager",
        ))

    def register_provider(self, provider: WorldProvider) -> None:
        if not provider.kind.strip():
            raise ValueError("world provider kind is required")
        with self._lock:
            if provider.kind in self._providers:
                raise ValueError(f"world provider already registered: {provider.kind}")
            self._providers[provider.kind] = provider

    def provider(self, kind: str) -> WorldProvider:
        with self._lock:
            try:
                return self._providers[kind]
            except KeyError as exc:
                raise KeyError(f"unknown world provider: {kind}") from exc

    def provider_for(self, requirements: WorldRequirements, kind: str | None = None) -> WorldProvider:
        with self._lock:
            providers = [self._providers[kind]] if kind else list(self._providers.values())
            for provider in providers:
                if provider.can_provision(requirements):
                    return provider
        requested = f" for kind '{kind}'" if kind else ""
        raise ValueError(f"no world provider satisfies requirements{requested}")

    def create(
        self,
        *,
        mission_id: str | None = None,
        account_id: str | None = None,
        kind: str | None = None,
        requirements: WorldRequirements | None = None,
        metadata: dict | None = None,
    ) -> World:
        requirements = requirements or WorldRequirements()
        provider = self.provider_for(requirements, kind)
        world = World(kind=provider.kind, mission_id=mission_id, account_id=account_id, requirements=requirements, metadata=metadata or {})
        with self._lock:
            self._worlds[world.id] = world
            self._execution_locks[world.id] = threading.RLock()
        try:
            result = provider.provision(world)
            self._emit("WorldCreated", result)
            return result
        except Exception as exc:
            release = getattr(provider, "_release_resource_reservation", None)
            if callable(release):
                release(world.id)
            with self._lock:
                world.transition(WorldStatus.FAILED)
            self._emit("WorldProvisionFailed", world, error=str(exc))
            raise

    def get(self, world_id: str) -> World:
        with self._lock:
            try:
                return self._worlds[world_id]
            except KeyError as exc:
                raise KeyError(f"unknown world: {world_id}") from exc

    def list(self, mission_id: str | None = None) -> list[World]:
        with self._lock:
            worlds = list(self._worlds.values())
        if mission_id is not None:
            worlds = [world for world in worlds if world.mission_id == mission_id]
        return worlds

    def execute(self, world_id: str, request: Any, context: Any = None):
        """Execute one request through the world's provider-owned boundary.

        A World is a hard actuator boundary: callers must identify the exact
        world, and the requested capability must match that world's declared
        interface. In particular, a desktop World can only receive the
        provider's VM-backed ``computer``/``desktop`` capability; this method
        never consults the host macOS executor registry.
        """
        world = self.get(world_id)
        if getattr(request, "account_id", None) is not None and str(request.account_id) != str(world.account_id):
            raise PermissionError("world execution account boundary mismatch")
        with self._lock:
            execution_lock = self._execution_locks.setdefault(world.id, threading.RLock())
        request_metadata = getattr(request, "metadata", {}) or {}
        if world.account_id is not None:
            requested_account_id = request_metadata.get("account_id")
            if requested_account_id is None or str(requested_account_id) != str(world.account_id):
                raise PermissionError("world execution account boundary mismatch")
        requested_world_id = request_metadata.get("world_id")
        if requested_world_id is not None and str(requested_world_id) != world.id:
            raise PermissionError(
                f"world execution boundary mismatch: request targets {requested_world_id!r}, world is {world.id!r}"
            )
        capability = str(getattr(request, "capability", "")).strip()
        allowed_capabilities = {
            "browser": {"browser"},
            "desktop": {"computer", "desktop"},
        }.get(world.kind, set(world.capabilities))
        if capability not in allowed_capabilities:
            raise PermissionError(
                f"capability {capability!r} is not permitted inside {world.kind!r} World {world.id}"
            )
        if world.status in {WorldStatus.DESTROYED, WorldStatus.DESTROYING, WorldStatus.FAILED}:
            raise RuntimeError(f"World {world.id} is not executable in state {world.status.value}")
        provider = self._providers.get(world.kind)
        if provider is None:
            raise ValueError(f"world provider {world.kind!r} is unavailable")
        # World execution must retain the governance boundary instead of
        # calling a provider executor as an ungoverned escape hatch. World
        # ownership authorizes *which* world may be touched; operation policy
        # still decides whether the requested action is automatically allowed
        # or requires an explicit approval carried by the agent request.
        spec = browser_spec() if world.kind == "browser" else computer_spec()
        operation = spec.operation(getattr(request, "operation", ""))
        decision = PolicyEngine().evaluate(PolicyContext(
            capability=capability, operation=operation.name,
            risk_level=operation.risk_level, metadata=dict(request_metadata),
        ))
        if decision.value == "denied":
            raise PermissionError("world operation denied by policy")
        if decision in {ApprovalDecision.USER_CONFIRMATION_REQUIRED, ApprovalDecision.EXPLICIT_APPROVAL_REQUIRED}:
            if not bool(request_metadata.get("approval_granted")):
                raise PermissionError("world operation requires explicit approval")
        executor_factory = getattr(provider, "executor", None)
        if not callable(executor_factory):
            raise ValueError(f"world provider {world.kind!r} has no executor")
        with execution_lock:
            world = self.get(world_id)
            if world.status in {WorldStatus.DESTROYED, WorldStatus.DESTROYING, WorldStatus.FAILED}:
                raise RuntimeError(f"World {world.id} is not executable in state {world.status.value}")
            capability_executor = executor_factory(world.id)
            if world.status is WorldStatus.READY:
                world.transition(WorldStatus.RUNNING)
            self._emit(
                "WorldExecutionStarted", world,
                request_id=getattr(request, "id", None),
                operation=getattr(request, "operation", None),
                capability=capability,
            )
            try:
                result = capability_executor.execute(request, context)
                if context is not None:
                    checker = getattr(context, "raise_if_cancelled", None)
                    if callable(checker):
                        checker()
                return result
            finally:
                if world.status is WorldStatus.RUNNING:
                    world.transition(WorldStatus.READY)
                    self._emit(
                        "WorldExecutionFinished", world,
                        request_id=getattr(request, "id", None),
                        operation=getattr(request, "operation", None),
                        capability=capability,
                    )
                if not world.requirements.persistent and world.status is WorldStatus.READY:
                    provider.destroy(world)
                    self._emit(
                        "WorldDestroyed", world,
                        reason="non_persistent_execution",
                    )

    def reset(self, world_id: str) -> World:
        world = self.get(world_id)
        with self._lock:
            execution_lock = self._execution_locks.setdefault(world.id, threading.RLock())
        with execution_lock:
            world = self.get(world_id)
            provider = self._providers[world.kind]
            result = provider.reset(world)
            self._emit("WorldReset", result)
            return result

    def destroy(self, world_id: str) -> World:
        world = self.get(world_id)
        with self._lock:
            execution_lock = self._execution_locks.setdefault(world.id, threading.RLock())
        with execution_lock:
            world = self.get(world_id)
            provider = self._providers[world.kind]
            result = provider.destroy(world)
            self._emit("WorldDestroyed", result)
            return result

    def force_destroy(self, world_id: str, *, reason: str = "forced_destroy") -> World:
        """Immediately tear down a World without waiting for its execution lock.

        This is reserved for authoritative safety controls such as Emergency
        Stop. Providers must terminate their external process/browser resources
        here; the normal lifecycle lock is intentionally bypassed so a stuck
        actuator cannot delay the safety boundary.
        """
        world = self.get(world_id)
        with self._lock:
            provider = self._providers[world.kind]
            result = provider.destroy(world)
            self._emit("WorldForceDestroyed", result, reason=reason)
            return result

    def close(self) -> None:
        """Close all Worlds durably before releasing provider resources.

        A clean service shutdown must not leave a READY/RUNNING world looking
        live in the event log; otherwise the next process can resurrect a VM
        that the previous process intentionally tore down.
        """
        with self._lock:
            worlds = list(self._worlds.values())
            providers = list(self._providers.values())
        for world in worlds:
            if world.status in {WorldStatus.DESTROYED, WorldStatus.FAILED}:
                continue
            provider = self._providers.get(world.kind)
            if provider is None:
                continue
            try:
                provider.destroy(world)
            except Exception as exc:
                if world.status is not WorldStatus.FAILED:
                    try:
                        world.transition(WorldStatus.FAILED)
                    except ValueError:
                        pass
                self._emit("WorldDestroyFailed", world, error=str(exc), reason="manager_close")
                continue
            self._emit("WorldDestroyed", world, reason="manager_close")
        for provider in providers:
            provider.close()

    def snapshot(self, world_id: str) -> World:
        world = self.get(world_id)
        result = self._providers[world.kind].snapshot(world)
        self._emit("WorldSnapshotCreated", result)
        return result

    def clone(self, world_id: str, *, mission_id: str | None = None) -> World:
        source = self.get(world_id)
        clone = self._providers[source.kind].clone(source, mission_id)
        if clone.account_id is None:
            clone.account_id = source.account_id
        with self._lock:
            self._worlds[clone.id] = clone
        self._emit("WorldCloned", clone, source_world_id=source.id)
        return clone
