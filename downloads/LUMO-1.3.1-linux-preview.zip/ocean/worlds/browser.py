"""Browser-world provider backed by isolated Playwright profiles."""
from __future__ import annotations

from ocean.capabilities.browser import PlaywrightBrowserExecutor
import hashlib
from pathlib import Path
from ocean.domain.enums import WorldStatus
from ocean.domain.world import World, WorldRequirements


class BrowserWorldProvider:
    kind = "browser"

    def __init__(self, *, root=None, headless: bool = True) -> None:
        self.root = root
        self.headless = headless
        self._executors: dict[str, PlaywrightBrowserExecutor] = {}

    def can_provision(self, requirements: WorldRequirements) -> bool:
        return requirements.network and (
            not requirements.capabilities
            or "browser" in requirements.capabilities
        )

    def provision(self, world: World) -> World:
        executor = PlaywrightBrowserExecutor(
            worker_id=world.id, root=self.root, headless=self.headless
        )
        self._executors[world.id] = executor
        world.metadata["executor"] = "playwright"
        world.metadata["isolated"] = True
        world.capabilities = tuple(dict.fromkeys((*world.capabilities, "browser")))
        world.transition(WorldStatus.READY)
        return world

    def executor(self, world_id: str) -> PlaywrightBrowserExecutor:
        try:
            return self._executors[world_id]
        except KeyError as exc:
            raise KeyError(f"unknown browser world: {world_id}") from exc

    def restore(self, world: World) -> World:
        if world.id in self._executors:
            return world
        self._executors[world.id] = PlaywrightBrowserExecutor(
            worker_id=world.id, root=self.root, headless=self.headless
        )
        world.metadata["executor"] = "playwright"
        world.metadata["isolated"] = True
        world.transition(WorldStatus.READY)
        return world

    def reset(self, world: World) -> World:
        executor = self.executor(world.id)
        executor.close()
        self._executors[world.id] = PlaywrightBrowserExecutor(
            worker_id=world.id, root=self.root, headless=self.headless
        )
        world.snapshot_id = None
        world.transition(WorldStatus.PROVISIONING)
        world.transition(WorldStatus.READY)
        return world

    def destroy(self, world: World) -> World:
        executor = self._executors.pop(world.id, None)
        if executor is not None:
            world.transition(WorldStatus.DESTROYING)
            executor.close()
        if world.status is not WorldStatus.DESTROYED:
            world.transition(WorldStatus.DESTROYED)
        return world

    def close(self) -> None:
        for executor in list(self._executors.values()):
            executor.close()
        self._executors.clear()

    def snapshot(self, world: World) -> World:
        import shutil
        from datetime import datetime, timezone

        executor = self.executor(world.id)
        executor.close()
        source = executor.profile_dir
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        snapshot_id = f"snap_{world.id}_{stamp}"
        destination = Path(self.root or source.parent) / "snapshots" / snapshot_id
        destination.parent.mkdir(parents=True, exist_ok=True)
        if source.exists():
            shutil.copytree(source, destination)
        else:
            destination.mkdir(parents=True, exist_ok=True)
        digest = hashlib.sha256()
        for path in sorted(destination.rglob("*")):
            if path.is_file():
                digest.update(str(path.relative_to(destination)).encode())
                with path.open("rb") as handle:
                    for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                        digest.update(chunk)
        world.snapshot_id = snapshot_id
        world.metadata["snapshot_path"] = str(destination)
        world.metadata["snapshot_sha256"] = digest.hexdigest()
        self._executors[world.id] = PlaywrightBrowserExecutor(
            worker_id=world.id, root=self.root, headless=self.headless
        )
        world.transition(WorldStatus.PROVISIONING)
        world.transition(WorldStatus.READY)
        return world

    def clone(self, world: World, mission_id: str | None = None) -> World:
        import shutil

        snapshot = world.metadata.get("snapshot_path")
        if not snapshot:
            self.snapshot(world)
            snapshot = world.metadata.get("snapshot_path")
        clone = World(
            kind=self.kind,
            mission_id=mission_id,
            account_id=world.account_id,
            requirements=world.requirements,
            capabilities=world.capabilities,
            resources=world.resources,
            metadata={"cloned_from": world.id, "snapshot_path": snapshot},
        )
        executor = PlaywrightBrowserExecutor(
            worker_id=clone.id, root=self.root, headless=self.headless
        )
        destination = executor.profile_dir
        if snapshot:
            snapshot_path = Path(snapshot).expanduser().resolve()
            root = Path(self.root or snapshot_path.parent).expanduser().resolve()
            if root != snapshot_path and root not in snapshot_path.parents:
                raise PermissionError("browser World snapshot is outside the provider root")
            if snapshot_path.exists():
                expected_hash = world.metadata.get("snapshot_sha256")
                if expected_hash:
                    digest = hashlib.sha256()
                    for path in sorted(snapshot_path.rglob("*")):
                        if path.is_file():
                            digest.update(str(path.relative_to(snapshot_path)).encode())
                            with path.open("rb") as handle:
                                for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                                    digest.update(chunk)
                    if digest.hexdigest() != expected_hash:
                        raise RuntimeError("browser World snapshot integrity check failed")
                shutil.copytree(snapshot_path, destination, dirs_exist_ok=True)
        self._executors[clone.id] = executor
        clone.snapshot_id = world.snapshot_id
        clone.transition(WorldStatus.READY)
        return clone
