"""Authenticated encryption envelope for World snapshot bytes."""
from __future__ import annotations
import os
from dataclasses import dataclass
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

@dataclass(frozen=True)
class EncryptedSnapshot:
    key_id: str
    nonce: bytes
    ciphertext: bytes

class SnapshotCipher:
    def __init__(self, keyring):
        self.keyring = keyring
    def encrypt(self, data: bytes) -> EncryptedSnapshot:
        if not isinstance(data, bytes): raise TypeError("snapshot data must be bytes")
        key_id = self.keyring.active_key_id
        key = self.keyring.key_bytes(key_id)
        nonce = os.urandom(12)
        return EncryptedSnapshot(key_id, nonce, AESGCM(key).encrypt(nonce, data, key_id.encode()))
    def decrypt(self, envelope: EncryptedSnapshot) -> bytes:
        key = self.keyring.key_bytes(envelope.key_id)
        return AESGCM(key).decrypt(envelope.nonce, envelope.ciphertext, envelope.key_id.encode())
