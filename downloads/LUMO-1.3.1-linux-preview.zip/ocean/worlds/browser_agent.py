"""Model-guided browser worker loop for isolated execution worlds."""
from __future__ import annotations

from typing import Any, Mapping

from ocean.domain.world import World
from runtime.types import ExecutionRequest


class BrowserAgent:
    """Drive one isolated browser world with bounded observe/plan/act cycles.

    The model proposes actions; the world executes them. No action is sent to
    the user's physical desktop. Each cycle observes only the current page and
    a bounded action history, keeping the loop adaptive without requiring a
    full strategic re-plan after every deterministic action.
    """

    def __init__(self, *, world_manager, planner, max_cycles: int = 12) -> None:
        if world_manager is None or planner is None:
            raise ValueError("world_manager and planner are required")
        if max_cycles <= 0 or max_cycles > 32:
            raise ValueError("max_cycles must be between 1 and 32")
        self._worlds = world_manager
        self._planner = planner
        self._max_cycles = max_cycles

    def run(self, *, mission_id: str, objective_id: str, goal: str, world: World) -> Mapping[str, Any]:
        if world.kind != "browser":
            raise ValueError("BrowserAgent requires a browser world")
        history: list[dict[str, Any]] = []
        page_text = ""
        page_url = ""
        page_title = ""

        for cycle in range(self._max_cycles):
            plan = self._planner.plan_browser_actions(
                goal=goal,
                page_url=page_url,
                page_title=page_title,
                page_text=page_text,
                history=history,
            )
            if not isinstance(plan, Mapping):
                raise ValueError("browser planner returned a non-object plan")
            actions = plan.get("actions", [])
            if not isinstance(actions, list) or len(actions) > 8:
                raise ValueError("browser planner returned too many actions")
            if bool(plan.get("done")) and not actions:
                return {"success": True, "cycles": cycle + 1, "url": page_url, "title": page_title, "history": history}
            if not actions:
                raise ValueError("browser planner returned neither completion nor actions")

            for index, action in enumerate(actions):
                if not isinstance(action, Mapping):
                    raise ValueError(f"browser action {index} is not an object")
                operation = str(action.get("operation", "")).strip()
                arguments = action.get("arguments", {})
                if operation not in {"navigate", "click", "fill", "extract", "screenshot"} or not isinstance(arguments, Mapping):
                    raise ValueError(f"invalid browser action {index}")
                request = ExecutionRequest(
                    task_id=objective_id,
                    capability="browser",
                    operation=operation,
                    mission_id=mission_id,
                    source="browser_agent",
                    metadata={"world_id": world.id, "account_id": world.account_id, "approval_granted": True},
                    arguments=dict(arguments),
                )
                result = self._worlds.execute(world.id, request)
                record = {"cycle": cycle, "operation": operation, "success": result.success, "result": result.result, "error": result.error}
                history.append(record)
                if not result.success:
                    return {"success": False, "cycles": cycle + 1, "error": result.error or "browser operation failed", "history": history}
                if isinstance(result.result, Mapping):
                    page_url = str(result.result.get("url", page_url))
                    page_title = str(result.result.get("title", page_title))
                    if operation == "extract":
                        page_text = str(result.result.get("text", ""))

            # If the plan changed the page without extracting it, obtain a
            # bounded observation for the next reasoning cycle.
            if history and history[-1]["operation"] != "extract":
                request = ExecutionRequest(
                    task_id=objective_id, capability="browser", operation="extract",
                    mission_id=mission_id, source="browser_agent", metadata={"world_id": world.id, "account_id": world.account_id, "approval_granted": True}, arguments={"locator": "body", "max_chars": 50_000},
                )
                result = self._worlds.execute(world.id, request)
                if not result.success:
                    return {"success": False, "cycles": cycle + 1, "error": result.error or "browser observation failed", "history": history}
                page_url = str(result.result.get("url", page_url))
                page_title = str(result.result.get("title", page_title))
                page_text = str(result.result.get("text", ""))
                history.append({"cycle": cycle, "operation": "extract", "success": True, "result": {"url": page_url, "title": page_title, "text_chars": len(page_text)}})

        return {"success": False, "cycles": self._max_cycles, "error": "browser agent cycle limit reached", "history": history, "url": page_url, "title": page_title}
