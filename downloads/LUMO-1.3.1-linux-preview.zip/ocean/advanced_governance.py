"""Machine-checkable governance records and invariant checks."""
from __future__ import annotations
from dataclasses import dataclass,field
from datetime import datetime,timezone
from enum import Enum
import hashlib,json,secrets

class RiskBand(str,Enum): SAFE="safe"; LOW="low"; IMPORTANT="important"; HIGH="high"; CRITICAL="critical"
@dataclass(frozen=True)
class ScopedGrant:
    principal_id:str; account_id:str; mission_id:str|None=None; device_id:str|None=None; permissions:frozenset[str]=frozenset(); expires_at:datetime|None=None
    def valid(self,now=None): return bool(self.principal_id and self.account_id and (self.expires_at is None or (now or datetime.now(timezone.utc))<self.expires_at))
@dataclass(frozen=True)
class ApprovalReceipt:
    approval_id:str; principal_id:str; action:str; risk:RiskBand; issued_at:datetime; expires_at:datetime|None=None; metadata:dict=field(default_factory=dict)
    def valid(self,now=None): return self.expires_at is None or (now or datetime.now(timezone.utc))<self.expires_at
@dataclass(frozen=True)
class PolicyRevision:
    version:int; rules:dict; created_at:datetime=field(default_factory=lambda:datetime.now(timezone.utc))
    @property
    def fingerprint(self): return hashlib.sha256(json.dumps(self.rules,sort_keys=True,separators=(",",":")).encode()).hexdigest()

def normalize_denial(reasons):
    mapping={"authorization requires a principal identity":"AUTH_REQUIRED","unknown credential":"AUTH_INVALID","credential expired":"AUTH_EXPIRED","invalid CSRF token":"CSRF_INVALID","operation policy denied execution":"POLICY_DENIED","usage limit reached":"QUOTA_EXCEEDED"}
    return tuple(mapping.get(str(r),"DENIED") for r in reasons)

def escalate_risk(base:RiskBand, context:dict)->RiskBand:
    if context.get("irreversible") or context.get("external_side_effect") or context.get("secret_access"): return RiskBand.CRITICAL if base is RiskBand.HIGH else RiskBand.HIGH
    return base

class GovernanceInvariantChecker:
    def check(self, *, emergency_stop:bool, executing:bool, approval:ApprovalReceipt|None=None, grant:ScopedGrant|None=None, account_id:str|None=None, verified:bool=False)->tuple[str,...]:
        violations=[]
        if emergency_stop and executing: violations.append("EMERGENCY_STOP_EXECUTION")
        if executing and grant is None: violations.append("MISSING_GRANT")
        if grant is not None and (not grant.valid() or (account_id is not None and grant.account_id!=account_id)): violations.append("INVALID_SCOPE")
        if approval is not None and not approval.valid(): violations.append("EXPIRED_APPROVAL")
        if executing and not verified: violations.append("UNVERIFIED_EXECUTION")
        return tuple(violations)
