"""First-person-view projection for the LUMO workforce and execution worlds."""
from __future__ import annotations
from typing import Any
from ocean.observability.agent_pov import AgentPOVProjector


class FPVProjector:
    """Build a safe, observable mission graph from durable events.

    This intentionally exposes operational state, evidence, world identity and
    current actions, never hidden chain-of-thought.
    """
    def __init__(self, events, worlds) -> None:
        self._events = events
        self._worlds = worlds

    def snapshot(self) -> dict[str, Any]:
        events = list(self._events.history()) if self._events is not None else []
        agents = AgentPOVProjector()
        agents.rebuild(events)
        nodes: list[dict[str, Any]] = []
        mission_ids = {}
        for event in events:
            if event.type == "MissionStarted":
                mid = event.payload.get("mission_id") or event.aggregate_id
                if mid:
                    mission_ids[str(mid)] = {"id": str(mid), "type": "mission", "status": "running", "goal": event.payload.get("goal", "")}
            elif event.type == "MissionCompleted" and event.aggregate_id:
                mission_ids[str(event.aggregate_id)] = {**mission_ids.get(str(event.aggregate_id), {"id": str(event.aggregate_id), "type": "mission"}), "status": "completed"}
            elif event.type in {"MissionBlocked", "MissionBlockedPendingUser", "MissionReplanStagnated"} and event.aggregate_id:
                mission_ids[str(event.aggregate_id)] = {**mission_ids.get(str(event.aggregate_id), {"id": str(event.aggregate_id), "type": "mission"}), "status": "blocked"}
        nodes.extend(mission_ids.values())
        for pov in agents.all():
            nodes.append({
                "id": pov.agent_id, "type": "agent", "mission_id": pov.mission_id,
                "task_id": pov.task_id, "status": pov.status,
                "activity": pov.current_activity, "observation": dict(pov.current_observation),
                "action": dict(pov.current_action), "uncertainty": pov.uncertainty,
                "policy_state": pov.policy_state, "evidence_ids": list(pov.evidence_ids),
                "resource_usage": dict(pov.resource_usage),
                "updated_at": pov.updated_at.isoformat() if pov.updated_at else None,
            })
        for world in self._worlds.list():
            nodes.append({
                "id": world.id, "type": "world", "mission_id": world.mission_id,
                "status": world.status.value, "kind": world.kind,
                "capabilities": list(world.capabilities), "metadata": dict(world.metadata),
                "snapshot_id": world.snapshot_id,
            })
        return {"nodes": nodes, "edges": self._edges(nodes, events), "updated_at": max((e.at for e in events), default=None).isoformat() if events else None}

    @staticmethod
    def _edges(nodes: list[dict[str, Any]], events) -> list[dict[str, str]]:
        edges: list[dict[str, str]] = []
        for node in nodes:
            mission_id = node.get("mission_id")
            if mission_id:
                edges.append({"source": str(mission_id), "target": str(node["id"]), "kind": "contains"})
            if node.get("type") == "agent" and node.get("task_id"):
                edges.append({"source": str(node["id"]), "target": str(node["task_id"]), "kind": "executes"})
        seen = {tuple(sorted((e["source"], e["target"]))) for e in edges}
        for event in events:
            if event.type in {"WorldCreated", "WorldExecutionStarted"}:
                wid = event.payload.get("world_id")
                aid = event.payload.get("agent_id") or event.payload.get("objective_id")
                if wid and aid and (str(aid), str(wid)) not in seen:
                    edges.append({"source": str(aid), "target": str(wid), "kind": "operates"})
        return edges
