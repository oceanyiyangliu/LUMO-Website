"""Durable, provider-agnostic LUMO transactional mail outbox.

The outbox keeps delivery metadata in SQLite and keeps message secrets (verification
and reset tokens) in the native secure store. Failed messages remain durable and are
retried with bounded exponential backoff.
"""
from __future__ import annotations
import json, sqlite3, threading, time, uuid
from pathlib import Path
from typing import Any
from ocean.email_delivery import EmailDelivery
from ocean.security import KeychainTokenStore

class EmailOutbox:
    MAX_ATTEMPTS = 8
    POLL_SECONDS = 15.0
    BASE_BACKOFF = 5.0
    MAX_BACKOFF = 3600.0

    def __init__(self, path: str | Path, delivery: EmailDelivery, *, start_worker: bool = True):
        self.path = Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)
        self.delivery = delivery; self._lock = threading.RLock(); self._stop = threading.Event()
        self._db = sqlite3.connect(str(self.path), check_same_thread=False, timeout=30)
        self._db.execute("PRAGMA journal_mode=WAL"); self._db.execute("PRAGMA busy_timeout=30000")
        self._db.execute("""CREATE TABLE IF NOT EXISTS email_outbox (
            id TEXT PRIMARY KEY, account_id TEXT, recipient_domain TEXT,
            template TEXT NOT NULL, subject TEXT NOT NULL, status TEXT NOT NULL,
            attempts INTEGER NOT NULL DEFAULT 0, next_attempt_at REAL NOT NULL,
            created_at REAL NOT NULL, updated_at REAL NOT NULL, sent_at REAL, last_error TEXT
        )""")
        self._db.execute("CREATE INDEX IF NOT EXISTS idx_email_outbox_due ON email_outbox(status, next_attempt_at)")
        self._db.commit(); self._secure = KeychainTokenStore("LUMO Email Outbox")
        if start_worker:
            self._worker = threading.Thread(target=self._run, name="lumo-email-outbox", daemon=True)
            self._worker.start()

    def close(self) -> None:
        self._stop.set()
        with self._lock: self._db.close()

    def enqueue(self, *, to: str, subject: str, template: str, variables: dict[str, str],
                account_id: str | None = None, deliver_now: bool = True) -> dict[str, Any]:
        recipient = str(to or "").strip()
        if "@" not in recipient: raise ValueError("recipient email address is invalid")
        message_id = uuid.uuid4().hex; now = time.time()
        payload = {"to": recipient, "subject": str(subject), "template": str(template),
                   "variables": {str(k): str(v) for k, v in variables.items()}}
        self._secure.set(message_id, json.dumps(payload, separators=(",", ":")))
        with self._lock:
            self._db.execute("""INSERT INTO email_outbox
                (id, account_id, recipient_domain, template, subject, status, attempts,
                 next_attempt_at, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, 'pending', 0, ?, ?, ?)""",
                (message_id, account_id, recipient.rsplit("@", 1)[1].lower(), template,
                 subject, now, now, now))
            self._db.commit()
        result = {"queued": True, "id": message_id}
        if deliver_now: result.update(self._deliver(message_id))
        return result

    def process_pending(self, *, limit: int = 20) -> int:
        with self._lock:
            rows = self._db.execute("""SELECT id FROM email_outbox
                WHERE status IN ('pending','retrying') AND next_attempt_at <= ?
                ORDER BY next_attempt_at ASC LIMIT ?""",
                (time.time(), max(1, min(int(limit), 100)))).fetchall()
        return sum(1 for (mid,) in rows if self._deliver(mid).get("sent"))

    def status(self) -> dict[str, Any]:
        with self._lock:
            counts = dict(self._db.execute("SELECT status, COUNT(*) FROM email_outbox GROUP BY status").fetchall())
            row = self._db.execute("""SELECT id, template, attempts, created_at, updated_at, sent_at, last_error
                FROM email_outbox ORDER BY created_at DESC LIMIT 1""").fetchone()
        return {"provider": self.delivery.provider, "configured": self.delivery.configured,
                "pending": int(counts.get("pending", 0) + counts.get("retrying", 0)),
                "failed": int(counts.get("failed", 0)), "sent": int(counts.get("sent", 0)),
                "last": None if row is None else {"id": row[0], "template": row[1], "attempts": row[2],
                    "created_at": row[3], "updated_at": row[4], "sent_at": row[5], "error": row[6]},
                "delivery": self.delivery.status()}

    def _deliver(self, message_id: str) -> dict[str, Any]:
        with self._lock:
            row = self._db.execute("SELECT status, attempts FROM email_outbox WHERE id = ?", (message_id,)).fetchone()
            if row is None or row[0] == "sent": return {"sent": row is not None and row[0] == "sent", "id": message_id}
            attempts = int(row[1])
            self._db.execute("UPDATE email_outbox SET status='sending', updated_at=? WHERE id=?", (time.time(), message_id)); self._db.commit()
        try:
            raw = self._secure.get(message_id)
            if not raw: raise RuntimeError("secure email payload is unavailable")
            payload = json.loads(raw)
            self.delivery.send(to=payload["to"], subject=payload["subject"], template=payload["template"], variables=payload["variables"])
            now = time.time()
            with self._lock:
                self._db.execute("""UPDATE email_outbox SET status='sent', attempts=?, sent_at=?,
                    updated_at=?, last_error=NULL WHERE id=?""", (attempts + 1, now, now, message_id)); self._db.commit()
            try: self._secure.delete(message_id)
            except Exception: pass
            return {"sent": True, "id": message_id}
        except Exception as exc:
            attempts += 1; terminal = attempts >= self.MAX_ATTEMPTS; now = time.time()
            delay = min(self.MAX_BACKOFF, self.BASE_BACKOFF * (2 ** min(attempts - 1, 10)))
            with self._lock:
                self._db.execute("""UPDATE email_outbox SET status=?, attempts=?, next_attempt_at=?,
                    updated_at=?, last_error=? WHERE id=?""",
                    ("failed" if terminal else "retrying", attempts, now + delay, now, str(exc)[:1000], message_id)); self._db.commit()
            return {"sent": False, "queued": not terminal, "failed": terminal, "id": message_id, "error": str(exc)[:1000]}

    def _run(self) -> None:
        while not self._stop.wait(self.POLL_SECONDS):
            try: self.process_pending(limit=20)
            except Exception: continue
