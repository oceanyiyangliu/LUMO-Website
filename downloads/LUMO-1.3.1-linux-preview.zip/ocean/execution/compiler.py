"""Compile immutable planning graphs into executable orchestration steps."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Protocol, Sequence

from ocean.domain.task import Task
from ocean.domain.work_graph import WorkEdgeKind, WorkGraph, WorkNodeKind
from ocean.orchestration.types import ExecutionIntent


class ExecutionIntentResolver(Protocol):
    """Resolve a Task into the capability operation that can execute it."""

    def resolve(self, task: Task) -> ExecutionIntent:
        ...


@dataclass(frozen=True)
class ExecutionStep:
    """One executable task derived from a WorkGraph node."""

    node_id: str
    task_id: str
    intent: ExecutionIntent
    depends_on_node_ids: tuple[str, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.node_id or not self.node_id.strip():
            raise ValueError("execution step node_id must be non-empty")
        if not self.task_id or not self.task_id.strip():
            raise ValueError("execution step task_id must be non-empty")

        dependencies = tuple(self.depends_on_node_ids)

        if self.node_id in dependencies:
            raise ValueError(
                "execution step cannot depend on itself"
            )

        if len(dependencies) != len(set(dependencies)):
            raise ValueError(
                "execution step cannot contain duplicate dependencies"
            )

        object.__setattr__(self, "depends_on_node_ids", dependencies)
        object.__setattr__(self, "metadata", dict(self.metadata))


@dataclass(frozen=True)
class ExecutionPlan:
    """Immutable executable representation of a validated WorkGraph."""

    mission_id: str
    plan_revision_id: str
    steps: tuple[ExecutionStep, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.mission_id or not self.mission_id.strip():
            raise ValueError("execution plan mission_id must be non-empty")

        if not self.plan_revision_id or not self.plan_revision_id.strip():
            raise ValueError(
                "execution plan plan_revision_id must be non-empty"
            )

        steps = tuple(self.steps)
        step_ids = [step.node_id for step in steps]

        if len(step_ids) != len(set(step_ids)):
            raise ValueError(
                "execution plan cannot contain duplicate node ids"
            )

        known_ids = set(step_ids)

        for step in steps:
            unknown = set(step.depends_on_node_ids) - known_ids
            if unknown:
                raise ValueError(
                    f"execution step {step.node_id!r} references "
                    f"unknown dependency nodes: {sorted(unknown)!r}"
                )

        object.__setattr__(self, "steps", steps)
        object.__setattr__(self, "metadata", dict(self.metadata))

    def step(self, node_id: str) -> ExecutionStep:
        """Return the executable step for a node."""
        for step in self.steps:
            if step.node_id == node_id:
                return step
        raise KeyError(f"unknown execution step: {node_id!r}")

    def dependencies(self, node_id: str) -> tuple[str, ...]:
        """Return direct dependency node IDs in deterministic order."""
        return self.step(node_id).depends_on_node_ids

    def dependents(self, node_id: str) -> tuple[str, ...]:
        """Return direct dependent node IDs in deterministic order."""
        self.step(node_id)

        dependents = [
            step.node_id
            for step in self.steps
            if node_id in step.depends_on_node_ids
        ]
        return tuple(sorted(dependents))

    def ready_steps(
        self,
        completed_node_ids: set[str] | frozenset[str] | tuple[str, ...] = (),
    ) -> tuple[ExecutionStep, ...]:
        """Return executable steps whose dependencies are all completed.

        A step is ready only when every direct dependency has completed.
        Already-completed steps are excluded. Results are deterministic and
        preserve the execution plan's canonical step ordering.
        """
        completed = set(completed_node_ids)

        unknown_completed = completed - {
            step.node_id for step in self.steps
        }
        if unknown_completed:
            raise ValueError(
                "completed_node_ids contains unknown execution steps: "
                f"{sorted(unknown_completed)!r}"
            )

        return tuple(
            step
            for step in self.steps
            if step.node_id not in completed
            and set(step.depends_on_node_ids).issubset(completed)
        )


class PlanExecutionCompiler:
    """Compile a validated WorkGraph into executable TASK steps.

    The compiler is deliberately pure with respect to the planning and
    runtime domains:

    - it does not mutate Tasks or WorkGraph;
    - it does not assign agents;
    - it does not create Assignments;
    - it does not schedule executions;
    - it does not execute capabilities;
    - it does not evaluate conditions.

    TASK nodes become ExecutionSteps. Structural control-flow nodes are
    currently rejected because their runtime semantics have not yet been
    defined. This prevents unsupported planning semantics from being
    silently discarded.
    """

    def compile(
        self,
        graph: WorkGraph,
        tasks: Sequence[Task],
        resolver: ExecutionIntentResolver,
    ) -> ExecutionPlan:
        if graph is None:
            raise ValueError("graph is required")

        if resolver is None:
            raise ValueError("resolver is required")

        task_list = tuple(tasks)

        task_by_id: dict[str, Task] = {}

        for task in task_list:
            if task is None:
                raise ValueError("tasks cannot contain None")

            if task.id in task_by_id:
                raise ValueError(
                    f"duplicate task in execution compiler input: {task.id!r}"
                )

            if task.mission_id != graph.mission_id:
                raise ValueError(
                    f"task {task.id!r} belongs to mission "
                    f"{task.mission_id!r}, not {graph.mission_id!r}"
                )

            task_by_id[task.id] = task

        node_by_id = {node.id: node for node in graph.nodes}

        task_nodes = [
            node for node in graph.nodes
            if node.kind is WorkNodeKind.TASK
        ]

        structural_nodes = [
            node for node in graph.nodes
            if node.kind is not WorkNodeKind.TASK
        ]

        if structural_nodes:
            kinds = sorted(
                {node.kind.value for node in structural_nodes}
            )
            raise ValueError(
                "unsupported structural work nodes in execution compiler: "
                + ", ".join(kinds)
            )

        for node in task_nodes:
            if node.task_id not in task_by_id:
                raise ValueError(
                    f"task node {node.id!r} references unknown task "
                    f"{node.task_id!r}"
                )

        dependency_map: dict[str, list[str]] = {
            node.id: [] for node in task_nodes
        }

        for edge in graph.edges:
            if edge.kind is not WorkEdgeKind.DEPENDENCY:
                raise ValueError(
                    "conditional work edges are not executable yet"
                )

            source = node_by_id[edge.source_node_id]
            target = node_by_id[edge.target_node_id]

            if (
                source.kind is not WorkNodeKind.TASK
                or target.kind is not WorkNodeKind.TASK
            ):
                raise ValueError(
                    "dependency edges involving structural nodes are not "
                    "executable yet"
                )

            dependency_map[target.id].append(source.id)

        # WorkGraph is already acyclic. Sorting here gives deterministic
        # compiler output independent of the original node/edge ordering.
        ordered_nodes = sorted(
            task_nodes,
            key=lambda node: node.id,
        )

        steps: list[ExecutionStep] = []

        for node in ordered_nodes:
            task = task_by_id[node.task_id]
            intent = resolver.resolve(task)

            if not isinstance(intent, ExecutionIntent):
                raise TypeError(
                    f"execution intent resolver returned "
                    f"{type(intent).__name__}, expected ExecutionIntent"
                )

            dependencies = tuple(
                sorted(set(dependency_map[node.id]))
            )

            steps.append(
                ExecutionStep(
                    node_id=node.id,
                    task_id=task.id,
                    intent=intent,
                    depends_on_node_ids=dependencies,
                )
            )

        return ExecutionPlan(
            mission_id=graph.mission_id,
            plan_revision_id=graph.plan_revision_id,
            steps=tuple(steps),
        )
