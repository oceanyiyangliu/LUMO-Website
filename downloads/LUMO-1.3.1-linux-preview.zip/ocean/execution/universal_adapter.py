from __future__ import annotations

"""
Adapter boundary: translate a repository-agnostic "UniversalAction" into the
control-plane's ExecutionRequest/ExecutionResult model and delegate to an
executor instance.

This module deliberately only performs translation and delegation. It does not
mutate production state, create workspaces, perform promotions, or assume any
authority beyond constructing request/result objects and calling an executor
API that already exists in the runtime.

Usage:
    from ocean.execution.universal_adapter import (
        UniversalAction, execute_universal_action, executor_from_name
    )

    action = UniversalAction(...)
    executor = executor_from_name("deterministic_local")  # optional helper
    result = execute_universal_action(action, executor)

The executor is only required to provide an execute(request) -> ExecutionResult
callable. This keeps the adapter decoupled from concrete executor constructors
and their configuration.
"""

from dataclasses import dataclass, field
from typing import Any, Mapping, MutableMapping, Optional, TYPE_CHECKING
import uuid
import time

from ocean.domain.enums import OrchestrationMode

if TYPE_CHECKING:
    from runtime.control import CancellationToken
    from runtime.runtime import ExecutionRuntime

from runtime.types import ExecutionRequest, ExecutionResult


@dataclass(frozen=True)
class UniversalAction:
    """A repository-agnostic action description.

    Fields are intentionally small and generic so multiple callers (models,
    UI, remote agents) can produce them. The adapter maps these into the
    project's ExecutionRequest shape.
    """

    id: str
    capability: str
    operation: str
    arguments: MutableMapping[str, Any] = field(default_factory=dict)
    timeout_seconds: Optional[float] = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    task_id: Optional[str] = None
    principal_id: Optional[str] = None
    agent_id: Optional[str] = None
    mission_id: Optional[str] = None
    mode: OrchestrationMode = OrchestrationMode.STANDARD

    def __post_init__(self) -> None:
        if not self.id:
            # allow empty id to be auto-assigned by helper
            object.__setattr__(self, "id", str(uuid.uuid4()))


@dataclass(frozen=True)
class UniversalActionResult:
    """Portable execution result shape returned by the adapter."""

    request_id: str
    status: str
    exit_code: Optional[int] = None
    stdout: str = ""
    stderr: str = ""
    duration_seconds: Optional[float] = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    outputs: Mapping[str, Any] = field(default_factory=dict)


def universal_to_execution_request(action: UniversalAction) -> ExecutionRequest:
    """Translate a UniversalAction into the project's ExecutionRequest.

    This function intentionally preserves fields in a one-to-one fashion when
    possible. If ExecutionRequest gains or changes fields, update this
    translation to maintain fidelity.
    """
    # ExecutionRequest constructor shape may vary across repo versions. Use
    # attribute names that are commonly present; if the concrete ExecutionRequest
    # requires different args this function should be updated accordingly.
    return ExecutionRequest(
        task_id=action.task_id or action.id,
        capability=action.capability,
        operation=action.operation,
        agent_id=action.agent_id,
        principal_id=action.principal_id,
        mission_id=action.mission_id,
        mode=action.mode,
        arguments=dict(action.arguments or {}),
        metadata=dict(action.metadata or {}),
    )


def execution_result_to_universal_result(result: ExecutionResult) -> UniversalActionResult:
    """Translate ExecutionResult into the adapter's UniversalActionResult.

    Preserve common diagnostics so callers can make deterministic promotion/verification
    decisions without touching executor internals.
    """
    # Map commonly-used fields. If ExecutionResult uses different names,
    # adapt this function to match the canonical model.
    metadata = dict(getattr(result, "metadata", {}) or {})
    request_id = getattr(result, "request_id", None) or metadata.get("execution_id", "")
    success = getattr(result, "success", None)
    status = getattr(result, "status", None)
    if status is None:
        status = "succeeded" if success is True else "failed" if success is False else "unknown"
    error = getattr(result, "error", None)
    exit_code = metadata.get("exit_code", getattr(result, "exit_code", None))
    stdout = metadata.get("stdout", getattr(result, "stdout", ""))
    stderr = metadata.get("stderr", getattr(result, "stderr", ""))
    duration = metadata.get("duration_seconds", getattr(result, "duration_seconds", None))
    outputs = getattr(result, "outputs", None)
    if outputs is None:
        raw_result = getattr(result, "result", None)
        outputs = raw_result if isinstance(raw_result, Mapping) else ({"result": raw_result} if raw_result is not None else {})
    if error and not stderr:
        stderr = str(error)

    return UniversalActionResult(
        request_id=str(request_id),
        status=str(status),
        exit_code=exit_code,
        stdout=str(stdout or ""),
        stderr=str(stderr or ""),
        duration_seconds=duration,
        metadata=metadata,
        outputs=dict(outputs or {}),
    )


def execute_universal_action(
    action: UniversalAction,
    runtime: "ExecutionRuntime",
    *,
    cancellation: "CancellationToken | None" = None,
) -> UniversalActionResult:
    """Execute through the canonical ExecutionRuntime governance boundary.

    A UniversalAction is data, not authority. Raw CapabilityExecutor objects
    are intentionally rejected so this adapter cannot bypass capability
    discovery, authorization, resource admission, isolation, lifecycle events,
    cancellation, or terminal-state handling.
    """
    from runtime.runtime import ExecutionRuntime as _ExecutionRuntime

    if not isinstance(runtime, _ExecutionRuntime):
        raise TypeError("universal actions must execute through ExecutionRuntime")

    request = universal_to_execution_request(action)
    start = time.time()
    result = runtime.execute(
        request,
        cancellation=cancellation,
        timeout_seconds=action.timeout_seconds,
    )
    elapsed = time.time() - start

    universal_result = execution_result_to_universal_result(result)
    if universal_result.duration_seconds is None:
        object.__setattr__(universal_result, "duration_seconds", elapsed)
    return universal_result
