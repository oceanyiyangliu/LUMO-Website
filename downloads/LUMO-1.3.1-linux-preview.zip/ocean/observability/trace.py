from __future__ import annotations

from eventing.store import EventStore
from .types import AuditEvent

class TraceReader:
    def __init__(self, store: EventStore) -> None:
        self._store = store

    def correlated_events(self, correlation_id: str) -> list[AuditEvent]:
        return [self._wrap(e) for e in self._store.list() if e.correlation_id == correlation_id]

    def causal_chain(self, event_id: str) -> list[AuditEvent]:
        events = {e.id: e for e in self._store.list()}
        current = events.get(event_id)
        if current is None:
            return []

        chain = []
        visited = set()

        while current is not None and current.id not in visited:
            visited.add(current.id)
            chain.append(self._wrap(current))
            if current.causation_id is None:
                break
            current = events.get(current.causation_id)

        chain.reverse()
        return chain

    def causally_related(self, event_id: str) -> list[AuditEvent]:
        events = {e.id: e for e in self._store.list()}
        if event_id not in events:
            return []

        result = []
        queue = [event_id]
        seen = set()

        while queue:
            parent = queue.pop(0)
            if parent in seen:
                continue
            seen.add(parent)
            event = events.get(parent)
            if event is None:
                continue
            result.append(self._wrap(event))
            queue.extend(e.id for e in events.values() if e.causation_id == parent)

        result.sort(key=lambda x: (x.sequence if x.sequence is not None else 0, x.id))
        return result

    def _wrap(self, event) -> AuditEvent:
        return AuditEvent(event=event, sequence=self._store.sequence(event.id))
