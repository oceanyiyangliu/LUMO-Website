"""Operational status and progress projection for Ocean."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Mapping, Optional

from ocean.domain.event import Event
from eventing.store import EventStore


MISSION_STARTED = {"MissionStarted"}
MISSION_COMPLETED = {"MissionCompleted"}
MISSION_FAILED = {"MissionFailed"}
MISSION_BLOCKED = {"MissionBlocked"}
MISSION_PAUSED = {"MissionPaused"}
MISSION_STAGNATED = {"MissionReplanStagnated"}
MISSION_CONTRACT_UNSATISFIED = {"MissionContractUnsatisfied"}
MISSION_REPLAN_LIMIT = {"MissionReplanLimitReached"}
MISSION_CANCELLED = {"MissionCancelled"}
MISSION_DEAD_LETTERED = {"MissionDeadLettered"}
MISSION_BLOCKED_PENDING_USER = {"MissionBlockedPendingUser"}
MISSION_RETRYING = {"MissionRetryScheduled"}
MISSION_REPLANNING = {"MissionReplanning", "MissionPlanningStarted"}

OBJECTIVE_STARTED = {"ObjectiveStarted", "TaskStarted"}
OBJECTIVE_COMPLETED = {"ObjectiveCompleted", "TaskCompleted"}
OBJECTIVE_FAILED = {"ObjectiveFailed", "ObjectiveRejected", "TaskFailed"}
OBJECTIVE_QUEUED = {"ObjectiveQueued"}

VERIFICATION_STARTED = {"VerificationStarted"}
VERIFICATION_COMPLETED = {"VerificationCompleted"}

# Real autonomous Builder lifecycle emitted by SelfImprovementCoordinator.
BUILDER_STARTED = {"ImprovementAttemptStarted"}
BUILDER_RESEARCH = {"ResearchFindingRecorded"}
BUILDER_CANDIDATE = {
    "ImprovementCandidateCreated",
    "ImprovementCheckpointCreated",
}
BUILDER_EXECUTION = {
    "ExecutionCreated",
    "ExecutionStarted",
    "ExecutionSucceeded",
    "ExecutionFailed",
    "ExecutionTimedOut",
    "ExecutionCancelled",
}
BUILDER_VERIFICATION = {"VerificationStarted", "VerificationRecorded"}
BUILDER_DECISION = {"ImprovementDecisionMade"}
BUILDER_PROMOTION = {"PlanCoordinatorAdvanced"}
BUILDER_FAILED = {"ImprovementAttemptFailed"}

_ACTIVITY_EVENTS = (
    MISSION_STARTED
    | MISSION_COMPLETED
    | MISSION_FAILED
    | MISSION_BLOCKED
    | MISSION_PAUSED
    | MISSION_STAGNATED
    | MISSION_CONTRACT_UNSATISFIED
    | MISSION_REPLAN_LIMIT
    | MISSION_CANCELLED
    | MISSION_DEAD_LETTERED
    | MISSION_BLOCKED_PENDING_USER
    | MISSION_RETRYING
    | MISSION_REPLANNING
    | OBJECTIVE_STARTED
    | OBJECTIVE_COMPLETED
    | OBJECTIVE_FAILED
    | OBJECTIVE_QUEUED
    | VERIFICATION_STARTED
    | VERIFICATION_COMPLETED
)


@dataclass(frozen=True)
class ObjectiveStatus:
    objective_id: str
    objective: str = ""
    status: str = "pending"
    progress: float = 0.0
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error: Optional[str] = None
    current_activity: Optional[str] = None
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class MissionStatus:
    mission_id: str
    status: str = "unknown"
    progress: float = 0.0
    objective_count: int = 0
    completed_objectives: int = 0
    failed_objectives: int = 0
    queued_objectives: int = 0
    active_objectives: int = 0
    verification_state: str = "idle"
    current_activity: Optional[str] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    last_event_at: Optional[datetime] = None
    latest_error: Optional[str] = None
    objective_statuses: tuple[ObjectiveStatus, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)


class OperationalStatusProjector:
    """Derive operational mission status from the canonical event stream."""

    def __init__(self, store: EventStore) -> None:
        self._store = store

    def mission(self, mission_id: str) -> MissionStatus:
        fast_getter = getattr(self._store, "list_by_mission_id", None)
        if callable(fast_getter):
            events = fast_getter(mission_id)
        else:
            events = [
                event
                for event in self._store.list()
                if self._event_mission_id(event) == mission_id
            ]
        return self.from_events(mission_id, events)

    @classmethod
    def from_events(
        cls,
        mission_id: str,
        events: list[Event] | tuple[Event, ...],
    ) -> MissionStatus:
        ordered = sorted(
            events,
            key=lambda event: (
                event.sequence if event.sequence is not None else 0,
                event.at,
                event.id,
            ),
        )

        objectives: dict[str, ObjectiveStatus] = {}
        mission_status = "unknown"
        verification_state = "idle"
        current_activity: Optional[str] = None
        started_at: Optional[datetime] = None
        completed_at: Optional[datetime] = None
        latest_error: Optional[str] = None
        last_event_at: Optional[datetime] = None

        for event in ordered:
            last_event_at = event.at

            if event.type in MISSION_STARTED:
                mission_status = "running"
                started_at = started_at or event.at
                current_activity = "mission started"
                continue

            if event.type in MISSION_REPLANNING:
                mission_status = "replanning"
                current_activity = "replanning mission"
                continue

            if event.type in MISSION_COMPLETED:
                mission_status = "completed"
                completed_at = event.at
                current_activity = "mission completed"
                continue

            if event.type in MISSION_FAILED:
                mission_status = "failed"
                latest_error = cls._error(event)
                current_activity = "mission failed"
                continue

            if event.type in MISSION_BLOCKED:
                mission_status = "blocked"
                latest_error = cls._error(event)
                current_activity = "mission blocked"
                continue

            if event.type in MISSION_PAUSED:
                mission_status = "paused"
                latest_error = cls._error(event)
                current_activity = "waiting for human action" if event.payload.get("waiting_for_user") else "mission paused"
                continue

            if event.type in MISSION_STAGNATED:
                mission_status = "stagnated"
                latest_error = cls._error(event)
                current_activity = "mission stagnated"
                continue

            if event.type in MISSION_CONTRACT_UNSATISFIED:
                mission_status = "mission_contract_unsatisfied"
                latest_error = cls._error(event)
                current_activity = "mission contract unsatisfied"
                continue

            if event.type in MISSION_REPLAN_LIMIT:
                mission_status = "replan_limit_reached"
                latest_error = cls._error(event)
                current_activity = "replan limit reached"
                continue

            if event.type in MISSION_CANCELLED:
                mission_status = "cancelled"
                latest_error = cls._error(event)
                current_activity = "mission cancelled"
                continue

            if event.type in MISSION_DEAD_LETTERED:
                mission_status = "dead_lettered"
                latest_error = cls._error(event)
                current_activity = "recovery required"
                continue

            if event.type in MISSION_BLOCKED_PENDING_USER:
                mission_status = "blocked_pending_user"
                latest_error = cls._error(event)
                current_activity = "waiting for human action"
                continue

            if event.type in MISSION_RETRYING:
                mission_status = "retrying"
                latest_error = cls._error(event)
                current_activity = "retrying objective"
                continue

            # Builder events are emitted against the improvement_run aggregate,
            # but carry mission_id. Map them onto the mission's active objective.
            # This keeps the event model honest while exposing real Builder progress.
            builder_event = event.type
            builder_progress = None
            builder_activity = None
            builder_status = "running"
            builder_error = None

            if builder_event in BUILDER_STARTED:
                builder_progress = 0.05
                builder_activity = "starting autonomous builder"
            elif builder_event in BUILDER_RESEARCH:
                builder_progress = 0.15
                builder_activity = "researching repository and requirements"
            elif builder_event in BUILDER_CANDIDATE:
                builder_progress = 0.30
                builder_activity = "preparing candidate implementation"
            elif builder_event in BUILDER_EXECUTION:
                if builder_event == "ExecutionCreated":
                    builder_progress = 0.35
                    builder_activity = "preparing candidate execution"
                elif builder_event == "ExecutionStarted":
                    builder_progress = 0.40
                    builder_activity = "executing candidate implementation"
                elif builder_event == "ExecutionSucceeded":
                    builder_progress = 0.55
                    builder_activity = "candidate execution completed"
                else:
                    builder_progress = 0.40
                    builder_activity = "candidate execution failed"
                    builder_error = cls._error(event)
                    builder_status = "failed"
            elif builder_event in BUILDER_VERIFICATION:
                builder_progress = 0.70 if builder_event == "VerificationRecorded" else 0.60
                builder_activity = "verifying candidate"
                builder_error = cls._error(event)
                if builder_error:
                    builder_status = "failed"
            elif builder_event in BUILDER_DECISION:
                if event.payload.get("passed") is False:
                    builder_progress = 0.75
                    builder_activity = "candidate rejected by improvement decision"
                    reasons = event.payload.get("reasons", ())
                    builder_error = ", ".join(str(reason) for reason in reasons) or None
                    builder_status = "failed"
                else:
                    builder_progress = 0.85
                    builder_activity = "improvement decision approved"
            elif builder_event in BUILDER_PROMOTION:
                builder_progress = 0.95
                builder_activity = "promoting validated improvement"
            elif builder_event in BUILDER_FAILED:
                builder_progress = 0.0
                builder_activity = "autonomous builder failed"
                builder_error = cls._error(event)
                builder_status = "failed"

            if builder_progress is not None:
                mission_event_id = event.payload.get("mission_id")
                if mission_event_id == mission_id and objectives:
                    # The mission engine normally has one runtime objective for
                    # this Builder invocation. Prefer the currently active one.
                    target_id = next(
                        (
                            item.objective_id
                            for item in objectives.values()
                            if item.status in {"running", "queued"}
                        ),
                        next(iter(objectives), None),
                    )
                    if target_id is not None:
                        current = objectives[target_id]
                        current = cls._replace(
                            current,
                            status=builder_status,
                            progress=max(current.progress, builder_progress),
                            current_activity=builder_activity,
                            error=builder_error if builder_error else current.error,
                        )
                        objectives[target_id] = current
                        current_activity = builder_activity
                        if builder_error:
                            latest_error = builder_error
                continue

            objective_id = cls._objective_id(event)
            if objective_id is not None:
                current = objectives.get(
                    objective_id,
                    ObjectiveStatus(
                        objective_id=objective_id,
                        objective=cls._objective_text(event),
                    ),
                )

                if event.type in OBJECTIVE_QUEUED:
                    current = cls._replace(
                        current,
                        status="queued",
                        current_activity="queued",
                    )
                elif event.type in OBJECTIVE_STARTED:
                    current = cls._replace(
                        current,
                        status="running",
                        progress=max(current.progress, 0.01),
                        started_at=current.started_at or event.at,
                        current_activity=cls._activity(event),
                    )
                elif event.type in OBJECTIVE_COMPLETED:
                    current = cls._replace(
                        current,
                        status="completed",
                        progress=1.0,
                        completed_at=event.at,
                        current_activity="completed",
                    )
                elif event.type in OBJECTIVE_FAILED:
                    error = cls._error(event)
                    current = cls._replace(
                        current,
                        status="failed",
                        error=error,
                        current_activity="failed",
                    )
                    latest_error = error
                elif event.type == "ObjectiveProgressed":
                    progress = cls._progress(event)
                    current = cls._replace(
                        current,
                        progress=progress,
                        status="running",
                        current_activity=cls._activity(event),
                    )

                objectives[objective_id] = current

            if event.type in VERIFICATION_STARTED:
                verification_state = "running"
                current_activity = "verification running"
            elif event.type in VERIFICATION_COMPLETED:
                verification_state = (
                    "passed"
                    if event.payload.get("passed", True)
                    else "failed"
                )

        objective_values = tuple(
            sorted(objectives.values(), key=lambda item: item.objective_id)
        )
        total = len(objective_values)
        completed_count = sum(
            item.status == "completed" for item in objective_values
        )
        failed_count = sum(
            item.status == "failed" for item in objective_values
        )
        queued_count = sum(
            item.status == "queued" for item in objective_values
        )
        active_count = sum(
            item.status == "running" for item in objective_values
        )

        if total:
            progress = sum(item.progress for item in objective_values) / total
        else:
            progress = 1.0 if mission_status == "completed" else 0.0

        if mission_status == "unknown" and objective_values:
            mission_status = "running"

        return MissionStatus(
            mission_id=mission_id,
            status=mission_status,
            progress=round(min(max(progress, 0.0), 1.0), 4),
            objective_count=total,
            completed_objectives=completed_count,
            failed_objectives=failed_count,
            queued_objectives=queued_count,
            active_objectives=active_count,
            verification_state=verification_state,
            current_activity=current_activity,
            started_at=started_at,
            completed_at=completed_at,
            last_event_at=last_event_at,
            latest_error=latest_error,
            objective_statuses=objective_values,
        )

    @staticmethod
    def _event_mission_id(event: Event) -> Optional[str]:
        return (
            event.payload.get("mission_id")
            or event.aggregate_id
            if event.aggregate_type == "mission"
            else event.payload.get("mission_id")
        )

    @staticmethod
    def _objective_id(event: Event) -> Optional[str]:
        return (
            event.payload.get("objective_id")
            or event.payload.get("task_id")
            or (
                event.aggregate_id
                if event.aggregate_type in {"objective", "task"}
                else None
            )
        )

    @staticmethod
    def _objective_text(event: Event) -> str:
        return str(
            event.payload.get("objective")
            or event.payload.get("title")
            or ""
        )

    @staticmethod
    def _activity(event: Event) -> str:
        return str(
            event.payload.get("activity")
            or event.payload.get("message")
            or event.type
        )

    @staticmethod
    def _error(event: Event) -> Optional[str]:
        value = (
            event.payload.get("error")
            or event.payload.get("reason")
            or event.payload.get("failure")
        )
        return str(value) if value is not None else None

    @staticmethod
    def _progress(event: Event) -> float:
        value = event.payload.get("progress", 0.0)
        try:
            return min(max(float(value), 0.0), 1.0)
        except (TypeError, ValueError):
            return 0.0

    @staticmethod
    def _replace(
        current: ObjectiveStatus,
        **changes: Any,
    ) -> ObjectiveStatus:
        values = {
            "objective_id": current.objective_id,
            "objective": current.objective,
            "status": current.status,
            "progress": current.progress,
            "started_at": current.started_at,
            "completed_at": current.completed_at,
            "error": current.error,
            "current_activity": current.current_activity,
            "metadata": current.metadata,
        }
        values.update(changes)
        return ObjectiveStatus(**values)


class LiveStatusReader:
    """Read current operational status directly from the event store."""

    def __init__(self, store: EventStore) -> None:
        self._projector = OperationalStatusProjector(store)

    def mission(self, mission_id: str) -> MissionStatus:
        return self._projector.mission(mission_id)
