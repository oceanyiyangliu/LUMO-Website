from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from eventing.store import EventStore
from .types import EventMetric

class MetricsReader:
    def __init__(self, store: EventStore) -> None:
        self._store = store

    def event_counts(self) -> list[EventMetric]:
        counts = Counter(e.type for e in self._store.list())
        return [EventMetric(key=k, count=counts[k]) for k in sorted(counts)]

    def type_counts(self) -> dict[str, int]:
        return dict(Counter(e.type for e in self._store.list()))

    def source_counts(self) -> dict[str, int]:
        return dict(Counter(e.source for e in self._store.list()))

@dataclass(frozen=True)
class LatencyMetric:
    key: str
    count: int
    total_seconds: float
    max_seconds: float

    @property
    def average_seconds(self) -> float:
        return self.total_seconds / self.count if self.count else 0.0


class OperationalMetricsReader(MetricsReader):
    """Derive lifecycle latency and queue/worker metrics from durable events."""
    _PAIRS = {
        "mission": ("MissionStarted", "MissionCompleted"),
        "objective": ("ObjectiveStarted", "ObjectiveCompleted"),
        "execution": ("ExecutionStarted", "ExecutionSucceeded"),
        "world": ("WorldCreated", "WorldDestroyed"),
    }
    def latencies(self) -> list[LatencyMetric]:
        events=list(self._store.list()); out=[]
        for key,(start,end) in self._PAIRS.items():
            starts={e.aggregate_id:e for e in events if e.type==start and e.aggregate_id}
            vals=[]
            for e in events:
                if e.type==end and e.aggregate_id in starts:
                    delta=(e.at-starts[e.aggregate_id].at).total_seconds()
                    if delta >= 0: vals.append(delta)
            if vals: out.append(LatencyMetric(key,len(vals),sum(vals),max(vals)))
        return out
    def queue_depth(self) -> int:
        queued={e.aggregate_id for e in self._store.list() if e.type in {"ScheduledExecutionQueued","ObjectiveQueued"} and e.aggregate_id}
        done={e.aggregate_id for e in self._store.list() if e.type in {"ScheduledExecutionCompleted","ScheduledExecutionFailed","ScheduledExecutionCancelled","ObjectiveCompleted","ObjectiveFailed"} and e.aggregate_id}
        return len(queued-done)
    def provider_health(self) -> dict[str,dict[str,int]]:
        result={}
        for e in self._store.list():
            provider=str(e.payload.get("provider") or e.source or "unknown")
            bucket=result.setdefault(provider,{"success":0,"failure":0})
            if e.type.endswith("Succeeded") or e.type in {"ExecutionSucceeded","VerificationRecorded"}: bucket["success"]+=1
            if e.type.endswith("Failed") or e.type in {"ExecutionFailed","ExecutionTimedOut"}: bucket["failure"]+=1
        return result

    def telemetry_summary(self) -> dict[str,int]:
        """Portable counters for worker/world/device/model/power/event-lag telemetry."""
        events=list(self._store.list())
        return {
            "worker_utilization_samples": sum(1 for e in events if "Worker" in e.type),
            "world_lifecycle_events": sum(1 for e in events if e.type.startswith("World")),
            "device_health_events": sum(1 for e in events if "Device" in e.type and "Health" in e.type),
            "model_latency_samples": sum(1 for e in events if "Model" in e.type and "Latency" in e.type),
            "model_error_samples": sum(1 for e in events if "Model" in e.type and ("Error" in e.type or "Failed" in e.type)),
            "power_lease_events": sum(1 for e in events if "PowerLease" in e.type),
            "event_lag_samples": sum(1 for e in events if "EventLag" in e.type),
            "delivery_retry_events": sum(1 for e in events if "DeliveryRetry" in e.type),
        }

@dataclass(frozen=True)
class Alert:
    fingerprint: str
    severity: str
    message: str
    first_seen: float
    last_seen: float
    count: int = 1

class AlertEngine:
    """Deterministic alert severity, deduplication and suppression windows."""
    _ORDER={"info":0,"warning":1,"error":2,"critical":3}
    def __init__(self,suppression_seconds:float=60): self.suppression_seconds=suppression_seconds; self._alerts={}; self._suppressed={}
    def observe(self,fingerprint:str,severity:str,message:str,now:float):
        if severity not in self._ORDER: raise ValueError("invalid alert severity")
        if now < self._suppressed.get(fingerprint,-float("inf")): return None
        old=self._alerts.get(fingerprint)
        if old: alert=Alert(fingerprint,severity if self._ORDER[severity]>=self._ORDER[old.severity] else old.severity,old.message,old.first_seen,now,old.count+1)
        else: alert=Alert(fingerprint,severity,message,now,now)
        self._alerts[fingerprint]=alert; self._suppressed[fingerprint]=now+self.suppression_seconds; return alert
    def suppress(self,fingerprint:str,until:float): self._suppressed[fingerprint]=float(until)
    def list(self): return tuple(self._alerts.values())
