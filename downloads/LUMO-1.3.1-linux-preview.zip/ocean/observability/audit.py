from __future__ import annotations

from typing import Optional
from eventing.store import EventStore
from ocean.domain.event import Event
from .types import AuditEvent

class AuditReader:
    def __init__(self, store: EventStore) -> None:
        self._store = store

    def all_events(self) -> list[AuditEvent]:
        return [self._wrap(e) for e in self._store.list()]

    def by_type(self, event_type: str) -> list[AuditEvent]:
        return [self._wrap(e) for e in self._store.list(event_type)]

    def by_aggregate(self, aggregate_type: Optional[str] = None, aggregate_id: Optional[str] = None) -> list[AuditEvent]:
        return [self._wrap(e) for e in self._store.list() if (aggregate_type is None or e.aggregate_type == aggregate_type) and (aggregate_id is None or e.aggregate_id == aggregate_id)]

    def by_correlation(self, correlation_id: str) -> list[AuditEvent]:
        return [self._wrap(e) for e in self._store.list() if e.correlation_id == correlation_id]

    def by_causation(self, causation_id: str) -> list[AuditEvent]:
        return [self._wrap(e) for e in self._store.list() if e.causation_id == causation_id]

    def by_source(self, source: str) -> list[AuditEvent]:
        return [self._wrap(e) for e in self._store.list() if e.source == source]

    def after_sequence(self, sequence: int) -> list[AuditEvent]:
        return [self._wrap(e) for e in self._store.list_after_sequence(sequence)]

    def _wrap(self, event: Event) -> AuditEvent:
        return AuditEvent(event=event, sequence=self._store.sequence(event.id))
