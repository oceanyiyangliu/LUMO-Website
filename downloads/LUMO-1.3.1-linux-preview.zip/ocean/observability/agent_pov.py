"""Operational Agent POV projection: observable context without exposing hidden reasoning."""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Mapping, Optional
from ocean.domain.event import Event

@dataclass(frozen=True)
class AgentPOV:
    agent_id: str
    mission_id: Optional[str] = None
    task_id: Optional[str] = None
    status: str = "unknown"
    current_activity: Optional[str] = None
    current_observation: Mapping[str, Any] = field(default_factory=dict)
    current_action: Mapping[str, Any] = field(default_factory=dict)
    uncertainty: Optional[float] = None
    policy_state: Optional[str] = None
    evidence_ids: tuple[str, ...] = ()
    resource_usage: Mapping[str, float] = field(default_factory=dict)
    updated_at: Optional[datetime] = None

class AgentPOVProjector:
    """Rebuild the latest observable operational POV for each agent from events."""
    def __init__(self): self._agents: dict[str, AgentPOV] = {}
    def apply(self, event: Event) -> None:
        p=event.payload or {}; aid=p.get("agent_id") or event.aggregate_id
        if not aid: return
        current=self._agents.get(aid, AgentPOV(agent_id=str(aid)))
        evidence=list(current.evidence_ids)
        if event.type in {"EvidenceRecorded","VerificationRecorded","ComputerScreenshotCaptured"}:
            eid=p.get("evidence_id") or p.get("artifact_id") or event.id
            if eid not in evidence: evidence.append(str(eid))
        usage=dict(current.resource_usage); usage.update({str(k):float(v) for k,v in (p.get("resource_usage") or {}).items()})
        self._agents[str(aid)]=AgentPOV(
            agent_id=str(aid), mission_id=p.get("mission_id",current.mission_id), task_id=p.get("task_id",current.task_id),
            status=p.get("status",current.status), current_activity=p.get("activity") or p.get("message") or current.current_activity,
            current_observation=p.get("observation") or current.current_observation, current_action=p.get("action") or current.current_action,
            uncertainty=p.get("uncertainty",current.uncertainty), policy_state=p.get("policy_state",current.policy_state),
            evidence_ids=tuple(evidence), resource_usage=usage, updated_at=event.at)
    def get(self, agent_id:str)->AgentPOV|None: return self._agents.get(agent_id)
    def all(self)->tuple[AgentPOV,...]: return tuple(self._agents.values())
    def rebuild(self, events:list[Event]|tuple[Event,...])->None:
        self._agents={}
        for event in sorted(events,key=lambda e:(e.sequence or 0,e.at,e.id)): self.apply(event)
