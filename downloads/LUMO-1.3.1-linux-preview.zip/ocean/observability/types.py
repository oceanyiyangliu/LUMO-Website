from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Mapping, Optional

from ocean.domain.event import Event


@dataclass(frozen=True)
class AuditEvent:
    event: Event
    sequence: Optional[int]

    @property
    def id(self) -> str:
        return self.event.id

    @property
    def type(self) -> str:
        return self.event.type

    @property
    def at(self) -> datetime:
        return self.event.at

    @property
    def payload(self) -> Mapping[str, Any]:
        return self.event.payload


@dataclass(frozen=True)
class EventMetric:
    key: str
    count: int
