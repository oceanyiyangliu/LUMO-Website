"""Fleet-wide release rollout policy for LUMO."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping


@dataclass(frozen=True)
class FleetHealth:
    sample_size: int
    crash_rate: float
    verification_failure_rate: float
    rollback_rate: float

    def __post_init__(self):
        if self.sample_size < 0 or any(not 0 <= x <= 1 for x in (
            self.crash_rate, self.verification_failure_rate, self.rollback_rate
        )):
            raise ValueError("invalid fleet health")


@dataclass(frozen=True)
class RolloutPolicy:
    stages: tuple[int, ...] = (1, 10, 50, 100)
    max_crash_rate: float = 0.01
    max_verification_failure_rate: float = 0.02
    max_rollback_rate: float = 0.01

    def __post_init__(self):
        if not self.stages or self.stages[-1] != 100 or sorted(self.stages) != list(self.stages):
            raise ValueError("rollout stages must be sorted and end at 100")
        if any(not 0 < x <= 1 for x in (
            self.max_crash_rate, self.max_verification_failure_rate, self.max_rollback_rate
        )):
            raise ValueError("invalid rollout thresholds")
class FleetRollout:
    """Deterministic canary promotion; safety failures freeze or roll back."""

    def __init__(self, state_path: Path, policy: RolloutPolicy | None = None):
        self.path = Path(state_path)
        self.policy = policy or RolloutPolicy()
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def stage(self, version: str, channel: str, health: FleetHealth) -> int:
        state = self._read()
        current = int(state.get("rollout_percent", 0))
        if not self._health_ok(health):
            state.update(status="frozen", version=version, channel=channel,
                         rollout_percent=current, reason="fleet health gate failed")
            self._write(state)
            return current
        next_stage = next((x for x in self.policy.stages if x > current), None)
        if next_stage is None:
            return current
        state.update(status="rolling_out", version=version, channel=channel,
                     rollout_percent=next_stage, reason="health gate passed")
        self._write(state)
        return next_stage

    def freeze(self, reason: str) -> None:
        state = self._read()
        state.update(status="frozen", reason=str(reason))
        self._write(state)

    def rollback(self, reason: str) -> None:
        state = self._read()
        state.update(status="rolled_back", rollout_percent=0, reason=str(reason))
        self._write(state)

    def _health_ok(self, health: FleetHealth) -> bool:
        if health.sample_size == 0:
            return False
        return (
            health.crash_rate <= self.policy.max_crash_rate
            and health.verification_failure_rate <= self.policy.max_verification_failure_rate
            and health.rollback_rate <= self.policy.max_rollback_rate
        )
    def assigned(self, installation_id: str, version: str, percent: int) -> bool:
        """Stable hashing keeps an installation in the same rollout cohort."""
        if not 0 <= percent <= 100:
            raise ValueError("percent must be 0..100")
        bucket = int(hashlib.sha256(
            f"{version}:{installation_id}".encode()
        ).hexdigest()[:8], 16) % 100
        return bucket < percent

    def _read(self) -> dict[str, object]:
        if not self.path.exists():
            return {}
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, state: Mapping[str, object]) -> None:
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(dict(state), sort_keys=True), encoding="utf-8")
        temp.replace(self.path)
@dataclass(frozen=True)
class EvolutionDecision:
    action: str
    reason: str
    version: str | None = None


class EvolutionReleaseGate:
    """The evolution engine may propose; only independent gates may release."""

    HARD_GATES = (
        "authorization", "isolation", "verification", "auditability",
        "kill_switch", "secret_protection", "trust_boundary",
    )

    @classmethod
    def decide(cls, version: str, gates: Mapping[str, bool]) -> EvolutionDecision:
        missing = tuple(name for name in cls.HARD_GATES if not gates.get(name, False))
        if missing:
            return EvolutionDecision("reject", "hard gate failed: " + ",".join(missing), version)
        release_gates = {
            key: value for key, value in gates.items()
            if key not in {"fleet_sample_size", "fleet_crash_rate",
                           "fleet_verification_failure_rate", "fleet_rollback_rate"}
        }
        if not all(bool(value) for value in release_gates.values()):
            return EvolutionDecision("hold", "non-hard release gate failed", version)
        return EvolutionDecision("canary", "all release gates passed", version)
