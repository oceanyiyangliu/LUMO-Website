"""Secure, atomic LUMO client updates with rollback and health gates."""
from __future__ import annotations

import json
import os
import shutil
import tempfile
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from .release import ReleaseManifest, ReleaseVerifier, verify_artifact


@dataclass(frozen=True)
class UpdateResult:
    status: str
    version: str
    previous_version: str | None
    message: str


class UpdateClient:
    """Download, verify, stage and atomically activate a signed release."""

    def __init__(self, install_root: Path, public_key: bytes):
        self.root = Path(install_root).resolve()
        self.verifier = ReleaseVerifier(public_key)
        self.releases = self.root / "releases"
        self.current = self.root / "current"
        self.previous = self.root / "previous"
        self.state = self.root / "update-state.json"
        self.releases.mkdir(parents=True, exist_ok=True)

    def check(self, manifest: ReleaseManifest, signature: str, current_version: str | None) -> bool:
        if current_version == manifest.version:
            return False
        if not self.verifier.verify(manifest, signature):
            raise RuntimeError("release signature verification failed")
        return True
    def apply(
        self,
        manifest: ReleaseManifest,
        signature: str,
        artifact: Path,
        health_check: Callable[[Path], bool],
        *,
        current_version: str | None = None,
    ) -> UpdateResult:
        if not self.check(manifest, signature, current_version):
            return UpdateResult("up_to_date", manifest.version, current_version, "no update required")
        if not verify_artifact(artifact, manifest):
            raise RuntimeError("release artifact integrity verification failed")
        target = self.releases / manifest.version
        if target.exists():
            raise RuntimeError("release directory already exists")
        temp = Path(tempfile.mkdtemp(prefix=".lumo-update-", dir=self.releases))
        try:
            self._safe_extract(artifact, temp)
            if not health_check(temp):
                raise RuntimeError("staged release health check failed")
            old = self.current.resolve() if self.current.is_symlink() else None
            if old is not None:
                self.previous.unlink(missing_ok=True)
                os.symlink(old, self.previous)
            temp.rename(target)
            self._atomic_symlink(target, self.current)
            self._write_state(manifest.version, current_version, "active")
            return UpdateResult("updated", manifest.version, current_version, "verified release activated")
        except Exception:
            shutil.rmtree(temp, ignore_errors=True)
            raise

    def rollback(self, health_check: Callable[[Path], bool]) -> UpdateResult:
        if not self.previous.is_symlink():
            raise RuntimeError("no previous release available")
        target = self.previous.resolve()
        if not health_check(target):
            raise RuntimeError("previous release failed rollback health check")
        current = self.current.resolve() if self.current.is_symlink() else None
        self._atomic_symlink(target, self.current)
        if current is not None:
            self.previous.unlink(missing_ok=True)
            os.symlink(current, self.previous)
        version = target.name
        self._write_state(version, current.name if current else None, "rolled_back")
        return UpdateResult("rolled_back", version, current.name if current else None, "rollback activated")
    def _atomic_symlink(self, target: Path, link: Path) -> None:
        tmp = link.with_name(f".{link.name}.next")
        tmp.unlink(missing_ok=True)
        os.symlink(target, tmp)
        os.replace(tmp, link)

    def _write_state(self, version: str, previous: str | None, status: str) -> None:
        payload = {"version": version, "previous_version": previous, "status": status}
        tmp = self.state.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, sort_keys=True), encoding="utf-8")
        os.replace(tmp, self.state)

    @staticmethod
    def _safe_extract(artifact: Path, destination: Path) -> None:
        destination = destination.resolve()
        with zipfile.ZipFile(artifact) as archive:
            for member in archive.infolist():
                name = Path(member.filename)
                if name.is_absolute() or ".." in name.parts:
                    raise RuntimeError("release archive contains unsafe path")
                target = (destination / name).resolve()
                if destination != target and destination not in target.parents:
                    raise RuntimeError("release archive escapes staging directory")
                if member.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                else:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with archive.open(member) as src, target.open("wb") as dst:
                        shutil.copyfileobj(src, dst)
    def update_from_url(
        self,
        manifest_url: str,
        artifact_url: str,
        health_check: Callable[[Path], bool],
        *,
        current_version: str | None = None,
        timeout: float = 15.0,
    ) -> UpdateResult:
        """Fetch a signed manifest and artifact; clients never trust remote code blindly."""
        if not manifest_url.startswith(("https://", "http://127.0.0.1", "http://localhost")):
            raise ValueError("update manifest must use HTTPS")
        if not artifact_url.startswith(("https://", "http://127.0.0.1", "http://localhost")):
            raise ValueError("update artifact must use HTTPS")
        with urllib.request.urlopen(manifest_url, timeout=timeout) as response:
            envelope = json.loads(response.read().decode("utf-8"))
        manifest = ReleaseManifest.from_dict(envelope["manifest"])
        signature = str(envelope["signature"])
        with tempfile.TemporaryDirectory(prefix="lumo-download-") as temp:
            artifact = Path(temp) / "release.zip"
            with urllib.request.urlopen(artifact_url, timeout=timeout) as response, artifact.open("wb") as dst:
                shutil.copyfileobj(response, dst)
            return self.apply(
                manifest, signature, artifact, health_check,
                current_version=current_version,
            )
