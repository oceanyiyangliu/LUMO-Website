"""TLS/authenticated production gateway for the local LUMO control plane.

The application server remains loopback-only. This gateway is the only component
allowed to expose it remotely and terminates TLS before proxying to 127.0.0.1.
"""
from __future__ import annotations
import http.client
import ipaddress
import os
import ssl
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit


class ProductionGateway:
    def __init__(self, *, listen_host: str = "0.0.0.0", listen_port: int = 443,
                 upstream_host: str = "127.0.0.1", upstream_port: int = 8765,
                 cert_file: str | None = None, key_file: str | None = None,
                 allowed_origins: tuple[str, ...] = ()):
        if not cert_file or not key_file:
            raise ValueError("production gateway requires TLS certificate and private key")
        if not PathLike(cert_file).is_file() or not PathLike(key_file).is_file():
            raise FileNotFoundError("TLS certificate or private key is missing")
        self.listen_host, self.listen_port = listen_host, listen_port
        self.upstream_host, self.upstream_port = upstream_host, upstream_port
        self.allowed_origins = set(allowed_origins)
        if not self.allowed_origins:
            raise ValueError("production gateway requires an explicit allowed-origin set")
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        context.load_cert_chain(cert_file, key_file)
        self.context = context
        gateway = self

        class Handler(BaseHTTPRequestHandler):
            def do_OPTIONS(self): self._proxy()
            def do_GET(self): self._proxy()
            def do_POST(self): self._proxy()
            def do_PUT(self): self._proxy()
            def do_PATCH(self): self._proxy()
            def do_DELETE(self): self._proxy()
            def _proxy(self):
                origin = self.headers.get("Origin")
                if origin and origin not in gateway.allowed_origins:
                    self.send_error(403, "untrusted browser origin")
                    return
                length = int(self.headers.get("Content-Length", "0"))
                if length > 64 * 1024:
                    self.send_error(413, "request body too large")
                    return
                body = self.rfile.read(length) if length else None
                headers = {k: v for k, v in self.headers.items()
                           if k.lower() not in {"host", "origin", "connection"}}
                headers["Host"] = f"127.0.0.1:{gateway.upstream_port}"
                if origin:
                    headers["X-LUMO-Forwarded-Origin"] = origin
                conn = http.client.HTTPConnection(gateway.upstream_host, gateway.upstream_port, timeout=30)
                try:
                    conn.request(self.command, self.path, body=body, headers=headers)
                    response = conn.getresponse()
                    data = response.read()
                    self.send_response(response.status)
                    for key, value in response.getheaders():
                        if key.lower() not in {"transfer-encoding", "connection", "content-length"}:
                            self.send_header(key, value)
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
                    self.end_headers()
                    self.wfile.write(data)
                finally:
                    conn.close()
            def log_message(self, fmt, *args): return

        self.server = ThreadingHTTPServer((listen_host, listen_port), Handler)
        self.server.socket = context.wrap_socket(self.server.socket, server_side=True)

    def serve_forever(self):
        self.server.serve_forever(poll_interval=0.2)

    def shutdown(self):
        self.server.shutdown(); self.server.server_close()


class PathLike:
    def __init__(self, value):
        from pathlib import Path
        self.path = Path(value).expanduser().resolve()
    def is_file(self): return self.path.is_file()
