"""Commercial entitlements for LUMO.

Billing is deliberately provider-neutral: a payment provider owns money movement,
while LUMO owns entitlement decisions. This keeps the execution plane testable and
prevents a checkout provider from becoming an authority over agent execution.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import sqlite3
import threading
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any


@dataclass(frozen=True)
class Plan:
    id: str
    name: str
    monthly_price_cents: int
    missions_per_month: int
    computer_tasks_per_month: int
    worlds: int
    concurrent_tasks: int
    history_days: int
    seats: int
    features: tuple[str, ...]
    checkout_url: str | None = None


PLANS: dict[str, Plan] = {
    "free": Plan("free", "Free", 0, 25, 5, 1, 1, 7, 1, (
        "25 missions / month", "5 World computer runs / month", "1 isolated World",
        "Core mission control", "Local-first account"
    )),
    "pro": Plan("pro", "Pro", 2900, 500, 100, 3, 3, 30, 1, (
        "500 missions / month", "100 World computer runs / month", "3 isolated Worlds",
        "Priority execution", "Advanced mission history", "Adaptive workspace"
    )),
    "team": Plan("team", "Team", 9900, 2500, 500, 10, 10, 365, 5, (
        "2,500 missions / month", "500 World computer runs / month", "10 isolated Worlds",
        "5 seats", "Shared workspace", "Audit-ready activity", "Team controls"
    )),
    "business": Plan("business", "Business", 29900, 10000, 2000, 50, 25, 1825, 25, (
        "10,000 missions / month", "2,000 World computer runs / month", "50 isolated Worlds",
        "25 seats", "Advanced governance", "Long-term history", "Priority support"
    )),
    "enterprise": Plan("enterprise", "Enterprise", 0, 1000000, 100000, 1000, 100, 3650, 1000, (
        "Custom capacity", "Custom retention", "SSO / SCIM ready", "Dedicated governance",
        "Private deployment", "Enterprise support"
    )),
}


def _period() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m")


class BillingStore:
    """Durable subscription and metered-usage authority for an account."""

    def __init__(self, path: str | os.PathLike[str]):
        self.path = str(path)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(self.path, check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=NORMAL")
        self._db.execute("PRAGMA busy_timeout=30000")
        self._db.executescript("""
        CREATE TABLE IF NOT EXISTS subscriptions (
            account_id TEXT PRIMARY KEY,
            plan_id TEXT NOT NULL,
            status TEXT NOT NULL,
            provider_customer_id TEXT,
            provider_subscription_id TEXT,
            current_period_end TEXT,
            trial_ends_at TEXT,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS usage (
            account_id TEXT NOT NULL,
            period TEXT NOT NULL,
            metric TEXT NOT NULL,
            quantity INTEGER NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL,
            PRIMARY KEY(account_id, period, metric)
        );
        CREATE TABLE IF NOT EXISTS billing_events (
            event_id TEXT PRIMARY KEY,
            received_at TEXT NOT NULL,
            payload TEXT NOT NULL
        );
        """)
        self._db.commit()

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    def delete_account(self, account_id: str) -> None:
        with self._lock:
            self._db.execute("DELETE FROM subscriptions WHERE account_id=?", (account_id,))
            self._db.execute("DELETE FROM usage WHERE account_id=?", (account_id,))
            self._db.commit()

    def ensure(self, account_id: str) -> dict[str, Any]:
        with self._lock:
            row = self._db.execute("SELECT * FROM subscriptions WHERE account_id=?", (account_id,)).fetchone()
            if row is None:
                now = self._now()
                self._db.execute(
                    "INSERT INTO subscriptions(account_id,plan_id,status,updated_at) VALUES(?,?,?,?)",
                    (account_id, "free", "active", now),
                )
                self._db.commit()
                return self.subscription(account_id)
            return self.subscription(account_id)

    def subscription(self, account_id: str) -> dict[str, Any]:
        self.ensure_row(account_id)
        row = self._db.execute(
            "SELECT account_id,plan_id,status,provider_customer_id,provider_subscription_id,current_period_end,trial_ends_at,updated_at FROM subscriptions WHERE account_id=?",
            (account_id,),
        ).fetchone()
        return {
            "account_id": row[0], "plan_id": row[1], "status": row[2],
            "provider_customer_id": row[3], "provider_subscription_id": row[4],
            "current_period_end": row[5], "trial_ends_at": row[6], "updated_at": row[7],
        }

    def ensure_row(self, account_id: str) -> None:
        row = self._db.execute("SELECT 1 FROM subscriptions WHERE account_id=?", (account_id,)).fetchone()
        if row is None:
            now = self._now()
            self._db.execute("INSERT INTO subscriptions(account_id,plan_id,status,updated_at) VALUES(?,?,?,?)", (account_id, "free", "active", now))
            self._db.commit()

    def set_subscription(self, account_id: str, *, plan_id: str, status: str = "active", **provider: Any) -> dict[str, Any]:
        if plan_id not in PLANS:
            raise ValueError(f"unknown plan: {plan_id}")
        self.ensure_row(account_id)
        now = self._now()
        with self._lock:
            self._db.execute(
                "UPDATE subscriptions SET plan_id=?,status=?,provider_customer_id=?,provider_subscription_id=?,current_period_end=?,trial_ends_at=?,updated_at=? WHERE account_id=?",
                (plan_id, status, provider.get("provider_customer_id"), provider.get("provider_subscription_id"), provider.get("current_period_end"), provider.get("trial_ends_at"), now, account_id),
            )
            self._db.commit()
        return self.subscription(account_id)

    def usage(self, account_id: str) -> dict[str, int]:
        period = _period()
        rows = self._db.execute("SELECT metric,quantity FROM usage WHERE account_id=? AND period=?", (account_id, period)).fetchall()
        return {str(k): int(v) for k, v in rows}

    def consume(self, account_id: str, metric: str, quantity: int = 1) -> dict[str, int]:
        if quantity < 1:
            raise ValueError("quantity must be positive")
        period = _period()
        now = self._now()
        with self._lock:
            self._db.execute(
                "INSERT INTO usage(account_id,period,metric,quantity,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(account_id,period,metric) DO UPDATE SET quantity=quantity+excluded.quantity,updated_at=excluded.updated_at",
                (account_id, period, metric, quantity, now),
            )
            self._db.commit()
        return self.usage(account_id)

    def consume_with_limit(self, account_id: str, metric: str, *, limit: int, quantity: int = 1) -> dict[str, int]:
        """Atomically admit and meter usage for one account/period.

        Separate check()+consume() calls are vulnerable to a concurrency race:
        two workers can both observe one remaining unit and then both spend it.
        This method makes entitlement admission and metering one serialized
        database operation, so usage can never cross the supplied hard limit.
        """
        if quantity < 1:
            raise ValueError("quantity must be positive")
        if limit < 0:
            raise ValueError("limit must be non-negative")
        period = _period()
        now = self._now()
        with self._lock:
            row = self._db.execute(
                "SELECT quantity FROM usage WHERE account_id=? AND period=? AND metric=?",
                (account_id, period, metric),
            ).fetchone()
            current = int(row[0]) if row is not None else 0
            if current + quantity > limit:
                raise PermissionError(f"usage limit reached for {metric}")
            if row is None:
                self._db.execute(
                    "INSERT INTO usage(account_id,period,metric,quantity,updated_at) VALUES(?,?,?,?,?)",
                    (account_id, period, metric, quantity, now),
                )
            else:
                self._db.execute(
                    "UPDATE usage SET quantity=quantity+?,updated_at=? WHERE account_id=? AND period=? AND metric=?",
                    (quantity, now, account_id, period, metric),
                )
            self._db.commit()
        return self.usage(account_id)

    def record_event(self, event_id: str, payload: dict[str, Any]) -> bool:
        with self._lock:
            try:
                self._db.execute("INSERT INTO billing_events(event_id,received_at,payload) VALUES(?,?,?)", (event_id, self._now(), json.dumps(payload, separators=(",", ":"))))
                self._db.commit()
                return True
            except sqlite3.IntegrityError:
                return False

    def audit_export(self, account_id: str) -> dict[str, Any]:
        """Return a provider-neutral, JSON-safe billing audit bundle."""
        with self._lock:
            subscription = self.subscription(account_id)
            usage = self.usage(account_id)
            rows = self._db.execute(
                "SELECT event_id,received_at,payload FROM billing_events ORDER BY received_at,event_id"
            ).fetchall()
        return {
            "account_id": account_id,
            "subscription": subscription,
            "usage": usage,
            "events": [
                {"event_id": r[0], "received_at": r[1], "payload": json.loads(r[2])}
                for r in rows
            ],
            "exported_at": self._now(),
        }

    def revenue_metrics(self) -> dict[str, Any]:
        """Compute recognized subscription MRR from the local entitlement ledger.

        This is an operational metric, not an accounting or tax statement.
        """
        with self._lock:
            rows = self._db.execute(
                "SELECT plan_id,status,COUNT(*) FROM subscriptions GROUP BY plan_id,status"
            ).fetchall()
        active = {
            plan_id: int(count)
            for plan_id, status, count in rows
            if status in {"active", "trialing"}
        }
        mrr_cents = sum(PLANS.get(plan_id, PLANS["free"]).monthly_price_cents * count for plan_id, count in active.items())
        return {"active_subscriptions": sum(active.values()), "by_plan": active, "mrr_cents": mrr_cents}

    def payment_outage(self, account_id: str, *, reason: str = "provider_unavailable") -> dict[str, Any]:
        """Put billing into a fail-closed, non-destructive outage state.

        Existing entitlements remain unchanged; new paid-state mutations should
        be reconciled once the provider is healthy again.
        """
        if not reason.strip():
            raise ValueError("outage reason is required")
        self.ensure_row(account_id)
        with self._lock:
            self._db.execute(
                "INSERT INTO billing_events(event_id,received_at,payload) VALUES(?,?,?)",
                (f"outage:{account_id}:{int(time.time())}", self._now(),
                 json.dumps({"type":"billing.outage","account_id":account_id,"reason":reason}, separators=(",", ":"))),
            )
            self._db.commit()
        return {"account_id": account_id, "outage": True, "reason": reason}

    def close(self) -> None:
        with self._lock:
            self._db.close()


class EntitlementEngine:
    def __init__(self, store: BillingStore):
        self.store = store

    def snapshot(self, account_id: str) -> dict[str, Any]:
        subscription = self.store.ensure(account_id)
        plan = PLANS.get(subscription["plan_id"], PLANS["free"])
        usage = self.store.usage(account_id)
        limits = {
            "missions": plan.missions_per_month,
            "computer_tasks": plan.computer_tasks_per_month,
            "worlds": plan.worlds,
            "concurrent_tasks": plan.concurrent_tasks,
            "history_days": plan.history_days,
            "seats": plan.seats,
        }
        return {"subscription": subscription, "plan": asdict(plan), "usage": usage, "limits": limits}

    def consume(self, account_id: str, metric: str, *, current: int = 0, quantity: int = 1) -> dict[str, int]:
        """Atomically enforce a metered entitlement and record its usage."""
        sub = self.store.ensure(account_id)
        plan = PLANS.get(sub["plan_id"], PLANS["free"])
        limit_name = {"missions": "missions_per_month", "computer_tasks": "computer_tasks_per_month"}.get(metric)
        if limit_name is None:
            raise ValueError(f"metric {metric!r} is not a metered monthly entitlement")
        return self.store.consume_with_limit(
            account_id, metric, limit=getattr(plan, limit_name), quantity=quantity,
        )

    def check(self, account_id: str, metric: str, *, current: int = 0, quantity: int = 1) -> None:
        sub = self.store.ensure(account_id)
        plan = PLANS.get(sub["plan_id"], PLANS["free"])
        limit_name = {"missions": "missions_per_month", "computer_tasks": "computer_tasks_per_month"}.get(metric)
        if limit_name and self.store.usage(account_id).get(metric, 0) + quantity > getattr(plan, limit_name):
            raise PermissionError(f"{plan.name} plan limit reached for {metric}; upgrade to continue")
        if metric == "worlds" and current + quantity > plan.worlds:
            raise PermissionError(f"{plan.name} plan allows {plan.worlds} active Worlds")
        if metric == "concurrent_tasks" and current + quantity > plan.concurrent_tasks:
            raise PermissionError(f"{plan.name} plan allows {plan.concurrent_tasks} concurrent tasks")

    @staticmethod
    def checkout_url(plan_id: str) -> str | None:
        plan = PLANS.get(plan_id)
        if plan is None or plan_id == "free":
            return None
        env_key = f"LUMO_CHECKOUT_URL_{plan_id.upper()}"
        return os.getenv(env_key) or plan.checkout_url


class BillingWebhook:
    """Small signed webhook verifier for a hosted payment provider adapter."""
    @staticmethod
    def verify(raw: bytes, signature: str, secret: str | None = None) -> bool:
        secret = secret or os.getenv("LUMO_BILLING_WEBHOOK_SECRET", "")
        if not secret or not signature:
            return False
        expected = hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, signature)

@dataclass(frozen=True)
class BillingLifecycle:
    status: str
    plan_id: str
    payment_state: str = "unknown"
    grace_until: str | None = None
    invoice_state: str = "unknown"
    refunded: bool = False

class BillingLifecycleProjector:
    """Provider-neutral subscription lifecycle projection."""
    _PAYMENT_STATES={"paid","failed","pending","refunded"}
    def apply(self, current: BillingLifecycle, event: Mapping[str,Any]) -> BillingLifecycle:
        typ=str(event.get("type","")); status=current.status; payment=current.payment_state; invoice=current.invoice_state; refunded=current.refunded; grace=current.grace_until
        if typ in {"subscription.active","subscription.renewed","payment.succeeded"}: status="active"; payment="paid"; invoice="paid"
        elif typ in {"payment.failed","invoice.payment_failed"}: payment="failed"; invoice="open"
        elif typ=="subscription.past_due": status="past_due"
        elif typ=="subscription.canceled": status="cancelled"
        elif typ=="invoice.paid": invoice="paid"; payment="paid"
        elif typ=="invoice.open": invoice="open"
        elif typ=="refund.created": payment="refunded"; invoice="refunded"; refunded=True
        elif typ=="grace.started": grace=str(event.get("grace_until") or "")
        elif typ=="grace.expired": grace=None; status="restricted"
        return BillingLifecycle(status,current.plan_id,payment,grace,invoice,refunded)

    def reconcile(self, subscription: Mapping[str,Any], provider_events: list[Mapping[str,Any]]) -> BillingLifecycle:
        current=BillingLifecycle(str(subscription.get("status","unknown")),str(subscription.get("plan_id","free")))
        for event in provider_events: current=self.apply(current,event)
        return current

class StripeBillingProvider:
    """Optional hosted Stripe adapter; LUMO remains the entitlement authority.

    No network call occurs until this adapter is explicitly invoked and a secret
    key is supplied. Price IDs are configuration, not hard-coded product data.
    """
    def __init__(self, secret_key: str | None = None, *, base_url: str = "https://api.stripe.com"):
        self.secret_key = secret_key or os.getenv("STRIPE_SECRET_KEY", "")
        self.base_url = base_url.rstrip("/")
        if not self.secret_key:
            raise ValueError("Stripe secret key is not configured")
        if not self.base_url.startswith("https://"):
            raise ValueError("Stripe base URL must use HTTPS")

    def _post(self, path: str, fields: dict[str, Any]) -> dict[str, Any]:
        from urllib.parse import urlencode
        from urllib.request import Request, urlopen
        body = urlencode({k: str(v) for k, v in fields.items()}).encode()
        request = Request(
            self.base_url + path,
            data=body,
            method="POST",
            headers={"Authorization": f"Bearer {self.secret_key}", "Content-Type": "application/x-www-form-urlencoded"},
        )
        with urlopen(request, timeout=15) as response:
            return json.loads(response.read(2_000_000).decode())

    def create_checkout(self, *, account_id: str, plan_id: str, success_url: str, cancel_url: str) -> dict[str, Any]:
        price_id = os.getenv(f"STRIPE_PRICE_ID_{plan_id.upper()}", "")
        if not price_id:
            raise ValueError(f"Stripe price ID is not configured for plan {plan_id!r}")
        if not account_id.strip():
            raise ValueError("account_id is required")
        if not success_url.startswith("https://") or not cancel_url.startswith("https://"):
            raise ValueError("checkout return URLs must use HTTPS")
        return self._post("/v1/checkout/sessions", {
            "mode": "subscription", "line_items[0][price]": price_id,
            "line_items[0][quantity]": 1, "client_reference_id": account_id,
            "success_url": success_url, "cancel_url": cancel_url,
        })

    def calculate_tax(self, *, amount_cents: int, currency: str, account_id: str, tax_code: str = "txcd_10000000") -> dict[str, Any]:
        if amount_cents <= 0:
            raise ValueError("amount_cents must be positive")
        if not re.fullmatch(r"[A-Za-z]{3}", currency):
            raise ValueError("currency must be a 3-letter code")
        if not account_id.strip():
            raise ValueError("account_id is required")
        return self._post("/v1/tax/calculations", {
            "currency": currency.lower(), "line_items[0][amount]": amount_cents,
            "line_items[0][quantity]": 1, "line_items[0][tax_code]": tax_code,
            "reference": account_id,
        })
