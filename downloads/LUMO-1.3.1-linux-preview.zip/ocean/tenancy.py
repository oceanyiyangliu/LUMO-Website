"""Durable organization, team, seat, and role hierarchy for multi-user LUMO."""
from __future__ import annotations

import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Organization:
    id: str
    name: str
    account_id: str


@dataclass(frozen=True)
class Membership:
    organization_id: str
    principal_id: str
    role: str
    team_id: str | None = None


class TenancyStore:
    ROLES = {"owner": 3, "admin": 2, "operator": 1, "viewer": 0}

    def __init__(self, path: str | Path):
        self.path = str(path)
        self.db = sqlite3.connect(self.path)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=NORMAL")
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS organizations(id TEXT PRIMARY KEY,name TEXT NOT NULL,account_id TEXT NOT NULL UNIQUE);
        CREATE TABLE IF NOT EXISTS teams(id TEXT PRIMARY KEY,organization_id TEXT NOT NULL,name TEXT NOT NULL,UNIQUE(organization_id,name));
        CREATE TABLE IF NOT EXISTS seats(organization_id TEXT NOT NULL,principal_id TEXT NOT NULL,role TEXT NOT NULL,team_id TEXT,created_at REAL NOT NULL,PRIMARY KEY(organization_id,principal_id));
        """)
        self.db.commit()

    def create_organization(self, organization_id: str, account_id: str, name: str) -> Organization:
        if not all(str(x).strip() for x in (organization_id, account_id, name)):
            raise ValueError("organization_id, account_id and name are required")
        self.db.execute("INSERT INTO organizations VALUES(?,?,?)", (organization_id, name.strip(), account_id))
        self.db.commit()
        return Organization(organization_id, name.strip(), account_id)

    def add_team(self, organization_id: str, team_id: str, name: str) -> str:
        self._org(organization_id)
        self.db.execute("INSERT INTO teams VALUES(?,?,?)", (team_id, organization_id, name.strip()))
        self.db.commit()
        return team_id

    def add_member(self, organization_id: str, principal_id: str, role: str = "viewer", team_id: str | None = None) -> Membership:
        self._org(organization_id)
        if role not in self.ROLES: raise ValueError("unknown role")
        if team_id is not None and self.db.execute("SELECT 1 FROM teams WHERE id=? AND organization_id=?", (team_id, organization_id)).fetchone() is None:
            raise KeyError(team_id)
        self.db.execute("INSERT INTO seats VALUES(?,?,?,?,?)", (organization_id, principal_id, role, team_id, time.time()))
        self.db.commit()
        return Membership(organization_id, principal_id, role, team_id)

    def authorize(self, organization_id: str, principal_id: str, required_role: str) -> bool:
        if required_role not in self.ROLES: raise ValueError("unknown role")
        row=self.db.execute("SELECT role FROM seats WHERE organization_id=? AND principal_id=?",(organization_id,principal_id)).fetchone()
        if row is None: return False
        role=str(row[0])
        return self.ROLES[role] >= self.ROLES[required_role]

    def _org(self, organization_id: str):
        if self.db.execute("SELECT 1 FROM organizations WHERE id=?", (organization_id,)).fetchone() is None:
            raise KeyError(organization_id)
