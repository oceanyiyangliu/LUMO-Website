"""Durable task-to-agent assignment domain model."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, Optional

from ocean.core.clock import Clock, SYSTEM_CLOCK
from ocean.core.ids import new_id
from ocean.domain.enums import AssignmentStatus, OrchestrationMode


ASSIGNMENT_TRANSITIONS = {
    AssignmentStatus.CREATED: {
        AssignmentStatus.QUEUED,
        AssignmentStatus.CANCELLED,
    },
    AssignmentStatus.QUEUED: {
        AssignmentStatus.ACTIVE,
        AssignmentStatus.CANCELLED,
        AssignmentStatus.SUPERSEDED,
    },
    AssignmentStatus.ACTIVE: {
        AssignmentStatus.COMPLETED,
        AssignmentStatus.FAILED,
        AssignmentStatus.CANCELLED,
        AssignmentStatus.SUPERSEDED,
    },
    AssignmentStatus.COMPLETED: set(),
    AssignmentStatus.FAILED: set(),
    AssignmentStatus.SUPERSEDED: set(),
    AssignmentStatus.CANCELLED: set(),
}


ASSIGNMENT_TERMINAL = {
    AssignmentStatus.COMPLETED,
    AssignmentStatus.FAILED,
    AssignmentStatus.SUPERSEDED,
    AssignmentStatus.CANCELLED,
}


@dataclass
class Assignment:
    """
    Durable binding between a Task and an Agent.

    An Assignment records orchestration intent, execution binding, lifecycle,
    and lineage. It does not execute work and does not determine Task success.
    """

    task_id: str
    agent_id: str
    principal_id: Optional[str] = None
    mission_id: Optional[str] = None
    mode: OrchestrationMode = OrchestrationMode.STANDARD
    priority: int = 0
    status: AssignmentStatus = AssignmentStatus.CREATED
    execution_id: Optional[str] = None
    parent_assignment_id: Optional[str] = None
    reason: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: new_id("assignment"))
    created_at: datetime = field(
        default_factory=lambda: SYSTEM_CLOCK.now()
    )
    updated_at: datetime = field(
        default_factory=lambda: SYSTEM_CLOCK.now()
    )

    def __post_init__(self) -> None:
        if not self.task_id:
            raise ValueError("assignment task_id must not be empty")

        if not self.agent_id:
            raise ValueError("assignment agent_id must not be empty")

        if self.priority < 0:
            raise ValueError("assignment priority must be non-negative")

        if not self.id:
            raise ValueError("assignment id must not be empty")

        if self.mission_id is not None and not self.mission_id:
            raise ValueError("assignment mission_id must not be empty")

        if self.execution_id is not None and not self.execution_id:
            raise ValueError("assignment execution_id must not be empty")

        if self.parent_assignment_id == self.id:
            raise ValueError(
                "assignment parent_assignment_id cannot reference itself"
            )

    def transition(
        self,
        new_status: AssignmentStatus,
        *,
        reason: Optional[str] = None,
        clock: Clock = SYSTEM_CLOCK,
    ) -> None:
        """Perform an authoritative lifecycle transition."""

        allowed = ASSIGNMENT_TRANSITIONS[self.status]

        if new_status not in allowed:
            raise ValueError(
                f"invalid assignment transition: "
                f"{self.status.value} -> {new_status.value}"
            )

        self.status = new_status

        if reason is not None:
            self.reason = reason

        self.updated_at = clock.now()

    def queue(
        self,
        *,
        reason: Optional[str] = None,
        clock: Clock = SYSTEM_CLOCK,
    ) -> None:
        """Move a created assignment into the orchestration queue."""

        self.transition(
            AssignmentStatus.QUEUED,
            reason=reason,
            clock=clock,
        )

    def activate(
        self,
        *,
        execution_id: Optional[str] = None,
        reason: Optional[str] = None,
        clock: Clock = SYSTEM_CLOCK,
    ) -> None:
        """Mark the assignment as actively executing."""

        if execution_id is not None:
            self.bind_execution(execution_id, clock=clock)

        self.transition(
            AssignmentStatus.ACTIVE,
            reason=reason,
            clock=clock,
        )

    def bind_execution(
        self,
        execution_id: str,
        *,
        clock: Clock = SYSTEM_CLOCK,
    ) -> None:
        """Bind exactly one execution attempt to this assignment."""

        if not execution_id:
            raise ValueError("assignment execution_id must not be empty")

        if (
            self.execution_id is not None
            and self.execution_id != execution_id
        ):
            raise ValueError(
                "assignment execution is already bound to a different execution"
            )

        self.execution_id = execution_id
        self.updated_at = clock.now()

    def complete(
        self,
        *,
        reason: Optional[str] = None,
        clock: Clock = SYSTEM_CLOCK,
    ) -> None:
        """Mark the assignment attempt as successfully completed."""

        self.transition(
            AssignmentStatus.COMPLETED,
            reason=reason,
            clock=clock,
        )

    def fail(
        self,
        *,
        reason: Optional[str] = None,
        clock: Clock = SYSTEM_CLOCK,
    ) -> None:
        """Mark the assignment attempt as failed."""

        self.transition(
            AssignmentStatus.FAILED,
            reason=reason,
            clock=clock,
        )

    def supersede(
        self,
        *,
        reason: Optional[str] = None,
        clock: Clock = SYSTEM_CLOCK,
    ) -> None:
        """Mark the assignment as intentionally replaced."""

        self.transition(
            AssignmentStatus.SUPERSEDED,
            reason=reason,
            clock=clock,
        )

    def cancel(
        self,
        *,
        reason: Optional[str] = None,
        clock: Clock = SYSTEM_CLOCK,
    ) -> None:
        """Cancel the assignment."""

        self.transition(
            AssignmentStatus.CANCELLED,
            reason=reason,
            clock=clock,
        )

    def is_terminal(self) -> bool:
        """Return whether this assignment has reached a terminal state."""

        return self.status in ASSIGNMENT_TERMINAL

    def is_active(self) -> bool:
        """Return whether this assignment currently owns active work."""

        return self.status == AssignmentStatus.ACTIVE

    def is_queued(self) -> bool:
        """Return whether this assignment is waiting for execution."""

        return self.status == AssignmentStatus.QUEUED

    def is_failed(self) -> bool:
        """Return whether this assignment attempt failed."""

        return self.status == AssignmentStatus.FAILED

    def is_superseded(self) -> bool:
        """Return whether orchestration replaced this assignment."""

        return self.status == AssignmentStatus.SUPERSEDED
