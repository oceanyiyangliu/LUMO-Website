"""Observation: information gathered from the environment, always timestamped
and always tied back to the task/execution that produced the need for it
(brief section 21)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, Optional

from ocean.core.clock import SYSTEM_CLOCK
from ocean.core.ids import new_id


@dataclass(frozen=True)
class Observation:
    kind: str
    data: Dict[str, Any] = field(default_factory=dict)
    task_id: Optional[str] = None
    execution_id: Optional[str] = None
    id: str = field(default_factory=lambda: new_id("obs"))
    at: datetime = field(default_factory=lambda: SYSTEM_CLOCK.now())
