"""First-class LUMO execution-world domain primitive.

A World is the isolation boundary in which a mission executes.  The domain
model deliberately does not assume a VM: providers may implement worlds with
browser profiles today and virtual machines/desktop sandboxes later.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import math
from datetime import datetime
from typing import Any, Mapping

from ocean.core.clock import Clock, SYSTEM_CLOCK
from ocean.core.ids import new_id
from .enums import WorldStatus


@dataclass(frozen=True)
class WorldRequirements:
    """Declarative requirements used by WorldManager provider selection."""
    capabilities: tuple[str, ...] = ()
    resources: Mapping[str, float] = field(default_factory=dict)
    persistent: bool = True
    network: bool = True

    def __post_init__(self) -> None:
        if any(not item.strip() for item in self.capabilities):
            raise ValueError("world capabilities must be non-empty strings")
        for value in self.resources.values():
            numeric = float(value)
            if not math.isfinite(numeric) or numeric < 0:
                raise ValueError("world resource amounts must be finite and non-negative")
        object.__setattr__(self, "capabilities", tuple(dict.fromkeys(self.capabilities)))
        object.__setattr__(self, "resources", dict(self.resources))


@dataclass
class World:
    """Durable identity and state for one isolated execution environment."""
    kind: str
    mission_id: str | None = None
    account_id: str | None = None
    requirements: WorldRequirements = field(default_factory=WorldRequirements)
    capabilities: tuple[str, ...] = ()
    resources: Mapping[str, float] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: new_id("world"))
    status: WorldStatus = WorldStatus.PROVISIONING
    created_at: datetime = field(default_factory=lambda: SYSTEM_CLOCK.now())
    updated_at: datetime = field(default_factory=lambda: SYSTEM_CLOCK.now())
    snapshot_id: str | None = None

    def __post_init__(self) -> None:
        if not self.kind.strip():
            raise ValueError("world kind is required")
        if self.account_id is not None and not str(self.account_id).strip():
            raise ValueError("world account_id must be non-empty when supplied")
        object.__setattr__(self, "capabilities", tuple(dict.fromkeys(self.capabilities)))
        self.resources = dict(self.resources)
        self.metadata = dict(self.metadata)

    def transition(self, status: WorldStatus, *, clock: Clock = SYSTEM_CLOCK) -> None:
        allowed = {
            WorldStatus.PROVISIONING: {WorldStatus.READY, WorldStatus.FAILED, WorldStatus.DESTROYED},
            WorldStatus.READY: {WorldStatus.PROVISIONING, WorldStatus.RUNNING, WorldStatus.PAUSED, WorldStatus.DESTROYING, WorldStatus.FAILED},
            WorldStatus.RUNNING: {WorldStatus.READY, WorldStatus.PAUSED, WorldStatus.DESTROYING, WorldStatus.FAILED},
            WorldStatus.PAUSED: {WorldStatus.PROVISIONING, WorldStatus.READY, WorldStatus.RUNNING, WorldStatus.DESTROYING, WorldStatus.FAILED},
            WorldStatus.DESTROYING: {WorldStatus.DESTROYED, WorldStatus.FAILED},
            WorldStatus.FAILED: {WorldStatus.PROVISIONING, WorldStatus.DESTROYING, WorldStatus.DESTROYED},
            WorldStatus.DESTROYED: set(),
        }
        if status not in allowed[self.status]:
            raise ValueError(f"invalid world transition: {self.status.value} -> {status.value}")
        self.status = status
        self.updated_at = clock.now()

    def supports(self, requirements: WorldRequirements) -> bool:
        available = set(self.capabilities)
        if not set(requirements.capabilities).issubset(available):
            return False
        return all(float(self.resources.get(k, 0)) >= float(v) for k, v in requirements.resources.items())

    def is_terminal(self) -> bool:
        return self.status is WorldStatus.DESTROYED
