"""Artifact: a file, document, dataset, or other output agents produce and
exchange, with identity and provenance (brief section 19)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, Optional

from ocean.core.clock import SYSTEM_CLOCK
from ocean.core.ids import new_id


@dataclass
class Artifact:
    kind: str
    name: str
    uri: Optional[str] = None
    produced_by_task_id: Optional[str] = None
    produced_by_agent_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    id: str = field(default_factory=lambda: new_id("artifact"))
    created_at: datetime = field(default_factory=lambda: SYSTEM_CLOCK.now())
