"""Agent: a worker that reasons and executes tasks through capabilities.

Deliberately generic -- "researcher", "coder", "verifier" etc. are
*configurations* of this one Agent type (a role name + a capability set),
not hard-coded subclasses (brief section 6: agents must not be baked into
the architecture as fixed classes).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, Optional, Set

from ocean.core.clock import Clock, SYSTEM_CLOCK
from ocean.core.ids import new_id
from ocean.core.state_machine import StateMachine

from .enums import AgentStatus

AGENT_TRANSITIONS: Dict[AgentStatus, Set[AgentStatus]] = {
    AgentStatus.IDLE: {
        AgentStatus.ASSIGNED,
        AgentStatus.RUNNING,
        AgentStatus.BACKGROUND,
        AgentStatus.TERMINATED,
    },
    AgentStatus.ASSIGNED: {
        AgentStatus.RUNNING,
        AgentStatus.IDLE,
        AgentStatus.FAILED,
        AgentStatus.TERMINATED,
    },
    AgentStatus.RUNNING: {
        AgentStatus.IDLE,
        AgentStatus.WAITING,
        AgentStatus.FAILED,
        AgentStatus.TERMINATED,
    },
    AgentStatus.WAITING: {AgentStatus.RUNNING, AgentStatus.FAILED, AgentStatus.TERMINATED},
    AgentStatus.BACKGROUND: {AgentStatus.RUNNING, AgentStatus.IDLE, AgentStatus.TERMINATED},
    AgentStatus.FAILED: {AgentStatus.IDLE, AgentStatus.TERMINATED},
    AgentStatus.TERMINATED: set(),
}
AGENT_TERMINAL: Set[AgentStatus] = {AgentStatus.TERMINATED}

_agent_sm: StateMachine[AgentStatus] = StateMachine(AGENT_TRANSITIONS, AGENT_TERMINAL)


@dataclass
class Agent:
    name: str
    role: str
    capabilities: Set[str] = field(default_factory=set)
    metadata: Dict[str, Any] = field(default_factory=dict)

    id: str = field(default_factory=lambda: new_id("agent"))
    status: AgentStatus = AgentStatus.IDLE
    current_task_id: Optional[str] = None
    created_at: datetime = field(default_factory=lambda: SYSTEM_CLOCK.now())
    updated_at: datetime = field(default_factory=lambda: SYSTEM_CLOCK.now())

    def transition(self, new_status: AgentStatus, *, clock: Clock = SYSTEM_CLOCK) -> None:
        _agent_sm.validate(self.status, new_status)
        self.status = new_status
        self.updated_at = clock.now()

    def can_perform(self, capability: str) -> bool:
        return capability in self.capabilities

    def is_terminal(self) -> bool:
        return _agent_sm.is_terminal(self.status)
