"""Verification: the record that distinguishes "we did something" from
"the intended outcome actually happened" (brief section 20).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

from ocean.core.clock import SYSTEM_CLOCK
from ocean.core.ids import new_id


@dataclass(frozen=True)
class Verification:
    task_id: str
    method: str
    passed: bool
    evidence: List[str] = field(default_factory=list)
    execution_id: Optional[str] = None
    id: str = field(default_factory=lambda: new_id("verif"))
    at: datetime = field(default_factory=lambda: SYSTEM_CLOCK.now())

    def explain(self) -> str:
        status = "PASSED" if self.passed else "FAILED"
        evidence = "; ".join(self.evidence) if self.evidence else "no evidence recorded"
        return f"[{status}] {self.method}: {evidence}"
