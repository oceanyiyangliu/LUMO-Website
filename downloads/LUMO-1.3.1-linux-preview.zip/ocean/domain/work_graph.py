"""Immutable work-graph primitives for Ocean planning."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import Any, Mapping, Optional, Tuple

from ocean.core.ids import new_id


def _freeze(value: Any) -> Any:
    """Recursively convert supported containers into immutable values."""
    if isinstance(value, Mapping):
        return MappingProxyType(
            {key: _freeze(item) for key, item in value.items()}
        )
    if isinstance(value, (list, tuple)):
        return tuple(_freeze(item) for item in value)
    if isinstance(value, (set, frozenset)):
        return frozenset(_freeze(item) for item in value)
    return value


class WorkNodeKind(str, Enum):
    TASK = "task"
    CONDITION = "condition"
    JOIN = "join"
    WAIT = "wait"
    HUMAN_APPROVAL = "human_approval"
    REPLAN = "replan"


class WorkEdgeKind(str, Enum):
    DEPENDENCY = "dependency"
    CONDITIONAL = "conditional"


@dataclass(frozen=True)
class WorkNode:
    """A node in a plan's work graph.

    A TASK node binds to an existing Task. Structural nodes do not.
    WorkNode never executes work itself.
    """

    kind: WorkNodeKind
    task_id: Optional[str] = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: new_id("node"))

    def __post_init__(self) -> None:
        if self.kind == WorkNodeKind.TASK:
            if not self.task_id or not self.task_id.strip():
                raise ValueError("TASK nodes require task_id")
        elif self.task_id is not None:
            raise ValueError(f"{self.kind.value} nodes cannot bind task_id")

        object.__setattr__(self, "metadata", _freeze(self.metadata))


@dataclass(frozen=True)
class WorkEdge:
    """A directed relationship between two work-graph nodes.

    Conditions describe transition intent only. WorkEdge never evaluates
    conditions; evaluation belongs to a future planning/runtime service.
    """

    source_node_id: str
    target_node_id: str
    kind: WorkEdgeKind
    condition: Optional[str] = None
    id: str = field(default_factory=lambda: new_id("edge"))

    def __post_init__(self) -> None:
        if not self.source_node_id or not self.source_node_id.strip():
            raise ValueError("source_node_id must be non-empty")
        if not self.target_node_id or not self.target_node_id.strip():
            raise ValueError("target_node_id must be non-empty")
        if self.source_node_id == self.target_node_id:
            raise ValueError("work edges cannot connect a node to itself")

        if self.kind == WorkEdgeKind.CONDITIONAL:
            if not self.condition or not self.condition.strip():
                raise ValueError("CONDITIONAL edges require condition")
        elif self.condition is not None:
            raise ValueError("DEPENDENCY edges cannot have a condition")


@dataclass(frozen=True)
class WorkGraph:
    """Immutable validated graph describing planned work relationships."""

    mission_id: str
    plan_revision_id: str
    nodes: Tuple[WorkNode, ...] = ()
    edges: Tuple[WorkEdge, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: new_id("graph"))

    def __post_init__(self) -> None:
        if not self.mission_id or not self.mission_id.strip():
            raise ValueError("mission_id must be non-empty")
        if not self.plan_revision_id or not self.plan_revision_id.strip():
            raise ValueError("plan_revision_id must be non-empty")

        nodes = tuple(self.nodes)
        edges = tuple(self.edges)

        node_ids = [node.id for node in nodes]
        if len(node_ids) != len(set(node_ids)):
            raise ValueError("work graph cannot contain duplicate node ids")

        node_id_set = set(node_ids)

        edge_pairs = [
            (edge.source_node_id, edge.target_node_id, edge.kind)
            for edge in edges
        ]
        if len(edge_pairs) != len(set(edge_pairs)):
            raise ValueError("work graph cannot contain duplicate edges")

        for edge in edges:
            if edge.source_node_id not in node_id_set:
                raise ValueError(
                    f"edge references unknown source node "
                    f"{edge.source_node_id!r}"
                )
            if edge.target_node_id not in node_id_set:
                raise ValueError(
                    f"edge references unknown target node "
                    f"{edge.target_node_id!r}"
                )

        self._validate_dependency_acyclic(nodes, edges)

        object.__setattr__(self, "nodes", nodes)
        object.__setattr__(self, "edges", edges)
        object.__setattr__(self, "metadata", _freeze(self.metadata))

    @staticmethod
    def _validate_dependency_acyclic(
        nodes: Tuple[WorkNode, ...],
        edges: Tuple[WorkEdge, ...],
    ) -> None:
        adjacency: dict[str, set[str]] = {node.id: set() for node in nodes}

        for edge in edges:
            if edge.kind == WorkEdgeKind.DEPENDENCY:
                adjacency[edge.source_node_id].add(edge.target_node_id)

        visiting: set[str] = set()
        visited: set[str] = set()

        def visit(node_id: str) -> None:
            if node_id in visiting:
                raise ValueError("work graph contains a dependency cycle")
            if node_id in visited:
                return

            visiting.add(node_id)
            for child in adjacency[node_id]:
                visit(child)
            visiting.remove(node_id)
            visited.add(node_id)

        for node_id in adjacency:
            visit(node_id)

    def node(self, node_id: str) -> WorkNode:
        for node in self.nodes:
            if node.id == node_id:
                return node
        raise KeyError(f"unknown work node: {node_id!r}")

    def edge(self, edge_id: str) -> WorkEdge:
        for edge in self.edges:
            if edge.id == edge_id:
                return edge
        raise KeyError(f"unknown work edge: {edge_id!r}")
