"""Capability registry: the mechanism that lets Ocean answer "what can I do?"
without the core ever maintaining a hard-coded enum of actions (brief
sections 3, 27, 28; RULE 9).

A CapabilitySpec is pure metadata -- name, operations, risk, execution
strategy, resource needs. It carries NO implementation. Binding a spec to
actual runtime code (filesystem calls, browser automation, etc.) is a Phase 4
concern (CapabilityRuntime); Phase 1 only needs the contract to be real and
enforceable so agents/orchestrator/policy can all be written against it now.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Set

from ocean.core.errors import DuplicateRegistration, UnknownCapability, UnknownOperation

from .enums import RiskLevel
from .resource import ResourceRequirement


class CapabilityIsolationPolicy(str, Enum):
    IN_PROCESS_SAFE = "in_process_safe"
    PROCESS_ISOLATED = "process_isolated"
    PROCESS_ISOLATED_REQUIRED = "process_isolated_required"


@dataclass(frozen=True)
class CapabilityExecutionPolicy:
    isolation: CapabilityIsolationPolicy = CapabilityIsolationPolicy.IN_PROCESS_SAFE

    @property
    def process_isolated(self) -> bool:
        return self.isolation is not CapabilityIsolationPolicy.IN_PROCESS_SAFE


@dataclass(frozen=True)
class OperationSpec:
    name: str
    description: str
    input_schema: Dict[str, Any] = field(default_factory=dict)
    output_schema: Dict[str, Any] = field(default_factory=dict)
    risk_level: RiskLevel = RiskLevel.LOW
    resource_requirements: List[ResourceRequirement] = field(default_factory=list)


@dataclass(frozen=True)
class CapabilitySpec:
    name: str
    description: str
    operations: Dict[str, OperationSpec]
    execution_strategy: str = "deterministic_local"
    requires_permissions: Set[str] = field(default_factory=set)
    execution_policy: CapabilityExecutionPolicy = field(
        default_factory=CapabilityExecutionPolicy
    )

    def operation(self, name: str) -> OperationSpec:
        try:
            return self.operations[name]
        except KeyError as exc:
            raise UnknownOperation(f"{self.name}.{name}") from exc


class CapabilityRegistry:
    """Register/describe/lookup capabilities. No orchestrator, agent, or
    policy code should ever need to change when a new capability is added --
    only a `register()` call, per RULE 9 / section 28."""

    def __init__(self) -> None:
        self._capabilities: Dict[str, CapabilitySpec] = {}

    def register(self, spec: CapabilitySpec) -> None:
        if spec.name in self._capabilities:
            raise DuplicateRegistration(f"capability '{spec.name}' already registered")
        self._capabilities[spec.name] = spec

    def get(self, name: str) -> CapabilitySpec:
        try:
            return self._capabilities[name]
        except KeyError as exc:
            raise UnknownCapability(name) from exc

    def get_operation(self, capability_name: str, operation_name: str) -> OperationSpec:
        return self.get(capability_name).operation(operation_name)

    def unregister(self, name: str) -> CapabilitySpec:
        try:
            return self._capabilities.pop(name)
        except KeyError as exc:
            raise UnknownCapability(name) from exc

    def disable(self, name: str) -> CapabilitySpec:
        return self.unregister(name)

    def list_capabilities(self) -> List[CapabilitySpec]:
        return list(self._capabilities.values())

    def describe(self) -> Dict[str, Any]:
        """Machine-readable catalogue -- what the reasoning/planning layer
        feeds the model so it knows what's actually available, instead of
        the model hallucinating capabilities (brief: "the LLM must NOT be
        the source of truth for what capabilities exist")."""
        return {
            cap.name: {
                "description": cap.description,
                "execution_strategy": cap.execution_strategy,
                "execution_policy": {
                    "isolation": cap.execution_policy.isolation.value,
                },
                "requires_permissions": sorted(cap.requires_permissions),
                "operations": {
                    op.name: {
                        "description": op.description,
                        "risk_level": op.risk_level.value,
                        "input_schema": op.input_schema,
                        "output_schema": op.output_schema,
                    }
                    for op in cap.operations.values()
                },
            }
            for cap in self._capabilities.values()
        }
