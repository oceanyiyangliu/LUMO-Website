"""Immutable planning decisions.

A Decision records an auditable strategic choice for a mission.
It stores concise justification and evidence, never private chain-of-thought.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from types import MappingProxyType
from typing import Any, Mapping, Optional, Tuple

from ocean.core.clock import SYSTEM_CLOCK
from ocean.core.ids import new_id


def _freeze(value: Any) -> Any:
    """Recursively convert supported containers into immutable values."""
    if isinstance(value, Mapping):
        return MappingProxyType(
            {key: _freeze(item) for key, item in value.items()}
        )
    if isinstance(value, (list, tuple)):
        return tuple(_freeze(item) for item in value)
    if isinstance(value, (set, frozenset)):
        return frozenset(_freeze(item) for item in value)
    return value


@dataclass(frozen=True)
class Decision:
    """An immutable, auditable planning decision."""

    mission_id: str
    kind: str
    objective: str
    rationale: str
    alternatives: Tuple[str, ...] = ()
    selected_option: Optional[str] = None
    confidence: Optional[float] = None
    evidence: Tuple[str, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: new_id("decision"))
    created_at: datetime = field(default_factory=SYSTEM_CLOCK.now)

    def __post_init__(self) -> None:
        if not self.mission_id or not self.mission_id.strip():
            raise ValueError("mission_id must be non-empty")
        if not self.kind or not self.kind.strip():
            raise ValueError("kind must be non-empty")
        if not self.objective or not self.objective.strip():
            raise ValueError("objective must be non-empty")
        if not self.rationale or not self.rationale.strip():
            raise ValueError("rationale must be non-empty")
        if self.confidence is not None and not 0.0 <= self.confidence <= 1.0:
            raise ValueError("confidence must be between 0.0 and 1.0")

        alternatives = tuple(self.alternatives)
        evidence = tuple(self.evidence)

        if any(not item or not item.strip() for item in alternatives):
            raise ValueError("alternatives must contain only non-empty strings")
        if any(not item or not item.strip() for item in evidence):
            raise ValueError("evidence must contain only non-empty strings")
        if self.selected_option is not None and not self.selected_option.strip():
            raise ValueError("selected_option must be non-empty when provided")

        object.__setattr__(self, "alternatives", alternatives)
        object.__setattr__(self, "evidence", evidence)
        object.__setattr__(self, "metadata", _freeze(self.metadata))
