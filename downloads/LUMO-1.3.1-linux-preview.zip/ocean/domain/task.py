"""Task: the atomic unit of work in Ocean.

Deliberately encodes RULE 11 from the engineering brief: successful execution
does not equal task success. `Task.complete()` refuses to mark a task done
unless it is handed a *passing* Verification for that exact task -- there is
no code path that lets a task reach COMPLETED on execution success alone.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Set

from ocean.core.clock import Clock, SYSTEM_CLOCK
from ocean.core.errors import ValidationError
from ocean.core.ids import new_id
from ocean.core.state_machine import StateMachine

from .enums import AssigneeType, TaskStatus
from .verification import Verification

TASK_TRANSITIONS: Dict[TaskStatus, Set[TaskStatus]] = {
    TaskStatus.PENDING: {TaskStatus.READY, TaskStatus.BLOCKED, TaskStatus.CANCELLED},
    TaskStatus.READY: {TaskStatus.QUEUED, TaskStatus.BLOCKED, TaskStatus.CANCELLED},
    TaskStatus.QUEUED: {TaskStatus.RUNNING, TaskStatus.READY, TaskStatus.CANCELLED},
    TaskStatus.RUNNING: {
        TaskStatus.WAITING,
        TaskStatus.PAUSED,
        TaskStatus.COMPLETED,
        TaskStatus.FAILED,
        TaskStatus.CANCELLED,
    },
    TaskStatus.WAITING: {TaskStatus.RUNNING, TaskStatus.FAILED, TaskStatus.CANCELLED},
    TaskStatus.BLOCKED: {TaskStatus.READY, TaskStatus.CANCELLED},
    TaskStatus.PAUSED: {TaskStatus.RUNNING, TaskStatus.CANCELLED},
    TaskStatus.COMPLETED: set(),
    # FAILED -> READY models "replan and retry", not a silent auto-retry.
    TaskStatus.FAILED: {TaskStatus.READY, TaskStatus.CANCELLED},
    TaskStatus.CANCELLED: set(),
}
TASK_TERMINAL: Set[TaskStatus] = {TaskStatus.COMPLETED, TaskStatus.CANCELLED}

_task_sm: StateMachine[TaskStatus] = StateMachine(TASK_TRANSITIONS, TASK_TERMINAL)


@dataclass(frozen=True)
class TaskTransitionRecord:
    from_status: Optional[TaskStatus]
    to_status: TaskStatus
    at: datetime
    reason: Optional[str] = None


@dataclass
class Task:
    title: str
    description: str = ""
    mission_id: Optional[str] = None
    depends_on: Set[str] = field(default_factory=set)
    assignee_type: AssigneeType = AssigneeType.AGENT
    assignee_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    id: str = field(default_factory=lambda: new_id("task"))
    status: TaskStatus = TaskStatus.PENDING
    result: Optional[Any] = None
    verification_id: Optional[str] = None
    history: List[TaskTransitionRecord] = field(default_factory=list)
    created_at: datetime = field(default_factory=lambda: SYSTEM_CLOCK.now())
    updated_at: datetime = field(default_factory=lambda: SYSTEM_CLOCK.now())

    def transition(
        self,
        new_status: TaskStatus,
        *,
        reason: Optional[str] = None,
        clock: Clock = SYSTEM_CLOCK,
    ) -> None:
        _task_sm.validate(self.status, new_status)
        now = clock.now()
        self.history.append(TaskTransitionRecord(self.status, new_status, now, reason))
        self.status = new_status
        self.updated_at = now

    def complete(self, verification: Verification, *, clock: Clock = SYSTEM_CLOCK) -> None:
        """The only sanctioned path to COMPLETED. Requires a passing
        Verification for *this* task -- execution success alone is not
        sufficient (brief RULE 11 / section 20)."""
        if verification.task_id != self.id:
            raise ValidationError(
                f"verification {verification.id} belongs to task "
                f"{verification.task_id!r}, not {self.id!r}"
            )
        if not verification.passed:
            raise ValidationError(
                f"cannot complete task {self.id}: verification did not pass "
                f"({verification.explain()})"
            )
        self.verification_id = verification.id
        self.transition(TaskStatus.COMPLETED, reason="verification passed", clock=clock)

    def fail(self, reason: str, *, clock: Clock = SYSTEM_CLOCK) -> None:
        self.transition(TaskStatus.FAILED, reason=reason, clock=clock)

    def cancel(self, reason: str = "cancelled", *, clock: Clock = SYSTEM_CLOCK) -> None:
        self.transition(TaskStatus.CANCELLED, reason=reason, clock=clock)

    def is_terminal(self) -> bool:
        return _task_sm.is_terminal(self.status)

    def is_ready(self, completed_task_ids: Set[str]) -> bool:
        """A task is ready once every dependency has completed."""
        return self.depends_on.issubset(completed_task_ids)
