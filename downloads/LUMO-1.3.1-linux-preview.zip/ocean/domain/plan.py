"""Immutable versioned planning revisions."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from types import MappingProxyType
from typing import Any, Mapping, Optional

from ocean.core.clock import SYSTEM_CLOCK
from ocean.core.ids import new_id


def _freeze(value: Any) -> Any:
    """Recursively convert supported containers into immutable values."""
    if isinstance(value, Mapping):
        return MappingProxyType(
            {key: _freeze(item) for key, item in value.items()}
        )
    if isinstance(value, (list, tuple)):
        return tuple(_freeze(item) for item in value)
    if isinstance(value, (set, frozenset)):
        return frozenset(_freeze(item) for item in value)
    return value


class PlanStatus(str, Enum):
    DRAFT = "draft"
    PROPOSED = "proposed"
    ACTIVE = "active"
    SUPERSEDED = "superseded"
    CANCELLED = "cancelled"
    COMPLETED = "completed"


@dataclass(frozen=True)
class PlanRevision:
    """One immutable version of a mission's strategic plan."""

    mission_id: str
    revision: int
    decision_id: str
    graph_id: str
    parent_revision_id: Optional[str] = None
    status: PlanStatus = PlanStatus.DRAFT
    reason: Optional[str] = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: new_id("plan"))
    created_at: datetime = field(default_factory=SYSTEM_CLOCK.now)

    def __post_init__(self) -> None:
        if not self.mission_id or not self.mission_id.strip():
            raise ValueError("mission_id must be non-empty")
        if not self.decision_id or not self.decision_id.strip():
            raise ValueError("decision_id must be non-empty")
        if not self.graph_id or not self.graph_id.strip():
            raise ValueError("graph_id must be non-empty")
        if self.revision < 1:
            raise ValueError("revision must be >= 1")
        if self.parent_revision_id is not None and not self.parent_revision_id.strip():
            raise ValueError("parent_revision_id must be non-empty when provided")
        if self.reason is not None and not self.reason.strip():
            raise ValueError("reason must be non-empty when provided")
        if self.revision == 1 and self.parent_revision_id is not None:
            raise ValueError("revision 1 cannot have a parent revision")
        if self.revision > 1 and self.parent_revision_id is None:
            raise ValueError("revisions after 1 require a parent_revision_id")

        object.__setattr__(self, "metadata", _freeze(self.metadata))
