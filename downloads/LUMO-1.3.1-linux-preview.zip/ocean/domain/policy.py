"""Policy engine: risk classification and approval routing, kept independent
of any individual capability's implementation (brief section 11; RULE 19).

Default behaviour maps RiskLevel -> ApprovalDecision. Capability authors
don't write approval logic; they just tag each operation with a RiskLevel
(see capability.OperationSpec). Callers needing finer-grained control (e.g.
"deleting files under /tmp is SAFE but deleting files under ~/Documents is
HIGH") register an override keyed by (capability, operation) that inspects
the PolicyContext and returns a decision.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Optional, Tuple

from .enums import ApprovalDecision, RiskLevel


@dataclass(frozen=True)
class PolicyContext:
    capability: str
    operation: str
    risk_level: RiskLevel
    metadata: Dict[str, Any] = field(default_factory=dict)


PolicyRule = Callable[[PolicyContext], ApprovalDecision]

_DEFAULT_RISK_MAP: Dict[RiskLevel, ApprovalDecision] = {
    RiskLevel.SAFE: ApprovalDecision.AUTOMATIC,
    RiskLevel.LOW: ApprovalDecision.AUTOMATIC_LOGGED,
    RiskLevel.IMPORTANT: ApprovalDecision.USER_CONFIRMATION_REQUIRED,
    RiskLevel.HIGH: ApprovalDecision.EXPLICIT_APPROVAL_REQUIRED,
}


class PolicyEngine:
    def __init__(self, default_risk_map: Optional[Dict[RiskLevel, ApprovalDecision]] = None) -> None:
        self._default_map = dict(default_risk_map or _DEFAULT_RISK_MAP)
        self._overrides: Dict[Tuple[str, str], PolicyRule] = {}

    def register_override(self, capability: str, operation: str, rule: PolicyRule) -> None:
        self._overrides[(capability, operation)] = rule

    def evaluate(self, ctx: PolicyContext) -> ApprovalDecision:
        # Model/external content is data, never an authority grant.
        metadata = ctx.metadata or {}
        if metadata.get("untrusted_instructions") or metadata.get("prompt_injection_detected"):
            return ApprovalDecision.DENIED
        if metadata.get("model_requested_permission_grant") or metadata.get("authority_escalation"):
            return ApprovalDecision.DENIED
        rule = self._overrides.get((ctx.capability, ctx.operation))
        if rule is not None:
            return rule(ctx)
        return self._default_map[ctx.risk_level]

    def requires_human(self, decision: ApprovalDecision) -> bool:
        return decision in (
            ApprovalDecision.USER_CONFIRMATION_REQUIRED,
            ApprovalDecision.EXPLICIT_APPROVAL_REQUIRED,
        )
