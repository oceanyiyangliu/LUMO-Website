"""Synchronous domain event bus backed by pluggable event infrastructure."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List, Optional

from eventing.dispatcher import EventDispatcher
from eventing.store import EventStore
from eventing.in_memory_store import InMemoryEventStore

from .event import Event


Handler = Callable[[Event], None]
WILDCARD = "*"


@dataclass
class HandlerFailure:
    handler: Handler
    error: Exception


class EventBus:
    def __init__(
        self,
        store: Optional[EventStore] = None,
        dispatcher: Optional[EventDispatcher] = None,
    ) -> None:
        self._store = store or InMemoryEventStore()
        self._dispatcher = dispatcher or EventDispatcher()

    def subscribe(self, event_type: str, handler: Handler) -> None:
        """Subscribe to a concrete event type or '*' for all events."""
        self._dispatcher.subscribe(event_type, handler)

    def unsubscribe(self, event_type: str, handler: Handler) -> None:
        self._dispatcher.unsubscribe(event_type, handler)

    def publish(self, event: Event) -> List[HandlerFailure]:
        self._store.append(event)

        failures: list[HandlerFailure] = []

        def dispatch_after_commit() -> None:
            dispatched = self._dispatcher.dispatch(event)
            failures.extend(
                HandlerFailure(handler=failure.handler, error=failure.error)
                for failure in dispatched
            )

        after_commit = getattr(self._store, "after_commit", None)
        if callable(after_commit):
            after_commit(dispatch_after_commit)
        else:
            dispatch_after_commit()

        return failures

    def history(self, event_type: Optional[str] = None) -> List[Event]:
        return list(self._store.list(event_type))
