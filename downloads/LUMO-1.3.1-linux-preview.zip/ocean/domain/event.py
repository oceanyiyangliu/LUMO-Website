"""Event: an immutable record of something that happened in Ocean."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, Optional

from ocean.core.clock import SYSTEM_CLOCK
from ocean.core.ids import new_id


@dataclass(frozen=True)
class Event:
    """Immutable fact in Ocean's canonical event stream."""

    type: str
    payload: Dict[str, Any] = field(default_factory=dict)

    # Aggregate this event belongs to.
    aggregate_type: Optional[str] = None
    aggregate_id: Optional[str] = None

    # Version of this event's schema/meaning.
    version: int = 1

    # Ordering is authoritative; timestamps are informational.
    sequence: Optional[int] = None

    # Causality is distinct from ordering.
    causation_id: Optional[str] = None
    correlation_id: Optional[str] = None

    source: Optional[str] = None

    id: str = field(default_factory=lambda: new_id("evt"))
    at: datetime = field(default_factory=lambda: SYSTEM_CLOCK.now())
