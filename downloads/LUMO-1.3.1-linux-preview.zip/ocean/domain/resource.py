"""Resource requirement declarations.

Phase 1 only declares *what a capability/execution needs*; the resource
manager that admits/queues/defers work based on availability is Phase 3
scheduling territory (brief section 16). Declaring the shape now means
capabilities written today already carry the metadata the scheduler will
need later, without a later rewrite of every capability.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ResourceRequirement:
    kind: str  # e.g. "cpu", "network", "api_calls", "model_tokens", "agent_slot"
    amount: float = 1.0
