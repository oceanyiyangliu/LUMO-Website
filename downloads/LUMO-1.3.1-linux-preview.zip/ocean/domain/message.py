"""Message: structured, observable communication between agents (brief
section 7 -- explicitly *not* free-form agent-to-agent chat)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, Optional

from ocean.core.clock import SYSTEM_CLOCK
from ocean.core.ids import new_id


@dataclass(frozen=True)
class Message:
    sender_id: str
    recipient_id: str
    type: str
    payload: Dict[str, Any] = field(default_factory=dict)
    correlation_id: Optional[str] = None
    id: str = field(default_factory=lambda: new_id("msg"))
    at: datetime = field(default_factory=lambda: SYSTEM_CLOCK.now())
