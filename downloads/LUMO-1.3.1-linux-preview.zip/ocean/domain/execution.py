"""Execution: one concrete attempt to run a capability operation for a task.

Execution is deliberately dumb: it just records what was attempted, when, and
what came back. It has *no* opinion on whether the task succeeded -- that
judgment belongs to Verification (see task.Task.complete).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, Optional

from ocean.core.clock import Clock, SYSTEM_CLOCK
from ocean.core.errors import InvalidStateTransition
from ocean.core.ids import new_id

from .enums import ExecutionStatus, OrchestrationMode


@dataclass
class Execution:
    task_id: str
    capability: str
    operation: str
    arguments: Dict[str, Any] = field(default_factory=dict)
    agent_id: Optional[str] = None
    principal_id: Optional[str] = None
    mission_id: Optional[str] = None
    mode: OrchestrationMode = OrchestrationMode.STANDARD

    id: str = field(default_factory=lambda: new_id("exec"))
    status: ExecutionStatus = ExecutionStatus.PENDING
    started_at: Optional[datetime] = None
    ended_at: Optional[datetime] = None
    raw_result: Optional[Any] = None
    error: Optional[str] = None

    def start(self, *, clock: Clock = SYSTEM_CLOCK) -> None:
        if self.status != ExecutionStatus.PENDING:
            raise InvalidStateTransition(f"cannot start execution from {self.status}")
        self.status = ExecutionStatus.RUNNING
        self.started_at = clock.now()

    def succeed(self, result: Any = None, *, clock: Clock = SYSTEM_CLOCK) -> None:
        if self.status != ExecutionStatus.RUNNING:
            raise InvalidStateTransition(f"cannot succeed execution from {self.status}")
        self.status = ExecutionStatus.SUCCEEDED
        self.raw_result = result
        self.ended_at = clock.now()

    def fail(self, error: str, *, clock: Clock = SYSTEM_CLOCK) -> None:
        if self.status != ExecutionStatus.RUNNING:
            raise InvalidStateTransition(f"cannot fail execution from {self.status}")
        self.status = ExecutionStatus.FAILED
        self.error = error
        self.ended_at = clock.now()

    def time_out(self, *, clock: Clock = SYSTEM_CLOCK) -> None:
        if self.status != ExecutionStatus.RUNNING:
            raise InvalidStateTransition(f"cannot time out execution from {self.status}")
        self.status = ExecutionStatus.TIMED_OUT
        self.error = "timed out"
        self.ended_at = clock.now()
    def cancel(self, *, clock: Clock = SYSTEM_CLOCK) -> None:
        if self.status not in (ExecutionStatus.PENDING, ExecutionStatus.RUNNING):
            raise InvalidStateTransition(
                f"cannot cancel execution from {self.status}"
            )
        self.status = ExecutionStatus.CANCELLED
        self.error = "cancelled"
        self.ended_at = clock.now()
