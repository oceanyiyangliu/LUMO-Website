"""Status and classification enums shared across the domain layer."""

from __future__ import annotations

from enum import Enum


class TaskStatus(str, Enum):

    PENDING = "pending"

    READY = "ready"

    QUEUED = "queued"

    RUNNING = "running"

    WAITING = "waiting"

    BLOCKED = "blocked"

    PAUSED = "paused"

    COMPLETED = "completed"

    FAILED = "failed"

    CANCELLED = "cancelled"


class MissionStatus(str, Enum):

    PLANNING = "planning"

    ACTIVE = "active"

    PAUSED = "paused"

    COMPLETED = "completed"

    FAILED = "failed"

    CANCELLED = "cancelled"


class AgentStatus(str, Enum):

    IDLE = "idle"

    ASSIGNED = "assigned"

    RUNNING = "running"

    WAITING = "waiting"

    BACKGROUND = "background"

    FAILED = "failed"

    TERMINATED = "terminated"


class ExecutionStatus(str, Enum):

    PENDING = "pending"

    RUNNING = "running"

    SUCCEEDED = "succeeded"

    FAILED = "failed"

    TIMED_OUT = "timed_out"

    CANCELLED = "cancelled"


class AssignmentStatus(str, Enum):

    """Lifecycle state of a task-to-agent assignment."""

    CREATED = "created"

    QUEUED = "queued"

    ACTIVE = "active"

    COMPLETED = "completed"

    FAILED = "failed"

    SUPERSEDED = "superseded"

    CANCELLED = "cancelled"


class OrchestrationMode(str, Enum):

    """Intent governing how an assignment is orchestrated."""

    STANDARD = "standard"

    PARALLEL = "parallel"

    BACKGROUND = "background"

    QUEUED = "queued"

    ROUTINE = "routine"

    GHOST = "ghost"

    SWARM = "swarm"

    SHADOW = "shadow"

    SPECULATIVE = "speculative"


class RiskLevel(str, Enum):

    """Classification used by the policy layer (brief section 11)."""

    SAFE = "safe"

    LOW = "low"

    IMPORTANT = "important"

    HIGH = "high"


class ApprovalDecision(str, Enum):

    AUTOMATIC = "automatic"

    AUTOMATIC_LOGGED = "automatic_logged"

    USER_CONFIRMATION_REQUIRED = "user_confirmation_required"

    EXPLICIT_APPROVAL_REQUIRED = "explicit_approval_required"

    DENIED = "denied"


class FailureCategory(str, Enum):

    """Structured classification of execution failures for recovery routing."""

    TRANSIENT = "transient"
    TIMEOUT = "timeout"
    RESOURCE_EXHAUSTION = "resource_exhaustion"
    DEPENDENCY_FAILURE = "dependency_failure"
    PERMISSION_GOVERNANCE = "permission_governance"
    INVALID_INPUT = "invalid_input"
    INFRASTRUCTURE = "infrastructure"
    PERMANENT = "permanent"
    CANCELLATION = "cancellation"
    UNKNOWN = "unknown"


class AssigneeType(str, Enum):

    AGENT = "agent"

    HUMAN = "human"

    AGENT_AND_HUMAN = "agent_and_human"


class WorldStatus(str, Enum):
    """Lifecycle state of an isolated LUMO execution world."""

    PROVISIONING = "provisioning"
    READY = "ready"
    RUNNING = "running"
    PAUSED = "paused"
    DESTROYING = "destroying"
    DESTROYED = "destroyed"
    FAILED = "failed"
