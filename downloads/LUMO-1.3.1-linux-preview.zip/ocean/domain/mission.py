"""Mission: a large user objective decomposed into Tasks (brief section 8)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Set

from ocean.core.clock import Clock, SYSTEM_CLOCK
from ocean.core.ids import new_id
from ocean.core.state_machine import StateMachine

from .enums import MissionStatus

MISSION_TRANSITIONS: Dict[MissionStatus, Set[MissionStatus]] = {
    MissionStatus.PLANNING: {MissionStatus.ACTIVE, MissionStatus.CANCELLED},
    MissionStatus.ACTIVE: {
        MissionStatus.PAUSED,
        MissionStatus.COMPLETED,
        MissionStatus.FAILED,
        MissionStatus.CANCELLED,
    },
    MissionStatus.PAUSED: {MissionStatus.ACTIVE, MissionStatus.CANCELLED},
    MissionStatus.COMPLETED: set(),
    MissionStatus.FAILED: {MissionStatus.ACTIVE},  # replan and resume
    MissionStatus.CANCELLED: set(),
}
MISSION_TERMINAL: Set[MissionStatus] = {MissionStatus.COMPLETED, MissionStatus.CANCELLED}

_mission_sm: StateMachine[MissionStatus] = StateMachine(MISSION_TRANSITIONS, MISSION_TERMINAL)


@dataclass
class Mission:
    goal: str
    task_ids: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    id: str = field(default_factory=lambda: new_id("mission"))
    status: MissionStatus = MissionStatus.PLANNING
    created_at: datetime = field(default_factory=lambda: SYSTEM_CLOCK.now())
    updated_at: datetime = field(default_factory=lambda: SYSTEM_CLOCK.now())

    def transition(self, new_status: MissionStatus, *, clock: Clock = SYSTEM_CLOCK) -> None:
        _mission_sm.validate(self.status, new_status)
        self.status = new_status
        self.updated_at = clock.now()

    def add_task(self, task_id: str) -> None:
        if task_id not in self.task_ids:
            self.task_ids.append(task_id)

    def is_terminal(self) -> bool:
        return _mission_sm.is_terminal(self.status)
