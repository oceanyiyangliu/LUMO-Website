from __future__ import annotations

import argparse
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(prog="lumo-server", description="LUMO local control-plane server.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    argv = sys.argv[1:]
    if argv[:1] == ["serve"]:
        argv = argv[1:]
    args = parser.parse_args(argv)

    # Keep the packaged server entrypoint tiny. The full CLI contains mission,
    # computer-use and self-improvement tooling that is irrelevant to first
    # launch and should never sit on the Core startup path.
    from ocean.service import OceanService
    from ocean.api import LumoAPIServer

    service = OceanService(repository_root=Path.cwd())
    api_server = None
    try:
        service.start()
        api_server = LumoAPIServer(service, host=args.host, port=args.port)
        host, port = api_server.address
        print(f"LUMO API listening on http://{host}:{port}", flush=True)
        api_server.serve_forever()
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        print(f"lumo serve failed: {exc}", file=__import__("sys").stderr)
        return 1
    finally:
        if api_server is not None:
            api_server.shutdown()
        service.stop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
