"""Durable control-plane primitives for advanced LUMO mission operation.

These primitives are intentionally provider-neutral and local-first. They encode
policy and intent; the existing MissionControl/Scheduler remain authoritative
for execution.
"""
from __future__ import annotations

import hashlib
import json
import secrets
import sqlite3
import math
import threading
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Mapping, Optional


class MissionMode(str, Enum):
    NORMAL = "normal"
    DRY_RUN = "dry_run"
    SIMULATION = "simulation"


@dataclass(frozen=True)
class MissionPolicy:
    priority: int = 0
    deadline: Optional[datetime] = None
    budget: Mapping[str, float] = field(default_factory=dict)
    sla_seconds: Optional[float] = None
    mode: MissionMode = MissionMode.NORMAL
    checkpoint_interval: Optional[int] = None
    privacy: str = "standard"
    device_affinity: tuple[str, ...] = ()
    world_requirements: Mapping[str, Any] = field(default_factory=dict)
    model_requirements: Mapping[str, Any] = field(default_factory=dict)
    max_retries: int = 0

    def __post_init__(self) -> None:
        if isinstance(self.priority, bool) or self.priority < 0:
            raise ValueError("priority must be a non-negative integer")
        if self.deadline is not None and self.deadline.tzinfo is None:
            raise ValueError("deadline must be timezone-aware")
        if self.sla_seconds is not None and (not isinstance(self.sla_seconds, (int, float)) or isinstance(self.sla_seconds, bool) or not math.isfinite(float(self.sla_seconds)) or self.sla_seconds <= 0):
            raise ValueError("sla_seconds must be positive")
        if self.checkpoint_interval is not None and self.checkpoint_interval <= 0:
            raise ValueError("checkpoint_interval must be positive")
        if self.max_retries < 0:
            raise ValueError("max_retries must be non-negative")
        if any((not isinstance(v, (int, float)) or isinstance(v, bool) or not math.isfinite(float(v)) or v < 0) for v in self.budget.values()):
            raise ValueError("budget values must be finite non-negative numbers")

    def deadline_status(self, now: Optional[datetime] = None) -> str:
        if self.deadline is None:
            return "none"
        current = now or datetime.now(timezone.utc)
        if current >= self.deadline:
            return "expired"
        return "active"


@dataclass(frozen=True)
class MissionCheckpoint:
    mission_id: str
    sequence: int
    state_hash: str
    state: Mapping[str, Any]
    created_at: datetime

    @classmethod
    def create(cls, mission_id: str, sequence: int, state: Mapping[str, Any]) -> "MissionCheckpoint":
        if not mission_id or sequence < 0:
            raise ValueError("invalid checkpoint identity")
        canonical=json.dumps(state, sort_keys=True, separators=(",", ":"), default=str).encode()
        return cls(mission_id, sequence, hashlib.sha256(canonical).hexdigest(), dict(state), datetime.now(timezone.utc))

    def verify(self) -> bool:
        canonical=json.dumps(self.state, sort_keys=True, separators=(",", ":"), default=str).encode()
        return hashlib.sha256(canonical).hexdigest() == self.state_hash


@dataclass(frozen=True)
class MissionTemplate:
    template_id: str
    name: str
    goal_template: str
    default_policy: MissionPolicy = field(default_factory=MissionPolicy)
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class MissionBranch:
    branch_id: str
    source_mission_id: str
    source_checkpoint_sequence: int
    created_at: datetime
    metadata: Mapping[str, Any] = field(default_factory=dict)


class MissionFeatureStore:
    """SQLite-backed policy/checkpoint/template/branch/idempotency store."""
    def __init__(self, path: str | Path):
        self.path=Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock=threading.RLock()
        self._db=sqlite3.connect(str(self.path), check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=NORMAL")
        self._db.execute("PRAGMA busy_timeout=30000")
        self._db.executescript("""
        CREATE TABLE IF NOT EXISTS mission_policies (mission_id TEXT PRIMARY KEY, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS checkpoints (mission_id TEXT NOT NULL, sequence INTEGER NOT NULL, data TEXT NOT NULL, PRIMARY KEY(mission_id,sequence));
        CREATE TABLE IF NOT EXISTS templates (template_id TEXT PRIMARY KEY, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS branches (branch_id TEXT PRIMARY KEY, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS idempotency (scope TEXT NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY(scope,key));
        """)
        self._db.commit()

    def set_policy(self, mission_id: str, policy: MissionPolicy) -> MissionPolicy:
        if not mission_id: raise ValueError("mission_id is required")
        with self._lock:
            self._db.execute("INSERT INTO mission_policies VALUES(?,?) ON CONFLICT(mission_id) DO UPDATE SET data=excluded.data", (mission_id, json.dumps(self._policy_data(policy))))
            self._db.commit()
        return policy

    def get_policy(self, mission_id: str) -> MissionPolicy | None:
        with self._lock:
            row=self._db.execute("SELECT data FROM mission_policies WHERE mission_id=?",(mission_id,)).fetchone()
        return None if row is None else self._policy_from(json.loads(row[0]))

    def save_checkpoint(self, checkpoint: MissionCheckpoint) -> MissionCheckpoint:
        if not checkpoint.verify(): raise ValueError("checkpoint integrity verification failed")
        with self._lock:
            self._db.execute("INSERT INTO checkpoints VALUES(?,?,?) ON CONFLICT(mission_id,sequence) DO UPDATE SET data=excluded.data", (checkpoint.mission_id, checkpoint.sequence, json.dumps(self._checkpoint_data(checkpoint))))
            self._db.commit()
        return checkpoint

    def latest_checkpoint(self, mission_id: str) -> MissionCheckpoint | None:
        with self._lock:
            row=self._db.execute("SELECT data FROM checkpoints WHERE mission_id=? ORDER BY sequence DESC LIMIT 1",(mission_id,)).fetchone()
        return None if row is None else self._checkpoint_from(json.loads(row[0]))

    def register_template(self, template: MissionTemplate) -> MissionTemplate:
        with self._lock:
            self._db.execute("INSERT INTO templates VALUES(?,?) ON CONFLICT(template_id) DO UPDATE SET data=excluded.data",(template.template_id,json.dumps(self._template_data(template))))
            self._db.commit()
        return template

    def template(self, template_id: str) -> MissionTemplate | None:
        with self._lock:
            row=self._db.execute("SELECT data FROM templates WHERE template_id=?",(template_id,)).fetchone()
        return None if row is None else self._template_from(json.loads(row[0]))

    def branch(self, source_mission_id: str, checkpoint: MissionCheckpoint, metadata: Mapping[str,Any]|None=None) -> MissionBranch:
        if checkpoint.mission_id != source_mission_id: raise ValueError("checkpoint does not belong to source mission")
        branch=MissionBranch(secrets.token_hex(12), source_mission_id, checkpoint.sequence, datetime.now(timezone.utc), dict(metadata or {}))
        with self._lock:
            self._db.execute("INSERT INTO branches VALUES(?,?)",(branch.branch_id,json.dumps(asdict(branch),default=str)))
            self._db.commit()
        return branch

    def claim_idempotency(self, scope: str, key: str, value: str) -> tuple[bool,str]:
        if not scope or not key: raise ValueError("scope and key are required")
        with self._lock:
            try:
                self._db.execute("INSERT INTO idempotency VALUES(?,?,?,?)",(scope,key,value,datetime.now(timezone.utc).isoformat()))
                self._db.commit()
                return True,value
            except sqlite3.IntegrityError:
                row=self._db.execute("SELECT value FROM idempotency WHERE scope=? AND key=?",(scope,key)).fetchone()
                return False,str(row[0])

    @staticmethod
    def _policy_data(p: MissionPolicy)->dict[str,Any]:
        d=asdict(p); d["deadline"]=p.deadline.isoformat() if p.deadline else None; d["mode"]=p.mode.value; d["device_affinity"]=list(p.device_affinity); return d
    @staticmethod
    def _policy_from(d):
        d=dict(d); d["deadline"]=datetime.fromisoformat(d["deadline"]) if d.get("deadline") else None; d["mode"]=MissionMode(d.get("mode","normal")); d["device_affinity"]=tuple(d.get("device_affinity",())) ; return MissionPolicy(**d)
    @staticmethod
    def _checkpoint_data(c):
        return {"mission_id":c.mission_id,"sequence":c.sequence,"state_hash":c.state_hash,"state":dict(c.state),"created_at":c.created_at.isoformat()}
    @staticmethod
    def _checkpoint_from(d):
        return MissionCheckpoint(d["mission_id"],int(d["sequence"]),d["state_hash"],dict(d["state"]),datetime.fromisoformat(d["created_at"]))
    @staticmethod
    def _template_data(t):
        return {"template_id":t.template_id,"name":t.name,"goal_template":t.goal_template,"default_policy":MissionFeatureStore._policy_data(t.default_policy),"metadata":dict(t.metadata)}
    @staticmethod
    def _template_from(d):
        return MissionTemplate(d["template_id"],d["name"],d["goal_template"],MissionFeatureStore._policy_from(d["default_policy"]),dict(d.get("metadata",{})))


def render_template(template: MissionTemplate, variables: Mapping[str, Any]) -> str:
    try:
        return template.goal_template.format_map(dict(variables))
    except KeyError as exc:
        raise ValueError(f"missing template variable: {exc.args[0]}") from exc


def deterministic_simulation(goal: str, *, steps: int = 1) -> dict[str, Any]:
    if not goal or steps < 0: raise ValueError("goal and non-negative steps are required")
    digest=hashlib.sha256(goal.encode()).hexdigest()
    return {"mode":"simulation","goal":goal,"steps":steps,"deterministic_seed":digest[:16],"would_execute":False,"effects":[]}
