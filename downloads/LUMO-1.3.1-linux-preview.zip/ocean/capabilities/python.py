from __future__ import annotations

from typing import Any
import ast

from ocean.domain.capability import (
    CapabilityExecutionPolicy,
    CapabilityIsolationPolicy,
    CapabilitySpec,
    OperationSpec,
)
from ocean.domain.enums import RiskLevel
from ocean.domain.resource import ResourceRequirement
from runtime.executor import CapabilityExecutor
from runtime.types import ExecutionRequest, ExecutionResult


def python_spec() -> CapabilitySpec:
    return CapabilitySpec(
        name="python",
        description="Execute a bounded Python expression in an isolated worker.",
        operations={
            "execute": OperationSpec(
                name="execute",
                description="Run code with a JSON-compatible result variable.",
                input_schema={"code": "string (required)", "inputs": "dict"},
                output_schema={"result": "any"},
                risk_level=RiskLevel.HIGH,
                resource_requirements=[ResourceRequirement(kind="process", amount=1.0)],
            )
        },
        execution_strategy="python_isolated",
        execution_policy=CapabilityExecutionPolicy(
            CapabilityIsolationPolicy.PROCESS_ISOLATED_REQUIRED
        ),
        requires_permissions={"python.execute"},
    )


class PythonExecutor(CapabilityExecutor):
    """Execute a deliberately tiny, side-effect-free Python subset.

    This capability is process-isolated by the canonical runtime, but process
    isolation alone is not a language sandbox.  Never feed arbitrary Python to
    ``exec``: Python object introspection can escape an empty ``__builtins__``
    namespace.  We therefore validate the AST and only permit expressions and
    assignments needed for data transformation.
    """

    _ALLOWED_NODES = (
        ast.Module, ast.Assign, ast.Name, ast.Load, ast.Store,
        ast.Constant, ast.List, ast.Tuple, ast.Dict, ast.Set,
        ast.Subscript, ast.Slice, ast.BinOp, ast.UnaryOp, ast.BoolOp,
        ast.Compare, ast.IfExp, ast.Add, ast.Sub, ast.Mult, ast.Div,
        ast.FloorDiv, ast.Mod, ast.Pow, ast.UAdd, ast.USub, ast.Not,
        ast.And, ast.Or, ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE,
    )

    @classmethod
    def _validate(cls, code: str) -> ast.Module:
        if not isinstance(code, str) or not code.strip():
            raise ValueError("code must be a non-empty string")
        if len(code) > 20_000:
            raise ValueError("code exceeds the 20000-character safety limit")
        tree = ast.parse(code, mode="exec")
        if len(tree.body) > 100:
            raise ValueError("code contains too many statements")
        for node in ast.walk(tree):
            if not isinstance(node, cls._ALLOWED_NODES):
                raise ValueError(f"unsupported Python syntax: {type(node).__name__}")
            if isinstance(node, ast.Name) and node.id not in {"inputs", "result"}:
                raise ValueError(f"unknown variable: {node.id}")
            if isinstance(node, ast.Assign):
                if len(node.targets) != 1 or not isinstance(node.targets[0], ast.Name) or node.targets[0].id != "result":
                    raise ValueError("only assignment to result is permitted")
            if isinstance(node, ast.Constant) and not isinstance(node.value, (str, int, float, bool, type(None))):
                raise ValueError("unsupported constant type")
        return tree

    def execute(self, request: ExecutionRequest, context: Any) -> ExecutionResult:
        try:
            tree = self._validate(request.arguments.get("code"))
            namespace = {"inputs": dict(request.arguments.get("inputs") or {})}
            # Validation forbids calls, attributes, imports, comprehensions,
            # lambdas and every other route to host-side effects.
            code = compile(tree, "<lumo-python>", "exec")
            exec(code, {"__builtins__": {}}, namespace)
            return ExecutionResult.succeeded({"result": namespace.get("result")})
        except Exception as exc:
            return ExecutionResult.failed(
                str(exc),
                metadata={"failure_type": "capability_failure", "exception_type": type(exc).__name__},
            )
