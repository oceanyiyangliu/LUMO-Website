from __future__ import annotations

import ctypes
import os
import subprocess
import tempfile
import time
import threading
from pathlib import Path
from typing import Any, Mapping

from ocean.domain.capability import (
    CapabilityExecutionPolicy,
    CapabilityIsolationPolicy,
    CapabilitySpec,
    OperationSpec,
)
from ocean.domain.enums import RiskLevel
from ocean.domain.resource import ResourceRequirement
from runtime.executor import CapabilityExecutor
from runtime.types import ExecutionRequest, ExecutionResult


_KEY_CODES = {
    "return": 36, "enter": 36, "tab": 48, "space": 49,
    "delete": 51, "escape": 53, "esc": 53,
    "command": 55, "shift": 56, "capslock": 57,
    "option": 58, "control": 59, "ctrl": 59,
    "right": 124, "left": 123, "down": 125, "up": 126,
    "home": 115, "end": 119, "pageup": 116, "pagedown": 121,
    "f1": 122, "f2": 120, "f3": 99, "f4": 118, "f5": 96,
    "f6": 97, "f7": 98, "f8": 100, "f9": 101, "f10": 109,
    "f11": 103, "f12": 111,
}


def computer_spec() -> CapabilitySpec:
    """Governed macOS computer-use capability.

    This is deliberately a primitive computer-control plane: higher layers
    decide *what* work to do while this capability performs bounded GUI
    actions and captures evidence. It is suitable for browser applications
    such as Canva and for other accessible macOS applications.
    """
    common = {"timeout": "number (seconds)"}
    return CapabilitySpec(
        name="computer",
        description="Operate the local macOS GUI and capture visual evidence.",
        requires_permissions={"computer.use"},
        execution_strategy="computer_macos",
        execution_policy=CapabilityExecutionPolicy(
            CapabilityIsolationPolicy.PROCESS_ISOLATED_REQUIRED
        ),
        operations={
            "screenshot": OperationSpec(
                name="screenshot",
                description="Capture the current macOS screen to a temporary PNG.",
                input_schema={**common, "path": "string | null"},
                output_schema={"path": "string", "width": "integer", "height": "integer"},
                risk_level=RiskLevel.LOW,
                resource_requirements=[ResourceRequirement(kind="computer", amount=1.0)],
            ),
            "open_url": OperationSpec(
                name="open_url",
                description="Open a URL in the default macOS browser.",
                input_schema={"url": "string (required)", **common},
                output_schema={"url": "string"},
                risk_level=RiskLevel.HIGH,
                resource_requirements=[ResourceRequirement(kind="computer", amount=1.0)],
            ),
            "launch_app": OperationSpec(
                name="launch_app",
                description="Launch a macOS application by name.",
                input_schema={"app": "string (required)", **common},
                output_schema={"app": "string"},
                risk_level=RiskLevel.HIGH,
                resource_requirements=[ResourceRequirement(kind="computer", amount=1.0)],
            ),
            "double_click": OperationSpec(
                name="double_click",
                description="Double-click a screen coordinate.",
                input_schema={"x": "number (required)", "y": "number (required)", **common},
                output_schema={"x": "number", "y": "number"},
                risk_level=RiskLevel.HIGH,
                resource_requirements=[ResourceRequirement(kind="computer", amount=1.0)],
            ),
            "drag": OperationSpec(
                name="drag",
                description="Drag through a bounded sequence of screen coordinates.",
                input_schema={"path": "array<{x:number,y:number}> (required)", **common},
                output_schema={"points": "integer"},
                risk_level=RiskLevel.HIGH,
                resource_requirements=[ResourceRequirement(kind="computer", amount=1.0)],
            ),
            "move": OperationSpec(
                name="move",
                description="Move the mouse to a screen coordinate.",
                input_schema={"x": "number (required)", "y": "number (required)", **common},
                output_schema={"x": "number", "y": "number"},
                risk_level=RiskLevel.HIGH,
                resource_requirements=[ResourceRequirement(kind="computer", amount=1.0)],
            ),
            "click": OperationSpec(
                name="click",
                description="Click a screen coordinate.",
                input_schema={"x": "number (required)", "y": "number (required)", **common},
                output_schema={"x": "number", "y": "number"},
                risk_level=RiskLevel.HIGH,
                resource_requirements=[ResourceRequirement(kind="computer", amount=1.0)],
            ),
            "accessibility_snapshot": OperationSpec(
                name="accessibility_snapshot",
                description="Inspect the frontmost application accessibility tree using stable roles, titles, descriptions, and values.",
                input_schema={"max_elements": "integer", **common},
                output_schema={"application": "string", "window": "string", "elements": "array"},
                risk_level=RiskLevel.LOW,
                resource_requirements=[ResourceRequirement(kind="computer", amount=1.0)],
            ),
            "click_element": OperationSpec(
                name="click_element",
                description="Click a uniquely identified accessible UI element by role and title/description/value instead of screen coordinates.",
                input_schema={"role": "string (required)", "title": "string", "description": "string", "value": "string", **common},
                output_schema={"role": "string", "title": "string", "description": "string"},
                risk_level=RiskLevel.HIGH,
                resource_requirements=[ResourceRequirement(kind="computer", amount=1.0)],
            ),
            "type_text": OperationSpec(
                name="type_text",
                description="Paste text into the focused application using the macOS clipboard.",
                input_schema={"text": "string (required)", **common},
                output_schema={"length": "integer"},
                risk_level=RiskLevel.HIGH,
                resource_requirements=[ResourceRequirement(kind="computer", amount=1.0)],
            ),
            "key_press": OperationSpec(
                name="key_press",
                description="Press one named macOS key.",
                input_schema={"key": "string (required)", **common},
                output_schema={"key": "string"},
                risk_level=RiskLevel.HIGH,
                resource_requirements=[ResourceRequirement(kind="computer", amount=1.0)],
            ),
            "hotkey": OperationSpec(
                name="hotkey",
                description="Press a sequence of modifier/key names together.",
                input_schema={"keys": "array<string> (required)", **common},
                output_schema={"keys": "array<string>"},
                risk_level=RiskLevel.HIGH,
                resource_requirements=[ResourceRequirement(kind="computer", amount=1.0)],
            ),
            "scroll": OperationSpec(
                name="scroll",
                description="Scroll vertically in the focused macOS application.",
                input_schema={"amount": "integer (required)", **common},
                output_schema={"amount": "integer"},
                risk_level=RiskLevel.HIGH,
                resource_requirements=[ResourceRequirement(kind="computer", amount=1.0)],
            ),
            "wait": OperationSpec(
                name="wait",
                description="Wait for a bounded interval so a GUI application can settle.",
                input_schema={"seconds": "number (required)"},
                output_schema={"seconds": "number"},
                risk_level=RiskLevel.LOW,
                resource_requirements=[ResourceRequirement(kind="computer", amount=1.0)],
            ),
        },
    )


class MacOSComputerExecutor(CapabilityExecutor):
    """Small deterministic macOS GUI adapter with exclusive, user-safe control."""

    _desktop_lock = threading.RLock()

    def __init__(self) -> None:
        self._last_lumo_input_at = 0.0
        self._last_lumo_cursor: tuple[float, float] | None = None
        self._last_observed_input_age = self._input_age()

    @staticmethod
    def _core_graphics():
        # Build the framework path at runtime. Keeping the absolute framework
        # path out of a ctypes.CDLL literal prevents PyInstaller from treating
        # CoreGraphics as a bundled binary dependency; macOS owns this framework.
        framework = os.path.join(
            "/System/Library/Frameworks",
            "CoreGraphics.framework",
            "CoreGraphics",
        )
        return ctypes.CDLL(framework)

    @classmethod
    def _input_age(cls) -> float | None:
        try:
            cg = cls._core_graphics()
            fn = cg.CGEventSourceSecondsSinceLastEventType
            fn.argtypes = [ctypes.c_int, ctypes.c_uint32]
            fn.restype = ctypes.c_double
            return float(fn(0, 0xFFFFFFFF))
        except (AttributeError, OSError):
            return None

    def _guard_user_control(self, *, timeout: float) -> None:
        """Pause automation when the user appears to be actively controlling the Mac."""
        if os.getenv("LUMO_ALLOW_USER_INTERFERENCE", "0") == "1":
            return
        # CoreGraphics exposes a session-wide last-input clock. Treat a fresh
        # transition to user input as takeover. The baseline captured at executor
        # creation prevents unrelated keystrokes that happened immediately before
        # a deterministic/test operation from being misclassified as takeover.
        seconds = self._input_age()
        previous = self._last_observed_input_age
        self._last_observed_input_age = seconds
        if (
            seconds is not None
            and previous is not None
            and seconds < 0.12
            and previous >= 0.12
            and (time.monotonic() - self._last_lumo_input_at) > 0.20
        ):
            raise RuntimeError("user input detected; LUMO paused computer control for user takeover")

    def _mark_lumo_input(self) -> None:
        self._last_lumo_input_at = time.monotonic()

    def _run(self, args: list[str], *, timeout: float) -> tuple[str, str]:
        try:
            completed = subprocess.run(
                args,
                check=False,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"computer operation timed out after {timeout} seconds")
        if completed.returncode != 0:
            detail = (completed.stderr or completed.stdout or "").strip()
            raise RuntimeError(detail or f"command exited with {completed.returncode}")
        return completed.stdout, completed.stderr

    @staticmethod
    def _timeout(arguments: Mapping[str, Any], default: float = 15.0) -> float:
        value = arguments.get("timeout", default)
        try:
            value = float(value)
        except (TypeError, ValueError):
            raise ValueError("timeout must be a number")
        if value <= 0 or value > 120:
            raise ValueError("timeout must be greater than 0 and at most 120 seconds")
        return value

    @staticmethod
    def _osascript(script: str) -> list[str]:
        return ["/usr/bin/osascript", "-e", script]

    @staticmethod
    def _apple_escape(value: str) -> str:
        return value.replace("\\", "\\\\").replace('"', '\\"')

    def _frontmost_window_bounds(self, *, timeout: float) -> tuple[int, int, int, int] | None:
        script = 'tell application "System Events" to tell (first process whose frontmost is true) to get {position, size} of front window'
        try:
            stdout, _ = self._run(self._osascript(script), timeout=min(timeout, 5.0))
            values = [int(v.strip()) for v in stdout.strip().split(",")]
            if len(values) != 4 or values[2] <= 0 or values[3] <= 0:
                return None
            return values[0], values[1], values[2], values[3]
        except Exception:
            return None

    def _frontmost_context(self, *, timeout: float) -> dict[str, str]:
        script = 'tell application "System Events" to tell (first process whose frontmost is true) to get {name, name of front window}'
        try:
            stdout, _ = self._run(self._osascript(script), timeout=min(timeout, 5.0))
            parts = [part.strip() for part in stdout.strip().split(",", 1)]
            return {"application": parts[0] if parts else "", "window": parts[1] if len(parts) > 1 else ""}
        except Exception:
            return {"application": "", "window": ""}

    @staticmethod
    def _core_graphics_mouse(operation: str, x: float, y: float, *, timeout: float) -> None:
        class CGPoint(ctypes.Structure):
            _fields_ = [("x", ctypes.c_double), ("y", ctypes.c_double)]
        cg = MacOSComputerExecutor._core_graphics()
        cg.CGEventCreateMouseEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint32, CGPoint, ctypes.c_uint32]
        cg.CGEventCreateMouseEvent.restype = ctypes.c_void_p
        cg.CGEventPost.argtypes = [ctypes.c_uint32, ctypes.c_void_p]
        cg.CGEventPost.restype = None
        cg.CGEventSetIntegerValueField.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_longlong]
        cg.CGEventSetIntegerValueField.restype = None
        point = CGPoint(x, y)
        tap = 0
        mouse_button = 0
        cg.CGEventPost(tap, cg.CGEventCreateMouseEvent(None, 5, point, mouse_button))
        if operation in ("click", "double_click"):
            count = 2 if operation == "double_click" else 1
            for index in range(count):
                down = cg.CGEventCreateMouseEvent(None, 1, point, mouse_button)
                up = cg.CGEventCreateMouseEvent(None, 2, point, mouse_button)
                if operation == "double_click":
                    cg.CGEventSetIntegerValueField(down, 1, 2 if index == 1 else 1)
                    cg.CGEventSetIntegerValueField(up, 1, 2 if index == 1 else 1)
                cg.CGEventPost(tap, down)
                cg.CGEventPost(tap, up)
                time.sleep(0.08)

    @staticmethod
    def _core_graphics_drag(points: list[tuple[float, float]], *, timeout: float) -> None:
        class CGPoint(ctypes.Structure):
            _fields_ = [("x", ctypes.c_double), ("y", ctypes.c_double)]
        cg = MacOSComputerExecutor._core_graphics()
        cg.CGEventCreateMouseEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint32, CGPoint, ctypes.c_uint32]
        cg.CGEventCreateMouseEvent.restype = ctypes.c_void_p
        cg.CGEventPost.argtypes = [ctypes.c_uint32, ctypes.c_void_p]
        cg.CGEventPost.restype = None
        tap = 0
        button = 0
        first = CGPoint(*points[0])
        cg.CGEventPost(tap, cg.CGEventCreateMouseEvent(None, 5, first, button))
        cg.CGEventPost(tap, cg.CGEventCreateMouseEvent(None, 1, first, button))
        for x, y in points[1:]:
            point = CGPoint(x, y)
            cg.CGEventPost(tap, cg.CGEventCreateMouseEvent(None, 6, point, button))
            time.sleep(0.02)
        last = CGPoint(*points[-1])
        cg.CGEventPost(tap, cg.CGEventCreateMouseEvent(None, 2, last, button))

    def _accessibility_snapshot(self, *, max_elements: int, timeout: float) -> dict[str, Any]:
        """Return a bounded accessibility tree for the frontmost app.

        This uses macOS System Events rather than coordinates, so the returned
        identities survive window movement and most layout changes.
        """
        max_elements = max(1, min(500, int(max_elements)))
        script = f'''tell application "System Events"
set p to first process whose frontmost is true
set w to front window of p
set output to ""
set n to 0
repeat with e in entire contents of w
    if n >= {max_elements} then exit repeat
    try
        set r to role of e as text
        set t to title of e as text
        set d to description of e as text
        set v to value of e as text
        if t is "missing value" then set t to ""
        if d is "missing value" then set d to ""
        if v is "missing value" then set v to ""
        set output to output & r & tab & t & tab & d & tab & v & linefeed
        set n to n + 1
    end try
end repeat
return (name of p as text) & linefeed & (name of w as text) & linefeed & output
end tell'''
        stdout, _ = self._run(self._osascript(script), timeout=min(timeout, 10.0))
        lines = stdout.splitlines()
        application = lines[0].strip() if lines else ""
        window = lines[1].strip() if len(lines) > 1 else ""
        elements = []
        for index, line in enumerate(lines[2:max_elements + 2]):
            parts = line.split("\\t", 3)
            while len(parts) < 4:
                parts.append("")
            elements.append({"index": index, "role": parts[0], "title": parts[1], "description": parts[2], "value": parts[3]})
        return {"application": application, "window": window, "elements": elements}

    def _click_element(self, args: Mapping[str, Any], *, timeout: float) -> dict[str, str]:
        role = str(args.get("role", "")).strip()
        title = str(args.get("title", "")).strip()
        description = str(args.get("description", "")).strip()
        value = str(args.get("value", "")).strip()
        if not role:
            raise ValueError("role is required")
        if not any((title, description, value)):
            raise ValueError("at least one of title, description, or value is required")
        role_q, title_q, desc_q, value_q = [self._apple_escape(x) for x in (role, title, description, value)]
        script = f'''tell application "System Events"
set p to first process whose frontmost is true
set matches to {{}}
repeat with e in entire contents of front window of p
    try
        if (role of e as text) is "{role_q}" then
            set ok to true
            if "{title_q}" is not "" and (title of e as text) is not "{title_q}" then set ok to false
            if "{desc_q}" is not "" and (description of e as text) is not "{desc_q}" then set ok to false
            if "{value_q}" is not "" and (value of e as text) is not "{value_q}" then set ok to false
            if ok then set end of matches to e
        end if
    end try
end repeat
if (count of matches) is not 1 then error "accessible target matched " & (count of matches) & " elements; refine role/title/description/value"
set target to item 1 of matches
click target
return (role of target as text) & tab & (title of target as text) & tab & (description of target as text)
end tell'''
        stdout, _ = self._run(self._osascript(script), timeout=min(timeout, 10.0))
        parts = stdout.strip().split("\\t", 2)
        while len(parts) < 3:
            parts.append("")
        self._mark_lumo_input()
        return {"role": parts[0], "title": parts[1], "description": parts[2]}

    def execute(self, request: ExecutionRequest, context: Any) -> ExecutionResult:
        args = request.arguments or {}
        timeout = self._timeout(args)
        try:
            operation = request.operation
            with self._desktop_lock:
                if operation not in {"screenshot", "wait"}:
                    self._guard_user_control(timeout=timeout)
                return self._execute_locked(request, context, args, timeout, operation)
        except Exception as exc:
            return ExecutionResult.failed(str(exc), metadata={"failure_type": "computer_capability_failure", "operation": request.operation})

    def _execute_locked(self, request: ExecutionRequest, context: Any, args: Mapping[str, Any], timeout: float, operation: str) -> ExecutionResult:
            if operation == "screenshot":
                # Never invoke macOS's `screencapture` CLI when the signed LUMO
                # host has not preflighted Screen Recording. That CLI is a
                # different TCC client and can trigger a fresh macOS prompt even
                # when the user has already granted LUMO. Fail closed and let the
                # control plane surface the exact permission boundary instead.
                if os.getenv("LUMO_SCREEN_TRUSTED", "") != "1":
                    raise RuntimeError(
                        "Screen Recording is not currently authorized for the signed LUMO host; "
                        "open LUMO Settings → Device permissions and grant access to LUMO. "
                        "LUMO will not invoke the macOS screencapture CLI while this grant is unresolved."
                    )
                requested = args.get("path")
                if requested is None:
                    fd, requested = tempfile.mkstemp(prefix="lumo-screen-", suffix=".png")
                    os.close(fd)
                path = Path(str(requested)).expanduser().resolve()
                path.parent.mkdir(parents=True, exist_ok=True)
                bounds = self._frontmost_window_bounds(timeout=timeout)
                frontmost = self._frontmost_context(timeout=timeout)
                if bounds is None:
                    self._run(["/usr/sbin/screencapture", "-x", str(path)], timeout=timeout)
                else:
                    x, y, width, height = bounds
                    self._run(["/usr/sbin/screencapture", "-x", "-R", f"{x},{y},{width},{height}", str(path)], timeout=timeout)
                if not path.is_file():
                    raise RuntimeError("screenshot command completed without creating the file")
                try:
                    from PIL import Image
                    with Image.open(path) as image:
                        image_width, image_height = image.size
                except Exception:
                    image_width = image_height = 0
                origin_x, origin_y = (0, 0) if bounds is None else (bounds[0], bounds[1])
                capture_width, capture_height = (
                    (image_width, image_height) if bounds is None else (bounds[2], bounds[3])
                )
                return ExecutionResult.succeeded({
                    "path": str(path),
                    "width": image_width,
                    "height": image_height,
                    "origin_x": origin_x,
                    "origin_y": origin_y,
                    "capture_width": capture_width,
                    "capture_height": capture_height,
                    "application": frontmost.get("application", ""),
                    "window": frontmost.get("window", ""),
                })

            if operation == "accessibility_snapshot":
                result = self._accessibility_snapshot(max_elements=args.get("max_elements", 150), timeout=timeout)
                return ExecutionResult.succeeded(result)

            if operation == "click_element":
                result = self._click_element(args, timeout=timeout)
                return ExecutionResult.succeeded(result)

            if operation == "open_url":
                url = args.get("url")
                if not isinstance(url, str) or not url.strip():
                    raise ValueError("url must be a non-empty string")
                # open(1) delegates to the user's configured browser; no shell is involved.
                self._run(["/usr/bin/open", url], timeout=timeout)
                return ExecutionResult.succeeded({"url": url})

            if operation == "launch_app":
                app = args.get("app")
                if not isinstance(app, str) or not app.strip():
                    raise ValueError("app must be a non-empty string")
                self._run(["/usr/bin/open", "-a", app], timeout=timeout)
                return ExecutionResult.succeeded({"app": app})

            if operation in {"click", "double_click", "move"}:
                x, y = float(args["x"]), float(args["y"])
                if x < 0 or y < 0:
                    raise ValueError("x and y must be non-negative")
                self._core_graphics_mouse(operation, x, y, timeout=timeout)
                self._mark_lumo_input()
                return ExecutionResult.succeeded({"x": x, "y": y})

            if operation == "drag":
                path = args.get("path")
                if not isinstance(path, list) or len(path) < 2 or len(path) > 100:
                    raise ValueError("drag path must contain between 2 and 100 points")
                points = []
                for point in path:
                    if not isinstance(point, Mapping):
                        raise ValueError("drag path points must be objects")
                    x, y = float(point["x"]), float(point["y"])
                    if x < 0 or y < 0:
                        raise ValueError("drag coordinates must be non-negative")
                    points.append((x, y))
                self._core_graphics_drag(points, timeout=timeout)
                self._mark_lumo_input()
                return ExecutionResult.succeeded({"points": len(points)})

            if operation == "type_text":
                text = args.get("text")
                if not isinstance(text, str):
                    raise ValueError("text must be a string")
                if len(text) > 100_000:
                    raise ValueError("text exceeds the 100000-character safety limit")
                if not bool(getattr(request, "metadata", {}).get("clipboard_approved", False)):
                    raise PermissionError("clipboard access requires explicit approval")
                # Clipboard + paste is more Unicode-safe than AppleScript keystroke.
                self._run(["/usr/bin/pbcopy"], timeout=timeout) if False else None
                try:
                    proc = subprocess.run(
                        ["/usr/bin/pbcopy"], input=text, text=True,
                        capture_output=True, timeout=timeout, check=False,
                    )
                except subprocess.TimeoutExpired:
                    raise RuntimeError(f"computer operation timed out after {timeout} seconds")
                if proc.returncode != 0:
                    raise RuntimeError((proc.stderr or "pbcopy failed").strip())
                self._run(self._osascript('tell application "System Events" to key code 9 using command down'), timeout=timeout)
                self._mark_lumo_input()
                return ExecutionResult.succeeded({"length": len(text)})

            if operation == "key_press":
                key = str(args.get("key", "")).strip().lower()
                if not key:
                    raise ValueError("key must be a non-empty string")
                if len(key) == 1:
                    script = f'tell application "System Events" to keystroke "{self._apple_escape(key)}"'
                elif key in _KEY_CODES:
                    script = f'tell application "System Events" to key code {_KEY_CODES[key]}'
                else:
                    raise ValueError(f"unsupported key: {key}")
                self._run(self._osascript(script), timeout=timeout)
                self._mark_lumo_input()
                return ExecutionResult.succeeded({"key": key})

            if operation == "hotkey":
                keys = args.get("keys")
                if not isinstance(keys, list) or not keys:
                    raise ValueError("keys must be a non-empty list")
                normalized = [str(k).strip().lower() for k in keys]
                if any(not k for k in normalized):
                    raise ValueError("keys must not contain empty values")
                modifier_names = {"command": "command down", "shift": "shift down", "option": "option down", "control": "control down", "ctrl": "control down"}
                modifiers = [modifier_names[k] for k in normalized[:-1] if k in modifier_names]
                key = normalized[-1]
                if key in modifier_names:
                    raise ValueError("last hotkey item must be a key, not a modifier")
                if len(key) == 1:
                    key_expr = f'keystroke "{self._apple_escape(key)}"'
                elif key in _KEY_CODES:
                    key_expr = f"key code {_KEY_CODES[key]}"
                else:
                    raise ValueError(f"unsupported key: {key}")
                using = " using {" + ", ".join(modifiers) + "}" if modifiers else ""
                script = f'tell application "System Events" to {key_expr}{using}'
                self._run(self._osascript(script), timeout=timeout)
                self._mark_lumo_input()
                return ExecutionResult.succeeded({"keys": normalized})

            if operation == "scroll":
                amount = int(args["amount"])
                if abs(amount) > 100:
                    raise ValueError("scroll amount must be between -100 and 100")
                script = f'tell application "System Events" to scroll {amount}'
                self._run(self._osascript(script), timeout=timeout)
                self._mark_lumo_input()
                return ExecutionResult.succeeded({"amount": amount})

            if operation == "wait":
                seconds = float(args["seconds"])
                if seconds < 0 or seconds > 30:
                    raise ValueError("seconds must be between 0 and 30")
                time.sleep(seconds)
                return ExecutionResult.succeeded({"seconds": seconds})

            return ExecutionResult.failed(f"unsupported computer operation: {operation}")
