from __future__ import annotations

import os
import signal
import subprocess
import threading
import time
from typing import Any

from ocean.domain.capability import CapabilitySpec, OperationSpec
from ocean.domain.enums import RiskLevel
from ocean.domain.resource import ResourceRequirement
from runtime.executor import CapabilityExecutor
from runtime.types import ExecutionRequest, ExecutionResult


def git_spec() -> CapabilitySpec:
    operations = {
        name: OperationSpec(
            name=name,
            description=f"Read-only git {name} information.",
            input_schema={"cwd": "string", "timeout": "number", "max_output_bytes": "integer"},
            output_schema={"stdout": "string", "stderr": "string", "exit_code": "integer"},
            risk_level=RiskLevel.LOW,
            resource_requirements=[ResourceRequirement(kind="process", amount=1.0)],
        )
        for name in ("status", "diff", "branch", "inspect")
    }
    return CapabilitySpec(
        name="git",
        description="Inspect repository state through bounded read-only git operations.",
        operations=operations,
        execution_strategy="git_local",
        requires_permissions={"git.read"},
    )


class GitExecutor(CapabilityExecutor):
    _COMMANDS = {
        "status": ("status", "--short"),
        "diff": ("diff",),
        "branch": ("branch", "--list"),
        "inspect": ("log", "-1", "--oneline"),
    }

    def execute(self, request: ExecutionRequest, context: Any) -> ExecutionResult:
        command = self._COMMANDS.get(request.operation)
        if command is None:
            return ExecutionResult.failed("unsupported git operation")
        args = request.arguments
        try:
            timeout = float(args.get("timeout", 30.0))
        except (TypeError, ValueError):
            return ExecutionResult.failed("timeout must be a number")
        if timeout <= 0 or timeout > 120:
            return ExecutionResult.failed("timeout must be greater than 0 and at most 120 seconds")
        try:
            limit = int(args.get("max_output_bytes", 1_000_000))
        except (TypeError, ValueError):
            return ExecutionResult.failed("max_output_bytes must be an integer")
        if limit <= 0:
            return ExecutionResult.failed("max_output_bytes must be positive")

        try:
            process = subprocess.Popen(
                ("git", *command), cwd=args.get("cwd"),
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.DEVNULL,
                text=False, close_fds=True, start_new_session=(os.name == "posix"),
            )
            out, err = process.communicate(timeout=timeout)
            stdout = out[:limit].decode("utf-8", errors="replace")
            stderr = err[:limit].decode("utf-8", errors="replace")
            truncated = len(out) > limit or len(err) > limit
            return ExecutionResult(
                success=process.returncode == 0,
                result={"stdout": stdout, "stderr": stderr, "exit_code": process.returncode},
                error=None if process.returncode == 0 else stderr or "git command failed",
                metadata={"output_truncated": truncated, "max_output_bytes": limit},
            )
        except subprocess.TimeoutExpired:
            try:
                if os.name == "posix" and process.pid:
                    os.killpg(process.pid, signal.SIGKILL)
                else:
                    process.kill()
            except Exception:
                pass
            try:
                process.communicate(timeout=1)
            except Exception:
                pass
            return ExecutionResult.failed("git command timed out", metadata={"failure_type": "timeout"})
        except Exception as exc:
            return ExecutionResult.failed(str(exc), metadata={"failure_type": "capability_failure"})