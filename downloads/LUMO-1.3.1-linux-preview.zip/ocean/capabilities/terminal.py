from __future__ import annotations

import os
import queue
import shlex
import subprocess
import threading
import time
from typing import Any, Dict, Optional, Sequence, Tuple

from ocean.domain.capability import (
    CapabilityExecutionPolicy,
    CapabilityIsolationPolicy,
    CapabilitySpec,
    OperationSpec,
)
from ocean.domain.enums import RiskLevel
from ocean.domain.resource import ResourceRequirement

from runtime.executor import CapabilityExecutor
from runtime.types import ExecutionRequest, ExecutionResult


def terminal_spec() -> CapabilitySpec:
    """Capability specification for short-lived terminal / process operations.

    Operations:
      - run: run a command (string or list) with resource limits
      - execute: alias of run (convenience)

    Input schema highlights the resource limits the runtime should enforce
    or validate:
      - command: string | list[string] (required)
      - cwd: optional working directory
      - env: optional mapping of env vars
      - timeout: optional number (seconds)
      - max_output_bytes: optional int - truncate stdout/stderr to this many bytes
      - cancellable: optional bool - if True the runtime may attempt cooperative cancellation
      - shell: optional bool - whether to run via shell
    """

    op_input_schema = {
        "command": "string | list[string]",
        "cwd": "string | null",
        "env": "dict<string,string> | null",
        "timeout": "number (seconds) | null",
        "max_output_bytes": "integer | null",
        "cancellable": "boolean | null",
        "shell": "boolean | null",
    }

    operations = {
        "run": OperationSpec(
            name="run",
            description="Run a command with bounded resources (timeout, max_output_bytes, cancellable)",
            input_schema=op_input_schema,
            output_schema={
                "stdout": "string",
                "stderr": "string",
                "exit_code": "integer",
            },
            risk_level=RiskLevel.IMPORTANT,
            resource_requirements=[ResourceRequirement(kind="process", amount=1.0)],
        ),
        "execute": OperationSpec(
            name="execute",
            description="Alias for run; execute a command with resource limits",
            input_schema=op_input_schema,
            output_schema={
                "stdout": "string",
                "stderr": "string",
                "exit_code": "integer",
            },
            risk_level=RiskLevel.IMPORTANT,
            resource_requirements=[ResourceRequirement(kind="process", amount=1.0)],
        ),
    }

    return CapabilitySpec(
        name="terminal",
        description="Execute short-lived processes in a governed, resource-limited way",
        operations=operations,
        execution_strategy="deterministic_local",
        execution_policy=CapabilityExecutionPolicy(
            CapabilityIsolationPolicy.PROCESS_ISOLATED_REQUIRED
        ),
        requires_permissions={"terminal.execute"},
    )


class TerminalExecutor(CapabilityExecutor):
    """Executor that runs local processes and enforces simple resource limits.

    Notes on cancellation:
      - Cooperative cancellation is supported: if the ExecutionContext passed
        in exposes either a callable attribute `should_cancel()` or a boolean
        attribute `cancelled` we will check it while waiting and kill the
        subprocess if cancellation is requested.
      - This executor purposefully returns the captured stdout/stderr (both
        truncated to max_output_bytes if provided) rather than streaming any
        output directly. This keeps callers deterministic and limits exposure
        in test/runtime contexts.
    """

    def _normalize_command(self, command: Any, shell: bool) -> Tuple[Sequence[str] | str, bool]:
        # Accept either a string or a sequence. If a string and shell=True,
        # pass it through as-is for Popen(shell=True). If a string and
        # shell=False, shell-split it so Popen receives a sequence.
        if isinstance(command, (list, tuple)):
            return list(command), False

        if not isinstance(command, str):
            # Defensive cast for poorly-formed input; try to coerce.
            command = str(command)

        if shell:
            return command, True

        # split respecting shell quoting
        return shlex.split(command), False

    def _check_cancelled(self, context: Any) -> bool:
        if context is None:
            return False

        # Prefer a callable should_cancel() if present
        should = getattr(context, "should_cancel", None)
        if callable(should):
            try:
                return bool(should())
            except Exception:
                # Cancellation is authoritative control-plane state. If the
                # cancellation probe itself fails, fail closed so an execution
                # cannot continue merely because its safety signal is broken.
                return True

        # Canonical runtime context exposes cancellation as a token. Read it
        # directly so a capability cannot accidentally ignore an authoritative
        # control-plane cancellation merely because it lacks a legacy helper.
        token = getattr(context, "cancellation", None)
        if token is not None:
            state = getattr(token, "is_cancelled", None)
            if isinstance(state, bool):
                return state

        # Fallback to boolean attribute for older executor contexts.
        cancelled = getattr(context, "cancelled", None)
        if isinstance(cancelled, bool):
            return cancelled

        return False

    def execute(self, request: ExecutionRequest, context: Any) -> ExecutionResult:
        args: Dict[str, Any] = getattr(request, "arguments", {}) or {}

        cmd = args.get("command")
        if cmd is None:
            return ExecutionResult(success=False, result={}, error="missing required argument: command")

        shell = bool(args.get("shell", False))
        if shell and not bool(getattr(request, "metadata", {}).get("shell_approved", False)):
            return ExecutionResult(success=False, result={}, error="shell execution requires explicit approval")
        cwd = args.get("cwd")
        env = args.get("env")
        timeout = args.get("timeout")
        requested_output = args.get("max_output_bytes")
        # A terminal capability must never accumulate unbounded pipe output.
        # The request may lower this cap, but omitting it still gets a bounded
        # safety default; the runtime's own resource limit remains authoritative.
        if requested_output is None:
            max_output = 1024 * 1024
        else:
            try:
                max_output = int(requested_output)
            except (TypeError, ValueError):
                return ExecutionResult(success=False, result={}, error="max_output_bytes must be an integer")
            if max_output <= 0:
                return ExecutionResult(success=False, result={}, error="max_output_bytes must be positive")
        proc_cmd, use_shell = self._normalize_command(cmd, shell)

        try:
            popen_kwargs = {
                "cwd": cwd, "env": env, "shell": use_shell,
                "stdout": subprocess.PIPE, "stderr": subprocess.PIPE,
                "stdin": subprocess.DEVNULL,
                "close_fds": True,
            }
            # On POSIX give the command its own session so a direct executor
            # cancellation can terminate the whole command tree. The governed
            # process-isolation layer additionally kills descendants itself.
            if hasattr(os, "setsid"):
                popen_kwargs["start_new_session"] = True
            popen = subprocess.Popen(proc_cmd, **popen_kwargs)
        except Exception as exc:
            return ExecutionResult(success=False, result={}, error=f"failed to spawn process: {exc}")

        chunks: queue.Queue[tuple[str, bytes | None]] = queue.Queue()
        def drain(name: str, stream) -> None:
            try:
                while True:
                    chunk = stream.read(65536)
                    if not chunk:
                        break
                    chunks.put((name, chunk))
            finally:
                chunks.put((name, None))

        readers = [
            threading.Thread(target=drain, args=("stdout", popen.stdout), daemon=True),
            threading.Thread(target=drain, args=("stderr", popen.stderr), daemon=True),
        ]
        for reader in readers:
            reader.start()

        start = time.monotonic()
        buffers = {"stdout": bytearray(), "stderr": bytearray()}
        totals = {"stdout": 0, "stderr": 0}
        truncated = {"stdout": False, "stderr": False}
        closed = {"stdout": False, "stderr": False}

        def collect(stream_name: str, data: bytes) -> bool:
            totals[stream_name] += len(data)
            captured_total = len(buffers["stdout"]) + len(buffers["stderr"])
            remaining = max_output - captured_total
            if remaining > 0:
                buffers[stream_name].extend(data[:remaining])
            if len(data) > max(remaining, 0):
                truncated[stream_name] = True
            return totals["stdout"] + totals["stderr"] > max_output

        def terminate() -> None:
            # The process is its own session on POSIX. Kill the entire process
            # group so cancellation/output-limit/timeout cannot leave children
            # executing after the parent is gone.
            if hasattr(os, "killpg") and popen.pid is not None:
                try:
                    os.killpg(popen.pid, 9)
                except ProcessLookupError:
                    pass
                except PermissionError:
                    try:
                        popen.kill()
                    except Exception:
                        pass
                except Exception:
                    try:
                        popen.kill()
                    except Exception:
                        pass
            else:
                try:
                    popen.kill()
                except Exception:
                    pass
            try:
                popen.wait(timeout=1.0)
            except Exception:
                pass

        error: str | None = None
        try:
            while not all(closed.values()):
                try:
                    name, data = chunks.get(timeout=0.05)
                    if data is None:
                        closed[name] = True
                    else:
                        exceeded = collect(name, data)
                        if exceeded:
                            terminate()
                            error = f"max_output_bytes exceeded ({max_output})"
                            break
                except queue.Empty:
                    pass

                if self._check_cancelled(context):
                    terminate()
                    error = "cancelled"
                    break

                if timeout is not None:
                    try:
                        timeout_value = float(timeout)
                    except (TypeError, ValueError):
                        terminate()
                        error = "timeout must be a number"
                        break
                    if timeout_value <= 0:
                        terminate()
                        error = f"timeout after {timeout} seconds"
                        break
                    if time.monotonic() - start >= timeout_value:
                        terminate()
                        error = f"timeout after {timeout} seconds"
                        break

            if error is None:
                popen.wait(timeout=1.0)
        except Exception as exc:
            terminate()
            error = f"execution failed: {exc}"
        finally:
            if popen.poll() is None:
                terminate()
            for reader in readers:
                reader.join(timeout=1.0)
            for stream in (popen.stdout, popen.stderr):
                try:
                    if stream is not None:
                        stream.close()
                except Exception:
                    pass

        def decode(data: bytearray) -> str:
            return bytes(data).decode("utf-8", errors="replace")

        stdout = decode(buffers["stdout"])
        stderr = decode(buffers["stderr"])
        if error is None and popen.returncode != 0:
            error = stderr or f"command exited with {popen.returncode}"
        if error is not None:
            metadata = {
                "output_bytes": totals["stdout"] + totals["stderr"],
                "output_truncated": truncated["stdout"] or truncated["stderr"],
                "max_output_bytes": max_output,
            }
            return ExecutionResult(success=False, result={"stdout": stdout, "stderr": stderr, "exit_code": popen.returncode}, error=error, metadata=metadata)

        result_payload: Dict[str, Any] = {"stdout": stdout, "stderr": stderr, "exit_code": popen.returncode}
        return ExecutionResult(
            success=True, result=result_payload,
            metadata={
                "output_bytes": totals["stdout"] + totals["stderr"],
                "output_truncated": truncated["stdout"] or truncated["stderr"],
                "max_output_bytes": max_output,
            },
        )
