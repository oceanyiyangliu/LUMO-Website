from __future__ import annotations

"""Isolated Playwright browser workers for non-destructive web automation.

Browser workers never attach to the user's interactive browser. Each worker owns
an isolated persistent Chromium profile, making parallel web missions possible
without cursor contention or shared session state.
"""

import hashlib
import ipaddress
import socket
import threading
import time
from pathlib import Path
from urllib.parse import urlparse
from typing import Any, Mapping

from ocean.domain.capability import (
    CapabilityExecutionPolicy,
    CapabilityIsolationPolicy,
    CapabilitySpec,
    OperationSpec,
)
from ocean.domain.enums import RiskLevel
from ocean.domain.resource import ResourceRequirement
from runtime.executor import CapabilityExecutor
from runtime.types import ExecutionRequest, ExecutionResult


_BROWSER_ROOT = Path.home() / ".lumo" / "browser-workers"
_PROFILE_LOCKS: dict[str, threading.Lock] = {}
_PROFILE_LOCKS_GUARD = threading.Lock()


def browser_spec() -> CapabilitySpec:
    common = {"timeout": "number (seconds)"}
    return CapabilitySpec(
        name="browser",
        description="Operate an isolated persistent Chromium worker with DOM locators and evidence capture.",
        requires_permissions={"browser.use"},
        execution_strategy="browser_playwright",
        execution_policy=CapabilityExecutionPolicy(CapabilityIsolationPolicy.IN_PROCESS_SAFE),
        operations={
            "navigate": OperationSpec(
                name="navigate", description="Navigate the isolated worker to an HTTP(S) URL.",
                input_schema={"url": "string (required)", **common},
                output_schema={"url": "string", "title": "string"}, risk_level=RiskLevel.IMPORTANT,
                resource_requirements=[ResourceRequirement(kind="browser", amount=1.0)],
            ),
            "accessibility_snapshot": OperationSpec(
                name="accessibility_snapshot", description="Return a bounded semantic snapshot of interactive DOM elements.",
                input_schema={"max_elements": "integer", **common},
                output_schema={"url": "string", "title": "string", "elements": "array"}, risk_level=RiskLevel.LOW,
                resource_requirements=[ResourceRequirement(kind="browser", amount=1.0)],
            ),
            "click_role": OperationSpec(
                name="click_role", description="Click an accessible DOM element by ARIA role and optional accessible name.",
                input_schema={"role": "string (required)", "name": "string", **common},
                output_schema={"url": "string", "role": "string", "name": "string"}, risk_level=RiskLevel.HIGH,
                resource_requirements=[ResourceRequirement(kind="browser", amount=1.0)],
            ),
            "fill_role": OperationSpec(
                name="fill_role", description="Fill an accessible textbox by ARIA role and accessible name.",
                input_schema={"name": "string (required)", "text": "string (required)", **common},
                output_schema={"length": "integer", "name": "string"}, risk_level=RiskLevel.HIGH,
                resource_requirements=[ResourceRequirement(kind="browser", amount=1.0)],
            ),
            "click": OperationSpec(
                name="click", description="Click a DOM locator in the isolated browser.",
                input_schema={"locator": "string (required)", **common},
                output_schema={"url": "string"}, risk_level=RiskLevel.HIGH,
                resource_requirements=[ResourceRequirement(kind="browser", amount=1.0)],
            ),
            "fill": OperationSpec(
                name="fill", description="Fill a DOM locator with text.",
                input_schema={"locator": "string (required)", "text": "string (required)", **common},
                output_schema={"locator": "string", "length": "integer"}, risk_level=RiskLevel.HIGH,
                resource_requirements=[ResourceRequirement(kind="browser", amount=1.0)],
            ),
            "extract": OperationSpec(
                name="extract", description="Extract bounded text from a DOM locator.",
                input_schema={"locator": "string", "max_chars": "integer", **common},
                output_schema={"text": "string", "url": "string", "title": "string"}, risk_level=RiskLevel.LOW,
                resource_requirements=[ResourceRequirement(kind="browser", amount=1.0)],
            ),
            "screenshot": OperationSpec(
                name="screenshot", description="Capture the isolated browser page as PNG evidence.",
                input_schema={"path": "string | null", **common},
                output_schema={"path": "string", "url": "string", "title": "string"}, risk_level=RiskLevel.LOW,
                resource_requirements=[ResourceRequirement(kind="browser", amount=1.0)],
            ),
        },
    )


def _profile_key(worker_id: str) -> str:
    return hashlib.sha256(worker_id.encode("utf-8")).hexdigest()[:24]


def _profile_lock(worker_id: str) -> threading.Lock:
    with _PROFILE_LOCKS_GUARD:
        return _PROFILE_LOCKS.setdefault(_profile_key(worker_id), threading.Lock())


def _timeout(arguments: Mapping[str, Any], default: float = 20.0) -> float:
    value = float(arguments.get("timeout", default))
    if value <= 0 or value > 120:
        raise ValueError("timeout must be greater than 0 and at most 120 seconds")
    return value


class PlaywrightBrowserExecutor(CapabilityExecutor):
    """Persistent, isolated Chromium worker.

    A worker profile is deterministic and reusable across calls, while different
    worker IDs are fully isolated. The executor exposes only locator-based DOM
    operations; it does not synthesize mouse coordinates or control the desktop.
    """

    def __init__(self, *, worker_id: str = "default", root: Path | None = None, headless: bool = True) -> None:
        if not worker_id or len(worker_id) > 128:
            raise ValueError("worker_id must be non-empty and at most 128 characters")
        self.worker_id = worker_id
        self.root = (root or _BROWSER_ROOT).expanduser().resolve()
        self.profile_dir = self.root / _profile_key(worker_id)
        self.headless = headless
        self._playwright = None
        self._context = None
        self._page = None
        self._lock = _profile_lock(worker_id)

    def _ensure_page(self):
        if self._page is not None and not self._page.is_closed():
            return self._page
        from playwright.sync_api import sync_playwright
        if self._playwright is None:
            self._playwright = sync_playwright().start()
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        self._context = self._playwright.chromium.launch_persistent_context(
            str(self.profile_dir), headless=self.headless,
            viewport={"width": 1440, "height": 900},
            accept_downloads=False,
        )
        self._page = self._context.pages[0] if self._context.pages else self._context.new_page()
        self._install_network_guard(self._page)
        return self._page

    @staticmethod
    def _url(url: Any) -> str:
        if not isinstance(url, str) or not url.strip():
            raise ValueError("url must be a non-empty string")
        value = url.strip()
        if not (value.startswith("https://") or value.startswith("http://")):
            raise ValueError("browser URLs must use http:// or https://")
        return value

    @staticmethod
    def _assert_safe_page_url(url: str) -> None:
        """Keep browser workers on public HTTP(S), not loopback/private host services."""
        normalized = str(url).strip()
        if normalized.lower() in {"", "about:blank"}:
            return
        parsed = urlparse(normalized)
        if parsed.scheme.lower() not in {"http", "https"} or not parsed.hostname:
            raise RuntimeError(f"browser worker blocked unsafe page URL: {url!r}")
        if parsed.username is not None or parsed.password is not None:
            raise RuntimeError("browser worker blocked URL userinfo")
        host = parsed.hostname.rstrip(".").lower()
        if host == "localhost" or host.endswith(".localhost") or host.endswith(".local"):
            raise RuntimeError(f"browser worker blocked local hostname: {host!r}")
        try:
            addresses = {info[4][0] for info in socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme.lower() == "https" else 80), type=socket.SOCK_STREAM)}
        except (OSError, ValueError):
            raise RuntimeError(f"browser worker could not safely resolve hostname: {host!r}")
        for address in addresses:
            ip = ipaddress.ip_address(address)
            if not ip.is_global:
                raise RuntimeError(f"browser worker blocked non-public network address: {address}")

    def _install_network_guard(self, page: Any) -> None:
        """Block private/loopback navigation and subresource requests, including redirects."""
        def guard(route, request):
            try:
                self._assert_safe_page_url(request.url)
            except RuntimeError:
                route.abort()
                return
            route.continue_()
        page.route("**/*", guard)

    @staticmethod
    def _assert_domain_allowed(url: str, metadata: Mapping[str, Any]) -> None:
        allowed=metadata.get("allowed_domains")
        if allowed is None: return
        if not isinstance(allowed,(list,tuple,set)) or any(not isinstance(x,str) or not x.strip() for x in allowed):
            raise PermissionError("allowed_domains must be a list of hostnames")
        host=(urlparse(url).hostname or "").lower().rstrip(".")
        rules={x.strip().lower().lstrip(".") for x in allowed}
        if host not in rules and not any(host.endswith("."+rule) for rule in rules if rule):
            raise PermissionError(f"browser domain is not permitted: {host}")

    def execute(self, request: ExecutionRequest, context: Any) -> ExecutionResult:
        start = time.monotonic()
        try:
            timeout = _timeout(request.arguments)
            with self._lock:
                page = self._ensure_page()
                page.set_default_timeout(int(timeout * 1000))
                op = request.operation
                args = request.arguments
                metadata = getattr(request, "metadata", {}) or {}
                if op == "accessibility_snapshot":
                    self._assert_domain_allowed(page.url, metadata)
                    max_elements = max(1, min(300, int(args.get("max_elements", 100))))
                    elements = page.locator("button, a, input, textarea, select, [role]").evaluate_all(
                        """(els, limit) => els.slice(0, limit).map((e, i) => ({index:i, tag:e.tagName.toLowerCase(), role:e.getAttribute("role") || "", name:(e.getAttribute("aria-label") || e.getAttribute("name") || e.innerText || "").trim().slice(0,240), value:(e.value || "").toString().slice(0,240), disabled:!!e.disabled}))""",
                        max_elements,
                    )
                    result = {"url": page.url, "title": page.title(), "elements": elements}
                elif op == "click_role":
                    self._assert_domain_allowed(page.url, metadata)
                    role = str(args.get("role", "")).strip()
                    name = str(args.get("name", "")).strip()
                    if not role:
                        raise ValueError("role is required")
                    locator = page.get_by_role(role, name=name or None)
                    if locator.count() != 1:
                        raise RuntimeError(f"accessible browser target matched {locator.count()} elements; refine role/name")
                    locator.click(timeout=int(timeout * 1000))
                    result = {"url": page.url, "role": role, "name": name}
                elif op == "fill_role":
                    self._assert_domain_allowed(page.url, metadata)
                    name = str(args.get("name", "")).strip()
                    text = args.get("text")
                    if not name or not isinstance(text, str):
                        raise ValueError("name and string text are required")
                    if len(text) > 100_000:
                        raise ValueError("text exceeds the 100000-character safety limit")
                    locator = page.get_by_role("textbox", name=name)
                    if locator.count() != 1:
                        raise RuntimeError(f"accessible textbox matched {locator.count()} elements; refine name")
                    locator.fill(text, timeout=int(timeout * 1000))
                    result = {"length": len(text), "name": name}
                elif op == "navigate":
                    url = self._url(args.get("url"))
                    self._assert_domain_allowed(url, metadata)
                    page.goto(url, wait_until="domcontentloaded", timeout=int(timeout * 1000))
                    self._assert_safe_page_url(page.url)
                    result = {"url": page.url, "title": page.title()}
                elif op == "click":
                    self._assert_domain_allowed(page.url, metadata)
                    locator = str(args.get("locator", "")).strip()
                    if not locator:
                        raise ValueError("locator is required")
                    page.locator(locator).first.click(timeout=int(timeout * 1000))
                    self._assert_safe_page_url(page.url)
                    result = {"url": page.url}
                elif op == "fill":
                    self._assert_domain_allowed(page.url, metadata)
                    locator = str(args.get("locator", "")).strip()
                    text = args.get("text")
                    if not locator or not isinstance(text, str):
                        raise ValueError("locator and string text are required")
                    if len(text) > 100_000:
                        raise ValueError("text exceeds the 100000-character safety limit")
                    page.locator(locator).first.fill(text, timeout=int(timeout * 1000))
                    result = {"locator": locator, "length": len(text)}
                elif op == "extract":
                    self._assert_domain_allowed(page.url, metadata)
                    locator = str(args.get("locator", "body")).strip() or "body"
                    max_chars = int(args.get("max_chars", 50_000))
                    if max_chars <= 0 or max_chars > 500_000:
                        raise ValueError("max_chars must be between 1 and 500000")
                    self._assert_safe_page_url(page.url)
                    text = page.locator(locator).first.inner_text(timeout=int(timeout * 1000))[:max_chars]
                    result = {"text": text, "url": page.url, "title": page.title()}
                elif op == "screenshot":
                    self._assert_domain_allowed(page.url, metadata)
                    requested = args.get("path")
                    evidence_root = (self.profile_dir / "evidence").resolve()
                    path = (evidence_root / f"{int(time.time() * 1000)}.png") if not requested else Path(str(requested)).expanduser().resolve()
                    if evidence_root not in path.parents:
                        raise ValueError("browser screenshots must be stored inside the worker evidence directory")
                    path.parent.mkdir(parents=True, exist_ok=True)
                    page.screenshot(path=str(path), full_page=False, timeout=int(timeout * 1000))
                    result = {"path": str(path), "url": page.url, "title": page.title()}
                else:
                    raise ValueError(f"unsupported browser operation: {op}")
            return ExecutionResult.succeeded(result, metadata={"worker_id": self.worker_id, "duration_seconds": time.monotonic() - start})
        except Exception as exc:
            return ExecutionResult.failed(str(exc), metadata={"failure_type": "browser_capability_failure", "worker_id": self.worker_id, "operation": request.operation, "duration_seconds": time.monotonic() - start})

    def close(self) -> None:
        with self._lock:
            if self._context is not None:
                self._context.close()
            self._context = None
            self._page = None
            if self._playwright is not None:
                self._playwright.stop()
            self._playwright = None
