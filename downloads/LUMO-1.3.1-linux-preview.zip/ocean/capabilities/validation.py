from __future__ import annotations

from typing import Any, Mapping

from ocean.core.errors import InvalidCapabilityInput, InvalidCapabilityOutput


def _type_matches(value: Any, declaration: str) -> bool:
    normalized = declaration.strip().lower()
    nullable = "null" in normalized and value is None
    if nullable:
        return True
    if value is None:
        return False
    if normalized.startswith("string"):
        return isinstance(value, str)
    if normalized.startswith("integer"):
        return isinstance(value, int) and not isinstance(value, bool)
    if normalized.startswith("number"):
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if normalized.startswith("boolean"):
        return isinstance(value, bool)
    if normalized.startswith("dict") or normalized.startswith("object"):
        return isinstance(value, Mapping)
    if normalized.startswith("array") or normalized.startswith("list"):
        return isinstance(value, (list, tuple))
    return True


def validate_input(arguments: Mapping[str, Any], schema: Mapping[str, Any]) -> None:
    for name, declaration in schema.items():
        if not isinstance(declaration, str):
            continue
        required = "required" in declaration.lower()
        if required and name not in arguments:
            raise InvalidCapabilityInput(f"missing required argument: {name}")
        if name in arguments and not _type_matches(arguments[name], declaration):
            raise InvalidCapabilityInput(
                f"invalid argument {name!r}: expected {declaration}"
            )


def validate_output(result: Any, schema: Mapping[str, Any]) -> None:
    if not schema:
        return
    if not isinstance(result, Mapping):
        raise InvalidCapabilityOutput("capability output must be an object")
    for name, declaration in schema.items():
        if name not in result:
            raise InvalidCapabilityOutput(f"missing output field: {name}")
        if isinstance(declaration, str) and not _type_matches(result[name], declaration):
            raise InvalidCapabilityOutput(
                f"invalid output {name!r}: expected {declaration}"
            )