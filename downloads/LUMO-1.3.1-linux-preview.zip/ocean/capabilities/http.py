from __future__ import annotations

import json
import ipaddress
import socket
import urllib.error
import urllib.request
from urllib.parse import urljoin, urlparse
from typing import Any

from ocean.domain.capability import (
    CapabilityExecutionPolicy,
    CapabilityIsolationPolicy,
    CapabilitySpec,
    OperationSpec,
)
from ocean.domain.enums import RiskLevel
from ocean.domain.resource import ResourceRequirement
from runtime.executor import CapabilityExecutor
from runtime.types import ExecutionRequest, ExecutionResult


def http_spec() -> CapabilitySpec:
    return CapabilitySpec(
        name="http",
        description="Make bounded governed HTTP requests.",
        requires_permissions={"http.request"},
        execution_strategy="http_local",
        execution_policy=CapabilityExecutionPolicy(
            CapabilityIsolationPolicy.PROCESS_ISOLATED_REQUIRED
        ),
        operations={
            "request": OperationSpec(
                name="request",
                description="Perform an HTTP request and return bounded metadata/body.",
                input_schema={
                    "url": "string (required)",
                    "method": "string",
                    "headers": "dict<string,string>",
                    "body": "string | null",
                    "timeout": "number",
                    "max_output_bytes": "integer",
                },
                output_schema={
                    "status": "integer",
                    "headers": "dict",
                    "body": "string",
                    "url": "string",
                },
                risk_level=RiskLevel.IMPORTANT,
                resource_requirements=[ResourceRequirement(kind="network", amount=1.0)],
            )
        },
    )


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _assert_safe_url(url: str) -> None:
    parsed = urlparse(url)
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.hostname:
        raise ValueError("URL must use http:// or https://")
    if parsed.username is not None or parsed.password is not None:
        raise ValueError("URL userinfo is not allowed")
    host = parsed.hostname.rstrip(".").lower()
    if host == "localhost" or host.endswith(".localhost") or host.endswith(".local"):
        raise ValueError("HTTP capability blocks local hostnames")
    try:
        addresses = {info[4][0] for info in socket.getaddrinfo(
            host, parsed.port or (443 if parsed.scheme.lower() == "https" else 80),
            type=socket.SOCK_STREAM,
        )}
    except (OSError, ValueError) as exc:
        raise ValueError("HTTP capability could not safely resolve hostname") from exc
    if not addresses or any(not ipaddress.ip_address(addr).is_global for addr in addresses):
        raise ValueError("HTTP capability blocks non-public network addresses")


class HttpExecutor(CapabilityExecutor):
    def execute(self, request: ExecutionRequest, context: Any) -> ExecutionResult:
        args = request.arguments
        url = str(args["url"]).strip()
        method = str(args.get("method", "GET")).upper()
        if method not in {"GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"}:
            raise ValueError("HTTP method is not permitted")
        raw_headers = args.get("headers") or {}
        if not isinstance(raw_headers, dict) or len(raw_headers) > 64:
            raise ValueError("headers must be an object with at most 64 entries")
        headers = {}
        for key, value in raw_headers.items():
            if not isinstance(key, str) or not isinstance(value, str) or not key.strip():
                raise ValueError("HTTP headers must be string key/value pairs")
            if len(key) > 256 or len(value) > 16_384 or "\r" in key + value or "\n" in key + value:
                raise ValueError("HTTP header exceeds safety limits")
            headers[key] = value
        body = args.get("body")
        if body is not None and not isinstance(body, str):
            raise ValueError("HTTP body must be a string or null")
        if isinstance(body, str) and len(body.encode("utf-8")) > 1_000_000:
            raise ValueError("HTTP request body exceeds 1MB safety limit")
        data = body.encode("utf-8") if isinstance(body, str) else None
        timeout = float(args.get("timeout", 10.0))
        limit = int(args.get("max_output_bytes", 1_000_000))
        if not (0 < timeout <= 120) or not (1 <= limit <= 10_000_000):
            raise ValueError("timeout or output limit outside safety bounds")
        opener = urllib.request.build_opener(_NoRedirectHandler())
        try:
            for hop in range(6):
                _assert_safe_url(url)
                request_obj = urllib.request.Request(url, data=data, headers=headers, method=method)
                try:
                    response = opener.open(request_obj, timeout=timeout)
                except urllib.error.HTTPError as exc:
                    if exc.code not in {301, 302, 303, 307, 308}:
                        return ExecutionResult.failed(
                            f"HTTP request failed with status {exc.code}",
                            metadata={"failure_type": "capability_failure", "status": exc.code},
                        )
                    location = exc.headers.get("Location")
                    if not location:
                        return ExecutionResult.failed("HTTP redirect missing Location", metadata={"failure_type": "capability_failure"})
                    url = urljoin(url, location)
                    if exc.code == 303 or (exc.code in {301, 302} and method not in {"GET", "HEAD"}):
                        method, data = "GET", None
                    continue
                with response:
                    raw = response.read(limit + 1)
                    if len(raw) > limit:
                        return ExecutionResult.failed(
                            "HTTP response exceeded output limit",
                            metadata={"failure_type": "resource_limit_exceeded"},
                        )
                    return ExecutionResult.succeeded({
                        "status": int(response.status),
                        "headers": dict(response.headers.items()),
                        "body": raw.decode("utf-8", errors="replace"),
                        "url": str(response.url),
                    })
            return ExecutionResult.failed("HTTP redirect limit exceeded", metadata={"failure_type": "capability_failure"})
        except Exception as exc:
            return ExecutionResult.failed(
                str(exc),
                metadata={"failure_type": "capability_failure", "exception_type": type(exc).__name__},
            )