from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from runtime.executor import CapabilityExecutor
from runtime.types import ExecutionRequest, ExecutionResult


class FilesystemExecutor(CapabilityExecutor):
    """Deterministic, read-only local filesystem capability executor."""

    def execute(
        self,
        request: ExecutionRequest,
        context: Any,
    ) -> ExecutionResult:
        try:
            if request.capability != "filesystem":
                return ExecutionResult.failed(
                    f"unsupported capability: {request.capability}"
                )

            if request.operation == "read_file":
                return self._read_file(request.arguments)

            if request.operation == "list_directory":
                return self._list_directory(request.arguments)

            if request.operation == "file_exists":
                return self._file_exists(request.arguments)

            if request.operation == "search_files":
                return self._search_files(request.arguments)


            return ExecutionResult.failed(
                f"unsupported filesystem operation: {request.operation}"
            )

        except Exception as exc:
            return ExecutionResult.failed(str(exc))

    @staticmethod
    def _path(arguments: Mapping[str, Any]) -> Path:
        path = arguments.get("path")

        if not isinstance(path, str) or not path.strip():
            raise ValueError("path must be a non-empty string")

        return Path(path).expanduser()

    @classmethod
    def _read_file(cls, arguments: Mapping[str, Any]) -> ExecutionResult:
        path = cls._path(arguments)

        if not path.exists():
            return ExecutionResult.failed(f"path does not exist: {path}")

        if not path.is_file():
            return ExecutionResult.failed(f"path is not a file: {path}")

        content = path.read_text(encoding="utf-8")

        return ExecutionResult.succeeded(
            {
                "content": content,
                "path": str(path),
            }
        )

    @classmethod
    def _file_exists(cls, arguments: Mapping[str, Any]) -> ExecutionResult:
        path = cls._path(arguments)
        return ExecutionResult.succeeded({"path": str(path), "exists": path.exists()})

    @classmethod
    def _search_files(cls, arguments: Mapping[str, Any]) -> ExecutionResult:
        path = cls._path(arguments)
        query = arguments.get("query")
        pattern = arguments.get("pattern", "*")
        max_results = arguments.get("max_results", 100)

        if not isinstance(query, str) or not query:
            raise ValueError("query must be a non-empty string")
        if not isinstance(pattern, str) or not pattern:
            raise ValueError("pattern must be a non-empty string")
        if not isinstance(max_results, int) or isinstance(max_results, bool) or max_results <= 0:
            raise ValueError("max_results must be a positive integer")
        if not path.exists():
            return ExecutionResult.failed(f"path does not exist: {path}")
        if not path.is_dir():
            return ExecutionResult.failed(f"path is not a directory: {path}")

        matches = []
        for candidate in sorted(path.rglob(pattern), key=lambda item: str(item)):
            if not candidate.is_file():
                continue
            try:
                with candidate.open("r", encoding="utf-8") as handle:
                    for line_number, line in enumerate(handle, 1):
                        if query in line:
                            matches.append({
                                "path": str(candidate),
                                "line": line_number,
                                "text": line.rstrip("\n"),
                            })
                            if len(matches) >= max_results:
                                return ExecutionResult.succeeded({
                                    "path": str(path),
                                    "query": query,
                                    "matches": matches,
                                    "truncated": True,
                                })
            except (UnicodeDecodeError, OSError):
                continue

        return ExecutionResult.succeeded({
            "path": str(path),
            "query": query,
            "matches": matches,
            "truncated": False,
        })

    @classmethod
    def _list_directory(cls, arguments: Mapping[str, Any]) -> ExecutionResult:
        path = cls._path(arguments)

        if not path.exists():
            return ExecutionResult.failed(f"path does not exist: {path}")

        if not path.is_dir():
            return ExecutionResult.failed(f"path is not a directory: {path}")

        entries = sorted(
            (
                {
                    "name": entry.name,
                    "path": str(entry),
                    "type": "directory" if entry.is_dir() else "file",
                }
                for entry in path.iterdir()
            ),
            key=lambda item: item["name"],
        )

        return ExecutionResult.succeeded(
            {
                "path": str(path),
                "entries": entries,
            }
        )


def filesystem_spec():
    from ocean.domain.capability import CapabilitySpec, OperationSpec
    from ocean.domain.enums import RiskLevel
    from ocean.domain.resource import ResourceRequirement

    return CapabilitySpec(
        name="filesystem",
        description="Local filesystem inspection operations",
        execution_strategy="deterministic_local",
        requires_permissions={"filesystem.read"},
        operations={
            "read_file": OperationSpec(
                name="read_file",
                description="Read a UTF-8 text file",
                input_schema={"path": "string"},
                output_schema={"content": "string", "path": "string"},
                risk_level=RiskLevel.LOW,
                resource_requirements=[
                    ResourceRequirement(kind="filesystem", amount=1.0)
                ],
            ),
            "list_directory": OperationSpec(
                name="list_directory",
                description="List entries in a directory",
                input_schema={"path": "string"},
                output_schema={"path": "string", "entries": "array"},
                risk_level=RiskLevel.LOW,
                resource_requirements=[
                    ResourceRequirement(kind="filesystem", amount=1.0)
                ],
            ),
            "file_exists": OperationSpec(
                name="file_exists",
                description="Check whether a filesystem path exists",
                input_schema={"path": "string"},
                output_schema={"path": "string", "exists": "boolean"},
                risk_level=RiskLevel.LOW,
                resource_requirements=[
                    ResourceRequirement(kind="filesystem", amount=1.0)
                ],
            ),

            "search_files": OperationSpec(
                name="search_files",
                description="Recursively search UTF-8 text files for a query",
                input_schema={
                    "path": "string",
                    "query": "string",
                    "pattern": "string",
                    "max_results": "integer",
                },
                output_schema={
                    "path": "string",
                    "query": "string",
                    "matches": "array",
                    "truncated": "boolean",
                },
                risk_level=RiskLevel.LOW,
                resource_requirements=[
                    ResourceRequirement(kind="filesystem", amount=1.0)
                ],
            ),

        },
    )


# Optional Universal Action Mapping (UAM)
#
# This small mapping exposes a repository-agnostic set of 'universal' action
# names to the concrete operation names defined by this capability. It is
# intentionally additive and purely declarative: discovery code may include
# this mapping in its output to help higher-level planners translate universal
# actions into concrete capability operations. The mapping is not used by the
# executor itself and does not change any runtime behaviour.

universal_action_mappings = {
    "read": "read_file",
    "list": "list_directory",
    "exists": "file_exists",
    "search": "search_files",
}
