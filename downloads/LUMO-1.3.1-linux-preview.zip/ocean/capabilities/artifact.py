"""Generic artifact creation and verification primitives for LUMO missions."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping, Sequence
import re

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN


def create_presentation(
    *,
    output_path: str | Path,
    title: str,
    slides: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Create a real PPTX from model-produced structured slide content."""
    if not title.strip() or not slides:
        raise ValueError("presentation requires a title and at least one slide")
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    presentation = Presentation()
    presentation.slide_width = Inches(13.333)
    presentation.slide_height = Inches(7.5)
    blank = presentation.slide_layouts[6]
    for index, spec in enumerate(slides, start=1):
        slide = presentation.slides.add_slide(blank)
        slide.background.fill.solid()
        slide.background.fill.fore_color.rgb = _rgb("F7F8FA")
        slide_title = title if index == 1 else str(spec.get("title", f"Slide {index}"))
        _add_text(slide, slide_title, 0.7, 0.45, 11.9, 0.7, 26, True)
        bullets = spec.get("bullets", ())
        if isinstance(bullets, str):
            bullets = [bullets]
        _add_bullets(slide, [str(x) for x in bullets], 0.9, 1.55, 11.5, 4.9)
        note = str(spec.get("speaker_notes", "")).strip()
        if note:
            _add_text(slide, note[:900], 0.9, 6.65, 11.5, 0.45, 9, False)
    presentation.save(path)
    return verify_presentation(path, expected_title=title)


def verify_presentation(path: str | Path, *, expected_title: str | None = None) -> dict[str, Any]:
    """Verify the produced PPTX by reopening the actual artifact."""
    target = Path(path)
    if not target.is_file() or target.stat().st_size < 4096:
        raise ValueError("presentation artifact is missing or implausibly small")
    presentation = Presentation(target)
    texts: list[str] = []
    slide_titles: list[str] = []
    for slide in presentation.slides:
        slide_text = []
        for shape in slide.shapes:
            if not getattr(shape, "has_text_frame", False):
                continue
            text = " ".join(p.text.strip() for p in shape.text_frame.paragraphs if p.text.strip())
            if text:
                slide_text.append(text)
        if not slide_text:
            raise ValueError(f"slide {len(slide_titles) + 1} contains no text")
        slide_titles.append(slide_text[0])
        texts.extend(slide_text)
    if expected_title and not any(expected_title.lower() in text.lower() for text in texts[:2]):
        raise ValueError("presentation title was not found in the produced artifact")
    if any(len(text) > 2200 for text in texts):
        raise ValueError("presentation contains an excessively long text block")
    return {
        "path": str(target),
        "exists": True,
        "slide_count": len(presentation.slides),
        "slide_titles": slide_titles,
        "text_blocks": len(texts),
        "verified": True,
        "verification_method": "reopened_pptx_and_inspected_slide_text",
    }


def _add_text(slide, text: str, left: float, top: float, width: float, height: float, size: int, bold: bool) -> None:
    box = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(height))
    frame = box.text_frame
    frame.clear()
    paragraph = frame.paragraphs[0]
    paragraph.text = text
    paragraph.alignment = PP_ALIGN.LEFT
    run = paragraph.runs[0]
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.name = "Aptos"


def _add_bullets(slide, bullets: Sequence[str], left: float, top: float, width: float, height: float) -> None:
    box = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(height))
    frame = box.text_frame
    frame.clear()
    frame.word_wrap = True
    for index, text in enumerate(bullets[:8]):
        paragraph = frame.paragraphs[0] if index == 0 else frame.add_paragraph()
        paragraph.text = text
        paragraph.level = 0
        paragraph.font.size = Pt(18)
        paragraph.font.name = "Aptos"
        paragraph.space_after = Pt(10)


def _rgb(value: str):
    from pptx.dml.color import RGBColor
    if not re.fullmatch(r"[0-9A-Fa-f]{6}", value):
        raise ValueError("invalid RGB value")
    return RGBColor.from_string(value)
