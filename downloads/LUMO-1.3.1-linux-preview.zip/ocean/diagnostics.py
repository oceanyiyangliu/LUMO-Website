"""Operator diagnostics for the LUMO control plane."""
from __future__ import annotations
import compileall
import importlib
import re
from pathlib import Path
from typing import Any
from ocean.advanced_capabilities import ReliabilitySLO

CORE_MODULES = (
    "ocean.api", "ocean.service", "ocean.computer_agent",
    "ocean.capabilities.computer", "ocean.capabilities.browser",
    "ocean.worlds.manager", "ocean.event_sourcing.replay",
    "ocean.governance.engine", "ocean.recovery.engine",
    "ocean.self_improvement.runtime", "ocean.kernel_invariants",
)


def doctor(repository_root: Path) -> dict[str, Any]:
    root = Path(repository_root)
    state = root / ".ocean"
    checks: dict[str, bool] = {
        "repository": root.is_dir(),
        "state_directory": state.is_dir(),
        "state_database": (state / "state.sqlite3").is_file(),
        "event_key": (root / ".lumo-event-keys").is_file(),
    }
    imports: dict[str, str] = {}
    for name in CORE_MODULES:
        try:
            importlib.import_module(name)
            imports[name] = "ok"
        except Exception as exc:
            imports[name] = f"error: {type(exc).__name__}: {str(exc)[:180]}"
    checks["core_imports"] = all(v == "ok" for v in imports.values())
    checks["python_compile"] = bool(compileall.compile_dir(str(root / "ocean"), quiet=1))
    return {"ok": all(checks.values()), "checks": checks, "imports": imports}


def deep_test(repository_root: Path) -> dict[str, Any]:
    """Run the repository's complete deterministic regression suite."""
    import subprocess
    result = subprocess.run(
        [str(Path(repository_root) / ".venv" / "bin" / "python"), "-m", "pytest", "-q"],
        cwd=str(repository_root), text=True, capture_output=True,
    )
    output = result.stdout + result.stderr
    match = re.search(r"(\d+) passed", output)
    passed = int(match.group(1)) if match else 0
    total = passed
    slo = ReliabilitySLO("deterministic_regression_suite", 1.0, 1.0 if result.returncode == 0 and total > 0 else 0.0)
    return {"ok": result.returncode == 0, "returncode": result.returncode,
            "tests_passed": passed, "reliability_slo": {"name": slo.name, "target": slo.target, "observed": slo.observed, "met": slo.met},
            "output": output[-12000:]}
