"""Host power leases for long-running LUMO work.

LUMO never disables the user's normal screen saver. A lease only prevents
system idle sleep while real work is running, then releases automatically.
"""
from __future__ import annotations

import os
import platform
import subprocess
import threading
import json
import time
from dataclasses import dataclass, field
from datetime import datetime, time as dt_time
from typing import Any, Callable


@dataclass(frozen=True)
class PowerLease:
    key: str
    account_id: str | None = None
    owner_type: str = "work"
    owner_id: str | None = None
    device_id: str | None = None


@dataclass(frozen=True)
class PowerPreferences:
    """User-controlled policy for when autonomous work may consume power."""
    min_battery_percent: float = 20.0
    max_temperature_c: float = 85.0
    allow_on_battery: bool = True
    allow_low_power_mode: bool = True
    quiet_hours_start: dt_time | None = None
    quiet_hours_end: dt_time | None = None

    def __post_init__(self) -> None:
        if not 0 <= float(self.min_battery_percent) <= 100:
            raise ValueError("min_battery_percent must be 0..100")
        if not -50 <= float(self.max_temperature_c) <= 150:
            raise ValueError("max_temperature_c outside safety range")


@dataclass(frozen=True)
class PowerDecision:
    allowed: bool
    reasons: tuple[str, ...] = ()
    battery_percent: float | None = None
    temperature_c: float | None = None
    low_power_mode: bool | None = None


class PowerPolicyEngine:
    """Pure, deterministic power admission policy; execution remains in the guardian."""
    def __init__(self, preferences: PowerPreferences | None = None) -> None:
        self.preferences = preferences or PowerPreferences()

    def decide(self, *, battery_percent: float | None = None, temperature_c: float | None = None,
               on_battery: bool = False, low_power_mode: bool = False, now: datetime | None = None) -> PowerDecision:
        p = self.preferences
        reasons: list[str] = []
        if battery_percent is not None and not 0 <= float(battery_percent) <= 100:
            raise ValueError("battery_percent must be 0..100")
        if temperature_c is not None and not -50 <= float(temperature_c) <= 150:
            raise ValueError("temperature_c outside safety range")
        if on_battery and not p.allow_on_battery:
            reasons.append("battery_operation_disabled")
        if battery_percent is not None and battery_percent < p.min_battery_percent:
            reasons.append("battery_below_minimum")
        if temperature_c is not None and temperature_c > p.max_temperature_c:
            reasons.append("temperature_above_limit")
        if low_power_mode and not p.allow_low_power_mode:
            reasons.append("low_power_mode_disabled")
        if self._in_quiet_hours((now or datetime.now()).time()):
            reasons.append("quiet_hours")
        return PowerDecision(not reasons, tuple(reasons), battery_percent, temperature_c, low_power_mode)

    def _in_quiet_hours(self, current: dt_time) -> bool:
        start, end = self.preferences.quiet_hours_start, self.preferences.quiet_hours_end
        if start is None or end is None or start == end:
            return False
        return (start <= current < end) if start < end else (current >= start or current < end)


class PowerGuardian:
    """Reference-counted macOS compute lease backed by caffeinate."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._leases: set[str] = set()
        self._process: subprocess.Popen | None = None
        self._lease_meta: dict[str, PowerLease] = {}
        self._audit: list[dict[str, Any]] = []

    def acquire(self, key: str, *, account_id: str | None = None, owner_type: str = "work", owner_id: str | None = None, device_id: str | None = None) -> PowerLease:
        key = str(key).strip()
        if not key:
            raise ValueError("power lease key is required")
        with self._lock:
            self._leases.add(key)
            lease = PowerLease(key, account_id=account_id, owner_type=owner_type, owner_id=owner_id or key, device_id=device_id)
            self._lease_meta[key] = lease
            self._audit.append({"at": time.time(), "event": "PowerLeaseAcquired", "key": key, "account_id": account_id, "owner_type": owner_type, "owner_id": owner_id or key, "device_id": device_id})
            self._ensure_process()
        return PowerLease(key, account_id=account_id, owner_type=owner_type, owner_id=owner_id or key, device_id=device_id)

    def release(self, lease: PowerLease | str) -> None:
        key = lease.key if isinstance(lease, PowerLease) else str(lease)
        with self._lock:
            existed = key in self._leases
            self._leases.discard(key)
            self._lease_meta.pop(key, None)
            if existed:
                self._audit.append({"at": time.time(), "event": "PowerLeaseReleased", "key": key})
            if not self._leases:
                self._stop_process()

    def status(self) -> dict[str, object]:
        with self._lock:
            # A lease is a live contract. If caffeinate died unexpectedly,
            # restore the assertion before reporting the host as protected.
            if self._leases and (self._process is None or self._process.poll() is not None):
                self._ensure_process()
            process_alive = self._process is not None and self._process.poll() is None
            capabilities = self.capabilities()
            return {
                "active": bool(self._leases),
                "leases": sorted(self._leases),
                "pid": self._process.pid if process_alive else None,
                "display_sleep_allowed": True,
                "system_sleep_blocked": bool(self._leases) and process_alive,
                "enforcement_available": capabilities["enforcement_available"],
                "wake_from_sleep": capabilities["wake_from_sleep"],
                "cold_boot": capabilities["cold_boot"],
                "lease_owners": [self._lease_meta[k].__dict__ for k in sorted(self._lease_meta)],
                "audit": list(self._audit[-100:]),
                "sleep_state": self.sleep_state(),
            }

    @staticmethod
    def capabilities() -> dict[str, Any]:
        """Report power features conservatively; unsupported actions stay false."""
        darwin = platform.system() == "Darwin"
        return {
            "display_sleep_allowed": True,
            "system_sleep_blocked_by_lease": darwin,
            "enforcement_available": darwin and os.path.exists("/usr/bin/caffeinate"),
            "wake_from_sleep": darwin and os.path.exists("/usr/bin/pmset"),
            "cold_boot": False,
        }

    def sleep_state(self) -> str:
        """Conservative host state: only claim awake when LUMO can prove it."""
        if platform.system() != "Darwin":
            return "unknown"
        with self._lock:
            if self._leases and self._process is not None and self._process.poll() is None:
                return "awake"
        return "unknown"

    def system_awake(self) -> bool | None:
        state = self.sleep_state()
        return True if state == "awake" else None

    def audit(self) -> list[dict[str, Any]]:
        with self._lock:
            return [dict(item) for item in self._audit[-100:]]

    def close(self) -> None:
        with self._lock:
            self._leases.clear()
            self._stop_process()

    def _ensure_process(self) -> None:
        if platform.system() != "Darwin":
            return
        if self._process is not None and self._process.poll() is None:
            return
        try:
            # -i: prevent idle system sleep; -m: prevent disk idle sleep;
            # -s: prevent system sleep; -u: assert user activity. Display sleep
            # remains allowed because -d is intentionally absent.
            self._process = subprocess.Popen(["caffeinate", "-imsu"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except (FileNotFoundError, OSError):
            self._process = None

    def _stop_process(self) -> None:
        process = self._process
        self._process = None
        if process is None:
            return
        if process.poll() is None:
            try:
                process.terminate()
                process.wait(timeout=2)
            except (OSError, subprocess.TimeoutExpired):
                try:
                    process.kill()
                except OSError:
                    pass
