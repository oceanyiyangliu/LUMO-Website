from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Generic, Optional, TypeVar


StateT = TypeVar("StateT")
ActionT = TypeVar("ActionT")


@dataclass(frozen=True)
class ReflexDecision(Generic[ActionT]):
    """A cheap, executable decision produced by the hot loop."""

    action: Optional[ActionT]
    changed: bool = True
    confidence: float = 1.0
    reason: str = ""


@dataclass(frozen=True)
class ReflexTelemetry:
    cycles: int
    actions: int
    observations: int
    elapsed_seconds: float
    average_cycle_ms: float
    last_cycle_ms: float
    target_hz: float
    state: str


@dataclass
class ReflexPolicy(Generic[StateT, ActionT]):
    """High-frequency policy separated from strategic cognition.

    The policy must be deterministic/cheap. It may use cached state, sensor
    deltas, or a local controller, but it must never invoke a cloud model.
    """

    decide: Callable[[StateT], ReflexDecision[ActionT]]
    changed: Callable[[StateT, Optional[StateT]], bool] = lambda state, previous: state != previous


class ReflexLoop(Generic[StateT, ActionT]):
    """Continuously close the perception -> decision -> action loop.

    This is deliberately independent from LLM planning. A strategic mission
    can install a policy, then let this loop react at high frequency while the
    strategic brain sleeps. Observation and action callbacks are intentionally
    synchronous so a controller can keep strict ordering and avoid actuator
    races. A loop may be stopped immediately from another thread.
    """

    def __init__(
        self,
        *,
        observe: Callable[[], StateT],
        policy: ReflexPolicy[StateT, ActionT],
        act: Callable[[ActionT], None],
        target_hz: float = 60.0,
        max_hz: float = 240.0,
        on_cycle: Optional[Callable[[ReflexTelemetry], None]] = None,
        on_error: Optional[Callable[[Exception], None]] = None,
    ) -> None:
        if target_hz <= 0 or target_hz > max_hz:
            raise ValueError("target_hz must be greater than 0 and no greater than max_hz")
        if max_hz <= 0:
            raise ValueError("max_hz must be positive")
        self.observe = observe
        self.policy = policy
        self.act = act
        self.target_hz = float(target_hz)
        self.max_hz = float(max_hz)
        self.on_cycle = on_cycle
        self.on_error = on_error
        self._stop = threading.Event()
        self._lock = threading.RLock()
        self._telemetry = ReflexTelemetry(0, 0, 0, 0.0, 0.0, 0.0, self.target_hz, "idle")

    def stop(self) -> None:
        self._stop.set()

    @property
    def telemetry(self) -> ReflexTelemetry:
        with self._lock:
            return self._telemetry

    def run(self, *, duration: Optional[float] = None) -> ReflexTelemetry:
        if duration is not None and duration < 0:
            raise ValueError("duration must be non-negative")
        self._stop.clear()
        started = time.perf_counter()
        # Finite runs use a deterministic number of cadence slots. Wall-clock
        # scheduling can oversleep on macOS, so using the wall deadline directly
        # can silently drop reactions from short diagnostic/benchmark runs.
        planned_cycles = int(duration * self.target_hz) if duration is not None else None
        previous: Optional[StateT] = None
        cycles = actions = observations = 0
        total_cycle = 0.0
        last_cycle = 0.0
        self._publish(cycles, actions, observations, started, last_cycle, "running")

        interval = 1.0 / self.target_hz
        next_tick = started
        while not self._stop.is_set() and (planned_cycles is None or cycles < planned_cycles):
            cycle_start = time.perf_counter()
            try:
                state = self.observe()
                observations += 1
                if previous is None or self.policy.changed(state, previous):
                    decision = self.policy.decide(state)
                    if decision.action is not None and decision.confidence > 0:
                        self.act(decision.action)
                        actions += 1
                    previous = state
            except Exception as exc:
                if self.on_error is not None:
                    self.on_error(exc)
                else:
                    raise
            cycles += 1
            last_cycle = time.perf_counter() - cycle_start
            total_cycle += last_cycle
            self._publish(
                cycles, actions, observations, started, last_cycle,
                "running" if not self._stop.is_set() else "stopped",
            )
            next_tick += interval
            sleep_for = next_tick - time.perf_counter()
            if sleep_for > 0:
                self._stop.wait(sleep_for)
            else:
                # We missed one or more scheduled ticks. Catch up immediately
                # rather than resetting the schedule; this prevents drift while
                # preserving the configured observation cadence.
                continue

        final = self._publish(cycles, actions, observations, started, last_cycle, "stopped")
        return final

    def _publish(
        self,
        cycles: int,
        actions: int,
        observations: int,
        started: float,
        last_cycle: float,
        state: str,
    ) -> ReflexTelemetry:
        elapsed = max(0.0, time.perf_counter() - started)
        telemetry = ReflexTelemetry(
            cycles=cycles,
            actions=actions,
            observations=observations,
            elapsed_seconds=elapsed,
            average_cycle_ms=(elapsed * 1000.0 / cycles) if cycles else 0.0,
            last_cycle_ms=last_cycle * 1000.0,
            target_hz=self.target_hz,
            state=state,
        )
        with self._lock:
            self._telemetry = telemetry
        if self.on_cycle is not None:
            self.on_cycle(telemetry)
        return telemetry


class AdaptiveReflexController(Generic[StateT, ActionT]):
    """Select an appropriate reflex frequency from observed work cost.

    The controller raises the loop toward the requested ceiling when cycles are
    cheap and backs off when observation/action cost approaches the budget. This
    keeps the fast path responsive without wasting CPU on an overloaded world.
    """

    def __init__(self, *, target_hz: float = 60.0, ceiling_hz: float = 240.0) -> None:
        if target_hz <= 0 or ceiling_hz < target_hz:
            raise ValueError("ceiling_hz must be at least target_hz")
        self.target_hz = float(target_hz)
        self.ceiling_hz = float(ceiling_hz)

    def tune(self, cycle_seconds: float) -> float:
        if cycle_seconds <= 0:
            self.target_hz = min(self.ceiling_hz, self.target_hz * 1.25)
            return self.target_hz
        budget = 1.0 / self.target_hz
        utilization = cycle_seconds / budget
        if utilization > 0.80:
            self.target_hz = max(10.0, self.target_hz * 0.75)
        elif utilization < 0.35:
            self.target_hz = min(self.ceiling_hz, self.target_hz * 1.15)
        return self.target_hz
