"""Device workload placement and failover policy."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping
import math

from ocean.device_registry import DeviceLifecycleController, DeviceProfile


@dataclass(frozen=True)
class Placement:
    device_id: str
    reason: str


class DeviceWorkloadScheduler:
    """Selects an eligible device without trusting remote capability claims."""

    def __init__(self, registry, lifecycle: DeviceLifecycleController):
        self._registry = registry
        self._lifecycle = lifecycle

    def eligible(self, account_id: str, devices: Iterable[DeviceProfile] | None = None) -> list[DeviceProfile]:
        candidates = list(devices if devices is not None else self._registry.list(account_id))
        result = []
        for device in candidates:
            if device.account_id != account_id or device.status != "online":
                continue
            if not self._lifecycle.can_schedule(account_id, device.id):
                continue
            if not self._registry.trusted_capabilities(device):
                continue
            result.append(device)
        return result

    @staticmethod
    def _score(device: DeviceProfile, metrics: Mapping[str, float] | None = None, *, require_low_power: bool = False) -> tuple[float, str]:
        m=metrics or {}
        latency=float(m.get(device.id+":latency_ms", m.get("latency_ms", 0.0)))
        load=float(m.get(device.id+":load", m.get("load", 0.0)))
        battery=float(m.get(device.id+":battery", m.get("battery", 100.0)))
        if not all(math.isfinite(x) for x in (latency,load,battery)): raise ValueError("device metrics must be finite")
        penalty=max(0.0,latency)*0.5+max(0.0,load)*20.0
        if require_low_power: penalty += max(0.0,50.0-battery)*2.0
        return penalty, f"measured latency/load/power score={penalty:.3f}"

    def place(self, account_id: str, *, require_world: bool = False, require_background: bool = True, metrics: Mapping[str, float] | None = None, require_low_power: bool = False) -> Placement:
        candidates = []
        for device in self.eligible(account_id):
            caps = self._registry.trusted_capabilities(device)
            if require_world and not caps.get("worlds", False): continue
            if require_background and not caps.get("background_execution", False): continue
            candidates.append(device)
        if not candidates: raise RuntimeError("no eligible device available")
        chosen=min(candidates, key=lambda d:self._score(d, metrics, require_low_power=require_low_power)[0])
        return Placement(chosen.id, self._score(chosen, metrics, require_low_power=require_low_power)[1])

    def failover(self, account_id: str, failed_device_id: str, *, require_world: bool = False) -> Placement:
        candidates = [d for d in self.eligible(account_id) if d.id != failed_device_id]
        for device in candidates:
            caps = self._registry.trusted_capabilities(device)
            if require_world and not caps.get("worlds", False):
                continue
            return Placement(device.id, f"failover from {failed_device_id}")
        raise RuntimeError("no failover device available")
