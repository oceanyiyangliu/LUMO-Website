"""Runtime performance primitives with explicit safety-preserving contracts."""
from __future__ import annotations
from dataclasses import dataclass
from threading import Event, RLock
from time import monotonic
from typing import Callable, Iterable, TypeVar
from .optimization_fabric import ConcurrencyPolicy

T=TypeVar('T')

@dataclass(frozen=True)
class Deadline:
    started_at: float
    deadline_at: float | None
    def remaining(self, now: float | None=None)->float|None:
        if self.deadline_at is None:return None
        return max(0.0,self.deadline_at-(monotonic() if now is None else now))
    def expired(self, now: float | None=None)->bool:
        r=self.remaining(now); return r is not None and r<=0

class CancellationToken:
    def __init__(self): self._event=Event()
    def cancel(self): self._event.set()
    @property
    def cancelled(self): return self._event.is_set()
    def raise_if_cancelled(self):
        if self.cancelled: raise RuntimeError('operation cancelled')

class Circuit:
    def __init__(self, failures=3, cooldown_seconds=5):
        if failures<=0 or cooldown_seconds<=0:raise ValueError('invalid circuit policy')
        self.failures=failures;self.cooldown=cooldown_seconds;self._count=0;self._opened=None;self._lock=RLock()
    def allow(self,now=None):
        with self._lock:
            if self._opened is None:return True
            t=monotonic() if now is None else now
            return t-self._opened>=self.cooldown
    def success(self):
        with self._lock:self._count=0;self._opened=None
    def failure(self,now=None):
        with self._lock:
            self._count+=1
            if self._count>=self.failures:self._opened=monotonic() if now is None else now
            return self._opened is not None

class AdaptivePoller:
    def __init__(self,min_seconds=.02,max_seconds=1.0):
        if not 0<min_seconds<=max_seconds:raise ValueError('invalid polling bounds')
        self.minimum=min_seconds;self.maximum=max_seconds;self.current=min_seconds
    def step(self,changed:bool):
        self.current=self.minimum if changed else min(self.maximum,self.current*2); return self.current
    def reset(self):self.current=self.minimum

def run_fast_path(operation: Callable[[],T], *, allowed: bool, verifier: Callable[[T], bool] | None = None)->T:
    """Run deterministic work without model overhead while preserving proof requirements."""
    if not allowed: raise PermissionError('fast path denied')
    result=operation()
    if verifier is None: raise RuntimeError('fast path requires an independent verifier')
    if not bool(verifier(result)): raise RuntimeError('fast path verification failed')
    return result

class ConcurrencyController:
    def __init__(self,max_workers=8):self.policy=ConcurrencyPolicy();self.max_workers=max_workers
    def workers(self,ready,cpu=.0,memory=.0,interactive=False):return self.policy.choose(ready=ready,cpu_pressure=cpu,memory_pressure=memory,interactive=interactive,max_workers=self.max_workers)
