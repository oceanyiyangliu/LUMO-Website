# Recovery Plane

The Recovery Plane is the autonomous failure-handling boundary of Ocean Agent OS.

## Contract

`TaskAssignmentFailed` is an immutable failure fact.

The Recovery Engine may respond by:

1. retrying on the same agent;
2. reassigning to another agent;
3. declaring recovery exhausted.

Recovery NEVER resurrects a failed assignment.

Every replacement assignment contains:

- `parent_assignment_id`
- recovery metadata
- the same task
- the same mission
- the inherited priority
- the inherited orchestration mode.

This creates durable assignment lineage suitable for:

- retry accounting
- agent failure analysis
- future adaptive policies
- mission-level replanning
- audit/replay
- self-healing orchestration.
