"""Deterministic recovery scheduling, worker health and degraded-mode policy."""
from __future__ import annotations
import hashlib, random, sqlite3, time
from pathlib import Path
from dataclasses import dataclass

@dataclass(frozen=True)
class BackoffPolicy:
    base_seconds:float=1.0; max_seconds:float=300.0; jitter_ratio:float=.2
    def delay(self,attempt:int,seed:str|None=None)->float:
        if attempt<0: raise ValueError("attempt must be non-negative")
        raw=min(self.max_seconds,self.base_seconds*(2**attempt)); r=random.Random(int(hashlib.sha256((seed or "").encode()).hexdigest()[:16],16)); return min(self.max_seconds,raw*(1+self.jitter_ratio*(r.random()*2-1)))

@dataclass(frozen=True)
class WorkerHealth:
    worker_id:str; last_heartbeat:float; active:bool=True
    def stale(self,now:float,timeout:float)->bool: return now-self.last_heartbeat>timeout

class WorkerReaper:
    def __init__(self,timeout:float=60): self.timeout=timeout
    def stale_workers(self,workers,now:float): return tuple(w.worker_id for w in workers if w.active and w.stale(now,self.timeout))

class ZombieProcessDetector:
    def __init__(self,allowed_pids=frozenset()): self.allowed=set(allowed_pids)
    def unexpected(self,pids): return tuple(sorted(set(pids)-self.allowed))

class DegradedMode:
    def __init__(self): self._reasons=set()
    @property
    def active(self): return bool(self._reasons)
    def enter(self,reason:str): self._reasons.add(reason)
    def leave(self,reason:str): self._reasons.discard(reason)
    def status(self): return {"active":self.active,"reasons":tuple(sorted(self._reasons))}


@dataclass(frozen=True)
class RecoveryIncidentReceipt:
    incident_id: str
    detected_at: float
    component: str
    status: str
    checks: tuple[str, ...] = ()
    details: str = ""


class DatabaseRecoveryChecker:
    """Read-only SQLite health checks plus a safe SQLite backup operation."""
    def __init__(self, path: str | Path):
        self.path = str(path)

    def check(self) -> RecoveryIncidentReceipt:
        checks=[]
        try:
            with sqlite3.connect(self.path, timeout=5) as db:
                result=str(db.execute("PRAGMA integrity_check").fetchone()[0])
                checks.append("integrity_check")
                status="healthy" if result == "ok" else "corrupt"
                return RecoveryIncidentReceipt(f"recovery-{int(time.time()*1000)}",time.time(),"sqlite",status,tuple(checks),result)
        except sqlite3.Error as exc:
            return RecoveryIncidentReceipt(f"recovery-{int(time.time()*1000)}",time.time(),"sqlite","unavailable",tuple(checks),str(exc))

    def backup(self, destination: str | Path) -> Path:
        destination=Path(destination)
        destination.parent.mkdir(parents=True,exist_ok=True)
        source=sqlite3.connect(self.path, timeout=5)
        target=sqlite3.connect(destination)
        try:
            source.backup(target)
            target.commit()
        finally:
            target.close(); source.close()
        return destination
