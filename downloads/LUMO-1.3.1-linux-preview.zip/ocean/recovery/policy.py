"""Recovery policy decisions."""

from __future__ import annotations

from dataclasses import dataclass

from ocean.domain.assignment import Assignment
from ocean.domain.enums import FailureCategory
from .types import RecoveryAction


# Failure categories that should never be retried or reassigned.
_PERMANENT_CATEGORIES = frozenset(
    {
        FailureCategory.INVALID_INPUT,
        FailureCategory.PERMISSION_GOVERNANCE,
        FailureCategory.CANCELLATION,
    }
)


@dataclass(frozen=True)
class DefaultRecoveryPolicy:
    """
    Deterministic recovery policy.

    Attempts are counted across assignment lineage for the same task.
    Retry happens first. Once retry capacity is exhausted, reassignment
    is attempted when enabled.

    Failure category governs recovery routing:
    - Permanent failures (invalid input, permission, cancellation) → CANCEL
    - Transient / timeout / unknown → RETRY then REASSIGN
    """

    retry_allowed: bool = True
    reassign_allowed: bool = True
    max_retries: int = 3

    def __post_init__(self) -> None:
        if self.max_retries < 0:
            raise ValueError("max_retries must be nonnegative")

    def decide(
        self,
        *,
        assignment: Assignment,
        attempt: int,
        failure_category: FailureCategory | None = None,
    ) -> RecoveryAction:
        if assignment.is_terminal() is False:
            raise ValueError("recovery requires a terminal assignment")

        if assignment.status.value != "failed":
            return RecoveryAction.IGNORE

        # Permanent failures should not be retried or reassigned.
        if failure_category in _PERMANENT_CATEGORIES:
            return RecoveryAction.CANCEL

        if self.retry_allowed and attempt <= self.max_retries:
            return RecoveryAction.RETRY

        if self.reassign_allowed:
            return RecoveryAction.REASSIGN

        return RecoveryAction.EXHAUSTED
