"""Autonomous recovery engine.

The recovery engine observes durable assignment failures and creates
replacement assignments. It never resurrects or mutates a failed
assignment.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Protocol

from ocean.domain.assignment import Assignment
from ocean.domain.enums import FailureCategory
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.domain.task import Task
from ocean.orchestration.orchestrator import Orchestrator
from ocean.orchestration.types import AssignmentRequest, OrchestrationMode
from persistence.repository import Repository

from .policy import DefaultRecoveryPolicy
from .types import RecoveryAction, RecoveryAttempt, RecoveryOutcome


class RecoveryAgentResolver(Protocol):
    """Select an alternative agent for a failed assignment."""

    def resolve(
        self,
        *,
        task: Task,
        failed_assignment: Assignment,
        attempt: int,
    ) -> str:
        ...


class ExecutionIntentProvider(Protocol):
    """Resolve the original execution intent for an assignment."""

    def get(
        self,
        *,
        assignment: Assignment,
        task: Task,
    ):
        ...


@dataclass(frozen=True)
class StaticRecoveryAgentResolver:
    """Simple deterministic resolver useful for early runtime deployments."""

    agent_id: str

    def resolve(
        self,
        *,
        task: Task,
        failed_assignment: Assignment,
        attempt: int,
    ) -> str:
        if not self.agent_id:
            raise ValueError("recovery agent_id must be nonempty")
        if self.agent_id == failed_assignment.agent_id:
            raise ValueError(
                "recovery resolver selected the same agent for reassignment"
            )
        return self.agent_id


class RecoveryEngine:
    """
    Event-driven autonomous recovery boundary.

    Responsibilities:
    - observe TaskAssignmentFailed
    - reconstruct attempt lineage from durable assignments
    - apply recovery policy
    - retry or reassign by creating a NEW assignment
    - dispatch the replacement execution

    Not responsible for:
    - scheduler internals
    - execution lifecycle
    - verification
    - mission replanning
    - mutating failed assignments
    """

    def __init__(
        self,
        *,
        event_bus: EventBus,
        assignments: Repository[Assignment],
        tasks: Repository[Task],
        orchestrator: Orchestrator,
        policy: DefaultRecoveryPolicy | None = None,
        agent_resolver: RecoveryAgentResolver | None = None,
        execution_intent_provider: ExecutionIntentProvider | None = None,
        subscribe: bool = True,
    ) -> None:
        if event_bus is None:
            raise ValueError("event_bus is required")
        if assignments is None:
            raise ValueError("assignments repository is required")
        if tasks is None:
            raise ValueError("tasks repository is required")
        if orchestrator is None:
            raise ValueError("orchestrator is required")

        self._event_bus = event_bus
        self._assignments = assignments
        self._tasks = tasks
        self._orchestrator = orchestrator
        self._policy = policy or DefaultRecoveryPolicy()
        self._agent_resolver = agent_resolver
        self._execution_intent_provider = execution_intent_provider

        if subscribe:
            self._event_bus.subscribe(
                "TaskAssignmentFailed",
                self._handle_assignment_failed,
            )

    @property
    def policy(self) -> DefaultRecoveryPolicy:
        return self._policy

    def recover(
        self,
        assignment_id: str,
        *,
        failure_category: FailureCategory | None = None,
    ) -> RecoveryOutcome:
        if not assignment_id:
            raise ValueError("assignment_id must be nonempty")

        assignment = self._assignments.get(assignment_id)
        if assignment is None:
            return RecoveryOutcome(
                action=RecoveryAction.IGNORE,
                source_assignment_id=assignment_id,
                reason="assignment not found",
            )

        if assignment.status.value != "failed":
            return RecoveryOutcome(
                action=RecoveryAction.IGNORE,
                source_assignment_id=assignment.id,
                reason="assignment is not failed",
            )

        task = self._tasks.get(assignment.task_id)
        if task is None:
            return RecoveryOutcome(
                action=RecoveryAction.EXHAUSTED,
                source_assignment_id=assignment.id,
                reason="task not found",
            )

        attempt = self._attempt_number(assignment)
        action = self._policy.decide(
            assignment=assignment,
            attempt=attempt,
            failure_category=failure_category,
        )

        if action is RecoveryAction.IGNORE:
            return RecoveryOutcome(
                action=action,
                source_assignment_id=assignment.id,
                attempt=attempt,
                reason="assignment is not recoverable",
                failure_category=failure_category,
            )

        if action is RecoveryAction.CANCEL:
            self._publish(
                "AssignmentRecoveryCancelled",
                assignment,
                {
                    "assignment_id": assignment.id,
                    "task_id": assignment.task_id,
                    "mission_id": assignment.mission_id,
                    "attempt": attempt,
                    "failure_category": (
                        failure_category.value
                        if failure_category
                        else FailureCategory.UNKNOWN.value
                    ),
                    "reason": "permanent failure; recovery cancelled",
                },
            )
            return RecoveryOutcome(
                action=action,
                source_assignment_id=assignment.id,
                attempt=attempt,
                reason="permanent failure; recovery cancelled",
                failure_category=failure_category,
            )

        if action is RecoveryAction.EXHAUSTED:
            self._publish(
                "AssignmentRecoveryExhausted",
                assignment,
                {
                    "assignment_id": assignment.id,
                    "task_id": assignment.task_id,
                    "mission_id": assignment.mission_id,
                    "attempt": attempt,
                    "reason": "recovery policy exhausted",
                },
            )
            return RecoveryOutcome(
                action=action,
                source_assignment_id=assignment.id,
                attempt=attempt,
                reason="recovery policy exhausted",
            )

        agent_id = assignment.agent_id

        if action is RecoveryAction.RETRY and failure_category in {
            FailureCategory.TIMEOUT,
            FailureCategory.CANCELLATION,
            FailureCategory.INFRASTRUCTURE,
            FailureCategory.RESOURCE_EXHAUSTION,
            FailureCategory.TRANSIENT,
            FailureCategory.UNKNOWN,
        }:
            alternate_agent_id = self._available_retry_agent(
                task=task,
                failed_assignment=assignment,
            )
            if alternate_agent_id is not None:
                agent_id = alternate_agent_id

        if action is RecoveryAction.REASSIGN:
            if self._agent_resolver is None:
                self._publish(
                    "AssignmentRecoveryExhausted",
                    assignment,
                    {
                        "assignment_id": assignment.id,
                        "task_id": assignment.task_id,
                        "mission_id": assignment.mission_id,
                        "attempt": attempt,
                        "reason": "reassignment requested but no resolver exists",
                    },
                )
                return RecoveryOutcome(
                    action=RecoveryAction.EXHAUSTED,
                    source_assignment_id=assignment.id,
                    attempt=attempt,
                    reason="reassignment requested but no resolver exists",
                )

            agent_id = self._agent_resolver.resolve(
                task=task,
                failed_assignment=assignment,
                attempt=attempt,
            )

        if self._execution_intent_provider is None:
            return RecoveryOutcome(
                action=RecoveryAction.EXHAUSTED,
                source_assignment_id=assignment.id,
                attempt=attempt,
                reason="execution intent provider is required for recovery",
            )

        intent = self._execution_intent_provider.get(
            assignment=assignment,
            task=task,
        )

        if intent is None:
            return RecoveryOutcome(
                action=RecoveryAction.EXHAUSTED,
                source_assignment_id=assignment.id,
                attempt=attempt,
                reason="original execution intent could not be reconstructed",
            )

        request = AssignmentRequest(
            task_id=assignment.task_id,
            agent_id=agent_id,
            mission_id=assignment.mission_id,
            mode=self._mode_from_assignment(assignment),
            priority=assignment.priority,
            parent_assignment_id=assignment.id,
            reason=(
                f"automatic recovery: {action.value} "
                f"of failed assignment {assignment.id}"
            ),
            metadata={
                **dict(assignment.metadata),
                "recovery": True,
                "recovery_action": action.value,
                "recovery_attempt": attempt,
                "recovery_parent_assignment_id": assignment.id,
                "recovery_source_agent_id": assignment.agent_id,
            },
        )

        assigned = self._orchestrator.assign(request)

        if not assigned.success or not assigned.assignment_id:
            self._publish(
                "AssignmentRecoveryFailed",
                assignment,
                {
                    "assignment_id": assignment.id,
                    "task_id": assignment.task_id,
                    "mission_id": assignment.mission_id,
                    "attempt": attempt,
                    "action": action.value,
                    "error": assigned.error,
                },
            )
            return RecoveryOutcome(
                action=action,
                source_assignment_id=assignment.id,
                attempt=attempt,
                reason=assigned.error or "replacement assignment failed",
            )

        replacement_id = assigned.assignment_id

        try:
            dispatched = self._orchestrator.dispatch(
                replacement_id,
                intent,
            )
        except Exception as exc:
            self._publish(
                "AssignmentRecoveryFailed",
                assignment,
                {
                    "assignment_id": assignment.id,
                    "replacement_assignment_id": replacement_id,
                    "task_id": assignment.task_id,
                    "mission_id": assignment.mission_id,
                    "attempt": attempt,
                    "action": action.value,
                    "error": str(exc),
                },
            )
            return RecoveryOutcome(
                action=action,
                source_assignment_id=assignment.id,
                replacement_assignment_id=replacement_id,
                attempt=attempt,
                reason=str(exc),
            )

        self._publish(
            "AssignmentRecoveryCreated",
            assignment,
            {
                "assignment_id": assignment.id,
                "replacement_assignment_id": replacement_id,
                "replacement_execution_id": dispatched.execution_id,
                "task_id": assignment.task_id,
                "mission_id": assignment.mission_id,
                "source_agent_id": assignment.agent_id,
                "replacement_agent_id": agent_id,
                "attempt": attempt,
                "action": action.value,
            },
        )

        return RecoveryOutcome(
            action=action,
            source_assignment_id=assignment.id,
            replacement_assignment_id=replacement_id,
            replacement_execution_id=dispatched.execution_id,
            attempt=attempt,
            success=True,
            metadata={
                "source_agent_id": assignment.agent_id,
                "replacement_agent_id": agent_id,
            },
        )

    def _handle_assignment_failed(self, event: Event) -> None:
        assignment_id = (
            event.payload.get("assignment_id")
            or event.causation_id
            or event.aggregate_id
        )

        if not assignment_id:
            raise ValueError("TaskAssignmentFailed event has no assignment identity")

        raw_category = event.payload.get("failure_category")
        failure_category = None
        if raw_category:
            try:
                failure_category = FailureCategory(raw_category)
            except ValueError:
                failure_category = FailureCategory.UNKNOWN

        self.recover(
            str(assignment_id),
            failure_category=failure_category,
        )

    def _available_retry_agent(
        self,
        *,
        task: Task,
        failed_assignment: Assignment,
    ) -> str | None:
        """Choose a different idle agent when the failed execution is still active."""
        runtime = self._orchestrator.ports.agent_runtime
        scheduler = getattr(runtime, "scheduler", None)
        if scheduler is None or failed_assignment.execution_id is None:
            return None

        capability = str(task.metadata.get("capability", ""))
        active_agent_ids = {
            str(item.request.agent_id)
            for item in scheduler.list()
            if item.state.value == "dispatched" and item.request.agent_id is not None
        }
        candidates = []
        for agent in runtime.agents():
            if str(agent.id) == str(failed_assignment.agent_id):
                continue
            if str(agent.id) in active_agent_ids:
                continue
            if agent.status.value not in {"idle", "background"}:
                continue
            if capability and not agent.can_perform(capability):
                continue
            candidates.append(agent)

        if not candidates:
            return None
        return str(min(candidates, key=lambda agent: str(agent.id)).id)

    def _attempt_number(self, assignment: Assignment) -> int:
        """
        Count prior failed assignments in the same lineage.

        The source failed assignment is attempt 0.
        Its first replacement is attempt 1, etc.
        """
        lineage_root = assignment.id
        current_parent = assignment.parent_assignment_id

        if current_parent:
            lineage_root = current_parent

        lineage = []
        current = assignment

        while current is not None:
            lineage.append(current)

            parent_id = current.parent_assignment_id
            if not parent_id:
                break

            current = self._assignments.get(parent_id)

        failed_count = sum(
            1 for item in lineage
            if item.status.value == "failed"
        )

        return max(0, failed_count - 1)

    @staticmethod
    def _mode_from_assignment(assignment: Assignment) -> OrchestrationMode:
        mode = assignment.mode
        if isinstance(mode, OrchestrationMode):
            return mode
        return OrchestrationMode(str(mode))

    def _publish(
        self,
        event_type: str,
        assignment: Assignment,
        payload: Mapping[str, Any],
    ) -> None:
        self._event_bus.publish(
            Event(
                type=event_type,
                payload=dict(payload),
                aggregate_type="assignment",
                aggregate_id=assignment.id,
                causation_id=assignment.id,
                correlation_id=assignment.mission_id,
                source="recovery",
            )
        )
