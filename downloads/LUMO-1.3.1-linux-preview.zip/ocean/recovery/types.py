"""Contracts for autonomous execution recovery."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping, Optional

from ocean.domain.enums import FailureCategory


class RecoveryAction(str, Enum):
    RETRY = "retry"
    REASSIGN = "reassign"
    EXHAUSTED = "exhausted"
    CANCEL = "cancel"
    IGNORE = "ignore"


@dataclass(frozen=True)
class RecoveryAttempt:
    """Durable lineage information for one recovery attempt."""

    assignment_id: str
    parent_assignment_id: Optional[str]
    task_id: str
    mission_id: Optional[str]
    agent_id: str
    attempt: int
    action: RecoveryAction
    reason: str
    failure_category: Optional[FailureCategory] = None
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class RecoveryOutcome:
    """Result of processing a failed assignment."""

    action: RecoveryAction
    source_assignment_id: str
    replacement_assignment_id: Optional[str] = None
    replacement_execution_id: Optional[str] = None
    attempt: int = 0
    success: bool = False
    reason: Optional[str] = None
    failure_category: Optional[FailureCategory] = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
