"""Tiny local bootstrap intelligence for LUMO first launch.

The bootstrap model is deliberately separate from the normal AI governor: it has
its own conservative, hardware-derived admission check so LUMO can initialize
when larger models cannot fit. It never raises the normal AI ceiling and never
quits applications or grants macOS permissions on its own.
"""
from __future__ import annotations
import json
import threading
import urllib.request
from dataclasses import dataclass
from .resources.intelligence_governor import sample_device_resources
from .resources.local_model_manager import LocalModelManager

@dataclass(frozen=True)
class BootstrapStatus:
    model: str
    installed: bool
    fits_now: bool
    healthy: bool
    state: str
    reason: str

class BootstrapIntelligence:
    MODEL = "qwen3:0.6b"
    RUNTIME_RAM_GIB = 0.85
    MIN_SYSTEM_HEADROOM_GIB = 2.0

    def __init__(self, manager: LocalModelManager | None = None) -> None:
        self.manager = manager or LocalModelManager()
        self._lock = threading.RLock()
        self._status = BootstrapStatus(self.MODEL, False, False, False, "starting", "not checked")

    def status(self) -> BootstrapStatus:
        with self._lock:
            try:
                installed = self.manager.is_installed(self.MODEL)
                device = sample_device_resources()
                available_gib = device.available_ram_bytes / 1024**3
                fits = installed and available_gib >= self.RUNTIME_RAM_GIB + self.MIN_SYSTEM_HEADROOM_GIB
                state = "ready" if fits and self._status.healthy else ("needs_model" if not installed else "waiting_for_memory")
                reason = ("bootstrap model ready" if state == "ready" else
                          "bootstrap model is not installed" if not installed else
                          f"need ~{self.RUNTIME_RAM_GIB + self.MIN_SYSTEM_HEADROOM_GIB:.1f} GiB available headroom")
                self._status = BootstrapStatus(self.MODEL, installed, fits, self._status.healthy, state, reason)
            except Exception as exc:
                self._status = BootstrapStatus(self.MODEL, False, False, False, "blocked", str(exc))
            return self._status

    def ensure_model(self, *, allow_download: bool = True) -> BootstrapStatus:
        with self._lock:
            try:
                if not self.manager.is_installed(self.MODEL):
                    if not allow_download:
                        return self.status()
                    self.manager.ensure_installed(self.MODEL, allow_download=True)
                return self.status()
            except Exception as exc:
                self._status = BootstrapStatus(self.MODEL, False, False, False, "error", str(exc))
                return self._status

    def health_check(self, timeout: float = 20.0) -> BootstrapStatus:
        with self._lock:
            status = self.status()
            if not status.fits_now:
                return status
            payload = json.dumps({
                "model": self.MODEL, "stream": False, "keep_alive": 0,
                "messages": [{"role": "system", "content": "You are LUMO bootstrap intelligence. Reply with exactly BOOT_OK."},
                             {"role": "user", "content": "Initialize."}],
                "think": False,
                "options": {"num_predict": 8},
            }).encode()
            try:
                req = urllib.request.Request(self.manager.base_url + "/api/chat", data=payload,
                                             headers={"Content-Type": "application/json"}, method="POST")
                with urllib.request.urlopen(req, timeout=timeout) as response:
                    body = json.loads(response.read().decode())
                content = str(body.get("message", {}).get("content", "")).strip()
                healthy = "BOOT_OK" in content
                self._status = BootstrapStatus(self.MODEL, True, True, healthy,
                    "ready" if healthy else "unhealthy", "health check passed" if healthy else "unexpected model response")
            except Exception as exc:
                self._status = BootstrapStatus(self.MODEL, True, True, False, "unhealthy", str(exc))
            return self._status
