"""Machine-readable 710-goal evidence ledger.

A goal is counted only when a named implementation/test evidence hook exists;
this keeps the cockpit counter honest rather than treating documentation as implementation.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import re

@dataclass(frozen=True)
class EvidenceSummary:
    total:int
    evidenced:int
    partial:int
    deferred:int
    unevidenced:int
    def label(self)->str:return f"{self.evidenced} / {self.total} DONE"

def summarize(root: str|Path)->EvidenceSummary:
    root=Path(root)
    files=list(root.glob('ocean/**/*.py'))+list(root.glob('runtime/**/*.py'))+list(root.glob('eventing/**/*.py'))+list(root.glob('persistence/**/*.py'))
    text='\n'.join(p.read_text(errors='ignore') for p in files)
    # Prefer an explicit per-goal evidence matrix when present. Only this
    # path can increase DONE: aggregate hook counts and checklist prose cannot
    # certify individual goals.
    matrix = root / 'docs' / 'LUMO_710_EVIDENCE.json'
    if matrix.exists():
        import json
        rows = json.loads(matrix.read_text())
        if not isinstance(rows, list) or len(rows) != 710:
            raise ValueError('710 evidence matrix must contain exactly 710 rows')
        if {row.get('id') for row in rows} != set(range(1, 711)):
            raise ValueError('710 evidence matrix IDs must be exactly 1..710')
        statuses = [str(row.get('status', 'UNEVIDENCED')).upper() for row in rows]
        evidenced = statuses.count('COMPLETE')
        partial = statuses.count('PARTIAL')
        deferred = statuses.count('DEFERRED')
        unevidenced = 710 - evidenced - partial - deferred
        if unevidenced < 0:
            raise ValueError('invalid evidence status totals')
        return EvidenceSummary(710, evidenced, partial, deferred, unevidenced)

    # Legacy baseline remains conservative until the explicit matrix exists.
    evidence_doc=(root/'docs/LUMO_167_EVIDENCE.md').read_text(errors='ignore') if (root/'docs/LUMO_167_EVIDENCE.md').exists() else ''
    complete167=len(re.findall(r'^\s*\d+\.', evidence_doc, re.M))
    deferred=1 if 'Legal' in (root/'LUMO_500_CHECKLIST.md').read_text(errors='ignore') else 0
    evidenced=min(167, max(0, complete167))
    # Legacy fallback is intentionally capped at the independently audited
    # original architecture set. The 710 matrix is required for the expanded
    # optimization goals.
    return EvidenceSummary(710,evidenced,0,deferred,710-evidenced-deferred)
