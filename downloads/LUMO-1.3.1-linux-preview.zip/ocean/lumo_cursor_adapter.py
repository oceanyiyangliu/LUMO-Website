"""Application-context adapter for LUMO virtual cursors.

The adapter targets a specific application process through macOS Accessibility
APIs. It never posts mouse or keyboard events and never changes the frontmost
application.
"""
from __future__ import annotations
from dataclasses import dataclass
import os
import subprocess
from typing import Protocol, Any
from ocean.lumo_cursor import CursorEvent, CursorEventType, LumoCursor

class CursorSurface(Protocol):
    def resolve(self, target: str) -> Any: ...
    def activate(self, target: str) -> Any: ...
    def hover(self, target: str) -> Any: ...
    def set_value(self, target: str, new_value: str) -> Any: ...

@dataclass(frozen=True)
class CursorExecutionResult:
    event: CursorEvent
    executed: bool
    detail: str = ""

class MacOSAccessibilitySurface:
    """Non-frontmost macOS UI surface backed by LumoAXBridge."""

    def __init__(self, application: str, bridge_path: str | None = None) -> None:
        self.application = application.strip()
        self.bridge_path = (bridge_path or os.getenv("LUMO_AX_BRIDGE", "")).strip()
        if not self.bridge_path:
            dev_bridge = os.path.join(os.path.dirname(os.path.dirname(__file__)), "tools", "LumoAXBridge")
            self.bridge_path = dev_bridge
        if not self.application:
            raise ValueError("application is required")
        if not os.path.isfile(self.bridge_path):
            raise FileNotFoundError(self.bridge_path)

    def _pid(self) -> int:
        result = subprocess.run(
            ["pgrep", "-x", self.application],
            capture_output=True, text=True, check=False, timeout=3,
        )
        if result.returncode != 0 or not result.stdout.strip():
            raise RuntimeError(f"application is not running: {self.application}")
        return int(result.stdout.splitlines()[0].strip())

    def resolve(self, target: str) -> str:
        # Target syntax: role|title|description|value
        parts = target.split("|", 3)
        while len(parts) < 4:
            parts.append("")
        role, title, description, value = parts
        rows = subprocess.run(
            [self.bridge_path, "list", str(self._pid())],
            capture_output=True, text=True, check=False, timeout=8,
        )
        if rows.returncode != 0:
            raise RuntimeError((rows.stderr or "Accessibility inspection failed").strip())
        for line in rows.stdout.splitlines():
            fields = line.split("\t", 3)
            while len(fields) < 4:
                fields.append("")
            if all(not expected or fields[i] == expected for i, expected in enumerate((role, title, description, value))):
                return line
        raise RuntimeError(f"target not found: {target}")

    def activate(self, target: str) -> str:
        parts = target.split("|", 3)
        while len(parts) < 4:
            parts.append("")
        result = subprocess.run(
            [self.bridge_path, "press", str(self._pid()), *parts],
            capture_output=True, text=True, check=False, timeout=8,
        )
        if result.returncode != 0:
            raise RuntimeError((result.stderr or "Accessibility action failed").strip())
        return result.stdout.strip()

    def set_value(self, target: str, new_value: str) -> str:
        parts = target.split("|", 3)
        while len(parts) < 4:
            parts.append("")
        result = subprocess.run(
            [self.bridge_path, "set", str(self._pid()), *parts, new_value],
            capture_output=True, text=True, check=False, timeout=8,
        )
        if result.returncode != 0:
            raise RuntimeError((result.stderr or "Accessibility value update failed").strip())
        return result.stdout.strip()

    def hover(self, target: str) -> str:
        raise RuntimeError("hover is not supported by AX without moving the physical pointer")

class VirtualCursorAdapter:
    """Executes cursor intents only through an explicit virtual surface."""

    def verify(self, event: CursorEvent) -> CursorExecutionResult:
        """Re-observe the virtual surface after a mutating action."""
        if event.type is CursorEventType.SET_VALUE:
            if not event.target:
                return CursorExecutionResult(event, False, "verification target is missing")
            expected = str((event.payload or {}).get("value", ""))
            target = event.target
            parts = target.split("|", 3)
            while len(parts) < 4:
                parts.append("")
            parts[3] = expected
            try:
                self.surface.resolve("|".join(parts))
                return CursorExecutionResult(event, True, "post-action value verified")
            except Exception as exc:
                return CursorExecutionResult(event, False, f"post-action verification failed: {exc}")
        if event.type is CursorEventType.CLICK:
            if not event.target:
                return CursorExecutionResult(event, False, "verification target is missing")
            try:
                self.surface.resolve(event.target)
                return CursorExecutionResult(event, True, "target remains resolvable after click")
            except Exception as exc:
                return CursorExecutionResult(event, False, f"post-click verification failed: {exc}")
        return CursorExecutionResult(event, True, "no mutation verification required")

    def __init__(self, surface: CursorSurface) -> None:
        self.surface = surface

    def execute(self, cursor: LumoCursor, event: CursorEvent) -> CursorExecutionResult:
        if event.type in {CursorEventType.MOVE, CursorEventType.HOVER, CursorEventType.CLICK, CursorEventType.SET_VALUE}:
            if not event.target:
                return CursorExecutionResult(event, False, "cursor target is required")
            try:
                resolved = self.surface.resolve(event.target)
                if event.type is CursorEventType.HOVER:
                    self.surface.hover(event.target)
                elif event.type is CursorEventType.CLICK:
                    self.surface.activate(event.target)
                elif event.type is CursorEventType.SET_VALUE:
                    payload = event.payload or {}
                    self.surface.set_value(event.target, str(payload.get("value", "")))
                return CursorExecutionResult(event, True, f"resolved={resolved!r}")
            except Exception as exc:
                return CursorExecutionResult(event, False, f"surface adapter blocked: {exc}")
        return CursorExecutionResult(event, True, "control event acknowledged")

__all__ = ["CursorExecutionResult", "CursorSurface", "MacOSAccessibilitySurface", "VirtualCursorAdapter"]
