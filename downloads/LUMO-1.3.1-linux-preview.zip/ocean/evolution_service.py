"""Continuous LUMO evolution orchestration with durable, gated releases."""
from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Mapping

from .fleet_rollout import EvolutionReleaseGate, FleetHealth, FleetRollout


@dataclass(frozen=True)
class EvolutionObservation:
    signal: str
    count: int
    severity: float = 1.0

    def __post_init__(self):
        if not self.signal or self.count < 0 or not 0 <= self.severity <= 1:
            raise ValueError("invalid evolution observation")


@dataclass(frozen=True)
class EvolutionCycle:
    cycle_id: int
    objective: str
    outcome: str
    version: str | None
    reason: str


class ContinuousEvolutionService:
    """Observe -> prioritize -> improve -> gate -> canary -> measure."""

    def __init__(self, state_path: Path, rollout: FleetRollout):
        self.path = Path(state_path)
        self.rollout = rollout
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def choose_objective(self, observations: list[EvolutionObservation]) -> str:
        if not observations:
            return "improve reliability without changing safety boundaries"
        best = max(observations, key=lambda x: (x.severity, x.count, x.signal))
        return f"reduce verified production failures related to {best.signal}"

    def run_cycle(
        self,
        observations: list[EvolutionObservation],
        version: str,
        improve: Callable[[str], Mapping[str, bool]],
    ) -> EvolutionCycle:
        objective = self.choose_objective(observations)
        gates = dict(improve(objective))
        decision = EvolutionReleaseGate.decide(version, gates)
        if decision.action != "canary":
            cycle = self._record(objective, decision.action, version, decision.reason)
            return cycle
        health = FleetHealth(
            sample_size=int(gates.get("fleet_sample_size", 0)),
            crash_rate=float(gates.get("fleet_crash_rate", 1.0)),
            verification_failure_rate=float(gates.get("fleet_verification_failure_rate", 1.0)),
            rollback_rate=float(gates.get("fleet_rollback_rate", 1.0)),
        )
        percent = self.rollout.stage(version, "canary", health)
        outcome = "canary" if percent else "frozen"
        return self._record(objective, outcome, version, f"rollout={percent}%")

    def _record(self, objective: str, outcome: str, version: str | None, reason: str) -> EvolutionCycle:
        state = self._read()
        cycle_id = int(state.get("cycle_id", 0)) + 1
        cycle = EvolutionCycle(cycle_id, objective, outcome, version, reason)
        self._write({
            "cycle_id": cycle_id,
            "last_cycle": cycle.__dict__,
            "updated_at": time.time(),
        })
        return cycle

    def _read(self) -> dict[str, object]:
        if not self.path.exists():
            return {}
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, state: Mapping[str, object]) -> None:
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(dict(state), sort_keys=True), encoding="utf-8")
        temp.replace(self.path)
    def start_loop(
        self,
        observe: Callable[[], list[EvolutionObservation]],
        improve: Callable[[str], Mapping[str, bool]],
        version_factory: Callable[[int], str],
        *,
        cycles: int = 1,
        sleep_seconds: float = 0.0,
    ) -> list[EvolutionCycle]:
        if cycles < 1 or sleep_seconds < 0:
            raise ValueError("invalid evolution loop bounds")
        results = []
        for _ in range(cycles):
            current = self._read()
            next_id = int(current.get("cycle_id", 0)) + 1
            results.append(self.run_cycle(
                observe(), version_factory(next_id), improve
            ))
            if sleep_seconds:
                time.sleep(sleep_seconds)
        return results
