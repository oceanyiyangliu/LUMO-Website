from __future__ import annotations

import base64
import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Optional

from ocean.capabilities.computer import MacOSComputerExecutor, computer_spec
from ocean.cognition import ActionBoundary, CognitiveRouter, CompletionContract, WorldContext
from ocean.assistant_runtime import ActionBudget, ActionClassifier, ActionRisk, ActionRecord, BudgetState, EvidenceLedger, LoopDetector, MissionVerifier, Observation, PlanLedger, RecoveryController, ProgressTracker, checkpoint, semantic_target_hint, summarize_failure, redact_arguments, redact_error
from ocean.advanced_capabilities import ExecutionTree, ExecutionTreeNode, SemanticStateGraph, SemanticState, ObservationCompressor, UndoManager, UndoReceipt, SkillRegistry, Skill, NavigationPlanner, state_diff, counterfactual
from ocean.optimization_fabric import OptimizationFabric
from ocean.domain.capability import CapabilityRegistry
from ocean.domain.enums import ApprovalDecision
from ocean.domain.policy import PolicyEngine
from runtime import ExecutionRuntime, ExecutorRegistry
from runtime.isolation import ProcessIsolationBackend
from runtime.types import ExecutionRequest, ExecutionResult


COMPUTER_TOOLS = [
    {
        "type": "function",
        "name": "screenshot",
        "description": "Capture the current Mac screen. Use this frequently to inspect the UI before deciding the next action.",
        "parameters": {"type": "object", "properties": {}, "additionalProperties": False},
        "strict": True,
    },
    {
        "type": "function",
        "name": "accessibility_snapshot",
        "description": "Inspect the frontmost app's accessible UI elements. Prefer this over coordinates when a target has a visible role/title/description.",
        "parameters": {"type": "object", "properties": {"max_elements": {"type": "integer", "minimum": 1, "maximum": 500}}, "required": ["max_elements"], "additionalProperties": False},
        "strict": True,
    },
    {
        "type": "function",
        "name": "click_element",
        "description": "Click a uniquely identified accessible UI element by role and title, description, or value. Use accessibility_snapshot first.",
        "parameters": {"type": "object", "properties": {"role": {"type": "string"}, "title": {"type": "string"}, "description": {"type": "string"}, "value": {"type": "string"}}, "required": ["role", "title", "description", "value"], "additionalProperties": False},
        "strict": True,
    },
    {
        "type": "function",
        "name": "open_url",
        "description": "Open a URL in the user's default browser.",
        "parameters": {"type": "object", "properties": {"url": {"type": "string"}}, "required": ["url"], "additionalProperties": False},
        "strict": True,
    },
    {
        "type": "function",
        "name": "launch_app",
        "description": "Launch a macOS application by name.",
        "parameters": {"type": "object", "properties": {"app": {"type": "string"}}, "required": ["app"], "additionalProperties": False},
        "strict": True,
    },
    {
        "type": "function",
        "name": "click",
        "description": "Click a screen coordinate. Always use a recent screenshot to choose coordinates.",
        "parameters": {"type": "object", "properties": {"x": {"type": "number"}, "y": {"type": "number"}}, "required": ["x", "y"], "additionalProperties": False},
        "strict": True,
    },
    {
        "type": "function",
        "name": "double_click",
        "description": "Double-click a screen coordinate. Always use a recent screenshot to choose coordinates.",
        "parameters": {"type": "object", "properties": {"x": {"type": "number"}, "y": {"type": "number"}}, "required": ["x", "y"], "additionalProperties": False},
        "strict": True,
    },
    {
        "type": "function",
        "name": "drag",
        "description": "Drag through screen coordinates. Use a recent screenshot and keep the path concise.",
        "parameters": {"type": "object", "properties": {"path": {"type": "array", "items": {"type": "object", "properties": {"x": {"type": "number"}, "y": {"type": "number"}}, "required": ["x", "y"], "additionalProperties": False}}}, "required": ["path"], "additionalProperties": False},
        "strict": True,
    },
    {
        "type": "function",
        "name": "move",
        "description": "Move the mouse to a screen coordinate without clicking.",
        "parameters": {"type": "object", "properties": {"x": {"type": "number"}, "y": {"type": "number"}}, "required": ["x", "y"], "additionalProperties": False},
        "strict": True,
    },
    {
        "type": "function",
        "name": "type_text",
        "description": "Paste text into the currently focused application.",
        "parameters": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"], "additionalProperties": False},
        "strict": True,
    },
    {
        "type": "function",
        "name": "key_press",
        "description": "Press a single keyboard key such as return, tab, escape, left, right, up, down, or a letter.",
        "parameters": {"type": "object", "properties": {"key": {"type": "string"}}, "required": ["key"], "additionalProperties": False},
        "strict": True,
    },
    {
        "type": "function",
        "name": "hotkey",
        "description": "Press a keyboard shortcut such as [command,a] or [command,c].",
        "parameters": {"type": "object", "properties": {"keys": {"type": "array", "items": {"type": "string"}}}, "required": ["keys"], "additionalProperties": False},
        "strict": True,
    },
    {
        "type": "function",
        "name": "scroll",
        "description": "Scroll the focused application vertically. Positive and negative values move in opposite directions. Keep amount between -100 and 100.",
        "parameters": {"type": "object", "properties": {"amount": {"type": "integer", "minimum": -100, "maximum": 100}}, "required": ["amount"], "additionalProperties": False},
        "strict": True,
    },
    {
        "type": "function",
        "name": "action_batch",
        "description": "Execute a short ordered batch of safe deterministic GUI actions without another reasoning round between them. Maximum 12 actions. Do not batch uncertain or consequential actions.",
        "parameters": {
            "type": "object",
            "properties": {
                "actions": {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": 12,
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string", "enum": ["click", "double_click", "drag", "move", "accessibility_snapshot", "click_element", "type_text", "key_press", "hotkey", "scroll", "open_url", "launch_app", "wait"]},
                            "arguments": {
                                "type": "object",
                                "properties": {
                                    "x": {"type": ["number", "null"]}, "y": {"type": ["number", "null"]},
                                    "path": {"type": ["array", "null"], "items": {"type": "object", "properties": {"x": {"type": "number"}, "y": {"type": "number"}}, "required": ["x", "y"], "additionalProperties": False}},
                                    "text": {"type": ["string", "null"]}, "key": {"type": ["string", "null"]},
                                    "keys": {"type": ["array", "null"], "items": {"type": "string"}},
                                    "amount": {"type": ["integer", "null"]}, "seconds": {"type": ["number", "null"]},
                                    "url": {"type": ["string", "null"]}, "app": {"type": ["string", "null"]},
                                    "role": {"type": ["string", "null"]}, "title": {"type": ["string", "null"]}, "description": {"type": ["string", "null"]}, "value": {"type": ["string", "null"]}, "max_elements": {"type": ["integer", "null"]}
                                },
                                "required": ["x", "y", "path", "text", "key", "keys", "amount", "seconds", "url", "app", "role", "title", "description", "value", "max_elements"],
                                "additionalProperties": False
                            }
                        },
                        "required": ["name", "arguments"],
                        "additionalProperties": False
                    }
                }
            },
            "required": ["actions"],
            "additionalProperties": False
        },
        "strict": True,
    },
    {
        "type": "function",
        "name": "wait",
        "description": "Wait briefly for the UI to settle, normally 0.5 to 5 seconds.",
        "parameters": {"type": "object", "properties": {"seconds": {"type": "number"}}, "required": ["seconds"], "additionalProperties": False},
        "strict": True,
    },
]


@dataclass(frozen=True)
class ComputerTaskResult:
    status: str
    steps: int
    message: str
    last_screenshot: Optional[str] = None


class ComputerUseAgent:
    """Vision-guided local computer agent for real desktop applications.

    The model decides actions; LUMO executes every action through the local
    computer capability. This keeps GUI control inside the LUMO execution
    boundary instead of granting the model arbitrary shell access.
    """

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        model: str = "auto",
        executor: Optional[MacOSComputerExecutor] = None,
        world_manager: Any = None,
        world_id: Optional[str] = None,
        account_id: Optional[str] = None,
        max_steps: int = 80,
        action_timeout: float = 20.0,
        allow_actions: bool = False,
        on_step: Optional[Callable[[dict[str, Any]], None]] = None,
        on_cursor: Optional[Callable[[dict[str, Any]], None]] = None,
        on_status: Optional[Callable[[dict[str, Any]], None]] = None,
        execution_guard: Optional[Callable[[], bool]] = None,
        execution_pause: Optional[Callable[[], bool]] = None,
        budget: Optional[ActionBudget] = None,
        allow_consequential_actions: bool = False,
        on_checkpoint: Optional[Callable[[dict[str, Any]], None]] = None,
        optimization: Optional[OptimizationFabric] = None,
    ) -> None:
        if max_steps <= 0:
            raise ValueError("max_steps must be positive")
        self.requested_model = model
        self.model = model
        if (world_manager is None) != (world_id is None):
            raise ValueError("world_manager and world_id must be supplied together")
        if world_manager is not None and executor is not None:
            raise ValueError("isolated World agents cannot accept a host computer executor")
        self.world_manager = world_manager
        self.world_id = world_id
        self.account_id = account_id
        self.executor = executor or (MacOSComputerExecutor() if world_manager is None else None)
        if self.executor is None and self.world_manager is None:
            raise ValueError("a computer executor or isolated World is required")
        self.max_steps = max_steps
        self.action_timeout = action_timeout
        self.allow_actions = allow_actions
        self.on_step = on_step
        self.on_cursor = on_cursor
        self.on_status = on_status
        self.execution_guard = execution_guard
        self.execution_pause = execution_pause
        self.budget = budget or ActionBudget(max_actions=max_steps * 4 + 20)
        self.allow_consequential_actions = allow_consequential_actions
        self.on_checkpoint = on_checkpoint
        self.optimization = optimization or OptimizationFabric()
        self._budget_state = BudgetState()
        self._evidence = EvidenceLedger()
        self._observations: list[Observation] = []
        self._actions: list[ActionRecord] = []
        self._loop_detector = LoopDetector()
        self._plan: PlanLedger | None = None
        self._recovery = RecoveryController(max_retries=self.budget.max_retries, max_replans=self.budget.max_replans)
        self._progress = ProgressTracker()
        self._execution_tree = ExecutionTree()
        self._state_graph = SemanticStateGraph()
        self._observation_compressor = ObservationCompressor()
        self._undo = UndoManager()
        self._skills = SkillRegistry()
        self._skills.register(Skill(
            skill_id="computer.navigation",
            name="Conservative semantic navigation",
            version="1.0.0",
            steps=({"operation": "accessibility_snapshot"}, {"operation": "choose_exact_target"},),
            risk="low",
            metadata={"selection": "risk_then_latency_then_stable_id"},
        ))
        self._navigation = NavigationPlanner()
        self._last_status_progress = 0.0
        self._previous_semantic_state: dict[str, Any] = {}
        self.cognitive_router = CognitiveRouter()
        self.action_boundary = ActionBoundary()
        capabilities = CapabilityRegistry()
        capabilities.register(computer_spec())
        policy = PolicyEngine()
        if allow_actions:
            for operation in computer_spec().operations:
                policy.register_override(
                    "computer", operation, lambda _ctx: ApprovalDecision.AUTOMATIC_LOGGED
                )
        executors = ExecutorRegistry()
        if self.executor is not None:
            executors.register("computer_macos", self.executor)
        self.runtime = ExecutionRuntime(
            capabilities=capabilities,
            policy=policy,
            executors=executors,
            isolation=ProcessIsolationBackend(),
        )

    @staticmethod
    def _screenshot_data(path: str) -> str:
        encoded = base64.b64encode(Path(path).read_bytes()).decode("ascii")
        return f"data:image/png;base64,{encoded}"

    def _translate_action(self, name: str, arguments: dict[str, Any], geometry: dict[str, float]) -> dict[str, Any]:
        if name not in {"click", "double_click", "move", "drag"}:
            return dict(arguments)
        image_width = geometry.get("image_width", 0)
        image_height = geometry.get("image_height", 0)
        capture_width = geometry.get("capture_width", image_width)
        capture_height = geometry.get("capture_height", image_height)
        if image_width <= 0 or image_height <= 0 or capture_width <= 0 or capture_height <= 0:
            return dict(arguments)
        scale_x = capture_width / image_width
        scale_y = capture_height / image_height
        origin_x = geometry.get("origin_x", 0)
        origin_y = geometry.get("origin_y", 0)
        translated = dict(arguments)
        if name == "drag":
            translated["path"] = [
                {"x": origin_x + float(point["x"]) * scale_x, "y": origin_y + float(point["y"]) * scale_y}
                for point in arguments.get("path", [])
            ]
        else:
            translated["x"] = origin_x + float(arguments["x"]) * scale_x
            translated["y"] = origin_y + float(arguments["y"]) * scale_y
        return translated

    def _execute(self, name: str, arguments: dict[str, Any], *, task_id: str, geometry: Optional[dict[str, float]] = None) -> ExecutionResult:
        started = time.monotonic()
        if self.execution_guard is not None and not self.execution_guard():
            return ExecutionResult.failed("execution guard denied the computer action")
        allowed, reason = self._budget_state.allow(name, self.budget)
        if not allowed:
            return ExecutionResult.failed(reason)
        risk = ActionClassifier.classify(name, arguments)
        if risk is ActionRisk.HIGH and not self.allow_consequential_actions:
            return ExecutionResult.failed("high-consequence computer action requires explicit confirmation")
        if not self.allow_actions and name not in {"screenshot", "wait"}:
            return ExecutionResult.failed("computer actions are disabled for this agent")
        if name == "screenshot":
            args = {"timeout": self.action_timeout}
        else:
            translated = self._translate_action(name, arguments, geometry or {})
            args = {**translated, "timeout": self.action_timeout}
            if name in {"move", "click", "double_click"} and self.on_cursor is not None:
                try:
                    self.on_cursor({"operation": name, "x": float(translated["x"]), "y": float(translated["y"])})
                except Exception:
                    pass
            elif name == "drag" and self.on_cursor is not None:
                try:
                    path = translated.get("path") or []
                    if path:
                        self.on_cursor({"operation": name, "x": float(path[-1]["x"]), "y": float(path[-1]["y"])})
                except Exception:
                    pass
        request = ExecutionRequest(
            task_id=task_id,
            capability="computer",
            operation=name,
            principal_id="lumo-computer-agent",
            mission_id=task_id,
            arguments=args,
            metadata={
                **({"world_id": self.world_id} if self.world_id and self.world_manager is not None else {}),
                **({"account_id": self.account_id} if self.world_id and self.world_manager is not None and self.account_id is not None else {}),
                "approval_granted": bool(self.allow_actions),
                "clipboard_approved": bool(self.allow_actions),
            },
            source="lumo.computer_use",
        )
        if self.world_manager is not None and self.world_id is not None:
            result = self.world_manager.execute(self.world_id, request)
        else:
            result = self.runtime.execute(request)
        if result.success:
            key_count = len(str(arguments.get("text", ""))) if name == "type_text" else len(arguments.get("keys", [])) if name == "hotkey" else (1 if name == "key_press" else 0)
            self._budget_state.record(name, key_count=key_count)
        elapsed_ms = (time.monotonic() - started) * 1000.0
        self.optimization.performance.record(f"computer:{name}", elapsed_ms, bool(result.success))
        self.optimization.costs.record(task_id, "computer_action", 0.0, operation=name, latency_ms=elapsed_ms, verified=bool(result.success))
        return result

    def _record_observation(self, result: ExecutionResult, path: str, task_id: str) -> None:
        payload = result.result or {}
        try:
            image_digest = __import__("hashlib").sha256(Path(path).read_bytes()).hexdigest()
        except OSError:
            image_digest = path
        digest = LoopDetector.state_key(str(payload.get("application", "")), str(payload.get("window", "")), image_digest)
        obs = Observation(len(self._observations) + 1, time.time(), path, str(payload.get("application", "")), str(payload.get("window", "")), digest)
        self._observations.append(obs)
        semantic_state = {"application": obs.application, "window": obs.window, "digest": digest}
        diff = state_diff(self._previous_semantic_state, semantic_state)
        self._previous_semantic_state = dict(semantic_state)
        self._state_graph.observe(SemanticState(
            entity_id=f"{task_id}:screen",
            attributes=semantic_state,
        ))
        self._evidence.add("state_diff", {
            "added": dict(diff.added),
            "removed": dict(diff.removed),
            "changed": {k: list(v) for k, v in diff.changed.items()},
        }, source="semantic_state", confidence=1.0)
        looped, reason = self._loop_detector.observe(digest, "screenshot")
        if looped:
            self._emit_status(phase="recovery", message="Repeated visual state detected; forcing reorientation", steps=self._budget_state.actions, progress=min(.98, self._last_status_progress), task_id=task_id, extra={"reason": reason})
        self._evidence.add("screen", {"application": obs.application, "window": obs.window, "screenshot": path}, source="screenshot", confidence=.95)

    def _record_action(self, action_id: str, name: str, arguments: dict[str, Any], result: ExecutionResult, screenshot: str, world: WorldContext) -> None:
        risk = ActionClassifier.classify(name, arguments)
        try:
            image_digest = __import__("hashlib").sha256(Path(screenshot).read_bytes()).hexdigest()
        except OSError:
            image_digest = screenshot
        record = ActionRecord(action_id, name, redact_arguments(arguments), result.success, time.time(), LoopDetector.state_key(world.application, world.window, image_digest), redact_error(result.error), risk)
        self._actions.append(record)
        skill = self._skills.select(
            goal=name,
            risk="low" if risk is ActionRisk.LOW else risk.value,
            context={"application": world.application, "window": world.window},
        )
        if skill is not None:
            self._evidence.add(
                "skill_selection",
                {"skill_id": skill.skill_id, "version": skill.version, "operation": name},
                source="skill_registry",
                confidence=1.0,
            )
        if name == "click_element":
            candidate = {
                "id": str(arguments.get("title") or arguments.get("description") or arguments.get("value") or "target"),
                "risk": 0,
                "latency": 0,
            }
            selected = self._navigation.choose([candidate], goal=name)
            self._evidence.add(
                "navigation_selection",
                {"target_id": selected["id"], "strategy": "risk_then_latency_then_stable_id"},
                source="navigation_planner",
                confidence=1.0,
            )
        self._execution_tree.add(ExecutionTreeNode(
            node_id=action_id,
            parent_id=self._actions[-2].action_id if len(self._actions) > 1 else None,
            status="succeeded" if result.success else "failed",
            metadata={"operation": name, "risk": risk.value},
        ))
        if result.success:
            self._evidence.add("action", {"operation": name, "action_id": action_id, "target": semantic_target_hint(world.application, world.window, name)}, source="runtime", confidence=1.0)
            self._undo.register(action_id, {"operation": "manual_review_required", "source_action": name}, reversible=name in {"move", "rename", "type_text"}, expected_state=self._previous_semantic_state, consequential=risk == ActionRisk.HIGH)
        else:
            self._evidence.add("failure", summarize_failure(result.error), source=name, confidence=1.0)

    def _save_checkpoint(self, task_id: str) -> None:
        if self._plan is None or self.on_checkpoint is None:
            return
        cp = checkpoint(task_id, self._plan, self._observations, self._actions, self._evidence)
        compressed = self._observation_compressor.compress(cp.observations)
        self.on_checkpoint({
            "task_id": task_id,
            "created_at": cp.created_at,
            "plan": cp.plan,
            "observations": compressed,
            "actions": cp.actions,
            "evidence": cp.evidence,
            "execution_tree": [n.__dict__ for n in self._execution_tree.snapshot()],
            "semantic_state": self._state_graph.snapshot(),
            "recovery_learning": [r.__dict__ for r in self._recovery.learning.export()],
        })

    def _emit_status(self, *, phase: str, message: str, steps: int, progress: float, task_id: str, extra: Optional[dict[str, Any]] = None) -> None:
        if self.on_status is None:
            return
        normalized_progress = max(0.0, min(1.0, progress))
        self._last_status_progress = max(self._last_status_progress, normalized_progress)
        payload = {
            "task_id": task_id,
            "phase": phase,
            "message": message,
            "step": steps,
            "progress": round(self._last_status_progress, 4),
        }
        if extra:
            payload.update(extra)
        self.on_status(payload)

    def _select_local_vision_model(self) -> str:
        from ocean.resources.local_model_manager import LocalModelManager
        from ocean.resources.intelligence_governor import LocalResourceGovernor

        inventory = {m.name: m for m in LocalModelManager().inventory_live()}
        safe_gib = LocalResourceGovernor().snapshot().safe_ai_ram_bytes / 1024**3
        # Only actual vision-capable models may enter the GUI control loop.
        # Text-only Qwen3 models are never acceptable fallbacks.
        preferred = ("qwen2.5vl:7b",)
        for name in preferred:
            item = inventory.get(name)
            if item is not None and item.size_gib <= safe_gib + 1e-6:
                return name
        raise RuntimeError("no installed local vision-capable model safely fits the current resource budget")

    def _reasoning_effort(self, *, escalation: bool, objective: str = "") -> str:
        return "high" if escalation else "low"

    def run(self, objective: str, *, mission_id: Optional[str] = None) -> ComputerTaskResult:
        if not objective.strip():
            raise ValueError("objective must not be empty")

        from ocean.local_model_client import LocalOllamaResponsesClient

        task_id = mission_id or "computer-task"
        completion_contract = CompletionContract.from_objective(objective)
        self._plan = PlanLedger(objective)
        observed_operations: list[str] = []
        if self.requested_model == "auto":
            self.cognitive_router.route(objective)
            self.model = self._select_local_vision_model()
        client = LocalOllamaResponsesClient(model=self.model)
        started_at = time.monotonic()
        instructions = (
            "You are LUMO's local computer-use agent. Treat the user's objective as a strict mission boundary, "
            "not a suggestion. Complete only that objective through the actual macOS GUI. Inspect a fresh "
            "Use the current screenshot and world state to choose the shortest reliable path. For obvious, "
            "safe, deterministic consecutive GUI actions, prefer the action_batch tool so they execute in one "
            "runtime turn. Do not batch uncertain actions or actions whose target depends on a changed screen. "
            "Do NOT click notifications, inboxes, badges, profiles, unrelated sidebar items, unrelated documents, "
            "or other visually salient controls merely because they are visible. Do NOT explore, browse, or "
            "improve unrelated content. Every click, keypress, scroll, or navigation must have a clear direct "
            "purpose for the objective. If the UI changes unexpectedly, stop making guesses: take a screenshot, "
            "re-orient to the objective, and continue from the new state. Never claim an action happened unless "
            "the tool result or a later screenshot confirms it. Prefer the shortest reliable path. If a login, "
            "payment, account-security change, or other sensitive confirmation is required, stop and report that "
            "the user must take over. When the objective is genuinely complete, stop immediately; do not keep "
            "exploring. Do not use shell commands; the computer tools are the execution boundary."
        )
        first = self._execute("screenshot", {}, task_id=task_id)
        if not first.success:
            return ComputerTaskResult("failed", 0, first.error or "initial screenshot failed")

        screenshot_path = str(first.result["path"])
        self._record_observation(first, screenshot_path, task_id)
        self._save_checkpoint(task_id)
        self._emit_status(phase="observing", message="Inspecting the current screen", steps=0, progress=0.02, task_id=task_id, extra={"world": {"application": first.result.get("application", ""), "window": first.result.get("window", "")}})
        self._emit_status(phase="reasoning", message="Choosing the next action", steps=0, progress=0.08, task_id=task_id, extra={"reasoning_effort": self._reasoning_effort(escalation=False, objective=objective)})
        response = client.create(
            model=self.model,
            instructions=instructions,
            input=[
                {"role": "user", "content": [
                    {"type": "input_text", "text": objective},
                    {"type": "input_image", "image_url": self._screenshot_data(screenshot_path)},
                ]}
            ],
            tools=COMPUTER_TOOLS,
            tool_choice="auto",
            parallel_tool_calls=False,
            max_output_tokens=1024,
        )

        steps = 0
        last_screenshot = screenshot_path
        screenshot_geometry = {
            "origin_x": int(first.result.get("origin_x", 0)),
            "origin_y": int(first.result.get("origin_y", 0)),
            "capture_width": float(first.result.get("capture_width", first.result.get("width", 0)) or 0),
            "capture_height": float(first.result.get("capture_height", first.result.get("height", 0)) or 0),
            "image_width": float(first.result.get("width", 0) or 0),
            "image_height": float(first.result.get("height", 0) or 0),
        }
        world = WorldContext(
            application=str(first.result.get("application", "")),
            window=str(first.result.get("window", "")),
            image_width=int(first.result.get("width", 0) or 0),
            image_height=int(first.result.get("height", 0) or 0),
            origin_x=int(first.result.get("origin_x", 0)),
            origin_y=int(first.result.get("origin_y", 0)),
        )
        last_operation: Optional[str] = None
        repeated_operation_count = 0
        completion_recoveries = 0
        tool_calls = 0
        last_progress = 0.08
        while steps < self.max_steps and tool_calls < (self.max_steps * 4 + 20):
            if self.execution_pause is not None and self.execution_pause():
                self._emit_status(phase="paused", message="Computer task paused; waiting for resume", steps=steps, progress=last_progress, task_id=task_id)
                while self.execution_pause():
                    if self.execution_guard is not None and not self.execution_guard():
                        return ComputerTaskResult("stopped", steps, "Computer task stopped while paused", last_screenshot)
                    time.sleep(0.25)
                self._emit_status(phase="resuming", message="Computer task resumed from checkpointed state", steps=steps, progress=last_progress, task_id=task_id)
            calls = [item for item in response.output if getattr(item, "type", None) == "function_call"]
            if not calls:
                text = getattr(response, "output_text", "") or ""
                if text.strip().upper().startswith("COMPLETED:"):
                    if completion_contract.satisfied(observed_operations):
                        verified, missing = MissionVerifier.verify(completion_contract, observed_operations, self._evidence)
                        if verified:
                            if self._plan is not None:
                                self._plan.update("root", status="completed")
                            self._evidence.add("completion", text, source="independent_verifier", confidence=1.0)
                            self._save_checkpoint(task_id)
                            self._emit_status(phase="completed", message=text, steps=steps, progress=1.0, task_id=task_id, extra={"latency_seconds": round(time.monotonic() - started_at, 3), "verified_operations": list(observed_operations), "evidence_count": len(self._evidence.items)})
                            return ComputerTaskResult("completed", steps, text, last_screenshot)
                    if completion_recoveries < 2:
                        completion_recoveries += 1
                        self._emit_status(phase="recovery", message="Completion claim rejected: requested action has not been evidenced; re-checking", steps=steps, progress=min(0.98, 0.85 + completion_recoveries * 0.05), task_id=task_id, extra={"reasoning_effort": "high", "required_action_families": sorted(completion_contract.required_families), "observed_operations": list(observed_operations)})
                        follow = self._execute("screenshot", {}, task_id=task_id, geometry=screenshot_geometry)
                        steps += 1
                        if not follow.success:
                            return ComputerTaskResult("failed", steps, follow.error or "completion verification screenshot failed", last_screenshot)
                        last_screenshot = str(follow.result["path"])
                        screenshot_geometry = {"origin_x": int(follow.result.get("origin_x", 0)), "origin_y": int(follow.result.get("origin_y", 0)), "capture_width": float(follow.result.get("capture_width", follow.result.get("width", 0)) or 0), "capture_height": float(follow.result.get("capture_height", follow.result.get("height", 0)) or 0), "image_width": float(follow.result.get("width", 0) or 0), "image_height": float(follow.result.get("height", 0) or 0)}
                        world = WorldContext(application=str(follow.result.get("application", "")), window=str(follow.result.get("window", "")), image_width=int(follow.result.get("width", 0) or 0), image_height=int(follow.result.get("height", 0) or 0), origin_x=int(follow.result.get("origin_x", 0)), origin_y=int(follow.result.get("origin_y", 0)))
                        response = client.create(model=self.model, instructions=instructions, previous_response_id=response.id, input=[{"role": "user", "content": [{"type": "input_text", "text": "Your completion claim was rejected because the requested action has not been evidenced. The visible result may have existed before this task. You must now perform the requested action, not merely observe the existing result. Required action families: " + ", ".join(sorted(completion_contract.required_families)) + ". Do not stop until the action is actually executed and the resulting state is verified."}, {"type": "input_image", "image_url": self._screenshot_data(last_screenshot)}]}], tools=COMPUTER_TOOLS, tool_choice="auto", parallel_tool_calls=False, max_output_tokens=768)
                        continue
                if completion_recoveries < 2:
                    completion_recoveries += 1
                    self._emit_status(phase="recovery", message="The model stopped without proving completion; re-checking the screen", steps=steps, progress=min(0.98, 0.85 + completion_recoveries * 0.05), task_id=task_id, extra={"reasoning_effort": "high"})
                    follow = self._execute("screenshot", {}, task_id=task_id, geometry=screenshot_geometry)
                    tool_calls += 1
                    if not follow.success:
                        return ComputerTaskResult("failed", steps, follow.error or "completion verification screenshot failed", last_screenshot)
                    last_screenshot = str(follow.result["path"])
                    screenshot_geometry = {
                        "origin_x": int(follow.result.get("origin_x", 0)),
                        "origin_y": int(follow.result.get("origin_y", 0)),
                        "capture_width": float(follow.result.get("capture_width", follow.result.get("width", 0)) or 0),
                        "capture_height": float(follow.result.get("capture_height", follow.result.get("height", 0)) or 0),
                        "image_width": float(follow.result.get("width", 0) or 0),
                        "image_height": float(follow.result.get("height", 0) or 0),
                    }
                    world = WorldContext(application=str(follow.result.get("application", "")), window=str(follow.result.get("window", "")), image_width=int(follow.result.get("width", 0) or 0), image_height=int(follow.result.get("height", 0) or 0), origin_x=int(follow.result.get("origin_x", 0)), origin_y=int(follow.result.get("origin_y", 0)))
                    response = client.create(
                        model=self.model,
                        instructions=instructions,
                        previous_response_id=response.id,
                        input=[{"role": "user", "content": [
                            {"type": "input_text", "text": "You stopped without proving completion. This is not a completion. Reinspect the fresh screenshot and continue operating the GUI. Do not stop until the objective's success condition is visibly verified. If it is verified, respond only with COMPLETED: followed by the verified result."},
                            {"type": "input_image", "image_url": self._screenshot_data(last_screenshot)},
                        ]}],
                        tools=COMPUTER_TOOLS,
                        tool_choice="auto",
                        parallel_tool_calls=False,
                        max_output_tokens=768,
                    )
                    continue
                message = text or "Model stopped without verifying completion."
                self._emit_status(phase="blocked", message=message, steps=steps, progress=min(0.99, 0.98), task_id=task_id)
                return ComputerTaskResult("blocked", steps, message, last_screenshot)

            outputs = []
            next_image = None
            escalation = False
            for call in calls:
                name = str(call.name)
                arguments = json.loads(call.arguments or "{}")
                tool_calls += 1
                if name == "action_batch":
                    batch = arguments.get("actions", [])
                    if not isinstance(batch, list) or not batch or len(batch) > 12:
                        outputs.append({"type": "function_call_output", "call_id": call.call_id, "output": json.dumps({"success": False, "error": "action_batch must contain 1-12 actions"}, default=str)})
                        escalation = True
                        continue
                    batch_results = []
                    batch_failed = False
                    for item in batch:
                        sub_name = str(item.get("name", ""))
                        sub_args = item.get("arguments", {})
                        if sub_name in {"screenshot", "action_batch"}:
                            batch_results.append({"operation": sub_name, "success": False, "error": "nested screenshot/action_batch is not allowed"})
                            batch_failed = True
                            break
                        decision = self.cognitive_router.route(objective, failures=completion_recoveries, action_risk="high" if sub_name not in {"wait"} else "low")
                        allowed, boundary_reason = self.action_boundary.validate(sub_name, sub_args, world=world, objective=objective)
                        self._emit_status(phase="executing" if allowed else "blocked", message=(f"Executing {sub_name}" if allowed else f"Blocked {sub_name}: {boundary_reason}"), steps=steps, progress=min(0.95, 0.08 + steps / max(self.max_steps, 1) * 0.82), task_id=task_id, extra={"operation": sub_name, "cognition_mode": decision.mode.value, "reasoning_effort": decision.effort, "batch": True})
                        result = self._execute(sub_name, sub_args, task_id=task_id, geometry=screenshot_geometry) if allowed else ExecutionResult.failed(f"action blocked by LUMO boundary: {boundary_reason}")
                        steps += 1
                        tool_calls += 1
                        if result.success and CompletionContract.family(sub_name) is not None:
                            observed_operations.append(sub_name)
                        self._progress.record(sub_name, result.success)
                        self._record_action(f"{call.call_id}:{steps}", sub_name, sub_args, result, last_screenshot, world)
                        self._save_checkpoint(task_id)
                        batch_results.append({"operation": sub_name, "success": result.success, "result": result.result, "error": result.error})
                        if self.on_step is not None:
                            self.on_step({"step": steps, "operation": sub_name, "success": result.success, "result": result.result, "error": result.error, "batch": True})
                        self._emit_status(phase="verifying", message=f"Verifying {sub_name}", steps=steps, progress=min(0.96, 0.08 + steps / max(self.max_steps, 1) * 0.84), task_id=task_id, extra={"operation": sub_name, "success": result.success, "batch": True})
                        if not result.success:
                            batch_failed = True
                            escalation = True
                            break
                    outputs.append({"type": "function_call_output", "call_id": call.call_id, "output": json.dumps({"success": not batch_failed, "results": batch_results}, default=str)})
                    # One checkpoint per batch, rather than one screenshot per action.
                    follow = self._execute("screenshot", {}, task_id=task_id, geometry=screenshot_geometry)
                    tool_calls += 1
                    if follow.success:
                        next_image = str(follow.result["path"])
                        screenshot_geometry = {"origin_x": int(follow.result.get("origin_x", 0)), "origin_y": int(follow.result.get("origin_y", 0)), "capture_width": float(follow.result.get("capture_width", follow.result.get("width", 0)) or 0), "capture_height": float(follow.result.get("capture_height", follow.result.get("height", 0)) or 0), "image_width": float(follow.result.get("width", 0) or 0), "image_height": float(follow.result.get("height", 0) or 0)}
                        world = WorldContext(application=str(follow.result.get("application", "")), window=str(follow.result.get("window", "")), image_width=int(follow.result.get("width", 0) or 0), image_height=int(follow.result.get("height", 0) or 0), origin_x=int(follow.result.get("origin_x", 0)), origin_y=int(follow.result.get("origin_y", 0)))
                    else:
                        return ComputerTaskResult("failed", steps, follow.error or "post-batch screenshot failed", last_screenshot)
                    continue

                decision = self.cognitive_router.route(objective, failures=completion_recoveries, action_risk="high" if name not in {"screenshot", "wait"} else "low")
                allowed, boundary_reason = self.action_boundary.validate(name, arguments, world=world, objective=objective)
                self._emit_status(phase="executing" if allowed else "blocked", message=(f"Executing {name}" if allowed else f"Blocked {name}: {boundary_reason}"), steps=steps, progress=min(0.95, 0.08 + steps / max(self.max_steps, 1) * 0.82), task_id=task_id, extra={"operation": name, "cognition_mode": decision.mode.value, "reasoning_effort": decision.effort})
                if allowed:
                    result = self._execute(name, arguments, task_id=task_id, geometry=screenshot_geometry)
                else:
                    result = ExecutionResult.failed(f"action blocked by LUMO boundary: {boundary_reason}")
                if name != "screenshot":
                    steps += 1
                if name == last_operation:
                    repeated_operation_count += 1
                else:
                    repeated_operation_count = 0
                last_operation = name
                if result.success and CompletionContract.family(name) is not None:
                    observed_operations.append(name)
                self._progress.record(name, result.success)
                self._record_action(call.call_id, name, arguments, result, last_screenshot, world)
                self._loop_detector.observe(self._actions[-1].evidence_digest, name)
                self._save_checkpoint(task_id)
                escalation = escalation or (not result.success) or repeated_operation_count >= 2
                payload = {"success": result.success, "result": result.result, "error": result.error}
                if self.on_step is not None:
                    self.on_step({"step": steps, "operation": name, "success": result.success, "result": result.result, "error": result.error})
                self._emit_status(phase="verifying", message=f"Verifying {name}", steps=steps, progress=min(0.96, 0.08 + steps / max(self.max_steps, 1) * 0.84), task_id=task_id, extra={"operation": name, "success": result.success})
                outputs.append({"type": "function_call_output", "call_id": call.call_id, "output": json.dumps(payload, default=str)})
                if name == "screenshot" and result.success:
                    next_image = str(result.result["path"])
                    self._record_observation(result, next_image, task_id)
                    self._save_checkpoint(task_id)
                    screenshot_geometry = {
                        "origin_x": int(result.result.get("origin_x", 0)),
                        "origin_y": int(result.result.get("origin_y", 0)),
                        "capture_width": float(result.result.get("capture_width", result.result.get("width", 0)) or 0),
                        "capture_height": float(result.result.get("capture_height", result.result.get("height", 0)) or 0),
                        "image_width": float(result.result.get("width", 0) or 0),
                        "image_height": float(result.result.get("height", 0) or 0),
                    }
                    world = WorldContext(application=str(result.result.get("application", "")), window=str(result.result.get("window", "")), image_width=int(result.result.get("width", 0) or 0), image_height=int(result.result.get("height", 0) or 0), origin_x=int(result.result.get("origin_x", 0)), origin_y=int(result.result.get("origin_y", 0)))
                elif result.success:
                    follow = self._execute("screenshot", {}, task_id=task_id, geometry=screenshot_geometry)
                    tool_calls += 1
                    if follow.success:
                        next_image = str(follow.result["path"])
                        screenshot_geometry = {
                            "origin_x": int(follow.result.get("origin_x", 0)),
                            "origin_y": int(follow.result.get("origin_y", 0)),
                            "capture_width": float(follow.result.get("capture_width", follow.result.get("width", 0)) or 0),
                            "capture_height": float(follow.result.get("capture_height", follow.result.get("height", 0)) or 0),
                            "image_width": float(follow.result.get("width", 0) or 0),
                            "image_height": float(follow.result.get("height", 0) or 0),
                        }
                        world = WorldContext(application=str(follow.result.get("application", "")), window=str(follow.result.get("window", "")), image_width=int(follow.result.get("width", 0) or 0), image_height=int(follow.result.get("height", 0) or 0), origin_x=int(follow.result.get("origin_x", 0)), origin_y=int(follow.result.get("origin_y", 0)))
                    else:
                        return ComputerTaskResult("failed", steps, follow.error or "post-action screenshot failed", last_screenshot)
                if not result.success:
                    self._evidence.add("failure", summarize_failure(result.error), source=name, confidence=1.0)
                    recovery = self._recovery.failure(result.error)
                    self._progress.record(name, False)
                    self._emit_status(phase="recovery" if recovery != "abort" else "blocked", message=f"Recovery decision: {recovery}", steps=steps, progress=min(.98, self._last_status_progress), task_id=task_id, extra={"recovery": self._recovery.snapshot(), "progress_state": self._progress.snapshot()})
                    if recovery == "handoff":
                        return ComputerTaskResult("blocked", steps, result.error or "User takeover required", last_screenshot)
                    if recovery == "abort":
                        return ComputerTaskResult("failed", steps, result.error or f"{name} failed", last_screenshot)
                    # Capability failures are observations, not automatically terminal failures.
                    # Re-observe immediately and let cognition recover/replan from the real error.
                    escalation = True
                    follow = self._execute("screenshot", {}, task_id=task_id, geometry=screenshot_geometry)
                    tool_calls += 1
                    if follow.success:
                        next_image = str(follow.result["path"])
                        screenshot_geometry = {
                            "origin_x": int(follow.result.get("origin_x", 0)),
                            "origin_y": int(follow.result.get("origin_y", 0)),
                            "capture_width": float(follow.result.get("capture_width", follow.result.get("width", 0)) or 0),
                            "capture_height": float(follow.result.get("capture_height", follow.result.get("height", 0)) or 0),
                            "image_width": float(follow.result.get("width", 0) or 0),
                            "image_height": float(follow.result.get("height", 0) or 0),
                        }
                        world = WorldContext(application=str(follow.result.get("application", "")), window=str(follow.result.get("window", "")), image_width=int(follow.result.get("width", 0) or 0), image_height=int(follow.result.get("height", 0) or 0), origin_x=int(follow.result.get("origin_x", 0)), origin_y=int(follow.result.get("origin_y", 0)))
                    else:
                        return ComputerTaskResult("failed", steps, follow.error or result.error or f"{name} failed", last_screenshot)
                    # Stop processing this model turn; the next turn gets the error + fresh screen.
                    break

            if next_image:
                last_screenshot = next_image
                outputs.append({"role": "user", "content": [{"type": "input_image", "image_url": self._screenshot_data(next_image)}]})

            self._emit_status(phase="reasoning", message="Evaluating the fresh screen", steps=steps, progress=min(0.97, 0.10 + steps / max(self.max_steps, 1) * 0.82), task_id=task_id, extra={"reasoning_effort": self._reasoning_effort(escalation=escalation), "latency_seconds": round(time.monotonic() - started_at, 3)})
            response = client.create(
                model=self.model,
                instructions=instructions,
                previous_response_id=response.id,
                input=outputs,
                tools=COMPUTER_TOOLS,
                tool_choice="auto",
                parallel_tool_calls=False,
                max_output_tokens=768,
            )

        message = f"Stopped after {self.max_steps} computer actions; objective may be incomplete."
        self._emit_status(phase="step_limit", message=message, steps=steps, progress=1.0, task_id=task_id, extra={"latency_seconds": round(time.monotonic() - started_at, 3), "budget": self._budget_state.__dict__.copy(), "evidence_count": len(self._evidence.items)})
        return ComputerTaskResult("step_limit", steps, message, last_screenshot)
