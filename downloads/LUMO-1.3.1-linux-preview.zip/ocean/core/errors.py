"""Ocean's error hierarchy.

Kept flat and specific on purpose -- callers (schedulers, agents, policy
enforcement) need to tell failure *kinds* apart (RULE 18: failures must not
silently disappear; brief section 62 distinguishes failure classes).
"""
from __future__ import annotations


class OceanError(Exception):
    """Base class for all Ocean domain errors."""


class InvalidStateTransition(OceanError):
    """Raised when an entity's state machine rejects a transition."""


class ValidationError(OceanError):
    """Raised when domain invariants are violated (e.g. malformed input)."""


class UnknownCapability(OceanError):
    """Raised when a capability name is not present in the registry."""


class UnknownOperation(OceanError):
    """Raised when an operation is not present on a known capability."""


class PolicyViolation(OceanError):
    """Raised when an action is attempted without the required approval."""


class DuplicateRegistration(OceanError):
    """Raised when something is registered under a name already in use."""


class InvalidCapabilityInput(OceanError):
    """Raised when capability arguments do not match its declared schema."""


class InvalidCapabilityOutput(OceanError):
    """Raised when an executor result does not match its declared schema."""
