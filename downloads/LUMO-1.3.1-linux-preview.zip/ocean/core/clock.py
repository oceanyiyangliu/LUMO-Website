"""Injectable clock.

Domain objects never call datetime.now() directly. They accept a Clock so
tests can freeze/control time instead of sleeping or racing wall-clock time.
"""
from __future__ import annotations

from datetime import datetime, timezone


class Clock:
    def now(self) -> datetime:
        return datetime.now(timezone.utc)


class FixedClock(Clock):
    """Test double: returns a fixed instant, optionally advanceable."""

    def __init__(self, at: datetime | None = None) -> None:
        self._at = at or datetime.now(timezone.utc)

    def now(self) -> datetime:
        return self._at

    def advance(self, seconds: float) -> None:
        from datetime import timedelta

        self._at = self._at + timedelta(seconds=seconds)


SYSTEM_CLOCK = Clock()
