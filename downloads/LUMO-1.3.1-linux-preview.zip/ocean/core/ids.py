"""Typed identity generation.

Every entity in Ocean gets a prefixed, sortable-enough id so that a bare id
string tells you what kind of thing it names -- useful for logs, traces, and
debugging (see brief RULE 15: every important action must be attributable).
"""
from __future__ import annotations

import uuid


def new_id(prefix: str) -> str:
    if not prefix or not prefix.isascii() or not prefix.replace("_", "").isalnum():
        raise ValueError(f"invalid id prefix: {prefix!r}")
    return f"{prefix}_{uuid.uuid4().hex[:12]}"
