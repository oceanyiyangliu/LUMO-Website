"""Generic, reusable finite-state machine used by every domain entity.

Every domain object (Task, Mission, Agent, Execution) has its own status enum
and its own allowed-transition table, but the *mechanism* for validating a
transition is identical. Centralizing it means every entity's lifecycle is
provably consistent and we're not hand-rolling if/else transition checks in
five different files.
"""
from __future__ import annotations

from typing import Dict, Generic, Set, TypeVar

from .errors import InvalidStateTransition

S = TypeVar("S")


class StateMachine(Generic[S]):
    def __init__(self, transitions: Dict[S, Set[S]], terminal_states: Set[S]):
        self._transitions = transitions
        self._terminal = set(terminal_states)

    def validate(self, current: S, new: S) -> None:
        if current == new:
            return
        if current in self._terminal:
            raise InvalidStateTransition(
                f"{current!r} is a terminal state; cannot transition to {new!r}"
            )
        allowed = self._transitions.get(current, set())
        if new not in allowed:
            allowed_names = sorted(getattr(a, "value", str(a)) for a in allowed)
            raise InvalidStateTransition(
                f"cannot transition from {current!r} to {new!r} "
                f"(allowed: {allowed_names or 'none'})"
            )

    def is_terminal(self, state: S) -> bool:
        return state in self._terminal
