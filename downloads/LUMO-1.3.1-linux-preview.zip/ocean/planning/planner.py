from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Protocol

from ocean.domain.decision import Decision
from ocean.domain.mission import Mission
from ocean.domain.task import Task


@dataclass(frozen=True)
class PlanningContext:
    """Immutable snapshot supplied to a planner."""

    mission: Mission
    tasks: tuple[Task, ...] = ()
    prior_decisions: tuple[Decision, ...] = ()
    observations: tuple[Any, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.mission is None:
            raise ValueError("mission is required")

        object.__setattr__(self, "tasks", tuple(self.tasks))
        object.__setattr__(self, "prior_decisions", tuple(self.prior_decisions))
        object.__setattr__(self, "observations", tuple(self.observations))
        object.__setattr__(self, "metadata", dict(self.metadata))


@dataclass(frozen=True)
class PlanningRequest:
    """Request to produce or revise a mission plan."""

    mission_id: str
    objective: str
    context: PlanningContext
    revision_reason: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.mission_id or not self.mission_id.strip():
            raise ValueError("mission_id must be non-empty")
        if not self.objective or not self.objective.strip():
            raise ValueError("objective must be non-empty")
        if self.context.mission.id != self.mission_id:
            raise ValueError(
                "planning context mission does not match mission_id"
            )
        object.__setattr__(self, "metadata", dict(self.metadata))


@dataclass(frozen=True)
class PlanningResult:
    """Planner output before persistence by PlanningService."""

    decision: Decision
    nodes: tuple[Any, ...] = ()
    edges: tuple[Any, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.decision is None:
            raise ValueError("decision is required")

        object.__setattr__(self, "nodes", tuple(self.nodes))
        object.__setattr__(self, "edges", tuple(self.edges))
        object.__setattr__(self, "metadata", dict(self.metadata))


class Planner(Protocol):
    """Contract implemented by concrete planning engines."""

    def plan(self, request: PlanningRequest) -> PlanningResult:
        ...
