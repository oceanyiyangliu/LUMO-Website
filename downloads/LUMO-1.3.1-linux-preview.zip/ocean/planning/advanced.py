"""Deterministic planning diagnostics and constraint evaluation."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence


@dataclass(frozen=True)
class CapabilityProfile:
    name: str
    operations: tuple[str, ...] = ()
    capabilities: tuple[str, ...] = ()
    max_context: int | None = None
    privacy: str = "standard"
    models: tuple[str, ...] = ()


@dataclass(frozen=True)
class PlanCandidate:
    plan_id: str
    steps: tuple[Mapping[str, Any], ...]
    confidence: float = 0.0
    rationale: str = ""

    def __post_init__(self):
        if not 0 <= self.confidence <= 1:
            raise ValueError("confidence must be between 0 and 1")

    @property
    def fingerprint(self) -> str:
        raw=json.dumps(list(self.steps),sort_keys=True,separators=(",",":"),default=str).encode()
        return hashlib.sha256(raw).hexdigest()


@dataclass(frozen=True)
class PlanConstraints:
    required_capabilities: frozenset[str] = frozenset()
    privacy: str = "standard"
    max_context: int | None = None
    max_latency_seconds: float | None = None
    max_cost: float | None = None
    device_affinity: frozenset[str] = frozenset()
    world_kind: str | None = None
    model_requirements: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class PlanDiagnostics:
    valid: bool
    errors: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
    resource_estimate: Mapping[str, float] = field(default_factory=dict)
    deadline_feasible: bool = True
    budget_feasible: bool = True
    privacy_feasible: bool = True


def discover_capabilities(profiles: Sequence[CapabilityProfile]) -> dict[str, CapabilityProfile]:
    return {p.name: p for p in profiles}


def validate_plan(candidate: PlanCandidate, capabilities: Mapping[str, CapabilityProfile], constraints: PlanConstraints) -> PlanDiagnostics:
    errors=[]; warnings=[]; required=set(constraints.required_capabilities)
    used=set()
    resource={"steps": float(len(candidate.steps)), "estimated_latency_seconds": 0.0, "estimated_cost": 0.0}
    for i, step in enumerate(candidate.steps):
        cap=str(step.get("capability", "")); used.add(cap)
        if not cap or cap not in capabilities: errors.append(f"step {i}: unknown capability {cap!r}"); continue
        profile=capabilities[cap]
        op=step.get("operation")
        if op and profile.operations and str(op) not in profile.operations: errors.append(f"step {i}: unsupported operation {op!r} for {cap!r}")
        latency=float(step.get("estimated_latency_seconds", 1.0)); cost=float(step.get("estimated_cost", 0.0))
        if latency < 0 or cost < 0: errors.append(f"step {i}: negative resource estimate")
        resource["estimated_latency_seconds"] += latency; resource["estimated_cost"] += cost
        if constraints.max_context is not None and profile.max_context is not None and profile.max_context < constraints.max_context: errors.append(f"step {i}: context requirement exceeds capability")
        if constraints.privacy == "local_only" and profile.privacy != "local": errors.append(f"step {i}: violates local-only privacy")
    missing=required-used
    errors.extend(f"missing required capability {x!r}" for x in sorted(missing))
    deadline_ok=constraints.max_latency_seconds is None or resource["estimated_latency_seconds"] <= constraints.max_latency_seconds
    budget_ok=constraints.max_cost is None or resource["estimated_cost"] <= constraints.max_cost
    if not deadline_ok: errors.append("estimated plan latency exceeds deadline budget")
    if not budget_ok: errors.append("estimated plan cost exceeds budget")
    return PlanDiagnostics(not errors,tuple(errors),tuple(warnings),resource,deadline_ok,budget_ok,constraints.privacy != "local_only" or all(capabilities.get(c,CapabilityProfile(c,privacy="unknown")).privacy == "local" for c in used))


def diff_plans(a: PlanCandidate, b: PlanCandidate) -> dict[str, Any]:
    max_len = max(len(a.steps), len(b.steps))
    added=[]; removed=[]; changed=[]
    for i in range(max_len):
        left = dict(a.steps[i]) if i < len(a.steps) else None
        right = dict(b.steps[i]) if i < len(b.steps) else None
        if left is None and right is not None: added.append(right)
        elif right is None and left is not None: removed.append(left)
        elif left != right: changed.append((left,right))
    return {"from": a.plan_id, "to": b.plan_id, "added": added, "removed": removed, "changed": changed, "fingerprint_changed": a.fingerprint != b.fingerprint}


def critical_path_seconds(candidate: PlanCandidate) -> float:
    """Compute dependency-aware critical-path latency from step metadata."""
    finish={}; steps_by_id={str(s.get("id", i)): s for i,s in enumerate(candidate.steps)}
    for i, step in enumerate(candidate.steps):
        sid=str(step.get("id", i)); deps=tuple(str(x) for x in step.get("depends_on", ()))
        duration=max(0.0,float(step.get("estimated_latency_seconds",1.0)))
        finish[sid]=duration + max((finish.get(d,0.0) for d in deps),default=0.0)
    return max(finish.values(),default=0.0)


def deadline_slack(candidate: PlanCandidate, deadline_seconds: float) -> float:
    return float(deadline_seconds) - critical_path_seconds(candidate)


def deterministic_plan_receipt(candidate: PlanCandidate, diagnostics: PlanDiagnostics) -> dict[str, Any]:
    return {"plan_id":candidate.plan_id,"fingerprint":candidate.fingerprint,"confidence":candidate.confidence,"valid":diagnostics.valid,"errors":list(diagnostics.errors),"warnings":list(diagnostics.warnings),"resources":dict(diagnostics.resource_estimate)}

@dataclass(frozen=True)
class PlanScore:
    """Explainable score vector; no hidden global ranking authority."""
    feasibility: float = 0.0
    resource_efficiency: float = 0.0
    confidence: float = 0.0
    privacy: float = 0.0
    def total(self) -> float: return self.feasibility + self.resource_efficiency + self.confidence + self.privacy

@dataclass(frozen=True)
class PlanApprovalGate:
    required: bool
    reason: str
    risk: str = "important"
    approved: bool = False
    approver_id: str | None = None
    def executable(self)->bool: return not self.required or self.approved

def score_plan(candidate: PlanCandidate, diagnostics: PlanDiagnostics) -> PlanScore:
    feasibility=1.0 if diagnostics.valid else 0.0
    estimate=diagnostics.resource_estimate
    efficiency=1.0/(1.0+estimate.get("estimated_latency_seconds",0.0)+estimate.get("estimated_cost",0.0))
    privacy=1.0 if diagnostics.privacy_feasible else 0.0
    return PlanScore(feasibility,efficiency,candidate.confidence,privacy)
