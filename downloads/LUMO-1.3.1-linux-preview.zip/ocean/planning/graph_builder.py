from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from ocean.domain.mission import Mission
from ocean.domain.task import Task
from ocean.domain.work_graph import (
    WorkGraph,
    WorkEdge,
    WorkEdgeKind,
    WorkNode,
    WorkNodeKind,
)


@dataclass(frozen=True)
class WorkGraphBuildResult:
    """Deterministic work structure produced from mission tasks."""

    nodes: tuple[WorkNode, ...]
    edges: tuple[WorkEdge, ...]


class WorkGraphBuilder:
    """Construct a validated work graph from mission task state.

    This is deliberately separate from WorkGraph itself.

    WorkGraph is an immutable domain structure.
    WorkGraphBuilder owns cross-aggregate construction rules such as:

    - task membership in the mission
    - dependency references
    - task -> graph-node translation

    It does not persist anything and does not execute tasks.
    """

    def build(
        self,
        mission: Mission,
        tasks: Iterable[Task],
    ) -> WorkGraphBuildResult:
        if mission is None:
            raise ValueError("mission is required")

        task_list = tuple(tasks)

        task_by_id: dict[str, Task] = {}

        for task in task_list:
            if task is None:
                raise ValueError("tasks cannot contain None")

            if task.id in task_by_id:
                raise ValueError(
                    f"duplicate task in work graph input: {task.id!r}"
                )

            if task.mission_id != mission.id:
                raise ValueError(
                    f"task {task.id!r} belongs to mission "
                    f"{task.mission_id!r}, not {mission.id!r}"
                )

            task_by_id[task.id] = task

        nodes = tuple(
            WorkNode(
                id=f"node-{task.id}",
                kind=WorkNodeKind.TASK,
                task_id=task.id,
            )
            for task in task_list
        )

        node_by_task_id = {
            node.task_id: node
            for node in nodes
        }

        edges: list[WorkEdge] = []

        for task in task_list:
            for dependency_id in sorted(task.depends_on):
                if dependency_id not in task_by_id:
                    raise ValueError(
                        f"task {task.id!r} depends on unknown task "
                        f"{dependency_id!r}"
                    )

                source = node_by_task_id[dependency_id]
                target = node_by_task_id[task.id]

                edges.append(
                    WorkEdge(
                        id=f"edge-{dependency_id}-{task.id}",
                        source_node_id=source.id,
                        target_node_id=target.id,
                        kind=WorkEdgeKind.DEPENDENCY,
                    )
                )

        edges_tuple = tuple(edges)

        # Reuse the canonical WorkGraph dependency invariant without
        # constructing a temporary WorkGraph.
        WorkGraph._validate_dependency_acyclic(
            nodes,
            edges_tuple,
        )

        return WorkGraphBuildResult(
            nodes=nodes,
            edges=edges_tuple,
        )
