from __future__ import annotations

from typing import Iterable, Optional

from ocean.core.ids import new_id
from ocean.domain.decision import Decision
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.domain.mission import Mission
from ocean.domain.plan import PlanRevision, PlanStatus
from ocean.domain.work_graph import WorkEdge, WorkGraph, WorkNode, WorkNodeKind
from ocean.planning.graph_builder import WorkGraphBuilder
from ocean.planning.planner import Planner, PlanningContext, PlanningRequest, PlanningResult
from persistence.repository import Repository


class PlanningService:
    """Application boundary for durable mission planning.

    PlanningService owns planning workflows and invariants. Planner engines
    produce decisions and work structures; this service owns persistence,
    lifecycle, validation, and durable events.
    """

    def __init__(
        self,
        *,
        missions: Repository[Mission],
        decisions: Repository[Decision],
        tasks: Repository,
        work_graphs: Repository[WorkGraph],
        plan_revisions: Repository[PlanRevision],
        events: EventBus,
    ) -> None:
        self._missions = missions
        self._decisions = decisions
        self._tasks = tasks
        self._work_graphs = work_graphs
        self._plan_revisions = plan_revisions
        self._events = events
        self._graph_builder = WorkGraphBuilder()

    @property
    def tasks(self) -> Repository:
        return self._tasks


    def create_decision(
        self,
        *,
        mission_id: str,
        kind: str,
        objective: str,
        rationale: str,
        alternatives: Iterable[str] = (),
        selected_option: Optional[str] = None,
        confidence: Optional[float] = None,
        evidence: Iterable[str] = (),
        metadata: Optional[dict] = None,
        decision_id: Optional[str] = None,
    ) -> Decision:
        self._require_mission(mission_id)

        decision = Decision(
            mission_id=mission_id,
            kind=kind,
            objective=objective,
            rationale=rationale,
            alternatives=tuple(alternatives),
            selected_option=selected_option,
            confidence=confidence,
            evidence=tuple(evidence),
            metadata=metadata or {},
            id=decision_id or new_id("decision"),
        )

        if self._decisions.get(decision.id) is not None:
            raise ValueError(f"decision already exists: {decision.id!r}")

        self._decisions.save(decision)
        self._publish(
            Event(
                type="DecisionCreated",
                payload={
                    "id": decision.id,
                    "mission_id": decision.mission_id,
                    "kind": decision.kind,
                    "objective": decision.objective,
                    "rationale": decision.rationale,
                    "alternatives": list(decision.alternatives),
                    "selected_option": decision.selected_option,
                    "confidence": decision.confidence,
                    "evidence": list(decision.evidence),
                    "metadata": dict(decision.metadata),
                },
                aggregate_type="decision",
                aggregate_id=decision.id,
                correlation_id=mission_id,
                source="planning",
            )
        )
        return decision

    def create_plan(
        self,
        *,
        mission_id: str,
        decision_id: str,
        nodes: Iterable[WorkNode],
        edges: Iterable[WorkEdge] = (),
        revision: Optional[int] = None,
        parent_revision_id: Optional[str] = None,
        reason: Optional[str] = None,
        metadata: Optional[dict] = None,
        plan_id: Optional[str] = None,
        graph_id: Optional[str] = None,
    ) -> tuple[PlanRevision, WorkGraph]:
        self._require_mission(mission_id)

        decision = self._decisions.get(decision_id)
        if decision is None:
            raise ValueError(f"unknown decision: {decision_id!r}")

        if decision.mission_id != mission_id:
            raise ValueError(
                f"decision {decision_id!r} belongs to mission "
                f"{decision.mission_id!r}, not {mission_id!r}"
            )

        existing = [
            plan
            for plan in self._plan_revisions.list()
            if plan.mission_id == mission_id
        ]

        next_revision = max(
            (plan.revision for plan in existing),
            default=0,
        ) + 1

        if revision is None:
            revision = next_revision
        elif revision < 1:
            raise ValueError("revision must be >= 1")
        elif any(plan.revision == revision for plan in existing):
            raise ValueError(
                f"plan revision already exists: {revision}"
            )

        if revision == 1:
            if parent_revision_id is not None:
                raise ValueError(
                    "revision 1 cannot have a parent revision"
                )
        else:
            if parent_revision_id is None:
                raise ValueError(
                    f"plan revision {revision} requires a parent revision"
                )

            parent = self._plan_revisions.get(parent_revision_id)
            if parent is None:
                raise ValueError(
                    f"unknown parent revision: {parent_revision_id!r}"
                )

            if parent.mission_id != mission_id:
                raise ValueError(
                    f"parent revision {parent_revision_id!r} belongs to "
                    f"mission {parent.mission_id!r}, not {mission_id!r}"
                )

            if parent.revision >= revision:
                raise ValueError(
                    f"plan revision {revision} must have a lower revision "
                    f"parent than {revision}"
                )

        plan_id = plan_id or new_id("plan")
        graph_id = graph_id or new_id("graph")

        if self._plan_revisions.get(plan_id) is not None:
            raise ValueError(f"plan already exists: {plan_id!r}")

        if self._work_graphs.get(graph_id) is not None:
            raise ValueError(f"work graph already exists: {graph_id!r}")

        graph = WorkGraph(
            mission_id=mission_id,
            plan_revision_id=plan_id,
            nodes=tuple(nodes),
            edges=tuple(edges),
            metadata=dict(metadata or {}),
            id=graph_id,
        )

        plan = PlanRevision(
            mission_id=mission_id,
            revision=revision,
            decision_id=decision_id,
            graph_id=graph.id,
            parent_revision_id=parent_revision_id,
            status=PlanStatus.DRAFT,
            reason=reason,
            metadata=dict(metadata or {}),
            id=plan_id,
        )

        self._work_graphs.save(graph)
        self._publish(
            Event(
                type="WorkGraphCreated",
                payload=self._serialize_graph(graph),
                aggregate_type="work_graph",
                aggregate_id=graph.id,
                correlation_id=mission_id,
                source="planning",
            )
        )

        self._plan_revisions.save(plan)
        self._publish(
            Event(
                type="PlanRevisionCreated",
                payload={
                    "id": plan.id,
                    "mission_id": plan.mission_id,
                    "revision": plan.revision,
                    "decision_id": plan.decision_id,
                    "graph_id": plan.graph_id,
                    "parent_revision_id": plan.parent_revision_id,
                    "reason": plan.reason,
                    "metadata": dict(plan.metadata),
                },
                aggregate_type="plan_revision",
                aggregate_id=plan.id,
                correlation_id=mission_id,
                source="planning",
            )
        )

        return plan, graph

    def plan(
        self,
        request: PlanningRequest,
        planner: Planner,
        *,
        plan_id: Optional[str] = None,
        graph_id: Optional[str] = None,
    ) -> tuple[PlanRevision, WorkGraph]:
        """Run a planner and persist its result through existing workflows."""

        mission = self._require_mission(request.mission_id)

        if request.context.mission.id != mission.id:
            raise ValueError(
                "planning context mission does not match persisted mission"
            )

        persisted_tasks = tuple(
            task
            for task in self._tasks.list()
            if task.mission_id == mission.id
        )

        authoritative_context = PlanningContext(
            mission=mission,
            tasks=persisted_tasks,
            prior_decisions=request.context.prior_decisions,
            observations=request.context.observations,
            metadata=request.context.metadata,
        )

        authoritative_request = PlanningRequest(
            mission_id=request.mission_id,
            objective=request.objective,
            context=authoritative_context,
            revision_reason=request.revision_reason,
            metadata=request.metadata,
        )

        result = planner.plan(authoritative_request)
        self._validate_result(authoritative_request, result)
        decision = result.decision

        task_graph = self._graph_builder.build(
            mission,
            persisted_tasks,
        )

        if any(node.kind == WorkNodeKind.TASK for node in result.nodes):
            raise ValueError(
                "planner results cannot contain TASK nodes; "
                "task nodes are owned by WorkGraphBuilder"
            )

        graph_nodes = task_graph.nodes + tuple(result.nodes)
        graph_edges = task_graph.edges + tuple(result.edges)

        # The planner produces the decision; create_decision remains the
        # canonical persistence/event boundary.
        if self._decisions.get(decision.id) is not None:
            raise ValueError(
                f"decision already exists: {decision.id!r}"
            )
        self._decisions.save(decision)
        self._publish(
            Event(
                type="DecisionCreated",
                payload={
                    "id": decision.id,
                    "mission_id": decision.mission_id,
                    "kind": decision.kind,
                    "objective": decision.objective,
                    "rationale": decision.rationale,
                    "alternatives": list(decision.alternatives),
                    "selected_option": decision.selected_option,
                    "confidence": decision.confidence,
                    "evidence": list(decision.evidence),
                    "metadata": dict(decision.metadata),
                },
                aggregate_type="decision",
                aggregate_id=decision.id,
                correlation_id=mission.id,
                source="planning",
            )
        )
        existing = [
            plan
            for plan in self._plan_revisions.list()
            if plan.mission_id == mission.id
        ]
        parent_revision_id = (
            max(existing, key=lambda plan: plan.revision).id
            if existing
            else None
        )

        return self.create_plan(
            mission_id=mission.id,
            decision_id=decision.id,
            nodes=graph_nodes,
            edges=graph_edges,
            parent_revision_id=parent_revision_id,
            reason=request.revision_reason,
            metadata=dict(request.metadata) or dict(result.metadata),
            plan_id=plan_id,
            graph_id=graph_id,
        )

    def propose(
        self,
        plan_id: str,
        *,
        reason: Optional[str] = None,
    ) -> PlanRevision:
        return self._transition(
            plan_id,
            PlanStatus.PROPOSED,
            allowed={PlanStatus.DRAFT},
            reason=reason,
        )

    def activate(
        self,
        plan_id: str,
        *,
        reason: Optional[str] = None,
    ) -> PlanRevision:
        plan = self._require_plan(plan_id)

        active = [
            other
            for other in self._plan_revisions.list()
            if other.mission_id == plan.mission_id
            and other.status == PlanStatus.ACTIVE
            and other.id != plan_id
        ]
        if active:
            raise ValueError(
                f"mission {plan.mission_id!r} already has an active plan"
            )

        return self._transition(
            plan_id,
            PlanStatus.ACTIVE,
            allowed={PlanStatus.PROPOSED},
            reason=reason,
        )

    def replace_active(
        self,
        plan_id: str,
        *,
        expected_active_id: str,
        reason: Optional[str] = None,
    ) -> PlanRevision:
        """Atomically replace one active plan with a proposed plan.

        The caller's transaction boundary guarantees rollback if either
        transition fails. The expected active revision prevents replacing
        a stale or concurrently changed production revision.
        """
        plan = self._require_plan(plan_id)

        if plan.status is not PlanStatus.PROPOSED:
            raise ValueError(
                f"cannot replace active plan with {plan_id!r} from "
                f"{plan.status.value!r}"
            )

        active = self._require_plan(expected_active_id)

        if active.mission_id != plan.mission_id:
            raise ValueError(
                "replacement plan and expected active plan belong to "
                "different missions"
            )

        current_active = [
            other
            for other in self._plan_revisions.list()
            if other.mission_id == plan.mission_id
            and other.status == PlanStatus.ACTIVE
            and other.id != plan_id
        ]

        if len(current_active) != 1 or current_active[0].id != expected_active_id:
            raise ValueError(
                f"expected active plan {expected_active_id!r} is not "
                "the current active plan"
            )

        self.supersede(
            expected_active_id,
            reason=reason,
        )

        return self.activate(
            plan_id,
            reason=reason,
        )

    def supersede(
        self,
        plan_id: str,
        *,
        reason: Optional[str] = None,
    ) -> PlanRevision:
        return self._transition(
            plan_id,
            PlanStatus.SUPERSEDED,
            allowed={PlanStatus.ACTIVE},
            reason=reason,
        )

    def cancel(
        self,
        plan_id: str,
        *,
        reason: Optional[str] = None,
    ) -> PlanRevision:
        return self._transition(
            plan_id,
            PlanStatus.CANCELLED,
            allowed={
                PlanStatus.DRAFT,
                PlanStatus.PROPOSED,
                PlanStatus.ACTIVE,
            },
            reason=reason,
        )

    def complete(
        self,
        plan_id: str,
        *,
        reason: Optional[str] = None,
    ) -> PlanRevision:
        return self._transition(
            plan_id,
            PlanStatus.COMPLETED,
            allowed={PlanStatus.ACTIVE},
            reason=reason,
        )

    def _transition(
        self,
        plan_id: str,
        target: PlanStatus,
        *,
        allowed: set[PlanStatus],
        reason: Optional[str],
    ) -> PlanRevision:
        current = self._require_plan(plan_id)

        if current.status not in allowed:
            raise ValueError(
                f"cannot transition plan {plan_id!r} from "
                f"{current.status.value!r} to {target.value!r}"
            )

        replacement = PlanRevision(
            mission_id=current.mission_id,
            revision=current.revision,
            decision_id=current.decision_id,
            graph_id=current.graph_id,
            parent_revision_id=current.parent_revision_id,
            status=target,
            reason=reason if reason is not None else current.reason,
            metadata=dict(current.metadata),
            id=current.id,
            created_at=current.created_at,
        )

        self._plan_revisions.save(replacement)

        event_type = {
            PlanStatus.PROPOSED: "PlanRevisionProposed",
            PlanStatus.ACTIVE: "PlanRevisionActivated",
            PlanStatus.SUPERSEDED: "PlanRevisionSuperseded",
            PlanStatus.CANCELLED: "PlanRevisionCancelled",
            PlanStatus.COMPLETED: "PlanRevisionCompleted",
        }[target]

        self._publish(
            Event(
                type=event_type,
                payload={
                    "id": replacement.id,
                    "mission_id": replacement.mission_id,
                    "revision": replacement.revision,
                    "decision_id": replacement.decision_id,
                    "graph_id": replacement.graph_id,
                    "parent_revision_id": replacement.parent_revision_id,
                    "status": replacement.status.value,
                    "reason": replacement.reason,
                    "metadata": dict(replacement.metadata),
                },
                aggregate_type="plan_revision",
                aggregate_id=replacement.id,
                correlation_id=replacement.mission_id,
                source="planning",
            )
        )

        return replacement

    def _validate_result(
        self,
        request: PlanningRequest,
        result: PlanningResult,
    ) -> None:
        if result is None:
            raise ValueError("planner returned no result")

        if result.decision.mission_id != request.mission_id:
            raise ValueError(
                "planner decision belongs to a different mission"
            )

        for node in result.nodes:
            if not isinstance(node, WorkNode):
                raise TypeError(
                    "planner result contains invalid work node"
                )

        for edge in result.edges:
            if not isinstance(edge, WorkEdge):
                raise TypeError(
                    "planner result contains invalid work edge"
                )

    def _serialize_graph(self, graph: WorkGraph) -> dict:
        return {
            "id": graph.id,
            "mission_id": graph.mission_id,
            "plan_revision_id": graph.plan_revision_id,
            "nodes": [
                {
                    "id": node.id,
                    "kind": node.kind.value,
                    "task_id": node.task_id,
                    "metadata": dict(node.metadata),
                }
                for node in graph.nodes
            ],
            "edges": [
                {
                    "id": edge.id,
                    "source_node_id": edge.source_node_id,
                    "target_node_id": edge.target_node_id,
                    "kind": edge.kind.value,
                    "condition": edge.condition,
                }
                for edge in graph.edges
            ],
            "metadata": dict(graph.metadata),
        }

    def _require_mission(self, mission_id: str) -> Mission:
        mission = self._missions.get(mission_id)
        if mission is None:
            raise ValueError(f"unknown mission: {mission_id!r}")
        return mission

    def _require_plan(self, plan_id: str) -> PlanRevision:
        plan = self._plan_revisions.get(plan_id)
        if plan is None:
            raise ValueError(f"unknown plan: {plan_id!r}")
        return plan

    def _publish(self, event: Event) -> None:
        failures = self._events.publish(event)
        if failures:
            raise RuntimeError(
                f"event handlers failed for {event.type!r}: "
                + "; ".join(str(failure.error) for failure in failures)
            )
