from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Mapping, Optional

from ocean.core.clock import SYSTEM_CLOCK
from ocean.core.ids import new_id
from runtime.types import ExecutionRequest


class TemporalScheduleKind(str, Enum):
    ONCE = "once"
    INTERVAL = "interval"


class MissedSchedulePolicy(str, Enum):
    SKIP = "skip"
    FIRE_ONCE = "fire_once"
    CATCH_UP = "catch_up"


class TemporalScheduleStatus(str, Enum):
    ACTIVE = "active"
    CANCELLED = "cancelled"
    COMPLETED = "completed"


@dataclass(frozen=True)
class TemporalRecurrence:
    interval: timedelta

    def __post_init__(self) -> None:
        if self.interval <= timedelta(0):
            raise ValueError("recurrence interval must be positive")


@dataclass(frozen=True)
class TemporalSchedule:
    execution_request: ExecutionRequest
    run_at: datetime
    kind: TemporalScheduleKind = TemporalScheduleKind.ONCE
    recurrence: Optional[TemporalRecurrence] = None
    missed_policy: MissedSchedulePolicy = MissedSchedulePolicy.FIRE_ONCE
    priority: int = 0
    metadata: Mapping[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: new_id("schedule"))
    created_at: datetime = field(default_factory=lambda: SYSTEM_CLOCK.now())
    status: TemporalScheduleStatus = TemporalScheduleStatus.ACTIVE

    def __post_init__(self) -> None:
        if self.priority < 0:
            raise ValueError("priority must be non-negative")
        if self.kind is TemporalScheduleKind.INTERVAL and self.recurrence is None:
            raise ValueError("interval schedules require recurrence")
        if self.kind is TemporalScheduleKind.ONCE and self.recurrence is not None:
            raise ValueError("one-shot schedules cannot have recurrence")

    @property
    def recurring(self) -> bool:
        return self.kind is TemporalScheduleKind.INTERVAL


@dataclass(frozen=True)
class TemporalOccurrence:
    schedule_id: str
    occurrence: int
    due_at: datetime
    @property
    def id(self) -> str:
        return f"{self.schedule_id}:{self.occurrence}"

    def __post_init__(self) -> None:
        if not self.schedule_id:
            raise ValueError("schedule_id must be non-empty")
        if self.occurrence < 0:
            raise ValueError("occurrence must be non-negative")


@dataclass(frozen=True)
class TemporalDecision:
    due: bool
    occurrences: tuple[TemporalOccurrence, ...] = ()
    reason: str = ""

    @property
    def failed(self) -> bool:
        return not self.due
