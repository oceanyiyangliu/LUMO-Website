from dataclasses import replace

from threading import RLock
from typing import Iterable

from ocean.domain.event import Event
from .types import TemporalOccurrence, TemporalSchedule, TemporalScheduleStatus


class TemporalRegistry:
    """Rebuildable temporal projection over canonical event history."""

    def __init__(self, events: Iterable[Event] = ()) -> None:
        self._lock = RLock()
        self._schedules: dict[str, TemporalSchedule] = {}
        self._fired: set[tuple[str, int]] = set()
        self.rebuild(events)

    def rebuild(self, events: Iterable[Event]) -> None:
        with self._lock:
            self._schedules.clear()
            self._fired.clear()
            for event in events:
                self._apply(event)

    def apply(self, event: Event) -> None:
        with self._lock:
            self._apply(event)

    def get(self, schedule_id: str) -> TemporalSchedule | None:
        with self._lock:
            return self._schedules.get(schedule_id)

    def require(self, schedule_id: str) -> TemporalSchedule:
        schedule = self.get(schedule_id)
        if schedule is None:
            raise KeyError(f"unknown temporal schedule: {schedule_id}")
        return schedule

    def list(self) -> list[TemporalSchedule]:
        with self._lock:
            return list(self._schedules.values())

    def occurrence_fired(self, schedule_id: str, occurrence: int) -> bool:
        with self._lock:
            return (schedule_id, occurrence) in self._fired

    def next_occurrence(self, schedule_id: str) -> int:
        with self._lock:
            occurrences = [
                occurrence
                for fired_schedule_id, occurrence in self._fired
                if fired_schedule_id == schedule_id
            ]
            return max(occurrences, default=-1) + 1

    def mark_fired(self, occurrence: TemporalOccurrence) -> bool:
        key = (occurrence.schedule_id, occurrence.occurrence)
        with self._lock:
            if key in self._fired:
                return False
            self._fired.add(key)
            return True

    def _apply(self, event: Event) -> None:
        from persistence.serializers.temporal import TemporalScheduleSerializer

        if event.type == "TemporalScheduleCreated":
            data = event.payload.get("schedule")
            if not isinstance(data, dict):
                raise TypeError("TemporalScheduleCreated requires serialized schedule")
            schedule = TemporalScheduleSerializer().deserialize(data)
            existing = self._schedules.get(schedule.id)
            if existing is not None and existing != schedule:
                raise ValueError(f"conflicting temporal schedule: {schedule.id}")
            self._schedules[schedule.id] = schedule

        elif event.type == "TemporalScheduleCancelled":
            schedule_id = event.payload["schedule_id"]
            schedule = self._schedules.get(schedule_id)
            if schedule is not None:
                self._schedules[schedule_id] = replace(
                    schedule,
                    status=TemporalScheduleStatus.CANCELLED,
                )

        elif event.type == "TemporalScheduleCompleted":
            schedule_id = str(event.payload["schedule_id"])
            schedule = self._schedules.get(schedule_id)
            if schedule is not None:
                self._schedules[schedule_id] = replace(
                    schedule,
                    status=TemporalScheduleStatus.COMPLETED,
                )
        elif event.type == "TemporalOccurrenceEnqueued":
            self._fired.add(
                (
                    event.payload["schedule_id"],
                    event.payload["occurrence"],
                )
            )
