from __future__ import annotations

from dataclasses import replace
from datetime import datetime
from typing import Callable

from ocean.core.clock import SYSTEM_CLOCK
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from runtime.scheduler import ScheduledExecution, Scheduler

from .policy import TemporalPolicy
from .registry import TemporalRegistry
from .types import TemporalOccurrence, TemporalScheduleStatus


class TemporalCoordinator:
    """Coordinates temporal eligibility without owning execution scheduling."""

    def __init__(
        self,
        *,
        registry: TemporalRegistry,
        policy: TemporalPolicy,
        scheduler: Scheduler,
        events: EventBus,
        clock: object = SYSTEM_CLOCK,
        now: Callable[[], datetime] | None = None,
    ) -> None:
        self._registry = registry
        self._policy = policy
        self._scheduler = scheduler
        self._events = events
        self._clock = clock
        self._now = now or clock.now

    def tick(self) -> list[ScheduledExecution]:
        """Evaluate all active schedules and enqueue newly due occurrences."""
        enqueued: list[ScheduledExecution] = []

        for schedule in self._registry.list():
            if schedule.status is not TemporalScheduleStatus.ACTIVE:
                continue

            next_occurrence = self._next_occurrence(schedule.id)
            occurrences = self._policy.evaluate(
                schedule,
                now=self._now(),
                next_occurrence=next_occurrence,
            )

            for occurrence in occurrences:
                if self._registry.occurrence_fired(
                    occurrence.schedule_id,
                    occurrence.occurrence,
                ):
                    continue

                self._events.publish(
                    Event(
                        type="TemporalOccurrenceDue",
                        payload={
                            "schedule_id": occurrence.schedule_id,
                            "occurrence": occurrence.occurrence,
                            "due_at": occurrence.due_at.isoformat(),
                        },
                        aggregate_type="temporal_schedule",
                        aggregate_id=schedule.id,
                    )
                )

                request = replace(
                    schedule.execution_request,
                    execution_id=occurrence.id,
                )

                try:
                    execution = self._scheduler.enqueue(
                        request,
                        priority=schedule.priority,
                    )
                except Exception:
                    # The occurrence remains unfired and will be retried on the
                    # next tick. Never consume a schedule slot before the actual
                    # scheduler admission boundary succeeds.
                    continue

                self._events.publish(
                    Event(
                        type="TemporalOccurrenceEnqueued",
                        payload={
                            "schedule_id": occurrence.schedule_id,
                            "occurrence": occurrence.occurrence,
                            "execution_id": execution.execution_id,
                        },
                        aggregate_type="temporal_schedule",
                        aggregate_id=schedule.id,
                    )
                )

                if not schedule.recurring:
                    self._events.publish(
                        Event(
                            type="TemporalScheduleCompleted",
                            payload={"schedule_id": schedule.id},
                            aggregate_type="temporal_schedule",
                            aggregate_id=schedule.id,
                        )
                    )

                enqueued.append(execution)

        return enqueued

    def cancel(self, schedule_id: str) -> None:
        schedule = self._registry.require(schedule_id)

        if schedule.status is TemporalScheduleStatus.CANCELLED:
            return

        self._events.publish(
            Event(
                type="TemporalScheduleCancelled",
                payload={"schedule_id": schedule.id},
                aggregate_type="temporal_schedule",
                aggregate_id=schedule.id,
            )
        )

    def _next_occurrence(self, schedule_id: str) -> int:
        return self._registry.next_occurrence(schedule_id)
