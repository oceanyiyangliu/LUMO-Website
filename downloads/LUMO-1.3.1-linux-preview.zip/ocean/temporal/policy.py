from __future__ import annotations

from datetime import datetime

from .types import (
    MissedSchedulePolicy,
    TemporalOccurrence,
    TemporalSchedule,
)


class TemporalPolicy:
    def __init__(self, *, max_catch_up: int = 1000) -> None:
        if isinstance(max_catch_up, bool) or max_catch_up <= 0:
            raise ValueError("max_catch_up must be a positive integer")
        self.max_catch_up = max_catch_up

    def evaluate(
        self,
        schedule: TemporalSchedule,
        *,
        now: datetime,
        next_occurrence: int,
    ) -> tuple[TemporalOccurrence, ...]:
        if schedule.status.value != "active":
            return ()

        if now < schedule.run_at:
            return ()

        if schedule.kind.value == "once":
            return (
                TemporalOccurrence(
                    schedule_id=schedule.id,
                    occurrence=next_occurrence,
                    due_at=schedule.run_at,
                ),
            )

        recurrence = schedule.recurrence
        if recurrence is None:
            raise RuntimeError("recurring schedule has no recurrence")

        elapsed = now - schedule.run_at
        latest_due = elapsed // recurrence.interval

        if next_occurrence > latest_due:
            return ()

        if schedule.missed_policy is MissedSchedulePolicy.SKIP:
            return (
                TemporalOccurrence(
                    schedule_id=schedule.id,
                    occurrence=latest_due,
                    due_at=schedule.run_at + recurrence.interval * latest_due,
                ),
            )

        if schedule.missed_policy is MissedSchedulePolicy.FIRE_ONCE:
            return (
                TemporalOccurrence(
                    schedule_id=schedule.id,
                    occurrence=latest_due,
                    due_at=now,
                ),
            )

        # Long downtime must not turn one scheduler tick into an unbounded
        # allocation/dispatch burst. A bounded catch-up window preserves order
        # and lets subsequent ticks continue from the next unfired occurrence.
        stop = min(latest_due + 1, next_occurrence + self.max_catch_up)
        return tuple(
            TemporalOccurrence(
                schedule_id=schedule.id,
                occurrence=occurrence,
                due_at=schedule.run_at + recurrence.interval * occurrence,
            )
            for occurrence in range(next_occurrence, stop)
        )
