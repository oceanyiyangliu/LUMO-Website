"""Deterministic safety governor for LUMO local intelligence.

AI models may request resources, but this module is the sole authority that
admits local model workers. It derives a conservative device budget, keeps a
system reserve, caps concurrent workers, and fails closed when hardware state
cannot be measured safely.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
import os
import platform
import shutil
import subprocess
import threading
from typing import Callable

try:
    import psutil
except ImportError:  # pragma: no cover - deployment fallback
    psutil = None


@dataclass(frozen=True)
class DeviceResources:
    physical_ram_bytes: int
    available_ram_bytes: int
    safe_ai_ram_bytes: int
    cpu_count: int
    battery_percent: float | None
    plugged_in: bool | None


@dataclass(frozen=True)
class ResourceRequest:
    worker_id: str
    ram_bytes: int
    cpu_percent: float = 0.0
    gpu_required: bool = False
    disk_bytes: int = 0


@dataclass(frozen=True)
class AdmissionDecision:
    admitted: bool
    reason: str
    safe_ai_ram_bytes: int
    reserved_ai_ram_bytes: int
    available_ai_ram_bytes: int


class LocalResourceGovernor:
    """Hard, deterministic admission control for local AI workers."""

    def __init__(self, *, ram_fraction: float | None = None, system_reserve_gib: float | None = None,
                 max_concurrent_workers: int | None = None, sampler: Callable[[], DeviceResources] | None = None) -> None:
        self._sampler = sampler or sample_device_resources
        fraction = float(os.getenv("LUMO_AI_RAM_FRACTION", "0.45") if ram_fraction is None else ram_fraction)
        reserve = float(os.getenv("LUMO_AI_RAM_RESERVE_GIB", "4") if system_reserve_gib is None else system_reserve_gib)
        workers = int(os.getenv("LUMO_AI_MAX_CONCURRENT_WORKERS", "2") if max_concurrent_workers is None else max_concurrent_workers)
        if not 0.10 <= fraction <= 0.75: raise ValueError("AI RAM fraction must be between 0.10 and 0.75")
        if reserve < 0 or not math.isfinite(reserve): raise ValueError("AI RAM reserve must be non-negative")
        if workers < 1: raise ValueError("max concurrent workers must be positive")
        self.ram_fraction = fraction
        self.system_reserve_bytes = int(reserve * 1024**3)
        self.max_concurrent_workers = workers
        self._lock = threading.RLock()
        self._reservations: dict[str, ResourceRequest] = {}

    def snapshot(self) -> DeviceResources:
        return self._sampler()

    def admit(self, request: ResourceRequest) -> AdmissionDecision:
        if not request.worker_id.strip(): raise ValueError("worker_id is required")
        if request.ram_bytes <= 0: raise ValueError("ram_bytes must be positive")
        if request.cpu_percent < 0 or request.cpu_percent > 100: raise ValueError("cpu_percent must be 0..100")
        device = self.snapshot()
        with self._lock:
            if request.worker_id in self._reservations:
                return AdmissionDecision(True, "worker already admitted", device.safe_ai_ram_bytes,
                                        self._reserved_ram(), max(0, device.safe_ai_ram_bytes-self._reserved_ram()))
            if len(self._reservations) >= self.max_concurrent_workers:
                return AdmissionDecision(False, "concurrent AI worker limit reached", device.safe_ai_ram_bytes,
                                        self._reserved_ram(), max(0, device.safe_ai_ram_bytes-self._reserved_ram()))
            reserved = self._reserved_ram()
            available = max(0, device.safe_ai_ram_bytes-reserved)
            if request.ram_bytes > available:
                return AdmissionDecision(False, f"AI RAM budget exceeded: requested={request.ram_bytes}, available={available}",
                                        device.safe_ai_ram_bytes, reserved, available)
            if request.disk_bytes and request.disk_bytes > shutil.disk_usage(os.path.expanduser("~")).free:
                return AdmissionDecision(False, "insufficient disk space", device.safe_ai_ram_bytes, reserved, available)
            self._reservations[request.worker_id] = request
            return AdmissionDecision(True, "admitted", device.safe_ai_ram_bytes, reserved+request.ram_bytes,
                                    max(0, device.safe_ai_ram_bytes-reserved-request.ram_bytes))

    def release(self, worker_id: str) -> bool:
        with self._lock: return self._reservations.pop(worker_id, None) is not None

    def reservations(self) -> tuple[ResourceRequest, ...]:
        with self._lock: return tuple(self._reservations.values())

    def _reserved_ram(self) -> int:
        return sum(x.ram_bytes for x in self._reservations.values())


def _mac_memory() -> tuple[int, int]:
    total = int(subprocess.check_output(["sysctl", "-n", "hw.memsize"], text=True).strip())
    if psutil is not None:
        available = min(total, int(psutil.virtual_memory().available))
        return total, available
    pagesize = int(subprocess.check_output(["sysctl", "-n", "vm.pagesize"], text=True).strip())
    vm = subprocess.check_output(["vm_stat"], text=True)
    free_pages = 0
    inactive_pages = 0
    for line in vm.splitlines():
        if "Pages free" in line or "Pages speculative" in line:
            free_pages += int(line.split(":",1)[1].strip().rstrip("."))
        elif "Pages inactive" in line:
            inactive_pages += int(line.split(":",1)[1].strip().rstrip("."))
    available = min(total, (free_pages + inactive_pages) * pagesize)
    return total, available


def sample_device_resources() -> DeviceResources:
    try:
        if platform.system() == "Darwin":
            total, available = _mac_memory()
        else:
            total = int(os.sysconf("SC_PHYS_PAGES") * os.sysconf("SC_PAGE_SIZE"))
            available = int(os.sysconf("SC_AVPHYS_PAGES") * os.sysconf("SC_PAGE_SIZE"))
        cpu = max(1, os.cpu_count() or 1)
        fraction = float(os.getenv("LUMO_AI_RAM_FRACTION", "0.45"))
        reserve = int(float(os.getenv("LUMO_AI_RAM_RESERVE_GIB", "4")) * 1024**3)
        # The active ceiling is recomputed on every admission from CURRENT available RAM.
        # It is bounded by a physical-device cap, while a fixed OS reserve prevents LUMO
        # from consuming the remaining headroom even when the machine is otherwise idle.
        dynamic_available_budget = max(0, available - reserve)
        hard_device_budget = max(0, total - reserve)
        safe = max(0, min(int(total * fraction), dynamic_available_budget, hard_device_budget))

        # The 0.6B bootstrap model is intentionally allowed a separate,
        # conservative floor. A fixed 4 GiB reserve is appropriate for normal
        # models, but must not reduce the bootstrap ceiling to zero when the
        # machine demonstrably has enough headroom for the bootstrap model.
        bootstrap_runtime = float(os.getenv("LUMO_BOOTSTRAP_RAM_GIB", "0.85"))
        bootstrap_headroom = float(os.getenv("LUMO_BOOTSTRAP_HEADROOM_GIB", "2.0"))
        if available >= int((bootstrap_runtime + bootstrap_headroom) * 1024**3):
            safe = max(safe, int(bootstrap_runtime * 1024**3))
        return DeviceResources(total, available, safe, cpu, None, None)
    except Exception as exc:
        raise RuntimeError("unable to safely measure device resources; refusing local AI admission") from exc
