"""Durable mission budget and consumption accounting."""
from __future__ import annotations
from dataclasses import dataclass, field
from threading import RLock
from typing import Iterable, Mapping, Optional
import math
from ocean.core.ids import new_id
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus

@dataclass(frozen=True)
class Budget:
    """Hard ceilings for a mission or execution."""
    mission_id: str
    limits: Mapping[str, float]
    budget_id: str = field(default_factory=lambda: new_id("budget"))
    consumed: Mapping[str, float] = field(default_factory=dict)
    def __post_init__(self):
        if not self.mission_id: raise ValueError("mission_id is required")
        if any(not isinstance(v, (int, float)) or isinstance(v, bool) or not math.isfinite(float(v)) or v < 0 for v in self.limits.values()):
            raise ValueError("budget limits must be finite non-negative numbers")
        if any(not isinstance(v, (int, float)) or isinstance(v, bool) or not math.isfinite(float(v)) or v < 0 for v in self.consumed.values()):
            raise ValueError("budget consumption must be finite non-negative numbers")
    def remaining(self, kind: str) -> Optional[float]:
        limit=self.limits.get(kind)
        return None if limit is None else max(0.0, limit-self.consumed.get(kind,0.0))
    def can_spend(self, costs: Mapping[str,float]) -> tuple[bool,str|None]:
        for kind, amount in costs.items():
            if not isinstance(amount, (int, float)) or isinstance(amount, bool) or not math.isfinite(float(amount)) or amount < 0:
                return False, f"invalid cost for {kind!r}"
            limit=self.limits.get(kind)
            if limit is not None and self.consumed.get(kind,0.0)+amount > limit:
                return False, f"budget exceeded for {kind}: required={amount}, remaining={self.remaining(kind)}"
        return True,None

class BudgetLedger:
    """Thread-safe budget authority with event-sourced reconstruction."""
    def __init__(self, event_bus: EventBus|None=None):
        self._events=event_bus; self._lock=RLock(); self._budgets={}
    def create(self, mission_id:str, limits:Mapping[str,float]) -> Budget:
        with self._lock:
            if mission_id in self._budgets: raise ValueError(f"budget already exists: {mission_id!r}")
            budget=Budget(mission_id=mission_id, limits=dict(limits)); self._budgets[mission_id]=budget
            self._publish("BudgetCreated", mission_id, {"mission_id":mission_id,"budget_id":budget.budget_id,"limits":dict(limits)})
            return budget
    def get(self, mission_id:str)->Budget|None:
        with self._lock: return self._budgets.get(mission_id)
    def authorize(self, mission_id:str, costs:Mapping[str,float])->tuple[bool,str|None]:
        with self._lock:
            b=self._budgets.get(mission_id)
            if b is None: return True,None
            return b.can_spend(costs)
    def consume(self, mission_id:str, costs:Mapping[str,float], *, execution_id:str|None=None)->Budget:
        with self._lock:
            b=self._budgets.get(mission_id)
            if b is None: raise KeyError(mission_id)
            ok,reason=b.can_spend(costs)
            if not ok: raise RuntimeError(reason)
            consumed=dict(b.consumed)
            for k,v in costs.items(): consumed[k]=consumed.get(k,0.0)+float(v)
            updated=Budget(mission_id=b.mission_id,limits=dict(b.limits),budget_id=b.budget_id,consumed=consumed)
            self._budgets[mission_id]=updated
            self._publish("BudgetConsumed", mission_id, {"mission_id":mission_id,"budget_id":b.budget_id,"execution_id":execution_id,"costs":dict(costs),"consumed":consumed})
            return updated
    def rebuild(self, events:Iterable[Event]|None=None)->None:
        if events is None:
            if self._events is None: raise ValueError("events or event_bus is required")
            events=self._events.history()
        with self._lock:
            budgets={}
            for e in events:
                if e.type=="BudgetCreated":
                    p=e.payload; budgets[str(p["mission_id"])]=Budget(str(p["mission_id"]),dict(p.get("limits",{})),str(p.get("budget_id") or new_id("budget")))
                elif e.type=="BudgetConsumed":
                    p=e.payload; mid=str(p["mission_id"]); b=budgets.get(mid)
                    if b:
                        c=dict(b.consumed)
                        for k,v in p.get("costs",{}).items(): c[k]=c.get(k,0.0)+float(v)
                        budgets[mid]=Budget(b.mission_id,b.limits,b.budget_id,c)
            self._budgets=budgets
    def _publish(self, typ, aggregate_id, payload):
        if self._events: self._events.publish(Event(type=typ,aggregate_type="budget",aggregate_id=aggregate_id,source="resources",payload=payload))
