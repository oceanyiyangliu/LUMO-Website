from __future__ import annotations

from typing import Iterable
import math

from ocean.domain.resource import ResourceRequirement


class ResourceAdmissionPolicy:
    """Validates and normalizes declarative resource requirements."""

    def normalize(
        self,
        requirements: Iterable[ResourceRequirement],
    ) -> dict[str, float]:
        normalized: dict[str, float] = {}

        for requirement in requirements:
            if not requirement.kind:
                raise ValueError("resource requirement kind is required")
            amount = float(requirement.amount)
            if not math.isfinite(amount) or amount <= 0:
                raise ValueError(
                    f"resource requirement amount must be positive: "
                    f"{requirement.kind!r}"
                )

            normalized[requirement.kind] = (
                normalized.get(requirement.kind, 0.0)
                + amount
            )

        return normalized
