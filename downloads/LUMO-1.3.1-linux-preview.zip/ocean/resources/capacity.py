from __future__ import annotations

from threading import RLock
import math
from typing import Iterable, Optional

from ocean.core.ids import new_id
from ocean.domain.capability import CapabilityRegistry
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.domain.resource import ResourceRequirement
from runtime.types import ExecutionRequest

from .policy import ResourceAdmissionPolicy
from .types import (
    ResourceAdmissionResult,
    ResourceCapacity,
    ResourceReservation,
)


class ResourceCapacityPlane:
    """
    Concrete resource-capacity admission authority.

    ResourceRequirement describes demand.
    ResourceCapacity describes supply.
    ResourceReservation represents committed supply.

    Multi-resource reservations are atomic: either every requested resource
    is reserved or none is reserved.
    """

    def __init__(
        self,
        *,
        capabilities: CapabilityRegistry,
        event_bus: Optional[EventBus] = None,
        policy: Optional[ResourceAdmissionPolicy] = None,
    ) -> None:
        if capabilities is None:
            raise ValueError("capabilities is required")

        self._capabilities = capabilities
        self._event_bus = event_bus
        self._policy = policy or ResourceAdmissionPolicy()
        self._lock = RLock()
        self._capacities: dict[str, ResourceCapacity] = {}
        self._reservations: dict[str, ResourceReservation] = {}
        self._execution_reservations: dict[str, str] = {}

    def register(
        self,
        kind: str,
        capacity: float,
    ) -> ResourceCapacity:
        if not kind:
            raise ValueError("resource kind is required")
        capacity = float(capacity)
        if not math.isfinite(capacity) or capacity < 0:
            raise ValueError("resource capacity must be finite and non-negative")

        with self._lock:
            if kind in self._capacities:
                raise ValueError(
                    f"resource capacity already registered: {kind!r}"
                )

            resource = ResourceCapacity(
                kind=kind,
                capacity=float(capacity),
            )
            self._capacities[kind] = resource
            self._publish(
                "ResourceCapacityRegistered",
                resource.kind,
                {
                    "kind": resource.kind,
                    "capacity": resource.capacity,
                },
            )
            return resource

    def set_capacity(
        self,
        kind: str,
        capacity: float,
    ) -> ResourceCapacity:
        capacity = float(capacity)
        if not math.isfinite(capacity) or capacity < 0:
            raise ValueError("resource capacity must be finite and non-negative")

        with self._lock:
            current = self._capacities.get(kind)
            if current is None:
                raise KeyError(kind)
            if capacity < current.reserved:
                raise ValueError(
                    "capacity cannot be reduced below current reservations"
                )

            updated = ResourceCapacity(
                kind=kind,
                capacity=float(capacity),
                reserved=current.reserved,
            )
            self._capacities[kind] = updated
            self._publish(
                "ResourceCapacityChanged",
                kind,
                {
                    "kind": kind,
                    "capacity": updated.capacity,
                    "reserved": updated.reserved,
                },
            )
            return updated

    def capacity(self, kind: str) -> Optional[ResourceCapacity]:
        with self._lock:
            return self._capacities.get(kind)

    def capacities(self) -> list[ResourceCapacity]:
        with self._lock:
            return list(self._capacities.values())

    def reservation(
        self,
        reservation_id: str,
    ) -> Optional[ResourceReservation]:
        with self._lock:
            return self._reservations.get(reservation_id)

    def reservation_for_execution(
        self,
        execution_id: str,
    ) -> Optional[ResourceReservation]:
        with self._lock:
            reservation_id = self._execution_reservations.get(execution_id)
            if reservation_id is None:
                return None
            return self._reservations.get(reservation_id)

    def requirements_for(
        self,
        request: ExecutionRequest,
    ) -> list[ResourceRequirement]:
        operation = self._capabilities.get_operation(
            request.capability,
            request.operation,
        )
        return list(operation.resource_requirements)

    def try_reserve(
        self,
        request: ExecutionRequest,
    ) -> ResourceAdmissionResult:
        requirements = self.requirements_for(request)

        if not requirements:
            return ResourceAdmissionResult.rejected(
                "execution requires no declared resources"
            )

        return self.try_reserve_requirements(
            execution_id=request.execution_id or new_id("exec"),
            requirements=requirements,
        )

    def try_reserve_requirements(
        self,
        *,
        execution_id: str,
        requirements: Iterable[ResourceRequirement],
    ) -> ResourceAdmissionResult:
        if not execution_id:
            raise ValueError("execution_id is required")

        normalized = self._policy.normalize(requirements)

        if not normalized:
            return ResourceAdmissionResult.rejected(
                "execution requires no declared resources"
            )

        with self._lock:
            existing_id = self._execution_reservations.get(execution_id)
            if existing_id is not None:
                existing = self._reservations[existing_id]
                if existing.requirements == normalized:
                    return ResourceAdmissionResult.accepted(existing)
                raise ValueError(
                    f"execution already has a different resource reservation: "
                    f"{execution_id!r}"
                )

            for kind, amount in normalized.items():
                capacity = self._capacities.get(kind)
                if capacity is None:
                    return ResourceAdmissionResult.rejected(
                        f"resource capacity is not registered: {kind!r}"
                    )
                if capacity.available < amount:
                    return ResourceAdmissionResult.rejected(
                        f"insufficient {kind} capacity: "
                        f"required={amount}, available={capacity.available}"
                    )

            reservation = ResourceReservation(
                execution_id=execution_id,
                requirements=dict(normalized),
            )

            for kind, amount in normalized.items():
                current = self._capacities[kind]
                self._capacities[kind] = ResourceCapacity(
                    kind=kind,
                    capacity=current.capacity,
                    reserved=current.reserved + amount,
                )

            self._reservations[reservation.reservation_id] = reservation
            self._execution_reservations[execution_id] = (
                reservation.reservation_id
            )

            self._publish(
                "ResourceReserved",
                execution_id,
                {
                    "reservation_id": reservation.reservation_id,
                    "execution_id": execution_id,
                    "requirements": dict(normalized),
                },
            )

            return ResourceAdmissionResult.accepted(reservation)

    def release(
        self,
        reservation_id: str,
    ) -> ResourceReservation:
        with self._lock:
            reservation = self._reservations.pop(reservation_id, None)
            if reservation is None:
                raise KeyError(reservation_id)

            self._execution_reservations.pop(
                reservation.execution_id,
                None,
            )

            for kind, amount in reservation.requirements.items():
                current = self._capacities.get(kind)
                if current is None:
                    raise RuntimeError(
                        f"reserved resource capacity disappeared: {kind!r}"
                    )

                if current.reserved < amount:
                    raise RuntimeError(
                        f"resource reservation underflow: {kind!r}"
                    )

                self._capacities[kind] = ResourceCapacity(
                    kind=kind,
                    capacity=current.capacity,
                    reserved=current.reserved - amount,
                )

            self._publish(
                "ResourceReleased",
                reservation.execution_id,
                {
                    "reservation_id": reservation.reservation_id,
                    "execution_id": reservation.execution_id,
                    "requirements": dict(reservation.requirements),
                },
            )

            return reservation

    def release_execution(
        self,
        execution_id: str,
    ) -> Optional[ResourceReservation]:
        with self._lock:
            reservation_id = self._execution_reservations.get(execution_id)
            if reservation_id is None:
                return None

        return self.release(reservation_id)

    def rebuild(self, events: Optional[Iterable[Event]] = None) -> None:
        if events is None:
            if self._event_bus is None:
                raise ValueError(
                    "events or event_bus is required for rebuild"
                )
            events = self._event_bus.history()

        with self._lock:
            reservations = {}
            execution_reservations = {}
            capacities = dict(self._capacities)

            for event in events:
                if event.type == "ResourceCapacityRegistered":
                    payload = event.payload
                    kind = str(payload["kind"])
                    capacities[kind] = ResourceCapacity(
                        kind=kind,
                        capacity=float(payload["capacity"]),
                    )

                elif event.type == "ResourceCapacityChanged":
                    payload = event.payload
                    kind = str(payload["kind"])
                    current = capacities.get(kind)
                    if current is None:
                        continue
                    capacities[kind] = ResourceCapacity(
                        kind=kind,
                        capacity=float(payload["capacity"]),
                        reserved=float(payload.get("reserved", 0.0)),
                    )

                elif event.type == "ResourceReserved":
                    payload = event.payload
                    reservation = ResourceReservation(
                        reservation_id=str(payload["reservation_id"]),
                        execution_id=str(payload["execution_id"]),
                        requirements={
                            str(kind): float(amount)
                            for kind, amount
                            in payload["requirements"].items()
                        },
                    )
                    reservations[reservation.reservation_id] = reservation
                    execution_reservations[
                        reservation.execution_id
                    ] = reservation.reservation_id

                elif event.type == "ResourceReleased":
                    payload = event.payload
                    reservation_id = str(payload["reservation_id"])
                    reservation = reservations.pop(
                        reservation_id,
                        None,
                    )
                    if reservation is not None:
                        execution_reservations.pop(
                            reservation.execution_id,
                            None,
                        )

            for kind, capacity in list(capacities.items()):
                reserved = 0.0
                for reservation in reservations.values():
                    reserved += reservation.requirements.get(kind, 0.0)
                capacities[kind] = ResourceCapacity(
                    kind=kind,
                    capacity=capacity.capacity,
                    reserved=reserved,
                )

            self._capacities = capacities
            self._reservations = reservations
            self._execution_reservations = execution_reservations

    def _publish(
        self,
        event_type: str,
        aggregate_id: str,
        payload: dict,
    ) -> None:
        if self._event_bus is None:
            return

        self._event_bus.publish(
            Event(
                type=event_type,
                aggregate_type="resource",
                aggregate_id=aggregate_id,
                source="resources",
                payload=payload,
            )
        )
