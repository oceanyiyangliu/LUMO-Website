from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Optional
import math

from ocean.core.clock import SYSTEM_CLOCK
from ocean.core.ids import new_id


@dataclass(frozen=True)
class ResourceCapacity:
    """Capacity and current reservation load for one resource kind."""

    kind: str
    capacity: float
    reserved: float = 0.0

    def __post_init__(self) -> None:
        if not self.kind:
            raise ValueError("resource kind is required")
        if not math.isfinite(float(self.capacity)) or self.capacity < 0:
            raise ValueError("resource capacity must be finite and non-negative")
        if not math.isfinite(float(self.reserved)) or self.reserved < 0:
            raise ValueError("reserved capacity must be non-negative")
        if self.reserved > self.capacity:
            raise ValueError("reserved capacity cannot exceed capacity")

    @property
    def available(self) -> float:
        return self.capacity - self.reserved


@dataclass(frozen=True)
class ResourceReservation:
    """Atomic reservation of concrete resource capacity for one execution."""

    execution_id: str
    requirements: Dict[str, float]
    reservation_id: str = field(default_factory=lambda: new_id("resource_reservation"))
    created_at: datetime = field(default_factory=lambda: SYSTEM_CLOCK.now())

    def __post_init__(self) -> None:
        if not self.execution_id:
            raise ValueError("execution_id is required")
        if not self.requirements:
            raise ValueError("reservation requires at least one resource")
        if any(not kind for kind in self.requirements):
            raise ValueError("resource kinds must be non-empty")
        if any(not isinstance(amount, (int, float)) or isinstance(amount, bool) or not math.isfinite(float(amount)) or amount <= 0 for amount in self.requirements.values()):
            raise ValueError("resource reservation amounts must be finite and positive")


@dataclass(frozen=True)
class ResourceAdmissionResult:
    admitted: bool
    reservation: Optional[ResourceReservation] = None
    reason: Optional[str] = None

    @classmethod
    def accepted(
        cls,
        reservation: ResourceReservation,
    ) -> "ResourceAdmissionResult":
        return cls(admitted=True, reservation=reservation)

    @classmethod
    def rejected(cls, reason: str) -> "ResourceAdmissionResult":
        return cls(admitted=False, reason=reason)
