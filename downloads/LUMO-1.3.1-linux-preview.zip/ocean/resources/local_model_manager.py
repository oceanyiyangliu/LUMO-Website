"""On-demand lifecycle management for LUMO's local Ollama models.

The manager separates model inventory from resource admission. It never downloads
large models implicitly unless auto-pull is explicitly enabled, and it exposes
safe inventory information to the intelligence layer.
"""
from __future__ import annotations

import json
import os
import subprocess
import shutil
import urllib.request
import threading
import time
from dataclasses import dataclass
from typing import Sequence, TYPE_CHECKING

if TYPE_CHECKING:
    from ocean.intelligence_router import ModelManifest


@dataclass(frozen=True)
class InstalledLocalModel:
    name: str
    size_bytes: int
    digest: str | None = None

    @property
    def size_gib(self) -> float:
        return self.size_bytes / (1024 ** 3)


class LocalModelManager:
    """Inventory and lifecycle management for LUMO's local Ollama model fleet."""

    DEFAULT_PACK = ("qwen3:4b", "qwen3:8b", "qwen2.5vl:7b", "devstral:24b", "qwen3:30b-a3b")
    BOOTSTRAP_MODEL = "qwen3:0.6b"

    def __init__(self, *, base_url: str | None = None) -> None:
        self.base_url = (base_url or os.getenv("OLLAMA_HOST", "http://127.0.0.1:11434")).rstrip("/")
        self._inventory_lock = threading.RLock()
        self._inventory_cache: tuple[InstalledLocalModel, ...] = ()
        self._inventory_checked_at = 0.0
        self._inventory_error: str | None = None

    @property
    def inventory_error(self) -> str | None:
        with self._inventory_lock:
            return self._inventory_error

    def inventory(self, *, max_age_seconds: float = 2.0) -> tuple[InstalledLocalModel, ...]:
        now = time.monotonic()
        with self._inventory_lock:
            if self._inventory_checked_at and now - self._inventory_checked_at < max_age_seconds:
                return self._inventory_cache
        request = urllib.request.Request(self.base_url + "/api/tags", method="GET")
        try:
            with urllib.request.urlopen(request, timeout=1.5) as response:
                payload = json.loads(response.read().decode())
            models = payload.get("models")
            if not isinstance(models, list):
                raise RuntimeError("Ollama returned invalid model inventory")
            result: list[InstalledLocalModel] = []
            for item in models:
                if not isinstance(item, dict) or not isinstance(item.get("name"), str):
                    continue
                size = int(item.get("size") or 0)
                if size <= 0:
                    continue
                result.append(InstalledLocalModel(item["name"], size, str(item.get("digest")) if item.get("digest") else None))
            result_tuple = tuple(result)
            with self._inventory_lock:
                self._inventory_cache = result_tuple
                self._inventory_checked_at = time.monotonic()
                self._inventory_error = None
            return result_tuple
        except Exception as exc:
            with self._inventory_lock:
                self._inventory_error = str(exc)
                # Preserve a last-known-good inventory during transient Ollama failures.
                self._inventory_checked_at = time.monotonic()
                return self._inventory_cache

    def inventory_live(self) -> tuple[InstalledLocalModel, ...]:
        with self._inventory_lock:
            self._inventory_checked_at = 0.0
        return self.inventory(max_age_seconds=0.0)


    def is_installed(self, model: str) -> bool:
        return any(item.name == model for item in self.inventory())

    def ensure_installed(self, model: str, *, allow_download: bool = False) -> InstalledLocalModel:
        installed = next((item for item in self.inventory() if item.name == model), None)
        if installed is not None:
            return installed
        if not allow_download:
            raise RuntimeError(f"local model {model!r} is not installed; download is disabled")
        completed = subprocess.run(
            ["ollama", "pull", model],
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=int(os.getenv("LUMO_MODEL_PULL_TIMEOUT_SECONDS", "1800")),
        )
        if completed.returncode != 0:
            raise RuntimeError(f"failed to install local model {model!r}: {completed.stdout[-2000:]}")
        installed = next((item for item in self.inventory() if item.name == model), None)
        if installed is None:
            raise RuntimeError(f"model {model!r} was pulled but is not visible in Ollama inventory")
        return installed

    def available_catalog(self, catalog: Sequence[ModelManifest]) -> tuple[ModelManifest, ...]:
        installed = {item.name for item in self.inventory()}
        return tuple(item for item in catalog if item.provider != "ollama" or item.name in installed)


@dataclass(frozen=True)
class ProvisioningResult:
    installed: tuple[str, ...]
    skipped: tuple[str, ...]
    failed: tuple[str, ...]
    reason: str | None = None

    def as_dict(self) -> dict:
        return {"installed": list(self.installed), "skipped": list(self.skipped), "failed": list(self.failed), "reason": self.reason}


def provision_standard_pack(*, manager: LocalModelManager | None = None, models: Sequence[str] | None = None,
                            minimum_free_gib: float = 12.0) -> ProvisioningResult:
    """Install LUMO's full standard local model pack when disk headroom permits.

    Disk provisioning is independent from RAM admission: downloaded models remain unloaded
    until the live resource governor selects a safe model.
    """
    manager = manager or LocalModelManager()
    targets = tuple(models or manager.DEFAULT_PACK)
    free_gib = shutil.disk_usage("/").free / (1024 ** 3)
    if free_gib < minimum_free_gib:
        return ProvisioningResult((), targets, (), f"only {free_gib:.1f} GiB free; need at least {minimum_free_gib:.1f} GiB")
    installed, skipped, failed = [], [], []
    for model in targets:
        try:
            if manager.is_installed(model):
                skipped.append(model)
                continue
            manager.ensure_installed(model, allow_download=True)
            installed.append(model)
        except Exception:
            failed.append(model)
    return ProvisioningResult(tuple(installed), tuple(skipped), tuple(failed))
