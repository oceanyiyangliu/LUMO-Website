"""Continuous, conservative device resource autopilot for LUMO.

Monitors live RAM/CPU pressure and proposes the least-disruptive recovery.
User applications are never force-killed. Automatic application quitting is
opt-in; default mode is recommend/ask. LUMO-owned work can be throttled safely.
"""
from __future__ import annotations

import os
import signal
import subprocess
import threading
import time

try:
    import psutil
except ImportError:
    psutil = None
from dataclasses import asdict, dataclass
from typing import Any, Callable

from .intelligence_governor import LocalResourceGovernor


@dataclass
class ResourceAutopilotState:
    enabled: bool = True
    mode: str = "ask"  # ask | auto
    pressure: bool = False
    available_ram_gib: float = 0.0
    safe_ai_ram_gib: float = 0.0
    cpu_percent: float = 0.0
    last_action: str | None = None
    recommendation: dict[str, Any] | None = None
    updated_at: float = 0.0


class ResourceAutopilot:
    """Always-on resource observer with explicit authority boundaries."""

    def __init__(self, api: Any, *, interval: float = 5.0):
        self.api = api
        self.interval = max(2.0, float(interval))
        self.governor = LocalResourceGovernor()
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._state = ResourceAutopilotState(
            mode=os.getenv("LUMO_RESOURCE_AUTOPILOT_MODE", "ask").strip().lower() or "ask",
            updated_at=time.time(),
        )
        if self._state.mode not in {"ask", "auto"}:
            self._state.mode = "ask"
        self._thread = threading.Thread(target=self._loop, name="lumo-resource-autopilot", daemon=True)
        self._thread.start()

    def status(self) -> dict[str, Any]:
        with self._lock:
            return asdict(self._state)

    def set_mode(self, mode: str) -> dict[str, Any]:
        mode = str(mode).strip().lower()
        if mode not in {"ask", "auto"}:
            raise ValueError("resource autopilot mode must be ask or auto")
        with self._lock:
            self._state.mode = mode
            self._state.updated_at = time.time()
        return self.status()

    def stop(self) -> None:
        self._stop.set()

    def approve_recommendation(self, *, names: list[str], reopen: bool = False) -> dict[str, Any]:
        """Execute only currently recommended, user-selected apps."""
        status = self.status()
        rec = status.get("recommendation") or {}
        allowed = {str(x.get("name", "")) for x in rec.get("apps", [])}
        selected = [str(x).strip() for x in names if str(x).strip() in allowed]
        if not selected:
            raise ValueError("no selected application is in the current recommendation")
        result = self.api.quit_memory_apps(selected)
        verified = [str(item.get("name", "")) for item in (result.get("verified", []) or []) if item.get("name")]
        if reopen:
            # Only reopen applications that LUMO actually verified as closed.
            # This prevents an "open" action from accidentally relaunching an app
            # whose graceful quit was rejected or blocked by unsaved work.
            reopen_names = [name for name in selected if name in verified]
            result["reopen_after"] = reopen_names
            if reopen_names:
                threading.Thread(target=self._reopen_after_pressure, args=(reopen_names,), daemon=True).start()
        with self._lock:
            self._state.last_action = "gracefully quit: " + ", ".join(selected)
            self._state.updated_at = time.time()
        return self.status() | {"result": result}

    def _sample_cpu(self) -> float:
        try:
            if psutil is not None:
                return max(0.0, min(100.0, float(psutil.cpu_percent(interval=0.15))))
        except Exception:
            pass
        return 0.0

    def _build_recommendation(self, memory: dict[str, Any], safe_gib: float) -> dict[str, Any] | None:
        pressure = bool(memory.get("memory_pressure", False))
        available = float(memory.get("available_ram_gib", 0) or 0)
        # Require both actual pressure and a meaningful AI shortfall before
        # recommending user-app intervention. This avoids churn on normal Macs.
        if not pressure and safe_gib >= 1.0:
            return None
        apps = list(memory.get("apps", []) or [])
        # Never recommend LUMO's own dependencies or core desktop infrastructure.
        # In particular, Ollama may look like a large background app but closing it
        # would destroy the local-AI path that Resource Autopilot is trying to save.
        protected = {"LUMO", "Ollama", "Finder", "System Events", "Dock", "WindowServer", "loginwindow", "System Settings"}
        candidates = []
        for app in apps:
            name = str(app.get("name", "")).strip()
            ram = float(app.get("memory_gib", 0) or 0)
            if not name or name in protected or ram < 0.25 or not bool(app.get("background_only", False)):
                continue
            candidates.append({
                "name": name,
                "pid": app.get("pid"),
                "memory_gib": ram,
                "reason": "background application consuming meaningful RAM",
                "action": "graceful_quit",
            })
        candidates.sort(key=lambda x: x["memory_gib"], reverse=True)
        if not candidates:
            return {"reason": "memory pressure detected, but no safe user-app candidate was identified", "apps": []}
        return {
            "reason": "free RAM before increasing LUMO's AI workload",
            "available_ram_gib": available,
            "apps": candidates[:5],
            "never_force_quit": True,
            "reopen_supported": True,
        }

    def _loop(self) -> None:
        while not self._stop.wait(self.interval):
            try:
                snap = self.governor.snapshot()
                memory = self.api.memory_state()
                safe_gib = snap.safe_ai_ram_bytes / 1024**3
                pressure = bool(memory.get("memory_pressure", False)) or safe_gib < 1.0
                recommendation = self._build_recommendation(memory, safe_gib)
                with self._lock:
                    self._state.pressure = pressure
                    self._state.available_ram_gib = round(snap.available_ram_bytes / 1024**3, 2)
                    self._state.safe_ai_ram_gib = round(safe_gib, 2)
                    self._state.cpu_percent = round(self._sample_cpu(), 1)
                    self._state.recommendation = recommendation
                    self._state.updated_at = time.time()
                # In auto mode, only act when the user has explicitly opted in.
                # Still use the same recommendation boundary and graceful quit API.
                if recommendation and self._state.mode == "auto" and recommendation.get("apps"):
                    names = [str(x["name"]) for x in recommendation["apps"][:1]]
                    self.approve_recommendation(names=names, reopen=False)
            except Exception as exc:
                with self._lock:
                    self._state.last_action = f"resource monitor error: {exc}"
                    self._state.updated_at = time.time()

    def _reopen_after_pressure(self, names: list[str]) -> None:
        deadline = time.monotonic() + 300
        while time.monotonic() < deadline and not self._stop.is_set():
            try:
                snap = self.governor.snapshot()
                if not (bool(self.api.memory_state().get("memory_pressure", False))):
                    for name in names:
                        subprocess.run(["/usr/bin/open", "-a", name], check=False, capture_output=True, timeout=8)
                    with self._lock:
                        self._state.last_action = "reopened after RAM pressure cleared: " + ", ".join(names)
                        self._state.updated_at = time.time()
                    return
            except Exception:
                pass
            time.sleep(5)
