"""Small cryptographic lifecycle primitives for local LUMO state."""
from __future__ import annotations
import base64
import hashlib
import hmac
import os
import secrets
from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class KeyMetadata:
    key_id: str
    algorithm: str = "HMAC-SHA256"
    created_at: float = 0.0
    active: bool = True

class KeyRing:
    """File-backed key ring with atomic writes and explicit rotation.

    This is a local foundation: production deployments should place the root
    key in an HSM/KMS rather than relying on a filesystem secret.
    """
    def __init__(self, path: str | Path):
        self.path = Path(path).expanduser().resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            self._load()
        else:
            self._keys = {}
            self._active = self._new_key()
            self._save()

    def _new_key(self) -> str:
        key_id = secrets.token_hex(16)
        self._keys[key_id] = base64.b64encode(secrets.token_bytes(32)).decode()
        return key_id

    def _save(self) -> None:
        import json
        payload = {"active": self._active, "keys": self._keys}
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, sort_keys=True), encoding="utf-8")
        os.chmod(tmp, 0o600)
        os.replace(tmp, self.path)
        os.chmod(self.path, 0o600)

    def _load(self) -> None:
        import json
        payload = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict) or not isinstance(payload.get("keys"), dict):
            raise ValueError("invalid key ring")
        self._keys = {str(k): str(v) for k, v in payload["keys"].items()}
        self._active = str(payload.get("active", ""))
        if self._active not in self._keys:
            raise ValueError("key ring has no active key")

    @property
    def active_key_id(self) -> str:
        return self._active

    def key_bytes(self, key_id: str) -> bytes:
        encoded = self._keys.get(str(key_id))
        if encoded is None:
            raise KeyError(key_id)
        return base64.b64decode(encoded)

    def rotate(self) -> str:
        self._active = self._new_key()
        self._save()
        return self._active

    def sign(self, data: bytes) -> tuple[str, str]:
        key_id = self._active
        key = base64.b64decode(self._keys[key_id])
        return key_id, hmac.new(key, data, hashlib.sha256).hexdigest()

    def verify(self, data: bytes, key_id: str, signature: str) -> bool:
        encoded = self._keys.get(str(key_id))
        if encoded is None:
            return False
        key = base64.b64decode(encoded)
        return hmac.compare_digest(hmac.new(key, data, hashlib.sha256).hexdigest(), str(signature))


class SnapshotCipher:
    """Authenticated AES-GCM encryption for local durable blobs."""
    def __init__(self, key_ring: KeyRing):
        self.key_ring = key_ring

    def encrypt(self, plaintext: bytes, *, aad: bytes = b"") -> str:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        key_id = self.key_ring.active_key_id
        nonce = os.urandom(12)
        ciphertext = AESGCM(self.key_ring.key_bytes(key_id)).encrypt(nonce, plaintext, aad)
        return "v1:" + base64.b64encode(key_id.encode() + b"\0" + nonce + ciphertext).decode()

    def decrypt(self, token: str, *, aad: bytes = b"") -> bytes:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        if not isinstance(token, str) or not token.startswith("v1:"):
            raise ValueError("invalid encrypted blob")
        raw = base64.b64decode(token[3:].encode(), validate=True)
        key_raw, rest = raw.split(b"\0", 1)
        if len(rest) < 12 + 16:
            raise ValueError("invalid encrypted blob")
        key_id = key_raw.decode()
        return AESGCM(self.key_ring.key_bytes(key_id)).decrypt(rest[:12], rest[12:], aad)
