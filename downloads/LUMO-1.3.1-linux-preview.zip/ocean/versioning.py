"""Canonical LUMO Core + platform variation versioning."""
from __future__ import annotations

from dataclasses import dataclass
import re

PLATFORM_IDS = {"macos": 1, "windows": 2, "linux": 3}
PLATFORM_NAMES = {value: key for key, value in PLATFORM_IDS.items()}
_VERSION_RE = re.compile(r"^(?P<core_major>\d+)\.(?P<platform>\d+)\.(?P<revision>\d+)$")


@dataclass(frozen=True, order=True)
class LumoVersion:
    """A release version: CORE.PLATFORM_VARIATION.PLATFORM_REVISION."""

    core: int
    platform_id: int
    revision: int

    def __post_init__(self) -> None:
        if self.core < 1 or self.platform_id not in PLATFORM_NAMES or self.revision < 1:
            raise ValueError("invalid LUMO version components")

    @property
    def platform(self) -> str:
        return PLATFORM_NAMES[self.platform_id]

    def __str__(self) -> str:
        return f"{self.core}.{self.platform_id}.{self.revision}"

    @classmethod
    def parse(cls, value: str) -> "LumoVersion":
        match = _VERSION_RE.fullmatch(value.strip().lstrip("Vv"))
        if not match:
            raise ValueError(f"invalid LUMO version: {value!r}")
        return cls(int(match["core_major"]), int(match["platform"]), int(match["revision"]))

    @classmethod
    def for_platform(cls, core: int, platform: str, revision: int = 1) -> "LumoVersion":
        try:
            platform_id = PLATFORM_IDS[platform.lower()]
        except KeyError as exc:
            raise ValueError(f"unsupported LUMO platform: {platform!r}") from exc
        return cls(core, platform_id, revision)


def platform_version(core: int, platform: str, revision: int = 1) -> str:
    return str(LumoVersion.for_platform(core, platform, revision))
