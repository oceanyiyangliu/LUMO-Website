from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, FrozenSet, Optional

from ocean.authorization.types import AuthorizationDecision
from ocean.domain.enums import ApprovalDecision, OrchestrationMode
from ocean.domain.policy import PolicyContext
from ocean.orchestration.policy import AdmissionDecision


@dataclass(frozen=True)
class GovernanceRequest:
    """Immutable control-plane request evaluated by Governance."""

    policy_context: PolicyContext
    principal_id: Optional[str] = None
    mode: OrchestrationMode = OrchestrationMode.STANDARD
    task_id: Optional[str] = None
    agent_id: Optional[str] = None
    mission_id: Optional[str] = None
    required_permissions: FrozenSet[str] = frozenset()
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class GovernanceDecision:
    """Deterministic composition of lower-level policy decisions."""

    allowed: bool
    approval: ApprovalDecision
    orchestration: AdmissionDecision
    authorization: Optional[AuthorizationDecision] = None
    reasons: tuple[str, ...] = ()
    requires_human: bool = False

    @property
    def executable(self) -> bool:
        """Whether governance permits execution without human approval."""

        return self.allowed and not self.requires_human
