from __future__ import annotations

"""Deterministic, governed capability discovery.

This module provides a small adapter around CapabilityRegistry that produces a
JSON-safe, stably ordered catalogue of capabilities including operation
metadata, risk levels, schemas, resource needs, and required permissions.

The discovery process is governed by a pluggable disclosure predicate
(allow_disclosure) which is a callable taking (capability_name, requester)
and returning a bool. This avoids coupling to a particular governance
implementation while allowing callers to enforce visibility rules.

Outputs are deterministic: capability names are sorted; operation names are
sorted; all enum/objects are materialized as primitives suitable for JSON
serialization.
"""

from typing import Any, Callable, Dict, Optional, List
import importlib

from ocean.domain.capability import CapabilityRegistry

AllowDisclosure = Callable[[str, Optional[Any]], bool]


class CapabilityDiscovery:
    """Expose a deterministic, governed view of installed CapabilitySpecs.

    Parameters
    - registry: the authoritative CapabilityRegistry instance
    - allow_disclosure: optional predicate (capability_name, requester) -> bool
      to determine whether a given capability should be visible to the
      requester. If omitted, all capabilities are visible.
    """

    def __init__(self, registry: CapabilityRegistry, allow_disclosure: Optional[AllowDisclosure] = None) -> None:
        self._registry = registry
        # default predicate: reveal everything
        self._allow = allow_disclosure or (lambda _name, _requester: True)

    def discover(self, requester: Optional[Any] = None) -> Dict[str, Any]:
        """Return a deterministic, JSON-safe catalogue of visible capabilities.

        The returned dict maps capability name -> metadata dict:
          - description
          - execution_strategy
          - requires_permissions: sorted list[str]
          - operations: mapping operation_name -> {
                description, risk_level (string), input_schema, output_schema,
                resource_requirements: [{kind, amount}, ...]
            }

        Ordering is deterministic: capability names sorted ascending; operation
        names sorted ascending.
        """
        # Pull authoritative list from the registry
        capabilities = self._registry.list_capabilities()

        # Filter via the disclosure predicate
        visible = [cap for cap in capabilities if self._allow(cap.name, requester)]

        # Sort capabilities by name to make output deterministic
        visible_sorted = sorted(visible, key=lambda c: c.name)

        result: Dict[str, Any] = {}

        for cap in visible_sorted:
            # Materialize capability-level primitives
            cap_entry: Dict[str, Any] = {
                "description": cap.description,
                "execution_strategy": cap.execution_strategy,
                "execution_policy": {
                    "isolation": cap.execution_policy.isolation.value,
                },
                "requires_permissions": sorted(list(cap.requires_permissions)),
                "operations": {},
            }

            # Sort operations by name for deterministic ordering
            for op_name in sorted(cap.operations.keys()):
                op = cap.operations[op_name]

                cap_entry["operations"][op_name] = {
                    "description": op.description,
                    # risk_level is an enum -- expose primitive value
                    "risk_level": op.risk_level.value,
                    "input_schema": op.input_schema if op.input_schema is not None else {},
                    "output_schema": op.output_schema if op.output_schema is not None else {},
                    "resource_requirements": [
                        {"kind": r.kind, "amount": r.amount} for r in op.resource_requirements
                    ],
                }

            # If the concrete capability module exposes an optional
            # `universal_action_mappings` dict, include it in the discovery
            # output so UAM-aware components can translate universal action
            # names into the capability's operation names. This is additive
            # and does not change capability behaviour.
            try:
                module = importlib.import_module(f"ocean.capabilities.{cap.name}")
                uam = getattr(module, "universal_action_mappings", None)
                if isinstance(uam, dict):
                    # deterministically ordered dict by sorted keys
                    cap_entry["universal_action_mappings"] = {
                        k: v for k, v in sorted(uam.items(), key=lambda item: item[0])
                    }
            except Exception:
                # Import errors or missing modules should not prevent discovery
                # of capabilities registered via CapabilityRegistry.
                pass

            result[cap.name] = cap_entry

        return result

    def capability(self, name: str, requester: Optional[Any] = None) -> Dict[str, Any]:
        catalogue = self.discover(requester)
        try:
            return catalogue[name]
        except KeyError as exc:
            raise KeyError(f"capability is not discoverable: {name!r}") from exc

    def operations(self, name: str, requester: Optional[Any] = None) -> Dict[str, Any]:
        return dict(self.capability(name, requester)["operations"])

    def operation(
        self,
        capability: str,
        operation: str,
        requester: Optional[Any] = None,
    ) -> Dict[str, Any]:
        try:
            return self.operations(capability, requester)[operation]
        except KeyError as exc:
            raise KeyError(f"operation is not discoverable: {capability}.{operation}") from exc
