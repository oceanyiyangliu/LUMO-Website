# Governance Plane v0.1

The Governance Plane is the OS-level policy composition boundary.

It composes:

- Domain Policy: operation risk and human approval.
- Orchestration Policy: assignment admission and execution-mode behaviour.

Governance may restrict lower-level decisions but never weakens them.

Governance does not own:

- resource reservation,
- scheduling,
- execution,
- agent lifecycle,
- verification,
- identity or permissions,
- authentication,
- human approval execution.

Resource capacity remains a scheduling concern and is not pre-consumed by Governance.

Governance v0.1 is deterministic and side-effect free. Callers may persist
the resulting decision as a durable fact without coupling the governance
engine to a particular event store.
