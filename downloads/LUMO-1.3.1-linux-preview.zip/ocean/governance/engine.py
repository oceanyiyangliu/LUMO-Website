from __future__ import annotations

from ocean.authorization import AuthorizationEngine, AuthorizationRequest
from ocean.domain.enums import ApprovalDecision
from ocean.domain.policy import PolicyEngine
from ocean.orchestration.policy import (
    OrchestrationPolicy,
    OrchestrationPolicyRegistry,
)

from .types import GovernanceDecision, GovernanceRequest


class GovernanceEngine:
    """OS-level governance boundary.

    Governance composes existing authorization, operation-policy, and
    orchestration-policy authorities. It does not replace scheduling,
    resource admission, execution, or agent lifecycle.

    Lower-level restrictions are never weakened by Governance.
    """

    def __init__(
        self,
        policy: PolicyEngine,
        orchestration_policies: OrchestrationPolicyRegistry | None = None,
        authorization: AuthorizationEngine | None = None,
    ) -> None:
        self._policy = policy
        self._orchestration_policies = (
            orchestration_policies or OrchestrationPolicyRegistry()
        )
        self._authorization = authorization

    def evaluate(self, request: GovernanceRequest) -> GovernanceDecision:
        operation_decision = self._policy.evaluate(request.policy_context)

        authorization_decision = None
        if self._authorization is not None:
            if request.principal_id is None:
                from ocean.authorization.types import AuthorizationDecision

                authorization_decision = AuthorizationDecision(
                    allowed=False,
                    reasons=("authorization requires a principal identity",),
                )
            else:
                required_permissions = request.required_permissions

                authorization_decision = self._authorization.authorize(
                    AuthorizationRequest(
                        principal_id=request.principal_id,
                        capability=request.policy_context.capability,
                        operation=request.policy_context.operation,
                        required_permissions=required_permissions,
                        metadata=request.policy_context.metadata,
                    )
                )

        # Orchestration admission requires a real assignment context.
        # Authorization-only governance evaluation must not manufacture an
        # AssignmentRequest merely to satisfy the orchestration policy.
        orchestration_decision = None
        if request.task_id and request.agent_id:
            orchestration_policy: OrchestrationPolicy = (
                self._orchestration_policies.get(request.mode)
            )
            orchestration_decision = orchestration_policy.admission(
                self._assignment_request(request)
            )

        reasons: list[str] = []

        if (
            orchestration_decision is not None
            and not orchestration_decision.allowed
        ):
            reasons.append(
                orchestration_decision.reason
                or "orchestration policy denied admission"
            )

        if operation_decision == ApprovalDecision.DENIED:
            reasons.append("operation policy denied execution")

        if authorization_decision is not None and not authorization_decision.allowed:
            reasons.extend(authorization_decision.reasons)

        requires_human = self._policy.requires_human(operation_decision)

        if requires_human:
            reasons.append(
                f"operation policy requires human approval: "
                f"{operation_decision.value}"
            )

        allowed = (
            (
                orchestration_decision is None
                or orchestration_decision.allowed
            )
            and operation_decision != ApprovalDecision.DENIED
            and (
                authorization_decision is None
                or authorization_decision.allowed
            )
        )

        return GovernanceDecision(
            allowed=allowed,
            approval=operation_decision,
            orchestration=orchestration_decision,
            authorization=authorization_decision,
            reasons=tuple(reasons),
            requires_human=requires_human,
        )

    @staticmethod
    def _assignment_request(request: GovernanceRequest):
        from ocean.orchestration.types import AssignmentRequest

        if not request.task_id:
            raise ValueError(
                "governance evaluation requires task_id for orchestration admission"
            )

        if not request.agent_id:
            raise ValueError(
                "governance evaluation requires agent_id for orchestration admission"
            )

        return AssignmentRequest(
            task_id=request.task_id,
            agent_id=request.agent_id,
            principal_id=request.principal_id,
            mission_id=request.mission_id,
            mode=request.mode,
            metadata={
                **request.policy_context.metadata,
                **request.metadata,
            },
        )
