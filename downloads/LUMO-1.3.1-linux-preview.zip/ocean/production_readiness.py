"""Production-readiness gates for LUMO's first launch."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping
import os


PRODUCTION_REQUIRED_ENV = (
    "LUMO_API_AUTH_REQUIRED",
    "LUMO_API_SESSION_BOOTSTRAP_SECRET",
    "LUMO_API_SESSION_SECRET",
)


def production_config_gates(environ: Mapping[str, str] | None = None) -> dict[str, bool]:
    """Evaluate security-critical deployment configuration without exposing secrets."""
    env = os.environ if environ is None else environ
    auth_required = env.get("LUMO_API_AUTH_REQUIRED") == "1"
    session_secret = str(env.get("LUMO_API_SESSION_SECRET", ""))
    bootstrap_secret = str(env.get("LUMO_API_SESSION_BOOTSTRAP_SECRET", ""))
    cert = str(env.get("LUMO_TLS_CERT_FILE", "")).strip()
    key = str(env.get("LUMO_TLS_KEY_FILE", "")).strip()
    health_url = str(env.get("LUMO_HEALTH_URL", "")).strip()
    alert_file = str(env.get("LUMO_ALERT_FILE", "")).strip()
    resend_key = str(env.get("RESEND_API_KEY", "")).strip()
    email_from = str(env.get("LUMO_EMAIL_FROM", "")).strip()
    direct_smtp = env.get("LUMO_EMAIL_DIRECT_SMTP", "") == "1"
    direct_host = str(env.get("LUMO_EMAIL_SMTP_HOST", "")).strip()
    direct_username = str(env.get("LUMO_EMAIL_SMTP_USERNAME", "")).strip()
    direct_password = str(env.get("LUMO_EMAIL_SMTP_PASSWORD", ""))
    webhook_url = str(env.get("LUMO_EMAIL_WEBHOOK_URL", "")).strip()
    webhook_secret = str(env.get("LUMO_EMAIL_WEBHOOK_SECRET", ""))
    direct_ready = bool(direct_smtp and direct_host and direct_username and direct_password and email_from)
    resend_ready = bool(resend_key and email_from)
    webhook_ready = bool(webhook_url.startswith("https://") and len(webhook_secret) >= 16)
    email_configured = direct_ready or resend_ready or webhook_ready
    return {
        "production_auth": auth_required,
        "production_secrets": bool(session_secret) and len(session_secret) >= 32 and bool(bootstrap_secret) and len(bootstrap_secret) >= 16,
        "production_tenant_store": bool(env.get("LUMO_TENANCY_STORE", "").strip()),
        "https_gateway": bool(cert and key),
        "monitoring_alerts": bool(health_url.startswith("https://") and alert_file),
        "email_delivery": email_configured,
    }


def email_delivery_preflight(environ: Mapping[str, str] | None = None) -> dict[str, object]:
    """Return safe, non-secret diagnostics for transactional-email deployment."""
    env = os.environ if environ is None else environ
    direct = {
        "ready": env.get("LUMO_EMAIL_DIRECT_SMTP", "") == "1"
        and bool(str(env.get("LUMO_EMAIL_SMTP_HOST", "")).strip())
        and bool(str(env.get("LUMO_EMAIL_SMTP_USERNAME", "")).strip())
        and bool(str(env.get("LUMO_EMAIL_SMTP_PASSWORD", "")))
        and bool(str(env.get("LUMO_EMAIL_FROM", "")).strip()),
        "missing": [],
    }
    for key in ("LUMO_EMAIL_DIRECT_SMTP", "LUMO_EMAIL_SMTP_HOST", "LUMO_EMAIL_SMTP_USERNAME", "LUMO_EMAIL_SMTP_PASSWORD", "LUMO_EMAIL_FROM"):
        if not str(env.get(key, "")).strip() or (key == "LUMO_EMAIL_DIRECT_SMTP" and env.get(key) != "1"):
            direct["missing"].append(key)
    resend = {"ready": bool(str(env.get("RESEND_API_KEY", "")).strip() and str(env.get("LUMO_EMAIL_FROM", "")).strip()), "missing": []}
    for key in ("RESEND_API_KEY", "LUMO_EMAIL_FROM"):
        if not str(env.get(key, "")).strip(): resend["missing"].append(key)
    webhook = {"ready": bool(str(env.get("LUMO_EMAIL_WEBHOOK_URL", "")).strip().startswith("https://") and len(str(env.get("LUMO_EMAIL_WEBHOOK_SECRET", ""))) >= 16), "missing": []}
    if not str(env.get("LUMO_EMAIL_WEBHOOK_URL", "")).strip().startswith("https://"): webhook["missing"].append("LUMO_EMAIL_WEBHOOK_URL")
    if len(str(env.get("LUMO_EMAIL_WEBHOOK_SECRET", ""))) < 16: webhook["missing"].append("LUMO_EMAIL_WEBHOOK_SECRET")
    provider = "direct_smtp" if direct["ready"] else "resend" if resend["ready"] else "webhook" if webhook["ready"] else "unconfigured"
    return {"ready": provider != "unconfigured", "provider": provider, "direct_smtp": direct, "resend": resend, "webhook": webhook}


def validate_production_config(environ: Mapping[str, str] | None = None) -> None:
    """Raise before startup when a production deployment is incompletely secured."""
    gates = production_config_gates(environ)
    missing = tuple(name for name, passed in gates.items() if not passed)
    if missing:
        raise RuntimeError("production configuration is incomplete: " + ", ".join(missing))


@dataclass(frozen=True)
class LaunchGateReport:
    gates: Mapping[str, bool]

    @property
    def blocking(self) -> tuple[str, ...]:
        return tuple(name for name, passed in self.gates.items() if not passed)

    @property
    def ready(self) -> bool:
        return not self.blocking


HARD_LAUNCH_GATES = (
    "doctor",
    "regression",
    "security",
    "authorization_isolation",
    "durability_recovery",
    "verification",
    "kill_pause_takeover",
    "clean_install",
    "backup_restore",
    "update_rollback",
    "production_auth",
    "production_tenant_store",
    "production_secrets",
    "https_gateway",
    "monitoring_alerts",
    "email_delivery",
)


def evaluate_launch_gates(results: Mapping[str, bool]) -> LaunchGateReport:
    return LaunchGateReport({
        gate: bool(results.get(gate, False)) for gate in HARD_LAUNCH_GATES
    })


def format_launch_report(report: LaunchGateReport) -> str:
    status = "READY" if report.ready else "BLOCKED"
    lines = [f"LUMO LAUNCH: {status}"]
    for gate, passed in report.gates.items():
        lines.append(("PASS " if passed else "BLOCK ") + gate)
    return "\n".join(lines)
