from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, Iterable, List, Optional, Protocol, Set, Tuple

from ocean.domain.event import Event
from ocean.domain.mission import Mission
from ocean.orchestration.orchestrator import Orchestrator, OrchestrationPorts
from ocean.orchestration.types import AssignmentRequest
from ocean.orchestration.mission_engine import MissionObjective
from ocean.domain.agent import Agent
from ocean.domain.task import Task
from ocean.core.ids import new_id
from ocean.domain.enums import OrchestrationMode


class AgentDirectory(Protocol):
    """Optional directory that can enumerate agents known to the environment.

    If not supplied, MultiAgentManager maintains a small in-memory registry
    populated via register_agent/unregister_agent.
    """

    def list(self) -> Iterable[Agent]:
        ...


class AgentSelector(Protocol):
    """Strategy interface to select an agent id for an objective."""

    def select(self, candidates: Iterable[Agent], objective: MissionObjective) -> Optional[str]:
        ...


class LifecycleHook(Protocol):
    def __call__(self, event: Event) -> None:
        ...


@dataclass
class RoundRobinAgentSelector:
    """Simple round-robin selector over a candidate list keyed by capability.

    The selector inspects objective.metadata.get('required_capability') or
    objective.metadata.get('capability') to filter candidate agents.
    """

    indices: Dict[str, int] = field(default_factory=dict)

    def select(self, candidates: Iterable[Agent], objective: MissionObjective) -> Optional[str]:
        capability = (
            str(objective.metadata.get("required_capability") or objective.metadata.get("capability", "")).strip()
        )
        filtered = [agent for agent in candidates if (not capability) or capability in agent.capabilities]
        if not filtered:
            return None
        key = capability or "__any__"
        idx = self.indices.get(key, 0) % len(filtered)
        self.indices[key] = (idx + 1) % len(filtered)
        return filtered[idx].id


@dataclass
class ExecutionAgentResolver:
    """Adapter that resolves an ExecutionStep to an agent id using a MultiAgentManager.

    This object matches the minimal resolver protocol expected by
    ExecutionPlanRunner.resolve(step) in existing code: a .resolve(step)
    method returning an agent id string.
    """

    manager: "MultiAgentManager"

    def resolve(self, step) -> str:
        # Expect step.intent.capability to be present.
        capability = getattr(step, "intent", None)
        if capability is None:
            raise ValueError("execution step has no intent")
        # defensive: the intent object is expected to expose 'capability'
        cap = getattr(step.intent, "capability", None)
        if not cap:
            # fallback: allow the manager to pick any available agent
            agent_id = self.manager.select_agent_for_capability(None)
        else:
            # Construct a tiny MissionObjective-like proxy to reuse matching logic
            proxy = MissionObjective(
                objective_id=getattr(step, "node_id", new_id("objective")),
                objective=getattr(step, "task_id", str(getattr(step, "node_id", ""))),
                metadata={"required_capability": cap},
            )
            agent_id = self.manager.select_agent_for_capability(cap, proxy)

        if not agent_id:
            raise ValueError(f"no agent available for execution step requiring capability {cap!r}")
        return agent_id


class MultiAgentManager:
    """Central manager for agent lifecycle, objective acceptance, assignment and hooks.

    Responsibilities:
    - maintain a registry of known agents (in-memory or via AgentDirectory)
    - apply a selection strategy to map objectives to agents
    - accept or reject mission objectives according to dependency readiness
    - create durable assignments via the Orchestrator.assign() API
    - subscribe to scheduling events and invoke lifecycle hooks
    - provide an ExecutionAgentResolver for plan runners

    The manager intentionally delegates persistence and lifecycle transitions
    to the existing Orchestrator / OrchestrationPorts implementation.
    """

    def __init__(
        self,
        orchestrator: Orchestrator,
        ports: OrchestrationPorts,
        *,
        agent_directory: Optional[AgentDirectory] = None,
        selector: Optional[AgentSelector] = None,
    ) -> None:
        if orchestrator is None:
            raise ValueError("orchestrator is required")
        if ports is None:
            raise ValueError("ports is required")

        self._orchestrator = orchestrator
        self._ports = ports
        self._agent_directory = agent_directory
        self._selector: AgentSelector = selector or RoundRobinAgentSelector()

        # fallback in-memory registry when AgentDirectory is not provided
        self._local_agents: Dict[str, Agent] = {}

        # lifecycle hooks keyed by scheduler event type
        self._hooks: Dict[str, List[LifecycleHook]] = {}

        # subscribe to scheduling lifecycle events to forward to hooks
        self._ports.events.subscribe("ScheduledExecutionDispatched", self._on_scheduled_event)
        self._ports.events.subscribe("ScheduledExecutionCompleted", self._on_scheduled_event)
        self._ports.events.subscribe("ScheduledExecutionFailed", self._on_scheduled_event)

    # ----------------------- Agent registry API -----------------------
    def register_agent(self, agent: Agent) -> None:
        """Register an agent with the manager (keeps an in-memory record).

        Prefer providing an AgentDirectory capable of enumerating agents in
        production. This method is intended for dynamic registration or tests.
        """
        if agent is None or not getattr(agent, "id", None):
            raise ValueError("agent must be a valid Agent instance with an id")
        self._local_agents[agent.id] = agent

    def unregister_agent(self, agent_id: str) -> None:
        self._local_agents.pop(agent_id, None)

    def list_agents(self) -> List[Agent]:
        if self._agent_directory is not None:
            return list(self._agent_directory.list())
        return list(self._local_agents.values())

    # ----------------------- Selection helpers -----------------------
    def select_agent_for_capability(self, capability: Optional[str], objective: Optional[MissionObjective] = None) -> Optional[str]:
        """Return an agent id that can perform the given capability.

        If capability is None, the selector may return any registered agent.
        """
        agents = self.list_agents()
        if not agents:
            return None
        # If an objective proxy wasn't provided, create a minimal one to pass to selector
        if objective is None:
            objective = MissionObjective(objective_id=new_id("mission_objective"), objective="", metadata={"required_capability": capability} )
        return self._selector.select(agents, objective)

    # ----------------------- Objective acceptance -----------------------
    def accept_objective(self, objective: MissionObjective, completed_objective_ids: Iterable[str]) -> bool:
        """Return True iff the objective's declared dependencies are satisfied.

        This is intentionally dependency-only acceptance: policies around
        capability availability or other admission checks are performed at
        assignment time when durable AssignmentRequest is built.
        """
        completed = set(str(x) for x in completed_objective_ids)
        required = set(objective.dependencies or ())
        return required.issubset(completed)

    # ----------------------- Assignment flow -----------------------
    def assign_objective_to_agent(
        self,
        task: Task,
        agent_id: Optional[str] = None,
        mission_id: Optional[str] = None,
        *,
        priority: int = 0,
        mode: OrchestrationMode = OrchestrationMode.STANDARD,
        reason: Optional[str] = None,
        metadata: Optional[dict] = None,
    ) -> Tuple[bool, Optional[str], Optional[str], Optional[str]]:
        """Create and persist an assignment for a task, returning a tuple:
        (success, assignment_id, execution_id, error)

        If agent_id is None, the manager will attempt to select one via the selector.
        """
        if task is None or not getattr(task, "id", None):
            return False, None, None, "invalid task"

        capability = (metadata or {}).get("required_capability") or (getattr(task, "capability", None) or (getattr(task, "metadata", {}) or {}).get("capability"))
        selected_agent = agent_id
        if selected_agent is None:
            selected_agent = self.select_agent_for_capability(capability)
        if not selected_agent:
            return False, None, None, "no agent available for required capability"

        request = AssignmentRequest(
            task_id=task.id,
            agent_id=selected_agent,
            mission_id=mission_id,
            mode=mode,
            priority=priority,
            parent_assignment_id=None,
            reason=reason,
            metadata=dict(metadata or {}),
        )

        try:
            result = self._orchestrator.assign(request)
        except Exception as exc:  # pragma: no cover - defensive
            return False, None, None, f"assignment failed: {exc}"

        if not result.success:
            return False, getattr(result, "assignment_id", None), getattr(result, "execution_id", None), result.error

        return True, getattr(result, "assignment_id", None), getattr(result, "execution_id", None), None

    # ----------------------- Scheduling hook integration -----------------------
    def add_hook(self, scheduler_event_type: str, hook: LifecycleHook) -> None:
        self._hooks.setdefault(scheduler_event_type, []).append(hook)

    def remove_hook(self, scheduler_event_type: str, hook: LifecycleHook) -> None:
        lst = self._hooks.get(scheduler_event_type)
        if not lst:
            return
        try:
            lst.remove(hook)
        except ValueError:
            pass

    def _on_scheduled_event(self, event: Event) -> None:
        """Internal subscriber forwarded to registered hooks.

        This handler is idempotent and lightweight: it forwards the raw
        Event object to hook callables and captures exceptions to avoid
        interrupting event processing.
        """
        hooks = list(self._hooks.get(event.type, ()))
        for hook in hooks:
            try:
                hook(event)
            except Exception:
                # swallow exceptions to avoid affecting event bus processing;
                # callers should ensure hooks are robust or wrap them.
                continue

    # ----------------------- Integration surface -----------------------
    def execution_agent_resolver(self) -> ExecutionAgentResolver:
        """Return an ExecutionAgentResolver bound to this manager.

        ExecutionPlanRunner and other consumers can call this to obtain a
        stable resolver implementation.
        """
        return ExecutionAgentResolver(self)

