"""Run compiled execution plans through Ocean orchestration."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Mapping, Protocol

from ocean.execution.compiler import ExecutionPlan, ExecutionStep
from ocean.orchestration.orchestrator import Orchestrator
from ocean.orchestration.types import AssignmentRequest
from ocean.self_improvement.execution_boundary import (
    CandidateExecutionBoundary,
    CandidateExecutionContext,
)
from ocean.domain.enums import OrchestrationMode


class ExecutionAgentResolver(Protocol):
    """Resolve an executable step to the agent responsible for it."""

    def resolve(self, step: ExecutionStep) -> str:
        ...


@dataclass(frozen=True)
class ExecutionPlanRunResult:
    """Result of submitting an executable plan frontier."""

    plan_revision_id: str
    assignment_ids: Mapping[str, str] = field(default_factory=dict)
    execution_ids: Mapping[str, str] = field(default_factory=dict)
    queued_node_ids: tuple[str, ...] = ()
    blocked_node_ids: tuple[str, ...] = ()
    errors: Mapping[str, str] = field(default_factory=dict)

    @property
    def success(self) -> bool:
        return not self.errors

    def assignment_id_for(self, node_id: str) -> str:
        return self.assignment_ids[node_id]

    def execution_id_for(self, node_id: str) -> str:
        return self.execution_ids[node_id]


class ExecutionPlanRunner:
    """Bridge a compiled ExecutionPlan into the orchestration control plane.

    The runner translates compiled node dependencies into runtime execution
    dependencies and delegates assignment and dispatch to Orchestrator.

    It does not own scheduling, execution, verification, or agent lifecycle.
    It does not wait synchronously for execution completion.

    Frontier advancement is explicit through ``start_frontier()``. This keeps
    execution outcomes authoritative and allows a higher-level durable
    coordinator to drive subsequent frontiers from persisted events.
    """

    _candidate_execution_boundary = CandidateExecutionBoundary()

    def __init__(
        self,
        orchestrator: Orchestrator,
        agent_resolver: ExecutionAgentResolver,
        candidate_execution_boundary: CandidateExecutionBoundary | None = None,
    ) -> None:
        if orchestrator is None:
            raise ValueError("orchestrator is required")
        if agent_resolver is None:
            raise ValueError("agent_resolver is required")
        self._orchestrator = orchestrator
        self._agent_resolver = agent_resolver
        self._candidate_execution_boundary = (
            candidate_execution_boundary or CandidateExecutionBoundary()
        )

    @property
    def orchestrator(self) -> Orchestrator:
        return self._orchestrator

    @property
    def agent_resolver(self) -> ExecutionAgentResolver:
        return self._agent_resolver

    def start(
        self,
        plan: ExecutionPlan,
        *,
        mode: OrchestrationMode = OrchestrationMode.STANDARD,
        priority: int = 0,
        candidate_execution: CandidateExecutionContext | None = None,
    ) -> ExecutionPlanRunResult:
        """Submit the initial executable frontier of a plan.

        Root steps are submitted immediately. Steps with dependencies are
        reported as blocked until their dependencies have completed.
        """
        if plan is None:
            raise ValueError("execution plan is required")

        self._validate_priority(priority)

        return self._start_ready_steps(
            plan,
            completed_node_ids=set(),
            node_execution_ids={},
            mode=mode,
            priority=priority,
            candidate_execution=candidate_execution,
        )

    def start_frontier(
        self,
        plan: ExecutionPlan,
        *,
        completed_node_ids: set[str] | frozenset[str] | tuple[str, ...],
        node_execution_ids: Mapping[str, str],
        submitted_node_ids: set[str] | frozenset[str] | tuple[str, ...] = (),
        mode: OrchestrationMode = OrchestrationMode.STANDARD,
        priority: int = 0,
        candidate_execution: CandidateExecutionContext | None = None,
    ) -> ExecutionPlanRunResult:
        """Submit the next executable frontier after dependency completion.

        ``completed_node_ids`` is the authoritative set of completed plan
        nodes. ``node_execution_ids`` maps completed dependency nodes to the
        concrete runtime execution IDs that Scheduler must depend upon.
        """
        if plan is None:
            raise ValueError("execution plan is required")

        self._validate_priority(priority)

        completed = set(completed_node_ids)
        submitted = set(submitted_node_ids)

        known_nodes = {step.node_id for step in plan.steps}

        unknown_completed = completed - known_nodes
        if unknown_completed:
            raise ValueError(
                "completed_node_ids contains unknown execution steps: "
                f"{sorted(unknown_completed)!r}"
            )

        unknown_submitted = submitted - known_nodes
        if unknown_submitted:
            raise ValueError(
                "submitted_node_ids contains unknown execution steps: "
                f"{sorted(unknown_submitted)!r}"
            )

        return self._start_ready_steps(
            plan,
            completed_node_ids=completed,
            submitted_node_ids=submitted,
            node_execution_ids=node_execution_ids,
            mode=mode,
            priority=priority,
            candidate_execution=candidate_execution,
        )

    def _start_ready_steps(
        self,
        plan: ExecutionPlan,
        *,
        completed_node_ids: set[str],
        submitted_node_ids: set[str] | frozenset[str] = (),
        node_execution_ids: Mapping[str, str],
        mode: OrchestrationMode,
        priority: int,
        candidate_execution: CandidateExecutionContext | None,
    ) -> ExecutionPlanRunResult:
        ready_steps = tuple(
            step
            for step in plan.ready_steps(completed_node_ids)
            if step.node_id not in submitted_node_ids
        )

        candidate_validation_error = None
        try:
            self._validate_candidate_execution(plan, candidate_execution)
        except ValueError as exc:
            candidate_validation_error = str(exc)

        ready_node_ids = {step.node_id for step in ready_steps}

        assignment_ids: Dict[str, str] = {}
        execution_ids: Dict[str, str] = {}
        queued: list[str] = []
        errors: Dict[str, str] = {}

        for step in ready_steps:
            if candidate_validation_error is not None:
                errors[step.node_id] = candidate_validation_error
                continue

            dependency_execution_ids = set()

            missing_dependency = None

            for dependency_node_id in step.depends_on_node_ids:
                dependency_execution_id = node_execution_ids.get(
                    dependency_node_id
                )

                if dependency_execution_id is None:
                    missing_dependency = dependency_node_id
                    break

                dependency_execution_ids.add(
                    dependency_execution_id
                )

            if missing_dependency is not None:
                errors[step.node_id] = (
                    f"missing execution ID for completed dependency "
                    f"{missing_dependency!r}"
                )
                continue

            try:
                assignment_id, execution_id = self._submit_step(
                    plan,
                    step,
                    mode=mode,
                    priority=priority,
                    dependency_execution_ids=dependency_execution_ids,
                    candidate_execution=candidate_execution,
                )
            except Exception as exc:
                errors[step.node_id] = str(exc)
                continue

            assignment_ids[step.node_id] = assignment_id
            execution_ids[step.node_id] = execution_id
            queued.append(step.node_id)

        blocked = tuple(
            step.node_id
            for step in plan.steps
            if step.node_id not in completed_node_ids
            and step.node_id not in ready_node_ids
            and step.node_id not in errors
        )

        return ExecutionPlanRunResult(
            plan_revision_id=plan.plan_revision_id,
            assignment_ids=dict(assignment_ids),
            execution_ids=dict(execution_ids),
            queued_node_ids=tuple(queued),
            blocked_node_ids=blocked,
            errors=dict(errors),
        )

    def _submit_step(
        self,
        plan: ExecutionPlan,
        step: ExecutionStep,
        *,
        mode: OrchestrationMode,
        priority: int,
        dependency_execution_ids: set[str],
        candidate_execution: CandidateExecutionContext | None,
    ) -> tuple[str, str]:
        self._validate_candidate_execution(plan, candidate_execution)

        agent_id = self._agent_resolver.resolve(step)

        if not agent_id:
            raise ValueError(
                f"agent resolver returned no agent for step {step.node_id!r}"
            )

        assignment_result = self._orchestrator.assign(
            AssignmentRequest(
                task_id=step.task_id,
                agent_id=agent_id,
                mission_id=plan.mission_id,
                mode=mode,
                priority=priority,
                metadata={
                    "execution_plan_id": plan.plan_revision_id,
                    "execution_node_id": step.node_id,
                    **(
                        dict(candidate_execution.metadata)
                        if candidate_execution is not None
                        else {}
                    ),
                },
            )
        )

        if not assignment_result.success:
            raise ValueError(
                assignment_result.error
                or f"failed to assign step {step.node_id!r}"
            )

        assignment_id = assignment_result.assignment_id

        if assignment_id is None:
            raise ValueError(
                f"assignment for step {step.node_id!r} "
                "returned no assignment ID"
            )

        dispatch_result = self._orchestrator.dispatch(
            assignment_id,
            step.intent,
            dependency_execution_ids=dependency_execution_ids,
        )

        if not dispatch_result.success:
            raise ValueError(
                dispatch_result.error
                or f"failed to dispatch step {step.node_id!r}"
            )

        execution_id = dispatch_result.execution_id

        if execution_id is None:
            raise ValueError(
                f"dispatch for step {step.node_id!r} "
                "returned no execution ID"
            )

        return assignment_id, execution_id

    @staticmethod
    def _validate_candidate_execution(
        plan: ExecutionPlan,
        candidate_execution: CandidateExecutionContext | None,
    ) -> None:
        if candidate_execution is None:
            return
        if plan.mission_id != candidate_execution.candidate_mission_id:
            raise ValueError(
                "candidate execution mission does not match execution plan"
            )
        if plan.plan_revision_id != candidate_execution.candidate_plan_revision_id:
            raise ValueError(
                "candidate execution plan does not match execution plan"
            )
        metadata = dict(candidate_execution.metadata)
        required = {
            "candidate_execution",
            "candidate_mission_id",
            "source_mission_id",
            "candidate_plan_revision_id",
            "source_plan_revision_id",
        }
        missing = required - metadata.keys()
        if missing:
            raise ValueError(
                "candidate execution metadata missing required fields: "
                f"{sorted(missing)!r}"
            )
        if metadata["candidate_execution"] is not True:
            raise ValueError(
                "candidate execution metadata must set candidate_execution to true"

            )
        if metadata["candidate_mission_id"] != candidate_execution.candidate_mission_id:
            raise ValueError(
                "candidate execution metadata mission identity mismatch"
            )
        if metadata["candidate_plan_revision_id"] != candidate_execution.candidate_plan_revision_id:
            raise ValueError(
                "candidate execution metadata plan identity mismatch"
            )
        if metadata["candidate_mission_id"] == metadata["source_mission_id"]:
            raise ValueError(
                "candidate execution cannot use the source mission"
            )
        if metadata["candidate_plan_revision_id"] == metadata["source_plan_revision_id"]:
            raise ValueError(
                "candidate execution cannot use the source plan"
            )

    @staticmethod
    def _validate_priority(priority: int) -> None:
        if priority < 0:
            raise ValueError("priority must be non-negative")
