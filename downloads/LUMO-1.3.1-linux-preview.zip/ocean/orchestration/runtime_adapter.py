from __future__ import annotations

from typing import Protocol

from runtime.control import CancellationToken
from runtime.runtime import ExecutionRuntime
from runtime.types import ExecutionRequest

from .mission_engine import (
    MissionObjective,
    MissionObjectiveExecution,
    MissionObjectiveResult,
)


class MissionObjectiveRequestFactory(Protocol):
    def __call__(
        self,
        mission_id: str,
        objective: MissionObjective,
    ) -> ExecutionRequest:
        ...


class ExecutionRuntimeMissionObjectiveAdapter:
    """Translate one typed mission objective into governed runtime execution."""

    def __init__(
        self,
        *,
        runtime: ExecutionRuntime,
        request_factory: MissionObjectiveRequestFactory,
    ) -> None:
        self._runtime = runtime
        self._request_factory = request_factory

    def execute(
        self,
        mission_id: str,
        objective: MissionObjective,
        execution: MissionObjectiveExecution,
    ) -> MissionObjectiveResult:
        request = self._request_factory(mission_id, objective)
        cancellation = (
            CancellationToken.from_event(execution.batch_cancel)
            if execution.batch_cancel is not None
            else None
        )
        result = self._runtime.execute(
            request,
            cancellation=cancellation,
            timeout_seconds=execution.lease_seconds,
            deadline=execution.deadline,
        )

        metadata = {
            "work_type": objective.work_type,
            "attempt_id": execution.attempt_id,
            "execution_id": request.execution_id,
            **dict(result.metadata),
        }

        if result.success:
            return MissionObjectiveResult(
                objective_id=objective.objective_id,
                objective=objective.objective,
                status="completed",
                metadata=metadata,
            )

        stale = result.metadata.get("failure_type") == "timeout"
        return MissionObjectiveResult(
            objective_id=objective.objective_id,
            objective=objective.objective,
            status="stale" if stale else "rejected",
            error=result.error,
            metadata={
                **metadata,
                "retryable": result.metadata.get("retryable") is True or stale,
                "stale": stale,
                "lease_expiry_event_published": False,
            },
        )