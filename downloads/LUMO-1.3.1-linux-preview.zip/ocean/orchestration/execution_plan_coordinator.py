"""Durable event-driven progression of compiled execution plans.

The coordinator advances execution-plan frontiers from durable assignment
events.  It reacts to both completion *and* failure events:

* **Completion** -- the coordinator reconstructs plan progress and submits
  the next ready frontier.
* **Failure** -- the coordinator retries failed plan-managed nodes up to
  ``max_retries`` times before accepting the failure and leaving dependents
  permanently blocked.

The coordinator never owns execution or scheduling.  It delegates
newly-ready work to :class:`ExecutionPlanRunner`.
"""

from __future__ import annotations

from typing import Dict, Mapping, Optional

from ocean.domain.assignment import Assignment
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.domain.enums import AssignmentStatus
from ocean.execution.compiler import ExecutionPlan
from ocean.orchestration.execution_plan_provider import ExecutionPlanProvider
from ocean.orchestration.execution_plan_runner import (
    ExecutionPlanRunResult,
    ExecutionPlanRunner,
)
from ocean.orchestration.orchestrator import Orchestrator
from persistence.repository import Repository


class ExecutionPlanCoordinator:
    """Advance execution-plan frontiers from durable assignment events.

    The coordinator owns neither execution nor scheduling.  It reacts to
    durable assignment lifecycle facts, reconstructs the current plan
    frontier from persisted assignments, and delegates newly-ready work to
    ExecutionPlanRunner.

    On failure the coordinator retries the failed plan node up to
    ``max_retries`` times by creating a fresh assignment and dispatching
    it through the orchestrator.  Retry assignments carry the same plan
    metadata so that subsequent completion/failure events remain traceable
    to the same plan node.

    No mutable completion map or node-to-execution map is maintained here
    except for the transient ``_node_attempts`` counter used to enforce
    the retry budget.
    """

    def __init__(
        self,
        *,
        events: EventBus,
        assignments: Repository[Assignment],
        plan_provider: ExecutionPlanProvider,
        runner: ExecutionPlanRunner,
        orchestrator: Optional[Orchestrator] = None,
        max_retries: int = 3,
    ) -> None:
        if events is None:
            raise ValueError("events is required")
        if assignments is None:
            raise ValueError("assignments is required")
        if plan_provider is None:
            raise ValueError("plan_provider is required")
        if runner is None:
            raise ValueError("runner is required")

        self._events = events
        self._assignments = assignments
        self._plan_provider = plan_provider
        self._runner = runner
        self._orchestrator = orchestrator
        self._max_retries = max(0, max_retries)
        self._node_attempts: Dict[str, int] = {}

        events.subscribe(
            "TaskAssignmentCompleted",
            self._handle_assignment_completed,
        )
        events.subscribe(
            "TaskAssignmentFailed",
            self._handle_assignment_failed,
        )

    @property
    def events(self) -> EventBus:
        return self._events

    @property
    def assignments(self) -> Repository[Assignment]:
        return self._assignments

    @property
    def plan_provider(self) -> ExecutionPlanProvider:
        return self._plan_provider

    @property
    def runner(self) -> ExecutionPlanRunner:
        return self._runner

    @property
    def max_retries(self) -> int:
        return self._max_retries

    def _handle_assignment_completed(self, event: Event) -> None:
        """Advance the plan affected by a completed plan-managed assignment."""

        assignment_id = (
            event.payload.get("assignment_id")
            or event.causation_id
            or event.aggregate_id
        )

        if not assignment_id:
            raise ValueError(
                "TaskAssignmentCompleted event is missing assignment identity"
            )

        assignment_id = str(assignment_id)

        assignment = self._assignments.get(assignment_id)

        if assignment is None:
            raise ValueError(
                f"unknown assignment referenced by completion event: "
                f"{assignment_id!r}"
            )

        if assignment.status is not AssignmentStatus.COMPLETED:
            raise ValueError(
                f"assignment {assignment_id!r} is not completed: "
                f"{assignment.status.value!r}"
            )

        plan_revision_id = assignment.metadata.get("execution_plan_id")
        node_id = assignment.metadata.get("execution_node_id")

        # Ordinary assignments are outside plan execution.
        if plan_revision_id is None and node_id is None:
            return

        if not plan_revision_id:
            raise ValueError(
                f"plan-managed assignment {assignment_id!r} is missing "
                "execution_plan_id metadata"
            )

        if not node_id:
            raise ValueError(
                f"plan-managed assignment {assignment_id!r} is missing "
                "execution_node_id metadata"
            )

        self.advance(str(plan_revision_id))

    def _handle_assignment_failed(self, event: Event) -> None:
        """Retry a failed plan-managed assignment or accept the failure."""

        assignment_id = (
            event.payload.get("assignment_id")
            or event.causation_id
            or event.aggregate_id
        )

        if not assignment_id:
            raise ValueError(
                "TaskAssignmentFailed event is missing assignment identity"
            )

        assignment_id = str(assignment_id)

        assignment = self._assignments.get(assignment_id)

        if assignment is None:
            raise ValueError(
                f"unknown assignment referenced by failure event: "
                f"{assignment_id!r}"
            )

        if assignment.status is not AssignmentStatus.FAILED:
            raise ValueError(
                f"assignment {assignment_id!r} is not failed: "
                f"{assignment.status.value!r}"
            )

        plan_revision_id = assignment.metadata.get("execution_plan_id")
        node_id = assignment.metadata.get("execution_node_id")

        if plan_revision_id is None and node_id is None:
            return

        if not plan_revision_id or not node_id:
            return

        node_id = str(node_id)

        if self._orchestrator is None:
            return

        attempt = self._node_attempts.get(node_id, 0)

        if attempt >= self._max_retries:
            return

        self._retry_failed_node(
            failed_assignment=assignment,
            plan_revision_id=str(plan_revision_id),
            node_id=node_id,
            attempt=attempt,
        )

        self._node_attempts[node_id] = attempt + 1

    def advance(
        self,
        plan_revision_id: str,
    ) -> ExecutionPlanRunResult:
        """Reconstruct durable plan progress and submit its ready frontier."""

        if not plan_revision_id or not plan_revision_id.strip():
            raise ValueError("plan_revision_id must be non-empty")

        plan = self._plan_provider.get(plan_revision_id)

        if plan is None:
            raise ValueError(
                f"plan provider returned no execution plan for "
                f"{plan_revision_id!r}"
            )

        (
            completed_node_ids,
            node_execution_ids,
            submitted_node_ids,
        ) = self._durable_progress(plan_revision_id)

        return self._runner.start_frontier(
            plan,
            completed_node_ids=completed_node_ids,
            node_execution_ids=node_execution_ids,
            submitted_node_ids=submitted_node_ids,
        )

    def _retry_failed_node(
        self,
        *,
        failed_assignment: Assignment,
        plan_revision_id: str,
        node_id: str,
        attempt: int,
    ) -> None:
        """Create a fresh assignment for a failed plan node and dispatch it."""

        plan = self._plan_provider.get(plan_revision_id)
        if plan is None:
            return

        try:
            step = plan.step(node_id)
        except KeyError:
            return

        retry_assignment = Assignment(
            task_id=failed_assignment.task_id,
            agent_id=failed_assignment.agent_id,
            mission_id=failed_assignment.mission_id,
            mode=failed_assignment.mode,
            priority=failed_assignment.priority,
            parent_assignment_id=failed_assignment.id,
            reason=(
                f"plan coordinator retry {attempt} "
                f"of failed node {node_id!r}"
            ),
            metadata={
                **dict(failed_assignment.metadata),
                "plan_retry_attempt": attempt,
                "plan_retry": True,
            },
        )

        self._assignments.save(retry_assignment)

        self._events.publish(
            Event(
                type="PlanNodeRetryScheduled",
                payload={
                    "assignment_id": retry_assignment.id,
                    "failed_assignment_id": failed_assignment.id,
                    "task_id": failed_assignment.task_id,
                    "agent_id": failed_assignment.agent_id,
                    "mission_id": failed_assignment.mission_id,
                    "execution_plan_id": plan_revision_id,
                    "execution_node_id": node_id,
                    "attempt": attempt,
                    "max_retries": self._max_retries,
                },
                aggregate_type="assignment",
                aggregate_id=retry_assignment.id,
                correlation_id=failed_assignment.mission_id,
                causation_id=failed_assignment.id,
                source="execution_plan_coordinator",
            )
        )

        retry_assignment.queue(reason="plan coordinator retry")
        self._assignments.save(retry_assignment)

        dispatch_result = self._orchestrator.dispatch(
            retry_assignment.id,
            step.intent,
            dependency_execution_ids=set(),
        )

        if not dispatch_result.success:
            retry_assignment.cancel(
                reason=dispatch_result.error or "retry dispatch failed"
            )
            self._assignments.save(retry_assignment)

    def _durable_progress(
        self,
        plan_revision_id: str,
    ) -> tuple[set[str], Mapping[str, str], set[str]]:
        """Derive plan progress exclusively from persisted assignments."""

        completed_node_ids: set[str] = set()
        node_execution_ids: dict[str, str] = {}
        submitted_node_ids: set[str] = set()

        for assignment in self._assignments.list():
            if assignment.metadata.get("execution_plan_id") != plan_revision_id:
                continue

            node_id = assignment.metadata.get("execution_node_id")

            if not node_id:
                continue

            node_id = str(node_id)
            submitted_node_ids.add(node_id)

            if assignment.status is AssignmentStatus.COMPLETED:
                completed_node_ids.add(str(node_id))

                if assignment.execution_id is None:
                    raise ValueError(
                        f"completed plan assignment {assignment.id!r} "
                        "has no execution ID"
                    )

                existing = node_execution_ids.get(node_id)

                if existing is not None and existing != assignment.execution_id:
                    raise ValueError(
                        f"plan node {node_id!r} has conflicting completed "
                        "execution IDs: {existing!r} and "
                        f"{assignment.execution_id!r}"
                    )

                node_execution_ids[node_id] = assignment.execution_id

        return (
            completed_node_ids,
            node_execution_ids,
            submitted_node_ids,
        )
