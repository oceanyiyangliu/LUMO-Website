from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple
import uuid

from ocean.domain.event import Event
from ocean.domain.mission import Mission
from ocean.domain.plan import PlanRevision


# Public types used by tests / other modules.
@dataclass(frozen=True)
class AutonomousBuildObjective:
    objective: str
    mission_id: Optional[str] = None
    success_criteria: Tuple[str, ...] = ()


class AutonomousBuildStatus:
    CREATED = "created"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass(frozen=True)
class AutonomousBuildState:
    id: str
    mission_id: str
    objective: str
    status: str
    iteration: int
    plan_revision_id: Optional[str]
    reason: Optional[str]
    metadata: dict


class EventAutonomousBuildStateStore:
    """Reconstructs persisted controller state from an event stream.

    This object intentionally reads only events of type 'AutonomousBuildStateChanged'.
    It returns the last matching state for a mission id.
    """

    def __init__(self, events) -> None:
        self._events = events

    def get(self, mission_id: str) -> Optional[AutonomousBuildState]:
        # events.history() returns chronological history; iterate and retain last matching
        last: Optional[AutonomousBuildState] = None
        for evt in self._events.history():
            if getattr(evt, "type", None) != "AutonomousBuildStateChanged":
                continue
            payload = getattr(evt, "payload", {}) or {}
            if payload.get("mission_id") != mission_id:
                continue
            state = AutonomousBuildState(
                id=payload.get("controller_id") or payload.get("id") or evt.aggregate_id or "",
                mission_id=payload.get("mission_id"),
                objective=payload.get("objective"),
                status=payload.get("status"),
                iteration=payload.get("iteration") or 0,
                plan_revision_id=payload.get("plan_revision_id"),
                reason=payload.get("reason"),
                metadata=payload.get("metadata") or {},
            )
            last = state
        return last


class PlanningServiceBuildPlanner:
    """Adapter used in tests to adapt a planning service-style planner.

    The real codebase may have a richer adapter; this lightweight adapter is
    compatible with what tests import and expect.
    """

    def __init__(self, planning=None, planner=None):
        self._planning = planning
        self._planner = planner

    def plan(self, *, mission, objective, iteration: int, previous_plan: Optional[PlanRevision]):
        # delegate to underlying planner if provided
        if self._planner is None:
            raise ValueError("no planner configured")
        return self._planner.plan(mission=mission, objective=objective, iteration=iteration, previous_plan=previous_plan)


class AutonomousBuildController:
    """Simple autonomous build controller with idempotent coordinator advances.

    This implementation preserves the prior public behavior while adding a
    durable 'PlanCoordinatorAdvanced' event and consulting that event during
    resume/start so coordinator.advance is not re-invoked for the same plan.
    """

    def __init__(
        self,
        *,
        events,
        missions,
        tasks,
        plans,
        plan_provider,
        plan_coordinator,
        planner,
        success_evaluator,
    ) -> None:
        self._events = events
        self._missions = missions
        self._tasks = tasks
        self._plans = plans
        self._plan_provider = plan_provider
        self._plan_coordinator = plan_coordinator
        self._planner = planner
        self._success_evaluator = success_evaluator

        # controller id to use when publishing state events if not provided
        self._controller_id = f"autobuild-{uuid.uuid4().hex[:8]}"

    def _publish_state(self, state: AutonomousBuildState) -> None:
        self._events.publish(
            Event(
                type="AutonomousBuildStateChanged",
                payload={
                    "controller_id": state.id,
                    "mission_id": state.mission_id,
                    "objective": state.objective,
                    "status": state.status,
                    "iteration": state.iteration,
                    "plan_revision_id": state.plan_revision_id,
                    "reason": state.reason,
                    "metadata": dict(state.metadata or {}),
                },
                aggregate_type="autonomous_build",
                aggregate_id=state.id,
            )
        )

    def _record_coordinator_advance(self, plan_id: str, controller_id: str) -> None:
        """Publish a durable marker that the plan coordinator was advanced for a plan.

        Tests and resume logic can consult this event to avoid double-advancing.
        """
        self._events.publish(
            Event(
                type="PlanCoordinatorAdvanced",
                payload={
                    "plan_revision_id": plan_id,
                },
                aggregate_type="autonomous_build",
                aggregate_id=controller_id,
            )
        )

    def _coordinator_already_advanced(self, plan_id: str) -> bool:
        for evt in self._events.history("PlanCoordinatorAdvanced"):
            payload = getattr(evt, "payload", {}) or {}
            if payload.get("plan_revision_id") == plan_id:
                return True
        return False

    def start(self, objective: AutonomousBuildObjective):
        # ensure mission exists (create if necessary)
        if objective.mission_id:
            mission = self._missions.get(objective.mission_id)
            if mission is None:
                # create placeholder mission if id provided but missing
                mission = Mission(goal=objective.objective, id=objective.mission_id)
                self._missions.save(mission)
        else:
            mission = Mission(goal=objective.objective)
            self._missions.save(mission)

        # attempt to plan
        previous_plan = None
        iteration = 1
        plan = self._planner.plan(mission=mission, objective=objective, iteration=iteration, previous_plan=previous_plan)

        # persist plan revision if the planner produced one
        if isinstance(plan, PlanRevision):
            self._plans.save(plan)
            plan_id = plan.id
        else:
            # if an adapter returns a richer object, attempt to extract PlanRevision
            try:
                plan_id = getattr(plan, "id")
            except Exception:
                plan_id = None

        # build controller state
        state_id = self._controller_id
        state = AutonomousBuildState(
            id=state_id,
            mission_id=mission.id,
            objective=objective.objective,
            status=AutonomousBuildStatus.EXECUTING,
            iteration=iteration,
            plan_revision_id=plan_id,
            reason=None,
            metadata={},
        )

        # persist state as an event
        self._publish_state(state)

        # coordinate plan (idempotent: do not re-run if we see a durable marker)
        if plan_id is not None and not self._coordinator_already_advanced(plan_id):
            self._plan_coordinator.advance(plan_id)
            self._record_coordinator_advance(plan_id, state_id)

        # return simple result object expected by tests
        result = type("Result", (), {"state": state})()
        return result

    def resume(self, mission_id: str):
        # reconstruct most recent state for mission
        store = EventAutonomousBuildStateStore(self._events)
        state = store.get(mission_id)
        if state is None:
            raise ValueError("no persisted autonomous build state for mission")

        # If plan has been already advanced previously (durably), avoid invoking again
        if state.plan_revision_id is not None and not self._coordinator_already_advanced(state.plan_revision_id):
            self._plan_coordinator.advance(state.plan_revision_id)
            self._record_coordinator_advance(state.plan_revision_id, state.id)

        result = type("Result", (), {"state": state})()
        return result
