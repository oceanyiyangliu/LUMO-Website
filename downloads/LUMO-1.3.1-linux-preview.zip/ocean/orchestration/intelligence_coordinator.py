"""Mission-wide intelligence scheduling without host control."""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Iterable

class ExecutionMode(str, Enum):
    CURSOR = "cursor"
    CURSOR_SWARM = "cursor_swarm"
    WORLD = "world"
    WORLD_SWARM = "world_swarm"

@dataclass(frozen=True)
class WorkItem:
    id: str
    objective: str
    dependencies: tuple[str, ...] = ()
    risk: str = "low"
    estimated_actions: int = 1
    requires_isolation: bool = False
    can_parallelize: bool = True
    priority: int = 0

@dataclass(frozen=True)
class ExecutionChoice:
    mode: ExecutionMode
    width: int
    reason: str
    host_control_allowed: bool = False

@dataclass(frozen=True)
class CoordinationSnapshot:
    mission_id: str
    active_workers: int
    ready_items: tuple[str, ...]
    blocked_items: tuple[str, ...]
    user_active: bool
    interruption_free: bool

class IntelligenceCoordinator:
    """Deterministic scheduler around model reasoning.
    
    It decides what can run and where. It never owns a mouse, keyboard,
    screen, or host computer executor.
    """
    def __init__(self, *, max_workers: int = 16) -> None:
        if max_workers < 1:
            raise ValueError("max_workers must be positive")
        self.max_workers = max_workers

    def ready(self, items: Iterable[WorkItem], completed: set[str]) -> tuple[WorkItem, ...]:
        return tuple(sorted(
            (i for i in items if all(d in completed for d in i.dependencies)),
            key=lambda i: (-i.priority, i.id),
        ))

    def choose_execution(self, items: tuple[WorkItem, ...], *, user_active: bool = True) -> ExecutionChoice:
        if not items:
            return ExecutionChoice(ExecutionMode.CURSOR, 0, "no executable work")

        if any(i.requires_isolation or i.estimated_actions >= 40 for i in items):
            width = min(self.max_workers, max(1, len(items)))
            mode = ExecutionMode.WORLD_SWARM if width > 1 else ExecutionMode.WORLD
            return ExecutionChoice(mode, width, "work is large or explicitly isolated")
        if len(items) > 1 and all(i.can_parallelize for i in items):
            width = min(self.max_workers, len(items))
            mode = ExecutionMode.CURSOR_SWARM if width > 1 else ExecutionMode.CURSOR
            return ExecutionChoice(mode, width, "independent small work can run concurrently")
        return ExecutionChoice(ExecutionMode.CURSOR, 1, "small bounded work stays in the current app context")

    def schedule(self, items: Iterable[WorkItem], completed: set[str], *,
                 user_active: bool = True, active_workers: int = 0):
        ready = self.ready(items, completed)
        capacity = max(0, self.max_workers - active_workers)
        if capacity == 0:
            return (), ExecutionChoice(ExecutionMode.CURSOR, 0, "worker capacity exhausted")
        choice = self.choose_execution(ready[:capacity], user_active=user_active)
        return ready[:max(1, min(choice.width, capacity))], choice

    def escalate_blocked(self, item: WorkItem, reason: str) -> ExecutionChoice:
        """Escalate a blocked Cursor task without ever granting host control."""
        if item.requires_isolation or item.estimated_actions >= 40:
            return ExecutionChoice(
                ExecutionMode.WORLD, 1,
                f"cursor blocked: {reason}; isolated execution required",
                host_control_allowed=False,
            )
        return ExecutionChoice(
            ExecutionMode.WORLD, 1,
            f"cursor blocked: {reason}; cursor capability exhausted",
            host_control_allowed=False,
        )

    def coordinate_swarm(self, items: Iterable[WorkItem], completed: set[str], *,
                         user_active: bool = True, active_workers: int = 0):
        """Return independent bounded work for parallel virtual cursors."""
        ready = self.ready(items, completed)
        bounded = tuple(i for i in ready if not i.requires_isolation and i.estimated_actions < 40)
        capacity = max(0, self.max_workers - active_workers)
        selected = bounded[:capacity]
        if len(selected) <= 1:
            return selected, self.choose_execution(selected, user_active=user_active)
        return selected, ExecutionChoice(
            ExecutionMode.CURSOR_SWARM,
            len(selected),
            "independent bounded work assigned to virtual Cursor Swarm",
            host_control_allowed=False,
        )

    def snapshot(self, mission_id: str, items: Iterable[WorkItem], completed: set[str], *,
                 active_workers: int = 0, user_active: bool = True) -> CoordinationSnapshot:
        rows = tuple(items)
        ready = self.ready(rows, completed)
        blocked = tuple(i.id for i in rows if i.id not in completed and i not in ready)
        return CoordinationSnapshot(
            mission_id, active_workers, tuple(i.id for i in ready), blocked,
            user_active, True
        )

__all__ = [
    "ExecutionChoice", "ExecutionMode", "IntelligenceCoordinator",
    "WorkItem", "CoordinationSnapshot",
]
