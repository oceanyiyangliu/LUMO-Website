"""Reconstruct executable plans from durable planning state."""

from __future__ import annotations

from typing import Protocol

from ocean.domain.plan import PlanRevision
from ocean.domain.task import Task
from ocean.domain.work_graph import WorkGraph
from ocean.execution.compiler import (
    ExecutionIntentResolver,
    ExecutionPlan,
    PlanExecutionCompiler,
)
from persistence.repository import Repository


class ExecutionPlanProvider(Protocol):
    """Resolve a durable plan revision into an executable plan."""

    def get(self, plan_revision_id: str) -> ExecutionPlan:
        ...


class RepositoryExecutionPlanProvider:
    """Reconstruct an ExecutionPlan from persisted planning state.

    This is deliberately a reconstruction boundary, not a second compiler.

    The provider:
    - loads the PlanRevision;
    - loads its WorkGraph;
    - loads the mission's Tasks;
    - validates cross-entity identity relationships;
    - delegates executable transformation to PlanExecutionCompiler.

    It does not mutate planning state, create assignments, schedule work,
    execute capabilities, or maintain runtime progress.
    """

    def __init__(
        self,
        *,
        plan_revisions: Repository[PlanRevision],
        work_graphs: Repository[WorkGraph],
        tasks: Repository[Task],
        resolver: ExecutionIntentResolver,
        compiler: PlanExecutionCompiler | None = None,
    ) -> None:
        if plan_revisions is None:
            raise ValueError("plan_revisions is required")

        if work_graphs is None:
            raise ValueError("work_graphs is required")

        if tasks is None:
            raise ValueError("tasks is required")

        if resolver is None:
            raise ValueError("resolver is required")

        self._plan_revisions = plan_revisions
        self._work_graphs = work_graphs
        self._tasks = tasks
        self._resolver = resolver
        self._compiler = compiler or PlanExecutionCompiler()

    @property
    def plan_revisions(self) -> Repository[PlanRevision]:
        return self._plan_revisions

    @property
    def work_graphs(self) -> Repository[WorkGraph]:
        return self._work_graphs

    @property
    def tasks(self) -> Repository[Task]:
        return self._tasks

    @property
    def resolver(self) -> ExecutionIntentResolver:
        return self._resolver

    @property
    def compiler(self) -> PlanExecutionCompiler:
        return self._compiler

    def get(self, plan_revision_id: str) -> ExecutionPlan:
        """Reconstruct and compile a durable plan revision."""

        if not plan_revision_id or not plan_revision_id.strip():
            raise ValueError("plan_revision_id must be non-empty")

        plan = self._plan_revisions.get(plan_revision_id)

        if plan is None:
            raise ValueError(
                f"unknown plan revision: {plan_revision_id!r}"
            )

        graph = self._work_graphs.get(plan.graph_id)

        if graph is None:
            raise ValueError(
                f"plan revision {plan.id!r} references unknown work graph "
                f"{plan.graph_id!r}"
            )

        if graph.mission_id != plan.mission_id:
            raise ValueError(
                f"work graph {graph.id!r} belongs to mission "
                f"{graph.mission_id!r}, not {plan.mission_id!r}"
            )

        if graph.plan_revision_id != plan.id:
            raise ValueError(
                f"work graph {graph.id!r} references plan revision "
                f"{graph.plan_revision_id!r}, not {plan.id!r}"
            )

        mission_tasks = tuple(
            task
            for task in self._tasks.list()
            if task.mission_id == plan.mission_id
        )

        return self._compiler.compile(
            graph,
            mission_tasks,
            self._resolver,
        )
