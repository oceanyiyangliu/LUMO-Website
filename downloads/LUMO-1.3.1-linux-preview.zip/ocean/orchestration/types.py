"""Contracts used by the multi-agent orchestration control plane."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from ocean.domain.enums import FailureCategory, OrchestrationMode


@dataclass(frozen=True)
class AssignmentRequest:
    """Transient intent to create a task-to-agent assignment."""

    task_id: str
    agent_id: str
    principal_id: Optional[str] = None
    mission_id: Optional[str] = None
    execution_id: Optional[str] = None
    mode: OrchestrationMode = OrchestrationMode.STANDARD
    priority: int = 0
    parent_assignment_id: Optional[str] = None
    reason: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.task_id:
            raise ValueError("assignment request task_id must not be empty")

        if not self.agent_id:
            raise ValueError("assignment request agent_id must not be empty")

        if self.mission_id is not None and not self.mission_id:
            raise ValueError(
                "assignment request mission_id must not be empty"
            )

        if self.priority < 0:
            raise ValueError(
                "assignment request priority must be non-negative"
            )

        if self.parent_assignment_id == "":
            raise ValueError(
                "assignment request parent_assignment_id must not be empty"
            )


@dataclass(frozen=True)
class OrchestrationResult:
    """Outcome of an orchestration control-plane operation."""

    success: bool
    assignment_id: Optional[str] = None
    execution_id: Optional[str] = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ReconciliationResult:
    """Observed state after reconciling an orchestration operation."""

    assignment_id: str
    status: str
    task_status: Optional[str] = None
    execution_id: Optional[str] = None
    success: Optional[bool] = None
    error: Optional[str] = None
    failure_category: Optional[FailureCategory] = None
    retryable: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class RecoveryDecision:
    """Decision produced by orchestration recovery logic."""

    action: str
    assignment_id: Optional[str] = None
    agent_id: Optional[str] = None
    reason: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ExecutionIntent:
    """Immutable orchestration-level intent for one capability operation."""

    capability: str
    operation: str
    arguments: Dict[str, Any] = field(default_factory=dict)
    resource_limits: Any = None

    def __post_init__(self) -> None:
        if not self.capability:
            raise ValueError("execution intent requires a capability")
        if not self.operation:
            raise ValueError("execution intent requires an operation")

        object.__setattr__(self, "arguments", dict(self.arguments))

        if self.resource_limits is None:
            from runtime.resources import ExecutionResourceLimits

            object.__setattr__(
                self,
                "resource_limits",
                ExecutionResourceLimits(),
            )
