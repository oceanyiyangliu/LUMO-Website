"""Typed autonomous-build execution above Ocean's existing capabilities.

The autonomous builder is deliberately a router, not a second execution
stack.  Strategic planning produces typed objectives; this boundary selects
the strongest existing bounded service for each type and converts its result
into durable, evidence-bearing mission facts.
"""

from __future__ import annotations

from enum import Enum
import os
from pathlib import Path
import re
from typing import Any, Mapping, Sequence

from ocean.core.ids import new_id
from ocean.domain.event import Event
from ocean.domain.mission import Mission
from ocean.orchestration.mission_engine import (
    MissionObjective,
    MissionObjectiveResult,
)
from ocean.orchestration.strategic_model_provider import StrategicMissionModel
from ocean.self_improvement.research import ResearchRequest
from ocean.domain.world import WorldRequirements
from ocean.worlds import BrowserAgent, BrowserWorldProvider, WorldManager
from runtime.types import ExecutionRequest


class AutonomousWorkType(str, Enum):
    RESEARCH = "research"
    DESIGN = "design"
    IMPLEMENTATION = "implementation"
    TESTING = "testing"
    INTEGRATION = "integration"
    VERIFICATION = "verification"
    BROWSER = "browser"
    COMPUTER = "computer"
    ARTIFACT = "artifact"

    @classmethod
    def parse(cls, value: str) -> "AutonomousWorkType":
        try:
            return cls(str(value).strip().lower())
        except ValueError as exc:
            raise ValueError(
                f"unsupported autonomous work type: {value!r}"
            ) from exc


class RuntimeAutonomousBuildExecutor:
    """Route autonomous-build objectives to existing bounded services.

    Implementation/integration are the only paths allowed to invoke the
    self-improvement promotion pipeline.  Research, design, testing and
    verification never enter that benchmark/promotion path.
    """

    def __init__(
        self,
        *,
        runtime,
        strategic_model: StrategicMissionModel,
        repository_context: str,
        world_manager: WorldManager | None = None,
        routing_repository_context: str | None = None,
        events=None,
        account_id: str | None = None,
    ) -> None:
        if runtime is None:
            raise ValueError("runtime is required")
        if strategic_model is None:
            raise ValueError("strategic_model is required")
        if not repository_context.strip():
            raise ValueError("repository_context is required")
        self._runtime = runtime
        self._strategic_model = strategic_model
        self._repository_context = repository_context
        self._routing_repository_context = routing_repository_context or repository_context
        self._worlds = world_manager or WorldManager([BrowserWorldProvider(headless=True)])
        self._events = events
        self._account_id = str(account_id) if account_id else None

    def execute(
        self,
        mission_id: str,
        objective: MissionObjective,
    ) -> MissionObjectiveResult:
        work_type = AutonomousWorkType.parse(
            getattr(objective, "work_type", "implementation")
        )

        world = self._ensure_world(mission_id, objective)
        if world is not None:
            objective = MissionObjective(
                objective_id=objective.objective_id,
                objective=objective.objective,
                rationale=objective.rationale,
                dependencies=objective.dependencies,
                priority=objective.priority,
                work_type=objective.work_type,
                acceptance_criteria=objective.acceptance_criteria,
                metadata={**dict(objective.metadata), "world_id": world.id},
            )

        browser_execution = self._browser_operations(mission_id, objective, world)
        if browser_execution is not None and not browser_execution[0]:
            return self._failure(objective, work_type, browser_execution[1])

        handlers = {
            AutonomousWorkType.IMPLEMENTATION: lambda: self._implementation(mission_id, objective, work_type),
            AutonomousWorkType.INTEGRATION: lambda: self._integration(mission_id, objective),
            AutonomousWorkType.RESEARCH: lambda: self._research(mission_id, objective),
            AutonomousWorkType.DESIGN: lambda: self._design(mission_id, objective),
            AutonomousWorkType.TESTING: lambda: self._testing(mission_id, objective),
            AutonomousWorkType.VERIFICATION: lambda: self._verification(mission_id, objective),
            AutonomousWorkType.BROWSER: lambda: self._browser(mission_id, objective, world),
            AutonomousWorkType.COMPUTER: lambda: self._computer(mission_id, objective, world),
            AutonomousWorkType.ARTIFACT: lambda: self._artifact(mission_id, objective),
        }
        handler = handlers.get(work_type)
        if handler is None:
            return self._failure(
                objective,
                work_type,
                f"no executor registered for work type {work_type.value!r}",
            )
        try:
            return handler()
        except Exception as exc:
            return self._failure(objective, work_type, str(exc))

    def _ensure_world(self, mission_id: str, objective: MissionObjective):
        metadata = dict(getattr(objective, "metadata", {}) or {})
        requested = metadata.get("world") or metadata.get("world_requirements")
        work_type = str(getattr(objective, "work_type", "")).strip().lower()
        is_computer = work_type == AutonomousWorkType.COMPUTER.value
        is_browser = work_type == AutonomousWorkType.BROWSER.value
        if not requested and not is_computer and not is_browser:
            return None
        if isinstance(requested, str):
            requested = {"kind": requested}
        requested = dict(requested or {}) if isinstance(requested, dict) else {}
        kind = str(requested.get("kind", "desktop" if is_computer else "browser"))
        default_capabilities = ("browser",) if kind == "browser" else ("desktop", "computer")
        requirements = WorldRequirements(
            capabilities=tuple(requested.get("capabilities", default_capabilities)),
            resources=dict(requested.get("resources", {})),
            persistent=bool(requested.get("persistent", True)),
            network=bool(requested.get("network", True)),
        )
        world = self._worlds.create(
            mission_id=mission_id, account_id=self._account_id, kind=kind, requirements=requirements,
            metadata={
                "objective_id": objective.objective_id,
                "purpose": "mission_execution",
            },
        )
        return world

    def _integration(self, mission_id, objective):
        """Execute an integration objective through the normal agentic planner.

        Integration is intentionally a routing problem, not a synonym for
        source-code mutation. The strategic model chooses the concrete
        capabilities required by the actual objective; this boundary merely
        executes those typed capabilities under the existing governance rules.
        """

        allowed = {
            AutonomousWorkType.RESEARCH.value,
            AutonomousWorkType.IMPLEMENTATION.value,
            AutonomousWorkType.TESTING.value,
            AutonomousWorkType.VERIFICATION.value,
            AutonomousWorkType.BROWSER.value,
            AutonomousWorkType.COMPUTER.value,
            AutonomousWorkType.ARTIFACT.value,
        }
        objective_metadata = dict(getattr(objective, "metadata", {}) or {})
        missing_outcomes = tuple(
            str(item).strip().lower()
            for item in objective_metadata.get("mission_missing_work_types", ())
            if str(item).strip()
        )
        required_outcomes = tuple(
            str(item).strip().lower()
            for item in objective_metadata.get("mission_required_work_types", ())
            if str(item).strip()
        )
        covered_outcomes = tuple(
            str(item).strip().lower()
            for item in objective_metadata.get("mission_covered_work_types", ())
            if str(item).strip()
        )
        contract_requirement = ""
        if missing_outcomes:
            contract_requirement = (
                "\n\nMISSION CONTROL REQUIREMENT (STRUCTURED, AUTHORITATIVE): "
                f"Required outcome classes: {required_outcomes}. "
                f"Missing outcome classes: {missing_outcomes}. "
                f"Already covered outcome classes: {covered_outcomes}. "
                "This routed objective MUST contribute verified evidence to at least one "
                "currently missing outcome class. Select the concrete capability from "
                "observed state; do not satisfy the requirement by merely labeling an "
                "objective with the missing class. If multiple missing classes can be "
                "satisfied by one coherent route, that is allowed. "
            )
        routing_goal = (
            "Determine the concrete execution steps required to complete this "
            "integration objective. Return only directly relevant objectives. "
            "Use research only for repository/local knowledge and factual "
            "discovery; it does not execute tests, diagnostics, state-changing "
            "actions, or inspect the user's accounts. When the objective asks to "
            "test, diagnose, benchmark, or produce behavioral evidence, choose "
            "testing or verification instead of research. When external service, "
            "account, domain, provider, or authorization state is unknown, use "
            "browser or computer to observe the external world. "
            "Choose implementation only when LUMO actually needs to change local "
            "code or local configuration; choose testing or verification when "
            "evidence must be produced; choose browser for an isolated web session; "
            "and choose computer for an isolated desktop application. Treat the "
            "external world as part of the task: inspect it, use available tools, "
            "and reason from observed results instead of assuming that every "
            "integration is a source-code change. Do not return integration or "
            "design objectives here, because this is already the integration "
            "routing boundary. Never invent credentials, accounts, permissions, "
            "payments, or external authorization. If a human-only prerequisite "
            "is encountered, pause and surface the exact prerequisite so the human "
            "can provide it; after the human acts, continue from the observed state. "
            "If an execution attempt fails, use its result as evidence and choose a "
            "different or more appropriate capability rather than repeating the "
            "same failed route. The original acceptance criteria are part of the mission intent; "
            "satisfy them through the selected capability rather than merely echoing them. "
            f"Original acceptance criteria: {tuple(dict(getattr(objective, 'metadata', {}) or {}).get('gateway_original_acceptance_criteria', ())) }. "
            "Original objective:\n"
            + contract_requirement
            + "Original objective:\n"
            + objective.objective
        )
        # Integration is an agentic routing boundary, not a task-specific script.
        # Give the strategic model the observed result of each bounded attempt so
        # it can recover from a bad route instead of immediately declaring the
        # whole mission failed.
        routing_feedback: tuple[MissionObjectiveResult, ...] = ()
        all_results: list[MissionObjectiveResult] = []
        attempted_routes: set[tuple[str, str]] = set()
        mutation_policy = str(
            dict(getattr(objective, "metadata", {}) or {}).get(
                "mission_mutation_policy", "allow"
            )
        ).strip().lower()
        read_only = mutation_policy == "read_only"

        for round_index in range(3):
            # First observe the real world before mutating local source/config.
            # This is a generic integration invariant: implementation becomes
            # eligible only after an observed route or failure establishes that
            # a local change is actually required.
            if missing_outcomes:
                # The mission contract is authoritative about the outcome still
                # missing. Prefer a capability whose work type directly proves
                # that outcome instead of asking a small model to rediscover
                # the contract semantics.
                round_allowed = allowed & set(missing_outcomes)
            elif read_only:
                round_allowed = allowed - {
                    AutonomousWorkType.IMPLEMENTATION.value,
                    AutonomousWorkType.BROWSER.value,
                    AutonomousWorkType.COMPUTER.value,
                }
            else:
                round_allowed = (
                    allowed
                    if round_index > 0
                    else allowed - {AutonomousWorkType.IMPLEMENTATION.value}
                )
            round_routing_goal = (
                routing_goal
                + "\n\nROUTING BOUNDARY FOR THIS ROUND (AUTHORITATIVE): "
                + f"The only legal concrete work types for this round are {tuple(sorted(round_allowed))}. "
                + "Return objectives only from that allowed set. Do not return integration or design "
                + "at this boundary. "
                + ("This mission is read-only: implementation, browser, and computer are forbidden in this round; "
                   "use research, testing, or verification as appropriate. " if read_only else "")
                + "If no legal route is possible, return no route rather than inventing an out-of-set work type."
            )
            proposed = tuple(
                self._strategic_model.decompose(
                    mission_id=mission_id,
                    goal=round_routing_goal,
                    repository_context=self._routing_repository_context,
                    completed_objectives=(),
                    previous_results=routing_feedback,
                )
            )
            routes = tuple(
                item for item in proposed
                if item.work_type in round_allowed
                and (item.work_type, item.objective.strip().lower()) not in attempted_routes
            )
            if not routes and len(missing_outcomes) == 1 and round_allowed:
                # Generic contract fallback: when exactly one outcome remains
                # and the model cannot emit a legal route, that outcome names
                # the bounded capability directly. Multi-gap missions still
                # require the model to choose the coherent next step.
                fallback_type = sorted(round_allowed)[0]
                routes = (
                    MissionObjective(
                        objective_id=f"{objective.objective_id}.contract.{fallback_type}",
                        objective=objective.objective,
                        rationale="Execute the mission contract's missing outcome directly.",
                        dependencies=(),
                        priority=objective.priority,
                        work_type=fallback_type,
                        acceptance_criteria=objective.acceptance_criteria,
                        metadata={"contract_fallback_route": True},
                    ),
                )
            if not routes:
                if missing_outcomes:
                    return MissionObjectiveResult(
                        objective_id=objective.objective_id,
                        objective=objective.objective,
                        status="rejected",
                        error="integration planner produced no legal route for the currently missing mission outcome",
                        metadata=self._metadata(
                            objective,
                            AutonomousWorkType.INTEGRATION,
                            verified=False,
                            evidence=("mission_contract_gap=True",),
                            verification_method="mission_contract_coverage_guard",
                            extra={
                                "mission_contract_gap": True,
                                "missing_work_types": list(missing_outcomes),
                                "routed_work_types": sorted({
                                    str(item.work_type).strip().lower() for item in proposed
                                }),
                            },
                        ),
                    )
                if round_index == 0 and not all_results:
                    routing_feedback = (
                        MissionObjectiveResult(
                            objective_id="integration_route_guard",
                            objective=objective.objective,
                            status="rejected",
                            error="initial integration routing may not mutate local source/config before observing the external state",
                            metadata={"routing_guard": True},
                        ),
                    )
                    continue
                if all_results:
                    last = all_results[-1]
                    return MissionObjectiveResult(
                        objective_id=objective.objective_id,
                        objective=objective.objective,
                        status=last.status,
                        run_id=last.run_id,
                        candidate_id=last.candidate_id,
                        promoted_plan_revision_id=last.promoted_plan_revision_id,
                        error=last.error or "integration planner produced no new executable route",
                        metadata=self._metadata(
                            objective,
                            AutonomousWorkType.INTEGRATION,
                            verified=False,
                            evidence=(f"routing_rounds={round_index + 1}",),
                            verification_method="agentic_integration_routing",
                            extra={"routed_results": [dict(r.metadata) for r in all_results]},
                        ),
                    )
                return self._failure(
                    objective,
                    AutonomousWorkType.INTEGRATION,
                    "integration planner produced no executable capability route",
                )

            round_results: list[MissionObjectiveResult] = []
            for index, item in enumerate(routes[:6]):
                route_key = (item.work_type, item.objective.strip().lower())
                attempted_routes.add(route_key)
                routed = MissionObjective(
                    objective_id=f"{objective.objective_id}.step{len(all_results) + index + 1}",
                    objective=item.objective,
                    rationale=item.rationale,
                    dependencies=(),
                    priority=item.priority,
                    work_type=item.work_type,
                    acceptance_criteria=item.acceptance_criteria,
                    metadata={
                        **dict(item.metadata),
                        "parent_integration_objective": objective.objective_id,
                        "routing_round": round_index + 1,
                    },
                )
                result = self.execute(mission_id, routed)
                round_results.append(result)
                all_results.append(result)
                if result.status not in {"completed", "promoted", "success"}:
                    routing_feedback = (*routing_feedback, result)
                    break

            if round_results and all(
                result.status in {"completed", "promoted", "success"}
                for result in round_results
            ):
                routed_work_types = sorted({
                    str(r.metadata.get("work_type", "")).strip().lower()
                    for r in all_results
                    if r.metadata.get("work_type")
                })
                if missing_outcomes and not (set(routed_work_types) & set(missing_outcomes)):
                    return MissionObjectiveResult(
                        objective_id=objective.objective_id,
                        objective=objective.objective,
                        status="rejected",
                        error=(
                            "integration routing completed executable work but produced no "
                            "verified evidence for any currently missing mission outcome: "
                            + ", ".join(missing_outcomes)
                        ),
                        metadata=self._metadata(
                            objective,
                            AutonomousWorkType.INTEGRATION,
                            verified=False,
                            evidence=[
                                "routed_work_types=" + ",".join(routed_work_types),
                                "missing_work_types=" + ",".join(missing_outcomes),
                            ],
                            verification_method="mission_contract_coverage_guard",
                            extra={
                                "routed_work_types": routed_work_types,
                                "routed_results": [
                                    {"objective_id": r.objective_id, "status": r.status, "metadata": dict(r.metadata)}
                                    for r in all_results
                                ],
                                "mission_contract_gap": True,
                            },
                        ),
                    )
                return MissionObjectiveResult(
                    objective_id=objective.objective_id,
                    objective=objective.objective,
                    status="completed",
                    metadata=self._metadata(
                        objective,
                        AutonomousWorkType.INTEGRATION,
                        verified=True,
                        evidence=[
                            "routed_objective_completed=True",
                            "verified_evidence=True",
                            f"routed_steps={len(all_results)}",
                            f"routing_rounds={round_index + 1}",
                            *(f"step={r.objective_id}:status={r.status}" for r in all_results),
                        ],
                        verification_method="agentic_integration_routing",
                        extra={
                            "acceptance_criteria": {
                                criterion: True
                                for criterion in objective.acceptance_criteria
                                if criterion == "Routed objective completed with verified evidence."
                            },
                            "routed_work_types": routed_work_types,
                            "routed_results": [
                                {"objective_id": r.objective_id, "status": r.status, "metadata": dict(r.metadata)}
                                for r in all_results
                            ],
                        },
                    ),
                )

        last = all_results[-1] if all_results else None
        return MissionObjectiveResult(
            objective_id=objective.objective_id,
            objective=objective.objective,
            status=last.status if last else "failed",
            run_id=last.run_id if last else None,
            candidate_id=last.candidate_id if last else None,
            promoted_plan_revision_id=last.promoted_plan_revision_id if last else None,
            error=(last.error if last else "integration routing exhausted bounded recovery attempts"),
            metadata=self._metadata(
                objective,
                AutonomousWorkType.INTEGRATION,
                verified=False,
                evidence=(f"routing_rounds={len(all_results)}",),
                verification_method="agentic_integration_routing",
                extra={
                    "routed_results": [
                        {"objective_id": r.objective_id, "status": r.status, "error": r.error, "metadata": dict(r.metadata)}
                        for r in all_results
                    ],
                },
            ),
        )

    def _implementation(self, mission_id, objective, work_type):
        try:
            from ocean.self_improvement.objective import EvidenceKind

            result = self._runtime.improve(
                objective.objective,
                mission_id=mission_id,
                objective_id=objective.objective_id,
                work_type=work_type.value,
                acceptance_criteria=getattr(objective, "acceptance_criteria", ()) or (
                    "candidate tests pass",
                ),
                # Code implementation is accepted on executable verification,
                # not on an arbitrary benchmark metric. Requiring BENCHMARK here
                # would make legitimate architectural changes fail with
                # "candidate does not meet minimum improvement requirement"
                # simply because they have no numeric performance metric.
                evidence_policy=(EvidenceKind.TESTS,),
                hypothesis=(
                    getattr(objective, "rationale", "")
                    or f"Implement objective: {objective.objective}"
                ),
                rationale=(
                    getattr(objective, "rationale", "")
                    or "Autonomous build implementation"
                ),
            )
        except TypeError as exc:
            # Preserve compatibility with bounded runtime adapters that still
            # expose the original improve(objective, mission_id=...) contract.
            if "unexpected keyword argument" not in str(exc):
                raise
            result = self._runtime.improve(
                objective.objective,
                mission_id=mission_id,
            )

        decision = getattr(result, "decision", None)
        decision_passed = (
            bool(decision.passed)
            if decision is not None
            else result.status == "promoted"
        )

        verified = (
            result.status == "promoted"
            and bool(result.candidate_tests_passed)
            and decision_passed
        )

        evidence = [
            f"work_type={work_type.value}",
            f"run_id={result.run_id}",
            f"candidate_id={result.candidate_id}",
            f"candidate_tests_passed={result.candidate_tests_passed}",
        ]
        if result.promoted_plan_revision_id:
            evidence.append(
                f"promoted_plan_revision_id={result.promoted_plan_revision_id}"
            )
        if decision is not None:
            evidence.append(
                f"improved_metrics={list(decision.improved_metrics)!r}"
            )

        return MissionObjectiveResult(
            objective_id=objective.objective_id,
            objective=objective.objective,
            status=result.status,
            run_id=result.run_id,
            candidate_id=result.candidate_id,
            promoted_plan_revision_id=result.promoted_plan_revision_id,
            error=None if verified else result.error,
            metadata=self._metadata(
                objective,
                work_type,
                verified=verified,
                evidence=evidence,
                verification_method="autonomous_improvement_pipeline",
                extra={
                    "improvement_metadata": dict(getattr(result, "metadata", {}) or {}),
                    "decision_reasons": list(getattr(decision, "reasons", ()) or ()),
                    "failure_diagnostics": (
                        dict(getattr(result, "metadata", {}).get("test_result", {}))
                        if isinstance(getattr(result, "metadata", {}), dict) else {}
                    ),
                },
            ),
        )

    def _browser(self, mission_id, objective, world):
        if world is None or world.kind != "browser":
            return self._failure(objective, AutonomousWorkType.BROWSER, "browser objective has no browser execution world")
        explicit = self._browser_operations(mission_id, objective, world)
        if explicit is not None:
            if not explicit[0]:
                return self._failure(objective, AutonomousWorkType.BROWSER, explicit[1])
            return MissionObjectiveResult(
                objective_id=objective.objective_id, objective=objective.objective,
                status="completed", metadata=self._metadata(
                    objective, AutonomousWorkType.BROWSER, verified=True,
                    evidence=["explicit_browser_operations_completed", "isolated_browser_world=True"],
                    verification_method="browser_capability_execution",
                ),
            )
        if not callable(getattr(self._strategic_model, "plan_browser_actions", None)):
            return self._failure(objective, AutonomousWorkType.BROWSER, "browser strategic planner is unavailable")
        outcome = BrowserAgent(world_manager=self._worlds, planner=self._strategic_model).run(
            mission_id=mission_id, objective_id=objective.objective_id,
            goal=objective.objective, world=world,
        )
        if not outcome.get("success"):
            return self._failure(objective, AutonomousWorkType.BROWSER, str(outcome.get("error", "browser agent failed")))
        evidence = [
            f"browser_cycles={outcome.get('cycles', 0)}",
            f"browser_url={outcome.get('url', '')}",
            f"browser_title={outcome.get('title', '')}",
            "isolated_browser_world=True",
        ]
        return MissionObjectiveResult(
            objective_id=objective.objective_id, objective=objective.objective,
            status="completed", metadata=self._metadata(
                objective, AutonomousWorkType.BROWSER, verified=True,
                evidence=evidence, verification_method="browser_agent_observed_state",
            ),
        )

    def _browser_operations(self, mission_id, objective, world):
        """Run declarative browser actions inside the objective's isolated world.

        The planner/model may propose a bounded list of capability operations;
        the world owns the actual browser executor and therefore the mission
        never falls back to the user's physical browser for these actions.
        """
        if world is None:
            return None
        operations = dict(getattr(objective, "metadata", {}) or {}).get("browser_operations")
        if operations is None:
            return None
        if not isinstance(operations, (list, tuple)) or not operations:
            return False, "browser_operations must be a non-empty list when supplied"
        if len(operations) > 32:
            return False, "browser_operations exceeds the 32-operation mission limit"
        for index, item in enumerate(operations):
            if not isinstance(item, dict):
                return False, f"browser operation {index} is not an object"
            operation = str(item.get("operation", "")).strip()
            arguments = item.get("arguments", {})
            if not operation or not isinstance(arguments, dict):
                return False, f"browser operation {index} requires operation and object arguments"
            request = ExecutionRequest(
                id=new_id("browser_exec"),
                capability="browser",
                operation=operation,
                arguments=dict(arguments),
                metadata={
                    "mission_id": mission_id,
                    "objective_id": objective.objective_id,
                    "world_id": world.id,
                    "account_id": world.account_id,
                    "operation_index": index,
                },
            )
            result = self._worlds.execute(world.id, request)
            if getattr(result, "status", "failed") != "succeeded":
                error = getattr(result, "error", None) or getattr(result, "stderr", None) or "browser operation failed"
                return False, f"browser operation {index} ({operation}) failed: {error}"
        return True, "browser operations completed"

    def _computer(self, mission_id, objective, world):
        """Execute a GUI objective only inside its dedicated isolated World."""
        from ocean.computer_agent import ComputerUseAgent

        if world is None or world.kind != "desktop":
            return self._failure(objective, AutonomousWorkType.COMPUTER, "computer objective has no desktop execution World")
        agent = ComputerUseAgent(
            max_steps=int(os.getenv("LUMO_COMPUTER_MAX_STEPS", "120")),
            model=os.getenv("LUMO_COMPUTER_MODEL", "auto"),
            allow_actions=True,
            world_manager=self._worlds,
            world_id=world.id,
            account_id=world.account_id,
        )
        result = agent.run(objective.objective, mission_id=mission_id)
        verified = result.status == "completed"
        return MissionObjectiveResult(
            objective_id=objective.objective_id,
            objective=objective.objective,
            status="completed" if verified else "failed",
            error=None if verified else result.message,
            metadata=self._metadata(
                objective,
                AutonomousWorkType.COMPUTER,
                verified=verified,
                evidence=(
                    f"computer_steps={result.steps}",
                    f"computer_status={result.status}",
                    *(
                        (f"last_screenshot={result.last_screenshot}",)
                        if result.last_screenshot
                        else ()
                    ),
                ),
                verification_method="computer_agent_final_state",
                extra={"computer_message": result.message},
            ),
        )

    def _research(self, mission_id, objective):
        candidate_id = new_id("research")
        report = self._runtime.research.conduct(
            ResearchRequest(
                candidate_id=candidate_id,
                objective=objective.objective,
                queries=(objective.objective,),
                metadata={
                    "mission_id": mission_id,
                    "objective_id": objective.objective_id,
                    "autonomous_build": True,
                },
            ),
            self._runtime.research_provider,
        )
        evidence = list(self._runtime.research.evidence_for_candidate(candidate_id))
        verified = bool(report.findings and evidence)
        return MissionObjectiveResult(
            objective_id=objective.objective_id,
            objective=objective.objective,
            status="completed" if verified else "rejected",
            candidate_id=candidate_id,
            error=None if verified else "research produced no evidence",
            metadata=self._metadata(
                objective,
                AutonomousWorkType.RESEARCH,
                verified=verified,
                evidence=evidence,
                verification_method="repository_research",
                extra={"finding_count": len(report.findings)},
            ),
        )

    def _design(self, mission_id, objective):
        proposed = tuple(
            self._strategic_model.decompose(
                mission_id=mission_id,
                goal=(
                    "Design the bounded architecture required for this objective: "
                    + objective.objective
                ),
                repository_context=self._repository_context,
                completed_objectives=(),
                previous_results=(),
            )
        )
        if not proposed:
            return self._failure(
                objective,
                AutonomousWorkType.DESIGN,
                "design provider returned no design structure",
            )

        ids = [item.objective_id for item in proposed]
        if len(ids) != len(set(ids)):
            return self._failure(
                objective,
                AutonomousWorkType.DESIGN,
                "design contains duplicate objective IDs",
            )
        known = set(ids)
        for item in proposed:
            if any(dep not in known for dep in item.dependencies):
                return self._failure(
                    objective,
                    AutonomousWorkType.DESIGN,
                    f"design contains unknown dependency for {item.objective_id!r}",
                )
        try:
            from ocean.orchestration.mission_engine import StrategicMissionPlanner
            StrategicMissionPlanner._validate(proposed)
            StrategicMissionPlanner._validate_acyclic(proposed, set())
        except (TypeError, ValueError) as exc:
            return self._failure(
                objective,
                AutonomousWorkType.DESIGN,
                f"design failed deterministic validation: {exc}",
            )

        design_mission = Mission(
            goal=objective.objective,
            metadata={
                "autonomous_build": True,
                "parent_mission_id": mission_id,
                "objective_id": objective.objective_id,
            },
        )
        self._runtime.missions.save(design_mission)
        self._runtime.events.publish(
            Event(
                type="MissionCreated",
                payload={
                    "id": design_mission.id,
                    "goal": design_mission.goal,
                    "task_ids": [],
                    "metadata": dict(design_mission.metadata),
                },
                aggregate_type="mission",
                aggregate_id=design_mission.id,
                correlation_id=mission_id,
                source="autonomous_build",
            )
        )

        decision = self._runtime.planning.create_decision(
            mission_id=design_mission.id,
            kind="autonomous_build_design",
            objective=objective.objective,
            rationale=objective.rationale or "Model-generated autonomous build design.",
            evidence=tuple(
                f"design_objective={item.objective_id}: {item.objective}"
                for item in proposed
            ),
            metadata={
                "autonomous_build": True,
                "objective_id": objective.objective_id,
                "work_type": AutonomousWorkType.DESIGN.value,
            },
        )

        evidence = [
            f"decision_id={decision.id}",
            f"design_objective_count={len(proposed)}",
        ]
        evidence.extend(
            f"design_objective={item.objective_id}"
            for item in proposed
        )

        return MissionObjectiveResult(
            objective_id=objective.objective_id,
            objective=objective.objective,
            status="completed",
            candidate_id=decision.id,
            metadata=self._metadata(
                objective,
                AutonomousWorkType.DESIGN,
                verified=True,
                evidence=evidence,
                verification_method="persisted_design_decision",
            ),
        )

    def _testing(self, mission_id, objective):
        candidate_id = new_id("test_run")
        report = self._runtime.benchmark_provider.benchmark(
            type(
                "TestingRequest",
                (),
                {
                    "candidate_id": candidate_id,
                    "objective": objective.objective,
                    "workspace_root": str(self._runtime.repository_root),
                    "baseline_root": str(self._runtime.baseline_root),
                },
            )()
        )
        quality = next(
            (item for item in report.results if item.name == "test_quality"),
            None,
        )
        verified = quality is not None and quality.value >= 1.0
        evidence = [
            f"test_quality={quality.value if quality is not None else 0.0}",
            f"command={list(report.metadata.get('command', ()))!r}",
        ]
        if quality is not None:
            evidence.append(
                f"exit_code={quality.metadata.get('exit_code')}"
            )
        return MissionObjectiveResult(
            objective_id=objective.objective_id,
            objective=objective.objective,
            status="completed" if verified else "rejected",
            candidate_id=candidate_id,
            error=None if verified else "test suite failed",
            metadata=self._metadata(
                objective,
                AutonomousWorkType.TESTING,
                verified=verified,
                evidence=evidence,
                verification_method="repository_test_execution",
            ),
        )

    def _verification(self, mission_id, objective):
        completed_by_id = {
            event.payload.get("objective_id"): event
            for event in self._runtime.events.history("ObjectiveCompleted")
            if event.payload.get("mission_id") == mission_id
        }
        dependencies = tuple(objective.dependencies)
        missing = [item for item in dependencies if item not in completed_by_id]
        if missing:
            return self._failure(
                objective,
                AutonomousWorkType.VERIFICATION,
                f"verification dependencies lack completion evidence: {missing!r}",
            )

        evidence: list[str] = []
        for dependency in dependencies:
            event = completed_by_id[dependency]
            metadata = dict(event.payload.get("metadata") or {})
            if metadata.get("verified") is not True:
                return self._failure(
                    objective,
                    AutonomousWorkType.VERIFICATION,
                    f"dependency {dependency!r} is not verified",
                )
            evidence.extend(str(item) for item in metadata.get("evidence", ()))
            evidence.append(f"verified_dependency={dependency}")

        if not dependencies:
            result = self._testing(mission_id, objective)
            if result.status != "completed":
                return result
            evidence.extend(str(item) for item in result.metadata.get("evidence", ()))

        return MissionObjectiveResult(
            objective_id=objective.objective_id,
            objective=objective.objective,
            status="completed",
            metadata=self._metadata(
                objective,
                AutonomousWorkType.VERIFICATION,
                verified=True,
                evidence=evidence,
                verification_method="dependency_evidence_verification",
            ),
        )

    def _artifact(self, mission_id, objective):
        """Create and verify a concrete file artifact from structured model output."""
        planner = getattr(self._strategic_model, "plan_artifact", None)
        if not callable(planner):
            return self._failure(objective, AutonomousWorkType.ARTIFACT, "artifact planning capability is unavailable")
        research = []
        for event in self._runtime.events.history("ResearchFindingRecorded"):
            if event.payload.get("mission_id") == mission_id:
                research.append({
                    "claim": event.payload.get("claim", ""),
                    "source": event.payload.get("source", {}),
                    "evidence": event.payload.get("evidence", ()),
                })
        plan = planner(goal=objective.objective, evidence=research)
        if not isinstance(plan, Mapping) or not isinstance(plan.get("slides"), list):
            return self._failure(objective, AutonomousWorkType.ARTIFACT, "artifact planner returned no slide structure")
        title = str(plan.get("title") or objective.objective).strip()
        output_dir = Path(self._runtime.repository_root) / ".ocean" / "artifacts" / mission_id
        safe_name = re.sub(r"[^A-Za-z0-9._-]+", "_", title).strip("_")[:80] or "presentation"
        output_path = output_dir / f"{safe_name}.pptx"
        from ocean.capabilities.artifact import create_presentation
        verification = create_presentation(output_path=output_path, title=title, slides=plan["slides"])
        return MissionObjectiveResult(
            objective_id=objective.objective_id,
            objective=objective.objective,
            status="completed" if verification.get("verified") else "rejected",
            error=None if verification.get("verified") else "artifact verification failed",
            metadata=self._metadata(
                objective, AutonomousWorkType.ARTIFACT, verified=bool(verification.get("verified")),
                evidence=(
                    f"artifact_path={verification['path']}",
                    f"slide_count={verification['slide_count']}",
                    "artifact_reopened_and_verified=True",
                ),
                verification_method="reopened_pptx_and_inspected_slide_text",
                extra={"artifact": verification, "artifact_plan": plan},
            ),
        )

    @staticmethod
    def _metadata(
        objective: MissionObjective,
        work_type: AutonomousWorkType,
        *,
        verified: bool,
        evidence: Sequence[str],
        verification_method: str,
        extra: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        metadata = {
            **dict(getattr(objective, "metadata", {}) or {}),
            "autonomous_build": True,
            "work_type": work_type.value,
            "acceptance_criteria": list(
                getattr(objective, "acceptance_criteria", ()) or ()
            ),
            "verified": bool(verified),
            "evidence": [str(item) for item in evidence if str(item).strip()],
            "verification_method": verification_method,
        }
        if extra:
            metadata.update(extra)
        return metadata

    def _failure(self, objective, work_type, error):
        return MissionObjectiveResult(
            objective_id=objective.objective_id,
            objective=objective.objective,
            status="rejected",
            error=error,
            metadata=self._metadata(
                objective,
                work_type,
                verified=False,
                evidence=(),
                verification_method="none",
            ),
        )
