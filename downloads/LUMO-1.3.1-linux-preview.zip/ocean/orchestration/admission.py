from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Protocol, TYPE_CHECKING

if TYPE_CHECKING:
    from ocean.domain.assignment import Assignment


@dataclass(frozen=True)
class ExecutionAdmissionKey:
    plan_revision_id: str
    execution_node_id: str

    def __post_init__(self) -> None:
        if not self.plan_revision_id or not self.plan_revision_id.strip():
            raise ValueError("plan_revision_id is required")
        if not self.execution_node_id or not self.execution_node_id.strip():
            raise ValueError("execution_node_id is required")

    @property
    def value(self) -> str:
        return f"{self.plan_revision_id}:{self.execution_node_id}"

    @classmethod
    def from_assignment_metadata(cls, metadata: dict) -> "ExecutionAdmissionKey | None":
        plan_revision_id = metadata.get("execution_plan_id")
        execution_node_id = metadata.get("execution_node_id")
        if plan_revision_id is None and execution_node_id is None:
            return None
        if plan_revision_id is None or execution_node_id is None:
            raise ValueError("plan-managed assignment metadata requires execution_plan_id and execution_node_id")
        return cls(plan_revision_id=str(plan_revision_id), execution_node_id=str(execution_node_id))


class ExecutionAdmissionStore(Protocol):
    """Atomic durable boundary for plan-node assignment admission."""

    def admit(self, key: ExecutionAdmissionKey, assignment: "Assignment") -> tuple["Assignment", bool]:
        """Return (assignment, created). Concurrent admission must converge."""
        ...
