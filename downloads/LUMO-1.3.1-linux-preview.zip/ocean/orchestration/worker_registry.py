"""Runtime worker registry for LUMO orchestration.

Workers are control-plane records. They never own host input devices.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from threading import RLock
from typing import Any
from time import time

class WorkerState(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    BLOCKED = "blocked"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"

@dataclass
class WorkerHandle:
    worker_id: str
    mission_id: str
    mode: str
    state: WorkerState = WorkerState.QUEUED
    cursor_id: str | None = None
    world_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time)
    updated_at: float = field(default_factory=time)

class WorkerRegistry:
    """Authoritative in-memory worker index for active orchestration."""

    def __init__(self) -> None:
        self._lock = RLock()
        self._workers: dict[str, WorkerHandle] = {}

    def register(self, worker: WorkerHandle) -> WorkerHandle:
        with self._lock:
            if worker.worker_id in self._workers:
                raise ValueError(f"worker already registered: {worker.worker_id}")
            worker.updated_at = time()
            self._workers[worker.worker_id] = worker
            return worker

    def get(self, worker_id: str) -> WorkerHandle | None:
        with self._lock:
            return self._workers.get(worker_id)

    def transition(self, worker_id: str, state: WorkerState, **metadata: Any) -> WorkerHandle:
        with self._lock:
            worker = self._workers[worker_id]
            worker.state = state
            worker.updated_at = time()
            if metadata:
                worker.metadata.update(metadata)
            return worker

    def remove(self, worker_id: str) -> WorkerHandle | None:
        with self._lock:
            return self._workers.pop(worker_id, None)

    def active(self, mission_id: str | None = None) -> tuple[WorkerHandle, ...]:
        with self._lock:
            rows = tuple(
                w for w in self._workers.values()
                if w.state in {WorkerState.QUEUED, WorkerState.RUNNING, WorkerState.BLOCKED}
                and (mission_id is None or w.mission_id == mission_id)
            )
            return tuple(sorted(rows, key=lambda w: w.created_at))

    def snapshot(self, mission_id: str | None = None) -> list[dict[str, Any]]:
        with self._lock:
            rows = tuple(
                w for w in self._workers.values()
                if mission_id is None or w.mission_id == mission_id
            )
        return [
            {
                "worker_id": w.worker_id,
                "mission_id": w.mission_id,
                "mode": w.mode,
                "state": w.state.value,
                "cursor_id": w.cursor_id,
                "world_id": w.world_id,
                "metadata": dict(w.metadata),
                "created_at": w.created_at,
                "updated_at": w.updated_at,
            }
            for w in sorted(rows, key=lambda w: w.created_at)
        ]

__all__ = ["WorkerHandle", "WorkerRegistry", "WorkerState"]
