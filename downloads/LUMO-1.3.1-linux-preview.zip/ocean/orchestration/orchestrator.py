"""Multi-agent orchestration control plane."""

from __future__ import annotations

from contextlib import contextmanager
from typing import Iterable, Iterator, Optional, Protocol, Set

from ocean.core.ids import new_id
from ocean.domain.assignment import Assignment
from ocean.domain.enums import AssignmentStatus, FailureCategory, TaskStatus
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.domain.mission import Mission
from ocean.domain.task import Task
from ocean.domain.agent import Agent
from ocean.orchestration.policy import OrchestrationPolicyRegistry
from ocean.orchestration.types import (
    AssignmentRequest,
    ExecutionIntent,
    OrchestrationResult,
    ReconciliationResult,
    RecoveryDecision,
)

from runtime.types import ExecutionResult


_FAILURE_TYPE_TO_CATEGORY = {
    "timeout": FailureCategory.TIMEOUT,
    "cancelled": FailureCategory.CANCELLATION,
    "execution_terminal_conflict": FailureCategory.TRANSIENT,
    "invalid_capability_output": FailureCategory.INVALID_INPUT,
    "execution_failure": FailureCategory.UNKNOWN,
}


def classify_failure(result: ExecutionResult) -> tuple[FailureCategory, bool]:
    """Extract structured failure classification from an ExecutionResult."""
    metadata = result.metadata
    raw_type = metadata.get("failure_type", "")
    category = _FAILURE_TYPE_TO_CATEGORY.get(
        raw_type, FailureCategory.UNKNOWN
    )
    retryable = bool(metadata.get("retryable", False))
    return category, retryable


class MissionPort(Protocol):
    """Port used by the orchestrator to access missions."""

    def get(self, mission_id: str) -> Optional[Mission]:
        ...

    def save(self, mission: Mission) -> None:
        ...


class TaskPort(Protocol):
    """Port used by the orchestrator to access tasks."""

    def get(self, task_id: str) -> Optional[Task]:
        ...

    def save(self, task: Task) -> None:
        ...


class AssignmentPort(Protocol):
    """Port used by the orchestrator to persist assignments."""

    def get(self, assignment_id: str) -> Optional[Assignment]:
        ...

    def save(self, assignment: Assignment) -> None:
        ...

    def list(self) -> Iterable[Assignment]:
        ...

    @contextmanager
    def transaction(self) -> Iterator[None]:
        ...


class AgentPort(Protocol):
    """Port used by the orchestrator to access agents."""

    def get(self, agent_id: str) -> Optional[Agent]:
        ...


class AgentRuntimePort(Protocol):
    """Port used by the orchestrator to submit work to agent runtime."""

    def submit(self, agent_id: str, request, *, priority: int = 0,
               dependencies=None):
        ...

    def mark_idle(self, agent_id: str) -> Agent:
        ...

    def mark_waiting(self, agent_id: str, *, task_id: Optional[str] = None) -> Agent:
        ...

    def mark_background(self, agent_id: str) -> Agent:
        ...


class OrchestrationPorts:
    """Dependency bundle for the orchestration control plane."""

    def __init__(
        self,
        *,
        missions: MissionPort,
        tasks: TaskPort,
        assignments: AssignmentPort,
        agents: AgentPort,
        agent_runtime: AgentRuntimePort,
        events: EventBus,
    ) -> None:
        self.missions = missions
        self.tasks = tasks
        self.assignments = assignments
        self.agents = agents
        self.agent_runtime = agent_runtime
        self.events = events


class Orchestrator:
    """
    Coordinates Missions, Tasks, Assignments, Agents, and Executions.

    The orchestrator owns relationships and control decisions. It does not
    execute capability work itself and does not replace domain lifecycles.
    """

    def __init__(
        self,
        ports: OrchestrationPorts,
        *,
        policies: Optional[OrchestrationPolicyRegistry] = None,
        subscribe: bool = True,
    ) -> None:
        self._ports = ports
        self._policies = policies or OrchestrationPolicyRegistry()

        # Scheduler communicates with orchestration exclusively through the
        # durable event boundary. The scheduler itself remains unaware of the
        # orchestrator.
        if subscribe:
            self._ports.events.subscribe(
                "ScheduledExecutionDispatched",
                self._handle_scheduled_execution_dispatched,
            )
            self._ports.events.subscribe(
                "ScheduledExecutionCompleted",
                self._handle_scheduled_execution_completed,
            )
            self._ports.events.subscribe(
                "ScheduledExecutionFailed",
                self._handle_scheduled_execution_failed,
            )
            self._ports.events.subscribe(
                "ScheduledExecutionCancelled",
                self._handle_scheduled_execution_cancelled,
            )

    @property
    def ports(self) -> OrchestrationPorts:
        return self._ports

    @property
    def policies(self) -> OrchestrationPolicyRegistry:
        return self._policies


    def _handle_scheduled_execution_dispatched(self, event: Event) -> None:
        """Reconcile a Scheduler dispatch event into Assignment.ACTIVE.

        A queued Assignment becomes ACTIVE only after the Scheduler has
        actually submitted the execution to the ExecutionSupervisor.
        ``causation_id`` identifies the originating Assignment and
        ``aggregate_id`` identifies the dispatched execution.
        """

        assignment_id = event.causation_id
        execution_id = event.aggregate_id

        if not assignment_id:
            raise ValueError(
                "scheduled execution dispatch event is missing causation_id"
            )

        if not execution_id:
            raise ValueError(
                "scheduled execution dispatch event is missing aggregate_id"
            )

        assignment = self._ports.assignments.get(assignment_id)

        if assignment is None:
            raise ValueError(
                f"unknown assignment referenced by scheduled execution "
                f"dispatch event: {assignment_id!r}"
            )

        if assignment.execution_id != execution_id:
            raise ValueError(
                f"scheduled execution {execution_id!r} does not match "
                f"assignment {assignment_id!r} execution "
                f"{assignment.execution_id!r}"
            )

        # Idempotent duplicate delivery.
        if assignment.status is AssignmentStatus.ACTIVE:
            return

        if assignment.status is not AssignmentStatus.QUEUED:
            raise ValueError(
                f"assignment {assignment_id!r} must be queued before "
                f"scheduler dispatch; current status is "
                f"{assignment.status.value!r}"
            )

        assignment.activate(
            reason="execution dispatched by scheduler",
        )

        event = Event(
            type="TaskAssignmentActivated",
            payload={
                "assignment_id": assignment.id,
                "task_id": assignment.task_id,
                "agent_id": assignment.agent_id,
                "mission_id": assignment.mission_id,
                "execution_id": execution_id,
                "mode": assignment.mode.value,
                "priority": assignment.priority,
            },
            aggregate_type="assignment",
            aggregate_id=assignment.id,
            correlation_id=assignment.mission_id,
            causation_id=event.id,
            source="orchestrator",
        )

        with self._ports.assignments.transaction():
            self._ports.assignments.save(assignment)
            self._ports.events.publish(event)

    def _handle_scheduled_execution_completed(self, event: Event) -> None:
        self._reconcile_scheduled_execution_event(
            event,
            success=True,
        )

    def _handle_scheduled_execution_failed(self, event: Event) -> None:
        self._reconcile_scheduled_execution_event(
            event,
            success=False,
        )

    def _handle_scheduled_execution_cancelled(self, event: Event) -> None:
        """Reconcile a scheduler cancellation event into Assignment.CANCELLED.

        When the scheduler cancels a QUEUED or ACTIVE item during shutdown,
        the corresponding assignment must transition to CANCELLED so it
        does not remain in a non-terminal state forever.
        """
        assignment_id = event.causation_id
        execution_id = event.aggregate_id

        if not assignment_id:
            return

        assignment = self._ports.assignments.get(assignment_id)
        if assignment is None:
            return

        if assignment.status in {
            AssignmentStatus.CANCELLED,
            AssignmentStatus.COMPLETED,
            AssignmentStatus.FAILED,
            AssignmentStatus.SUPERSEDED,
        }:
            return

        if assignment.execution_id != execution_id:
            return

        assignment.cancel(reason="scheduler shutdown; execution cancelled")

        cancel_event = Event(
            type="TaskAssignmentCancelled",
            payload={
                "assignment_id": assignment.id,
                "task_id": assignment.task_id,
                "agent_id": assignment.agent_id,
                "mission_id": assignment.mission_id,
                "execution_id": execution_id,
            },
            aggregate_type="assignment",
            aggregate_id=assignment.id,
            correlation_id=assignment.mission_id,
            causation_id=event.id,
            source="orchestrator",
        )

        with self._ports.assignments.transaction():
            self._ports.assignments.save(assignment)
            self._ports.events.publish(cancel_event)

    def _reconcile_scheduled_execution_event(
        self,
        event: Event,
        *,
        success: bool,
    ) -> None:
        """Reconcile a Scheduler terminal event into its Assignment.

        Scheduler events identify the originating assignment through
        ``causation_id`` and the execution through ``aggregate_id``.
        The adapter validates both identities before allowing the
        orchestration state machine to change.

        Terminal duplicate delivery is intentionally idempotent: once an
        assignment has already reached the expected terminal state for the
        same execution, the event is treated as already applied.
        """
        assignment_id = event.causation_id
        execution_id = event.aggregate_id

        if not assignment_id:
            raise ValueError(
                "scheduled execution event is missing causation_id"
            )

        if not execution_id:
            raise ValueError(
                "scheduled execution event is missing aggregate_id"
            )

        assignment = self._ports.assignments.get(assignment_id)
        if assignment is None:
            raise ValueError(
                f"unknown assignment referenced by scheduled execution "
                f"event: {assignment_id!r}"
            )

        if assignment.execution_id != execution_id:
            raise ValueError(
                f"scheduled execution {execution_id!r} does not match "
                f"assignment {assignment_id!r} execution "
                f"{assignment.execution_id!r}"
            )

        expected_status = (
            AssignmentStatus.COMPLETED
            if success
            else AssignmentStatus.FAILED
        )

        # Idempotent terminal delivery.
        if assignment.status is expected_status:
            return

        # A terminal assignment with the opposite result is a contradiction,
        # not a duplicate.
        if assignment.status in {
            AssignmentStatus.COMPLETED,
            AssignmentStatus.FAILED,
            AssignmentStatus.CANCELLED,
            AssignmentStatus.SUPERSEDED,
        }:
            raise ValueError(
                f"assignment {assignment_id!r} is already terminal with "
                f"status {assignment.status.value!r}"
            )

        result = ExecutionResult(
            success=success,
            result=event.payload.get("result"),
            error=event.payload.get("error"),
            metadata={
                "scheduler_event_id": event.id,
                "scheduler_event_type": event.type,
            },
        )

        # A failed execution is still a successfully processed lifecycle
        # event. ``reconciliation.success`` describes the execution outcome,
        # not whether the event handler itself succeeded.
        self.reconcile(
            assignment_id,
            result,
        )

    def _find_scheduler_event(self, execution_id):
        scheduler_event_types = {"ScheduledExecutionQueued", "ScheduledExecutionDispatched", "ScheduledExecutionCompleted", "ScheduledExecutionFailed", "ScheduledExecutionCancelled"}


        return next((e for e in reversed(self._ports.events.history()) if e.aggregate_id == execution_id and e.type in scheduler_event_types), None)
    def dispatch(
        self,
        assignment_id: str,
        intent: ExecutionIntent,

        *,
        dependency_execution_ids: Optional[Set[str]] = None,
    ) -> OrchestrationResult:
        """Dispatch a queued assignment into the execution runtime.

        The orchestrator translates the task dependency graph from task IDs
        into execution IDs understood by the scheduler. It then constructs
        the canonical runtime ExecutionRequest and activates the assignment.
        """

        assignment = self._ports.assignments.get(assignment_id)
        if assignment is None:
            return OrchestrationResult(
                success=False,
                error=f"unknown assignment: {assignment_id!r}",
            )

        if assignment.status != AssignmentStatus.QUEUED:
            return OrchestrationResult(
                success=False,
                error=(
                    f"assignment {assignment_id!r} must be queued before "
                    f"dispatch; current status is {assignment.status.value!r}"
                ),
            )

        task = self._ports.tasks.get(assignment.task_id)
        if task is None:
            return OrchestrationResult(
                success=False,
                error=f"unknown task: {assignment.task_id!r}",
            )

        agent = self._ports.agents.get(assignment.agent_id)
        if agent is None:
            return OrchestrationResult(
                success=False,
                error=f"unknown agent: {assignment.agent_id!r}",
            )

        if dependency_execution_ids is None:
            dependency_execution_ids = set()

            for dependency_task_id in task.depends_on:
                dependency_assignment = self._find_active_assignment_for_task(
                    dependency_task_id
                )

                if dependency_assignment is None:
                    return OrchestrationResult(
                        success=False,
                        error=(
                            f"unresolved dependency task "
                            f"{dependency_task_id!r}: no assignment exists"
                        ),
                    )

                if dependency_assignment.execution_id is None:
                    return OrchestrationResult(
                        success=False,
                        error=(
                            f"unresolved dependency task "
                            f"{dependency_task_id!r}: assignment "
                            f"{dependency_assignment.id!r} has no execution"
                        ),
                    )

                dependency_execution_ids.add(
                    dependency_assignment.execution_id
                )
        else:
            dependency_execution_ids = set(dependency_execution_ids)

        from runtime.types import ExecutionRequest
        from ocean.domain.execution import new_id

        execution_id = assignment.execution_id or new_id("exec")
        assignment.bind_execution(execution_id)
        self._ports.assignments.save(assignment)

        existing_event = self._find_scheduler_event(execution_id)
        if existing_event is not None:
            if existing_event.type in {"ScheduledExecutionQueued", "ScheduledExecutionDispatched"}:
                return OrchestrationResult(success=True, assignment_id=assignment.id, execution_id=execution_id, metadata={"status": existing_event.payload.get("state", assignment.status.value), "reconciled": True, "scheduler_event_id": existing_event.id, "scheduler_event_type": existing_event.type, "dependencies": sorted(dependency_execution_ids)})
            return OrchestrationResult(success=False, assignment_id=assignment.id, execution_id=execution_id, error=f"execution {execution_id!r} already has terminal scheduler event {existing_event.type!r}; a new execution attempt is required", metadata={"reconciled": True, "scheduler_event_id": existing_event.id, "scheduler_event_type": existing_event.type, "status": existing_event.payload.get("state")})

        request = ExecutionRequest(
            task_id=task.id,
            capability=intent.capability,
            operation=intent.operation,
            agent_id=agent.id,
            principal_id=assignment.principal_id,
            mission_id=assignment.mission_id,
            mode=assignment.mode,
            arguments=dict(intent.arguments),
            correlation_id=assignment.mission_id,
            causation_id=assignment.id,
            source="orchestrator",
            execution_id=execution_id,
            resource_limits=intent.resource_limits,
        )

        try:
            scheduled = self._ports.agent_runtime.submit(
                agent.id,
                request,
                priority=assignment.priority,
                dependencies=dependency_execution_ids,
            )
        except Exception as exc:
            return OrchestrationResult(
                success=False,
                error=f"failed to dispatch assignment: {exc}",
            )

        scheduled_execution_id = scheduled.execution_id
        if not scheduled_execution_id:
            return OrchestrationResult(
                success=False,
                error="execution runtime returned no execution ID",
            )

        if scheduled_execution_id != execution_id:
            return OrchestrationResult(
                success=False,
                error=(
                    "execution runtime returned a different execution ID "
                    f"{scheduled_execution_id!r}; expected {execution_id!r}"
                ),
            )

        return OrchestrationResult(
            success=True,
            assignment_id=assignment.id,
            execution_id=execution_id,
            metadata={
                "status": AssignmentStatus.QUEUED.value,
                "dependencies": sorted(dependency_execution_ids),
            },
        )

    def reconcile(
        self,
        assignment_id: str,
        result,
    ) -> ReconciliationResult:
        """Reconcile an execution result into assignment state.

        Execution success means the assigned operation completed successfully.
        It does not by itself prove that the Task objective was achieved.
        Task completion therefore remains the responsibility of verification.
        """

        assignment = self._ports.assignments.get(assignment_id)
        if assignment is None:
            return ReconciliationResult(
                assignment_id=assignment_id,
                status="unknown",
                success=False,
                error=f"unknown assignment: {assignment_id!r}",
            )

        if assignment.execution_id is None:
            return ReconciliationResult(
                assignment_id=assignment.id,
                status=assignment.status.value,
                success=False,
                error="assignment has no execution to reconcile",
            )

        if assignment.status != AssignmentStatus.ACTIVE:
            return ReconciliationResult(
                assignment_id=assignment.id,
                status=assignment.status.value,
                execution_id=assignment.execution_id,
                success=False,
                error=(
                    f"assignment must be active before reconciliation; "
                    f"current status is {assignment.status.value!r}"
                ),
            )

        if result.success:
            assignment.complete(reason="execution succeeded")

            event = Event(
                type="TaskAssignmentCompleted",
                payload={
                    "assignment_id": assignment.id,
                    "task_id": assignment.task_id,
                    "agent_id": assignment.agent_id,
                    "mission_id": assignment.mission_id,
                    "execution_id": assignment.execution_id,
                    "result": result.result,
                },
                aggregate_type="assignment",
                aggregate_id=assignment.id,
                correlation_id=assignment.mission_id,
                source="orchestrator",
            )

            with self._ports.assignments.transaction():
                self._ports.assignments.save(assignment)
                self._ports.events.publish(event)

            return ReconciliationResult(
                assignment_id=assignment.id,
                status=assignment.status.value,
                execution_id=assignment.execution_id,
                success=True,
                metadata={
                    "result": result.result,
                    "task_requires_verification": True,
                },
            )

        error = result.error or "execution failed"
        failure_category, retryable = classify_failure(result)

        assignment.fail(
            reason=error,
        )

        event = Event(
            type="TaskAssignmentFailed",
            payload={
                "assignment_id": assignment.id,
                "task_id": assignment.task_id,
                "agent_id": assignment.agent_id,
                "mission_id": assignment.mission_id,
                "execution_id": assignment.execution_id,
                "error": error,
                "failure_category": failure_category.value,
                "retryable": retryable,
            },
            aggregate_type="assignment",
            aggregate_id=assignment.id,
            correlation_id=assignment.mission_id,
            source="orchestrator",
        )

        with self._ports.assignments.transaction():
            self._ports.assignments.save(assignment)
            self._ports.events.publish(event)

        return ReconciliationResult(
            assignment_id=assignment.id,
            status=assignment.status.value,
            execution_id=assignment.execution_id,
            success=False,
            error=error,
            failure_category=failure_category,
            retryable=retryable,
        )

    def _find_active_assignment_for_task(
        self,
        task_id: str,
    ) -> Optional[Assignment]:
        """Find the assignment whose execution represents a task dependency.

        Prefer an active assignment with an execution ID. If none exists,
        an assignment that has already completed is also a valid dependency
        provider because its execution is already a completed prerequisite.
        """

        candidates = [
            assignment
            for assignment in self._ports.assignments.list()
            if assignment.task_id == task_id
            and assignment.execution_id is not None
            and assignment.status
            not in {
                AssignmentStatus.CANCELLED,
                AssignmentStatus.SUPERSEDED,
            }
        ]

        if not candidates:
            return None

        return max(
            candidates,
            key=lambda assignment: assignment.updated_at,
        )

    def assign(
        self,
        request: AssignmentRequest,
    ) -> OrchestrationResult:
        """Create and queue a durable task-to-agent assignment.

        This operation performs orchestration admission only. It does not
        dispatch execution and does not activate the agent.
        """
        policy = self._policies.get(request.mode)

        admission = policy.admission(request)
        if not admission.allowed:
            return OrchestrationResult(
                success=False,
                error=admission.reason or "assignment rejected by policy",
            )

        task = self._ports.tasks.get(request.task_id)
        if task is None:
            return OrchestrationResult(
                success=False,
                error=f"unknown task: {request.task_id!r}",
            )

        agent = self._ports.agents.get(request.agent_id)
        if agent is None:
            return OrchestrationResult(
                success=False,
                error=f"unknown agent: {request.agent_id!r}",
            )

        if task.is_terminal():
            return OrchestrationResult(
                success=False,
                error=(
                    f"cannot assign terminal task "
                    f"{request.task_id!r}: {task.status.value}"
                ),
            )

        if request.mission_id is not None:
            mission = self._ports.missions.get(request.mission_id)
            if mission is None:
                return OrchestrationResult(
                    success=False,
                    error=f"unknown mission: {request.mission_id!r}",
                )

            if task.mission_id != request.mission_id:
                return OrchestrationResult(
                    success=False,
                    error=(
                        f"task {request.task_id!r} does not belong to "
                        f"mission {request.mission_id!r}"
                    ),
                )

            if request.task_id not in mission.task_ids:
                return OrchestrationResult(
                    success=False,
                    error=(
                        f"task {request.task_id!r} is not registered "
                        f"with mission {request.mission_id!r}"
                    ),
                )

        routing = policy.routing(request)

        if routing.agent_id != request.agent_id:
            return OrchestrationResult(
                success=False,
                error="policy routing decision conflicts with requested agent",
            )

        assignment = Assignment(
            task_id=request.task_id,
            agent_id=request.agent_id,
            mission_id=request.mission_id,
            execution_id=request.execution_id,
            mode=request.mode,
            priority=request.priority,
            parent_assignment_id=request.parent_assignment_id,
            reason=request.reason,
            metadata=dict(request.metadata),
        )

        from ocean.orchestration.admission import ExecutionAdmissionKey

        admission_key = ExecutionAdmissionKey.from_assignment_metadata(
            dict(assignment.metadata)
        )

        if admission_key is None:
            self._ports.assignments.save(assignment)
            admitted = True
        else:
            admit = getattr(self._ports.assignments, "admit", None)
            if admit is None:
                return OrchestrationResult(
                    success=False,
                    error="assignment persistence does not support atomic admission",
                )
            existing, admitted = admit(admission_key, assignment)
            if not admitted:
                return OrchestrationResult(
                    success=True,
                    assignment_id=existing.id,
                    metadata={
                        "status": existing.status.value,
                        "idempotent": True,
                    },
                )

        self._ports.events.publish(
            Event(
                type="TaskAssignmentCreated",
                payload={
                    "assignment_id": assignment.id,
                    "task_id": assignment.task_id,
                    "agent_id": assignment.agent_id,
                    "mission_id": assignment.mission_id,
                    "mode": assignment.mode.value,
                    "priority": assignment.priority,
                    "parent_assignment_id": assignment.parent_assignment_id,
                    "reason": assignment.reason,
                    "metadata": dict(assignment.metadata),
                },
                aggregate_type="assignment",
                aggregate_id=assignment.id,
                correlation_id=assignment.mission_id,
                source="orchestrator",
            )
        )

        assignment.queue(reason="orchestration admitted")
        self._ports.assignments.save(assignment)

        self._ports.events.publish(
            Event(
                type="TaskAssignmentQueued",
                payload={
                    "assignment_id": assignment.id,
                    "task_id": assignment.task_id,
                    "agent_id": assignment.agent_id,
                    "mission_id": assignment.mission_id,
                    "mode": assignment.mode.value,
                    "priority": assignment.priority,
                },
                aggregate_type="assignment",
                aggregate_id=assignment.id,
                correlation_id=assignment.mission_id,
                source="orchestrator",
            )
        )

        return OrchestrationResult(
            success=True,
            assignment_id=assignment.id,
            metadata={
                "status": AssignmentStatus.QUEUED.value,
            },
        )
