from __future__ import annotations

from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from concurrent.futures import TimeoutError as FutureTimeoutError
from dataclasses import dataclass, field, replace
import re
import threading
import time
from typing import Callable, Mapping, Protocol, Sequence

from ocean.core.ids import new_id
from ocean.cognition import MissionIntelligenceRouter
from ocean.resilience import DependencyRequirement, DependencyRecovery
from ocean.optimization_fabric import OptimizationFabric, BudgetHierarchy
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus


@dataclass(frozen=True)
class MissionObjective:
    objective_id: str
    objective: str
    rationale: str = ""
    dependencies: tuple[str, ...] = ()
    priority: int = 0
    work_type: str = "implementation"
    acceptance_criteria: tuple[str, ...] = ()
    metadata: Mapping[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.objective_id.strip():
            raise ValueError("objective_id must be non-empty")
        # Empty objective validation belongs to the planner boundary so
        # callers can construct invalid proposals and have them rejected
        # consistently by planning validation.
        if not self.work_type.strip():
            raise ValueError("work_type must be non-empty")
        criteria = tuple(item.strip() for item in self.acceptance_criteria)
        if any(not item for item in criteria):
            raise ValueError("acceptance_criteria must contain non-empty strings")
        object.__setattr__(self, "acceptance_criteria", criteria)
        object.__setattr__(self, "metadata", dict(self.metadata))


@dataclass(frozen=True)
class MissionContract:
    """Mission-level outcome contract used to decide whether a goal is done."""

    required_work_types: tuple[str, ...] = ()
    require_evidence: bool = False
    mutation_policy: str = "allow"

    def __post_init__(self) -> None:
        allowed = {
            "research",
            "design",
            "implementation",
            "testing",
            "integration",
            "verification",
            "browser",
            "computer",
            "artifact",
        }
        normalized = tuple(dict.fromkeys(item.strip().lower() for item in self.required_work_types))
        if any(item not in allowed for item in normalized):
            raise ValueError("mission contract contains unsupported work type")
        mutation_policy = str(self.mutation_policy).strip().lower()
        if mutation_policy not in {"allow", "read_only"}:
            raise ValueError("mission contract contains unsupported mutation policy")
        object.__setattr__(self, "required_work_types", normalized)
        object.__setattr__(self, "mutation_policy", mutation_policy)

    @classmethod
    def from_goal(cls, goal: str) -> "MissionContract":
        """Infer only explicit outcome stages from mission language."""
        text = goal.lower()
        required: list[str] = []

        if any(word in text for word in ("research", "investigate", "audit", "inspect", "review", "analy")):
            required.append("research")
        # "plan" refers to the Mission Engine's planning process and must not
        # implicitly require a separate design deliverable. Require the design
        # outcome only when the user explicitly asks to design/architect something.
        if any(word in text for word in ("design", "designing", "architect", "architecting")):
            required.append("design")
        implementation_verbs = (
            "implement", "build", "fix", "create", "develop", "refactor",
            "add", "change", "improve", "harden",
        )
        if any(re.search(rf"\b{re.escape(word)}(?:s|ed|ing)?\b", text) for word in implementation_verbs):
            required.append("implementation")
        if any(word in text for word in ("test", "tests", "testing")):
            required.append("testing")
        if any(word in text for word in ("integrate", "integration")):
            required.append("integration")
        artifact_markers = (
            "presentation", "powerpoint", "power point", "slides", "slide deck",
            "pptx", "spreadsheet", "file deliverable",
            "create a report", "produce a report", "generate a report", "make a report",
            "create a document", "produce a document", "generate a document",
        )
        if any(marker in text for marker in artifact_markers):
            required.append("artifact")
            # Artifact creation is itself the implementation outcome for a
            # concrete deliverable; do not demand a separate source-code
            # implementation stage merely because the user said "build/create".
            required = [item for item in required if item != "implementation"]
        if any(word in text for word in (
            "verify", "verification", "validate", "validation", "evidence",
            "confirm", "prove",
        )):
            required.append("verification")
        # Browser/computer are execution modalities, not generic mission
        # outcomes. Require them only when the user explicitly asks for that
        # modality or an observable UI action; ordinary mentions such as
        # "website" or "app" must not accidentally make a mission contract
        # impossible to satisfy.
        if any(phrase in text for phrase in (
            "use a browser", "use the browser", "browse to", "open in browser",
            "visit the website", "navigate to the website", "browser automation",
        )):
            required.append("browser")
        if any(phrase in text for phrase in (
            "use the computer", "use a computer", "control the computer",
            "desktop automation", "gui automation", "click", "screen interaction",
        )):
            required.append("computer")

        read_only_markers = (
            "read-only",
            "read only",
            "do not modify",
            "don't modify",
            "without modifying",
            "do not change",
            "don't change",
            "without changing",
            "no modifications",
            "no mutation",
        )
        mutation_policy = (
            "read_only"
            if any(marker in text for marker in read_only_markers)
            else "allow"
        )
        return cls(
            required_work_types=tuple(required),
            require_evidence=bool(required),
            mutation_policy=mutation_policy,
        )

    def coverage(self, results: Sequence["MissionObjectiveResult"]) -> set[str]:
        successful = {"promoted", "completed", "success"}
        covered: set[str] = set()
        for result in results:
            if result.status not in successful:
                continue
            metadata = dict(result.metadata or {})
            work_type = str(metadata.get("work_type", "")).strip().lower()
            if work_type:
                covered.add(work_type)
            routed = metadata.get("routed_work_types")
            if isinstance(routed, (list, tuple, set, frozenset)):
                covered.update(
                    str(item).strip().lower()
                    for item in routed
                    if str(item).strip()
                )
        return covered

    def missing(self, results: Sequence["MissionObjectiveResult"]) -> tuple[str, ...]:
        covered = self.coverage(results)
        return tuple(item for item in self.required_work_types if item not in covered)


@dataclass(frozen=True)
class MissionPlan:
    mission_id: str
    goal: str
    objectives: tuple[MissionObjective, ...]
    metadata: Mapping[str, object] = field(default_factory=dict)


@dataclass(frozen=True)
class MissionObjectiveResult:
    objective_id: str
    objective: str
    status: str
    run_id: str | None = None
    candidate_id: str | None = None
    promoted_plan_revision_id: str | None = None
    error: str | None = None
    metadata: Mapping[str, object] = field(default_factory=dict)


@dataclass(frozen=True)
class MissionResult:
    mission_id: str
    goal: str
    status: str
    objective_results: tuple[MissionObjectiveResult, ...]
    completed_objectives: tuple[str, ...]
    remaining_objectives: tuple[str, ...]
    metadata: Mapping[str, object] = field(default_factory=dict)


class MissionPlanner(Protocol):
    def plan(
        self,
        mission_id: str,
        goal: str,
        *,
        completed_objectives: Sequence[str] = (),
        previous_results: Sequence[MissionObjectiveResult] = (),
    ) -> MissionPlan:
        ...


class MissionObjectiveExecutor(Protocol):
    def execute(
        self,
        mission_id: str,
        objective: MissionObjective,
    ) -> MissionObjectiveResult:
        ...


@dataclass(frozen=True)
class MissionObjectiveExecution:
    """The single lease deadline shared by mission and execution runtime."""

    attempt_id: str
    lease_seconds: float | None
    deadline: float | None
    batch_cancel: threading.Event | None = None

    def is_batch_cancelled(self) -> bool:
        """True if the MissionEngine has moved on from this execution batch."""
        return self.batch_cancel is not None and self.batch_cancel.is_set()


class MissionObjectiveExecutionAdapter(Protocol):
    def execute(
        self,
        mission_id: str,
        objective: MissionObjective,
        execution: MissionObjectiveExecution,
    ) -> MissionObjectiveResult:
        ...


class LegacyMissionObjectiveExecutionAdapter:
    """Keep existing mission executors on their original contract."""

    def __init__(self, executor: MissionObjectiveExecutor) -> None:
        self._executor = executor

    def execute(
        self,
        mission_id: str,
        objective: MissionObjective,
        execution: MissionObjectiveExecution,
    ) -> MissionObjectiveResult:
        return self._executor.execute(mission_id, objective)


class DeterministicMissionPlanner:
    """Conservative bootstrap planner.

    This remains useful for deterministic tests. Production strategic
    planning should be supplied by a model-backed planner.
    """

    def plan(
        self,
        mission_id: str,
        goal: str,
        *,
        completed_objectives: Sequence[str] = (),
        previous_results: Sequence[MissionObjectiveResult] = (),
    ) -> MissionPlan:
        if completed_objectives:
            return MissionPlan(
                mission_id=mission_id,
                goal=goal,
                objectives=(),
                metadata={"planner": "deterministic-bootstrap"},
            )

        return MissionPlan(
            mission_id=mission_id,
            goal=goal,
            objectives=(
                MissionObjective(
                    objective_id=new_id("mission_objective"),
                    objective=goal,
                    rationale="Bootstrap planner forwards the mission unchanged.",
                    priority=0,
                    metadata={"bootstrap": True},
                ),
            ),
            metadata={"planner": "deterministic-bootstrap"},
        )


class StrategicMissionPlanningModel(Protocol):
    """Untrusted model used only to propose strategic decomposition."""

    def decompose(
        self,
        *,
        mission_id: str,
        goal: str,
        repository_context: str,
        completed_objectives: Sequence[str],
        previous_results: Sequence[MissionObjectiveResult],
    ) -> Sequence[MissionObjective]:
        ...


class StrategicMissionPlanner:
    """Repository-grounded strategic mission planner.

    The planner determines *what bounded objectives are needed* to achieve a
    mission. It does not execute code, mutate production, verify work, or
    promote changes. Those responsibilities remain below the mission layer.
    """

    def __init__(
        self,
        *,
        repository_context: str,
        model: StrategicMissionPlanningModel,
    ) -> None:
        if not repository_context.strip():
            raise ValueError("repository_context must not be empty")
        self._repository_context = repository_context
        self._model = model

    def plan(
        self,
        mission_id: str,
        goal: str,
        *,
        completed_objectives: Sequence[str] = (),
        previous_results: Sequence[MissionObjectiveResult] = (),
    ) -> MissionPlan:
        if not mission_id.strip():
            raise ValueError("mission_id must not be empty")
        if not goal.strip():
            raise ValueError("goal must not be empty")

        # Every mission goal goes through the strategic model. This is the
        # autonomy boundary: task semantics are not encoded as keyword-specific
        # scripts. Deterministic validation below only checks graph integrity and
        # whether the model stayed grounded in the operator's actual goal.
        planning_feedback = tuple(previous_results)
        objectives: tuple[MissionObjective, ...] = ()
        for attempt in range(2):
            objectives = tuple(
                self._model.decompose(
                    mission_id=mission_id,
                    goal=goal,
                    repository_context=self._repository_context,
                    completed_objectives=tuple(completed_objectives),
                    previous_results=planning_feedback,
                )
            )
            try:
                # The strategic model proposes intent, not an irrevocable
                # execution capability. Route every concrete capability proposal
                # through the integration gateway so the execution layer can
                # inspect current state, recover from a bad route, and choose the
                # appropriate capability without task-specific scripts.
                objectives = tuple(
                    replace(
                        objective,
                        work_type="integration",
                        acceptance_criteria=(
                            "Routed objective completed with verified evidence.",
                        ),
                        metadata={
                            **dict(objective.metadata),
                            "gateway_original_work_type": objective.work_type,
                            "gateway_original_acceptance_criteria": tuple(objective.acceptance_criteria),
                            "autonomous_integration_gateway": True,
                        },
                    )
                    if objective.work_type != "integration"
                    else replace(
                        objective,
                        acceptance_criteria=(
                            "Routed objective completed with verified evidence.",
                        ),
                        metadata={
                            **dict(objective.metadata),
                            "gateway_original_work_type": "integration",
                            "gateway_original_acceptance_criteria": tuple(objective.acceptance_criteria),
                            "autonomous_integration_gateway": True,
                        },
                    )
                    for objective in objectives
                )
                self._validate(objectives)
                completed = set(completed_objectives)
                repeated_completed = sorted(
                    objective.objective_id
                    for objective in objectives
                    if objective.objective_id in completed
                )
                if repeated_completed:
                    # Completed work is durable state, not a fresh planning
                    # target. Weak models sometimes echo a completed node even
                    # after it is supplied in completed_objectives. Drop those
                    # nodes before graph validation so a replan can continue
                    # with genuinely pending work without encoding task-specific
                    # knowledge in the planner.
                    objectives = tuple(
                        objective
                        for objective in objectives
                        if objective.objective_id not in completed
                    )
                    if not objectives:
                        # If the model can only echo completed work, preserve
                        # forward progress with one generic continuation node.
                        # The continuation is intentionally routed through the
                        # integration gateway; it must re-observe the current
                        # state and decide what, if anything, remains.
                        objectives = (
                            MissionObjective(
                                objective_id="mission_continuation",
                                objective=goal.strip(),
                                rationale="Continue from durable completed state and determine the remaining work needed to satisfy the mission.",
                                dependencies=(),
                                priority=100,
                                work_type="integration",
                                acceptance_criteria=(
                                    "Routed objective completed with verified evidence.",
                                ),
                                metadata={
                                    "autonomous_continuation": True,
                                    "repeated_completed_objectives": tuple(repeated_completed),
                                },
                            ),
                        )
                pending_ids = {objective.objective_id for objective in objectives}
                for objective in objectives:
                    unknown = set(objective.dependencies) - pending_ids - completed
                    if unknown:
                        raise ValueError(
                            f"objective {objective.objective_id!r} has unknown "
                            f"dependencies: {sorted(unknown)!r}"
                        )
                self._validate_acyclic(objectives, completed)
                self._validate_relevance(goal, objectives)
                break
            except ValueError as exc:
                if attempt == 1:
                    raise
                planning_feedback = (
                    *planning_feedback,
                    MissionObjectiveResult(
                        objective_id="planner_validation_feedback",
                        objective=goal,
                        status="rejected",
                        error=str(exc),
                        metadata={"planner_feedback": True},
                    ),
                )

        return MissionPlan(
            mission_id=mission_id,
            goal=goal,
            objectives=objectives,
            metadata={
                "planner": "strategic",
                "repository_grounded": True,
            },
        )

    @staticmethod
    def _validate_relevance(
        goal: str,
        objectives: Sequence[MissionObjective],
    ) -> None:
        """Reject obvious model hallucinations without encoding task semantics."""
        goal_tokens = set(re.findall(r"[a-z0-9][a-z0-9_-]{2,}", goal.lower()))
        if not goal_tokens:
            return

        # Keep relevance generic: require model objectives to retain multiple
        # meaningful anchors from the user's goal. This prevents repository
        # vocabulary from displacing the actual mission without maintaining a
        # task-specific allowlist.
        relevance_stopwords = {
            "about", "after", "allow", "also", "and", "anything", "as", "at",
            "available", "can", "complete", "determine", "do", "everything",
            "existing", "for", "from", "if", "into", "is", "it", "missing",
            "only", "public", "required", "should", "step", "that", "the", "then",
            "this", "to", "what", "when", "with", "without", "you",
        }
        meaningful_goal_tokens = {
            token for token in goal_tokens
            if len(token) >= 5 and token not in relevance_stopwords
        }

        for objective in objectives:
            if objective.objective_id == "planner_validation_feedback" or bool(getattr(objective, "metadata", {}).get("planner_feedback")):
                continue
            text = objective.objective.strip().lower()
            objective_tokens = set(re.findall(r"[a-z0-9][a-z0-9_-]{2,}", text))

            # Function-call fragments and raw repository paths are common signs
            # that a weak model has copied an implementation detail instead of
            # proposing an objective. Reject these before relevance matching:
            # sharing one word with the goal must never make executable syntax
            # acceptable.
            looks_like_function = bool(re.search(r"\b[a-z_][a-z0-9_.-]*\s*\([^)]*\)", text))
            looks_like_path = bool(
                re.search(r"(?:^|\s)(?:\.?\.?/)?[^\s]+/(?:[^\s]+/)*[^\s]+\.(?:py|ts|tsx|js|jsx|json|yaml|yml|md)(?:\s|$)", text)
            )
            looks_like_filename = bool(
                re.search(r"(?<![A-Za-z0-9_.-])[^\s/]+\.(?:py|ts|tsx|js|jsx|json|yaml|yml|md)(?![A-Za-z0-9_.-])", text)
            )
            if looks_like_function or looks_like_path or looks_like_filename:
                raise ValueError(
                    f"objective {objective.objective_id!r} is not grounded in the mission goal"
                )
            if len(objective_tokens) < 2:
                raise ValueError(
                    f"objective {objective.objective_id!r} is too vague to be an autonomous work statement"
                )
            if len(meaningful_goal_tokens) >= 3:
                semantic_text = " ".join((
                    objective.objective,
                    objective.rationale,
                    *objective.acceptance_criteria,
                )).lower()
                semantic_tokens = set(re.findall(r"[a-z0-9][a-z0-9_-]{2,}", semantic_text))
                anchors = meaningful_goal_tokens & semantic_tokens
                if len(anchors) < 2:
                    raise ValueError(
                        f"objective {objective.objective_id!r} is insufficiently anchored to the mission goal"
                    )

    @staticmethod
    def _validate(
        objectives: Sequence[MissionObjective],
    ) -> None:
        ids = [objective.objective_id for objective in objectives]

        if len(ids) != len(set(ids)):
            raise ValueError("mission plan contains duplicate objective ids")

        allowed_work_types = {
            "research",
            "design",
            "implementation",
            "testing",
            "integration",
            "verification",
            "browser",
            "computer",
        }

        for objective in objectives:
            if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,100}", objective.objective_id):
                raise ValueError(
                    f"objective {objective.objective_id!r} has an invalid identifier"
                )
            if re.search(r"(?<![A-Za-z0-9_.-])[^\s/]+\.(?:py|ts|tsx|js|jsx|json|yaml|yml|md)$", objective.objective_id):
                raise ValueError(
                    f"objective {objective.objective_id!r} looks like a repository filename, not a stable objective identifier"
                )
            if not objective.objective.strip():
                raise ValueError(
                    f"objective {objective.objective_id!r} is empty"
                )
            if objective.work_type not in allowed_work_types:
                raise ValueError(
                    f"objective {objective.objective_id!r} has unsupported "
                    f"work type {objective.work_type!r}"
                )
            if objective.metadata.get("autonomous_build") and not objective.acceptance_criteria:
                raise ValueError(
                    f"autonomous-build objective {objective.objective_id!r} "
                    "must define acceptance criteria"
                )
            if any(not dependency.strip() for dependency in objective.dependencies):
                raise ValueError(
                    f"objective {objective.objective_id!r} contains an empty "
                    "dependency"
                )
            if objective.objective_id in objective.dependencies:
                raise ValueError(
                    f"objective {objective.objective_id!r} depends on itself"
                )

    @staticmethod
    def _validate_acyclic(
        objectives: Sequence[MissionObjective],
        completed: set[str],
    ) -> None:
        dependencies = {
            objective.objective_id: set(objective.dependencies)
            for objective in objectives
        }
        visiting: set[str] = set()
        visited: set[str] = set()

        def visit(objective_id: str) -> None:
            if objective_id in completed:
                return
            if objective_id in visiting:
                raise ValueError("mission plan contains a dependency cycle")
            if objective_id in visited:
                return

            visiting.add(objective_id)
            for dependency in dependencies[objective_id]:
                visit(dependency)
            visiting.remove(objective_id)
            visited.add(objective_id)

        for objective_id in dependencies:
            visit(objective_id)


class MissionEngine:
    """Mission-level control plane above bounded objective execution."""

    # Reserved identifiers belong to the planner/control protocol itself and
    # can never become executable mission objectives, even if an untrusted
    # planner model echoes runtime feedback back into its proposed graph.
    _CONTROL_OBJECTIVE_IDS = frozenset({
        "planner_contract_gap",
        "planner_validation_feedback",
    })

    def __init__(
        self,
        *,
        planner: MissionPlanner,
        executor: MissionObjectiveExecutor,
        events: EventBus | None = None,
        max_concurrent_objectives: int = 16,
        objective_lease_seconds: float | None = None,
        execution_adapter: MissionObjectiveExecutionAdapter | None = None,
        max_lease_retries: int = 3,
        optimization: OptimizationFabric | None = None,
        budget_limits: Mapping[str, Mapping[str, float]] | None = None,
    ) -> None:
        if max_concurrent_objectives <= 0:
            raise ValueError("max_concurrent_objectives must be positive")
        if objective_lease_seconds is not None and objective_lease_seconds <= 0:
            raise ValueError("objective_lease_seconds must be positive when set")
        if max_lease_retries < 0:
            raise ValueError("max_lease_retries must be non-negative")
        self._planner = planner
        self._executor = executor
        self._execution_adapter = execution_adapter or LegacyMissionObjectiveExecutionAdapter(executor)
        self._events = events
        self._max_concurrent_objectives = max_concurrent_objectives
        self._intelligence = MissionIntelligenceRouter(max_parallelism=max_concurrent_objectives)
        self._dependency_recovery = DependencyRecovery(events=events)
        # None (the default) disables leasing entirely and preserves the
        # exact prior behavior (unbounded future.result()), so existing
        # callers/tests are unaffected unless they opt in.
        self._objective_lease_seconds = objective_lease_seconds
        self._max_lease_retries = max_lease_retries
        self._optimization = optimization or OptimizationFabric()
        self._budget_hierarchy = BudgetHierarchy(budget_limits or {})
        # Tracks the single currently-authoritative attempt per
        # (mission_id, objective_id). Guarded by _attempt_lock so a stale
        # worker thread's done-callback (running on a pool thread) and the
        # main control loop (which may start a superseding retry attempt)
        # never race on the same entry.
        self._current_attempt: dict[tuple[str, str], str] = {}
        self._attempt_lock = threading.Lock()
        # Tracks lease retry count per (mission_id, objective_id)
        self._lease_retry_count: dict[tuple[str, str], int] = {}

    def _set_current_attempt(self, mission_id: str, objective_id: str, attempt_id: str) -> None:
        with self._attempt_lock:
            self._current_attempt[(mission_id, objective_id)] = attempt_id

    def _make_stale_attempt_callback(self, mission_id: str, objective_id: str, attempt_id: str):
        """Build a future done-callback for an objective whose lease expired.

        If a retry has since superseded this attempt, any late result is
        durable evidence only -- it is never re-applied to mission state
        (no double ObjectiveCompleted, no double promotion). If no retry
        ever superseded it (e.g. the mission already reached a terminal
        replan/replan-limit state), there is nothing left to apply it to
        either; the synthetic "stale" result already drove control flow
        synchronously when the lease expired.
        """

        def _callback(future) -> None:
            with self._attempt_lock:
                current = self._current_attempt.get((mission_id, objective_id))
            superseded = current != attempt_id
            try:
                exc = future.exception()
            except Exception:
                exc = None
            if superseded:
                # The callback may run after the owning process has already
                # closed its event-store connection. A late worker result is
                # deliberately non-authoritative, so failure to persist this
                # best-effort telemetry must never surface as an unhandled
                # Future callback exception or corrupt mission shutdown.
                try:
                    self._publish(
                        "ObjectiveStaleAttemptDiscarded",
                        mission_id,
                        {
                            "mission_id": mission_id,
                            "objective_id": objective_id,
                            "attempt_id": attempt_id,
                            "superseding_attempt_id": current,
                            "late_result_error": str(exc) if exc else None,
                            "note": (
                                "stale worker eventually finished after its lease "
                                "expired and after a newer attempt superseded it; "
                                "the late result is recorded but was not applied"
                            ),
                        },
                    )
                except Exception:
                    # Best-effort late-result telemetry cannot be allowed to
                    # escape from a background callback, especially during
                    # process teardown when the event store may be closed.
                    return

        return _callback

    def _publish(
        self,
        event_type: str,
        mission_id: str,
        payload: dict[str, object],
    ) -> None:
        if self._events is None:
            return
        self._events.publish(
            Event(
                type=event_type,
                payload=payload,
                aggregate_type="mission",
                aggregate_id=mission_id,
                correlation_id=mission_id,
                source="mission_engine",
            )
        )

    def _dead_letter(self, mission_id: str, objective_id: str, *, reason: str, error: object, replans: int) -> None:
        """Persist terminal work that exhausted bounded recovery paths."""
        self._publish("MissionDeadLettered", mission_id, {
            "mission_id": mission_id,
            "objective_id": objective_id,
            "reason": reason,
            "error": error,
            "replans": replans,
            "recovery_required": True,
        })

    @staticmethod
    def _apply_contract_policy(
        plan: MissionPlan | None,
        contract: MissionContract,
        *,
        missing_work: Sequence[str] = (),
        covered_work: Sequence[str] = (),
    ) -> MissionPlan | None:
        if plan is None:
            return plan
        missing = tuple(dict.fromkeys(str(item).strip().lower() for item in missing_work if str(item).strip()))
        covered = tuple(dict.fromkeys(str(item).strip().lower() for item in covered_work if str(item).strip()))
        objectives = tuple(
            replace(
                objective,
                metadata={
                    **dict(objective.metadata),
                    "mission_mutation_policy": contract.mutation_policy,
                    "mission_required_work_types": tuple(contract.required_work_types),
                    "mission_missing_work_types": missing,
                    "mission_covered_work_types": covered,
                    "mission_contract_context": True,
                },
            )
            for objective in plan.objectives
        )
        return replace(plan, objectives=objectives)

    def _replan_limit_result(
        self,
        *,
        mission_id: str,
        goal: str,
        results: Sequence[MissionObjectiveResult],
        completed: Sequence[str],
        pending: Mapping[str, MissionObjective],
        metadata: Mapping[str, object],
    ) -> MissionResult:
        payload = {
            "mission_id": mission_id,
            "goal": goal,
            "error": str(metadata.get("failure_error") or metadata.get("reason") or "mission replanning limit reached"),
            **dict(metadata),
        }
        self._publish("MissionReplanLimitReached", mission_id, payload)
        return MissionResult(
            mission_id=mission_id,
            goal=goal,
            status="replan_limit_reached",
            objective_results=tuple(results),
            completed_objectives=tuple(completed),
            remaining_objectives=tuple(
                objective_id for objective_id in pending if objective_id not in completed
            ),
            metadata=dict(metadata),
        )

    def run(
        self,
        goal: str,
        *,
        mission_id: str | None = None,
        max_replans: int = 3,
        contract: MissionContract | None = None,
        cancelled: Callable[[], bool] | None = None,
    ) -> MissionResult:
        # The public mission boundary is fail-durable: an unexpected runtime
        # exception must become a persisted mission failure before it escapes.
        # Callers can then inspect the exact failure and resume from durable
        # history instead of seeing an unexplained STATUS UNKNOWN.
        if goal.strip() and max_replans >= 0:
            durable_mission_id = mission_id or new_id("mission")
            try:
                result = self._run(
                    goal,
                    mission_id=durable_mission_id,
                    max_replans=max_replans,
                    contract=contract,
                    cancelled=cancelled,
                )
                self._ensure_terminal_event(result)
                return result
            except Exception as exc:
                self._publish(
                    "MissionFailed",
                    durable_mission_id,
                    {
                        "mission_id": durable_mission_id,
                        "goal": goal,
                        "error": f"{type(exc).__name__}: {exc}",
                        "recoverable": True,
                        "reason": "unexpected mission runtime exception",
                    },
                )
                raise

        return self._run(
            goal,
            mission_id=mission_id,
            max_replans=max_replans,
            contract=contract,
            cancelled=cancelled,
        )

    def _ensure_terminal_event(self, result: MissionResult) -> None:
        """Persist a terminal lifecycle event for every returned mission result.

        MissionEngine has many bounded recovery branches. Historically some of
        them returned a MissionResult directly without emitting the matching
        terminal event, leaving the durable projector stuck on an earlier
        REPLANNING/RUNNING state after the worker had already exited. Keep the
        execution branches focused on control flow and enforce the lifecycle
        invariant once at the public boundary. Existing terminal events are
        detected so successful/failed paths that already publish one are not
        duplicated.
        """
        event_types = {
            "completed": "MissionCompleted",
            "failed": "MissionFailed",
            "blocked": "MissionBlocked",
            "blocked_pending_user": "MissionBlockedPendingUser",
            "paused": "MissionPaused",
            "cancelled": "MissionCancelled",
            "replan_limit_reached": "MissionReplanLimitReached",
            "replan_stagnated": "MissionReplanStagnated",
            "mission_contract_unsatisfied": "MissionContractUnsatisfied",
            "dead_lettered": "MissionDeadLettered",
        }
        event_type = event_types.get(result.status)
        if event_type is None or self._events is None:
            return
        getter = getattr(self._events, "list_by_mission_id", None)
        if callable(getter):
            events = getter(result.mission_id)
        else:
            events = tuple(
                event
                for event in self._events.history()
                if event.aggregate_id == result.mission_id
                or (isinstance(event.payload, Mapping) and event.payload.get("mission_id") == result.mission_id)
            )
        if any(event.type == event_type for event in events):
            return
        payload = {
            "mission_id": result.mission_id,
            "goal": result.goal,
            "status": result.status,
            "replans": result.metadata.get("replans"),
            "completed_objectives": list(result.completed_objectives),
            "remaining_objectives": list(result.remaining_objectives),
            **dict(result.metadata),
        }
        if result.status in {"failed", "blocked", "blocked_pending_user", "paused", "replan_stagnated", "mission_contract_unsatisfied"}:
            payload.setdefault("error", result.metadata.get("reason") or result.metadata.get("error") or result.status)
        self._publish(event_type, result.mission_id, payload)

    def _run(
        self,
        goal: str,
        *,
        mission_id: str | None = None,
        max_replans: int = 3,
        contract: MissionContract | None = None,
        cancelled: Callable[[], bool] | None = None,
    ) -> MissionResult:
        if not goal.strip():
            raise ValueError("mission goal must not be empty")
        if max_replans < 0:
            raise ValueError("max_replans must be non-negative")

        mission_id = mission_id or new_id("mission")
        contract = contract or MissionContract()

        def _cancelled() -> bool:
            try:
                return bool(cancelled and cancelled())
            except Exception:
                return True

        if _cancelled():
            self._publish("MissionCancelled", mission_id, {"mission_id": mission_id, "reason": "cancellation requested before execution"})
            return MissionResult(mission_id=mission_id, goal=goal, status="cancelled", objective_results=(), completed_objectives=(), remaining_objectives=(), metadata={"cancelled": True})
        completed: list[str] = []
        results: list[MissionObjectiveResult] = []
        replans = 0
        previous_plan: MissionPlan | None = None

        existing_events: Sequence[Event]
        if self._events is None:
            existing_events = ()
        else:
            # Prefer the event store's indexed mission query when available.
            # Replaying the entire global event log for every resume is an
            # O(total-history) operation and becomes a serious bottleneck for
            # long-lived LUMO installations. Fall back to the generic history
            # API for in-memory/event-bus implementations.
            mission_getter = getattr(self._events, "list_by_mission_id", None)
            if callable(mission_getter):
                existing_events = tuple(mission_getter(mission_id))
            else:
                history = self._events.history()
                existing_events = tuple(
                    event
                    for event in history
                    if event.aggregate_id == mission_id
                    or (
                        isinstance(event.payload, Mapping)
                        and event.payload.get("mission_id") == mission_id
                    )
                )
        mission_events = list(existing_events)
        # A continuation is a new conversational turn on the same durable mission.
        # It intentionally reopens the mission lifecycle without creating a new mission id.
        terminal_types = {
            "MissionCompleted",
            "MissionCancelled",
            "MissionFailed",
            "MissionBlocked",
            "MissionPaused",
            "MissionDeadLettered",
        }
        latest_terminal_index = max(
            (index for index, event in enumerate(mission_events) if event.type in terminal_types),
            default=-1,
        )
        continuation_pending = any(
            event.type == "MissionContinuationRequested"
            and index > latest_terminal_index
            and not any(
                applied.type == "MissionContinuationApplied"
                and applied.payload.get("continuation_id") == event.payload.get("continuation_id")
                for applied in mission_events[index + 1:]
            )
            for index, event in enumerate(mission_events)
        )
        # A strategic decomposition is expensive and must survive a process
        # restart. Reuse it until a terminal failure or an unsatisfied mission
        # contract genuinely requires a fresh proposal.
        active_plan = None if continuation_pending else self._apply_contract_policy(
            self._latest_persisted_plan(mission_events, mission_id, goal),
            contract,
            missing_work=contract.missing(results),
            covered_work=contract.coverage(results),
        )

        if mission_events:
            for event in mission_events:
                payload = event.payload or {}
                if event.type == "ObjectiveCompleted":
                    objective_id = payload.get("objective_id")
                    if objective_id and objective_id not in completed:
                        completed.append(str(objective_id))
                    if objective_id:
                        # Reconstruct metadata from event payload (includes work_type, verified, evidence)
                        metadata = dict(payload.get("metadata") or {})
                        if "work_type" in payload:
                            metadata["work_type"] = payload["work_type"]
                        if "verified" in payload:
                            metadata["verified"] = payload["verified"]
                        if "evidence" in payload:
                            metadata["evidence"] = payload["evidence"]
                        results.append(
                            MissionObjectiveResult(
                                objective_id=str(objective_id),
                                objective=str(payload.get("objective", "")),
                                status=str(payload.get("status", "completed")),
                                run_id=payload.get("run_id"),
                                candidate_id=payload.get("candidate_id"),
                                promoted_plan_revision_id=payload.get(
                                    "promoted_plan_revision_id"
                                ),
                                error=payload.get("error"),
                                metadata=metadata,
                            )
                        )
                elif event.type == "ObjectiveRejected":
                    objective_id = payload.get("objective_id")
                    if objective_id:
                        # Reconstruct metadata from event payload
                        metadata = dict(payload.get("metadata") or {})
                        if "work_type" in payload:
                            metadata["work_type"] = payload["work_type"]
                        results.append(
                            MissionObjectiveResult(
                                objective_id=str(objective_id),
                                objective=str(payload.get("objective", "")),
                                status=str(payload.get("status", "rejected")),
                                run_id=payload.get("run_id"),
                                candidate_id=payload.get("candidate_id"),
                                error=payload.get("error"),
                                metadata=metadata,
                            )
                        )
                elif event.type == "MissionReplanning":
                    replans = max(replans, int(payload.get("replans", 0)))

            if continuation_pending:
                # Prior lifecycle events remain durable history, but the new
                # conversational turn gets a fresh execution result.
                completed = []
                results = []

            if any(event.type == "MissionCompleted" for event in mission_events) and not continuation_pending:
                return MissionResult(
                    mission_id=mission_id,
                    goal=goal,
                    status="completed",
                    objective_results=tuple(results),
                    completed_objectives=tuple(completed),
                    remaining_objectives=(),
                    metadata={"replans": replans, "resumed": True},
                )

            if any(event.type == "MissionCancelled" for event in mission_events) and not continuation_pending:
                latest = next(
                    event for event in reversed(mission_events)
                    if event.type == "MissionCancelled"
                )
                return MissionResult(
                    mission_id=mission_id,
                    goal=goal,
                    status="cancelled",
                    objective_results=tuple(results),
                    completed_objectives=tuple(completed),
                    remaining_objectives=tuple(
                        objective.objective_id
                        for objective in (active_plan.objectives if active_plan else ())
                        if objective.objective_id not in completed
                    ),
                    metadata={
                        "replans": replans,
                        "resumed": True,
                        "cancelled": True,
                        "reason": latest.payload.get("reason"),
                    },
                )
        else:
            self._publish(
                "MissionStarted",
                mission_id,
                {
                    "mission_id": mission_id,
                    "goal": goal,
                    "max_replans": max_replans,
                },
            )

        first_plan = True
        plan_exhausted = True
        planner_exhausted = False
        while True:
            if _cancelled():
                self._publish("MissionCancelled", mission_id, {"mission_id": mission_id, "reason": "cancellation requested"})
                return MissionResult(mission_id=mission_id, goal=goal, status="cancelled", objective_results=tuple(results), completed_objectives=tuple(completed), remaining_objectives=(), metadata={"replans": replans, "cancelled": True})
            # Compute planning_goal at the top of the loop based on current results
            missing_work = contract.missing(results)
            planning_goal = goal
            if missing_work:
                planning_goal = (
                    f"{goal}\n\nMISSION CONTROL REQUIREMENT: The mission is not complete yet. "
                    f"Required outcome classes still missing: {', '.join(missing_work)}. "
                    "Prioritize objectives that produce these missing outcomes. "
                    "Do not generate another objective whose primary purpose is "
                    "an already-satisfied outcome class unless it is a prerequisite "
                    "for the missing outcomes."
                )

            # If we don't have an active plan, ask the planner for more work.
            # This happens on the first iteration (plan_exhausted=True) or after
            # a non-retryable failure that cleared active_plan.
            if active_plan is None and not planner_exhausted:
                plan_exhausted = False
                # Give the planner structured contract-gap feedback as well as
                # the human-readable planning goal. The feedback is runtime
                # state, not an instruction, so a weak model cannot mistake it
                # for repository content. This makes replanning outcome-aware
                # instead of relying on keyword interpretation alone.
                planner_results = tuple(results)
                if missing_work:
                    planner_results = (
                        *planner_results,
                        MissionObjectiveResult(
                            objective_id="planner_contract_gap",
                            objective=planning_goal,
                            status="planner_feedback",
                            metadata={
                                "planner_feedback": True,
                                "missing_work_types": tuple(missing_work),
                                "covered_work_types": tuple(sorted(contract.coverage(results))),
                            },
                        ),
                    )
                # Ask planner for next plan
                try:
                    try:
                        plan = self._planner.plan(
                            mission_id,
                            planning_goal,
                            completed_objectives=tuple(completed),
                            previous_results=planner_results,
                        )
                    except Exception as exc:
                        resource_block = self._resource_block_from_error(str(exc))
                        if resource_block:
                            self._publish("MissionPaused", mission_id, {
                                "mission_id": mission_id,
                                "reason": "waiting for human action",
                                "waiting_for_user": True,
                            })
                            self._publish("MissionBlockedPendingUser", mission_id, {
                                "mission_id": mission_id,
                                "goal": goal,
                                "reason": resource_block["action"],
                                "dependencies": [resource_block["name"]],
                                "resource_blocker": resource_block,
                            })
                            return MissionResult(
                                mission_id=mission_id,
                                goal=goal,
                                status="blocked_pending_user",
                                objective_results=tuple(results),
                                completed_objectives=tuple(completed),
                                remaining_objectives=tuple(pending) if 'pending' in locals() else (),
                                metadata={"replans": replans, "resource_blocker": resource_block},
                            )
                        raise
                except StopIteration:
                    planner_exhausted = True
                    # Planner has no more plans; check contract and complete
                    missing_work = contract.missing(results)
                    if not missing_work:
                        self._publish(
                            "MissionCompleted",
                            mission_id,
                            {
                                "mission_id": mission_id,
                                "goal": goal,
                                "completed_objectives": list(completed),
                                "replans": replans,
                                "contract_satisfied": True,
                                "covered_work_types": sorted(contract.coverage(results)),
                            },
                        )
                        return MissionResult(
                            mission_id=mission_id,
                            goal=goal,
                            status="completed",
                            objective_results=tuple(results),
                            completed_objectives=tuple(completed),
                            remaining_objectives=(),
                            metadata={
                                "replans": replans,
                                "contract_satisfied": True,
                                "covered_work_types": sorted(contract.coverage(results)),
                            },
                        )
                    if replans >= max_replans:
                        return MissionResult(
                            mission_id=mission_id,
                            goal=goal,
                            status="mission_contract_unsatisfied",
                            objective_results=tuple(results),
                            completed_objectives=tuple(completed),
                            remaining_objectives=(),
                            metadata={
                                "replans": replans,
                                "missing_work_types": list(missing_work),
                                "covered_work_types": sorted(contract.coverage(results)),
                            },
                        )
                    # Contract not satisfied but we have replans left
                    replans += 1
                    self._publish(
                        "MissionReplanning",
                        mission_id,
                        {
                            "mission_id": mission_id,
                            "goal": goal,
                            "replans": replans,
                            "reason": "mission contract has unsatisfied outcome classes",
                            "missing_work_types": list(missing_work),
                        },
                    )
                    active_plan = None
                    continue
                active_plan = self._apply_contract_policy(
                    plan,
                    contract,
                    missing_work=missing_work,
                    covered_work=contract.coverage(results),
                )
                self._publish(
                    "MissionPlanProposed",
                    mission_id,
                    self._plan_payload(plan),
                )
                # Planner returned a plan; check if it has pending work
                pending = {
                    objective.objective_id: objective
                    for objective in active_plan.objectives
                    if objective.objective_id not in completed
                    and objective.objective_id not in self._CONTROL_OBJECTIVE_IDS
                }
                if not pending:
                    # Planner returned no new work; check contract and complete
                    missing_work = contract.missing(results)
                    if not missing_work:
                        self._publish(
                            "MissionCompleted",
                            mission_id,
                            {
                                "mission_id": mission_id,
                                "goal": goal,
                                "completed_objectives": list(completed),
                                "replans": replans,
                                "contract_satisfied": True,
                                "covered_work_types": sorted(contract.coverage(results)),
                            },
                        )
                        return MissionResult(
                            mission_id=mission_id,
                            goal=goal,
                            status="completed",
                            objective_results=tuple(results),
                            completed_objectives=tuple(completed),
                            remaining_objectives=(),
                            metadata={
                                "replans": replans,
                                "contract_satisfied": True,
                                "covered_work_types": sorted(contract.coverage(results)),
                            },
                        )
                    if replans >= max_replans:
                        return MissionResult(
                            mission_id=mission_id,
                            goal=goal,
                            status="mission_contract_unsatisfied",
                            objective_results=tuple(results),
                            completed_objectives=tuple(completed),
                            remaining_objectives=(),
                            metadata={
                                "replans": replans,
                                "missing_work_types": list(missing_work),
                                "covered_work_types": sorted(contract.coverage(results)),
                            },
                        )
                    # Contract not satisfied but we have replans left
                    replans += 1
                    self._publish(
                        "MissionReplanning",
                        mission_id,
                        {
                            "mission_id": mission_id,
                            "goal": goal,
                            "replans": replans,
                            "reason": "mission contract has unsatisfied outcome classes",
                            "missing_work_types": list(missing_work),
                        },
                    )
                    active_plan = None
                    continue
                # Planner returned new work
                if not first_plan:
                    # This is a replan (not the first plan)
                    replans += 1
                    if replans > max_replans:
                        return self._replan_limit_result(
                            mission_id=mission_id,
                            goal=goal,
                            results=results,
                            completed=completed,
                            pending=pending,
                            metadata={
                                "replans": replans - 1,
                                "reason": "maximum replanning cycles reached after plan exhaustion",
                            },
                        )
                    self._publish(
                        "MissionReplanning",
                        mission_id,
                        {
                            "mission_id": mission_id,
                            "goal": goal,
                            "replans": replans,
                            "reason": (
                                "progress made; mission contract still requires further work"
                                if contract.required_work_types
                                else "progress made; checking whether the mission requires further work"
                            ),
                            **({"missing_work_types": list(missing_work)} if contract.required_work_types else {}),
                        },
                    )
                first_plan = False
                # Continue to normal execution flow with the new plan
                previous_plan = plan
            else:
                # If we have no active plan and planner is exhausted, the mission cannot proceed
                if active_plan is None:
                    if planner_exhausted:
                        missing_work = contract.missing(results)
                        return MissionResult(
                            mission_id=mission_id,
                            goal=goal,
                            status="mission_contract_unsatisfied",
                            objective_results=tuple(results),
                            completed_objectives=tuple(completed),
                            remaining_objectives=(),
                            metadata={
                                "replans": replans,
                                "missing_work_types": list(missing_work),
                                "covered_work_types": sorted(contract.coverage(results)),
                            },
                        )
                    continue
                self._publish(
                    "MissionPlanningStarted",
                    mission_id,
                    {
                        "mission_id": mission_id,
                        "goal": goal,
                        "replans": replans,
                    },
                )

            # active_plan is already set from the plan_exhausted block
            plan = active_plan
            previous_plan = plan

            pending = {
                objective.objective_id: objective
                for objective in plan.objectives
                if objective.objective_id not in completed
                and objective.objective_id not in self._CONTROL_OBJECTIVE_IDS
            }

            if not pending:
                missing_work = contract.missing(results)
                if not missing_work:
                    self._publish(
                        "MissionCompleted",
                        mission_id,
                        {
                            "mission_id": mission_id,
                            "goal": goal,
                            "completed_objectives": list(completed),
                            "replans": replans,
                            "contract_satisfied": True,
                            "covered_work_types": sorted(contract.coverage(results)),
                        },
                    )
                    return MissionResult(
                        mission_id=mission_id,
                        goal=goal,
                        status="completed",
                        objective_results=tuple(results),
                        completed_objectives=tuple(completed),
                        remaining_objectives=(),
                        metadata={
                            "replans": replans,
                            "contract_satisfied": True,
                            "covered_work_types": sorted(contract.coverage(results)),
                        },
                    )
                if replans >= max_replans:
                    return MissionResult(
                        mission_id=mission_id,
                        goal=goal,
                        status="mission_contract_unsatisfied",
                        objective_results=tuple(results),
                        completed_objectives=tuple(completed),
                        remaining_objectives=(),
                        metadata={
                            "replans": replans,
                            "missing_work_types": list(missing_work),
                            "covered_work_types": sorted(contract.coverage(results)),
                        },
                    )
                # Contract not satisfied but we have replans left.
                replans += 1
                self._publish(
                    "MissionReplanning",
                    mission_id,
                    {
                        "mission_id": mission_id,
                        "goal": goal,
                        "replans": replans,
                        "reason": "mission contract has unsatisfied outcome classes",
                        "missing_work_types": list(missing_work),
                    },
                )
                active_plan = None
                plan_exhausted = True
                continue

            ready = self._ready_objectives(pending, completed)
            if not ready:
                self._publish(
                    "MissionBlocked",
                    mission_id,
                    {
                        "mission_id": mission_id,
                        "goal": goal,
                        "error": "no objective is dependency-ready",
                        "remaining_objectives": list(pending),
                    },
                )
                return MissionResult(
                    mission_id=mission_id,
                    goal=goal,
                    status="blocked",
                    objective_results=tuple(results),
                    completed_objectives=tuple(completed),
                    remaining_objectives=tuple(pending),
                    metadata={
                        "replans": replans,
                        "reason": "no objective is dependency-ready",
                    },
                )

            # Successful objectives are already protected by resolved_ids;
            # feeding every historical success into the semantic-stagnation scan
            # creates O(n²) work on gargantuan DAGs and can incorrectly suppress
            # legitimate follow-on work. Stagnation is specifically about
            # repeatedly proposing work that has already been rejected.
            failed_objectives = tuple(
                result.objective
                for result in results
                if result.status not in {"promoted", "completed", "success"}
                and result.metadata.get("retryable") is not True
                and result.objective.strip()
            )
            prior_objectives = failed_objectives
            completed_objective_texts = {
                self._normalize_objective(result.objective)
                for result in results
                if result.status in {"promoted", "completed", "success"}
                and result.objective.strip()
            }
            # Build a lightweight inverted index so semantic stagnation only
            # compares against successful objectives sharing rare meaningful
            # terms. This preserves duplicate detection without scanning every
            # historical success for every ready objective.
            completed_semantic_index: dict[str, set[str]] = {}
            for text in completed_objective_texts:
                for token in self._meaningful_tokens(text):
                    completed_semantic_index.setdefault(token, set()).add(text)

            resolved_ids = {
                result.objective_id
                for result in results
                if result.status in {"promoted", "completed", "success"}
            }

            novel_ready = tuple(
                objective
                for objective in ready
                if objective.objective_id not in resolved_ids
                and self._normalize_objective(objective.objective) not in completed_objective_texts
                and not self._is_stagnant_objective(
                    objective.objective,
                    prior_objectives
                    + self._semantic_stagnation_candidates(
                        objective.objective,
                        completed_semantic_index,
                    ),
                )
            )

            if not novel_ready:
                missing_work = contract.missing(results)
                error = (
                    "planner produced no novel objective; mission contract remains "
                    f"unsatisfied for: {', '.join(missing_work) or 'none'}"
                )
                self._publish(
                    "MissionReplanStagnated",
                    mission_id,
                    {
                        "mission_id": mission_id,
                        "goal": goal,
                        "replans": replans,
                        "rejected_objectives": list(failed_objectives),
                        "error": error,
                    },
                )
                return MissionResult(
                    mission_id=mission_id,
                    goal=goal,
                    status=(
                        "mission_contract_unsatisfied"
                        if missing_work
                        else "replan_stagnated"
                    ),
                    objective_results=tuple(results),
                    completed_objectives=tuple(completed),
                    remaining_objectives=tuple(
                        objective_id
                        for objective_id in pending
                        if objective_id not in completed
                    ),
                    metadata={
                        "replans": replans,
                        "reason": error,
                        "rejected_objectives": failed_objectives,
                        "missing_work_types": list(missing_work),
                        "covered_work_types": sorted(contract.coverage(results)),
                    },
                )

            # Resolve predictable environment blockers before spending model/tool calls.
            # Missing developer tools become explicit user-action alerts; the mission can
            # later be resumed from the durable plan after the dependency is installed.
            blocked_dependencies: list[tuple[MissionObjective, tuple[DependencyRequirement, ...]]] = []
            for objective in novel_ready:
                requirements = self._dependency_requirements(objective)
                missing = self._dependency_recovery.inspect(requirements)
                if missing:
                    blocked_dependencies.append((objective, missing))
                    self._dependency_recovery.recover(mission_id, missing)
            if blocked_dependencies:
                blocked_ids = [objective.objective_id for objective, _ in blocked_dependencies]
                self._publish("MissionPaused", mission_id, {
                    "mission_id": mission_id,
                    "reason": "waiting for human action",
                    "waiting_for_user": True,
                })
                self._publish("MissionBlockedPendingUser", mission_id, {
                    "mission_id": mission_id, "goal": goal, "objective_ids": blocked_ids,
                    "reason": "required execution dependencies are missing",
                    "dependencies": [req.name for _, reqs in blocked_dependencies for req in reqs],
                })
                return MissionResult(
                    mission_id=mission_id, goal=goal, status="blocked_pending_user",
                    objective_results=tuple(results), completed_objectives=tuple(completed),
                    remaining_objectives=tuple(pending), metadata={
                        "replans": replans, "blocked_objectives": blocked_ids,
                        "reason": "required execution dependencies are missing; resolve user alerts and resume",
                    },
                )

            progress = False

            attempt_ids: dict[str, str] = {}
            for objective in novel_ready:
                attempt_id = new_id("attempt")
                attempt_ids[objective.objective_id] = attempt_id
                self._set_current_attempt(mission_id, objective.objective_id, attempt_id)
                self._publish(
                    "AgentAssigned", mission_id, {"mission_id": mission_id, "agent_id": f"agent_{objective.objective_id}", "objective_id": objective.objective_id, "status": "assigned"},
                )
                self._publish(
                    "AgentStarted", mission_id, {"mission_id": mission_id, "agent_id": f"agent_{objective.objective_id}", "objective_id": objective.objective_id, "status": "running", "activity": objective.objective},
                )
                self._publish(
                    "ObjectiveStarted",
                    mission_id,
                    {
                        "mission_id": mission_id,
                        "objective_id": objective.objective_id,
                        "objective": objective.objective,
                        "status": "running",
                        "work_type": objective.work_type,
                        "acceptance_criteria": list(objective.acceptance_criteria),
                        "attempt_id": attempt_id,
                    },
                )
                if self._objective_lease_seconds is not None:
                    self._publish(
                        "ObjectiveLeaseAcquired",
                        mission_id,
                        {
                            "mission_id": mission_id,
                            "objective_id": objective.objective_id,
                            "attempt_id": attempt_id,
                            "lease_seconds": self._objective_lease_seconds,
                        },
                    )

            lease_deadline = (
                time.monotonic() + self._objective_lease_seconds
                if self._objective_lease_seconds is not None
                else None
            )

            batch_cancel = threading.Event()

            def execute_objective(objective: MissionObjective) -> MissionObjectiveResult:
                if _cancelled():
                    return MissionObjectiveResult(objective_id=objective.objective_id, objective=objective.objective, status="cancelled", error="mission cancellation requested", metadata={"cancelled": True})
                started_at = time.monotonic()
                reservation = ()
                estimated_budget = dict(objective.metadata.get("estimated_budget", {}) or {})
                if not estimated_budget and objective.metadata.get("estimated_cost") is not None:
                    estimated_budget = {"money": float(objective.metadata.get("estimated_cost", 0.0) or 0.0)}
                if estimated_budget:
                    scopes = ["global", f"mission:{mission_id}", f"objective:{objective.objective_id}"]
                    reservation = self._budget_hierarchy.reserve(scopes, estimated_budget, attempt_ids[objective.objective_id])
                    self._publish("ObjectiveBudgetReserved", mission_id, {"mission_id": mission_id, "objective_id": objective.objective_id, "attempt_id": attempt_ids[objective.objective_id], "budget": estimated_budget})
                try:
                    result = self._execution_adapter.execute(
                        mission_id,
                        objective,
                        MissionObjectiveExecution(
                            attempt_id=attempt_ids[objective.objective_id],
                            lease_seconds=self._objective_lease_seconds,
                            deadline=lease_deadline,
                            batch_cancel=batch_cancel,
                        ),
                    )
                except Exception:
                    if reservation:
                        self._budget_hierarchy.release(reservation)
                    latency_ms = (time.monotonic() - started_at) * 1000.0
                    self._optimization.performance.record(f"objective:{objective.objective_id}", latency_ms, False)
                    raise
                latency_ms = (time.monotonic() - started_at) * 1000.0
                metadata = dict(result.metadata)
                estimated_cost = float(metadata.get("estimated_cost", 0.0) or 0.0)
                actual_cost = float(metadata.get("actual_cost", estimated_cost) or 0.0)
                verified = result.status in {"promoted", "completed", "success"}
                self._optimization.postflight(f"objective:{objective.objective_id}", estimated_cost, actual_cost, latency_ms, verified)
                metadata.update({"latency_ms": latency_ms, "estimated_cost": estimated_cost, "actual_cost": actual_cost, "cost_variance": actual_cost-estimated_cost, "verification_required": True})
                if reservation:
                    actual_budget = dict(metadata.get("actual_budget", {}) or {})
                    if not actual_budget:
                        actual_budget = dict(estimated_budget)
                        if "money" in actual_budget:
                            actual_budget["money"] = actual_cost
                    self._budget_hierarchy.commit(reservation, actual_budget)
                    self._publish("ObjectiveBudgetCommitted", mission_id, {"mission_id": mission_id, "objective_id": objective.objective_id, "attempt_id": attempt_ids[objective.objective_id], "budget": actual_budget})
                return replace(result, metadata=metadata)

            # A worker (thread) can remain technically alive -- e.g. blocked
            # in an untrusted model call or a hung subprocess wait -- without
            # ever returning. Waiting on future.result() with no timeout
            # would let one stuck objective block the entire mission
            # forever, with no way to detect or recover from it. When a
            # bounded lease is configured we stop waiting at the lease
            # deadline and treat the objective as stale/retryable instead,
            # while durably recording what happened. We intentionally do not
            # call pool.shutdown(wait=True) (which the `with` form performs
            # implicitly): CPython cannot forcibly kill a running thread, so
            # a genuinely hung worker thread will keep running in the
            # background even after we stop waiting on it. That thread is
            # leaked, not corrected -- see _make_stale_attempt_callback for
            # how a late/superseded result from it is safely discarded
            # rather than double-applied.
            intelligence = self._intelligence.decide(
                goal, ready_count=len(novel_ready), total_count=len(pending),
                failures=sum(1 for r in results if r.status not in {"promoted", "completed", "success"}),
            )
            self._publish(
                "MissionExecutionStrategySelected",
                mission_id,
                {
                    "mission_id": mission_id,
                    "goal": goal,
                    "cognition_mode": intelligence.cognition.mode.value,
                    "cognition_effort": intelligence.cognition.effort,
                    "orchestration_mode": intelligence.orchestration.value,
                    "autonomous_swarm": intelligence.autonomous_swarm,
                    "parallelism": intelligence.max_parallelism,
                    "reason": intelligence.reason,
                },
            )
            pool = ThreadPoolExecutor(
                max_workers=min(intelligence.max_parallelism, len(novel_ready)),
                thread_name_prefix="lumo-objective",
            )
            try:
                future_to_objective = {
                    pool.submit(execute_objective, objective): objective
                    for objective in novel_ready
                }

                execution_results_by_id: dict[str, MissionObjectiveResult] = {}
                pending_futures = set(future_to_objective)
                batch_deadline = (
                    time.monotonic() + self._objective_lease_seconds
                    if self._objective_lease_seconds is not None
                    else None
                )
                while pending_futures:
                    if _cancelled():
                        # Cancellation is a control-plane event: do not wait for
                        # arbitrary adapter/model calls to return. Signal every
                        # running adapter and discard every unfinished future.
                        batch_cancel.set()
                        for future in pending_futures:
                            future.cancel()
                        for future in pending_futures:
                            objective = future_to_objective[future]
                            execution_results_by_id[objective.objective_id] = MissionObjectiveResult(
                                objective_id=objective.objective_id,
                                objective=objective.objective,
                                status="cancelled",
                                error="mission cancellation requested",
                                metadata={
                                    "cancelled": True,
                                    "attempt_id": attempt_ids[objective.objective_id],
                                    "work_type": objective.work_type,
                                },
                            )
                        pending_futures.clear()
                        break

                    timeout = 0.05
                    if batch_deadline is not None:
                        remaining = batch_deadline - time.monotonic()
                        if remaining <= 0:
                            timeout = 0
                        else:
                            timeout = min(timeout, remaining)
                    done, _ = wait(
                        pending_futures,
                        timeout=timeout,
                        return_when=FIRST_COMPLETED,
                    )

                    if not done:
                        if batch_deadline is not None and time.monotonic() >= batch_deadline:
                            batch_cancel.set()
                            for future in pending_futures:
                                future.cancel()
                                objective = future_to_objective[future]
                                attempt_id = attempt_ids[objective.objective_id]
                                self._publish(
                                    "ObjectiveLeaseExpired",
                                    mission_id,
                                    {
                                        "mission_id": mission_id,
                                        "objective_id": objective.objective_id,
                                        "attempt_id": attempt_id,
                                        "lease_seconds": self._objective_lease_seconds,
                                    },
                                )
                                execution_results_by_id[objective.objective_id] = MissionObjectiveResult(
                                    objective_id=objective.objective_id,
                                    objective=objective.objective,
                                    status="stale",
                                    metadata={
                                        "retryable": True,
                                        "stale": True,
                                        "lease_expiry_event_published": True,
                                        "attempt_id": attempt_id,
                                        "work_type": objective.work_type,
                                    },
                                    error=(
                                        f"objective exceeded lease of {self._objective_lease_seconds}s "
                                        "while the worker remained alive; treating as stale and retrying"
                                    ),
                                )
                                future.add_done_callback(
                                    self._make_stale_attempt_callback(
                                        mission_id, objective.objective_id, attempt_id
                                    )
                                )
                            pending_futures.clear()
                        continue

                    for future in done:
                        pending_futures.discard(future)
                        objective = future_to_objective[future]
                        try:
                            result = future.result()
                        except Exception as exc:
                            result = MissionObjectiveResult(
                                objective_id=objective.objective_id,
                                objective=objective.objective,
                                status="stale",
                                metadata={
                                    "retryable": True,
                                    "stale": True,
                                    "attempt_id": attempt_ids[objective.objective_id],
                                    "work_type": objective.work_type,
                                },
                                error=f"adapter raised {type(exc).__name__}: {exc}",
                            )
                        execution_results_by_id[objective.objective_id] = result

                execution_results = tuple(
                    execution_results_by_id[objective.objective_id]
                    for objective in novel_ready
                )
                if any(result.status == "cancelled" for result in execution_results):
                    results.extend(execution_results)
                    self._publish(
                        "MissionCancelled",
                        mission_id,
                        {
                            "mission_id": mission_id,
                            "reason": "cancellation requested during objective execution",
                        },
                    )
                    return MissionResult(
                        mission_id=mission_id,
                        goal=goal,
                        status="cancelled",
                        objective_results=tuple(results),
                        completed_objectives=tuple(completed),
                        remaining_objectives=tuple(
                            objective_id for objective_id in pending
                            if objective_id not in completed
                        ),
                        metadata={"replans": replans, "cancelled": True},
                    )
            finally:
                # Signal that the MissionEngine has moved on from this batch.
                # Orphaned adapter threads must not dispatch new work after
                # the engine has stopped waiting for their results.
                batch_cancel.set()
                # Never block mission control flow on a stale worker thread.
                # Completed/live futures are already done or will finish on
                # their own; we simply stop waiting here.
                pool.shutdown(wait=False)

            retry_required = False
            retry_objective: MissionObjective | None = None
            retry_result: MissionObjectiveResult | None = None

            for objective, result in zip(novel_ready, execution_results):
                if (
                    result.metadata.get("stale") is True
                    and result.metadata.get("lease_expiry_event_published") is not True
                ):
                    self._publish(
                        "ObjectiveLeaseExpired",
                        mission_id,
                        {
                            "mission_id": mission_id,
                            "objective_id": objective.objective_id,
                            "attempt_id": attempt_ids[objective.objective_id],
                            "lease_seconds": self._objective_lease_seconds,
                        },
                    )

                if (
                    objective.metadata.get("autonomous_build")
                    and result.status in {"promoted", "completed", "success"}
                    and (
                        result.metadata.get("verified") is not True
                        or not result.metadata.get("evidence")
                    )
                ):
                    result = replace(
                        result,
                        status="rejected",
                        error=(
                            "autonomous-build objective cannot complete without "
                            "explicit verification evidence"
                        ),
                    )

                if (
                    objective.acceptance_criteria
                    and result.status in {"promoted", "completed", "success"}
                ):
                    unmet = self._unmet_acceptance_criteria(
                        objective.acceptance_criteria,
                        result,
                    )
                    if unmet:
                        result = replace(
                            result,
                            status="rejected",
                            error=(
                                "acceptance criteria not satisfied: "
                                + "; ".join(unmet)
                            ),
                        )

                if result.metadata.get("work_type") != objective.work_type:
                    result = replace(
                        result,
                        metadata={**dict(result.metadata), "work_type": objective.work_type},
                    )
                # A failed tool call can reveal a dependency the planner could not
                # know in advance. Turn common environment failures into a durable
                # user-action alert instead of blindly replanning the same work.
                discovered = self._dependencies_from_error(result.error or "")
                resource_block = self._resource_block_from_error(result.error or "")
                if discovered or resource_block:
                    if discovered:
                        self._dependency_recovery.recover(mission_id, discovered)
                    blocker_names = [req.name for req in discovered]
                    if resource_block:
                        blocker_names.append(resource_block["name"])
                    result = replace(
                        result,
                        metadata={
                            **dict(result.metadata),
                            "user_action_required": True,
                            "retryable": False,
                            "missing_dependencies": blocker_names,
                            **({"resource_blocker": resource_block} if resource_block else {}),
                        },
                        error=(
                            result.error + " | " + resource_block["action"]
                            if resource_block and result.error
                            else (resource_block["action"] if resource_block else result.error)
                        ),
                    )
                results.append(result)

                if result.metadata.get("user_action_required") is True:
                    self._publish("MissionPaused", mission_id, {
                        "mission_id": mission_id,
                        "reason": "waiting for human action",
                        "waiting_for_user": True,
                    })
                    self._publish("MissionBlockedPendingUser", mission_id, {
                        "mission_id": mission_id, "goal": goal,
                        "objective_id": objective.objective_id,
                        "reason": result.error or "user action required",
                        "dependencies": list(result.metadata.get("missing_dependencies", ())),
                    })
                    return MissionResult(
                        mission_id=mission_id, goal=goal, status="blocked_pending_user",
                        objective_results=tuple(results), completed_objectives=tuple(completed),
                        remaining_objectives=tuple(objective_id for objective_id in pending if objective_id not in completed),
                        metadata={"replans": replans, "blocked_objective": objective.objective_id, "reason": "user action required"},
                    )

                if result.status in {"promoted", "completed", "success"}:
                    completed.append(objective.objective_id)
                    # Reset lease retry count on successful completion
                    lease_key = (mission_id, objective.objective_id)
                    self._lease_retry_count.pop(lease_key, None)
                    progress = True
                    self._publish(
                        "AgentCompleted", mission_id, {"mission_id": mission_id, "agent_id": f"agent_{objective.objective_id}", "objective_id": objective.objective_id, "status": "completed", "activity": objective.objective, "verified": result.metadata.get("verified", False), "evidence": list(result.metadata.get("evidence", ()))},
                    )
                    self._publish(
                        "ObjectiveCompleted",
                        mission_id,
                        {
                            "mission_id": mission_id,
                            "objective_id": objective.objective_id,
                            "objective": objective.objective,
                            "status": result.status,
                            "run_id": result.run_id,
                            "candidate_id": result.candidate_id,
                            "promoted_plan_revision_id": result.promoted_plan_revision_id,
                            "work_type": result.metadata.get("work_type"),
                            "verified": result.metadata.get("verified", False),
                            "evidence": list(result.metadata.get("evidence", ())),
                            "metadata": dict(result.metadata),
                        },
                    )
                    continue

                self._publish(
                    "AgentFailed", mission_id, {"mission_id": mission_id, "agent_id": f"agent_{objective.objective_id}", "objective_id": objective.objective_id, "status": "failed", "activity": objective.objective, "error": result.error},
                )
                self._publish(
                    "ObjectiveRejected",
                    mission_id,
                    {
                        "mission_id": mission_id,
                        "objective_id": objective.objective_id,
                        "objective": objective.objective,
                        "status": result.status,
                        "error": result.error,
                        "run_id": result.run_id,
                        "candidate_id": result.candidate_id,
                        "metadata": dict(result.metadata),
                    },
                )
                if retry_objective is None:
                    retry_objective = objective
                    retry_result = result
                    retry_required = True

            if retry_required and retry_objective is not None and retry_result is not None:
                is_lease_expiry = retry_result.metadata.get("lease_expiry_event_published") is True
                is_retryable = retry_result.metadata.get("retryable") is True
                if is_lease_expiry:
                    lease_key = (mission_id, retry_objective.objective_id)
                    lease_retries = self._lease_retry_count.get(lease_key, 0)
                    if lease_retries >= self._max_lease_retries:
                        return self._replan_limit_result(
                            mission_id=mission_id,
                            goal=goal,
                            results=results,
                            completed=completed,
                            pending=pending,
                            metadata={
                                "replans": replans,
                                "failed_objective": retry_objective.objective_id,
                                "failure_error": retry_result.error,
                                "reason": f"max lease retries ({self._max_lease_retries}) exceeded",
                            },
                        )
                    self._dead_letter(mission_id, retry_objective.objective_id, reason=f"max lease retries ({self._max_lease_retries}) exceeded", error=retry_result.error, replans=replans)
                    self._lease_retry_count[lease_key] = lease_retries + 1
                elif is_retryable:
                    # Retryable failure (non-lease-expiry): check replan limit and increment replans
                    if replans >= max_replans:
                        return self._replan_limit_result(
                            mission_id=mission_id,
                            goal=goal,
                            results=results,
                            completed=completed,
                            pending=pending,
                            metadata={
                                "replans": replans,
                                "failed_objective": retry_objective.objective_id,
                                "failure_error": retry_result.error,
                            },
                        )
                    self._dead_letter(mission_id, retry_objective.objective_id, reason="maximum replans exceeded", error=retry_result.error, replans=replans)
                    replans += 1
                else:
                    # Non-retryable failure: trigger replan or hit limit
                    if replans >= max_replans:
                        return self._replan_limit_result(
                            mission_id=mission_id,
                            goal=goal,
                            results=results,
                            completed=completed,
                            pending=pending,
                            metadata={
                                "replans": replans,
                                "failed_objective": retry_objective.objective_id,
                                "failure_error": retry_result.error,
                            },
                        )
                    self._dead_letter(mission_id, retry_objective.objective_id, reason="maximum replans exceeded", error=retry_result.error, replans=replans)
                    replans += 1
                # For retryable failures (including lease expiry), we retry the same objective
                # by NOT clearing active_plan. For non-retryable failures, we clear active_plan to trigger replan.
                if not is_retryable:
                    active_plan = None
                    plan_exhausted = True
                self._publish(
                    (
                        "MissionRetryScheduled"
                        if is_retryable
                        else "MissionReplanning"
                    ),
                    mission_id,
                    {
                        "mission_id": mission_id,
                        "goal": goal,
                        "replans": replans,
                        "failed_objective_id": retry_objective.objective_id,
                        "error": retry_result.error,
                    },
                )
                continue

            if progress:
                missing_work = contract.missing(results)
                if contract.required_work_types and not missing_work:
                    self._publish(
                        "MissionCompleted",
                        mission_id,
                        {
                            "mission_id": mission_id,
                            "goal": goal,
                            "completed_objectives": list(completed),
                            "replans": replans,
                            "contract_satisfied": True,
                            "covered_work_types": sorted(contract.coverage(results)),
                        },
                    )
                    return MissionResult(
                        mission_id=mission_id,
                        goal=goal,
                        status="completed",
                        objective_results=tuple(results),
                        completed_objectives=tuple(completed),
                        remaining_objectives=(),
                        metadata={
                            "replans": replans,
                            "contract_satisfied": True,
                            "covered_work_types": sorted(contract.coverage(results)),
                        },
                    )

                # Advance known dependency frontiers locally. This avoids a
                # redundant strategic/model call after every prerequisite.
                if any(
                    objective.objective_id not in completed
                    for objective in plan.objectives
                ):
                    self._publish(
                        "MissionPlanContinued",
                        mission_id,
                        {
                            "mission_id": mission_id,
                            "completed_objectives": list(completed),
                            "replans": replans,
                        },
                    )
                    continue

                # All objectives in the plan are completed.
                # Signal plan exhaustion; the next loop iteration will ask the planner
                # for more work. If the planner returns an empty plan, the "if not pending:"
                # block above will complete the mission. If it returns more work, we'll
                # increment replans at the top of the loop.
                plan_exhausted = True
                active_plan = None
                continue

            if replans >= max_replans:
                return self._replan_limit_result(
                    mission_id=mission_id,
                    goal=goal,
                    results=results,
                    completed=completed,
                    pending=pending,
                    metadata={"replans": replans},
                )

    @staticmethod
    def _dependencies_from_error(error: str) -> tuple[DependencyRequirement, ...]:
        text = error.lower()
        found: list[DependencyRequirement] = []
        if "code: command not found" in text or "visual studio code" in text or "vs code" in text:
            found.append(DependencyRequirement("Visual Studio Code", command="code", auto_install=True, rationale="the execution environment is missing the requested editor"))
        if "node: command not found" in text:
            found.append(DependencyRequirement("Node.js", command="node", auto_install=False, install_hint="Install Node.js and resume the mission."))
        if "git: command not found" in text:
            found.append(DependencyRequirement("Git", command="git", auto_install=False, install_hint="Install Git and resume the mission."))
        return tuple(found)

    @staticmethod
    def _resource_block_from_error(error: str) -> dict[str, str] | None:
        """Turn live AI-memory admission failures into a recoverable user state."""
        text = error.strip()
        lower = text.lower()
        if "refusing to load it" not in lower or "safe" not in lower or "runtime headroom" not in lower:
            return None
        match = re.search(
            r"needs about\s+([0-9.]+)\s+gib runtime headroom, but only\s+([0-9.]+)\s+gib is currently safe",
            text,
            re.IGNORECASE,
        )
        if match:
            required, safe = match.groups()
            action = (
                f"Local AI is temporarily blocked by RAM pressure: it needs about {required} GiB "
                f"of runtime headroom but only {safe} GiB is currently safe. Close or pause "
                f"resource-heavy applications, or choose a lower-resource mode, then resume the mission."
            )
        else:
            action = (
                "Local AI is temporarily blocked by current RAM pressure. Close or pause "
                "resource-heavy applications, or choose a lower-resource mode, then resume the mission."
            )
        return {
            "name": "sufficient RAM for local AI",
            "required_gib": match.group(1) if match else "",
            "safe_gib": match.group(2) if match else "",
            "action": action,
        }

    @staticmethod
    def _dependency_requirements(objective: MissionObjective) -> tuple[DependencyRequirement, ...]:
        metadata = dict(objective.metadata or {})
        raw = metadata.get("dependencies") or metadata.get("required_tools") or ()
        requirements: list[DependencyRequirement] = []
        if isinstance(raw, (list, tuple)):
            for item in raw:
                if isinstance(item, str):
                    requirements.append(DependencyRequirement(item, command=item.lower().replace(" ", "-")))
                elif isinstance(item, dict) and item.get("name"):
                    requirements.append(DependencyRequirement(
                        str(item["name"]), str(item.get("command")) if item.get("command") else None,
                        str(item.get("install_hint")) if item.get("install_hint") else None,
                        bool(item.get("auto_install", False)), str(item.get("rationale", "")),
                    ))
        text = objective.objective.lower()
        if any(token in text for token in ("vs code", "visual studio code", "in vscode", "in vs code")):
            requirements.append(DependencyRequirement(
                "Visual Studio Code", command="code", auto_install=True,
                rationale="the requested coding workflow explicitly requires VS Code",
            ))
        return tuple({req.name.lower(): req for req in requirements}.values())

    @staticmethod
    def _normalize_objective(text: str) -> str:
        return re.sub(r"\s+", " ", text.strip().lower())

    _STOP_WORDS = frozenset(
        {"a", "an", "the", "to", "of", "in", "for", "and", "or", "is", "on", "at", "by", "with", "from"}
    )

    @classmethod
    def _meaningful_tokens(cls, text: str) -> frozenset[str]:
        tokens: set[str] = set()
        for word in text.split():
            cleaned = re.sub(r"[^a-z0-9]", "", word)
            if len(cleaned) >= 2 and cleaned not in cls._STOP_WORDS:
                tokens.add(cleaned)
        return frozenset(tokens)

    @classmethod
    def _semantic_stagnation_candidates(
        cls,
        objective: str,
        index: Mapping[str, set[str]],
    ) -> tuple[str, ...]:
        """Return a bounded set of successful objectives for semantic comparison."""
        tokens = cls._meaningful_tokens(cls._normalize_objective(objective))
        if not tokens:
            return ()
        ranked = sorted(tokens, key=lambda token: len(index.get(token, ())))
        selected: set[str] = set()
        for token in ranked[:2]:
            selected.update(index.get(token, ()))
        return tuple(selected)

    @classmethod
    def _is_stagnant_objective(
        cls,
        objective: str,
        rejected_objectives: Sequence[str],
    ) -> bool:
        candidate = cls._normalize_objective(objective)
        if not candidate:
            return True

        candidate_tokens = cls._meaningful_tokens(candidate)

        for rejected in rejected_objectives:
            previous = cls._normalize_objective(rejected)
            if not previous:
                continue

            if candidate == previous:
                return True

            # Structured identifiers commonly differ only by a numeric suffix
            # (for example "objective 10" vs "objective 1"). Treat those as
            # distinct work before applying substring similarity, otherwise the
            # shorter identifier can incorrectly match the longer one.
            candidate_numbers = set(re.findall(r"\d+", candidate))
            previous_numbers = set(re.findall(r"\d+", previous))
            if candidate_numbers and previous_numbers and candidate_numbers != previous_numbers:
                continue

            if candidate in previous or previous in candidate:
                return True

            previous_tokens = cls._meaningful_tokens(previous)

            # Require at least two shared lexical tokens before declaring
            # semantically similar objectives stagnant. This prevents generic
            # words such as "task" from making distinct objectives like
            # "Task A" and "Task B" collide, while still catching meaningful
            # repetitions such as "Audit the repository" versus "Perform
            # another repository audit".
            intersection = candidate_tokens & previous_tokens
            shorter_count = min(len(candidate_tokens), len(previous_tokens))
            if len(intersection) >= 2 and shorter_count and len(intersection) / shorter_count >= 0.6:
                return True

        return False

    @staticmethod
    def _is_duplicate_objective_id(
        objective_id: str,
        resolved_ids: set[str],
    ) -> bool:
        return objective_id in resolved_ids

    @staticmethod
    def _unmet_acceptance_criteria(
        criteria: tuple[str, ...],
        result: MissionObjectiveResult,
    ) -> list[str]:
        """Check which acceptance criteria are not satisfied by the result.

        A criterion is satisfied if it appears as a substring in the
        stringified result objective, metadata values, or error.  Returns
        the list of unmet criteria (empty when all are satisfied).
        """
        # Prefer explicit evidence emitted by the executor. This lets a
        # capability prove a criterion without relying on fragile substring
        # coincidence in arbitrary metadata. The legacy text search remains
        # as a compatibility fallback for existing executors/tests.
        metadata = dict(result.metadata or {})
        explicit = metadata.get("acceptance_criteria")
        if isinstance(explicit, Mapping):
            unmet = [
                criterion for criterion in criteria
                if explicit.get(criterion) is not True
            ]
            if unmet:
                # An explicit map is authoritative: do not let unrelated text
                # accidentally satisfy a criterion that the executor marked false.
                return unmet
            return []
        evidence = metadata.get("evidence")
        if isinstance(evidence, (list, tuple, set, frozenset)):
            # Executors commonly emit evidence as richer statements such as
            # "PASS: Configuration validates without errors" rather than an
            # exact copy of the criterion. Treat the evidence collection as
            # authoritative, but allow the criterion to appear within an
            # evidence statement. This avoids brittle exact-string coupling
            # while still requiring explicit executor evidence.
            evidence_text = " ".join(str(item).strip().lower() for item in evidence if str(item).strip())
            def _tokens(text: str) -> set[str]:
                return {token for token in re.findall(r"[a-z0-9]+", text.lower()) if len(token) > 2}
            evidence_tokens = _tokens(evidence_text)
            unmet: list[str] = []
            for criterion in criteria:
                normalized = criterion.strip().lower()
                if normalized in evidence_text:
                    continue
                tokens = _tokens(normalized)
                overlap = len(tokens & evidence_tokens)
                # Evidence is already an explicit executor-owned signal. Allow
                # concise paraphrases (for example "event bus initialized with
                # registry" for "event processing system initializes successfully
                # with the registry") while requiring at least three meaningful
                # criterion terms and half of them to be present.
                if len(tokens) >= 3 and overlap >= 3 and overlap * 2 >= len(tokens):
                    continue
                unmet.append(criterion)
            return unmet

        result_text = result.objective or ""
        if result.metadata:
            result_text += " " + " ".join(str(v) for v in result.metadata.values())
        if result.error:
            result_text += " " + result.error
        result_text = result_text.lower()

        return [
            criterion for criterion in criteria
            if criterion.lower() not in result_text
        ]

    @staticmethod
    def _ready_objectives(
        pending: Mapping[str, MissionObjective],
        completed: Sequence[str],
    ) -> tuple[MissionObjective, ...]:
        completed_set = set(completed)
        ready = [
            objective
            for objective in pending.values()
            if set(objective.dependencies).issubset(completed_set)
        ]
        ready.sort(
            key=lambda objective: (
                -objective.priority,
                objective.objective_id,
            )
        )
        return tuple(ready)

    @staticmethod
    def _plan_payload(plan: MissionPlan) -> dict[str, object]:
        return {
            "mission_id": plan.mission_id,
            "goal": plan.goal,
            "metadata": dict(plan.metadata),
            "objectives": [
                {
                    "objective_id": objective.objective_id,
                    "objective": objective.objective,
                    "rationale": objective.rationale,
                    "dependencies": list(objective.dependencies),
                    "priority": objective.priority,
                    "work_type": objective.work_type,
                    "acceptance_criteria": list(objective.acceptance_criteria),
                    "metadata": dict(objective.metadata),
                }
                for objective in plan.objectives
            ],
        }

    @staticmethod
    def _latest_persisted_plan(
        events: Sequence[Event],
        mission_id: str,
        goal: str,
    ) -> MissionPlan | None:
        for event in reversed(events):
            if event.type != "MissionPlanProposed":
                continue
            payload = event.payload or {}
            if payload.get("mission_id") != mission_id:
                continue
            if str(payload.get("goal", "")).strip() != goal:
                continue
            try:
                objectives = tuple(
                    MissionObjective(
                        objective_id=str(item["objective_id"]),
                        objective=str(item["objective"]),
                        rationale=str(item.get("rationale", "")),
                        dependencies=tuple(item.get("dependencies", ())),
                        priority=int(item.get("priority", 0)),
                        work_type=str(item.get("work_type", "implementation")),
                        acceptance_criteria=tuple(item.get("acceptance_criteria", ())),
                        metadata=dict(item.get("metadata") or {}),
                    )
                    for item in payload["objectives"]
                )
                StrategicMissionPlanner._validate(objectives)
                StrategicMissionPlanner._validate_acyclic(objectives, set())
                return MissionPlan(
                    mission_id=mission_id,
                    goal=goal,
                    objectives=objectives,
                    metadata=dict(payload.get("metadata") or {}),
                )
            except (KeyError, TypeError, ValueError):
                # Corrupt/legacy events fall back to a fresh validated plan.
                continue
        return None

