from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Callable, Iterable, Any

from ocean.lumo_cursor import CursorAction, CursorContext, LumoCursorSwarm, validate_cursor_plan

@dataclass(frozen=True)
class SwarmTask:
    task_id: str
    application: str
    actions: tuple[CursorAction, ...]

@dataclass(frozen=True)
class SwarmResult:
    task_id: str
    succeeded: bool
    detail: str
    cursor_id: str

class CursorSwarmRuntime:
    """Runs independent bounded virtual cursors concurrently; never host-controlled."""
    def __init__(self, *, max_cursors: int = 8) -> None:
        self.swarm = LumoCursorSwarm(max_cursors=max_cursors)

    def run(self, tasks: Iterable[SwarmTask], adapter_factory: Callable[[str], Any]) -> tuple[SwarmResult, ...]:
        rows = tuple(tasks)
        if not rows:
            return ()
        if len(rows) > self.swarm.max_cursors:
            raise ValueError("swarm task count exceeds cursor capacity")

        def one(task: SwarmTask) -> SwarmResult:
            plan = validate_cursor_plan(task.actions)
            cursor_id = f"cursor:{task.task_id}"
            cursor = self.swarm.spawn(CursorContext(
                cursor_id=cursor_id,
                surface="macos.ax",
                application=task.application,
                user_owned_surface=True,
            ))
            try:
                adapter = adapter_factory(task.application)
                results = cursor.execute_plan(adapter, plan)
                verified, detail = cursor.verify_plan(adapter, plan, results)
                if verified:
                    cursor.success()
                else:
                    cursor.blocked(detail)
                return SwarmResult(task.task_id, verified, detail, cursor_id)
            finally:
                self.swarm.release(cursor_id)

        results = []
        with ThreadPoolExecutor(max_workers=min(len(rows), self.swarm.max_cursors)) as pool:
            futures = [pool.submit(one, task) for task in rows]
            for future in as_completed(futures):
                try:
                    results.append(future.result())
                except Exception as exc:
                    results.append(SwarmResult("unknown", False, str(exc), ""))
        return tuple(sorted(results, key=lambda r: r.task_id))
