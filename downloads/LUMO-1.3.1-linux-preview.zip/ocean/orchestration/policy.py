"""Policy abstractions for multi-agent orchestration."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from ocean.domain.enums import OrchestrationMode
from ocean.orchestration.types import AssignmentRequest


@dataclass(frozen=True)
class AdmissionDecision:
    """Whether an assignment is allowed to enter orchestration."""

    allowed: bool
    reason: str | None = None


@dataclass(frozen=True)
class RoutingDecision:
    """Routing decision for an assignment."""

    agent_id: str
    reason: str | None = None


@dataclass(frozen=True)
class ConcurrencyPolicy:
    """Concurrency constraints for an orchestration mode."""

    max_parallel_assignments: int | None = None
    allow_background: bool = False
    allow_queued: bool = True


@dataclass(frozen=True)
class RecoveryPolicy:
    """Recovery behavior for failed assignments."""

    retry_allowed: bool = True
    reassign_allowed: bool = True
    max_retries: int = 3


class OrchestrationPolicy(Protocol):
    """Behavioral contract for an orchestration mode."""

    mode: OrchestrationMode

    def admission(
        self,
        request: AssignmentRequest,
    ) -> AdmissionDecision:
        ...

    def routing(
        self,
        request: AssignmentRequest,
    ) -> RoutingDecision:
        ...

    def concurrency(self) -> ConcurrencyPolicy:
        ...

    def recovery(self) -> RecoveryPolicy:
        ...


class StandardOrchestrationPolicy:
    """Default policy for ordinary task orchestration."""

    mode = OrchestrationMode.STANDARD

    def admission(
        self,
        request: AssignmentRequest,
    ) -> AdmissionDecision:
        return AdmissionDecision(allowed=True)

    def routing(
        self,
        request: AssignmentRequest,
    ) -> RoutingDecision:
        return RoutingDecision(
            agent_id=request.agent_id,
            reason="explicit agent assignment",
        )

    def concurrency(self) -> ConcurrencyPolicy:
        return ConcurrencyPolicy(
            max_parallel_assignments=1,
            allow_background=False,
            allow_queued=True,
        )

    def recovery(self) -> RecoveryPolicy:
        return RecoveryPolicy(
            retry_allowed=True,
            reassign_allowed=True,
            max_retries=3,
        )


class ParallelOrchestrationPolicy(StandardOrchestrationPolicy):
    """Policy allowing multiple assignments to progress concurrently."""

    mode = OrchestrationMode.PARALLEL

    def concurrency(self) -> ConcurrencyPolicy:
        return ConcurrencyPolicy(
            max_parallel_assignments=None,
            allow_background=False,
            allow_queued=True,
        )


class BackgroundOrchestrationPolicy(StandardOrchestrationPolicy):
    """Policy for work intended to continue in background operation."""

    mode = OrchestrationMode.BACKGROUND

    def concurrency(self) -> ConcurrencyPolicy:
        return ConcurrencyPolicy(
            max_parallel_assignments=None,
            allow_background=True,
            allow_queued=True,
        )


class QueuedOrchestrationPolicy(StandardOrchestrationPolicy):
    """Policy emphasizing deferred execution through the scheduler."""

    mode = OrchestrationMode.QUEUED

    def concurrency(self) -> ConcurrencyPolicy:
        return ConcurrencyPolicy(
            max_parallel_assignments=0,
            allow_background=False,
            allow_queued=True,
        )



class SwarmOrchestrationPolicy(ParallelOrchestrationPolicy):
    """Elastic policy for coordinated multi-agent swarm execution.

    Swarm is intentionally bounded at the active-worker layer: missions may
    represent hundreds of logical workers while the scheduler caps live
    execution to a safe, resource-aware width.
    """

    mode = OrchestrationMode.SWARM

    def concurrency(self) -> ConcurrencyPolicy:
        return ConcurrencyPolicy(
            max_parallel_assignments=128,
            allow_background=True,
            allow_queued=True,
        )


class ShadowOrchestrationPolicy(BackgroundOrchestrationPolicy):
    """Persistent, low-interruption policy for user shadow agents."""

    mode = OrchestrationMode.SHADOW


class RoutineOrchestrationPolicy(BackgroundOrchestrationPolicy):
    """Durable recurring automation policy."""

    mode = OrchestrationMode.ROUTINE


class GhostOrchestrationPolicy(BackgroundOrchestrationPolicy):
    """Latent/ephemeral policy for agents activated by events or triggers."""

    mode = OrchestrationMode.GHOST


class SpeculativeOrchestrationPolicy(ParallelOrchestrationPolicy):
    """Parallel policy for competing speculative strategies."""

    mode = OrchestrationMode.SPECULATIVE


class OrchestrationPolicyRegistry:
    """Resolves orchestration modes into policy implementations."""

    def __init__(self) -> None:
        self._policies: dict[OrchestrationMode, OrchestrationPolicy] = {}

        self.register(StandardOrchestrationPolicy())
        self.register(ParallelOrchestrationPolicy())
        self.register(BackgroundOrchestrationPolicy())
        self.register(QueuedOrchestrationPolicy())
        self.register(SwarmOrchestrationPolicy())
        self.register(ShadowOrchestrationPolicy())
        self.register(RoutineOrchestrationPolicy())
        self.register(GhostOrchestrationPolicy())
        self.register(SpeculativeOrchestrationPolicy())

    def register(self, policy: OrchestrationPolicy) -> None:
        self._policies[policy.mode] = policy

    def get(self, mode: OrchestrationMode) -> OrchestrationPolicy:
        try:
            return self._policies[mode]
        except KeyError as exc:
            raise KeyError(
                f"no orchestration policy registered for mode {mode.value!r}"
            ) from exc

    def supports(self, mode: OrchestrationMode) -> bool:
        return mode in self._policies
