"""Cost/latency optimization primitives with hard safety boundaries."""
from __future__ import annotations
from dataclasses import dataclass, field
from hashlib import sha256
from threading import RLock, Timer
from concurrent.futures import Future
from time import monotonic
from typing import Any, Callable, Mapping
import json
import math


def stable_key(value: Any) -> str:
    return sha256(json.dumps(value, sort_keys=True, default=str, separators=(",", ":")).encode()).hexdigest()


@dataclass(frozen=True)
class BudgetEstimate:
    estimated_cost: float = 0.0
    estimated_latency_ms: float = 0.0
    estimated_tokens: int = 0
    confidence: float = 0.0

    def __post_init__(self):
        if self.estimated_cost < 0 or self.estimated_latency_ms < 0 or self.estimated_tokens < 0:
            raise ValueError("budget estimates must be non-negative")
        if not 0 <= self.confidence <= 1:
            raise ValueError("confidence must be 0..1")


@dataclass(frozen=True)
class BudgetReservation:
    reservation_id: str
    mission_id: str
    costs: Mapping[str, float]
    created_at: float


class BudgetGuard:
    """Two-stage reservation/commit guard: estimate first, consume only after execution."""
    def __init__(self, limits: Mapping[str, float]):
        self._limits = {str(k): float(v) for k, v in limits.items()}
        if any(not math.isfinite(v) or v < 0 for v in self._limits.values()):
            raise ValueError("limits must be finite and non-negative")
        self._consumed: dict[str, float] = {}
        self._reserved: dict[str, float] = {}
        self._reservations: dict[str, BudgetReservation] = {}
        self._lock = RLock()

    def remaining(self, kind: str) -> float | None:
        with self._lock:
            limit = self._limits.get(kind)
            if limit is None:
                return None
            return max(0.0, limit - self._consumed.get(kind, 0.0) - self._reserved.get(kind, 0.0))

    def reserve(self, mission_id: str, costs: Mapping[str, float], reservation_id: str) -> BudgetReservation:
        if not reservation_id or not mission_id:
            raise ValueError("mission_id and reservation_id are required")
        with self._lock:
            existing = self._reservations.get(reservation_id)
            if existing is not None:
                if existing.mission_id != mission_id or dict(existing.costs) != {str(k): float(v) for k, v in costs.items()}:
                    raise RuntimeError("reservation_id already belongs to a different reservation")
                return existing
            normalized: dict[str, float] = {}
            for kind, amount in costs.items():
                amount = float(amount)
                if not math.isfinite(amount) or amount < 0:
                    raise ValueError("reservation costs must be finite and non-negative")
                normalized[str(kind)] = amount
            for kind, amount in normalized.items():
                limit = self._limits.get(kind)
                if limit is not None and self._consumed.get(kind, 0.0) + self._reserved.get(kind, 0.0) + amount > limit + 1e-12:
                    raise RuntimeError(f"budget exceeded for {kind}")
            reservation = BudgetReservation(reservation_id, mission_id, normalized, monotonic())
            self._reservations[reservation_id] = reservation
            for kind, amount in normalized.items():
                self._reserved[kind] = self._reserved.get(kind, 0.0) + amount
            return reservation

    def can_afford(self, costs: Mapping[str, float]) -> bool:
        """Constant-time admission check with no reservation side effects."""
        with self._lock:
            for kind, amount in costs.items():
                amount = float(amount)
                if not math.isfinite(amount) or amount < 0:
                    return False
                limit = self._limits.get(str(kind))
                if limit is not None and self._consumed.get(str(kind), 0.0) + self._reserved.get(str(kind), 0.0) + amount > limit + 1e-12:
                    return False
            return True

    def release(self, reservation_id: str) -> bool:
        with self._lock:
            reservation = self._reservations.pop(reservation_id, None)
            if reservation is None:
                return False
            for kind, amount in reservation.costs.items():
                self._reserved[kind] = max(0.0, self._reserved.get(kind, 0.0) - float(amount))
            return True

    def commit(self, reservation_id: str, actual_costs: Mapping[str, float] | None = None) -> Mapping[str, float]:
        with self._lock:
            reservation = self._reservations.get(reservation_id)
            if reservation is None:
                raise KeyError(reservation_id)
            actual = dict(reservation.costs if actual_costs is None else actual_costs)
            # Postflight accounting may differ from the estimate. Never allow
            # an under-reservation to silently consume budget that another
            # concurrent execution already reserved.
            reserved=dict(reservation.costs)
            for kind, amount in actual.items():
                amount=float(amount)
                if amount > float(reserved.get(kind, 0.0)):
                    extra=amount-float(reserved.get(kind, 0.0))
                    limit=self._limits.get(kind)
                    other_reserved=max(0.0, self._reserved.get(kind,0.0)-float(reserved.get(kind,0.0)))
                    available=None if limit is None else limit-self._consumed.get(kind,0.0)-other_reserved-float(reserved.get(kind,0.0))
                    if limit is not None and extra > max(0.0, available or 0.0):
                        raise RuntimeError(f"postflight budget variance exceeded for {kind}")
            for kind, amount in actual.items():
                amount = float(amount)
                if not math.isfinite(amount) or amount < 0:
                    raise ValueError("actual costs must be finite and non-negative")
                limit = self._limits.get(kind)
                if limit is not None and self._consumed.get(kind, 0.0) + amount > limit:
                    raise RuntimeError(f"budget exceeded for {kind}")
            self.release(reservation_id)
            for kind, amount in actual.items():
                self._consumed[kind] = self._consumed.get(kind, 0.0) + float(amount)
            return actual

    def snapshot(self) -> Mapping[str, Mapping[str, float]]:
        with self._lock:
            return {"limits": dict(self._limits), "consumed": dict(self._consumed), "reserved": dict(self._reserved)}


@dataclass(frozen=True)
class CacheEntry:
    key: str
    value: Any
    fingerprint: str
    created_at: float
    hits: int = 0


class SafeResultCache:
    """Deterministic cache; callers explicitly declare whether reuse is safe."""
    def __init__(self, max_entries: int = 2048):
        if max_entries <= 0:
            raise ValueError("max_entries must be positive")
        self.max_entries = max_entries
        self._items: dict[str, CacheEntry] = {}
        self._lock = RLock()
        self.hits = 0
        self.misses = 0

    def get(self, key: str, *, current_fingerprint: str, reusable: bool = True) -> Any | None:
        if not reusable:
            self.misses += 1
            return None
        with self._lock:
            entry = self._items.get(key)
            if entry is None or entry.fingerprint != current_fingerprint:
                self.misses += 1
                return None
            self.hits += 1
            self._items[key] = CacheEntry(entry.key, entry.value, entry.fingerprint, entry.created_at, entry.hits + 1)
            return entry.value

    def put(self, key: str, value: Any, *, fingerprint: str) -> None:
        with self._lock:
            if len(self._items) >= self.max_entries and key not in self._items:
                oldest = min(self._items.values(), key=lambda x: x.created_at)
                self._items.pop(oldest.key, None)
            self._items[key] = CacheEntry(key, value, fingerprint, monotonic())

    def invalidate(self, key: str) -> bool:
        with self._lock:
            return self._items.pop(key, None) is not None

    def invalidate_fingerprint(self, fingerprint: str) -> int:
        with self._lock:
            doomed = [k for k, v in self._items.items() if v.fingerprint == fingerprint]
            for k in doomed:
                self._items.pop(k, None)
            return len(doomed)

    def stats(self) -> Mapping[str, float | int]:
        with self._lock:
            total = self.hits + self.misses
            return {"entries": len(self._items), "hits": self.hits, "misses": self.misses, "hit_rate": self.hits / total if total else 0.0}


class SingleFlight:
    """Coalesce identical concurrent deterministic work without weakening authority."""
    def __init__(self):
        self._lock = RLock()
        self._inflight: dict[str, Future] = {}
        # A tiny completion grace absorbs scheduler jitter between threads that
        # were launched together but do not reach the lock before the producer
        # finishes. It is not a result cache: completed work is discarded shortly
        # after the coalescing window closes.
        self._completion_grace_seconds = 0.05

    def _expire(self, key: str, future: Future) -> None:
        with self._lock:
            if self._inflight.get(key) is future:
                self._inflight.pop(key, None)

    def run(self, key: str, fn: Callable[[], Any]) -> Any:
        with self._lock:
            future = self._inflight.get(key)
            producer = future is None
            if producer:
                future = Future()
                self._inflight[key] = future
        if producer:
            try:
                future.set_result(fn())
            except Exception as exc:
                future.set_exception(exc)
            finally:
                Timer(self._completion_grace_seconds, self._expire, args=(key, future)).start()
        return future.result()


@dataclass(frozen=True)
class OptimizationDecision:
    objective: str
    estimated_cost: float
    estimated_latency_ms: float
    reason: str

def choose_objective(*, objective: str, cost: float, latency_ms: float, deadline_slack_ms: float|None=None) -> OptimizationDecision:
    if objective not in {"cost","latency","balanced"}: raise ValueError("objective must be cost, latency, or balanced")
    if deadline_slack_ms is not None and deadline_slack_ms < 0:
        objective="latency"; reason="deadline has no slack"
    else: reason=f"{objective} objective"
    return OptimizationDecision(objective,float(cost),float(latency_ms),reason)


@dataclass(frozen=True)
class CostSample:
    scope: str
    kind: str
    amount: float
    metadata: Mapping[str, Any] = field(default_factory=dict)

class CostLedger:
    def __init__(self):
        self._samples: list[CostSample] = []
        self._lock = RLock()
    def record(self, scope: str, kind: str, amount: float, **metadata: Any) -> CostSample:
        amount=float(amount)
        if not scope or not kind or not math.isfinite(amount) or amount<0: raise ValueError("invalid cost sample")
        row=CostSample(scope,kind,amount,dict(metadata))
        with self._lock: self._samples.append(row)
        return row
    def total(self, *, scope: str|None=None, kind: str|None=None) -> float:
        with self._lock: return sum(x.amount for x in self._samples if (scope is None or x.scope==scope) and (kind is None or x.kind==kind))
    def breakdown(self, *, scope: str|None=None) -> Mapping[str,float]:
        with self._lock:
            rows=[x for x in self._samples if scope is None or x.scope==scope]
        out={}
        for x in rows: out[x.kind]=out.get(x.kind,0.0)+x.amount
        return out


@dataclass(frozen=True)
class FastPathResult:
    handled: bool
    result: Any = None
    reason: str = ""


class DeterministicFastPath:
    """Routes only explicitly registered, low-risk deterministic operations."""
    def __init__(self):
        self._handlers: dict[str, Callable[..., Any]] = {}

    def register(self, operation: str, handler: Callable[..., Any]) -> None:
        if not operation or operation in self._handlers:
            raise ValueError("operation must be unique and non-empty")
        self._handlers[operation] = handler

    def execute(self, operation: str, *, risk: str, authorized: bool, kwargs: Mapping[str, Any] | None = None) -> FastPathResult:
        if risk != "low" or not authorized:
            return FastPathResult(False, reason="fast path requires authorized low-risk operation")
        handler = self._handlers.get(operation)
        if handler is None:
            return FastPathResult(False, reason="no deterministic fast-path handler")
        return FastPathResult(True, handler(**dict(kwargs or {})), "deterministic fast path")


@dataclass(frozen=True)
class LatencySample:
    operation: str
    latency_ms: float
    success: bool


class PerformanceLedger:
    def __init__(self):
        self._samples: list[LatencySample] = []
        self._lock = RLock()

    def record(self, operation: str, latency_ms: float, success: bool = True) -> None:
        if latency_ms < 0 or not math.isfinite(float(latency_ms)):
            raise ValueError("latency must be finite and non-negative")
        with self._lock:
            self._samples.append(LatencySample(operation, float(latency_ms), bool(success)))

    def summary(self, operation: str | None = None) -> Mapping[str, float | int]:
        with self._lock:
            rows = [x for x in self._samples if operation is None or x.operation == operation]
        if not rows:
            return {"count": 0, "success_rate": 0.0, "p50_ms": 0.0, "p95_ms": 0.0, "p99_ms": 0.0}
        values = sorted(x.latency_ms for x in rows)
        def percentile(p: float) -> float:
            return values[min(len(values) - 1, max(0, math.ceil(len(values) * p) - 1))]
        return {"count": len(rows), "success_rate": sum(x.success for x in rows) / len(rows), "p50_ms": percentile(.50), "p95_ms": percentile(.95), "p99_ms": percentile(.99)}
