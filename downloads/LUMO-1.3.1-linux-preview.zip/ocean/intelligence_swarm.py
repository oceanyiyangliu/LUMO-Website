"""Adaptive specialist-model swarms for LUMO intelligence.

A swarm is a coordinated set of specialist roles, not a requirement to keep
multiple models resident. Roles are admitted independently and may run
sequentially or in parallel when the resource governor permits it.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable

from ocean.intelligence_catalog import DEFAULT_LOCAL_MODELS
from ocean.resources.local_model_manager import LocalModelManager
from ocean.resources.intelligence_governor import LocalResourceGovernor

@dataclass(frozen=True)
class IntelligenceRole:
    name: str
    purpose: str
    capabilities: frozenset[str]
    preferred_models: tuple[str, ...]

@dataclass(frozen=True)
class SwarmAssignment:
    role: str
    model_id: str | None
    purpose: str
    mode: str
    available: bool

ROLES = (
    IntelligenceRole("planner", "decompose missions and coordinate work", frozenset({"reasoning", "planning"}), ("qwen3:8b", "qwen3:4b")),
    IntelligenceRole("coder", "write, inspect and repair code", frozenset({"coding", "tools"}), ("devstral:24b", "qwen3:30b-a3b", "qwen3:8b", "qwen3:4b")),
    IntelligenceRole("vision", "understand screenshots and visual interfaces", frozenset({"vision"}), ("qwen2.5vl:7b",)),
    IntelligenceRole("researcher", "general research, synthesis and evidence gathering", frozenset({"general", "reasoning"}), ("qwen3:8b", "qwen3:4b")),
    IntelligenceRole("critic", "challenge plans and check consistency", frozenset({"reasoning"}), ("qwen3:8b", "qwen3:4b")),
)

class IntelligenceSwarm:
    """Builds the strongest safe specialist team for a mission."""
    def __init__(self, *, manager: LocalModelManager | None = None, governor: LocalResourceGovernor | None = None) -> None:
        self.manager = manager or LocalModelManager()
        self.governor = governor or LocalResourceGovernor()
        self._manifests = {m.model_id: m for m in DEFAULT_LOCAL_MODELS}

    def _fits(self, model_id: str) -> bool:
        m = self._manifests.get(model_id)
        if not m or m.size_gib is None:
            return False
        if m.size_gib > 64.0 or not self.manager.is_installed(model_id):
            return False
        runtime = m.runtime_ram_gib or m.size_gib
        return runtime * 1024**3 <= self.governor.snapshot().safe_ai_ram_bytes

    def assign(self, roles: Iterable[str], *, allow_sequential_fallback: bool = True) -> tuple[SwarmAssignment, ...]:
        by_name = {r.name: r for r in ROLES}
        out = []
        for name in roles:
            role = by_name[name]
            chosen = next((m for m in role.preferred_models if self._fits(m)), None)
            out.append(SwarmAssignment(role.name, chosen, role.purpose, "parallel" if chosen and len(out) < self.governor.max_concurrent_workers else "sequential", chosen is not None))
        if allow_sequential_fallback and any(not x.available for x in out):
            # Availability is reported honestly; provisioning is handled by the model lifecycle manager.
            pass
        return tuple(out)

    def mission_team(self, *, needs_vision: bool = False, needs_coding: bool = False, deep: bool = False) -> tuple[SwarmAssignment, ...]:
        roles = ["planner", "researcher", "critic"]
        if needs_coding: roles.append("coder")
        if needs_vision: roles.append("vision")
        if deep and "critic" not in roles: roles.append("critic")
        return self.assign(roles)

    def snapshot(self) -> dict:
        assignments = self.mission_team()
        return {
            "architecture": "specialist_swarm",
            "roles": [r.name for r in ROLES],
            "installed": [m.model_id for m in self._manifests.values() if m.privacy == "local" and self.manager.is_installed(m.model_id)],
            "default_team": [a.__dict__ for a in assignments],
            "adaptive": True,
            "parallelism": self.governor.max_concurrent_workers,
            "resident_models": 0,
            "note": "Models are loaded per role and unloaded after use; the swarm does not require all models resident simultaneously.",
        }
