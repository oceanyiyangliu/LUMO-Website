"""Persistent, low-noise assistant for the user's working context.

Observation is host-side and strictly read-only. Consequential computer actions
must run inside isolated LUMO Worlds; this component never controls the host.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import threading
import time
from pathlib import Path
from typing import Any, Callable

from ocean.capabilities.computer import MacOSComputerExecutor
from runtime.types import ExecutionRequest


class ActiveAssistant:
    """An always-available copilot that intervenes only when it has a reason."""

    def __init__(self, *, interval: float = 0.75, enabled: bool = False) -> None:
        self.interval = max(0.25, interval)
        self._enabled = enabled
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._lock = threading.RLock()
        self._executor = MacOSComputerExecutor()
        self._last_digest = ""
        self._last_analysis = 0.0
        self._last_context_key = ""
        self._last_attention_key = ""
        self._last_attention_at = 0.0
        self._analysis_failures = 0
        self._context_history: list[dict[str, Any]] = []
        self._attention_history: list[dict[str, Any]] = []
        self._sensitive_patterns = ("1password", "bitwarden", "keychain", "bank", "wallet", "password", "messages", "mail", "email", "health")
        self._status: dict[str, Any] = {
            "enabled": enabled, "state": "ready" if enabled else "idle",
            "application": "", "window": "", "attention": None,
            "updated_at": None, "last_screenshot": None,
            "screen_changed": False, "observations": 0, "analyses": 0,
            "last_reason": "startup",
            "context_label": "Unknown workspace", "context_confidence": 0.0,
            "attention_policy": "helpful", "observation_paused": not enabled,
            "host_control": "blocked", "voice_listening": False,
            "sensitive_context": False, "context_started_at": None,
            "last_observed_at": None, "privacy_scope": "permitted_context_only",
            "capabilities": {"observe": True, "suggest": True, "mission_handoff": True, "world_execution": True, "host_control": False},
        }
        self._listeners: list[Callable[[dict[str, Any]], None]] = []

    def start(self) -> dict[str, Any]:
        """Enable the companion without starting host screen observation.

        Host observation is an explicit user action. Starting LUMO or enabling
        the assistant must never silently launch macOS screen capture.
        """
        with self._lock:
            self._enabled = True
            self._status.update(
                enabled=True,
                state="ready",
                observation_paused=True,
                last_reason="enabled_observation_paused_until_user_resume",
            )
        self._stop.set()
        return self.status()

    def stop(self) -> dict[str, Any]:
        with self._lock:
            self._enabled = False
            self._status.update(enabled=False, state="idle", observation_paused=True, last_reason="disabled")
            self._stop.set()
        thread = self._thread
        if thread is not None and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=2.0)
        return self.status()

    def status(self) -> dict[str, Any]:
        with self._lock:
            return dict(self._status)

    def add_listener(self, listener: Callable[[dict[str, Any]], None]) -> None:
        with self._lock:
            if listener not in self._listeners:
                self._listeners.append(listener)

    def set_policy(self, policy: str) -> dict[str, Any]:
        allowed = {"silent", "minimal", "helpful", "proactive"}
        with self._lock:
            self._status["attention_policy"] = policy if policy in allowed else "helpful"
            self._status["last_reason"] = "attention_policy_changed"
            return dict(self._status)

    def pause_observation(self) -> dict[str, Any]:
        with self._lock:
            self._status.update(observation_paused=True, state="paused", last_reason="observation_paused")
            self._stop.set()
        thread = self._thread
        if thread is not None and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=2.0)
        return self.status()

    def resume_observation(self) -> dict[str, Any]:
        with self._lock:
            if not self._enabled:
                self._status.update(state="idle", observation_paused=True, last_reason="observation_requires_assistant")
                return dict(self._status)
            self._status.update(observation_paused=False, state="watching", last_reason="observation_resumed")
            if self._thread is None or not self._thread.is_alive():
                self._stop.clear()
                self._thread = threading.Thread(
                    target=self._run, name="lumo-active-assistant", daemon=True
                )
                self._thread.start()
            return dict(self._status)

    def notify_human_action(self, *, message: str, suggestion: str = "", urgency: str = "important", kind: str = "human_action") -> dict[str, Any]:
        """Surface an authoritative system request through the companion.

        This bypasses model interpretation: credentials, account creation, consent,
        payment, ownership and other authority-boundary requests originate in the
        control plane and are therefore safe to surface directly.
        """
        urgency = urgency if urgency in {"normal", "important", "urgent"} else "important"
        attention = {
            "kind": kind,
            "message": str(message).strip(),
            "confidence": 1.0,
            "suggestion": str(suggestion).strip(),
            "urgency": urgency,
            "timestamp": time.time(),
        }
        with self._lock:
            now = time.time()
            duplicate = next((item for item in reversed(self._attention_history)
                              if item.get("kind") == attention["kind"]
                              and item.get("message") == attention["message"]
                              and item.get("urgency") == attention["urgency"]
                              and now - float(item.get("timestamp", 0) or 0) < 30.0), None)
            if duplicate is not None:
                # Keep the authoritative attention visible without generating
                # notification spam while a first-launch gate is being polled.
                self._status.update(
                    state="attention",
                    attention={k: attention[k] for k in ("kind", "message", "confidence", "suggestion", "urgency")},
                    updated_at=attention["timestamp"],
                    last_reason="authoritative_human_action_required",
                )
                return dict(self._status)
            self._attention_history.append(attention)
            self._attention_history = self._attention_history[-50:]
            self._status.update(
                state="attention",
                attention={k: attention[k] for k in ("kind", "message", "confidence", "suggestion", "urgency")},
                attention_count=int(self._status.get("attention_count", 0)) + 1,
                updated_at=attention["timestamp"],
                last_reason="authoritative_human_action_required",
            )
            listeners = tuple(self._listeners)
            snapshot = dict(self._status)
        for listener in listeners:
            try:
                listener(snapshot)
            except Exception:
                pass
        return snapshot

    def dismiss(self) -> None:
        with self._lock:
            self._status["attention"] = None
            self._status["attention_count"] = 0
            self._status["state"] = (
                "watching" if self._enabled and not self._status.get("observation_paused") else
                "ready" if self._enabled else "idle"
            )
            self._status["last_reason"] = "dismissed"

    def history(self, *, limit: int = 50) -> dict[str, Any]:
        """Return bounded local telemetry without exposing screenshot bytes."""
        with self._lock:
            n = max(1, min(200, int(limit)))
            return {"contexts": list(self._context_history[-n:]), "attention": list(self._attention_history[-n:]), "status": dict(self._status)}

    def _is_sensitive(self, application: str, window: str) -> bool:
        text = f"{application} {window}".lower()
        return any(pattern in text for pattern in self._sensitive_patterns)

    def _emit(self, update: dict[str, Any]) -> None:
        with self._lock:
            self._status.update(update)
            snapshot = dict(self._status)
            listeners = tuple(self._listeners)
        for listener in listeners:
            try:
                listener(snapshot)
            except Exception:
                continue

    @staticmethod
    def _digest(path: str) -> str:
        try:
            return hashlib.sha256(Path(path).read_bytes()).hexdigest()
        except OSError:
            return ""

    @staticmethod
    def _context_score(application: str, window: str) -> int:
        """Rank contexts instead of using a brittle allow-list."""
        text = f"{application} {window}".lower()
        high = ("cursor", "visual studio code", "xcode", "jupyter", "terminal")
        study = ("math", "geogebra", "desmos", "word", "onenote", "notion")
        design = ("cad", "fusion", "solidworks", "onshape", "canva")
        return 3 if any(x in text for x in high) else 2 if any(x in text for x in study + design) else 1

    @staticmethod
    def _context_label(application: str, window: str) -> str:
        text = f"{application} {window}".lower()
        groups = [
            (("cursor", "visual studio code", "xcode", "jupyter", "terminal"), "Development"),
            (("math", "geogebra", "desmos", "onenote", "notion", "physics", "chemistry"), "Study"),
            (("canva", "figma", "cad", "fusion", "solidworks", "onshape"), "Design"),
            (("chrome", "safari", "firefox", "research", "scholar"), "Research"),
            (("word", "pages", "docs", "writing"), "Writing"),
        ]
        for needles, label in groups:
            if any(x in text for x in needles):
                return label
        return "General workspace"

    def _analysis_interval(self, score: int) -> float:
        """Adaptive cognition budget: useful contexts get faster attention."""
        base = float(os.getenv("LUMO_ASSISTANT_ANALYSIS_INTERVAL", "3.0"))
        return max(1.5, base - (score - 1) * 0.75)

    def _capture(self) -> tuple[str, str, str] | None:
        result = self._executor.execute(
            ExecutionRequest(
                task_id=f"assistant-screen-{time.time_ns()}", capability="computer",
                operation="screenshot", arguments={"timeout": 5},
                principal_id="lumo-active-assistant", source="lumo.assistant",
            ), None,
        )
        if not result.success:
            self._emit({
                "state": "degraded",
                "attention": {"kind": "permission", "message": result.error or "Screen observation unavailable"},
                "updated_at": time.time(), "last_reason": "observation_failed",
            })
            return None
        payload = result.result or {}
        return str(payload.get("path", "")), str(payload.get("application", "")), str(payload.get("window", ""))

    def _run(self) -> None:
        while not self._stop.wait(self.interval):
            with self._lock:
                if not self._enabled or self._status.get("observation_paused"):
                    continue
            try:
                captured = self._capture()
                if not captured:
                    continue
                path, application, window = captured
                digest = self._digest(path)
                changed = bool(digest and digest != self._last_digest)
                if digest:
                    self._last_digest = digest
                score = self._context_score(application, window)
                context_label = self._context_label(application, window)
                sensitive = self._is_sensitive(application, window)
                # Confidence is evidence-backed: app/window identification is
                # stronger than a generic screen classification, but never 100%.
                # Unknown/generic contexts must not report the old misleading 0%.
                confidence = {1: 0.72, 2: 0.84, 3: 0.94}[score]
                now = time.time()
                with self._lock:
                    self._status["observations"] += 1
                context_event = {"timestamp": now, "application": application, "window": window, "label": context_label, "sensitive": sensitive}
                with self._lock:
                    if not self._context_history or self._context_history[-1]["label"] != context_label or self._context_history[-1]["application"] != application:
                        self._context_history.append(context_event)
                        self._context_history = self._context_history[-50:]
                self._emit({
                    "state": "watching", "application": application, "window": window,
                    "last_screenshot": path, "updated_at": now, "screen_changed": changed,
                    "context_score": score, "context_label": context_label, "context_confidence": confidence, "sensitive_context": sensitive, "last_observed_at": now, "context_started_at": self._status.get("context_started_at") or now, "last_reason": "sensitive_context" if sensitive else ("screen_changed" if changed else "no_change"),
                })
                if sensitive:
                    continue
                if not changed:
                    continue
                if now - self._last_analysis < self._analysis_interval(score):
                    continue
                self._analyze(path, application, window, score)
            except Exception as exc:
                self._emit({"state": "degraded", "updated_at": time.time(), "last_reason": type(exc).__name__})

    def _analyze(self, path: str, application: str, window: str, score: int) -> None:
        """Use vision sparingly, with structured output and duplicate suppression.

        Attention must be grounded in visible evidence; model confidence alone
        is never sufficient for claims about an unfinished user request.
        """
        # Active Assistant is local-only. Vision requires an installed local
        # vision model that safely fits the current resource budget; never
        # fall back to a cloud credential.
        try:
            from ocean.resources.local_model_manager import LocalModelManager
            from ocean.resources.intelligence_governor import LocalResourceGovernor
            manager = LocalModelManager()
            inventory = {m.name: m for m in manager.inventory_live()}
            vision_model = inventory.get("qwen2.5vl:7b")
            safe_gib = LocalResourceGovernor().snapshot().safe_ai_ram_bytes / 1024**3
            if vision_model is None or vision_model.size_gib > safe_gib + 1e-6:
                self._emit({"last_reason": "local_vision_model_unavailable"})
                return
        except Exception:
            self._emit({"last_reason": "local_vision_model_unavailable"})
            return
        self._last_analysis = time.time()
        try:
            encoded = base64.b64encode(Path(path).read_bytes()).decode("ascii")
            prompt = (
                "You are LUMO, an unobtrusive active work assistant. Inspect the current screen "
                "and find at most ONE useful intervention. Prioritize blocking mistakes, likely errors, "
                "missing next steps, deadlines visible on screen, or a concrete way to save time. "
                "Do not comment on appearance. Do not invent hidden state. If nothing is clearly useful, "
                "return alert=false. Never claim to have acted. Return ONLY JSON with keys "
                "alert, kind, message, suggestion, confidence, urgency, evidence."
            )
            payload = json.dumps({
                "model": "qwen2.5vl:7b",
                "stream": False,
                "keep_alive": 0,
                "messages": [{
                    "role": "user",
                    "content": prompt + f"\nApplication: {application}\nWindow: {window}\nContext priority: {score}",
                    "images": [encoded],
                }],
            }).encode("utf-8")
            import urllib.request
            request = urllib.request.Request(
                "http://127.0.0.1:11434/api/chat",
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(request, timeout=30) as response:
                body = json.loads(response.read().decode("utf-8"))
            content = body.get("message", {}).get("content", "{}")
            data = json.loads(content)
            confidence = max(0.0, min(1.0, float(data.get("confidence", 0))))
            message = str(data.get("message", "")).strip()
            suggestion = str(data.get("suggestion", "")).strip()
            evidence = str(data.get("evidence", "")).strip()
            kind = str(data.get("kind", "notice")).strip() or "notice"
            requested_urgency = str(data.get("urgency", "normal")).strip().lower()
            if requested_urgency not in {"normal", "important", "urgent"}:
                requested_urgency = "normal"
            # Urgent visual interruptions are deliberately rare: require very high
            # confidence and a concrete message, then rate-limit them through the
            # same duplicate suppression path as every other attention event.
            urgency = requested_urgency if confidence >= 0.90 and message else "normal"
            # Incomplete-request alerts require concrete visible evidence, not
            # merely a high model confidence score.
            if kind == "incomplete_request" and (not evidence or len(evidence) > 240):
                self._emit({"last_reason": "ungrounded_incomplete_request"})
                return
            key = f"{kind}:{message}:{suggestion}:{evidence}".lower()
            with self._lock:
                self._status["analyses"] += 1
            if kind in {"incomplete_request", "blocking_error", "permission"}:
                # These are control-plane/system claims. They must originate
                # from authoritative runtime state, not model interpretation.
                self._emit({"state": "watching", "attention": None, "last_reason": f"unsupported_model_system_claim:{kind}"})
                return
            if not bool(data.get("alert")) or confidence < 0.70 or not message:
                self._emit({"state": "watching", "attention": None, "last_reason": "no_actionable_finding"})
                return
            if key == self._last_attention_key and time.time() - self._last_attention_at < 45:
                self._emit({"last_reason": "duplicate_suppressed"})
                return
            self._last_attention_key = key
            self._last_attention_at = time.time()
            attention = {"kind": kind, "message": message, "confidence": confidence, "suggestion": suggestion, "urgency": urgency, "timestamp": time.time()}
            with self._lock:
                self._attention_history.append(attention)
                self._attention_history = self._attention_history[-50:]
            self._emit({
                "state": "attention",
                "attention": {"kind": kind, "message": message, "confidence": confidence, "suggestion": suggestion, "urgency": urgency},
                "updated_at": time.time(), "last_reason": "actionable_finding",
            })
        except Exception:
            self._analysis_failures += 1
            self._emit({"last_reason": "analysis_failed", "state": "watching"})
