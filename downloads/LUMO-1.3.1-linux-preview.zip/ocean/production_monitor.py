"""Fail-closed production health monitor with durable alert records."""
from __future__ import annotations
import json
import time
from pathlib import Path
from urllib.request import Request, urlopen


class ProductionMonitor:
    def __init__(self, health_url: str, alert_file: str | Path, *, timeout: float = 5.0):
        if not health_url.startswith("https://"):
            raise ValueError("production health URL must use HTTPS")
        self.health_url = health_url
        self.alert_file = Path(alert_file).expanduser().resolve()
        self.timeout = timeout

    def check(self) -> dict:
        result = {"timestamp": time.time(), "healthy": False, "status": None, "error": None}
        try:
            response = urlopen(Request(self.health_url, headers={"Accept": "application/json"}), timeout=self.timeout)
            result["status"] = response.status
            payload = json.loads(response.read())
            result["healthy"] = response.status == 200 and payload.get("status") == "ok"
        except Exception as exc:
            result["error"] = type(exc).__name__
        if not result["healthy"]:
            self._alert(result)
        return result

    def _alert(self, result: dict) -> None:
        self.alert_file.parent.mkdir(parents=True, exist_ok=True)
        with self.alert_file.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps({"type": "LUMO_HEALTH_FAILURE", **result}, sort_keys=True) + "\n")
