"""Hands-off first-launch setup orchestrator.

This is a bounded local control-plane workflow. It uses the tiny bootstrap
intelligence for decisions and the LUMO Cursor/AX surface for deterministic UI
work. macOS privacy consent remains an OS-controlled boundary: the agent can
open the exact pane and wait, but cannot grant consent on the user's behalf.
"""
from __future__ import annotations
import os, subprocess, threading, time
from dataclasses import dataclass, asdict
from typing import Any
from .bootstrap_intelligence import BootstrapIntelligence
from .resources.intelligence_governor import LocalResourceGovernor

@dataclass
class SetupAutopilotState:
    enabled: bool = False
    running: bool = False
    phase: str = "idle"
    progress: float = 0.0
    message: str = "Hands-off setup is idle"
    blocked_reason: str | None = None
    pending_permission: str | None = None
    permission_decision: str | None = None
    memory_actions: list[str] | None = None
    memory_review_required: bool = False
    memory_candidates: list[dict[str, Any]] | None = None
    memory_decision: str | None = None
    memory_selected: list[str] | None = None
    reopen_after_setup: list[str] | None = None
    cursor_x: float | None = None
    cursor_y: float | None = None
    cursor_visible: bool = False
    cursor_message: str | None = None
    updated_at: float = 0.0

class SetupAutopilot:
    """Single-flight first-launch setup controller."""
    def __init__(self, api: Any):
        self.api = api
        # Share the API's authoritative bootstrap controller; a second controller
        # would create contradictory health snapshots during first launch.
        self.bootstrap = api._bootstrap_intelligence
        self._lock = threading.RLock()
        self._state = SetupAutopilotState(updated_at=time.time(), memory_actions=[])
        self._thread: threading.Thread | None = None

    def _notify_user(self, message: str, suggestion: str, *, urgency: str = "important", kind: str = "first_launch") -> None:
        """Surface setup authority-boundaries through the persistent companion."""
        try:
            self.api.service.active_assistant.notify_human_action(
                message=message, suggestion=suggestion, urgency=urgency, kind=kind,
            )
        except Exception:
            # Setup must never fail because presentation of an attention message failed.
            pass

    def status(self) -> dict[str, Any]:
        with self._lock:
            d = asdict(self._state)
        d["bootstrap"] = asdict(self.bootstrap.status())
        return d

    def start(self, *, manage_memory: bool = True) -> dict[str, Any]:
        with self._lock:
            if self._state.running:
                return self.status()
            self._state.enabled = True
            self._state.running = True
            self._state.phase = "bootstrap"
            self._state.progress = 0.02
            self._state.message = "Bootstrap intelligence is taking over setup"
            self._state.blocked_reason = None
            self._state.updated_at = time.time()
            self._state.memory_actions = []
            self._thread = threading.Thread(target=self._run, args=(manage_memory,), name="lumo-setup-autopilot", daemon=True)
            self._thread.start()
        return self.status()

    def stop(self) -> dict[str, Any]:
        with self._lock:
            self._state.running = False
            self._state.phase = "stopped"
            self._state.message = "Hands-off setup stopped"
            self._state.updated_at = time.time()
        return self.status()

    def permission_response(self, decision: str) -> dict[str, Any]:
        decision = str(decision).strip().lower()
        if decision not in {"allow", "deny"}:
            raise ValueError("permission decision must be allow or deny")
        with self._lock:
            self._state.permission_decision = decision
            if decision == "deny":
                self._state.running = False
                self._state.phase = "blocked"
                self._state.message = f"User declined macOS permission: {self._state.pending_permission or 'unknown'}"
                self._state.blocked_reason = self._state.pending_permission
            self._state.updated_at = time.time()
        return self.status()

    def _set(self, **values: Any) -> None:
        with self._lock:
            for key, value in values.items():
                setattr(self._state, key, value)
            self._state.updated_at = time.time()

    @staticmethod
    def _open_settings(pane: str) -> None:
        panes = {
            "accessibility": "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility",
            "screen": "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture",
            "automation": "x-apple.systempreferences:com.apple.preference.security?Privacy_Automation",
            "files": "x-apple.systempreferences:com.apple.preference.security?Privacy_FilesAndFolders",
        }
        subprocess.run(["/usr/bin/open", panes[pane]], check=False, capture_output=True, timeout=5)

    def _memory_plan(self, apps: list[dict[str, Any]], required_safe_gib: float) -> list[dict[str, Any]]:
        """Score memory candidates without blindly targeting the biggest process."""
        protected = {"LUMO", "Finder", "System Events", "Dock", "WindowServer", "loginwindow", "System Settings"}
        usable = [a for a in apps if str(a.get("name", "")).strip() and str(a.get("name", "")).strip() not in protected]
        frontmost = {str(a.get("name", "")).strip() for a in usable if bool(a.get("frontmost"))}
        ranked: list[dict[str, Any]] = []
        for app in usable:
            name = str(app.get("name", "")).strip()
            ram = float(app.get("memory_gib", 0) or 0)
            if ram <= 0 or name in frontmost:
                continue
            # Background apps get a strong preference; large consumers matter,
            # but a cluster of small idle apps can collectively beat one useful app.
            score = ram * 1.8 + (0.8 if ram >= 1.0 else 0.0)
            if ram < 0.35:
                score += 0.25
            ranked.append({"name": name, "pid": app.get("pid"), "memory_gib": ram,
                           "frontmost": bool(app.get("frontmost")),
                           "action": "quit", "score": round(score, 3),
                           "reason": "background and high memory use" if ram >= 1.0 else "background; small memory use"})
        ranked.sort(key=lambda item: item["score"], reverse=True)
        # Prefer one large idle app or a compact group of small idle apps, never
        # an arbitrary top-N list. Stop once the projected recovery is sufficient.
        selected: list[dict[str, Any]] = []
        recovered = 0.0
        target = max(0.5, required_safe_gib)
        for item in ranked:
            selected.append(item)
            recovered += float(item["memory_gib"])
            if recovered >= target:
                break
        return selected

    def memory_response(self, decision: str, names: list[str] | None = None, restart_names: list[str] | None = None) -> dict[str, Any]:
        decision = str(decision).strip().lower()
        if decision not in {"allow", "deny"}:
            raise ValueError("memory decision must be allow or deny")
        with self._lock:
            candidates = list(self._state.memory_candidates or [])
            allowed = {str(item.get("name", "")).strip() for item in candidates}
            selected = [str(name).strip() for name in (names or []) if str(name).strip() in allowed]
            restart = [str(name).strip() for name in (restart_names or []) if str(name).strip() in allowed]
            self._state.memory_decision = decision
            self._state.memory_selected = selected
            self._state.reopen_after_setup = restart
            self._state.memory_review_required = False
            if decision == "allow" and selected:
                self._state.phase = "memory"
                self._state.progress = 0.31
                self._state.message = "Closing the selected apps gracefully and verifying they actually exit"
            elif decision == "deny":
                self._state.message = "Memory recovery declined; LUMO will keep everything open"
            self._state.updated_at = time.time()
        return self.status()

    def _graceful_memory_recovery(self, *, required_safe_gib: float = 0.0, selected: list[str] | None = None) -> None:
        """Quit only user-facing apps, never force-quit and never touch protected apps."""
        self._set(phase="memory", progress=0.28, message="Freeing memory with graceful application quits")
        memory = self.api.memory_state()
        apps = memory.get("apps", []) if isinstance(memory, dict) else []
        selected_names = {str(name).strip() for name in (selected or [])}
        candidates = [a for a in apps if str(a.get("name", "")).strip() in selected_names]
        for app in candidates:
            if not self._state.running:
                return
            name = str(app.get("name", "")).strip()
            if not name:
                continue
            pid = int(app.get("pid") or 0)
            # Use AppleScript for a real graceful application quit. Never fall back
            # to kill(1): if macOS refuses the quit, report the failure instead of
            # pretending memory was recovered.
            safe_name = name.replace("\\", "\\\\").replace('"', '\\"')
            script = f'tell application "{safe_name}" to quit'
            try:
                result = subprocess.run(["/usr/bin/osascript", "-e", script], capture_output=True, text=True, timeout=8, check=False)
                if result.returncode == 0:
                    with self._lock:
                        self._state.memory_actions.append(f"requested graceful quit: {name}")
                else:
                    detail = (result.stderr or result.stdout or "AppleScript quit failed").strip().replace("\\n", " ")[:220]
                    with self._lock:
                        self._state.memory_actions.append(f"graceful quit failed: {name} ({detail})")
                    continue
            except subprocess.TimeoutExpired:
                with self._lock:
                    self._state.memory_actions.append(f"graceful quit timed out: {name}")
                continue
            except Exception as exc:
                with self._lock:
                    self._state.memory_actions.append(f"graceful quit error: {name} ({exc})")
                continue
            # Verify application-level state, not just one PID. Chromium-style apps
            # have many helper processes, and the main PID can disappear while the
            # application immediately remains/reopens. A successful AppleScript
            # request is not enough evidence that the app actually closed.
            exited = False
            for _ in range(10):
                time.sleep(0.5)
                # Do not query the target app with AppleScript here: even a
                # harmless "get running" can launch the application again.
                # pgrep reads the process table without launching anything.
                try:
                    probe = subprocess.run(
                        ["/usr/bin/pgrep", "-x", name],
                        capture_output=True, text=True, timeout=2, check=False,
                    )
                    main_pids = [line for line in probe.stdout.splitlines() if line.strip().isdigit()]
                    if not main_pids:
                        exited = True
                        break
                except Exception:
                    if pid > 0:
                        try:
                            os.kill(pid, 0)
                        except ProcessLookupError:
                            exited = True
                            break
                        except PermissionError:
                            pass
            if exited:
                with self._lock:
                    self._state.memory_actions.append(f"verified graceful quit: {name}")
            else:
                with self._lock:
                    self._state.memory_actions.append(f"graceful quit not verified: {name}")
            memory = self.api.memory_state()
            budget = float(memory.get("local_ai_ram_budget_gib", 0) or 0)
            if budget >= required_safe_gib and not bool(memory.get("memory_pressure", False)):
                break

    def _run(self, manage_memory: bool) -> None:
        try:
            status = self.bootstrap.ensure_model(allow_download=True)
            if not status.installed:
                raise RuntimeError(status.reason)
            if status.fits_now:
                status = self.bootstrap.health_check()
            if not status.healthy:
                raise RuntimeError(f"bootstrap health check: {status.reason}")
            # Once bootstrapped, immediately select the strongest installed local
            # model that the live resource governor can safely admit. This keeps
            # setup intelligence adaptive instead of permanently pinning setup to
            # the tiny bootstrap model.
            self._set(phase="intelligence", progress=0.16, message="Selecting the strongest local AI that is safe to launch")
            inventory = self.bootstrap.manager.inventory_live()
            safe_gib = LocalResourceGovernor().snapshot().safe_ai_ram_bytes / (1024 ** 3)
            def model_ram(item: Any) -> float:
                return float(getattr(item, "runtime_ram_gib", 0) or getattr(item, "size_gib", 0) or 0)
            fitting = [item for item in inventory if model_ram(item) <= safe_gib + 1e-6]
            fitting.sort(key=model_ram, reverse=True)
            selected = fitting[0].name if fitting else self.bootstrap.MODEL
            self._set(phase="inventory", progress=0.20, message=f"Setup intelligence selected: {selected} ({safe_gib:.2f} GiB safe AI budget)")
            time.sleep(0.15)
            memory_now = self.api.memory_state()
            # Memory pressure alone is not a first-launch blocker. If the tiny
            # bootstrap model is admitted, let LUMO open immediately and let the
            # resource governor optimize toward stronger models later.
            needs_memory = not bool(status.fits_now)
            if manage_memory and needs_memory:
                # Ask for exactly the missing headroom, rather than a fixed 1 GiB.
                # This keeps first launch adaptive on 8/16/24/32 GiB Macs and avoids
                # pretending that a small recovery is enough when the bootstrap
                # model still cannot be admitted safely.
                available_now = float(memory_now.get("available_ram_gib", 0) or 0)
                required_now = float(self.bootstrap.RUNTIME_RAM_GIB + self.bootstrap.MIN_SYSTEM_HEADROOM_GIB)
                memory_deficit = max(0.5, required_now - available_now)
                plan = self._memory_plan(list(memory_now.get("apps", []) or []), memory_deficit)
                if plan:
                    with self._lock:
                        self._state.memory_candidates = plan
                        self._state.memory_review_required = True
                        self._state.memory_decision = None
                    self._set(phase="memory_review", progress=0.30, message="I found a few low-disruption ways to free enough RAM. Review them before LUMO quits anything.")
                    self._notify_user(
                        "I found a safe way to make enough RAM for setup. I need your approval before closing any apps.",
                        "Open LUMO to review the suggested background apps, or keep everything open and I’ll stay on the lightweight path.",
                        kind="memory_review",
                    )
                    while self._state.running:
                        with self._lock:
                            decision = self._state.memory_decision
                            selected = list(self._state.memory_selected or [])
                        if decision == "allow":
                            if selected:
                                self._graceful_memory_recovery(required_safe_gib=memory_deficit, selected=selected)
                            break
                        if decision == "deny":
                            break
                        time.sleep(0.5)
            self._set(phase="permissions", progress=0.55, message="Checking macOS permissions")
            # TCC permissions are capabilities, not prerequisites for opening LUMO.
            # Never make first launch wait for a protected permission or a heavyweight
            # vision model. The control plane is usable without them; computer control
            # becomes available automatically once the user grants the relevant access.
            missing = self.api.missing_setup_permissions()
            if missing:
                self._set(
                    running=False,
                    phase="complete",
                    progress=1.0,
                    message=f"LUMO is ready. Optional Mac access remains: {', '.join(missing)}",
                    blocked_reason=None,
                    pending_permission=None,
                )
            else:
                self._set(phase="verify", progress=0.90, message="Verifying the local control plane")
                final = self.bootstrap.health_check()
                if not final.healthy:
                    raise RuntimeError(final.reason)
                self._set(running=False, phase="complete", progress=1.0, message="LUMO setup completed autonomously", blocked_reason=None)
            if self.api._emergency_stop.is_set():
                self._notify_user(
                    "LUMO is ready. I’m stopped safely until you explicitly release me.",
                    "Open LUMO, review the safety acknowledgement, and release me when you want me to go live.",
                    urgency="important", kind="safety_release",
                )
            reopen = list(self._state.reopen_after_setup or [])
            for name in reopen:
                try:
                    subprocess.run(["/usr/bin/open", "-a", name], check=False, capture_output=True, timeout=8)
                    with self._lock:
                        self._state.memory_actions.append(f"reopened after setup: {name}")
                except Exception:
                    continue
            return
        except Exception as exc:
            self._set(running=False, phase="error", message=str(exc), blocked_reason=str(exc))
