from __future__ import annotations

from typing import Any, Mapping, Optional

from ocean.core.clock import SYSTEM_CLOCK
from ocean.core.ids import new_id
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus

from .registry import ReputationRegistry
from .types import EvidenceCategory, EvidenceOutcome, TrustEvidence


class TrustController:
    """Authoritative mutation boundary for trust evidence."""

    def __init__(self, *, event_bus: Optional[EventBus] = None, registry: Optional[ReputationRegistry] = None) -> None:
        self._event_bus = event_bus
        self._registry = registry or ReputationRegistry()

    @property
    def registry(self) -> ReputationRegistry:
        return self._registry

    def record(self, subject_id: str, source_id: str, category: EvidenceCategory, outcome: EvidenceOutcome, *, context: Optional[Mapping[str, Any]] = None, confidence: float = 1.0, metadata: Optional[Mapping[str, Any]] = None, evidence_id: Optional[str] = None) -> TrustEvidence:
        evidence = TrustEvidence(subject_id=subject_id, source_id=source_id, category=category, outcome=outcome, context=dict(context or {}), confidence=confidence, metadata=dict(metadata or {}), id=evidence_id or new_id("evidence"), at=SYSTEM_CLOCK.now())
        self._registry.record(evidence)
        self._publish(Event(type="TrustEvidenceRecorded", payload={"evidence_id": evidence.id, "subject_id": evidence.subject_id, "source_id": evidence.source_id, "category": evidence.category.value, "outcome": evidence.outcome.value, "context": dict(evidence.context), "confidence": evidence.confidence, "metadata": dict(evidence.metadata), "at": evidence.at}, aggregate_type="trust", aggregate_id=evidence.subject_id))
        return evidence

    def rebuild(self, events) -> None:
        self._registry.rebuild(events)

    def _publish(self, event: Event) -> None:
        if self._event_bus is not None:
            self._event_bus.publish(event)
