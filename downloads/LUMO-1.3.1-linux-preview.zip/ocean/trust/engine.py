from __future__ import annotations

from .registry import ReputationRegistry
from .types import TrustDecision, TrustRequest


class TrustEngine:
    """Deterministic trust evaluation over reputation evidence."""

    def __init__(self, registry: ReputationRegistry) -> None:
        self._registry = registry

    def evaluate(self, request: TrustRequest) -> TrustDecision:
        profile = self._registry.profile(request.subject_id)
        if profile.evidence_count == 0:
            return TrustDecision(False, 0.0, ("no trust evidence available",), profile)
        context_categories = request.context.get("categories")
        dimensions = profile.dimensions
        if context_categories:
            selected = [dimensions[c] for c in context_categories if c in dimensions]
            score = sum(selected) / len(selected) if selected else 0.0
        else:
            score = sum(dimensions.values()) / len(dimensions) if dimensions else 0.0
        trusted = score >= 0.5 and profile.confidence >= request.required_confidence
        reasons = (f"trust score {score:.3f}", f"reputation confidence {profile.confidence:.3f}")
        return TrustDecision(trusted, score, reasons, profile)
