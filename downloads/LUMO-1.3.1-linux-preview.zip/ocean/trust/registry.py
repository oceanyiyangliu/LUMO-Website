from __future__ import annotations

from datetime import datetime
from typing import Dict, Iterable, Optional

from ocean.domain.event import Event

from .types import EvidenceCategory, EvidenceOutcome, ReputationProfile, TrustEvidence


class ReputationRegistry:
    """Rebuildable projection of immutable trust evidence."""

    def __init__(self) -> None:
        self._evidence: Dict[str, TrustEvidence] = {}

    def record(self, evidence: TrustEvidence) -> TrustEvidence:
        existing = self._evidence.get(evidence.id)
        if existing is not None and existing != evidence:
            raise ValueError(f"evidence already recorded: {evidence.id!r}")
        self._evidence[evidence.id] = evidence
        return evidence

    def get(self, evidence_id: str) -> Optional[TrustEvidence]:
        return self._evidence.get(evidence_id)

    def require(self, evidence_id: str) -> TrustEvidence:
        evidence = self.get(evidence_id)
        if evidence is None:
            raise KeyError(f"unknown evidence: {evidence_id!r}")
        return evidence

    def list(self) -> Iterable[TrustEvidence]:
        return tuple(self._evidence.values())

    def for_subject(self, subject_id: str) -> tuple[TrustEvidence, ...]:
        return tuple(e for e in self._evidence.values() if e.subject_id == subject_id)

    def profile(self, subject_id: str) -> ReputationProfile:
        evidence = self.for_subject(subject_id)
        totals: dict[str, float] = {}
        weights: dict[str, float] = {}
        for item in evidence:
            weight = item.confidence
            value = 1.0 if item.outcome is EvidenceOutcome.POSITIVE else -1.0 if item.outcome is EvidenceOutcome.NEGATIVE else 0.0
            totals[item.category.value] = totals.get(item.category.value, 0.0) + value * weight
            weights[item.category.value] = weights.get(item.category.value, 0.0) + weight
        dimensions = {category: (totals[category] / weights[category] + 1.0) / 2.0 for category in totals if weights[category] > 0}
        confidence = min(1.0, len(evidence) / 5.0)
        updated_at = max((e.at for e in evidence), default=datetime.min)
        return ReputationProfile(subject_id=subject_id, dimensions=dimensions, evidence_count=len(evidence), confidence=confidence, updated_at=updated_at)

    def rebuild(self, events: Iterable[Event]) -> None:
        self._evidence.clear()
        for event in events:
            if event.type != "TrustEvidenceRecorded":
                continue
            payload = event.payload
            evidence_id = str(payload["evidence_id"])
            if evidence_id in self._evidence:
                raise ValueError(f"duplicate trust evidence during rebuild: {evidence_id!r}")
            self.record(TrustEvidence(subject_id=str(payload["subject_id"]), source_id=str(payload["source_id"]), category=EvidenceCategory(payload["category"]), outcome=EvidenceOutcome(payload["outcome"]), context=dict(payload.get("context", {})), confidence=float(payload.get("confidence", 1.0)), metadata=dict(payload.get("metadata", {})), id=evidence_id, at=payload["at"]))
