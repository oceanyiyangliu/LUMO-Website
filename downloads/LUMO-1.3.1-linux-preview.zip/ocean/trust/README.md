# Trust & Reputation Plane v0.1

Trust is an evidence-derived confidence boundary. It does not authenticate principals, grant permissions, or create delegation authority.

Architecture:

    TrustEvidence → ReputationRegistry → TrustEngine → TrustDecision

Evidence is immutable. Reputation is a rebuildable projection. Trust decisions are derived and deterministic.

Initial dimensions:
- reliability
- task success
- verification quality
- policy compliance
- communication reliability

Trust may inform governance, workforce allocation, routing, recovery, and future autonomous coordination, but never silently replaces authorization.
