from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Mapping

from ocean.core.clock import SYSTEM_CLOCK
from ocean.core.ids import new_id


class EvidenceCategory(str, Enum):
    RELIABILITY = "reliability"
    TASK_SUCCESS = "task_success"
    VERIFICATION_QUALITY = "verification_quality"
    POLICY_COMPLIANCE = "policy_compliance"
    COMMUNICATION_RELIABILITY = "communication_reliability"


class EvidenceOutcome(str, Enum):
    POSITIVE = "positive"
    NEGATIVE = "negative"
    NEUTRAL = "neutral"


@dataclass(frozen=True)
class TrustEvidence:
    subject_id: str
    source_id: str
    category: EvidenceCategory
    outcome: EvidenceOutcome
    context: Mapping[str, Any] = field(default_factory=dict)
    confidence: float = 1.0
    metadata: Mapping[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: new_id("evidence"))
    at: datetime = field(default_factory=lambda: SYSTEM_CLOCK.now())

    def __post_init__(self) -> None:
        if not self.subject_id.strip():
            raise ValueError("evidence subject_id must not be empty")
        if not self.source_id.strip():
            raise ValueError("evidence source_id must not be empty")
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError("evidence confidence must be between 0 and 1")


@dataclass(frozen=True)
class ReputationProfile:
    subject_id: str
    dimensions: Mapping[str, float]
    evidence_count: int
    confidence: float
    updated_at: datetime


@dataclass(frozen=True)
class TrustRequest:
    subject_id: str
    context: Mapping[str, Any] = field(default_factory=dict)
    required_confidence: float = 0.0

    def __post_init__(self) -> None:
        if not self.subject_id.strip():
            raise ValueError("trust subject_id must not be empty")
        if not 0.0 <= self.required_confidence <= 1.0:
            raise ValueError("required_confidence must be between 0 and 1")


@dataclass(frozen=True)
class TrustDecision:
    trusted: bool
    confidence: float
    reasons: tuple[str, ...] = ()
    profile: ReputationProfile | None = None

    @property
    def failed(self) -> bool:
        return not self.trusted
