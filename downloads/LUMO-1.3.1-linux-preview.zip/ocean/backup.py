"""Crash-safe backup and restore for LUMO SQLite state databases."""
from __future__ import annotations
import os
import sqlite3
import tempfile
from pathlib import Path


def verify_database(path: str | Path) -> bool:
    db = sqlite3.connect(str(Path(path).expanduser().resolve()))
    try:
        return db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    finally:
        db.close()


def backup_database(source: str | Path, destination: str | Path) -> Path:
    source = Path(source).expanduser().resolve()
    destination = Path(destination).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=destination.name + ".", dir=destination.parent)
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        src = sqlite3.connect(str(source))
        dst = sqlite3.connect(str(tmp))
        try:
            src.backup(dst)
            if dst.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise RuntimeError("backup integrity check failed")
            dst.close(); src.close()
            os.replace(tmp, destination)
        finally:
            try: src.close()
            except Exception: pass
            try: dst.close()
            except Exception: pass
    finally:
        tmp.unlink(missing_ok=True)
    return destination


def restore_database(backup: str | Path, destination: str | Path) -> Path:
    backup_path = Path(backup).expanduser().resolve()
    if not verify_database(backup_path):
        raise RuntimeError("refusing to restore an invalid SQLite backup")
    return backup_database(backup_path, destination)
