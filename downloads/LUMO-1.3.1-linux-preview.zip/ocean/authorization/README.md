# Authorization Plane

The Authorization Plane answers:

> Is this principal permitted to perform this capability/operation?

It does not authenticate principals and does not execute work.

The canonical permission requirements originate from `CapabilitySpec` via
`requires_permissions`.

Architecture:

    Principal
        ↓
    AuthorizationRequest
        ↓
    AuthorizationPolicy
        ↓
    AuthorizationDecision
        ↓
    Governance

The engine is deterministic and side-effect free.

Future extensions can add:

- scoped permissions;
- delegation;
- temporary grants;
- organization principals;
- trust levels;
- mission-specific authorization;
- policy versioning;
- durable authorization events.
