"""Authorization domain types."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, FrozenSet, Mapping, Tuple


@dataclass(frozen=True)
class Permission:
    """Canonical permission identifier."""

    name: str

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise ValueError("permission name must not be empty")


@dataclass(frozen=True)
class AuthorizationRequest:
    """Pure authorization input."""

    principal_id: str
    capability: str
    operation: str
    required_permissions: FrozenSet[str] = frozenset()
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class AuthorizationDecision:
    """Deterministic authorization result."""

    allowed: bool
    reasons: Tuple[str, ...] = ()
    
    @property
    def denied(self) -> bool:
        return not self.allowed
