"""Authorization policy contracts and deterministic implementations."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import FrozenSet, Iterable, Mapping, Set

from .types import AuthorizationRequest


class AuthorizationPolicy(ABC):
    """Policy boundary for authorization decisions."""

    @abstractmethod
    def allowed_permissions(self, principal_id: str) -> FrozenSet[str]:
        raise NotImplementedError

    def evaluate(self, request: AuthorizationRequest) -> tuple[bool, tuple[str, ...]]:
        granted = self.allowed_permissions(request.principal_id)
        missing = sorted(set(request.required_permissions) - set(granted))

        if missing:
            return (
                False,
                (
                    f"principal {request.principal_id!r} lacks required "
                    f"permissions: {', '.join(missing)}",
                ),
            )

        return True, ()


class StaticAuthorizationPolicy(AuthorizationPolicy):
    """Deterministic permission mapping.

    This is intentionally a policy implementation, not the security
    authority for identity or authentication.
    """

    def __init__(
        self,
        permissions: Mapping[str, Iterable[str]] | None = None,
    ) -> None:
        self._permissions: dict[str, FrozenSet[str]] = {
            principal_id: frozenset(values)
            for principal_id, values in (permissions or {}).items()
        }

    def allowed_permissions(self, principal_id: str) -> FrozenSet[str]:
        return self._permissions.get(principal_id, frozenset())
