"""Authorization decision engine."""

from __future__ import annotations

from .policy import AuthorizationPolicy
from .types import AuthorizationDecision, AuthorizationRequest


class AuthorizationEngine:
    """Pure authorization boundary."""

    def __init__(self, policy: AuthorizationPolicy) -> None:
        self._policy = policy

    @property
    def policy(self) -> AuthorizationPolicy:
        return self._policy

    def authorize(self, request: AuthorizationRequest) -> AuthorizationDecision:
        allowed, reasons = self._policy.evaluate(request)
        return AuthorizationDecision(
            allowed=allowed,
            reasons=reasons,
        )
