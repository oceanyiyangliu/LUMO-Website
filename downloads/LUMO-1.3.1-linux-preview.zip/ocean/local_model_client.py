from __future__ import annotations

import json
import urllib.request
from dataclasses import dataclass
from typing import Any


@dataclass
class LocalFunctionCall:
    type: str
    name: str
    arguments: str
    call_id: str


@dataclass
class LocalResponse:
    id: str
    output: list[Any]
    output_text: str = ""


class LocalOllamaResponsesClient:
    """Small Responses-shaped adapter backed directly by Ollama's local HTTP API."""

    def __init__(self, model: str, base_url: str = "http://127.0.0.1:11434") -> None:
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.messages: list[dict[str, Any]] = []
        self._counter = 0

    @staticmethod
    def _tools(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
        result = []
        for tool in tools:
            if tool.get("type") != "function":
                continue
            result.append({"type": "function", "function": {
                "name": tool["name"],
                "description": tool.get("description", ""),
                "parameters": tool.get("parameters", {"type": "object", "properties": {}}),
            }})
        return result

    @staticmethod
    def _content(items: Any) -> Any:
        if isinstance(items, str):
            return items
        if not isinstance(items, list):
            return str(items)
        out = []
        images = []
        for item in items:
            kind = item.get("type")
            if kind in {"input_text", "text"}:
                out.append({"type": "text", "text": item.get("text", "")})
            elif kind in {"input_image", "image_url"}:
                url = item.get("image_url", "")
                if isinstance(url, dict):
                    url = url.get("url", "")
                if str(url).startswith("data:image/") and "," in str(url):
                    images.append(str(url).split(",", 1)[1])
        if images:
            # Ollama's native chat API keeps images beside the text content.
            return {"text": "\n".join(item.get("text", "") for item in out), "images": images}
        # Ollama expects ordinary text as a string, not OpenAI-style content blocks.
        return "\n".join(item.get("text", "") for item in out).strip()

    def _append_input(self, items: Any) -> None:
        if isinstance(items, str):
            self.messages.append({"role": "user", "content": items})
            return
        if not isinstance(items, list):
            self.messages.append({"role": "user", "content": str(items)})
            return
        user_content = []
        for item in items:
            if item.get("role") in {"user", "assistant"}:
                self.messages.append({"role": item.get("role"), "content": str(item.get("content", ""))})
            elif item.get("type") == "function_call_output":
                self.messages.append({
                    "role": "tool",
                    "tool_call_id": item.get("call_id", ""),
                    "content": item.get("output", ""),
                })
            elif item.get("role") == "user":
                user_content.append({"type": "text", "text": str(item.get("content", ""))})
            elif item.get("type") in {"input_text", "input_image"}:
                user_content.append(item)
        if user_content:
            converted = self._content(user_content)
            if isinstance(converted, dict):
                self.messages.append({"role": "user", "content": converted["text"], "images": converted["images"]})
            else:
                self.messages.append({"role": "user", "content": converted})

    def create(self, *, model: str | None = None, instructions: str = "", input: Any = None,
               tools: list[dict[str, Any]] | None = None, **_: Any) -> LocalResponse:
        if not self.messages and instructions:
            self.messages.append({"role": "system", "content": instructions})
        self._append_input(input)
        payload = {
            "model": model or self.model,
            "stream": False,
            "keep_alive": 0,
            "messages": self.messages,
        }
        if tools:
            payload["tools"] = self._tools(tools)
            payload["tool_choice"] = "auto"
        request = urllib.request.Request(
            f"{self.base_url}/api/chat",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=120) as response:
            body = json.loads(response.read().decode("utf-8"))
        message = body.get("message", {})
        assistant = {"role": "assistant", "content": message.get("content", "")}
        tool_calls = message.get("tool_calls") or []
        output: list[Any] = []
        for index, call in enumerate(tool_calls):
            fn = call.get("function", {})
            call_id = call.get("id") or f"ollama-call-{self._counter}-{index}"
            output.append(LocalFunctionCall("function_call", str(fn.get("name", "")), json.dumps(fn.get("arguments", {})), call_id))
        if tool_calls:
            assistant["tool_calls"] = tool_calls
        self.messages.append(assistant)
        self._counter += 1
        return LocalResponse(
            id=f"ollama-response-{self._counter}",
            output=output,
            output_text=str(message.get("content", "") or ""),
        )
