from __future__ import annotations
from typing import Dict,Iterable,Optional
from .types import Credential,CredentialStatus

class CredentialRegistry:
    def __init__(self): self._credentials:Dict[str,Credential]={}
    def register(self,credential):
        if credential.status is not CredentialStatus.ACTIVE: raise ValueError("only active credentials may be registered")
        if credential.id in self._credentials: raise KeyError(f"credential already registered: {credential.id!r}")
        self._credentials[credential.id]=credential
    def get(self,credential_id): return self._credentials.get(credential_id)
    def require(self,credential_id):
        credential=self.get(credential_id)
        if credential is None: raise KeyError(f"unknown credential: {credential_id!r}")
        return credential
    def revoke(self,credential_id):
        credential=self.require(credential_id)
        revoked=Credential(principal_id=credential.principal_id,kind=credential.kind,metadata=dict(credential.metadata),expires_at=credential.expires_at,status=CredentialStatus.REVOKED,id=credential.id,created_at=credential.created_at)
        del self._credentials[credential_id]
        return revoked
    def list(self): return tuple(self._credentials.values())
    def rebuild(self,events:Iterable):
        self._credentials.clear()
        for event in events:
            if event.type=="CredentialCreated":
                payload=event.payload
                credential=Credential(principal_id=str(payload["principal_id"]),kind=str(payload["kind"]),metadata=dict(payload.get("metadata",{})),expires_at=payload.get("expires_at"),id=str(payload["credential_id"]),created_at=payload["created_at"])
                self._credentials[credential.id]=credential
            elif event.type=="CredentialRevoked": self._credentials.pop(str(event.payload["credential_id"]),None)
