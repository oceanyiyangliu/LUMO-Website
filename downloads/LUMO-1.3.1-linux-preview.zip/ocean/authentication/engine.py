from __future__ import annotations
from typing import Any,Callable,Mapping
from .registry import CredentialRegistry
from .types import AuthenticationDecision,AuthenticationRequest

class AuthenticationEngine:
    def __init__(self,registry:CredentialRegistry,verifier:Callable[[Any,Any,Mapping[str,Any]],bool]):
        self._registry=registry
        self._verifier=verifier
    def authenticate(self,request):
        credential=self._registry.get(request.credential_id)
        if credential is None: return AuthenticationDecision(False,reasons=("unknown credential",))
        if credential.expired(): return AuthenticationDecision(False,reasons=("credential expired",))
        try: valid=bool(self._verifier(request.proof,credential,request.metadata))
        except Exception: return AuthenticationDecision(False,reasons=("credential verification failed",))
        if not valid: return AuthenticationDecision(False,reasons=("invalid credential proof",))
        return AuthenticationDecision(True,principal_id=credential.principal_id)
