from __future__ import annotations
from datetime import datetime
from typing import Any,Mapping,Optional
from ocean.core.clock import SYSTEM_CLOCK
from ocean.core.ids import new_id
from ocean.domain.event import Event
from .registry import CredentialRegistry
from .types import Credential

class CredentialController:
    def __init__(self,registry:CredentialRegistry,event_bus): self._registry=registry; self._event_bus=event_bus
    def create(self,*,principal_id:str,kind:str,metadata:Optional[Mapping[str,Any]]=None,expires_at:Optional[datetime]=None,credential_id:Optional[str]=None):
        credential=Credential(principal_id=principal_id,kind=kind,metadata=dict(metadata or {}),expires_at=expires_at,id=credential_id or new_id("credential"))
        self._registry.register(credential)
        self._event_bus.publish(Event(type="CredentialCreated",payload={"credential_id":credential.id,"principal_id":credential.principal_id,"kind":credential.kind,"metadata":dict(credential.metadata),"expires_at":credential.expires_at,"created_at":credential.created_at}))
        return credential
    def revoke(self,credential_id:str):
        credential=self._registry.revoke(credential_id)
        self._event_bus.publish(Event(type="CredentialRevoked",payload={"credential_id":credential.id,"principal_id":credential.principal_id,"revoked_at":SYSTEM_CLOCK.now()}))
        return credential
