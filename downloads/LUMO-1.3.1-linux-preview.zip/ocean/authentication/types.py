from __future__ import annotations
from dataclasses import dataclass,field
from datetime import datetime
from enum import Enum
from typing import Any,Mapping,Optional
from ocean.core.clock import SYSTEM_CLOCK
from ocean.core.ids import new_id

class CredentialStatus(str,Enum):
    ACTIVE="active"
    REVOKED="revoked"

@dataclass(frozen=True)
class Credential:
    principal_id:str
    kind:str
    metadata:Mapping[str,Any]=field(default_factory=dict)
    expires_at:Optional[datetime]=None
    status:CredentialStatus=CredentialStatus.ACTIVE
    id:str=field(default_factory=lambda:new_id("credential"))
    created_at:datetime=field(default_factory=lambda:SYSTEM_CLOCK.now())
    def __post_init__(self):
        if not self.principal_id.strip(): raise ValueError("principal_id must not be empty")
        if not self.kind.strip(): raise ValueError("credential kind must not be empty")
        if self.expires_at is not None and self.expires_at<=self.created_at: raise ValueError("credential expiration must be after creation")
    def expired(self,now=None):
        current=now or SYSTEM_CLOCK.now()
        return self.expires_at is not None and current>=self.expires_at

@dataclass(frozen=True)
class AuthenticationRequest:
    credential_id:str
    proof:Any
    metadata:Mapping[str,Any]=field(default_factory=dict)

@dataclass(frozen=True)
class AuthenticationDecision:
    authenticated:bool
    principal_id:Optional[str]=None
    reasons:tuple[str,...]=()
    @property
    def failed(self): return not self.authenticated
