from .registry import DelegationRegistry


class AuthorityEngine:
    """Deterministic evaluation of effective delegated authority."""

    def __init__(self, registry: DelegationRegistry):
        self._registry = registry

    @property
    def registry(self) -> DelegationRegistry:
        return self._registry

    def permissions(self, principal_id, *, now=None):
        result = set()
        for grant in self._registry.incoming(principal_id):
            if not grant.expired(now):
                result.update(grant.permissions)
        return frozenset(result)

    def can(self, principal_id, permission, *, now=None):
        return permission in self.permissions(principal_id, now=now)

    def can_delegate(self, delegator_id, permissions, *, now=None):
        requested = set(permissions)
        if not requested:
            return True

        visiting = set()
        memo = {}

        def effective(principal_id):
            if principal_id in memo:
                return memo[principal_id]
            if principal_id in visiting:
                return frozenset()

            visiting.add(principal_id)
            result = set()

            for grant in self._registry.incoming(principal_id):
                if grant.expired(now):
                    continue
                result.update(grant.permissions)

            visiting.remove(principal_id)
            memo[principal_id] = frozenset(result)
            return memo[principal_id]

        return requested.issubset(effective(delegator_id))
