from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, FrozenSet, Mapping, Optional

from ocean.core.ids import new_id
from ocean.core.clock import SYSTEM_CLOCK


class DelegationStatus(str, Enum):
    ACTIVE = "active"
    REVOKED = "revoked"


@dataclass(frozen=True)
class DelegationGrant:
    delegator_id: str
    delegate_id: str
    permissions: FrozenSet[str]
    constraints: Mapping[str, Any] = field(default_factory=dict)
    parent_grant_id: Optional[str] = None
    expires_at: Optional[datetime] = None
    status: DelegationStatus = DelegationStatus.ACTIVE
    metadata: Mapping[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: new_id("delegation"))
    created_at: datetime = field(default_factory=lambda: SYSTEM_CLOCK.now())

    def __post_init__(self) -> None:
        if not self.delegator_id.strip():
            raise ValueError("delegator_id must not be empty")
        if not self.delegate_id.strip():
            raise ValueError("delegate_id must not be empty")
        if self.delegator_id == self.delegate_id:
            raise ValueError("delegator and delegate must differ")
        if not self.permissions:
            raise ValueError("delegation must contain at least one permission")
        if any(not permission.strip() for permission in self.permissions):
            raise ValueError("delegation permissions must not be empty")
        if self.expires_at is not None and self.expires_at <= self.created_at:
            raise ValueError("expires_at must be later than created_at")

    def expired(self, now: Optional[datetime] = None) -> bool:
        current = now or SYSTEM_CLOCK.now()
        return self.expires_at is not None and current >= self.expires_at
