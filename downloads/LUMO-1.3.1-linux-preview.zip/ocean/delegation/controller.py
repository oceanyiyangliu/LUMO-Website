from ocean.domain.event import Event
from ocean.core.ids import new_id

from .registry import DelegationRegistry
from .types import DelegationGrant


class DelegationController:
    """Mutation boundary for delegation grants."""

    def __init__(self, event_bus=None, registry=None):
        self._event_bus = event_bus
        self._registry = registry or DelegationRegistry()

    @property
    def registry(self):
        return self._registry

    def create(
        self,
        delegator_id,
        delegate_id,
        permissions,
        *,
        constraints=None,
        parent_grant_id=None,
        expires_at=None,
        metadata=None,
        delegation_id=None,
    ):
        grant = DelegationGrant(
            delegator_id=delegator_id,
            delegate_id=delegate_id,
            permissions=frozenset(permissions),
            constraints=dict(constraints or {}),
            parent_grant_id=parent_grant_id,
            expires_at=expires_at,
            metadata=dict(metadata or {}),
            id=delegation_id or new_id("delegation"),
        )
        self._registry.register(grant)
        self._publish(Event(
            type="DelegationCreated",
            aggregate_type="delegation",
            aggregate_id=grant.id,
            payload={
                "delegation_id": grant.id,
                "delegator_id": grant.delegator_id,
                "delegate_id": grant.delegate_id,
                "permissions": sorted(grant.permissions),
                "constraints": dict(grant.constraints),
                "parent_grant_id": grant.parent_grant_id,
                "expires_at": grant.expires_at,
                "metadata": dict(grant.metadata),
                "created_at": grant.created_at,
            },
        ))
        return grant

    def revoke(self, delegation_id):
        grant = self._registry.revoke(delegation_id)
        self._publish(Event(
            type="DelegationRevoked",
            aggregate_type="delegation",
            aggregate_id=delegation_id,
            payload={"delegation_id": delegation_id},
        ))
        return grant

    def rebuild(self, events):
        self._registry.rebuild(events)

    def _publish(self, event):
        if self._event_bus is not None:
            self._event_bus.publish(event)
