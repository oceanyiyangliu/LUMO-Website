from datetime import datetime

from ocean.domain.event import Event

from .types import DelegationGrant, DelegationStatus


def _datetime(value):
    if value is None or isinstance(value, datetime):
        return value
    return datetime.fromisoformat(value)


class DelegationRegistry:
    """Rebuildable active-delegation projection."""

    def __init__(self):
        self._grants = {}

    def register(self, grant):
        if grant.id in self._grants:
            raise ValueError(f"delegation already registered: {grant.id}")
        if grant.status != DelegationStatus.ACTIVE:
            raise ValueError("only active delegations may be registered")
        self._grants[grant.id] = grant
        return grant

    def revoke(self, delegation_id):
        grant = self.require(delegation_id)
        revoked = DelegationGrant(
            delegator_id=grant.delegator_id,
            delegate_id=grant.delegate_id,
            permissions=grant.permissions,
            constraints=dict(grant.constraints),
            parent_grant_id=grant.parent_grant_id,
            expires_at=grant.expires_at,
            status=DelegationStatus.REVOKED,
            metadata=dict(grant.metadata),
            id=grant.id,
            created_at=grant.created_at,
        )
        del self._grants[delegation_id]
        return revoked

    def get(self, delegation_id):
        return self._grants.get(delegation_id)

    def require(self, delegation_id):
        grant = self.get(delegation_id)
        if grant is None:
            raise KeyError(f"unknown delegation: {delegation_id}")
        return grant

    def list(self):
        return tuple(self._grants.values())

    def incoming(self, principal_id):
        return tuple(
            grant for grant in self._grants.values()
            if grant.delegate_id == principal_id
        )

    def outgoing(self, principal_id):
        return tuple(
            grant for grant in self._grants.values()
            if grant.delegator_id == principal_id
        )

    def rebuild(self, events):
        self._grants.clear()
        for event in events:
            if event.type == "DelegationCreated":
                payload = event.payload
                delegation_id = payload["delegation_id"]
                if delegation_id in self._grants:
                    raise ValueError(
                        f"duplicate delegation id during rebuild: {delegation_id}"
                    )
                self._grants[delegation_id] = DelegationGrant(
                    delegator_id=payload["delegator_id"],
                    delegate_id=payload["delegate_id"],
                    permissions=frozenset(payload["permissions"]),
                    constraints=dict(payload.get("constraints", {})),
                    parent_grant_id=payload.get("parent_grant_id"),
                    expires_at=_datetime(payload.get("expires_at")),
                    metadata=dict(payload.get("metadata", {})),
                    id=delegation_id,
                    created_at=_datetime(payload["created_at"]),
                )
            elif event.type == "DelegationRevoked":
                self._grants.pop(event.payload["delegation_id"], None)
