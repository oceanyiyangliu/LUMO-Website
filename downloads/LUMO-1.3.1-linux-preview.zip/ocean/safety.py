"""Scoped stop authority and runaway circuit breakers."""
from __future__ import annotations
from dataclasses import dataclass
from threading import RLock
from time import monotonic
from typing import Callable

@dataclass(frozen=True)
class StopReceipt:
    scope: str
    scope_id: str
    engaged_at: float
    reason: str
    acknowledgement_required: bool = True

class StopAuthority:
    def __init__(self): self._global=False; self._scopes=set(); self._lock=RLock(); self._receipts=[]
    def engage(self, scope:str="global", scope_id:str="lumo", reason:str="operator") -> StopReceipt:
        if scope not in {"global","mission","device","agent","world"}: raise ValueError("invalid stop scope")
        if not scope_id: raise ValueError("scope_id is required")
        with self._lock:
            if scope=="global": self._global=True
            self._scopes.add((scope,scope_id)); receipt=StopReceipt(scope,scope_id,monotonic(),reason); self._receipts.append(receipt); return receipt
    def release(self, scope:str="global", scope_id:str="lumo"):
        with self._lock:
            if scope=="global": self._global=False
            self._scopes.discard((scope,scope_id))
    def blocked(self, *, mission_id=None, device_id=None, agent_id=None, world_id=None)->bool:
        with self._lock:
            return self._global or any(x in self._scopes for x in (("mission",mission_id),("device",device_id),("agent",agent_id),("world",world_id)) if x[1])
    def receipts(self):
        with self._lock: return tuple(self._receipts)

class FailureCircuitBreaker:
    def __init__(self, threshold:int=5, window_seconds:float=60):
        if threshold<=0 or window_seconds<=0: raise ValueError("invalid circuit policy")
        self.threshold=threshold; self.window=window_seconds; self._failures={}; self._open=set(); self._lock=RLock()
    def record_failure(self,key:str,now:float|None=None):
        t=monotonic() if now is None else now
        with self._lock:
            values=[v for v in self._failures.get(key,[]) if t-v<self.window]; values.append(t); self._failures[key]=values
            if len(values)>=self.threshold: self._open.add(key)
            return key in self._open
    def allow(self,key:str)->bool:
        with self._lock: return key not in self._open
    def reset(self,key:str):
        with self._lock: self._failures.pop(key,None); self._open.discard(key)

class ResourceCircuitBreaker:
    def __init__(self, max_value:float):
        if max_value<=0: raise ValueError("max_value must be positive")
        self.max_value=max_value
    def allow(self, observed:float)->bool:
        return float(observed) <= self.max_value

class RunawayDetector:
    def __init__(self, max_iterations:int=100):
        if max_iterations<=0: raise ValueError("max_iterations must be positive")
        self.max_iterations=max_iterations
    def check(self, iterations:int)->bool: return int(iterations) <= self.max_iterations


class ThresholdCircuitBreaker:
    def __init__(self, threshold:int=5, window_seconds:float=60):
        if threshold<=0 or window_seconds<=0: raise ValueError("invalid circuit policy")
        self.threshold=threshold; self.window=window_seconds; self._hits={}; self._open=set(); self._lock=RLock()
    def record(self,key:str,now:float|None=None)->bool:
        t=monotonic() if now is None else now
        with self._lock:
            hits=[v for v in self._hits.get(key,[]) if t-v<self.window]; hits.append(t); self._hits[key]=hits
            if len(hits)>=self.threshold: self._open.add(key)
            return key in self._open
    def allow(self,key:str)->bool:
        with self._lock: return key not in self._open
    def reset(self,key:str)->None:
        with self._lock: self._hits.pop(key,None); self._open.discard(key)


class NetworkAnomalyCircuitBreaker(ThresholdCircuitBreaker):
    """Named circuit-breaker policy for repeated network anomalies."""
    def record_anomaly(self, endpoint: str, now: float | None = None) -> bool:
        return self.record(endpoint, now)


class ModelLoopCircuitBreaker(ThresholdCircuitBreaker):
    """Open when an agent repeats the same model/action fingerprint too often."""
    def record_loop(self, agent_id:str, fingerprint:str, now:float|None=None)->bool:
        return self.record(f"{agent_id}:{fingerprint}", now)


class ApprovalTimeoutCircuitBreaker:
    def __init__(self, timeout_seconds:float=300):
        if timeout_seconds<=0: raise ValueError("timeout_seconds must be positive")
        self.timeout=timeout_seconds
    def expired(self, requested_at:float, now:float|None=None)->bool:
        current=monotonic() if now is None else now
        return current-requested_at >= self.timeout


class SafetyPolicySimulator:
    """Evaluate proposed side effects without executing them."""
    def __init__(self, stop:StopAuthority): self.stop=stop
    def evaluate(self, *, operation:str, mission_id:str|None=None, device_id:str|None=None, world_id:str|None=None, irreversible:bool=False, approval_granted:bool=False)->dict:
        reasons=[]
        if self.stop.blocked(mission_id=mission_id,device_id=device_id,world_id=world_id): reasons.append("stop_authority")
        if irreversible and not approval_granted: reasons.append("approval_required")
        return {"allowed":not reasons,"operation":operation,"reasons":tuple(reasons),"would_execute":False}


class SafetyInvariantDashboard:
    def __init__(self, stop:StopAuthority): self.stop=stop
    def status(self, *, active_assignments:int=0, active_worlds:int=0, verified_completions:int=0, total_completions:int=0)->dict:
        checks={"stop_authority_available":True,"no_active_assignments_after_global_stop":not (self.stop.blocked() and active_assignments>0),"no_active_worlds_after_global_stop":not (self.stop.blocked() and active_worlds>0),"verified_completion_discipline":verified_completions>=total_completions}
        return {"healthy":all(checks.values()),"checks":checks}
