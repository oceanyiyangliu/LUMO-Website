"""Cross-cutting reliability primitives for the LUMO kernel.

These primitives are deliberately provider-agnostic and side-effect free except
for the caller-supplied cleanup hooks. They provide durable-execution building
blocks without coupling the mission layer to a particular database or model.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
import hashlib
import json
import threading
from typing import Any, Callable, Iterable


class LeaseState(str, Enum):
    ACTIVE = "active"
    EXPIRED = "expired"
    RELEASED = "released"


@dataclass
class WorkerLease:
    lease_id: str
    task_id: str
    worker_id: str
    acquired_at: datetime
    heartbeat_at: datetime
    expires_at: datetime
    state: LeaseState = LeaseState.ACTIVE

    def live(self, now: datetime) -> bool:
        return self.state is LeaseState.ACTIVE and now < self.expires_at


class WorkerLeaseBook:
    """Thread-safe lease book with stale-worker protection."""
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._leases: dict[str, WorkerLease] = {}

    def acquire(self, task_id: str, worker_id: str, ttl: float, *, lease_id: str, now: datetime | None = None) -> WorkerLease:
        if not task_id or not worker_id or ttl <= 0:
            raise ValueError("task_id, worker_id and positive ttl are required")
        now = now or datetime.now(timezone.utc)
        with self._lock:
            existing = next((x for x in self._leases.values() if x.task_id == task_id and x.state is LeaseState.ACTIVE), None)
            if existing and existing.live(now):
                if existing.worker_id != worker_id:
                    raise RuntimeError("task already leased by another worker")
                return existing
            lease = WorkerLease(lease_id, task_id, worker_id, now, now, now + timedelta(seconds=ttl))
            self._leases[lease_id] = lease
            return lease

    def heartbeat(self, lease_id: str, worker_id: str, ttl: float, *, now: datetime | None = None) -> WorkerLease:
        now = now or datetime.now(timezone.utc)
        with self._lock:
            lease = self._leases[lease_id]
            if lease.worker_id != worker_id or not lease.live(now):
                raise RuntimeError("stale or expired worker lease")
            lease.heartbeat_at = now
            lease.expires_at = now + timedelta(seconds=ttl)
            return lease

    def release(self, lease_id: str, worker_id: str) -> None:
        with self._lock:
            lease = self._leases[lease_id]
            if lease.worker_id != worker_id:
                raise RuntimeError("stale worker cannot release lease")
            lease.state = LeaseState.RELEASED

    def expire_due(self, *, now: datetime | None = None) -> tuple[WorkerLease, ...]:
        now = now or datetime.now(timezone.utc)
        with self._lock:
            expired = []
            for lease in self._leases.values():
                if lease.state is LeaseState.ACTIVE and lease.expires_at <= now:
                    lease.state = LeaseState.EXPIRED
                    expired.append(lease)
            return tuple(expired)


@dataclass(frozen=True)
class IdempotencyRecord:
    key: str
    fingerprint: str
    result: Any


class IdempotencyLedger:
    """In-memory idempotency boundary; persistence can be layered underneath."""
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._records: dict[str, IdempotencyRecord] = {}

    @staticmethod
    def fingerprint(operation: str, arguments: Any) -> str:
        payload = json.dumps({"operation": operation, "arguments": arguments}, sort_keys=True, default=str, separators=(",", ":"))
        return hashlib.sha256(payload.encode()).hexdigest()

    def get(self, key: str, fingerprint: str) -> Any | None:
        with self._lock:
            record = self._records.get(key)
            if record is None:
                return None
            if record.fingerprint != fingerprint:
                raise RuntimeError("idempotency key reused with different operation")
            return record.result

    def commit(self, key: str, fingerprint: str, result: Any) -> Any:
        with self._lock:
            existing = self._records.get(key)
            if existing:
                if existing.fingerprint != fingerprint:
                    raise RuntimeError("idempotency key reused with different operation")
                return existing.result
            self._records[key] = IdempotencyRecord(key, fingerprint, result)
            return result


@dataclass(frozen=True)
class PermissionGrant:
    operation: str
    scope: str = "*"
    expires_at: datetime | None = None
    one_shot: bool = False


class PermissionBoundary:
    """Small deny-by-default policy primitive for capability admission."""
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._grants: list[PermissionGrant] = []
        self._consumed: set[tuple[str, str]] = set()

    def grant(self, operation: str, *, scope: str = "*", expires_at: datetime | None = None, one_shot: bool = False) -> PermissionGrant:
        grant = PermissionGrant(operation, scope, expires_at, one_shot)
        with self._lock:
            self._grants.append(grant)
        return grant

    def allowed(self, operation: str, scope: str = "*", *, now: datetime | None = None) -> bool:
        now = now or datetime.now(timezone.utc)
        with self._lock:
            for grant in self._grants:
                if grant.operation not in {operation, "*"} or grant.scope not in {scope, "*"}:
                    continue
                if grant.expires_at and now >= grant.expires_at:
                    continue
                marker = (grant.operation, grant.scope)
                if grant.one_shot and marker in self._consumed:
                    continue
                if grant.one_shot:
                    self._consumed.add(marker)
                return True
            return False


@dataclass(frozen=True)
class VerificationResult:
    passed: bool
    reason: str
    evidence: tuple[dict[str, Any], ...] = ()


class ArtifactVerifier:
    """Verify concrete artifact predicates rather than action claims."""
    @staticmethod
    def file_exists(path: str) -> VerificationResult:
        from pathlib import Path
        p = Path(path).expanduser()
        if not p.is_file():
            return VerificationResult(False, "artifact file does not exist")
        digest = hashlib.sha256(p.read_bytes()).hexdigest()
        return VerificationResult(True, "artifact exists", ({"kind": "file", "path": str(p), "sha256": digest, "size": p.stat().st_size},))


class CleanupStack:
    """LIFO cleanup with complete-attempt semantics and error collection."""
    def __init__(self) -> None:
        self._hooks: list[tuple[str, Callable[[], Any]]] = []

    def push(self, name: str, hook: Callable[[], Any]) -> None:
        self._hooks.append((name, hook))

    def close(self) -> list[dict[str, str]]:
        errors: list[dict[str, str]] = []
        while self._hooks:
            name, hook = self._hooks.pop()
            try:
                hook()
            except Exception as exc:
                errors.append({"name": name, "error": str(exc)[:500]})
        return errors


@dataclass(frozen=True)
class CausalTrace:
    trace_id: str
    correlation_id: str
    causation_id: str | None = None
    parent_id: str | None = None


class FaultInjector:
    """Deterministic test-only fault hooks."""
    def __init__(self, faults: Iterable[str] = ()) -> None:
        self._faults = set(faults)

    def trip(self, point: str) -> None:
        if point in self._faults:
            raise RuntimeError(f"injected fault: {point}")

    def enabled(self, point: str) -> bool:
        return point in self._faults
