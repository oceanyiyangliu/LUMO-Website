from __future__ import annotations

import argparse
import os
import sqlite3
import sys
import threading
import time
import json
import urllib.error
import urllib.request
from pathlib import Path

# Lazy-loaded compatibility hooks. Keeping these names at module scope preserves
# the CLI's test/mocking surface without importing the full autonomous stack on startup.
AutonomousImprovementRuntime = None
build_strategic_model = None
StrategicMissionPlanner = None
MissionEngine = None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="lumo",
        description="LUMO autonomous agent operating system command line interface.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    mission = subparsers.add_parser(
        "mission",
        help="run a strategic autonomous engineering mission",
    )
    mission.add_argument(
        "goal",
        nargs="?",
        help="what LUMO should accomplish",
    )
    mission.add_argument(
        "--resume",
        metavar="MISSION_ID",
        help="resume a persisted mission from its durable event history",
    )
    mission.add_argument(
        "--max-replans",
        type=int,
        default=8,
        help="maximum mission replanning cycles",
    )
    mission.add_argument(
        "--watch",
        dest="watch",
        action="store_true",
        default=True,
        help="run the mission while continuously displaying live status (default)",
    )
    mission.add_argument(
        "--no-watch",
        dest="watch",
        action="store_false",
        help="run silently and print only the final mission result",
    )
    mission.add_argument(
        "--interval",
        type=float,
        default=1.0,
        help="status refresh interval in seconds when watching",
    )

    status = subparsers.add_parser(
        "status",
        help="show live status for a persisted mission",
    )
    status.add_argument(
        "mission_id",
        help="mission ID to inspect",
    )
    status.add_argument(
        "--watch",
        action="store_true",
        help="continuously refresh persisted mission status",
    )
    status.add_argument(
        "--interval",
        type=float,
        default=1.0,
        help="status refresh interval in seconds",
    )

    computer = subparsers.add_parser(
        "computer",
        help="run a vision-guided task on the local macOS GUI",
    )
    computer.add_argument(
        "objective",
        help="what LUMO should accomplish on the computer",
    )
    computer.add_argument(
        "--max-steps",
        type=int,
        default=80,
        help="maximum GUI actions before stopping",
    )
    computer.add_argument(
        "--model",
        default="auto",
        help="Local vision model (auto routes through the installed Ollama fleet)",
    )
    computer.add_argument(
        "--allow-computer-actions",
        action="store_true",
        help="explicitly authorize LUMO to click/type/control the local GUI",
    )

    improve = subparsers.add_parser(
        "improve",
        help="run one autonomous self-improvement mission",
    )
    improve.add_argument(
        "objective",
        help="what LUMO should improve",
    )
    improve.add_argument(
        "--hypothesis",
        default=None,
        help="optional improvement hypothesis",
    )
    improve.add_argument(
        "--rationale",
        default=None,
        help="optional improvement rationale",
    )
    improve.add_argument(
        "--test-timeout",
        type=float,
        default=120.0,
        help="candidate test timeout in seconds",
    )

    overnight = subparsers.add_parser(
        "improve-overnight",
        help="run a bounded, local-first self-improvement campaign",
    )
    overnight.add_argument("objective", help="what LUMO should improve")
    overnight.add_argument("--hours", type=float, default=10.0, help="hard wall-clock budget")
    overnight.add_argument("--model-calls", type=int, default=8, help="hard local model-call budget")
    overnight.add_argument("--candidates", type=int, default=8, help="hard candidate budget")
    overnight.add_argument("--test-timeout", type=float, default=120.0, help="candidate test timeout")
    overnight.add_argument("--model", default="qwen3:0.6b", help="local Ollama model; larger models must still pass live RAM admission")

    forever = subparsers.add_parser(
        "improve-forever",
        help="run a durable local-first self-improvement worker while the device is available",
    )
    forever.add_argument("objective", help="what LUMO should continuously improve")
    forever.add_argument("--model", default="qwen3:0.6b", help="local Ollama model; larger models must still pass live RAM admission")
    forever.add_argument("--cycle-delay", type=float, default=30.0, help="delay between improvement cycles")
    forever.add_argument("--idle-delay", type=float, default=300.0, help="delay after a failed/blocked cycle")
    forever.add_argument("--test-timeout", type=float, default=120.0, help="candidate test timeout")

    serve = subparsers.add_parser(
        "serve",
        help="start the local LUMO HTTP control plane",
    )
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8765)

    doctor_cmd = subparsers.add_parser("doctor", help="run fail-safe LUMO health diagnostics")
    doctor_cmd.add_argument("--json", action="store_true", help="print machine-readable diagnostics")

    deep = subparsers.add_parser("test-deep", help="run the complete deterministic regression suite")
    deep.add_argument("--json", action="store_true", help="print machine-readable test output")

    return parser


def _print_status(status) -> None:
    print("\033[2J\033[H", end="")
    print(f"MISSION {status.mission_id}")
    print(f"STATUS {status.status.upper()}")
    print(f"PROGRESS {status.progress:.0%}")
    print()
    print("OBJECTIVES")

    for objective in status.objective_statuses:
        if objective.status == "completed":
            marker = "✓"
        elif objective.status == "running":
            marker = "◉"
        elif objective.status == "queued":
            marker = "○"
        elif objective.status == "failed":
            marker = "✗"
        else:
            marker = "·"

        progress = f"{objective.progress:.0%}"
        activity = (
            f" — {objective.current_activity}"
            if objective.current_activity
            else ""
        )

        print(
            f"{marker} {objective.objective or objective.objective_id}"
            f" [{progress}]{activity}"
        )

    print()
    print(
        f"ACTIVE {status.active_objectives}  "
        f"QUEUED {status.queued_objectives}  "
        f"COMPLETED {status.completed_objectives}  "
        f"FAILED {status.failed_objectives}"
    )
    print(f"VERIFICATION {status.verification_state}")
    print(flush=True)

    if status.current_activity:
        print(f"CURRENT ACTIVITY {status.current_activity}")

    if status.latest_error:
        print(f"ERROR {status.latest_error}")


def _persisted_mission_goal(store: SQLiteEventStore, mission_id: str) -> str:
    """Return the original goal recorded for a mission resume request."""
    for event in store.list_after_sequence(0):
        if event.type != "MissionStarted":
            continue
        if event.aggregate_id != mission_id and event.payload.get("mission_id") != mission_id:
            continue
        goal = str(event.payload.get("goal", "")).strip()
        if goal:
            return goal
    raise ValueError(f"no persisted mission goal found for {mission_id!r}")


def _status_reader(repository_root: Path, mission_id: str | None = None):
    from ocean.observability.status import LiveStatusReader
    from eventing.sqlite_store import SQLiteEventStore
    """Open the canonical persisted mission event stream.

    Mission CLI execution is backed by the autonomous-improvement runtime,
    whose durable event stream lives in improvement.sqlite3. The broader
    service control plane has a separate state.sqlite3 store. Status must
    inspect the store that actually contains the requested mission instead of
    silently reporting unknown from an unrelated empty database.
    """
    state_directory = repository_root / ".ocean"
    candidates = [state_directory / "improvement.sqlite3", state_directory / "state.sqlite3"]
    existing = [path for path in candidates if path.is_file()]
    if not existing:
        raise FileNotFoundError(
            f"LUMO mission state database not found in {state_directory}"
        )

    # Prefer the mission runtime store when it contains this mission. Fall back
    # to the general control-plane store for service-created missions and for
    # compatibility with existing state-only installations.
    for database_path in existing:
        connection = sqlite3.connect(str(database_path))
        try:
            store = SQLiteEventStore(connection)
            if mission_id is None or store.list_by_mission_id(mission_id):
                return LiveStatusReader(store), connection
        except Exception:
            connection.close()
            continue
        connection.close()

    # Preserve the normal status surface even when the requested mission is not
    # present yet; the selected fallback store will correctly report unknown.
    database_path = existing[-1]
    connection = sqlite3.connect(str(database_path))
    return LiveStatusReader(SQLiteEventStore(connection)), connection


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "doctor":
        from ocean.diagnostics import doctor
        result = doctor(Path.cwd())
        print(json.dumps(result, indent=2) if args.json else ("LUMO DOCTOR: PASS" if result["ok"] else "LUMO DOCTOR: FAIL"))
        if not args.json:
            for name, ok in result["checks"].items(): print(f"  {'✓' if ok else '✗'} {name}")
        return 0 if result["ok"] else 1

    if args.command == "test-deep":
        from ocean.diagnostics import deep_test
        result = deep_test(Path.cwd())
        if args.json: print(json.dumps(result, indent=2))
        else: print(result["output"])
        return int(result["returncode"])

    if args.command == "mission":
        from ocean.core.ids import new_id
        from ocean.observability.status import LiveStatusReader
        from ocean.orchestration.autonomous_build import RuntimeAutonomousBuildExecutor
        from ocean.orchestration.mission_engine import MissionContract
        global AutonomousImprovementRuntime, build_strategic_model, StrategicMissionPlanner, MissionEngine
        if AutonomousImprovementRuntime is None:
            from ocean.self_improvement.runtime import AutonomousImprovementRuntime as _Runtime
            AutonomousImprovementRuntime = _Runtime
        if build_strategic_model is None:
            from ocean.orchestration.strategic_model_provider import build_strategic_model as _build_model
            build_strategic_model = _build_model
        if StrategicMissionPlanner is None or MissionEngine is None:
            from ocean.orchestration.mission_engine import MissionEngine as _MissionEngine, StrategicMissionPlanner as _Planner
            MissionEngine = _MissionEngine
            StrategicMissionPlanner = _Planner
        runtime = None

        try:
            if bool(args.goal) == bool(args.resume):
                parser.error("mission requires exactly one of goal or --resume")
            if args.watch and args.interval <= 0:
                print(
                    "lumo mission failed: --interval must be greater than 0",
                    file=sys.stderr,
                )
                return 2

            repository_root = Path.cwd()
            mission_id = args.resume or new_id("mission")
            print(f"MISSION {mission_id} STARTING", flush=True)
            print("PLANNING  preparing mission runtime...", flush=True)
            runtime = AutonomousImprovementRuntime(
                repository_root=repository_root,
            )

            goal = args.goal
            if args.resume:
                goal = _persisted_mission_goal(runtime.events._store, mission_id)
            assert goal is not None

            repository_snapshot = runtime.repository_context.build(
                repository_root,
                objective=goal,
            )
            repository_context = repository_snapshot.as_prompt_text()
            routing_builder = getattr(repository_snapshot, "as_routing_prompt_text", None)
            routing_repository_context = (
                routing_builder() if callable(routing_builder) else repository_context
            )

            strategic_model = build_strategic_model()
            executor = RuntimeAutonomousBuildExecutor(
                runtime=runtime,
                strategic_model=strategic_model,
                repository_context=repository_context,
                routing_repository_context=routing_repository_context,
            )


            engine_kwargs = {
                "planner": StrategicMissionPlanner(
                    model=strategic_model,
                    repository_context=repository_context,
                ),
                "executor": executor,
                "events": runtime.events,
                "objective_lease_seconds": float(os.getenv("LUMO_MISSION_OBJECTIVE_LEASE_SECONDS", "180")),
                "max_lease_retries": int(os.getenv("LUMO_MISSION_MAX_LEASE_RETRIES", "2")),
            }
            try:
                engine = MissionEngine(**engine_kwargs)
            except TypeError as exc:
                # Preserve compatibility with older/test engine adapters that
                # predate objective leases without masking unrelated constructor
                # errors.
                if "objective_lease_seconds" not in str(exc) and "max_lease_retries" not in str(exc):
                    raise
                engine_kwargs.pop("objective_lease_seconds", None)
                engine_kwargs.pop("max_lease_retries", None)
                engine = MissionEngine(**engine_kwargs)

            if args.watch:
                reader = LiveStatusReader(runtime.events._store)
                holder = {"result": None, "error": None}

                def run_mission() -> None:
                    try:
                        holder["result"] = engine.run(
                            goal,
                            mission_id=mission_id,
                            max_replans=args.max_replans,
                            contract=MissionContract.from_goal(goal),
                        )
                    except Exception as exc:
                        holder["error"] = exc

                worker = threading.Thread(
                    target=run_mission,
                    name=f"ocean-mission-{mission_id}",
                    daemon=True,
                )
                worker.start()

                try:
                    while worker.is_alive():
                        status = reader.mission(mission_id)

                        if status.status != "unknown":
                            _print_status(status)

                        time.sleep(args.interval)
                except KeyboardInterrupt:
                    print()
                    return 130

                worker.join()

                if holder["error"] is not None:
                    raise holder["error"]

                result = holder["result"]

                if result is None:
                    raise RuntimeError(
                        "mission worker exited without a result"
                    )

                _print_status(reader.mission(mission_id))

            else:
                result = engine.run(
                    goal,
                    mission_id=mission_id,
                    max_replans=args.max_replans,
                    contract=MissionContract.from_goal(goal),
                )

        except Exception as exc:
            print(f"lumo mission failed: {exc}", file=sys.stderr)
            return 1
        finally:
            if runtime is not None:
                runtime.close()

        print()
        print(f"status={result.status}")
        print(f"mission_id={result.mission_id}")
        print(f"completed_objectives={len(result.completed_objectives)}")
        print(f"remaining_objectives={len(result.remaining_objectives)}")

        for objective_result in result.objective_results:
            print(
                f"objective={objective_result.objective_id} "
                f"status={objective_result.status} "
                f"error={objective_result.error!r} "
                f"run_id={objective_result.run_id} "
                f"candidate_id={objective_result.candidate_id}"
            )

        return 0 if result.status == "completed" else 2

    if args.command == "status":
        if args.watch and args.interval <= 0:
            print(
                "lumo status failed: --interval must be greater than 0",
                file=sys.stderr,
            )
            return 2

        connection = None

        try:
            reader, connection = _status_reader(Path.cwd(), args.mission_id)

            if not args.watch:
                _print_status(reader.mission(args.mission_id))
                return 0

            try:
                while True:
                    status = reader.mission(args.mission_id)
                    _print_status(status)

                    if status.status in {
                        "completed",
                        "failed",
                        "blocked",
                        "replan_stagnated",
                        "replan_limit_reached",
                        "cancelled",
                    }:
                        return 0

                    time.sleep(args.interval)
            except KeyboardInterrupt:
                print()
                return 130

        except Exception as exc:
            print(f"lumo status failed: {exc}", file=sys.stderr)
            return 1
        finally:
            if connection is not None:
                connection.close()

    if args.command == "computer":
        try:
            if args.max_steps <= 0:
                print("lumo computer failed: --max-steps must be positive", file=sys.stderr)
                return 2
            from ocean.computer_agent import ComputerUseAgent

            agent = ComputerUseAgent(
                model=args.model,
                max_steps=args.max_steps,
                allow_actions=args.allow_computer_actions,
            )
            def live_status(info: dict[str, object]) -> None:
                phase = str(info.get("phase", "working")).upper()
                progress = float(info.get("progress", 0.0))
                message = str(info.get("message", "Working"))
                effort = info.get("reasoning_effort")
                suffix = f" / {effort}" if effort else ""
                print(f"[{progress:>5.1%}] {phase:<10} {message}{suffix}", flush=True)

            def live_step(info: dict[str, object]) -> None:
                operation = str(info.get("operation", "action"))
                state = "OK" if info.get("success") else "FAIL"
                print(f"  step {info.get('step', '?')}: {operation} [{state}]", flush=True)

            agent.on_status = live_status
            agent.on_step = live_step
            result = agent.run(args.objective)
        except Exception as exc:
            print(f"lumo computer failed: {exc}", file=sys.stderr)
            return 1

        print(f"status={result.status}")
        print(f"steps={result.steps}")
        print(f"message={result.message}")
        if result.last_screenshot:
            print(f"last_screenshot={result.last_screenshot}")
        return 0 if result.status == "completed" else 2

    if args.command == "improve-overnight":
        from ocean.self_improvement.runtime import AutonomousImprovementRuntime, ImprovementBudget
        runtime = None
        try:
            if args.hours <= 0 or args.model_calls < 1 or args.candidates < 1:
                print("lumo improve-overnight failed: budgets must be positive", file=sys.stderr)
                return 2
            runtime = AutonomousImprovementRuntime(
                repository_root=Path.cwd(),
                test_timeout_seconds=args.test_timeout,
                provider_name="ollama",
                model_name=args.model,
            )
            budget = ImprovementBudget(
                max_wall_seconds=args.hours * 3600.0,
                max_model_calls=args.model_calls,
                max_candidates=args.candidates,
                max_test_timeout_seconds=args.test_timeout,
            )
            print(f"provider=ollama model={args.model} max_model_calls={args.model_calls} max_candidates={args.candidates}", flush=True)
            results = runtime.improve_overnight(args.objective, budget=budget)
            for result in results:
                print(f"status={result.status} run_id={result.run_id} candidate_id={result.candidate_id}", flush=True)
            promoted = sum(result.status == "promoted" for result in results)
            print(f"campaign_complete candidates={len(results)} promoted={promoted}", flush=True)
            return 0
        except Exception as exc:
            print(f"lumo improve-overnight failed: {exc}", file=sys.stderr)
            return 1
        finally:
            if runtime is not None:
                runtime.close()

    if args.command == "improve-forever":
        from ocean.self_improvement.evolution_org import EvolutionOrganization
        # The permanent service now runs the Evolution Organization rather than
        # the legacy single-worker loop. The organization owns discovery,
        # research, invention, engineering, adversarial review and release work.
        organization = EvolutionOrganization(
            repository_root=Path.cwd(),
            model=args.model,
            idle_delay=args.idle_delay,
            test_timeout=args.test_timeout,
        )
        try:
            return organization.run()
        except KeyboardInterrupt:
            organization.stop()
            return 130

    if args.command == "serve":
        # Keep the import boundary out of the process' module-import phase. The
        # packaged launcher can now start Python without eagerly importing the
        # entire control plane before the service command is even selected.
        from ocean.service import OceanService
        from ocean.api import LumoAPIServer
        service = OceanService(repository_root=Path.cwd())
        api_server = None
        try:
            service.start()
            # Construct the HTTP surface only after the durable service exists.
            # This removes the old API-before-service initialization inversion.
            api_server = LumoAPIServer(service, host=args.host, port=args.port)
            # First launch is a fast path. Do not download the entire specialist
            # fleet behind the user's back. The bootstrap model is provisioned on demand;
            # larger specialists are lazy-loaded later when the live governor admits them.
            host, port = api_server.address
            print(f"LUMO API listening on http://{host}:{port}", flush=True)
            api_server.serve_forever()
        except KeyboardInterrupt:
            return 130
        except Exception as exc:
            print(f"lumo serve failed: {exc}", file=sys.stderr)
            return 1
        finally:
            if api_server is not None:
                api_server.shutdown()
            service.stop()
        return 0

    if args.command == "improve":
        from ocean.self_improvement.runtime import AutonomousImprovementRuntime
        runtime = None

        try:
            # Interactive shells intentionally do not inherit LUMO's service
            # credentials. Prefer the already-running localhost control plane
            # so secrets remain inside the long-lived service process. Direct
            # runtime execution remains available when a caller explicitly
            # supplies the provider credentials in its own environment.
            runtime = AutonomousImprovementRuntime(
                repository_root=Path.cwd(),
                provider_name="ollama",
                model_name=os.getenv("LUMO_IMPROVEMENT_MODEL") or "qwen3:0.6b",
                test_timeout_seconds=args.test_timeout,
            )
            if runtime is not None:
                result = runtime.improve(
                    args.objective,
                    hypothesis=args.hypothesis,
                    rationale=args.rationale,
                )
                print(f"status={result.status}")
                print(f"run_id={result.run_id}")
                print(f"candidate_id={result.candidate_id}")
                if result.error:
                    print(f"error={result.error}")
                return 0 if result.status == "promoted" else 2

            request_body = json.dumps({
                "objective": args.objective,
                "test_timeout": args.test_timeout,
            }).encode("utf-8")
            request = urllib.request.Request(
                "http://127.0.0.1:8765/api/improvements",
                data=request_body,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(request, timeout=5) as response:
                submission = json.loads(response.read().decode("utf-8"))
            run_id = str(submission["run_id"])
            print(f"run_id={run_id}", flush=True)

            terminal = {"promoted", "rejected", "rolled_back", "failed"}
            while True:
                with urllib.request.urlopen(
                    f"http://127.0.0.1:8765/api/improvements/{run_id}",
                    timeout=5,
                ) as response:
                    status = json.loads(response.read().decode("utf-8"))
                state = str(status.get("state", "unknown"))
                print(f"status={state}", flush=True)
                if state in terminal:
                    result = status.get("result") or {}
                    if status.get("error"):
                        print(f"error={status['error']}")
                    if result.get("candidate_tests_passed") is not None:
                        print(f"candidate_tests_passed={result['candidate_tests_passed']}")
                    if result.get("promoted_plan_revision_id"):
                        print(f"promoted_plan_revision_id={result['promoted_plan_revision_id']}")
                    return 0 if state == "promoted" else 2
                time.sleep(1.0)
        except (urllib.error.URLError, TimeoutError, KeyError, ValueError) as exc:
            print(f"lumo improve failed: {exc}", file=sys.stderr)
            return 1
        except Exception as exc:
            print(f"lumo improve failed: {exc}", file=sys.stderr)
            return 1
        finally:
            if runtime is not None:
                runtime.close()

    parser.error("unknown command")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
