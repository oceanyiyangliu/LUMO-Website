"""Safe bootstrap-to-runtime local-model handoff.

The tiny bootstrap model proves the local inference path. Once verified RAM
headroom is sufficient, this controller may warm one stronger installed model.
It never downloads arbitrary models, never exceeds the resource governor, and
never keeps more than one handoff attempt active.
"""
from __future__ import annotations
import json
import threading
import time
import urllib.request
from dataclasses import dataclass
from .resources.intelligence_governor import sample_device_resources
from .resources.local_model_manager import LocalModelManager

@dataclass(frozen=True)
class HandoffStatus:
    bootstrap_model: str
    runtime_model: str | None
    active_model: str | None
    state: str
    reason: str
    updated_at: float

class IntelligenceHandoff:
    def __init__(self, manager: LocalModelManager) -> None:
        self.manager = manager
        self._lock = threading.RLock()
        self._active: str | None = None
        self._attempting = False
        self._last_attempt = 0.0
        self._status = HandoffStatus("qwen3:0.6b", None, None, "bootstrap", "bootstrap remains authoritative", time.time())

    def status(self) -> HandoffStatus:
        with self._lock:
            return self._status

    def maybe_start(self, runtime_model: str | None, runtime_ram_gib: float | None) -> HandoffStatus:
        now = time.monotonic()
        with self._lock:
            if not runtime_model or not runtime_ram_gib:
                self._status = HandoffStatus("qwen3:0.6b", runtime_model, self._active, "bootstrap", "no stronger model safely fits", time.time())
                return self._status
            if self._attempting or now - self._last_attempt < 30:
                return self._status
            self._last_attempt = now
            self._attempting = True
        threading.Thread(target=self._warm, args=(runtime_model, float(runtime_ram_gib)), name="lumo-intelligence-handoff", daemon=True).start()
        return self.status()

    def _warm(self, model: str, runtime_ram_gib: float) -> None:
        try:
            device = sample_device_resources()
            available = device.available_ram_bytes / 1024**3
            required = runtime_ram_gib + 2.5
            if available < required:
                self._set(model, "waiting", f"need {required:.1f} GiB available headroom")
                return
            if not self.manager.is_installed(model):
                self._set(model, "bootstrap", "runtime model is not installed")
                return
            payload = json.dumps({"model": model, "prompt": "Reply READY.", "stream": False, "keep_alive": "5m", "options": {"num_predict": 2}}).encode()
            req = urllib.request.Request(self.manager.base_url + "/api/generate", data=payload, headers={"Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(req, timeout=30) as response:
                response.read()
            self._set(model, "ready", "stronger local model warmed successfully", active=model)
        except Exception as exc:
            self._set(model, "bootstrap", f"handoff deferred: {exc}")
        finally:
            with self._lock:
                self._attempting = False

    def _set(self, model: str, state: str, reason: str, *, active: str | None = None) -> None:
        with self._lock:
            if active is not None:
                self._active = active
            self._status = HandoffStatus("qwen3:0.6b", model, self._active, state, reason, time.time())

__all__ = ["HandoffStatus", "IntelligenceHandoff"]
