"""Versioned transport contracts shared by local and future remote clients."""
from __future__ import annotations
import hashlib
import hmac
import json
from dataclasses import dataclass
from typing import Any

PROTOCOL_VERSION = 1

@dataclass(frozen=True)
class ProtocolFrame:
    kind: str
    version: int
    stream_id: str
    sequence: int
    payload: dict[str, Any]
    mac: str | None = None
    def canonical(self) -> bytes:
        return json.dumps({"kind":self.kind,"version":self.version,"stream_id":self.stream_id,"sequence":self.sequence,"payload":self.payload},sort_keys=True,separators=(",",":"),default=str).encode()
    def sign(self, secret: bytes) -> "ProtocolFrame":
        return ProtocolFrame(self.kind,self.version,self.stream_id,self.sequence,self.payload,hmac.new(secret,self.canonical(),hashlib.sha256).hexdigest())
    def verify(self, secret: bytes) -> bool:
        return self.mac is not None and hmac.compare_digest(self.mac,hmac.new(secret,self.canonical(),hashlib.sha256).hexdigest())

class ProtocolNegotiator:
    def __init__(self, supported: set[int] | None = None): self.supported=frozenset(supported or {PROTOCOL_VERSION})
    def negotiate(self, peer_versions: list[int] | tuple[int,...]) -> int:
        common=self.supported.intersection(int(v) for v in peer_versions)
        if not common: raise RuntimeError("no compatible LUMO protocol version")
        return max(common)

class StreamPartitioner:
    def __init__(self, partitions: int = 16):
        if partitions <= 0: raise ValueError("partitions must be positive")
        self.partitions=partitions
    def partition(self, stream_id: str) -> int:
        if not stream_id: raise ValueError("stream_id is required")
        return int(hashlib.sha256(stream_id.encode()).hexdigest()[:16],16) % self.partitions

def device_frame(device_id: str, sequence: int, payload: dict[str,Any], secret: bytes) -> ProtocolFrame:
    return ProtocolFrame("device",PROTOCOL_VERSION,device_id,sequence,payload).sign(secret)

def cloud_frame(account_id: str, sequence: int, payload: dict[str,Any], secret: bytes) -> ProtocolFrame:
    return ProtocolFrame("cloud",PROTOCOL_VERSION,account_id,sequence,payload).sign(secret)

def world_frame(world_id: str, sequence: int, payload: dict[str,Any], secret: bytes) -> ProtocolFrame:
    return ProtocolFrame("world",PROTOCOL_VERSION,world_id,sequence,payload).sign(secret)
