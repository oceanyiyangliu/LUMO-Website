"""Executable safety/reliability invariants for the LUMO kernel."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class InvariantViolation:
    name: str
    detail: str


def check_event_sequence(events: list[Any]) -> list[InvariantViolation]:
    violations: list[InvariantViolation] = []
    previous = 0
    for event in events:
        sequence = getattr(event, "sequence", None)
        if sequence is None:
            continue
        if sequence <= previous:
            violations.append(InvariantViolation("monotonic_event_sequence", f"sequence {sequence} followed {previous}"))
        previous = sequence
    return violations


def check_completion_requires_verification(state: dict[str, Any]) -> list[InvariantViolation]:
    if state.get("state") == "completed" and state.get("verification_state") not in {"verified", "passed", "complete"}:
        return [InvariantViolation("completion_requires_verification", "task is completed without a verified completion state")]
    return []


def check_no_active_assignments_after_stop(assignments: list[dict[str, Any]], stopped: bool) -> list[InvariantViolation]:
    if not stopped:
        return []
    active = [a for a in assignments if a.get("state") in {"active", "running", "assigned"}]
    return [InvariantViolation("stop_clears_active_assignments", f"{len(active)} active assignments remain") ] if active else []


def check_world_ownership(world: dict[str, Any], *, task_id: str, account_id: str) -> list[InvariantViolation]:
    violations: list[InvariantViolation] = []
    if world.get("task_id") not in {None, task_id}:
        violations.append(InvariantViolation("world_task_isolation", "World belongs to another task"))
    if world.get("account_id") not in {None, account_id}:
        violations.append(InvariantViolation("world_account_isolation", "World belongs to another account"))
    return violations
