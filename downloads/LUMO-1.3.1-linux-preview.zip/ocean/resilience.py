"""Dependency recovery and mission continuation policy.

LUMO treats missing tooling, missing files, and failed setup as recoverable
obstacles rather than reasons to abandon an otherwise valid mission. External
software installation remains an explicit authority boundary and is surfaced
as a user alert before execution.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import shutil
import subprocess
import time
from typing import Any, Sequence

from ocean.domain.event import Event


@dataclass(frozen=True)
class DependencyRequirement:
    name: str
    command: str | None = None
    install_hint: str | None = None
    auto_install: bool = False
    rationale: str = ""


@dataclass(frozen=True)
class RecoveryAction:
    action_id: str
    kind: str
    status: str
    target: str
    message: str
    requires_user: bool = False
    evidence: tuple[str, ...] = ()


class DependencyRecovery:
    """Deterministic preflight/recovery helper used by mission executors."""

    SAFE_INSTALLERS = {
        "visual studio code": "https://code.visualstudio.com/",
        "vs code": "https://code.visualstudio.com/",
    }

    def __init__(self, *, events=None) -> None:
        self._events = events
        self._pending: dict[str, DependencyRequirement] = {}

    def _publish(self, mission_id: str, event_type: str, payload: dict[str, Any]) -> None:
        if self._events is not None:
            self._events.publish(Event(type=event_type, aggregate_type="mission", aggregate_id=mission_id,
                                       correlation_id=mission_id, source="dependency_recovery", payload={"mission_id": mission_id, **payload}))

    def inspect(self, requirements: Sequence[DependencyRequirement]) -> tuple[DependencyRequirement, ...]:
        missing = []
        for req in requirements:
            if req.command and shutil.which(req.command) is None:
                missing.append(req)
        return tuple(missing)

    def recover(self, mission_id: str, requirements: Sequence[DependencyRequirement]) -> tuple[RecoveryAction, ...]:
        actions: list[RecoveryAction] = []
        for req in self.inspect(requirements):
            action_id = f"dependency-{time.time_ns()}"
            installer = self.SAFE_INSTALLERS.get(req.name.lower())
            if installer and req.auto_install:
                self._pending[action_id] = req
                self._publish(mission_id, "DependencyInstallApprovalRequired", {
                    "action_id": action_id, "dependency": req.name, "installer": installer,
                    "message": f"{req.name} is required to continue this mission. User approval is required before installing software.",
                    "rationale": req.rationale or "required execution dependency",
                })
                actions.append(RecoveryAction(action_id, "install_software", "blocked_pending_user", req.name,
                    f"Waiting for user approval to install {req.name}", True, (f"installer={installer}",)))
                continue
            self._publish(mission_id, "DependencyMissing", {
                "action_id": action_id, "dependency": req.name, "command": req.command,
                "message": f"Required dependency missing: {req.name}", "install_hint": req.install_hint,
            })
            actions.append(RecoveryAction(action_id, "missing_dependency", "blocked_pending_user", req.name,
                f"Required dependency missing: {req.name}", True, ()))
        return tuple(actions)

    def approve(self, mission_id: str, action_id: str) -> RecoveryAction:
        req = self._pending.get(action_id)
        if req is None:
            raise KeyError(action_id)
        installer = self.SAFE_INSTALLERS.get(req.name.lower())
        if installer is None:
            raise ValueError(f"no approved installer for {req.name}")
        self._publish(mission_id, "DependencyInstallStarted", {
            "action_id": action_id, "dependency": req.name, "installer": installer,
        })
        # Prefer Homebrew when present; it is a deterministic, user-visible
        # installation path. Never download arbitrary executables from model text.
        if shutil.which("brew") is None:
            return RecoveryAction(action_id, "install_software", "blocked", req.name,
                "Homebrew is required for the approved automatic installer", True, (f"installer={installer}",))
        formula = {"visual studio code": "visual-studio-code", "vs code": "visual-studio-code"}.get(req.name.lower())
        if formula is None:
            raise ValueError(f"no approved package for {req.name}")
        completed = subprocess.run(["brew", "install", "--cask", formula], capture_output=True, text=True, timeout=600, check=False)
        if completed.returncode != 0:
            error = (completed.stderr or completed.stdout or "brew install failed").strip()
            self._publish(mission_id, "DependencyInstallFailed", {"action_id": action_id, "dependency": req.name, "error": error})
            return RecoveryAction(action_id, "install_software", "failed", req.name, error, False, ())
        self._pending.pop(action_id, None)
        self._publish(mission_id, "DependencyInstalled", {"action_id": action_id, "dependency": req.name, "command": req.command})
        return RecoveryAction(action_id, "install_software", "completed", req.name, f"Installed {req.name}", False, ("verified_by_installer_exit_code=0",))

    def verify_available(self, requirements: Sequence[DependencyRequirement]) -> bool:
        return not self.inspect(requirements)
