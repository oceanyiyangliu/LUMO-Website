"""Protocol-level API authentication, CSRF, cursors and typed errors."""
from __future__ import annotations
import base64,hmac,hashlib,json,secrets,time
from dataclasses import dataclass
from .security import SessionAuthority

@dataclass(frozen=True)
class APIError:
    code:str
    message:str
    request_id:str

class APIAuth:
    def __init__(self, sessions:SessionAuthority): self.sessions=sessions
    def authenticate(self, authorization:str|None):
        if not authorization or not authorization.startswith("Bearer "): raise PermissionError("authentication required")
        return self.sessions.verify(authorization[7:].strip())
    @staticmethod
    def csrf(session_id:str, method:str, path:str, nonce:str)->str:
        return hmac.new(session_id.encode(),f"{method.upper()} {path} {nonce}".encode(),hashlib.sha256).hexdigest()
    @staticmethod
    def verify_csrf(session_id,method,path,nonce,token)->bool:
        return hmac.compare_digest(APIAuth.csrf(session_id,method,path,nonce),token or "")

class CursorCodec:
    def __init__(self,secret:bytes|None=None): self._secret=secret or secrets.token_bytes(32)
    def encode(self,position:int,scope:str)->str:
        raw=json.dumps({"p":int(position),"s":scope},separators=(",",":"),sort_keys=True).encode(); sig=hmac.new(self._secret,raw,hashlib.sha256).digest(); return base64.urlsafe_b64encode(raw+b"."+sig).decode()
    def decode(self,cursor:str,scope:str)->int:
        try: raw,sig=base64.urlsafe_b64decode(cursor.encode()).rsplit(b".",1); payload=json.loads(raw)
        except Exception as exc: raise ValueError("invalid pagination cursor") from exc
        if not hmac.compare_digest(sig,hmac.new(self._secret,raw,hashlib.sha256).digest()) or payload.get("s")!=scope or int(payload.get("p",-1))<0: raise ValueError("invalid pagination cursor")
        return int(payload["p"])

def negotiate_content_type(accept:str|None)->str:
    if not accept or "application/json" in accept or "*/*" in accept: return "application/json"
    raise ValueError("unsupported response media type")

class DeviceEnrollmentAuthority:
    """Short-lived, one-time enrollment codes; possession alone never grants execution."""
    def __init__(self,ttl_seconds:int=300): self.ttl=ttl_seconds; self._codes={}
    def issue(self,account_id:str)->str:
        code=f"{secrets.randbelow(1_000_000):06d}"; self._codes[code]=(account_id,time.monotonic()+self.ttl); return code
    def consume(self,code:str,account_id:str)->bool:
        value=self._codes.pop(str(code),None)
        if value is None or value[0]!=account_id or time.monotonic()>=value[1]: return False
        return True
