"""LUMO Root operator: autonomous health projection and bounded self-management."""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any


@dataclass(frozen=True)
class OperatorIncident:
    id: str
    severity: str
    title: str
    detail: str
    action: str
    automatic: bool

    def as_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "severity": self.severity,
            "title": self.title,
            "detail": self.detail,
            "action": self.action,
            "automatic": self.automatic,
        }


class RootOperator:
    """Project the Root's operational state without granting unrestricted authority."""

    def __init__(self, service: Any) -> None:
        self.service = service

    def snapshot(self, api: Any) -> dict[str, Any]:
        readiness = api.readiness()
        emergency = api.emergency_status()
        billing = api.billing()
        worlds = api.worlds()
        devices = api.devices()
        missions = api.missions()
        nodes = self.service.nodes.list(api._active_account_id)
        feedback = api.feedback_snapshot(limit=50)
        email = api.email_status()
        incidents: list[OperatorIncident] = []
        if not email.get("configured"):
            incidents.append(OperatorIncident("email-delivery", "warning", "Transactional email needs configuration", "Account verification and password-reset mail cannot be delivered until a provider is configured.", "Configure LUMO Mail", False))
        elif int(email.get("failed", 0)) > 0:
            incidents.append(OperatorIncident("email-failures", "warning", "Transactional email delivery has failures", f"{email.get('failed')} messages reached the retry limit.", "Inspect LUMO Mail", True))

        if emergency.get("engaged"):
            incidents.append(OperatorIncident("emergency-stop", "critical", "Emergency stop engaged", "LUMO execution is intentionally halted.", "Wait for Root release", False))
        if not readiness.get("mission_execution", False):
            incidents.append(OperatorIncident("intelligence", "high", "Intelligence provider unavailable", str(readiness.get("degraded_reason") or "Mission execution is unavailable."), "Configure or restore the provider", False))

        running = [m for m in missions if m.get("status") in {"running", "replanning", "starting"}]
        failed = [m for m in missions if m.get("status") == "failed"]
        for mission in running:
            last = mission.get("last_event_at") or mission.get("updated_at")
            if last:
                try:
                    age = (datetime.now(timezone.utc) - datetime.fromisoformat(str(last).replace("Z", "+00:00"))).total_seconds()
                    if age > 600:
                        incidents.append(OperatorIncident(f"stalled-{mission['id']}", "warning", "Mission may be stalled", f"{mission['id']} has had no recent activity for {int(age)}s.", "Inspect and recover", True))
                except (TypeError, ValueError):
                    pass
        if len(failed) >= 3:
            incidents.append(OperatorIncident("failure-cluster", "warning", "Recent mission failures clustered", f"{len(failed)} failed missions are currently visible.", "Review failure patterns", True))

        node_counts = Counter(str(n.get("status", "unknown")) for n in nodes)
        offline_expired = [n for n in nodes if n.get("status") in {"offline", "revoked"}]
        if offline_expired:
            incidents.append(OperatorIncident("nodes-offline", "notice", "Nodes need attention", f"{len(offline_expired)} registered nodes are offline or revoked.", "Review Nodes", True))

        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "mode": "autonomous-operator",
            "health": "critical" if any(i.severity == "critical" for i in incidents) else "degraded" if any(i.severity in {"high", "warning"} for i in incidents) else "healthy",
            "readiness": readiness,
            "emergency_stop": emergency,
            "missions": {"running": len(running), "failed": len(failed), "total_visible": len(missions)},
            "worlds": {"active": len(worlds)},
            "nodes": {"total": len(nodes), "by_status": dict(node_counts)},
            "devices": {"total": len(devices), "online": sum(d.get("status") == "online" for d in devices)},
            "billing": {"plan": billing.get("plan"), "usage": billing.get("usage"), "limits": billing.get("limits")},
            "feedback": {
                "received": feedback.get("count", 0),
                "unreviewed": feedback.get("unreviewed", 0),
                "latest": feedback.get("feedback", [])[-5:],
            },
            "email": {
                "configured": bool(email.get("configured")),
                "provider": email.get("provider"),
                "pending": int(email.get("pending", 0)),
                "failed": int(email.get("failed", 0)),
                "sent": int(email.get("sent", 0)),
                "last": email.get("last"),
            },
            "incidents": [i.as_dict() for i in incidents],
            "root": {
                "authority": "root",
                "control_scope": "platform telemetry, safety stop, recovery workflows",
            },
            "autonomy": {
                "automatic_recovery": True,
                "human_attention_only_for_authority_boundaries": True,
                "unrestricted_root_access": False,
            },
        }
