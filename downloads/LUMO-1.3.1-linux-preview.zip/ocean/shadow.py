from __future__ import annotations

import threading
import time
from typing import Any


class ShadowAgent:
    """Passive local companion: observes desktop context without taking control."""

    def __init__(self, *, interval: float = 1.0) -> None:
        self.interval = max(0.25, interval)
        self._lock = threading.RLock()
        self._enabled = False
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._context: dict[str, Any] = {"enabled": False, "application": "", "window": "", "updated_at": None}

    def start(self) -> dict[str, Any]:
        with self._lock:
            self._enabled = True
            if self._thread is None or not self._thread.is_alive():
                self._stop.clear()
                self._thread = threading.Thread(target=self._run, name="lumo-shadow", daemon=True)
                self._thread.start()
            return dict(self._context)

    def stop(self) -> dict[str, Any]:
        with self._lock:
            self._enabled = False
            self._context["enabled"] = False
            return dict(self._context)

    def status(self) -> dict[str, Any]:
        with self._lock:
            return dict(self._context)

    def _run(self) -> None:
        from ocean.capabilities.computer import MacOSComputerExecutor
        executor = MacOSComputerExecutor()
        while not self._stop.wait(self.interval):
            with self._lock:
                if not self._enabled:
                    continue
            try:
                context = executor._frontmost_context(timeout=2.0)
                with self._lock:
                    self._context.update({"enabled": True, **context, "updated_at": time.time()})
            except Exception:
                continue
