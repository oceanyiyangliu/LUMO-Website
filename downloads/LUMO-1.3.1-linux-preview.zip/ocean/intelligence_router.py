"""Provider/model-neutral intelligence routing with hard local safety limits."""
from __future__ import annotations
from dataclasses import dataclass,field
from typing import Mapping
import math
import threading

from ocean.optimization import CostLedger
from ocean.resources.intelligence_governor import LocalResourceGovernor
from ocean.resources.local_model_manager import LocalModelManager

@dataclass(frozen=True)
class ModelManifest:
    model_id:str; provider:str; capabilities:frozenset[str]=frozenset(); context_window:int=0; latency_ms:float=0; cost_per_1k_tokens:float=0; size_gib:float|None=None; privacy:str="cloud"; healthy:bool=True; runtime_ram_gib:float|None=None
    def __post_init__(self):
        if self.size_gib is not None and self.size_gib < 0: raise ValueError("model size must be non-negative")
        if self.runtime_ram_gib is not None and self.runtime_ram_gib <= 0: raise ValueError("runtime_ram_gib must be positive")
        if self.context_window<0 or self.latency_ms<0 or self.cost_per_1k_tokens<0: raise ValueError("model metrics must be non-negative")

@dataclass(frozen=True)
class RouteRequest:
    capabilities:frozenset[str]=frozenset(); min_context:int=0; max_latency_ms:float|None=None; max_cost_per_1k:float|None=None; privacy:str="standard"; local_only:bool=False; max_local_gib:float=10.0
    max_memory_bytes:int|None=None; require_gpu:bool=False; objective:str="cost"; performance:str="auto"
    def __post_init__(self):
        if self.objective not in {"cost","latency","balanced"}:
            raise ValueError("objective must be cost, latency, or balanced")


@dataclass(frozen=True)
class RouteObservation:
    model_id:str
    provider:str
    latency_ms:float
    input_tokens:int
    output_tokens:int
    estimated_cost:float
    success:bool

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

@dataclass(frozen=True)
class RouteReceipt:
    model_id:str; provider:str; reason:str; fallback_chain:tuple[str,...]=(); local:bool=False

class ModelRegistry:
    def __init__(self,models=()): self._models={m.model_id:m for m in models}
    def register(self,m:ModelManifest): self._models[m.model_id]=m
    def list(self): return tuple(self._models.values())
    def get(self,model_id): return self._models.get(model_id)

class IntelligenceRouter:
    def __init__(self,registry:ModelRegistry, *, governor:LocalResourceGovernor|None=None, model_manager:LocalModelManager|None=None):
        self.registry=registry
        self.governor=governor or LocalResourceGovernor()
        self.model_manager=model_manager or LocalModelManager()
        self._observations:list[RouteObservation]=[]
        self._costs = CostLedger()
        self._lock=threading.RLock()

    def record_usage(self, model_id:str, *, latency_ms:float, input_tokens:int, output_tokens:int, success:bool=True) -> RouteObservation:
        model=self.registry.get(model_id)
        if model is None: raise KeyError(model_id)
        if not math.isfinite(float(latency_ms)) or latency_ms < 0: raise ValueError("latency_ms must be finite and non-negative")
        if any(isinstance(v,bool) or not isinstance(v,int) or v < 0 for v in (input_tokens,output_tokens)): raise ValueError("token counts must be non-negative integers")
        cost=(input_tokens+output_tokens)*model.cost_per_1k_tokens/1000.0
        observation=RouteObservation(model_id,model.provider,float(latency_ms),input_tokens,output_tokens,cost,bool(success))
        with self._lock: self._observations.append(observation)
        self._costs.record(model_id, "inference", cost, provider=model.provider, input_tokens=input_tokens, output_tokens=output_tokens, latency_ms=latency_ms, success=bool(success))
        return observation

    def cost_breakdown(self, model_id: str | None = None) -> dict[str, float]:
        return dict(self._costs.breakdown(scope=model_id))

    def telemetry(self, model_id:str|None=None) -> dict[str,float|int]:
        with self._lock:
            rows=[o for o in self._observations if model_id is None or o.model_id==model_id]
        if not rows: return {"requests":0,"successes":0,"tokens":0,"estimated_cost":0.0,"avg_latency_ms":0.0,"p95_latency_ms":0.0,"success_rate":0.0}
        latencies=sorted(o.latency_ms for o in rows)
        p95=latencies[min(len(latencies)-1,max(0,int(math.ceil(len(latencies)*0.95))-1))]
        successes=sum(o.success for o in rows)
        return {"requests":len(rows),"successes":successes,"tokens":sum(o.total_tokens for o in rows),"estimated_cost":sum(o.estimated_cost for o in rows),"avg_latency_ms":sum(o.latency_ms for o in rows)/len(rows),"p95_latency_ms":p95,"success_rate":successes/len(rows)}

    def _effective_metrics(self, model:ModelManifest) -> tuple[float,float,float]:
        """Return expected cost, p95-ish latency, and reliability-adjusted cost.

        Sparse telemetry falls back to manifest values. Failed historical calls increase
        expected cost so the router does not optimize sticker price while ignoring retries.
        """
        stats=self.telemetry(model.model_id)
        success_rate=float(stats["success_rate"])
        if int(stats["requests"]) == 0:
            return model.cost_per_1k_tokens, model.latency_ms, model.cost_per_1k_tokens
        reliability=max(success_rate,0.05)
        observed_cost=float(stats["estimated_cost"])/max(int(stats["requests"]),1)
        expected_cost=observed_cost/reliability
        latency=max(model.latency_ms,float(stats["p95_latency_ms"]))
        return observed_cost,latency,expected_cost
    def route(self,request:RouteRequest)->RouteReceipt:
        candidates=[]
        for m in self.registry.list():
            if not m.healthy or m.context_window < request.min_context or not request.capabilities.issubset(m.capabilities): continue
            if request.max_latency_ms is not None and m.latency_ms > request.max_latency_ms: continue
            if request.max_cost_per_1k is not None and m.cost_per_1k_tokens > request.max_cost_per_1k: continue
            if request.max_memory_bytes is not None and m.privacy == "local" and m.runtime_ram_gib is not None and m.runtime_ram_gib * 1024**3 > request.max_memory_bytes: continue
            if request.max_memory_bytes is not None and m.privacy == "local" and m.runtime_ram_gib is None and m.size_gib is not None and m.size_gib * 1024**3 > request.max_memory_bytes: continue
            if request.require_gpu and "gpu" not in m.capabilities: continue
            if request.local_only and m.privacy != "local": continue
            if m.privacy=="local":
                if m.provider == "ollama" and ":" in m.model_id:
                    try:
                        if not self.model_manager.is_installed(m.model_id): continue
                    except Exception:
                        continue
                if m.size_gib is None or m.size_gib > min(float(request.max_local_gib), 64.0): continue
                runtime_gib = m.runtime_ram_gib if m.runtime_ram_gib is not None else m.size_gib
                if runtime_gib is None or runtime_gib * 1024**3 > self.governor.snapshot().safe_ai_ram_bytes: continue
            if request.privacy=="local_only" and m.privacy!="local": continue
            candidates.append(m)
        if not candidates: raise RuntimeError("no model satisfies routing constraints")
        # Optimize against observed economics, not sticker price alone.
        metrics={m.model_id:self._effective_metrics(m) for m in candidates}
        if request.objective=="latency":
            chosen=min(candidates,key=lambda m:(metrics[m.model_id][1],metrics[m.model_id][2],m.model_id))
        elif request.objective=="balanced":
            chosen=min(candidates,key=lambda m:(metrics[m.model_id][2],metrics[m.model_id][1],m.model_id))
        else:
            chosen=min(candidates,key=lambda m:(metrics[m.model_id][2],metrics[m.model_id][1],m.model_id))
        return RouteReceipt(chosen.model_id,chosen.provider,"satisfies requested capability/context/privacy/cost/latency constraints",tuple(m.model_id for m in candidates),chosen.privacy=="local")
