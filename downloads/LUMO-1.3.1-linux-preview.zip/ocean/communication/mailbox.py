from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from threading import RLock
from typing import Dict, Iterable, List, Optional

from ocean.core.clock import SYSTEM_CLOCK

from .types import DeliveryReceipt, DeliveryStatus, MessageEnvelope


@dataclass
class _MailboxEntry:
    envelope: MessageEnvelope
    status: DeliveryStatus = DeliveryStatus.PENDING
    delivered_at: Optional[datetime] = None
    acknowledged_at: Optional[datetime] = None
    reason: Optional[str] = None


class Mailbox:
    """Thread-safe durable-state projection for one agent mailbox."""

    def __init__(self, agent_id: str):
        self.agent_id = agent_id
        self._lock = RLock()
        self._entries: Dict[str, _MailboxEntry] = {}

    def enqueue(self, envelope: MessageEnvelope) -> DeliveryReceipt:
        if envelope.message.recipient_id != self.agent_id:
            raise ValueError(
                f"message recipient {envelope.message.recipient_id!r} "
                f"does not match mailbox {self.agent_id!r}"
            )

        with self._lock:
            existing = self._entries.get(envelope.message.id)
            if existing is not None:
                return self._receipt(existing)

            entry = _MailboxEntry(envelope=envelope)
            self._entries[envelope.message.id] = entry
            return self._receipt(entry)

    def deliver(self, message_id: str) -> DeliveryReceipt:
        with self._lock:
            entry = self._require(message_id)

            if entry.status in {
                DeliveryStatus.DELIVERED,
                DeliveryStatus.ACKNOWLEDGED,
                DeliveryStatus.REJECTED,
                DeliveryStatus.EXPIRED,
            }:
                return self._receipt(entry)

            if self._expired(entry.envelope):
                entry.status = DeliveryStatus.EXPIRED
                entry.reason = "message expired"
                return self._receipt(entry)

            entry.status = DeliveryStatus.DELIVERED
            entry.delivered_at = SYSTEM_CLOCK.now()
            return self._receipt(entry)

    def acknowledge(self, message_id: str) -> DeliveryReceipt:
        with self._lock:
            entry = self._require(message_id)

            if entry.status == DeliveryStatus.ACKNOWLEDGED:
                return self._receipt(entry)

            if entry.status != DeliveryStatus.DELIVERED:
                raise ValueError(
                    f"cannot acknowledge message {message_id!r} "
                    f"from status {entry.status.value!r}"
                )

            entry.status = DeliveryStatus.ACKNOWLEDGED
            entry.acknowledged_at = SYSTEM_CLOCK.now()
            return self._receipt(entry)

    def reject(self, message_id: str, reason: str) -> DeliveryReceipt:
        with self._lock:
            entry = self._require(message_id)

            if entry.status == DeliveryStatus.ACKNOWLEDGED:
                raise ValueError(
                    f"cannot reject acknowledged message {message_id!r}"
                )

            if entry.status == DeliveryStatus.REJECTED:
                if entry.reason == reason:
                    return self._receipt(entry)
                raise ValueError(
                    f"message {message_id!r} was already rejected"
                )

            if entry.status == DeliveryStatus.EXPIRED:
                return self._receipt(entry)

            entry.status = DeliveryStatus.REJECTED
            entry.reason = reason
            return self._receipt(entry)

    def expire(self, message_id: str) -> DeliveryReceipt:
        with self._lock:
            entry = self._require(message_id)

            if entry.status in {
                DeliveryStatus.EXPIRED,
                DeliveryStatus.ACKNOWLEDGED,
                DeliveryStatus.REJECTED,
            }:
                return self._receipt(entry)

            if not self._expired(entry.envelope):
                raise ValueError(
                    f"message {message_id!r} has not expired"
                )

            entry.status = DeliveryStatus.EXPIRED
            entry.reason = "message expired"
            return self._receipt(entry)

    def pending(self) -> List[MessageEnvelope]:
        with self._lock:
            return [
                entry.envelope
                for entry in sorted(
                    self._entries.values(),
                    key=lambda entry: (
                        -entry.envelope.priority,
                        entry.envelope.at,
                        entry.envelope.message.id,
                    ),
                )
                if entry.status == DeliveryStatus.PENDING
            ]

    def get(self, message_id: str) -> MessageEnvelope:
        with self._lock:
            return self._require(message_id).envelope

    def receipt(self, message_id: str) -> DeliveryReceipt:
        with self._lock:
            return self._receipt(self._require(message_id))

    def entries(self) -> List[DeliveryReceipt]:
        with self._lock:
            return [
                self._receipt(entry)
                for entry in sorted(
                    self._entries.values(),
                    key=lambda entry: (
                        entry.envelope.at,
                        entry.envelope.message.id,
                    ),
                )
            ]

    def rebuild(
        self,
        envelopes: Iterable[MessageEnvelope],
        states: Optional[Dict[str, DeliveryReceipt]] = None,
    ) -> None:
        """Reconstruct the mailbox projection from durable message state."""

        with self._lock:
            self._entries.clear()
            states = states or {}

            for envelope in envelopes:
                message_id = envelope.message.id
                receipt = states.get(message_id)

                entry = _MailboxEntry(envelope=envelope)

                if receipt is not None:
                    entry.status = receipt.status
                    entry.delivered_at = receipt.delivered_at
                    entry.acknowledged_at = receipt.acknowledged_at
                    entry.reason = receipt.reason

                self._entries[message_id] = entry

    def _expired(self, envelope: MessageEnvelope) -> bool:
        return (
            envelope.expires_at is not None
            and SYSTEM_CLOCK.now() >= envelope.expires_at
        )

    def _require(self, message_id: str) -> _MailboxEntry:
        entry = self._entries.get(message_id)
        if entry is None:
            raise KeyError(f"unknown message: {message_id!r}")
        return entry

    def _receipt(self, entry: _MailboxEntry) -> DeliveryReceipt:
        return DeliveryReceipt(
            message_id=entry.envelope.message.id,
            recipient_id=self.agent_id,
            status=entry.status,
            delivered_at=entry.delivered_at,
            acknowledged_at=entry.acknowledged_at,
            reason=entry.reason,
        )
