from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional

from ocean.core.clock import SYSTEM_CLOCK
from ocean.core.ids import new_id
from ocean.domain.message import Message


class DeliveryStatus(str, Enum):
    PENDING = "pending"
    DELIVERED = "delivered"
    ACKNOWLEDGED = "acknowledged"
    REJECTED = "rejected"
    EXPIRED = "expired"


@dataclass(frozen=True)
class MessageEnvelope:
    message: Message
    priority: int = 0
    reply_to: Optional[str] = None
    expires_at: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: new_id("env"))
    at: datetime = field(default_factory=lambda: SYSTEM_CLOCK.now())


@dataclass(frozen=True)
class MessageRoute:
    recipient_id: str
    mailbox_id: str


@dataclass(frozen=True)
class DeliveryReceipt:
    message_id: str
    recipient_id: str
    status: DeliveryStatus
    delivered_at: Optional[datetime] = None
    acknowledged_at: Optional[datetime] = None
    reason: Optional[str] = None
