from __future__ import annotations

from datetime import datetime
from threading import RLock
from typing import Dict, Optional

from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.domain.message import Message

from .mailbox import Mailbox
from .router import MessageRouter
from .types import DeliveryReceipt, DeliveryStatus, MessageEnvelope


class MessageBroker:
    """Durable event-backed structured agent communication broker."""

    def __init__(
        self,
        *,
        event_bus: EventBus,
        router: Optional[MessageRouter] = None,
    ):
        self.event_bus = event_bus
        self.router = router or MessageRouter()
        self._lock = RLock()
        self._mailboxes: Dict[str, Mailbox] = {}

    def mailbox(self, agent_id: str) -> Mailbox:
        with self._lock:
            mailbox = self._mailboxes.get(agent_id)
            if mailbox is None:
                mailbox = Mailbox(agent_id)
                self._mailboxes[agent_id] = mailbox
                try:
                    self.router.register(agent_id, mailbox)
                except ValueError:
                    existing = self.router.mailbox(agent_id)
                    if existing is not mailbox:
                        raise
            return mailbox

    def register_agent(self, agent_id: str) -> Mailbox:
        return self.mailbox(agent_id)

    def send(
        self,
        message: Message,
        *,
        priority: int = 0,
        reply_to: Optional[str] = None,
        expires_at: Optional[datetime] = None,
        metadata=None,
    ) -> DeliveryReceipt:
        envelope = MessageEnvelope(
            message=message,
            priority=priority,
            reply_to=reply_to,
            expires_at=expires_at,
            metadata=dict(metadata or {}),
        )

        self.router.route(envelope)

        existing = self._find_message(message.id)
        if existing is not None:
            return existing

        self.event_bus.publish(
            Event(
                type="MessageSent",
                aggregate_type="message",
                aggregate_id=message.id,
                payload={
                    "message_id": message.id,
                    "sender_id": message.sender_id,
                    "recipient_id": message.recipient_id,
                    "type": message.type,
                    "payload": dict(message.payload),
                    "correlation_id": message.correlation_id,
                    "priority": priority,
                    "reply_to": reply_to,
                    "expires_at": (
                        expires_at.isoformat()
                        if expires_at is not None
                        else None
                    ),
                    "metadata": dict(metadata or {}),
                },
            )
        )

        mailbox = self.mailbox(message.recipient_id)
        mailbox.enqueue(envelope)

        receipt = mailbox.deliver(message.id)

        if receipt.status == DeliveryStatus.DELIVERED:
            self.event_bus.publish(
                Event(
                    type="MessageDelivered",
                    aggregate_type="message",
                    aggregate_id=message.id,
                    payload={
                        "message_id": message.id,
                        "recipient_id": message.recipient_id,
                        "status": receipt.status.value,
                        "delivered_at": (
                            receipt.delivered_at.isoformat()
                            if receipt.delivered_at
                            else None
                        ),
                    },
                )
            )
        elif receipt.status == DeliveryStatus.EXPIRED:
            self.event_bus.publish(
                Event(
                    type="MessageExpired",
                    aggregate_type="message",
                    aggregate_id=message.id,
                    payload={
                        "message_id": message.id,
                        "recipient_id": message.recipient_id,
                        "reason": receipt.reason,
                    },
                )
            )

        return receipt

    def acknowledge(
        self,
        agent_id: str,
        message_id: str,
    ) -> DeliveryReceipt:
        mailbox = self.mailbox(agent_id)
        existing = mailbox.receipt(message_id)

        if existing.status == DeliveryStatus.ACKNOWLEDGED:
            return existing

        receipt = mailbox.acknowledge(message_id)

        self.event_bus.publish(
            Event(
                type="MessageAcknowledged",
                aggregate_type="message",
                aggregate_id=message_id,
                payload={
                    "message_id": message_id,
                    "recipient_id": agent_id,
                    "acknowledged_at": (
                        receipt.acknowledged_at.isoformat()
                        if receipt.acknowledged_at
                        else None
                    ),
                },
            )
        )

        return receipt

    def reject(
        self,
        agent_id: str,
        message_id: str,
        reason: str,
    ) -> DeliveryReceipt:
        receipt = self.mailbox(agent_id).reject(message_id, reason)

        if receipt.status == DeliveryStatus.REJECTED:
            history = self.event_bus.history("MessageRejected")
            if not any(
                event.payload.get("message_id") == message_id
                for event in history
            ):
                self.event_bus.publish(
                    Event(
                        type="MessageRejected",
                        aggregate_type="message",
                        aggregate_id=message_id,
                        payload={
                            "message_id": message_id,
                            "recipient_id": agent_id,
                            "reason": reason,
                        },
                    )
                )

        return receipt

    def expire(
        self,
        agent_id: str,
        message_id: str,
    ) -> DeliveryReceipt:
        receipt = self.mailbox(agent_id).expire(message_id)

        if receipt.status == DeliveryStatus.EXPIRED:
            history = self.event_bus.history("MessageExpired")
            if not any(
                event.payload.get("message_id") == message_id
                for event in history
            ):
                self.event_bus.publish(
                    Event(
                        type="MessageExpired",
                        aggregate_type="message",
                        aggregate_id=message_id,
                        payload={
                            "message_id": message_id,
                            "recipient_id": agent_id,
                            "reason": receipt.reason,
                        },
                    )
                )

        return receipt

    def pending(self, agent_id: str):
        return self.mailbox(agent_id).pending()

    def rebuild(self) -> None:
        """Rebuild all mailbox projections exclusively from event history."""

        sent: Dict[str, MessageEnvelope] = {}
        states: Dict[str, DeliveryReceipt] = {}

        for event in self.event_bus.history():
            if event.type == "MessageSent":
                payload = event.payload
                expires_at = payload.get("expires_at")
                envelope = MessageEnvelope(
                    message=Message(
                        sender_id=str(payload["sender_id"]),
                        recipient_id=str(payload["recipient_id"]),
                        type=str(payload["type"]),
                        payload=dict(payload.get("payload", {})),
                        correlation_id=payload.get("correlation_id"),
                        id=str(payload["message_id"]),
                        at=event.at,
                    ),
                    priority=int(payload.get("priority", 0)),
                    reply_to=payload.get("reply_to"),
                    expires_at=(
                        datetime.fromisoformat(expires_at)
                        if expires_at
                        else None
                    ),
                    metadata=dict(payload.get("metadata", {})),
                    at=event.at,
                )
                sent[envelope.message.id] = envelope

            elif event.type == "MessageDelivered":
                message_id = str(event.payload["message_id"])
                states[message_id] = DeliveryReceipt(
                    message_id=message_id,
                    recipient_id=str(event.payload["recipient_id"]),
                    status=DeliveryStatus.DELIVERED,
                    delivered_at=(
                        datetime.fromisoformat(event.payload["delivered_at"])
                        if event.payload.get("delivered_at")
                        else None
                    ),
                )

            elif event.type == "MessageAcknowledged":
                message_id = str(event.payload["message_id"])
                previous = states.get(message_id)
                states[message_id] = DeliveryReceipt(
                    message_id=message_id,
                    recipient_id=str(event.payload["recipient_id"]),
                    status=DeliveryStatus.ACKNOWLEDGED,
                    delivered_at=(
                        previous.delivered_at
                        if previous is not None
                        else None
                    ),
                    acknowledged_at=(
                        datetime.fromisoformat(
                            event.payload["acknowledged_at"]
                        )
                        if event.payload.get("acknowledged_at")
                        else None
                    ),
                )

            elif event.type in {"MessageRejected", "MessageExpired"}:
                message_id = str(event.payload["message_id"])
                previous = states.get(message_id)
                status = (
                    DeliveryStatus.REJECTED
                    if event.type == "MessageRejected"
                    else DeliveryStatus.EXPIRED
                )
                states[message_id] = DeliveryReceipt(
                    message_id=message_id,
                    recipient_id=str(event.payload["recipient_id"]),
                    status=status,
                    delivered_at=(
                        previous.delivered_at
                        if previous is not None
                        else None
                    ),
                    acknowledged_at=(
                        previous.acknowledged_at
                        if previous is not None
                        else None
                    ),
                    reason=event.payload.get("reason"),
                )

        with self._lock:
            recipient_ids = {
                envelope.message.recipient_id
                for envelope in sent.values()
            }

            for recipient_id in recipient_ids:
                self.mailbox(recipient_id)

            grouped: Dict[str, list[MessageEnvelope]] = {}
            for envelope in sent.values():
                grouped.setdefault(
                    envelope.message.recipient_id, []
                ).append(envelope)

            for recipient_id, mailbox in self._mailboxes.items():
                mailbox.rebuild(
                    grouped.get(recipient_id, []),
                    {
                        message_id: receipt
                        for message_id, receipt in states.items()
                        if sent.get(message_id)
                        and sent[message_id].message.recipient_id
                        == recipient_id
                    },
                )

    def _find_message(
        self,
        message_id: str,
    ) -> Optional[DeliveryReceipt]:
        for agent_id in self.router.recipients():
            mailbox = self.router.mailbox(agent_id)
            try:
                return mailbox.receipt(message_id)
            except KeyError:
                continue
        return None
