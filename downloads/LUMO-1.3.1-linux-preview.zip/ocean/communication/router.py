from __future__ import annotations

from threading import RLock
from typing import Dict, Iterable, List

from .types import MessageEnvelope, MessageRoute


class MessageRouter:
    """Thread-safe recipient-to-mailbox routing registry."""

    def __init__(self):
        self._lock = RLock()
        self._mailboxes: Dict[str, object] = {}

    def register(self, agent_id: str, mailbox: object) -> None:
        with self._lock:
            existing = self._mailboxes.get(agent_id)
            if existing is mailbox:
                return
            if existing is not None:
                raise ValueError(
                    f"mailbox already registered for agent {agent_id!r}"
                )
            self._mailboxes[agent_id] = mailbox

    def unregister(self, agent_id: str) -> None:
        with self._lock:
            self._mailboxes.pop(agent_id, None)

    def route(self, envelope: MessageEnvelope) -> MessageRoute:
        recipient = envelope.message.recipient_id
        with self._lock:
            if recipient not in self._mailboxes:
                raise KeyError(
                    f"unknown message recipient: {recipient!r}"
                )
        return MessageRoute(
            recipient_id=recipient,
            mailbox_id=recipient,
        )

    def mailbox(self, agent_id: str):
        with self._lock:
            mailbox = self._mailboxes.get(agent_id)
            if mailbox is None:
                raise KeyError(f"unknown mailbox: {agent_id!r}")
            return mailbox

    def recipients(self):
        with self._lock:
            return tuple(self._mailboxes.keys())

    def broadcast(
        self,
        envelope: MessageEnvelope,
        recipient_ids: Iterable[str],
    ) -> List[MessageEnvelope]:
        copies = []

        for recipient_id in recipient_ids:
            with self._lock:
                if recipient_id not in self._mailboxes:
                    raise KeyError(
                        f"unknown message recipient: {recipient_id!r}"
                    )

            copies.append(
                MessageEnvelope(
                    message=type(envelope.message)(
                        sender_id=envelope.message.sender_id,
                        recipient_id=recipient_id,
                        type=envelope.message.type,
                        payload=dict(envelope.message.payload),
                        correlation_id=envelope.message.correlation_id,
                    ),
                    priority=envelope.priority,
                    reply_to=envelope.reply_to,
                    expires_at=envelope.expires_at,
                    metadata=dict(envelope.metadata),
                )
            )

        return copies
