"""Durable local device identity, capability, and availability registry."""
from __future__ import annotations
import json
import hashlib
import secrets
import platform
import sqlite3
import threading
import time
import os
from dataclasses import dataclass
from typing import Any, Mapping
from ocean.core.ids import new_id

@dataclass(frozen=True)
class DeviceProfile:
    id: str
    account_id: str
    name: str
    platform: str
    architecture: str
    capabilities: Mapping[str, Any]
    capability_source: str = "reported"
    status: str = "offline"
    last_seen: float = 0.0

class DeviceRegistry:
    """Single-machine durable device authority; cloud sync can consume this later."""
    def __init__(self, path):
        self._path = str(path)
        self._lock = threading.RLock()
        with self._connect() as db:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS devices (
              id TEXT PRIMARY KEY, account_id TEXT NOT NULL, name TEXT NOT NULL,
              platform TEXT NOT NULL, architecture TEXT NOT NULL,
              capabilities TEXT NOT NULL, capability_source TEXT NOT NULL DEFAULT 'reported',
              status TEXT NOT NULL, last_seen REAL NOT NULL, created_at REAL NOT NULL, updated_at REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_devices_account ON devices(account_id);
            CREATE TABLE IF NOT EXISTS pairing_codes (code_hash TEXT PRIMARY KEY, account_id TEXT NOT NULL, expires_at REAL NOT NULL, used INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS device_control (
              device_id TEXT PRIMARY KEY, mode TEXT NOT NULL DEFAULT 'active',
              revoked INTEGER NOT NULL DEFAULT 0, health TEXT NOT NULL DEFAULT '{}',
              updated_at REAL NOT NULL
            );
            """)
            columns = {row[1] for row in db.execute("PRAGMA table_info(devices)").fetchall()}
            if "capability_source" not in columns:
                db.execute("ALTER TABLE devices ADD COLUMN capability_source TEXT NOT NULL DEFAULT 'reported'")
                db.commit()

    def _connect(self):
        db = sqlite3.connect(self._path, timeout=30)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("PRAGMA synchronous=NORMAL")
        db.execute("PRAGMA busy_timeout=30000")
        return db

    def register(self, account_id: str, *, name: str | None = None,
                 capabilities: Mapping[str, Any] | None = None, device_id: str | None = None):
        if not account_id.strip(): raise ValueError("account_id is required")
        now = time.time(); device_id = device_id or new_id("device")
        detected = capabilities is None
        profile = DeviceProfile(
            device_id, account_id, name or platform.node(),
            platform.system().lower(), platform.machine(),
            dict(capabilities or self.detect_capabilities()),
            "measured" if detected else "reported",
            "online", now,
        )
        with self._lock, self._connect() as db:
            existing = db.execute("SELECT account_id FROM devices WHERE id=?", (profile.id,)).fetchone()
            if existing is not None and str(existing["account_id"]) != profile.account_id:
                raise PermissionError("device id is already owned by another account")
            db.execute("""INSERT INTO devices
                (id,account_id,name,platform,architecture,capabilities,capability_source,status,last_seen,created_at,updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET name=excluded.name,
                platform=excluded.platform, architecture=excluded.architecture,
                capabilities=excluded.capabilities, capability_source=excluded.capability_source,
                status='online', last_seen=excluded.last_seen, updated_at=excluded.updated_at""",
                (profile.id, profile.account_id, profile.name, profile.platform, profile.architecture,
                 json.dumps(profile.capabilities, sort_keys=True), profile.capability_source, profile.status, profile.last_seen, now, now))
        return profile

    @staticmethod
    def detect_capabilities() -> dict[str, Any]:
        system = platform.system()
        memory_bytes = None
        if system == "Darwin":
            try:
                import subprocess
                memory_bytes = int(subprocess.check_output(["/usr/sbin/sysctl", "-n", "hw.memsize"], text=True).strip())
            except (OSError, ValueError, subprocess.CalledProcessError):
                memory_bytes = None
        return {
            "worlds": True,
            "background_execution": True,
            "wake_from_sleep": system == "Darwin" and os.path.exists("/usr/bin/pmset"),
            "cold_boot": False,
            "display_sleep_allowed": True,
            "local_model_max_gib": 10.0,
            "cpu_count": os.cpu_count() or 1,
            "memory_bytes": memory_bytes,
            "power_policy": "lease_only",
        }

    def heartbeat(self, device_id: str, *, status: str = "online", account_id: str | None = None) -> DeviceProfile:
        if account_id is None or not str(account_id).strip():
            raise PermissionError("device heartbeat requires account scope")
        if status not in {"online", "offline"}:
            raise ValueError("device status must be online or offline")
        now = time.time()
        with self._lock, self._connect() as db:
            db.execute("UPDATE devices SET status=?, last_seen=?, updated_at=? WHERE id=? AND account_id=?",
                       (status, now, now, device_id, account_id))
            row = db.execute("SELECT * FROM devices WHERE id=? AND account_id=?", (device_id, account_id)).fetchone()
        if row is None: raise KeyError(device_id)
        return self._row(row)

    def mark_stale(self, *, after_seconds: float = 30.0) -> int:
        cutoff = time.time() - max(1.0, float(after_seconds))
        with self._lock, self._connect() as db:
            result = db.execute("UPDATE devices SET status='offline', updated_at=? WHERE status='online' AND last_seen<?",
                                (time.time(), cutoff))
            return result.rowcount

    def get(self, device_id: str) -> DeviceProfile:
        with self._lock, self._connect() as db:
            row = db.execute("SELECT * FROM devices WHERE id=?", (device_id,)).fetchone()
        if row is None: raise KeyError(device_id)
        return self._row(row)

    def delete_account(self, account_id: str) -> None:
        with self._lock, self._connect() as db:
            ids=[r[0] for r in db.execute("SELECT id FROM devices WHERE account_id=?", (account_id,)).fetchall()]
            if ids:
                db.executemany("DELETE FROM device_control WHERE device_id=?", [(x,) for x in ids])
                db.executemany("DELETE FROM devices WHERE id=?", [(x,) for x in ids])
            db.execute("DELETE FROM pairing_codes WHERE account_id=?", (account_id,))

    def list(self, account_id: str) -> list[DeviceProfile]:
        with self._lock, self._connect() as db:
            rows = db.execute("SELECT * FROM devices WHERE account_id=? ORDER BY name,id", (account_id,)).fetchall()
        return [self._row(row) for row in rows]

    @staticmethod
    def trusted_capabilities(device: DeviceProfile) -> dict[str, Any]:
        """Return only capabilities that this registry has measured locally.

        Remote registration is intentionally treated as an untrusted claim. A
        device cannot self-escalate compute, power, World, or model ceilings by
        POSTing a larger capability map. A future authenticated pairing flow
        can promote a reported device to measured capabilities.
        """
        if device.capability_source != "measured":
            return {}
        return dict(device.capabilities)

    def remove(self, account_id: str, device_id: str) -> None:
        with self._lock, self._connect() as db:
            result = db.execute("DELETE FROM devices WHERE id=? AND account_id=?", (device_id, account_id))
        if result.rowcount != 1: raise KeyError(device_id)

    @staticmethod
    def _row(row: sqlite3.Row) -> DeviceProfile:
        return DeviceProfile(id=row["id"], account_id=row["account_id"], name=row["name"],
            platform=row["platform"], architecture=row["architecture"],
            capabilities=json.loads(row["capabilities"]),
            capability_source=str(row["capability_source"] or "reported"),
            status=row["status"], last_seen=row["last_seen"])

    def close(self) -> None:
        return None

class DeviceLifecycleController:
    """Durable trust and scheduling state for registered devices."""
    def __init__(self, registry: DeviceRegistry):
        self._registry=registry
        self._lock=threading.RLock()

    def issue_pairing_code(self, account_id: str, ttl_seconds: int = 300) -> str:
        if not account_id.strip() or isinstance(ttl_seconds, bool) or ttl_seconds <= 0 or ttl_seconds > 3600:
            raise ValueError("invalid pairing code policy")
        code=secrets.token_urlsafe(9)
        digest=hashlib.sha256(code.encode()).hexdigest()
        with self._registry._lock, self._registry._connect() as db:
            db.execute("INSERT INTO pairing_codes VALUES(?,?,?,0)",(digest,account_id,time.time()+ttl_seconds))
        return code

    def redeem_pairing_code(self, account_id: str, code: str) -> bool:
        if not account_id.strip() or not code: raise ValueError("account_id and pairing code are required")
        digest=hashlib.sha256(code.encode()).hexdigest()
        with self._registry._lock, self._registry._connect() as db:
            row=db.execute("SELECT account_id,expires_at,used FROM pairing_codes WHERE code_hash=?",(digest,)).fetchone()
            if row is None or row[0] != account_id or row[2] or time.time() >= float(row[1]): return False
            db.execute("UPDATE pairing_codes SET used=1 WHERE code_hash=?",(digest,))
        return True

    def _state(self, device_id: str) -> tuple[str,bool,dict[str,Any]]:
        with self._registry._lock, self._registry._connect() as db:
            row=db.execute("SELECT mode,revoked,health FROM device_control WHERE device_id=?",(device_id,)).fetchone()
        if row is None: return "active",False,{}
        return str(row["mode"]),bool(row["revoked"]),json.loads(row["health"] or "{}")

    def _save(self, device_id: str, *, mode: str|None=None, revoked: bool|None=None, health: dict[str,Any]|None=None) -> None:
        old_mode,old_revoked,old_health=self._state(device_id)
        with self._registry._lock, self._registry._connect() as db:
            db.execute("""INSERT INTO device_control(device_id,mode,revoked,health,updated_at) VALUES(?,?,?,?,?)
                ON CONFLICT(device_id) DO UPDATE SET mode=excluded.mode,revoked=excluded.revoked,health=excluded.health,updated_at=excluded.updated_at""",
                (device_id, mode if mode is not None else old_mode, int(old_revoked if revoked is None else revoked),
                 json.dumps(health if health is not None else old_health,sort_keys=True),time.time()))

    def _owned(self, account_id:str, device_id:str)->DeviceProfile:
        device=self._registry.get(device_id)
        if device.account_id != account_id: raise PermissionError("device belongs to another account")
        return device

    def set_mode(self, account_id:str, device_id:str, mode:str)->DeviceProfile:
        if mode not in {"active","drain","maintenance"}: raise ValueError("invalid device mode")
        device=self._owned(account_id,device_id)
        with self._lock: self._save(device_id,mode=mode)
        return device

    def mode(self, account_id:str, device_id:str)->str:
        self._owned(account_id,device_id)
        with self._lock: return self._state(device_id)[0]

    def can_schedule(self, account_id:str, device_id:str)->bool:
        self._owned(account_id,device_id)
        mode,revoked,_=self._state(device_id)
        return mode=="active" and not revoked

    def revoke(self, account_id:str, device_id:str)->None:
        self._owned(account_id,device_id)
        with self._lock: self._save(device_id,mode="maintenance",revoked=True)
        self._registry.heartbeat(device_id,status="offline",account_id=account_id)

    def record_health(self, account_id:str, device_id:str, **telemetry:Any)->dict[str,Any]:
        self._owned(account_id,device_id)
        allowed={"battery_percent","temperature_c","network_online","storage_free_bytes","gpu_available","memory_free_bytes"}
        clean={k:v for k,v in telemetry.items() if k in allowed}
        if "battery_percent" in clean and not 0 <= float(clean["battery_percent"]) <= 100: raise ValueError("battery_percent must be 0..100")
        if "temperature_c" in clean and not -50 <= float(clean["temperature_c"]) <= 150: raise ValueError("temperature_c outside safety range")
        with self._lock: self._save(device_id,health=clean)
        return dict(clean)

    def health(self, account_id:str, device_id:str)->dict[str,Any]:
        self._owned(account_id,device_id)
        with self._lock: return dict(self._state(device_id)[2])
