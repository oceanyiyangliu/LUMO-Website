"""Persistent autonomous service infrastructure for Ocean Agent OS.

The service wires together the full autonomous stack:

- Durable event store (SQLite WAL)
- EventBus with synchronous dispatch
- DeliveryCoordinator for durable subscriber delivery
- LeaseExpirySweeper for automatic lease management
- Scheduler with daemon execution loop
- Orchestrator for assignment lifecycle
- MissionEngine for autonomous mission execution
- Graceful shutdown handling

Usage::

    from ocean.service import OceanService

    service = OceanService(repository_root=Path.cwd())
    service.start()
    result = service.run_mission("Complete Ocean OS")
    service.stop()
"""

from __future__ import annotations

import logging
import os
import signal
import sqlite3
import threading
from pathlib import Path
from typing import Optional, Callable

from eventing.delivery_coordinator import DeliveryCoordinator
from eventing.sqlite_store import SQLiteEventStore
from ocean.domain.event_bus import EventBus
from ocean.observability.status import LiveStatusReader
from ocean.orchestration.autonomous_build import RuntimeAutonomousBuildExecutor
from ocean.orchestration.mission_engine import (
    MissionContract,
    MissionEngine,
    MissionObjective,
    MissionObjectiveResult,
    StrategicMissionPlanner,
)
from ocean.orchestration.strategic_model_provider import build_strategic_model
from ocean.self_improvement.runtime import AutonomousImprovementRuntime, RuntimeBenchmarkProvider
from ocean.workforce.lease_sweeper import LeaseExpirySweeper
from ocean.worlds import BrowserWorldProvider, DesktopWorldProvider, WorldManager
from ocean.domain.enums import WorldStatus
from ocean.domain.world import World, WorldRequirements
from ocean.active_assistant import ActiveAssistant
from ocean.power import PowerGuardian
from ocean.resilience import DependencyRecovery
from ocean.device_registry import DeviceRegistry, DeviceLifecycleController
from ocean.device_scheduler import DeviceWorkloadScheduler
from ocean.node import NodeRegistry, RootAuthority
from ocean.tenancy import TenancyStore
from ocean.platforms import runtime_state_dir

logger = logging.getLogger(__name__)


class OceanService:
    """Persistent autonomous service for Ocean Agent OS.

    Manages the lifecycle of all background services and provides
    a clean interface for running missions and inspecting state.
    """

    def __init__(
        self,
        *,
        repository_root: Path | None = None,
        lease_sweep_interval: float = 10.0,
        delivery_poll_interval: float = 0.5,
    ) -> None:
        configured_root = os.getenv("LUMO_REPOSITORY_ROOT")
        if configured_root:
            candidate_root = Path(configured_root).expanduser()
        elif repository_root is not None:
            candidate_root = repository_root
        else:
            candidate_root = Path.cwd()
        self._repository_root = candidate_root.resolve()
        self._lease_sweep_interval = lease_sweep_interval
        self._delivery_poll_interval = delivery_poll_interval

        configured_state = os.environ.get("LUMO_STATE_DIR", "").strip()
        # Development/test services remain repository-local for isolation. Installed
        # LUMO instances explicitly opt into platform-native application storage so
        # Windows/Linux/macOS builds never depend on the source tree for mutable state.
        if configured_state:
            self._state_dir = Path(configured_state).expanduser()
        elif os.environ.get("LUMO_LOCAL_INSTALL") == "1":
            self._state_dir = runtime_state_dir()
        else:
            self._state_dir = self._repository_root / ".ocean"
        if not self._state_dir.is_absolute():
            self._state_dir = (self._repository_root / self._state_dir).resolve()
        self._state_dir.mkdir(parents=True, exist_ok=True)
        self._database_path = self._state_dir / "state.sqlite3"

        self._connection: Optional[sqlite3.Connection] = None
        self._event_store: Optional[SQLiteEventStore] = None
        self._events: Optional[EventBus] = None
        self._delivery_coordinator: Optional[DeliveryCoordinator] = None
        self._delivery_thread: Optional[threading.Thread] = None
        self._lease_sweeper: Optional[LeaseExpirySweeper] = None
        self._runtime: Optional[AutonomousImprovementRuntime] = None
        self._started = False
        self._shutdown_event = threading.Event()
        self._worlds = WorldManager([
            BrowserWorldProvider(headless=True),
            DesktopWorldProvider(root=self._repository_root / ".lumo-worlds"),
        ])
        # Enabling the companion never enables host observation. Observation is
        # an explicit user action through the assistant observation controls.
        self._active_assistant = ActiveAssistant()
        self._dependency_recovery = DependencyRecovery()
        self._power = PowerGuardian()
        self._devices = DeviceRegistry(self._state_dir / "devices.sqlite3")
        self._device_lifecycle = DeviceLifecycleController(self._devices)
        self._device_scheduler = DeviceWorkloadScheduler(self._devices, self._device_lifecycle)
        # LUMO Root owns authority; Nodes execute locally on their own devices.
        self._root_authority = RootAuthority(self._state_dir)
        self._nodes = NodeRegistry(self._state_dir / "nodes.sqlite3", self._root_authority)
        tenancy_path = Path(os.environ.get("LUMO_TENANCY_STORE", str(self._state_dir / "tenancy.sqlite3"))).expanduser()
        if not tenancy_path.is_absolute():
            tenancy_path = (self._repository_root / tenancy_path).resolve()
        tenancy_path.parent.mkdir(parents=True, exist_ok=True)
        self._tenancy = TenancyStore(tenancy_path)

    @property
    def repository_root(self) -> Path:
        return self._repository_root

    @property
    def database_path(self) -> Path:
        return self._database_path

    @property
    def is_running(self) -> bool:
        return self._started

    @property
    def events(self) -> EventBus | None:
        return self._events

    @property
    def event_store(self) -> SQLiteEventStore | None:
        return self._event_store

    @property
    def worlds(self) -> WorldManager:
        return self._worlds

    @property
    def active_assistant(self) -> ActiveAssistant:
        return self._active_assistant

    @property
    def dependency_recovery(self) -> DependencyRecovery:
        return self._dependency_recovery

    @property
    def power(self) -> PowerGuardian:
        return self._power

    @property
    def devices(self) -> DeviceRegistry:
        return self._devices

    @property
    def device_lifecycle(self) -> DeviceLifecycleController:
        return self._device_lifecycle

    @property
    def device_scheduler(self) -> DeviceWorkloadScheduler:
        return self._device_scheduler

    @property
    def root_authority(self) -> RootAuthority:
        return self._root_authority

    @property
    def nodes(self) -> NodeRegistry:
        return self._nodes

    @property
    def tenancy(self) -> TenancyStore:
        return self._tenancy

    @property
    def mission_execution_error(self) -> str | None:
        """Return a deterministic startup error when mission execution is unavailable."""
        if self._runtime is None:
            return "autonomous local-model runtime is unavailable; service started in background-only mode"
        return None

    def _on_mission_human_action_required(self, event: Any) -> None:
        payload = dict(getattr(event, "payload", {}) or {})
        reason = str(payload.get("reason") or "This mission needs your input before I can continue.").strip()
        dependencies = payload.get("dependencies") or ()
        names = [str(x).strip() for x in dependencies if str(x).strip()]
        goal = str(payload.get("goal") or "").strip()
        if names:
            reason = f"I need your help with {', '.join(names)} before I can continue. {reason}"
        if goal:
            suggestion = "Mission paused. Resolve this requirement and I’ll resume automatically."
        else:
            suggestion = "Mission paused. Complete the requested step and I’ll resume automatically."
        self._active_assistant.notify_human_action(message=reason, suggestion=suggestion, urgency="important")

    def start(self) -> None:
        """Start all background services."""
        if self._started:
            return

        logger.info("starting Ocean service (root=%s)", self._repository_root)

        self._connection = sqlite3.connect(
            str(self._database_path),
            check_same_thread=False,
        )
        self._connection.execute("PRAGMA journal_mode=WAL")
        self._connection.execute("PRAGMA synchronous=NORMAL")
        self._connection.execute("PRAGMA busy_timeout=30000")

        self._event_store = SQLiteEventStore(self._connection)
        self._events = EventBus(store=self._event_store)
        # Authority-boundary events are surfaced through the Active Assistant so
        # the user never has to monitor a technical dashboard for credentials,
        # account creation, consent, or other human-only prerequisites.
        self._events.subscribe("MissionBlockedPendingUser", self._on_mission_human_action_required)
        self._worlds.set_event_sink(self._events.publish)
        self._dependency_recovery = DependencyRecovery(events=self._events)
        self._hydrate_worlds()

        self._delivery_coordinator = DeliveryCoordinator(
            database_path=str(self._database_path),
            poll_interval=self._delivery_poll_interval,
        )
        self._delivery_thread = threading.Thread(
            target=self._delivery_coordinator.run,
            name="ocean-delivery",
            daemon=True,
        )
        self._delivery_thread.start()

        try:
            self._runtime = AutonomousImprovementRuntime(
                repository_root=self._repository_root,
                provider_name="ollama",
                model_name=os.getenv("LUMO_LOCAL_MODEL"),
            )
        except RuntimeError:
            logger.exception("autonomous local-model runtime unavailable")
            self._runtime = None

        # The mission runtime may not expose workforce leases; the service
        # must remain startable for mission/API operation in that configuration.
        lease_coordinator = getattr(self._runtime, "leases", None) if self._runtime is not None else None
        if lease_coordinator is not None:
            self._lease_sweeper = LeaseExpirySweeper(
                lease_coordinator=lease_coordinator,
                interval_seconds=self._lease_sweep_interval,
            )
            self._lease_sweeper.start()

        self._started = True
        self._shutdown_event.clear()

        # Active Assistant is a persistent companion, not a dormant demo toggle.
        # It observes the host context only; all consequential computer control
        # is routed through isolated LUMO Worlds.
        self._active_assistant.start()

        self._register_signal_handlers()

        logger.info("Ocean service started")

    def _hydrate_worlds(self) -> None:
        """Replay the world aggregate without touching manager internals."""
        if self._events is None:
            return
        # Hydrate only world aggregates. The previous implementation replayed
        # the entire encrypted event log (tens of thousands of rows) just to find
        # world events, making every launch pay the full event-history decryption
        # cost. The event-store index lets startup touch only relevant aggregates.
        event_store = self._event_store
        if event_store is not None and hasattr(event_store, "list_by_aggregate_type"):
            events = list(event_store.list_by_aggregate_type("world"))
        else:
            events = [
                event for event in self._events.history()
                if event.aggregate_type == "world" or event.type.startswith("World")
            ]
        states: dict[str, dict] = {}
        for event in events:
            payload = dict(event.payload or {})
            world_id = str(payload.get("world_id") or event.aggregate_id or "")
            if not world_id:
                continue
            state = states.setdefault(world_id, {})
            state.update({key: value for key, value in payload.items() if value is not None})
            state["status"] = payload.get("status", state.get("status", "ready"))
        for world_id, payload in states.items():
            req_data = payload.get("requirements") or {}
            try:
                target = WorldStatus(str(payload.get("status", WorldStatus.READY.value)))
                # Terminal worlds are historical facts, not resources to boot.
                # Never provision a provider merely to reconstruct a destroyed
                # or failed world during service startup.
                if target in {WorldStatus.DESTROYED, WorldStatus.FAILED}:
                    world = World(
                        id=world_id, kind=str(payload.get("kind", "browser")),
                        mission_id=payload.get("mission_id"),
                        account_id=payload.get("account_id") or (payload.get("metadata") or {}).get("account_id"),
                        requirements=WorldRequirements(
                            capabilities=tuple(req_data.get("capabilities", ())),
                            resources=dict(req_data.get("resources", {})),
                            persistent=bool(req_data.get("persistent", True)),
                            network=bool(req_data.get("network", True)),
                        ),
                        capabilities=tuple(payload.get("capabilities", ())),
                        resources=dict(payload.get("resources", {})),
                        metadata=dict(payload.get("metadata", {})),
                        snapshot_id=payload.get("snapshot_id"),
                        status=WorldStatus.PROVISIONING,
                    )
                    world.transition(target)
                    self._worlds.register_hydrated(world)
                    continue

                requirements = WorldRequirements(
                    capabilities=tuple(req_data.get("capabilities", ())),
                    resources=dict(req_data.get("resources", {})),
                    persistent=bool(req_data.get("persistent", True)),
                    network=bool(req_data.get("network", True)),
                )
                world = World(
                    id=world_id, kind=str(payload.get("kind", "browser")),
                    mission_id=payload.get("mission_id"),
                    account_id=payload.get("account_id") or (payload.get("metadata") or {}).get("account_id"),
                    requirements=requirements,
                    capabilities=tuple(payload.get("capabilities", ())),
                    resources=dict(payload.get("resources", {})),
                    metadata=dict(payload.get("metadata", {})),
                    snapshot_id=payload.get("snapshot_id"),
                    status=WorldStatus.PROVISIONING,
                )
                if world.kind in {"browser", "desktop"}:
                    provider = self._worlds.provider(world.kind)
                    provider.restore(world)
                if target is WorldStatus.PAUSED:
                    world.transition(WorldStatus.PAUSED)
                elif target is WorldStatus.RUNNING:
                    world.transition(WorldStatus.READY)
                    world.transition(WorldStatus.RUNNING)
                self._worlds.register_hydrated(world)
            except (KeyError, StopIteration, TypeError, ValueError) as exc:
                logger.warning("unable to hydrate world %s: %s", world_id, exc)

    def stop(self) -> None:
        """Stop all background services gracefully."""
        if not self._started:
            return

        logger.info("stopping Ocean service")
        self._shutdown_event.set()

        self._active_assistant.stop()
        self._power.close()

        # Worlds own external resources (QEMU/Chromium). Tear them down before
        # the service drops its durable event-store references so no orphaned
        # execution environments survive a service restart.
        try:
            self._worlds.close()
        except Exception:
            logger.exception("failed to close execution worlds during shutdown")

        if self._lease_sweeper is not None:
            self._lease_sweeper.stop()

        if self._delivery_coordinator is not None:
            self._delivery_coordinator.shutdown()

        # Do not close the primary event-store connection until all service
        # threads have observed shutdown. This keeps teardown deterministic
        # and prevents late background work from racing connection cleanup.
        if self._delivery_thread is not None:
            self._delivery_thread.join(timeout=5.0)
            self._delivery_thread = None

        if self._connection is not None:
            self._connection.close()
            self._connection = None

        self._delivery_coordinator = None
        self._lease_sweeper = None
        self._runtime = None
        self._event_store = None
        self._events = None
        self._started = False
        logger.info("Ocean service stopped")

    def run_mission(
        self,
        goal: str,
        *,
        mission_id: str | None = None,
        max_replans: int = 8,
        contract: MissionContract | None = None,
        account_id: str | None = None,
        cancelled: Callable[[], bool] | None = None,
    ):
        """Run an autonomous mission to completion.

        Returns the MissionResult.
        """
        if not self._started:
            raise RuntimeError("service not started; call start() first")

        if self._runtime is None:
            raise RuntimeError(
                "autonomous local-model runtime is unavailable; service started in background-only mode"
            )

        repository_snapshot = self._runtime.repository_context.build(
            self._repository_root,
            objective=goal,
        )
        repository_context = repository_snapshot.as_prompt_text()
        routing_builder = getattr(repository_snapshot, "as_routing_prompt_text", None)
        routing_repository_context = (
            routing_builder() if callable(routing_builder) else repository_context
        )

        strategic_model = build_strategic_model()
        executor = RuntimeAutonomousBuildExecutor(
            runtime=self._runtime,
            strategic_model=strategic_model,
            repository_context=repository_context,
            routing_repository_context=routing_repository_context,
            world_manager=self._worlds,
            events=self._events,
            account_id=account_id,
        )

        engine = MissionEngine(
            planner=StrategicMissionPlanner(
                model=strategic_model,
                repository_context=repository_context,
            ),
            executor=executor,
            events=self._events,
        )

        return engine.run(
            goal,
            mission_id=mission_id,
            max_replans=max_replans,
            contract=contract or MissionContract.from_goal(goal),
            cancelled=cancelled,
        )

    def run_improvement(
        self,
        objective: str,
        *,
        run_id: str | None = None,
        candidate_id: str | None = None,
        test_timeout_seconds: float = 120.0,
    ):
        """Run one bounded self-improvement cycle through the service runtime.

        The CLI/API control plane delegates here so model credentials remain
        inside the long-lived service process rather than being copied into
        interactive shell environments. Candidate isolation, verification,
        benchmark gates, and promotion policy remain owned by the runtime.
        """
        if not self._started:
            raise RuntimeError("service not started; call start() first")
        if self._runtime is None:
            raise RuntimeError(
                "autonomous improvement runtime is unavailable; "
                "the service has no configured intelligence provider"
            )
        if not isinstance(objective, str) or not objective.strip():
            raise ValueError("objective must not be empty")
        if test_timeout_seconds <= 0:
            raise ValueError("test_timeout_seconds must be greater than 0")
        self._runtime.test_timeout_seconds = float(test_timeout_seconds)
        self._runtime.benchmark_provider = RuntimeBenchmarkProvider(
            self._runtime.test_command,
            self._runtime.test_timeout_seconds,
        )
        return self._runtime.improve(
            objective.strip(),
            improvement_run_id=run_id,
            improvement_candidate_id=candidate_id,
        )

    def get_status(self, mission_id: str):
        """Return live operational status for a mission."""
        if self._event_store is None:
            raise RuntimeError("service not started")

        reader = LiveStatusReader(self._event_store)
        return reader.mission(mission_id)

    def wait_for_shutdown(self) -> None:
        """Block until the service receives a shutdown signal."""
        self._shutdown_event.wait()

    def _register_signal_handlers(self) -> None:
        """Register signal handlers for graceful shutdown."""

        def handle_signal(signum, frame):
            logger.info("received signal %d, initiating shutdown", signum)
            self._shutdown_event.set()

        # Python only permits signal registration from the main thread.
        # Embedded/test hosts can still use ``wait_for_shutdown`` and call
        # ``stop`` explicitly without requiring process-global handlers.
        if threading.current_thread() is threading.main_thread():
            signal.signal(signal.SIGINT, handle_signal)
            signal.signal(signal.SIGTERM, handle_signal)
