"""Canonical LUMO startup state machine.

The UI never invents startup progress. The control plane reconciles this state
from verified facts and exposes the same snapshot to every client.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from enum import Enum
import time

class StartupPhase(str, Enum):
    NEW = "new"
    CORE = "core"
    BOOTSTRAP = "bootstrap"
    INTELLIGENCE = "intelligence"
    PERMISSIONS = "permissions"
    SERVICES = "services"
    VERIFYING = "verifying"
    READY = "ready"
    DEGRADED = "degraded"
    BLOCKED = "blocked"

@dataclass(frozen=True)
class StartupSnapshot:
    phase: str
    progress: float
    message: str
    blocker: str | None
    updated_at: float

class StartupStateMachine:
    """Deterministic, fact-driven startup state.

    Progress is a coarse milestone, never a fake timer. A phase advances only
    when the corresponding verified fact is true.
    """
    def __init__(self) -> None:
        self._snapshot = StartupSnapshot(StartupPhase.NEW.value, 0.0, "Starting LUMO", None, time.time())

    @property
    def snapshot(self) -> StartupSnapshot:
        return self._snapshot

    def reconcile(self, facts: dict[str, object]) -> StartupSnapshot:
        core = bool(facts.get("core"))
        event_store = bool(facts.get("event_store"))
        bootstrap_installed = bool(facts.get("bootstrap_installed"))
        bootstrap_healthy = bool(facts.get("bootstrap_healthy"))
        intelligence = bool(facts.get("intelligence_ready"))
        permissions = bool(facts.get("permissions_ready"))
        permissions_required = bool(facts.get("permissions_required", True))
        optional_permissions = facts.get("optional_permissions") or []
        services = bool(facts.get("services_ready"))
        verified = bool(facts.get("verified"))
        blocker = str(facts.get("blocker") or "") or None

        if not core or not event_store:
            phase, progress, message = StartupPhase.CORE, 0.12, "Starting LUMO Core"
        elif not bootstrap_installed:
            phase, progress, message = StartupPhase.BOOTSTRAP, 0.28, "Preparing bootstrap intelligence"
        elif not bootstrap_healthy:
            phase, progress, message = StartupPhase.BOOTSTRAP, 0.38, "Verifying bootstrap intelligence"
        elif not intelligence:
            phase, progress, message = StartupPhase.INTELLIGENCE, 0.55, "Selecting safe local intelligence"
        elif not permissions and permissions_required:
            phase, progress, message = StartupPhase.PERMISSIONS, 0.68, "Checking macOS permissions"
        elif not services:
            phase, progress, message = StartupPhase.SERVICES, 0.80, "Starting LUMO services"
        elif not verified:
            phase, progress, message = StartupPhase.VERIFYING, 0.92, "Running final startup verification"
        else:
            phase, progress, message = StartupPhase.READY, 1.0, "LUMO is ready"
            if optional_permissions:
                names = ", ".join(str(item) for item in optional_permissions)
                message = f"LUMO is ready — optional Mac access remains: {names}"

        if blocker and phase not in {StartupPhase.READY, StartupPhase.NEW, StartupPhase.INTELLIGENCE, StartupPhase.PERMISSIONS}:
            phase = StartupPhase.BLOCKED
            message = f"LUMO is blocked: {blocker}"
        elif blocker and phase == StartupPhase.PERMISSIONS:
            message = f"Waiting for macOS permission: {blocker}"
        elif blocker and phase == StartupPhase.INTELLIGENCE:
            message = f"Bootstrap intelligence is online; waiting for {blocker}"

        self._snapshot = StartupSnapshot(phase.value, progress, message, blocker, time.time())
        return self._snapshot

    def as_dict(self) -> dict[str, object]:
        return asdict(self._snapshot)

__all__ = ["StartupPhase", "StartupSnapshot", "StartupStateMachine"]
