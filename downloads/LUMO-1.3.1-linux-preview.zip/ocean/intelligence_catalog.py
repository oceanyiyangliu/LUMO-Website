"""LUMO v1 local/cloud intelligence catalog and performance tiers."""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Mapping
from ocean.intelligence_router import ModelManifest, ModelRegistry

class PerformanceLevel(str, Enum):
    AUTO="auto"; QUICK="quick"; STANDARD="standard"; DEEP="deep"; MAX="max"

@dataclass(frozen=True)
class IntelligenceProfile:
    level: PerformanceLevel
    preferred_capabilities: frozenset[str]
    allow_cloud: bool
    max_local_gib: float
    max_workers: int

DEFAULT_LOCAL_MODELS = (
    # Bootstrap intelligence: intentionally tiny and first in the admission ladder.
    ModelManifest("qwen3:0.6b", "ollama", frozenset({"general","routing","memory","tools"}), 8192, 0, 0, 0.45, "local", True, 0.85),
    ModelManifest("qwen3:4b", "ollama", frozenset({"general","routing","memory","tools","reasoning"}), 32768, 0, 0, 3.0, "local", True, 3.5),
    ModelManifest("qwen3:8b", "ollama", frozenset({"general","reasoning","coding","tools","planning"}), 40960, 0, 0, 6.0, "local", True, 6.5),
    ModelManifest("devstral:24b", "ollama", frozenset({"coding","reasoning","tools","planning"}), 131072, 0, 0, 14.0, "local", True, 15.5),
    ModelManifest("qwen3:30b-a3b", "ollama", frozenset({"general","reasoning","coding","tools","planning"}), 262144, 0, 0, 19.0, "local", True, 20.5),
    ModelManifest("qwen2.5vl:7b", "ollama", frozenset({"vision","general","tools"}), 32768, 0, 0, 6.0, "local", True, 6.5),
)

def profile(level: PerformanceLevel) -> IntelligenceProfile:
    return {
        PerformanceLevel.QUICK: IntelligenceProfile(level,frozenset({"general"}),False,4.0,1),
        PerformanceLevel.STANDARD: IntelligenceProfile(level,frozenset({"general","tools"}),False,8.0,2),
        PerformanceLevel.DEEP: IntelligenceProfile(level,frozenset({"reasoning","planning"}),False,20.0,4),
        PerformanceLevel.MAX: IntelligenceProfile(level,frozenset({"reasoning","planning","coding","tools"}),False,64.0,8),
        PerformanceLevel.AUTO: IntelligenceProfile(level,frozenset({"general"}),False,20.0,4),
    }[level]

def build_registry() -> ModelRegistry:
    return ModelRegistry(DEFAULT_LOCAL_MODELS)
