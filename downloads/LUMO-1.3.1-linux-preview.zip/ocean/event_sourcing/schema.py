"""Event schema registry, migration and deterministic audit export."""
from __future__ import annotations
import hashlib, json
from dataclasses import dataclass
from typing import Callable, Iterable
from ocean.domain.event import Event

@dataclass(frozen=True)
class EventSchema:
    event_type: str
    version: int
    required_fields: tuple[str, ...] = ()

class EventSchemaRegistry:
    def __init__(self): self._schemas={}; self._migrations={}
    def register(self, schema: EventSchema):
        if schema.version < 1 or not schema.event_type: raise ValueError("invalid event schema")
        key=(schema.event_type,schema.version)
        if key in self._schemas: raise ValueError(f"schema already registered: {key!r}")
        self._schemas[key]=schema
    def migrate(self, event: Event, target_version: int) -> Event:
        if target_version < event.version: raise ValueError("downgrade is not supported")
        current=event
        while current.version < target_version:
            fn=self._migrations.get((current.type,current.version,current.version+1))
            if fn is None: raise ValueError(f"no migration for {current.type} v{current.version}->v{current.version+1}")
            current=fn(current)
        self.validate(current); return current
    def add_migration(self,event_type,from_version,to_version,fn:Callable[[Event],Event]):
        if to_version != from_version+1: raise ValueError("migrations must advance one version at a time")
        self._migrations[(event_type,from_version,to_version)]=fn
    def validate(self,event: Event):
        schema=self._schemas.get((event.type,event.version))
        if schema is None: return
        missing=[f for f in schema.required_fields if f not in event.payload]
        if missing: raise ValueError(f"event {event.type} missing required fields: {missing}")
        return True

class AuditExporter:
    @staticmethod
    def canonical(events: Iterable[Event]) -> bytes:
        rows=[]
        previous=None
        for e in events:
            row={"id":e.id,"type":e.type,"version":e.version,"aggregate_type":e.aggregate_type,"aggregate_id":e.aggregate_id,"sequence":e.sequence,"causation_id":e.causation_id,"correlation_id":e.correlation_id,"source":e.source,"at":e.at.isoformat(),"payload":e.payload,"previous_hash":previous}
            encoded=json.dumps(row,sort_keys=True,separators=(",",":"),default=str).encode(); digest=hashlib.sha256(encoded).hexdigest(); row["hash"]=digest; previous=digest; rows.append(row)
        return (json.dumps(rows,sort_keys=True,separators=(",",":"),default=str)+"\n").encode()
    @staticmethod
    def digest(events: Iterable[Event]) -> str: return hashlib.sha256(AuditExporter.canonical(events)).hexdigest()
