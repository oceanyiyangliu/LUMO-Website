from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable

from ocean.core.errors import InvalidStateTransition, ValidationError
from ocean.domain.agent import Agent
from ocean.identity import Principal, PrincipalType
from ocean.domain.assignment import Assignment
from ocean.domain.enums import (
    AgentStatus,
    AssignmentStatus,
    AssigneeType,
    MissionStatus,
    OrchestrationMode,
    TaskStatus,
)
from ocean.domain.event import Event
from ocean.domain.execution import Execution
from ocean.domain.mission import Mission
from ocean.delegation.types import DelegationGrant
from ocean.authentication.types import Credential
from ocean.trust.types import EvidenceCategory, EvidenceOutcome, TrustEvidence
from ocean.domain.task import Task
from ocean.domain.verification import Verification
from ocean.self_improvement.types import (
    ImprovementEvaluation,
    ImprovementHypothesis,
    ImprovementRun,
    ImprovementStatus,
)
from ocean.domain.decision import Decision
from ocean.domain.plan import PlanRevision, PlanStatus
from ocean.domain.work_graph import WorkGraph
from persistence.serializers.work_graph import WorkGraphSerializer


@dataclass
class ReplayState:
    agents: Dict[str, Agent] = field(default_factory=dict)
    missions: Dict[str, Mission] = field(default_factory=dict)
    tasks: Dict[str, Task] = field(default_factory=dict)
    assignments: Dict[str, Assignment] = field(default_factory=dict)
    executions: Dict[str, Execution] = field(default_factory=dict)
    verifications: Dict[str, Verification] = field(default_factory=dict)
    decisions: Dict[str, Decision] = field(default_factory=dict)
    plan_revisions: Dict[str, PlanRevision] = field(default_factory=dict)
    work_graphs: Dict[str, WorkGraph] = field(default_factory=dict)
    agent_lineages: Dict[str, dict] = field(default_factory=dict)
    reservations: Dict[str, dict] = field(default_factory=dict)
    principals: Dict[str, Principal] = field(default_factory=dict)

    delegations: Dict[str, DelegationGrant] = field(default_factory=dict)
    credentials: Dict[str, Credential] = field(default_factory=dict)
    trust_evidence: Dict[str, TrustEvidence] = field(default_factory=dict)
    improvement_runs: Dict[str, ImprovementRun] = field(default_factory=dict)
    autonomous_build_states: Dict[str, dict] = field(default_factory=dict)
    auxiliary_events: Dict[str, list[Event]] = field(default_factory=dict)


class ReplayError(Exception):
    """Raised when an event history cannot be deterministically replayed."""


class EventReplayer:
    """
    Reconstructs current domain state from an ordered event history.

    Replay is deliberately pure:
    - it does not persist anything
    - it does not publish events
    - it does not call external services
    - it does not make decisions
    """

    def replay(self, events: Iterable[Event]) -> ReplayState:
        state = ReplayState()

        for event in events:
            self._apply(state, event)

        return state

    def debug_mission(self, events: Iterable[Event], mission_id: str, *, upto_sequence: int | None = None) -> dict:
        """Produce a deterministic, read-only mission replay debugger view.

        The debugger never executes the mission; it replays only the durable
        history and exposes each mission event plus the reconstructed state at
        the requested sequence. This makes historical failures inspectable
        without rerunning side effects.
        """
        if not str(mission_id).strip():
            raise ValueError("mission_id is required")
        if upto_sequence is not None and (isinstance(upto_sequence, bool) or upto_sequence < 0):
            raise ValueError("upto_sequence must be non-negative")
        source = list(events)
        ordered = [e for e in source if str(e.payload.get("mission_id") or e.aggregate_id) == str(mission_id)]
        if upto_sequence is not None:
            ordered = [e for e in ordered if int(e.metadata.get("sequence", e.payload.get("sequence", 0)) or 0) <= upto_sequence]
        state = self.replay(ordered)
        mission = state.missions.get(str(mission_id))
        return {
            "mission_id": str(mission_id),
            "event_count": len(ordered),
            "events": [{"id": e.id, "type": e.type, "at": e.at.isoformat(), "payload": dict(e.payload)} for e in ordered],
            "state": {
                "status": mission.status.value if mission is not None else "unknown",
                "task_ids": list(mission.task_ids) if mission is not None else [],
                "metadata": dict(mission.metadata) if mission is not None else {},
            },
        }

    def replay_from_store(
        self,
        store,
        after_sequence: int = 0,
    ) -> ReplayState:
        if after_sequence < 0:
            raise ValueError("after_sequence must be non-negative")

        events = store.list_after_sequence(after_sequence)
        return self.replay(events)

    def _apply(self, state: ReplayState, event: Event) -> None:
        handler_name = f"_apply_{event.type}"
        handler = getattr(self, handler_name, None)

        if handler is None:
            raise ReplayError(
                f"unsupported event type during replay: {event.type!r}"
            )

        handler(state, event)

    # ------------------------------------------------------------------
    # Autonomous build / candidate isolation events
    # ------------------------------------------------------------------

    def _apply_AutonomousBuildStateChanged(self, state: ReplayState, event: Event) -> None:
        payload = dict(event.payload)
        mission_id = payload.get("mission_id")
        if not mission_id:
            raise ReplayError("AutonomousBuildStateChanged event missing mission_id")
        state.autonomous_build_states[str(mission_id)] = payload

    def _apply_CandidateMissionCreated(self, state: ReplayState, event: Event) -> None:
        payload = event.payload
        mission_id = payload.get("candidate_mission_id") or event.aggregate_id
        if not mission_id:
            raise ReplayError("CandidateMissionCreated event missing candidate_mission_id")
        if str(mission_id) in state.missions:
            raise ReplayError(f"duplicate candidate mission: {mission_id!r}")
        mission = Mission(
            goal=str(payload.get("objective") or payload.get("goal") or "candidate"),
            task_ids=list(payload.get("task_ids", [])),
            metadata={**dict(payload.get("metadata", {})), "candidate": True, "source_mission_id": payload.get("source_mission_id")},
            id=str(mission_id),
        )
        state.missions[mission.id] = mission

    def _apply_CandidateTaskCreated(self, state: ReplayState, event: Event) -> None:
        payload = event.payload
        task_id = payload.get("candidate_task_id") or event.aggregate_id
        if not task_id:
            raise ReplayError("CandidateTaskCreated event missing candidate_task_id")
        if str(task_id) in state.tasks:
            raise ReplayError(f"duplicate candidate task: {task_id!r}")
        task = Task(
            title=str(payload.get("title") or "candidate task"),
            mission_id=payload.get("candidate_mission_id"),
            metadata={"candidate": True, "source_task_id": payload.get("source_task_id"), "source_mission_id": payload.get("source_mission_id")},
            id=str(task_id),
        )
        state.tasks[task.id] = task

    def _apply_MissionStarted(self, state: ReplayState, event: Event) -> None:
        mission_id = event.payload.get("mission_id") or event.aggregate_id
        if not mission_id:
            raise ReplayError("MissionStarted event missing mission_id")
        mission = state.missions.get(str(mission_id))
        if mission is None:
            mission = Mission(goal=str(event.payload.get("goal", "")), id=str(mission_id))
            state.missions[mission.id] = mission
        try:
            if mission.status is MissionStatus.PLANNING:
                mission.transition(MissionStatus.ACTIVE)
        except InvalidStateTransition as exc:
            raise ReplayError(f"invalid MissionStarted event for mission {mission.id!r}") from exc

    def _apply_ObjectiveCompleted(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_MissionReplanStagnated(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_ImprovementRecoveryStarted(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_ImprovementAttemptStarted(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_ImprovementDecisionMade(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_ImprovementAttemptFailed(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_ScheduledExecutionQueued(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_ScheduledExecutionDispatched(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_ScheduledExecutionCompleted(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_ScheduledExecutionFailed(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_ComputerTaskStarted(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_ComputerActionExecuted(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_ComputerTaskCompleted(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_ComputerTaskFinished(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_ComputerTaskFailed(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_TemporalScheduleCreated(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    # These events are durable telemetry/projection facts rather than domain
    # aggregates. Preserve them during replay so unknown telemetry never
    # silently disappears, while keeping the aggregate state pure.
    def _record_auxiliary(self, state: ReplayState, event: Event) -> None:
        state.auxiliary_events.setdefault(event.type, []).append(event)

    def _apply_MessageAcknowledged(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_MessageDelivered(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_MessageExpired(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_MessageRejected(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_MessageSent(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_PlanCoordinatorAdvanced(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_PlanNodeRetryScheduled(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_ResearchFindingRecorded(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_TemporalOccurrenceDue(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_TemporalOccurrenceEnqueued(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_TemporalScheduleCancelled(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_TemporalScheduleCompleted(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_ComputerTaskCancelled(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_ComputerTaskStatusUpdated(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_EmergencyStopEngaged(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_EmergencyStopReleased(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_ImprovementSubmissionAccepted(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_ImprovementSubmissionCompleted(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_ImprovementSubmissionFailed(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_MissionSubmissionAccepted(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_MissionSubmissionCompleted(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_MissionSubmissionFailed(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_MissionCancellationRequested(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    def _apply_UserActionResolved(self, state: ReplayState, event: Event) -> None:
        self._record_auxiliary(state, event)

    # ------------------------------------------------------------------
    # Agent events
    # ------------------------------------------------------------------

    def _apply_AgentCreated(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._require_absent(state.agents, event)

        payload = event.payload

        agent_id = payload.get("agent_id", payload.get("id"))
        if agent_id is None:
            raise ReplayError(
                "AgentCreated event missing agent_id"
            )

        agent = Agent(
            name=str(payload["name"]),
            role=str(payload["role"]),
            capabilities=set(payload.get("capabilities", [])),
            metadata=dict(payload.get("metadata", {})),
            id=str(agent_id),
        )

        state.agents[agent.id] = agent

    def _apply_AgentStateChanged(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        agent_id = str(event.payload["id"])
        agent = state.agents.get(agent_id)

        if agent is None:
            raise ReplayError(
                f"cannot change state of unknown agent: {agent_id!r}"
            )

        try:
            new_status = AgentStatus(event.payload["status"])
            agent.transition(new_status)
        except InvalidStateTransition as exc:
            raise ReplayError(
                f"invalid AgentStateChanged event for agent "
                f"{agent.id!r}: {exc}"
            ) from exc
        except (ValueError, TypeError) as exc:
            raise ReplayError(
                f"invalid AgentStateChanged event for agent {agent_id!r}"
            ) from exc

        if "current_task_id" in event.payload:
            agent.current_task_id = event.payload["current_task_id"]

    def _apply_AgentSpawned(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        agent_id = str(event.payload["agent_id"])
        if agent_id not in state.agents:
            raise ReplayError(
                f"AgentSpawned references unknown agent {agent_id!r}"
            )

    def _apply_AgentLineageEstablished(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        payload = event.payload
        agent_id = str(payload["agent_id"])

        if agent_id not in state.agents:
            raise ReplayError(
                f"lineage references unknown agent {agent_id!r}"
            )

        existing = state.agent_lineages.get(agent_id)
        lineage = {
            "agent_id": agent_id,
            "parent_agent_id": payload.get("parent_agent_id"),
            "generation": int(payload.get("generation", 0)),
            "persistent": bool(payload.get("persistent", True)),
            "provenance": dict(payload.get("provenance", {})),
        }

        if existing is not None and existing != lineage:
            raise ReplayError(
                f"conflicting lineage for agent {agent_id!r}"
            )

        state.agent_lineages[agent_id] = lineage

    def _apply_AgentReserved(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        payload = event.payload
        reservation_id = str(payload["reservation_id"])
        agent_id = str(payload["agent_id"])

        if agent_id not in state.agents:
            raise ReplayError(
                f"reservation references unknown agent {agent_id!r}"
            )

        if reservation_id in state.reservations:
            raise ReplayError(
                f"duplicate reservation {reservation_id!r}"
            )

        state.reservations[reservation_id] = {
            "reservation_id": reservation_id,
            "agent_id": agent_id,
            "task_id": str(payload["task_id"]),
            "assignment_id": None,
        }

    def _apply_AgentReservationBound(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        payload = event.payload
        reservation_id = str(payload["reservation_id"])
        reservation = state.reservations.get(reservation_id)

        if reservation is None:
            raise ReplayError(
                f"cannot bind unknown reservation {reservation_id!r}"
            )

        assignment_id = str(payload["assignment_id"])
        existing = reservation["assignment_id"]

        if existing is not None and existing != assignment_id:
            raise ReplayError(
                f"reservation {reservation_id!r} bound twice"
            )

        reservation["assignment_id"] = assignment_id

    def _apply_AgentReleased(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        reservation_id = str(event.payload["reservation_id"])
        state.reservations.pop(reservation_id, None)

    def _apply_AgentRetired(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        agent_id = str(event.payload["agent_id"])
        if agent_id not in state.agents:
            raise ReplayError(
                f"retirement references unknown agent {agent_id!r}"
            )

    # ------------------------------------------------------------------
    # Identity events
    # ------------------------------------------------------------------

    def _apply_PrincipalCreated(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        payload = event.payload
        principal_id = payload.get(
            "principal_id",
            payload.get("id"),
        )
        if principal_id is None:
            raise ReplayError(
                "PrincipalCreated event missing principal_id"
            )

        principal_id = str(principal_id)
        if principal_id in state.principals:
            raise ReplayError(
                f"duplicate principal creation during replay: "
                f"{principal_id!r}"
            )
        try:
            principal_type = PrincipalType(payload["type"])
            principal = Principal(
                type=principal_type,
                name=str(payload["name"]),
                metadata=dict(payload.get("metadata", {})),
                id=str(principal_id),
            )
        except (KeyError, ValueError, TypeError) as exc:
            raise ReplayError(
                "invalid PrincipalCreated event"
            ) from exc

        state.principals[principal.id] = principal

    def _apply_PrincipalRetired(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        principal_id = str(event.payload["principal_id"])

        if principal_id not in state.principals:
            raise ReplayError(
                f"retirement references unknown principal {principal_id!r}"
            )

        del state.principals[principal_id]

    def _apply_DelegationCreated(self, state: ReplayState, event: Event) -> None:
        payload = event.payload
        delegation_id = payload.get("delegation_id")
        if delegation_id is None:
            raise ReplayError("DelegationCreated event missing delegation_id")
        delegation_id = str(delegation_id)
        if delegation_id in state.delegations:
            raise ReplayError(f"duplicate delegation creation during replay: {delegation_id!r}")
        delegator_id = str(payload["delegator_id"])
        delegate_id = str(payload["delegate_id"])
        if delegator_id not in state.principals:
            raise ReplayError(f"delegation references unknown delegator {delegator_id!r}")
        if delegate_id not in state.principals:
            raise ReplayError(f"delegation references unknown delegate {delegate_id!r}")
        try:
            grant = DelegationGrant(delegator_id=delegator_id, delegate_id=delegate_id, permissions=frozenset(payload["permissions"]), constraints=dict(payload.get("constraints", {})), parent_grant_id=payload.get("parent_grant_id"), expires_at=payload.get("expires_at"), metadata=dict(payload.get("metadata", {})), id=delegation_id, created_at=payload["created_at"])
        except (KeyError, TypeError, ValueError) as exc:
            raise ReplayError("invalid DelegationCreated event") from exc
        state.delegations[grant.id] = grant

    def _apply_DelegationRevoked(self, state: ReplayState, event: Event) -> None:
        delegation_id = str(event.payload["delegation_id"])
        if delegation_id not in state.delegations:
            raise ReplayError(f"revocation references unknown delegation {delegation_id!r}")
        del state.delegations[delegation_id]

    def _apply_CredentialCreated(self, state: ReplayState, event: Event) -> None:
        payload = event.payload
        credential_id = payload.get("credential_id")
        if credential_id is None:
            raise ReplayError("CredentialCreated event missing credential_id")
        credential_id = str(credential_id)
        if credential_id in state.credentials:
            raise ReplayError(
                f"duplicate credential creation during replay: {credential_id!r}"
            )

        principal_id = str(payload["principal_id"])
        if principal_id not in state.principals:
            raise ReplayError(
                f"credential references unknown principal {principal_id!r}"
            )

        try:
            credential = Credential(
                principal_id=principal_id,
                kind=str(payload["kind"]),
                metadata=dict(payload.get("metadata", {})),
                expires_at=payload.get("expires_at"),
                id=credential_id,
                created_at=payload["created_at"],
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise ReplayError("invalid CredentialCreated event") from exc

        state.credentials[credential.id] = credential

    def _apply_CredentialRevoked(self, state: ReplayState, event: Event) -> None:
        credential_id = str(event.payload["credential_id"])
        if credential_id not in state.credentials:
            raise ReplayError(
                f"revocation references unknown credential {credential_id!r}"
            )
        del state.credentials[credential_id]

    def _apply_TrustEvidenceRecorded(self, state: ReplayState, event: Event) -> None:
        payload = event.payload
        evidence_id = payload.get("evidence_id")
        if evidence_id is None:
            raise ReplayError("TrustEvidenceRecorded event missing evidence_id")
        evidence_id = str(evidence_id)
        if evidence_id in state.trust_evidence:
            raise ReplayError(f"duplicate trust evidence during replay: {evidence_id!r}")
        try:
            evidence = TrustEvidence(
                subject_id=str(payload["subject_id"]),
                source_id=str(payload["source_id"]),
                category=EvidenceCategory(payload["category"]),
                outcome=EvidenceOutcome(payload["outcome"]),
                context=dict(payload.get("context", {})),
                confidence=float(payload.get("confidence", 1.0)),
                metadata=dict(payload.get("metadata", {})),
                id=evidence_id,
                at=payload["at"],
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise ReplayError("invalid TrustEvidenceRecorded event") from exc
        state.trust_evidence[evidence.id] = evidence

    # ------------------------------------------------------------------
    # Mission events
    # ------------------------------------------------------------------

    def _apply_MissionCreated(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._require_absent(state.missions, event)

        payload = event.payload

        mission = Mission(
            goal=str(payload["goal"]),
            task_ids=list(payload.get("task_ids", [])),
            metadata=dict(payload.get("metadata", {})),
            id=str(payload.get("id", event.source or event.id)),
        )

        state.missions[mission.id] = mission

    def _apply_MissionActivated(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._transition_mission(
            state,
            event,
            MissionStatus.ACTIVE,
            "activate",
        )

    def _apply_MissionPaused(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._transition_mission(
            state,
            event,
            MissionStatus.PAUSED,
            "pause",
        )

    def _apply_MissionResumed(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._transition_mission(
            state,
            event,
            MissionStatus.ACTIVE,
            "resume",
        )

    def _apply_MissionReplanned(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        mission_id = str(event.payload["id"])
        mission = state.missions.get(mission_id)

        if mission is None:
            raise ReplayError(
                f"cannot replan unknown mission: {mission_id!r}"
            )

        if "goal" not in event.payload:
            raise ReplayError(
                f"MissionReplanned event missing goal for mission {mission_id!r}"
            )

        mission.goal = str(event.payload["goal"])

        if "task_ids" in event.payload:
            mission.task_ids = list(event.payload["task_ids"])

        if "metadata" in event.payload:
            mission.metadata = dict(event.payload["metadata"])

    def _apply_TaskAddedToMission(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        mission_id = str(event.payload["mission_id"])
        task_id = str(event.payload["task_id"])

        mission = state.missions.get(mission_id)

        if mission is None:
            raise ReplayError(
                f"cannot add task to unknown mission: {mission_id!r}"
            )

        if task_id not in state.tasks:
            raise ReplayError(
                f"cannot add unknown task {task_id!r} "
                f"to mission {mission_id!r}"
            )

        mission.add_task(task_id)

    def _apply_MissionCompleted(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._transition_mission(
            state,
            event,
            MissionStatus.COMPLETED,
            "complete",
        )

    def _apply_MissionFailed(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._transition_mission(
            state,
            event,
            MissionStatus.FAILED,
            "fail",
        )

    def _apply_MissionCancelled(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._transition_mission(
            state,
            event,
            MissionStatus.CANCELLED,
            "cancel",
        )

    # ------------------------------------------------------------------
    # Task creation + lifecycle
    # ------------------------------------------------------------------

    def _apply_TaskCreated(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._require_absent(state.tasks, event)

        payload = event.payload

        task = Task(
            title=str(payload["title"]),
            description=str(payload.get("description", "")),
            mission_id=payload.get("mission_id"),
            depends_on=set(payload.get("depends_on", [])),
            assignee_type=payload.get("assignee_type", "agent"),
            assignee_id=payload.get("assignee_id"),
            metadata=dict(payload.get("metadata", {})),
            id=str(payload.get("id", event.source or event.id)),
        )

        state.tasks[task.id] = task

    def _apply_TaskReadied(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._transition_task(
            state,
            event,
            TaskStatus.READY,
            "ready",
        )

    def _apply_TaskQueued(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._transition_task(
            state,
            event,
            TaskStatus.QUEUED,
            "queue",
        )

    def _apply_TaskStarted(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._transition_task(
            state,
            event,
            TaskStatus.RUNNING,
            "start",
        )

    def _apply_TaskWaiting(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._transition_task(
            state,
            event,
            TaskStatus.WAITING,
            "wait",
        )

    def _apply_TaskBlocked(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._transition_task(
            state,
            event,
            TaskStatus.BLOCKED,
            "block",
        )

    def _apply_TaskPaused(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._transition_task(
            state,
            event,
            TaskStatus.PAUSED,
            "pause",
        )

    def _apply_TaskUnblocked(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._transition_task(
            state,
            event,
            TaskStatus.READY,
            "unblock",
        )

    def _apply_TaskFailed(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._transition_task(
            state,
            event,
            TaskStatus.FAILED,
            "fail",
        )

    def _apply_TaskCancelled(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._transition_task(
            state,
            event,
            TaskStatus.CANCELLED,
            "cancel",
        )

    def _apply_TaskReplanned(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        task_id = str(event.payload["id"])
        task = state.tasks.get(task_id)

        if task is None:
            raise ReplayError(
                f"cannot replan unknown task: {task_id!r}"
            )

        task.title = str(event.payload["title"])
        task.description = str(event.payload.get("description", ""))
        task.depends_on = set(event.payload.get("depends_on", []))
        task.assignee_type = AssigneeType(event.payload["assignee_type"])
        task.assignee_id = event.payload.get("assignee_id")
        task.metadata = dict(event.payload.get("metadata", {}))

    def _apply_TaskCompleted(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        task_id = str(event.payload["task_id"])
        verification_id = str(event.payload["verification_id"])

        task = state.tasks.get(task_id)

        if task is None:
            raise ReplayError(
                f"cannot complete unknown task: {task_id!r}"
            )

        verification = state.verifications.get(verification_id)

        if verification is None:
            raise ReplayError(
                f"cannot complete task {task_id!r}: "
                f"unknown verification {verification_id!r}"
            )

        if verification.task_id != task.id:
            raise ReplayError(
                f"verification {verification.id!r} belongs to task "
                f"{verification.task_id!r}, not {task.id!r}"
            )

        if not verification.passed:
            raise ReplayError(
                f"cannot complete task {task.id!r}: "
                "verification did not pass"
            )

        try:
            task.complete(verification)
        except (ValidationError, ValueError) as exc:
            raise ReplayError(
                f"invalid TaskCompleted event for task {task.id!r}"
            ) from exc

    # ------------------------------------------------------------------
    # Assignment events
    # ------------------------------------------------------------------

    def _apply_TaskAssignmentCreated(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        payload = event.payload
        assignment_id = str(
            payload.get("assignment_id", event.aggregate_id or event.id)
        )
        if assignment_id in state.assignments:
            raise ReplayError(
                f"duplicate assignment creation during replay: "
                f"{assignment_id!r} already exists"
            )
        payload = event.payload

        assignment = Assignment(
            task_id=str(payload["task_id"]),
            agent_id=str(payload["agent_id"]),
            mission_id=payload.get("mission_id"),
            mode=OrchestrationMode(payload.get("mode", "standard")),
            priority=int(payload.get("priority", 0)),
            parent_assignment_id=payload.get("parent_assignment_id"),
            reason=payload.get("reason"),
            metadata=dict(payload.get("metadata", {})),
            id=str(payload.get("assignment_id", event.aggregate_id or event.id)),
        )

        state.assignments[assignment.id] = assignment

    def _apply_TaskAssignmentQueued(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._transition_assignment(
            state,
            event,
            AssignmentStatus.QUEUED,
            "queue",
        )

    def _apply_TaskAssignmentActivated(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        assignment_id = str(event.payload["assignment_id"])
        assignment = state.assignments.get(assignment_id)

        if assignment is None:
            raise ReplayError(
                f"cannot activate unknown assignment: {assignment_id!r}"
            )

        execution_id = event.payload.get("execution_id")

        try:
            assignment.activate(execution_id=execution_id)
        except (InvalidStateTransition, ValueError) as exc:
            raise ReplayError(
                f"invalid TaskAssignmentActivated event for assignment "
                f"{assignment_id!r}: {exc}"
            ) from exc

    def _apply_TaskAssignmentCompleted(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._transition_assignment(
            state,
            event,
            AssignmentStatus.COMPLETED,
            "complete",
        )

    def _apply_TaskAssignmentFailed(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        assignment_id = str(event.payload["assignment_id"])
        assignment = state.assignments.get(assignment_id)

        if assignment is None:
            raise ReplayError(
                f"cannot fail unknown assignment: {assignment_id!r}"
            )

        reason = event.payload.get("error")

        try:
            assignment.fail(reason=reason)
        except (InvalidStateTransition, ValueError) as exc:
            raise ReplayError(
                f"invalid TaskAssignmentFailed event for assignment "
                f"{assignment_id!r}: {exc}"
            ) from exc

    def _apply_TaskAssignmentSuperseded(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        assignment_id = str(event.payload["assignment_id"])
        assignment = state.assignments.get(assignment_id)

        if assignment is None:
            raise ReplayError(
                f"cannot supersede unknown assignment: {assignment_id!r}"
            )

        try:
            assignment.supersede(
                reason=event.payload.get("reason")
            )
        except (InvalidStateTransition, ValueError) as exc:
            raise ReplayError(
                f"invalid TaskAssignmentSuperseded event for assignment "
                f"{assignment_id!r}: {exc}"
            ) from exc

    def _apply_TaskAssignmentCancelled(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        assignment_id = str(event.payload["assignment_id"])
        assignment = state.assignments.get(assignment_id)

        if assignment is None:
            raise ReplayError(
                f"cannot cancel unknown assignment: {assignment_id!r}"
            )

        try:
            assignment.cancel(
                reason=event.payload.get("reason")
            )
        except (InvalidStateTransition, ValueError) as exc:
            raise ReplayError(
                f"invalid TaskAssignmentCancelled event for assignment "
                f"{assignment_id!r}: {exc}"
            ) from exc

    # ------------------------------------------------------------------
    # Execution events
    # ------------------------------------------------------------------

    def _apply_ExecutionCreated(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._require_absent(state.executions, event)

        payload = event.payload

        execution = Execution(
            task_id=str(payload["task_id"]),
            capability=str(payload["capability"]),
            operation=str(payload["operation"]),
            arguments=dict(payload.get("arguments", {})),
            agent_id=payload.get("agent_id"),
            principal_id=payload.get("principal_id"),
            mission_id=payload.get("mission_id"),
            mode=OrchestrationMode(payload.get("mode", "standard")),
            id=str(payload.get("id", event.source or event.id)),
        )

        state.executions[execution.id] = execution

    def _apply_ExecutionStarted(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        execution_id = str(event.payload["id"])
        execution = state.executions.get(execution_id)

        if execution is None:
            raise ReplayError(
                f"cannot start unknown execution: {execution_id!r}"
            )

        try:
            execution.start()
        except ValueError as exc:
            raise ReplayError(
                f"invalid ExecutionStarted event for execution "
                f"{execution_id!r}"
            ) from exc

    def _apply_ExecutionSucceeded(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        execution_id = str(event.payload["id"])
        execution = state.executions.get(execution_id)

        if execution is None:
            raise ReplayError(
                f"cannot succeed unknown execution: {execution_id!r}"
            )

        result = event.payload.get("raw_result")

        try:
            execution.succeed(result)
        except InvalidStateTransition as exc:
            raise ReplayError(
                f"invalid ExecutionSucceeded event for execution "
                f"{execution.id!r}: {exc}"
            ) from exc
        except ValueError as exc:
            raise ReplayError(
                f"invalid ExecutionSucceeded event for execution "
                f"{execution_id!r}"
            ) from exc

    def _apply_ExecutionFailed(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        execution_id = str(event.payload["id"])
        execution = state.executions.get(execution_id)

        if execution is None:
            raise ReplayError(
                f"cannot fail unknown execution: {execution_id!r}"
            )

        error = str(event.payload["error"])

        try:
            execution.fail(error)
        except InvalidStateTransition as exc:
            raise ReplayError(
                f"invalid ExecutionFailed event for execution "
                f"{execution.id!r}: {exc}"
            ) from exc
        except ValueError as exc:
            raise ReplayError(
                f"invalid ExecutionFailed event for execution "
                f"{execution_id!r}"
            ) from exc

    def _apply_ExecutionTimedOut(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        execution_id = str(event.payload["id"])
        execution = state.executions.get(execution_id)

        if execution is None:
            raise ReplayError(
                f"cannot time out unknown execution: {execution_id!r}"
            )

        try:
            execution.time_out()
        except InvalidStateTransition as exc:
            raise ReplayError(
                f"invalid ExecutionTimedOut event for execution "
                f"{execution.id!r}: {exc}"
            ) from exc
        except ValueError as exc:
            raise ReplayError(
                f"invalid ExecutionTimedOut event for execution "
                f"{execution_id!r}"
            ) from exc

    def _apply_ExecutionCancelled(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        execution_id = str(event.payload["id"])
        execution = state.executions.get(execution_id)

        if execution is None:
            raise ReplayError(
                f"cannot cancel unknown execution: {execution_id!r}"
            )

        try:
            execution.cancel()
        except InvalidStateTransition as exc:
            raise ReplayError(
                f"invalid ExecutionCancelled event for execution "
                f"{execution.id!r}: {exc}"
            ) from exc
        except ValueError as exc:
            raise ReplayError(
                f"invalid ExecutionCancelled event for execution "
                f"{execution_id!r}"
            ) from exc

    # ------------------------------------------------------------------
    # Planning
    # ------------------------------------------------------------------

    def _apply_DecisionCreated(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._require_absent(state.decisions, event)
        payload = event.payload

        mission_id = str(payload["mission_id"])
        if mission_id not in state.missions:
            raise ReplayError(
                f"cannot create decision for unknown mission: {mission_id!r}"
            )

        decision = Decision(
            mission_id=mission_id,
            kind=str(payload["kind"]),
            objective=str(payload["objective"]),
            rationale=str(payload["rationale"]),
            alternatives=tuple(payload.get("alternatives", [])),
            selected_option=payload.get("selected_option"),
            confidence=(
                float(payload["confidence"])
                if payload.get("confidence") is not None
                else None
            ),
            evidence=tuple(payload.get("evidence", [])),
            metadata=dict(payload.get("metadata", {})),
            id=str(payload.get("id", event.aggregate_id or event.id)),
            created_at=event.at,
        )
        state.decisions[decision.id] = decision

    def _apply_WorkGraphCreated(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._require_absent(state.work_graphs, event)
        payload = event.payload

        mission_id = str(payload["mission_id"])
        if mission_id not in state.missions:
            raise ReplayError(
                f"cannot create work graph for unknown mission: {mission_id!r}"
            )

        graph = WorkGraph(
            mission_id=mission_id,
            plan_revision_id=str(payload["plan_revision_id"]),
            nodes=tuple(
                WorkGraphSerializer.deserialize_node(node)
                for node in payload.get("nodes", [])
            ),
            edges=tuple(
                WorkGraphSerializer.deserialize_edge(edge)
                for edge in payload.get("edges", [])
            ),
            metadata=dict(payload.get("metadata", {})),
            id=str(payload.get("id", event.aggregate_id or event.id)),
        )
        state.work_graphs[graph.id] = graph

    def _apply_PlanRevisionCreated(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._require_absent(state.plan_revisions, event)
        payload = event.payload

        mission_id = str(payload["mission_id"])
        decision_id = str(payload["decision_id"])
        graph_id = str(payload["graph_id"])
        plan_id = str(payload.get("id", event.aggregate_id or event.id))

        mission = state.missions.get(mission_id)
        if mission is None:
            raise ReplayError(
                f"cannot create plan for unknown mission: {mission_id!r}"
            )

        decision = state.decisions.get(decision_id)
        if decision is None:
            raise ReplayError(
                f"cannot create plan {plan_id!r}: "
                f"unknown decision {decision_id!r}"
            )

        if decision.mission_id != mission_id:
            raise ReplayError(
                f"decision {decision_id!r} belongs to mission "
                f"{decision.mission_id!r}, not {mission_id!r}"
            )

        revision_number = int(payload["revision"])
        parent_revision_id = payload.get("parent_revision_id")

        # Validate parent lineage before graph cross-references so the
        # earliest violated invariant produces the deterministic error.
        if revision_number > 1:
            if parent_revision_id is None:
                raise ReplayError(
                    f"plan revision {plan_id!r} requires a parent revision"
                )

            parent = state.plan_revisions.get(str(parent_revision_id))
            if parent is None:
                raise ReplayError(
                    f"unknown parent revision {parent_revision_id!r}"
                )

            if parent.mission_id != mission_id:
                raise ReplayError(
                    f"parent revision {parent_revision_id!r} belongs to mission "
                    f"{parent.mission_id!r}, not {mission_id!r}"
                )

            if parent.revision >= revision_number:
                raise ReplayError(
                    f"plan revision {plan_id!r} must have a lower revision "
                    f"parent than {revision_number}"
                )
        elif parent_revision_id is not None:
            raise ReplayError(
                f"plan revision {plan_id!r} cannot have a parent"
            )

        graph = state.work_graphs.get(graph_id)
        if graph is None:
            raise ReplayError(
                f"unknown work graph {graph_id!r}"
            )

        if graph.mission_id != mission_id:
            raise ReplayError(
                f"work graph {graph_id!r} belongs to mission "
                f"{graph.mission_id!r}, not {mission_id!r}"
            )

        if graph.plan_revision_id != plan_id:
            raise ReplayError(
                f"work graph {graph_id!r} references plan "
                f"{graph.plan_revision_id!r}, not {plan_id!r}"
            )

        revision = PlanRevision(
            mission_id=mission_id,
            revision=revision_number,
            decision_id=decision_id,
            graph_id=graph_id,
            parent_revision_id=(
                str(parent_revision_id)
                if parent_revision_id is not None
                else None
            ),
            status=PlanStatus.DRAFT,
            reason=payload.get("reason"),
            metadata=payload.get("metadata", {}),
            id=plan_id,
        )

        state.plan_revisions[revision.id] = revision

    def _apply_PlanRevisionProposed(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._replace_plan_status(
            state,
            event,
            PlanStatus.PROPOSED,
            allowed_from={PlanStatus.DRAFT},
        )

    def _apply_PlanRevisionActivated(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._replace_plan_status(
            state,
            event,
            PlanStatus.ACTIVE,
            allowed_from={PlanStatus.PROPOSED},
        )

    def _apply_PlanRevisionSuperseded(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._replace_plan_status(
            state,
            event,
            PlanStatus.SUPERSEDED,
            allowed_from={PlanStatus.ACTIVE},
        )

    def _apply_PlanRevisionCancelled(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._replace_plan_status(
            state,
            event,
            PlanStatus.CANCELLED,
            allowed_from={
                PlanStatus.DRAFT,
                PlanStatus.PROPOSED,
                PlanStatus.ACTIVE,
            },
        )

    def _apply_PlanRevisionCompleted(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._replace_plan_status(
            state,
            event,
            PlanStatus.COMPLETED,
            allowed_from={PlanStatus.ACTIVE},
        )

    @staticmethod
    def _replace_plan_status(
        state: ReplayState,
        event: Event,
        new_status: PlanStatus,
        allowed_from: set[PlanStatus],
    ) -> None:
        plan_id = str(event.payload["id"])
        current = state.plan_revisions.get(plan_id)

        if current is None:
            raise ReplayError(
                f"cannot transition unknown plan revision: {plan_id!r}"
            )

        if current.status not in allowed_from:
            raise ReplayError(
                f"invalid {event.type} event for plan revision "
                f"{plan_id!r}: cannot transition from "
                f"{current.status.value!r} to {new_status.value!r}"
            )

        reason = event.payload.get("reason", current.reason)

        replacement = PlanRevision(
            mission_id=current.mission_id,
            revision=current.revision,
            decision_id=current.decision_id,
            graph_id=current.graph_id,
            parent_revision_id=current.parent_revision_id,
            status=new_status,
            reason=reason,
            metadata=dict(current.metadata),
            id=current.id,
            created_at=current.created_at,
        )

        state.plan_revisions[plan_id] = replacement

    # ------------------------------------------------------------------
    # Self-improvement
    # ------------------------------------------------------------------

    def _apply_ImprovementCheckpointCreated(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        payload = event.payload
        run_id = str(payload.get("run_id") or "")
        if not run_id:
            raise ReplayError("ImprovementCheckpointCreated event missing run_id")
        current = state.improvement_runs.get(run_id)
        if current is None:
            raise ReplayError(
                f"cannot checkpoint unknown improvement run: {run_id!r}"
            )
        candidate_id = payload.get("candidate_id")
        if candidate_id is not None and str(candidate_id) != current.candidate_id:
            raise ReplayError(
                f"ImprovementCheckpointCreated candidate mismatch for run {run_id!r}"
            )
        phase = payload.get("phase")
        if not isinstance(phase, str) or not phase.strip():
            raise ReplayError("ImprovementCheckpointCreated event missing phase")
        metadata = dict(current.metadata)
        metadata["recovery_checkpoint"] = {
            "phase": phase,
            "context": dict(payload.get("context", {})),
        }
        state.improvement_runs[run_id] = ImprovementRun(
            id=current.id,
            mission_id=current.mission_id,
            candidate_id=current.candidate_id,
            status=current.status,
            evaluation=current.evaluation,
            promoted_plan_revision_id=current.promoted_plan_revision_id,
            metadata=metadata,
        )

    def _apply_ImprovementCandidateCreated(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        payload = event.payload
        run_id = str(payload["run_id"])
        if run_id in state.improvement_runs:
            raise ReplayError(
                f"duplicate improvement run during replay: {run_id!r}"
            )

        hypothesis_payload = payload.get("hypothesis")
        if not isinstance(hypothesis_payload, dict):
            raise ReplayError(
                "ImprovementCandidateCreated event missing hypothesis"
            )

        hypothesis = ImprovementHypothesis(
            objective=str(hypothesis_payload["objective"]),
            hypothesis=str(hypothesis_payload["hypothesis"]),
            rationale=str(hypothesis_payload["rationale"]),
            success_criteria=tuple(
                str(item)
                for item in hypothesis_payload.get("success_criteria", [])
            ),
            constraints=dict(hypothesis_payload.get("constraints", {})),
        )

        metadata = dict(payload.get("metadata", {}))
        metadata["hypothesis"] = {
            "objective": hypothesis.objective,
            "hypothesis": hypothesis.hypothesis,
            "rationale": hypothesis.rationale,
            "success_criteria": list(hypothesis.success_criteria),
            "constraints": dict(hypothesis.constraints),
        }

        state.improvement_runs[run_id] = ImprovementRun(
            id=run_id,
            mission_id=str(payload["mission_id"]),
            candidate_id=str(payload["candidate_id"]),
            status=ImprovementStatus.CANDIDATE,
            metadata=metadata,
        )

    def _apply_ImprovementEvaluated(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        payload = event.payload
        run_id = str(payload["run_id"])
        current = state.improvement_runs.get(run_id)
        if current is None:
            raise ReplayError(
                f"cannot evaluate unknown improvement run: {run_id!r}"
            )
        if current.candidate_id != str(payload["candidate_id"]):
            raise ReplayError(
                f"ImprovementEvaluated candidate mismatch for run {run_id!r}"
            )
        if current.status not in {
            ImprovementStatus.CANDIDATE,
            ImprovementStatus.TESTING,
            ImprovementStatus.VERIFIED,
        }:
            raise ReplayError(
                f"invalid ImprovementEvaluated transition for run {run_id!r} "
                f"from {current.status.value!r}"
            )

        passed = bool(payload["passed"])
        evaluation = ImprovementEvaluation(
            candidate_id=current.candidate_id,
            passed=passed,
            score=float(payload["score"]),
            evidence=tuple(str(item) for item in payload.get("evidence", [])),
            metrics={
                str(key): float(value)
                for key, value in payload.get("metrics", {}).items()
            },
            reason=payload.get("reason"),
        )
        metadata = dict(current.metadata)
        verification_id = payload.get("verification_id")
        if verification_id is not None:
            metadata["verification_id"] = str(verification_id)

        state.improvement_runs[run_id] = ImprovementRun(
            id=current.id,
            mission_id=current.mission_id,
            candidate_id=current.candidate_id,
            status=(
                ImprovementStatus.VERIFIED
                if passed
                else ImprovementStatus.REJECTED
            ),
            evaluation=evaluation,
            promoted_plan_revision_id=current.promoted_plan_revision_id,
            metadata=metadata,
        )

    def _apply_ImprovementPromoted(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        payload = event.payload
        run_id = str(payload["run_id"])
        current = state.improvement_runs.get(run_id)
        if current is None:
            raise ReplayError(
                f"cannot promote unknown improvement run: {run_id!r}"
            )
        if current.candidate_id != str(payload["candidate_id"]):
            raise ReplayError(
                f"ImprovementPromoted candidate mismatch for run {run_id!r}"
            )
        if current.status is not ImprovementStatus.VERIFIED:
            raise ReplayError(
                f"invalid ImprovementPromoted transition for run {run_id!r} "
                f"from {current.status.value!r}"
            )

        plan_revision_id = str(payload["plan_revision_id"])
        metadata = dict(current.metadata)
        metadata["production_plan_revision_id"] = plan_revision_id
        if payload.get("source_candidate_plan_revision_id") is not None:
            metadata["source_candidate_plan_revision_id"] = str(
                payload["source_candidate_plan_revision_id"]
            )

        state.improvement_runs[run_id] = ImprovementRun(
            id=current.id,
            mission_id=current.mission_id,
            candidate_id=current.candidate_id,
            status=ImprovementStatus.PROMOTED,
            evaluation=current.evaluation,
            promoted_plan_revision_id=plan_revision_id,
            metadata=metadata,
        )

    def _apply_ImprovementRolledBack(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        payload = event.payload
        run_id = str(payload["run_id"])
        current = state.improvement_runs.get(run_id)
        if current is None:
            raise ReplayError(
                f"cannot roll back unknown improvement run: {run_id!r}"
            )
        if current.candidate_id != str(payload["candidate_id"]):
            raise ReplayError(
                f"ImprovementRolledBack candidate mismatch for run {run_id!r}"
            )
        if current.status is not ImprovementStatus.PROMOTED:
            raise ReplayError(
                f"invalid ImprovementRolledBack transition for run {run_id!r} "
                f"from {current.status.value!r}"
            )
        if (
            current.promoted_plan_revision_id is not None
            and str(payload["from_plan_revision_id"])
            != current.promoted_plan_revision_id
        ):
            raise ReplayError(
                f"ImprovementRolledBack source plan mismatch for run {run_id!r}"
            )

        metadata = dict(current.metadata)
        metadata["rollback_reason"] = payload.get("reason")
        metadata["rollback_plan_revision_id"] = str(
            payload["to_plan_revision_id"]
        )
        if payload.get("rollback_source_plan_revision_id") is not None:
            metadata["rollback_source_plan_revision_id"] = str(
                payload["rollback_source_plan_revision_id"]
            )

        state.improvement_runs[run_id] = ImprovementRun(
            id=current.id,
            mission_id=current.mission_id,
            candidate_id=current.candidate_id,
            status=ImprovementStatus.ROLLED_BACK,
            evaluation=current.evaluation,
            promoted_plan_revision_id=current.promoted_plan_revision_id,
            metadata=metadata,
        )

    # ------------------------------------------------------------------
    # Verification
    # ------------------------------------------------------------------

    def _apply_VerificationRecorded(
        self,
        state: ReplayState,
        event: Event,
    ) -> None:
        self._require_absent(state.verifications, event)

        payload = event.payload

        verification = Verification(
            task_id=str(payload["task_id"]),
            method=str(payload["method"]),
            passed=bool(payload["passed"]),
            evidence=list(payload.get("evidence", [])),
            execution_id=payload.get("execution_id"),
            id=str(payload.get("id", event.source or event.id)),
        )

        state.verifications[verification.id] = verification

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _transition_assignment(
        state: ReplayState,
        event: Event,
        expected_status: AssignmentStatus,
        operation: str,
    ) -> None:
        assignment_id = str(event.payload["assignment_id"])
        assignment = state.assignments.get(assignment_id)

        if assignment is None:
            raise ReplayError(
                f"cannot transition unknown assignment: {assignment_id!r}"
            )

        try:
            getattr(assignment, operation)(
                reason=event.payload.get("reason")
            )
        except (InvalidStateTransition, ValueError) as exc:
            raise ReplayError(
                f"invalid {event.type} event for assignment "
                f"{assignment_id!r}: {exc}"
            ) from exc

        if assignment.status is not expected_status:
            raise ReplayError(
                f"{event.type} produced unexpected assignment status "
                f"{assignment.status.value!r}"
            )

    @staticmethod
    def _require_absent(
        collection: Dict[str, object],
        event: Event,
    ) -> None:
        entity_id = str(
            event.payload.get(
                "id",
                event.source or event.id,
            )
        )

        if entity_id in collection:
            raise ReplayError(
                f"duplicate entity creation during replay: {entity_id!r}"
            )

    @staticmethod
    def _transition_mission(
        state: ReplayState,
        event: Event,
        new_status: MissionStatus,
        action: str,
    ) -> None:
        mission_id = str(event.payload["id"])
        mission = state.missions.get(mission_id)

        if mission is None:
            raise ReplayError(
                f"cannot {action} unknown mission: {mission_id!r}"
            )

        try:
            mission.transition(new_status)
        except ValueError as exc:
            raise ReplayError(
                f"invalid {event.type} event for mission {mission_id!r}"
            ) from exc

    @staticmethod
    def _transition_task(
        state: ReplayState,
        event: Event,
        new_status: TaskStatus,
        action: str,
    ) -> None:
        task_id = str(event.payload["id"])
        task = state.tasks.get(task_id)

        if task is None:
            raise ReplayError(
                f"cannot {action} unknown task: {task_id!r}"
            )

        try:
            task.transition(new_status)
        except ValueError as exc:
            raise ReplayError(
                f"invalid {event.type} event for task {task_id!r}"
            ) from exc
