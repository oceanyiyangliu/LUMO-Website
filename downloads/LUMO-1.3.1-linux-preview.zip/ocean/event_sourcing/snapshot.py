"""Crash-safe aggregate snapshots and replay comparison utilities."""
from __future__ import annotations
import hashlib,json,sqlite3
from threading import RLock
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

@dataclass(frozen=True)
class Snapshot:
    aggregate_type:str
    aggregate_id:str
    sequence:int
    state:dict[str,Any]
    state_hash:str
    @classmethod
    def create(cls, aggregate_type, aggregate_id, sequence, state):
        raw=json.dumps(state,sort_keys=True,separators=(",",":"),default=str).encode(); return cls(aggregate_type,aggregate_id,sequence,dict(state),hashlib.sha256(raw).hexdigest())
    def verify(self):
        raw=json.dumps(self.state,sort_keys=True,separators=(",",":"),default=str).encode(); return hashlib.sha256(raw).hexdigest()==self.state_hash

class SnapshotStore:
    def __init__(self,path:str|Path):
        self._db=sqlite3.connect(str(path), check_same_thread=False); self._lock=RLock(); self._db.execute("PRAGMA busy_timeout=30000"); self._db.execute("PRAGMA journal_mode=WAL"); self._db.execute("CREATE TABLE IF NOT EXISTS snapshots (aggregate_type TEXT,aggregate_id TEXT,sequence INTEGER,state TEXT NOT NULL,state_hash TEXT NOT NULL,PRIMARY KEY(aggregate_type,aggregate_id,sequence))"); self._db.commit()
    def save(self,s:Snapshot):
        if not s.verify(): raise ValueError("snapshot integrity verification failed")
        data=json.dumps(s.state,sort_keys=True,default=str)
        with self._lock:
            existing=self._db.execute("SELECT state,state_hash FROM snapshots WHERE aggregate_type=? AND aggregate_id=? AND sequence=?",(s.aggregate_type,s.aggregate_id,s.sequence)).fetchone()
            if existing is not None:
                if existing[1] != s.state_hash or existing[0] != data:
                    raise ValueError("snapshot identity already exists with different content")
                return s
            self._db.execute("INSERT INTO snapshots VALUES(?,?,?,?,?)",(s.aggregate_type,s.aggregate_id,s.sequence,data,s.state_hash)); self._db.commit(); return s
    def latest(self,t,a):
        with self._lock:
            row=self._db.execute("SELECT aggregate_type,aggregate_id,sequence,state,state_hash FROM snapshots WHERE aggregate_type=? AND aggregate_id=? ORDER BY sequence DESC LIMIT 1",(t,a)).fetchone()
        if row is None: return None
        snapshot=Snapshot(row[0],row[1],row[2],json.loads(row[3]),row[4])
        if not snapshot.verify(): raise RuntimeError("snapshot integrity verification failed")
        return snapshot
    def delete_before(self,t,a,sequence):
        with self._lock:
            self._db.execute("DELETE FROM snapshots WHERE aggregate_type=? AND aggregate_id=? AND sequence<?",(t,a,sequence)); self._db.commit()

def replay_dry_run(events, replay:Callable[[list],Any], expected:Any=None)->dict[str,Any]:
    state=replay(list(events)); equal=expected is None or state==expected; return {"events":len(events),"equal":equal,"diverged":not equal,"state":state}
