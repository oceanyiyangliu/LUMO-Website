"""Cross-platform LUMO OS boundary.

The LUMO Core stays platform-neutral. Only native capabilities live behind
this adapter so releases can share one Core/UI/update protocol across OSes.
"""
from __future__ import annotations

from dataclasses import dataclass
import os
import platform as _platform
from pathlib import Path
from typing import Protocol

from .versioning import PLATFORM_IDS, platform_version


@dataclass(frozen=True)
class PlatformInfo:
    os: str
    architecture: str
    version: str
    family: str
    platform_id: int = 0
    lumo_version: str = ""


class PlatformAdapter(Protocol):
    """Native boundary consumed by LUMO Core, never by mission logic."""

    info: PlatformInfo

    def app_data_dir(self) -> Path: ...
    def cache_dir(self) -> Path: ...
    def config_dir(self) -> Path: ...
    def capabilities(self) -> dict[str, bool]: ...


class _BaseAdapter:
    def __init__(self) -> None:
        system = _platform.system().lower()
        self.info = PlatformInfo(
            os=system or "unknown",
            architecture=_platform.machine() or "unknown",
            version=_platform.version(),
            family=system or "unknown",
        )

    def capabilities(self) -> dict[str, bool]:
        return {
            "filesystem": True,
            "process_control": True,
            "notifications": False,
            "screen_capture": False,
            "microphone": False,
            "computer_control": False,
            "local_models": True,
        }


class MacOSAdapter(_BaseAdapter):
    def __init__(self) -> None:
        super().__init__()
        self.info = PlatformInfo("macos", self.info.architecture, self.info.version, "unix", PLATFORM_IDS["macos"], platform_version(1, "macos"))

    def app_data_dir(self) -> Path:
        return Path.home() / "Library" / "Application Support" / "LUMO"

    def cache_dir(self) -> Path:
        return Path.home() / "Library" / "Caches" / "LUMO"

    def config_dir(self) -> Path:
        return self.app_data_dir() / "Config"

    def capabilities(self) -> dict[str, bool]:
        return {**super().capabilities(), "notifications": True, "screen_capture": True, "microphone": True, "computer_control": True}


class WindowsAdapter(_BaseAdapter):
    def __init__(self) -> None:
        super().__init__()
        self.info = PlatformInfo("windows", self.info.architecture, self.info.version, "windows", PLATFORM_IDS["windows"], platform_version(1, "windows"))

    def app_data_dir(self) -> Path:
        return Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local")) / "LUMO"

    def cache_dir(self) -> Path:
        return self.app_data_dir() / "Cache"

    def config_dir(self) -> Path:
        return self.app_data_dir() / "Config"

    def capabilities(self) -> dict[str, bool]:
        return {**super().capabilities(), "notifications": True}


class LinuxAdapter(_BaseAdapter):
    def __init__(self) -> None:
        super().__init__()
        self.info = PlatformInfo("linux", self.info.architecture, self.info.version, "unix", PLATFORM_IDS["linux"], platform_version(1, "linux"))

    def app_data_dir(self) -> Path:
        return Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / "LUMO"

    def cache_dir(self) -> Path:
        return Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache")) / "LUMO"

    def config_dir(self) -> Path:
        return Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "LUMO"

    def capabilities(self) -> dict[str, bool]:
        return {**super().capabilities(), "notifications": True}


def platform_adapter() -> PlatformAdapter:
    system = _platform.system().lower()
    if system == "darwin":
        return MacOSAdapter()
    if system == "windows":
        return WindowsAdapter()
    if system == "linux":
        return LinuxAdapter()
    raise RuntimeError(f"unsupported operating system: {system or 'unknown'}")


def runtime_state_dir() -> Path:
    """Return production state storage without coupling it to the source tree."""
    override = os.getenv("LUMO_STATE_DIR", "").strip()
    path = Path(override).expanduser() if override else platform_adapter().app_data_dir()
    path.mkdir(parents=True, exist_ok=True)
    return path
