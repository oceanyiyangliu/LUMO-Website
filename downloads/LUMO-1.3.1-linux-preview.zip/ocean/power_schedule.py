"""Explicit, bounded macOS wake scheduling primitives."""
from __future__ import annotations
import platform
import subprocess
from datetime import datetime, timezone

class WakeScheduler:
    def __init__(self): self._last_requested: datetime | None = None

    def schedule(self, when: datetime) -> bool:
        if platform.system() != "Darwin" or not __import__('os').path.exists('/usr/bin/pmset'):
            return False
        local_tz = datetime.now().astimezone().tzinfo
        when = when.astimezone(local_tz)
        if when <= datetime.now(local_tz): raise ValueError("wake time must be in the future")
        # pmset uses MM/dd/yy HH:mm:ss for scheduled wake events.
        stamp=when.strftime('%m/%d/%y %H:%M:%S')
        subprocess.run(['/usr/bin/pmset','schedule','wakeorpoweron',stamp],check=True,capture_output=True,text=True,timeout=5)
        self._last_requested=when
        return self.verify(expected=when)

    def verify(self, *, expected: datetime | None = None) -> bool:
        if platform.system() != "Darwin": return False
        result=subprocess.run(['/usr/bin/pmset','-g','sched'],check=False,capture_output=True,text=True,timeout=5)
        if result.returncode != 0: return False
        if expected is None: return True
        stamp=expected.astimezone(datetime.now().astimezone().tzinfo).strftime('%m/%d/%y %H:%M:%S')
        return stamp in result.stdout
