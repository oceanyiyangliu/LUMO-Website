"""Advanced control-plane primitives for state, skills, reversibility and resilience."""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from hashlib import sha256
from typing import Any, Callable, Mapping, Sequence
import json

def _fp(v: Any)->str: return sha256(json.dumps(v,sort_keys=True,default=str,separators=(",",":")).encode()).hexdigest()
@dataclass(frozen=True)
class StateDiff:
    added: Mapping[str,Any]=field(default_factory=dict); removed: Mapping[str,Any]=field(default_factory=dict); changed: Mapping[str,tuple[Any,Any]]=field(default_factory=dict)
def state_diff(before:Mapping[str,Any],after:Mapping[str,Any])->StateDiff:
    b=set(before); a=set(after); return StateDiff({k:after[k] for k in a-b},{k:before[k] for k in b-a},{k:(before[k],after[k]) for k in a&b if before[k]!=after[k]})
@dataclass(frozen=True)
class SemanticState:
    entity_id:str; attributes:Mapping[str,Any]; relations:Mapping[str,tuple[str,...]]=field(default_factory=dict); observed_at:datetime=field(default_factory=lambda:datetime.now(timezone.utc))
    @property
    def fingerprint(self)->str:return _fp({"id":self.entity_id,"attributes":dict(self.attributes),"relations":{k:list(v) for k,v in self.relations.items()}})
class SemanticStateGraph:
    def __init__(self):self._states={}
    def observe(self,state):self._states[state.entity_id]=state
    def get(self,entity_id):return self._states.get(entity_id)
    def snapshot(self):return {k:{"attributes":dict(v.attributes),"relations":{r:list(x) for r,x in v.relations.items()},"fingerprint":v.fingerprint} for k,v in self._states.items()}
@dataclass(frozen=True)
class Skill:
    skill_id:str; name:str; version:str; steps:tuple[Mapping[str,Any],...]; risk:str="low"; metadata:Mapping[str,Any]=field(default_factory=dict)
class SkillRegistry:
    def __init__(self):self._skills={}
    def register(self,skill):
        key=(skill.skill_id,skill.version)
        if key in self._skills:raise ValueError("skill version already registered")
        self._skills[key]=skill;return skill
    def get(self,skill_id,version=None):
        matches=[s for (sid,_),s in self._skills.items() if sid==skill_id]
        if not matches:raise KeyError(skill_id)
        return self._skills[(skill_id,version)] if version else sorted(matches,key=lambda s:s.version)[-1]
    def select(self,*,goal="",risk="low",context=None):
        context_text=json.dumps(dict(context or {}),default=str).lower()
        goal_text=str(goal).lower()
        candidates=[]
        for skill in self._skills.values():
            metadata=json.dumps(dict(skill.metadata),default=str).lower()
            risk_ok=skill.risk == risk or (risk=="low" and skill.risk=="low")
            keyword_hit=any(token in (goal_text+" "+context_text+" "+metadata) for token in ("navigate","click","ui","browser","computer"))
            if risk_ok and keyword_hit:candidates.append(skill)
        if not candidates:
            return None
        return sorted(candidates,key=lambda s:(s.risk,s.skill_id,s.version))[-1]
    def evaluate(self,skill_id,version,evaluator):
        score=float(evaluator(self.get(skill_id,version)))
        if not 0<=score<=1:raise ValueError("skill evaluation must be 0..1")
        return score
@dataclass(frozen=True)
class UndoReceipt:
    action_id:str; inverse:Mapping[str,Any]; reversible:bool=True; created_at:datetime=field(default_factory=lambda:datetime.now(timezone.utc))
class UndoManager:
    def __init__(self): self._receipts={}
    def register(self,action_id,inverse,*,reversible=True,expected_state=None,consequential=False):
        r=UndoReceipt(action_id,{**dict(inverse),"expected_state":expected_state,"consequential":bool(consequential)},reversible); self._receipts[action_id]=r; return r
    def preview(self,action_id):
        r=self._receipts[action_id]; return {"action_id":r.action_id,"reversible":r.reversible,"inverse":dict(r.inverse)}
    def inverse(self,action_id,*,current_state=None,authorized=False):
        r=self._receipts[action_id]
        if not r.reversible: raise ValueError("action is not reversible")
        expected=r.inverse.get("expected_state")
        if expected is not None and current_state != expected: raise ValueError("state changed since reversible action")
        if r.inverse.get("consequential") and not authorized: raise PermissionError("consequential undo requires authorization")
        return {k:v for k,v in r.inverse.items() if k not in {"expected_state","consequential"}}
@dataclass(frozen=True)
class CounterfactualResult:
    baseline:Any; alternative:Any; changed:bool; effects:tuple[Any,...]=()
def counterfactual(baseline,alternative):return CounterfactualResult(baseline,alternative,baseline!=alternative)
def metamorphic_check(run,value,transform,relation):return bool(relation(run(value),run(transform(value))))
def property_check(run,values,predicate):
    failures=[]
    for value in values:
        result=run(value)
        if not predicate(value,result):failures.append({"input":value,"result":result})
    return {"passed":not failures,"checked":len(values),"failures":failures}
class ChaosHarness:
    def __init__(self,injector=None):self.injector=injector
    def run(self,scenarios):
        results=[]
        for scenario in scenarios:
            try:
                if self.injector:self.injector(scenario)
                results.append({"scenario":scenario,"status":"injected"})
            except Exception as exc:results.append({"scenario":scenario,"status":"failed","error":type(exc).__name__})
        return {"scenarios":results,"count":len(results)}
@dataclass(frozen=True)
class ReliabilitySLO:
    name:str; target:float; observed:float; unit:str="ratio"
    @property
    def met(self):return self.observed>=self.target
@dataclass(frozen=True)
class ExecutionTreeNode:
    node_id:str; parent_id:str|None; status:str; metadata:Mapping[str,Any]=field(default_factory=dict)
class ExecutionTree:
    def __init__(self):self._nodes={}
    def add(self,node):
        if node.node_id in self._nodes:raise ValueError("duplicate execution node")
        if node.parent_id is not None and node.parent_id not in self._nodes:raise KeyError(node.parent_id)
        self._nodes[node.node_id]=node
    def children(self,node_id):return tuple(n for n in self._nodes.values() if n.parent_id==node_id)
    def snapshot(self):return tuple(self._nodes.values())
class NavigationPlanner:
    def choose(self,candidates,*,goal=""):
        if not candidates:raise ValueError("no navigation candidates")
        return min(candidates,key=lambda c:(float(c.get("risk",0)),float(c.get("latency",0)),str(c.get("id",""))))
class ContextBudget:
    def __init__(self,max_items):self.max_items=max(0,int(max_items))
    def minimize(self,items):return tuple(items[:self.max_items])
class ObservationCompressor:
    def compress(self,observations):
        seen=set();out=[]
        for item in observations:
            k=_fp(item)
            if k not in seen:seen.add(k);out.append(dict(item))
        return tuple(out)
class RecoveryStrategyRegistry:
    def __init__(self):self._strategies={}
    def register(self,name,strategy):
        if not name or name in self._strategies:raise ValueError("invalid or duplicate recovery strategy")
        self._strategies[name]=strategy
    def execute(self,name,**kwargs):return self._strategies[name](**kwargs)

@dataclass(frozen=True)
class RecoveryLearning:
    failure_category: str
    strategy: str
    attempts: int
    successes: int

class RecoveryLearningStore:
    def __init__(self): self._rows={}
    def record(self,failure_category,strategy,success):
        k=(str(failure_category),str(strategy)); a,s=self._rows.get(k,(0,0)); self._rows[k]=(a+1,s+int(bool(success)))
    def effectiveness(self,failure_category,strategy):
        a,s=self._rows.get((str(failure_category),str(strategy)),(0,0)); return 0.0 if not a else s/a
    def export(self): return tuple(RecoveryLearning(k[0],k[1],v[0],v[1]) for k,v in sorted(self._rows.items()))

def verify_retry_allowed(*, verification_passed: bool, evidence_count: int, attempt: int, max_attempts: int) -> bool:
    """Retry only when the previous attempt did not establish success and budget remains."""
    if attempt < 0 or max_attempts < 0 or evidence_count < 0: raise ValueError("invalid retry counters")
    return (not verification_passed) and evidence_count >= 0 and attempt < max_attempts

@dataclass(frozen=True)
class MissionProgress:
    completed: int
    total: int
    blocked: int = 0
    failed: int = 0
    @property
    def fraction(self)->float: return 0.0 if self.total <= 0 else min(1.0,max(0.0,self.completed/self.total))
    @property
    def terminal(self)->bool: return self.completed+self.blocked+self.failed >= self.total

def progress_semantics(completed:int,total:int,blocked:int=0,failed:int=0)->MissionProgress:
    if min(completed,total,blocked,failed)<0 or completed+blocked+failed>total: raise ValueError("invalid mission progress")
    return MissionProgress(completed,total,blocked,failed)
