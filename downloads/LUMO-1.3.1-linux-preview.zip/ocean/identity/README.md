# Identity Plane

The Identity Plane provides durable, stable actor identities.

Responsibilities:

- represent human, agent, and system principals;
- provide stable principal identifiers;
- own principal lifecycle;
- emit durable principal lifecycle events;
- provide rebuildable principal lookup;
- integrate with the canonical event replay system.

The event stream is the durable source of truth. `PrincipalRegistry` is an
operational projection and can be rebuilt from `PrincipalCreated` and
`PrincipalRetired` events.

Authentication, credentials, trust, delegation, and authorization remain
separate security boundaries.
