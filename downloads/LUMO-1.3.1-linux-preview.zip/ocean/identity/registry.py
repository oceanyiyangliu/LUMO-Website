"""Principal registry projection."""

from __future__ import annotations

from typing import Dict, Iterable, Optional

from ocean.domain.event import Event

from .types import Principal


class PrincipalRegistry:
    """Rebuildable in-memory projection of active principals.

    The event stream is the durable source of truth. The registry is only
    an operational lookup projection.
    """

    def __init__(self) -> None:
        self._principals: Dict[str, Principal] = {}

    def register(self, principal: Principal) -> Principal:
        existing = self._principals.get(principal.id)
        if existing is not None and existing != principal:
            raise ValueError(
                f"principal already registered: {principal.id!r}"
            )
        self._principals[principal.id] = principal
        return principal

    def retire(self, principal_id: str) -> Principal:
        principal = self.require(principal_id)
        del self._principals[principal_id]
        return principal

    def get(self, principal_id: str) -> Optional[Principal]:
        return self._principals.get(principal_id)

    def require(self, principal_id: str) -> Principal:
        principal = self.get(principal_id)
        if principal is None:
            raise KeyError(f"unknown principal: {principal_id!r}")
        return principal

    def list(self) -> Iterable[Principal]:
        return tuple(self._principals.values())

    def rebuild(self, events: Iterable[Event]) -> None:
        """Reconstruct the active projection from durable identity events."""
        self._principals.clear()

        for event in events:
            if event.type == "PrincipalCreated":
                payload = event.payload
                principal_id = payload.get(
                    "principal_id",
                    payload.get("id"),
                )
                if principal_id is None:
                    raise ValueError(
                        "PrincipalCreated event missing principal_id"
                    )

                self.register(
                    Principal(
                        type=payload["type"],
                        name=str(payload["name"]),
                        metadata=dict(payload.get("metadata", {})),
                        id=str(principal_id),
                    )
                )

            elif event.type == "PrincipalRetired":
                principal_id = str(event.payload["principal_id"])
                if principal_id in self._principals:
                    self.retire(principal_id)
