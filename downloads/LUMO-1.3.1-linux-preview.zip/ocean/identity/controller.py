"""Authoritative principal lifecycle boundary."""

from __future__ import annotations

from typing import Any, Mapping, Optional

from ocean.core.ids import new_id
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus

from .registry import PrincipalRegistry
from .types import Principal, PrincipalType


class IdentityController:
    """Owns durable principal creation and retirement."""

    def __init__(
        self,
        *,
        event_bus: Optional[EventBus] = None,
        registry: Optional[PrincipalRegistry] = None,
    ) -> None:
        self._event_bus = event_bus
        self._registry = registry or PrincipalRegistry()

    @property
    def registry(self) -> PrincipalRegistry:
        return self._registry

    def create(
        self,
        principal_type: PrincipalType,
        name: str,
        *,
        metadata: Optional[Mapping[str, Any]] = None,
        principal_id: Optional[str] = None,
    ) -> Principal:
        principal = Principal(
            type=principal_type,
            name=name,
            metadata=dict(metadata or {}),
            id=principal_id or new_id("principal"),
        )

        self._registry.register(principal)

        self._publish(
            Event(
                type="PrincipalCreated",
                payload={
                    "principal_id": principal.id,
                    "type": principal.type.value,
                    "name": principal.name,
                    "metadata": dict(principal.metadata),
                },
                aggregate_type="principal",
                aggregate_id=principal.id,
            )
        )

        return principal

    def retire(self, principal_id: str) -> Principal:
        principal = self._registry.require(principal_id)
        self._registry.retire(principal_id)

        self._publish(
            Event(
                type="PrincipalRetired",
                payload={
                    "principal_id": principal.id,
                },
                aggregate_type="principal",
                aggregate_id=principal.id,
            )
        )

        return principal

    def rebuild(self, events) -> None:
        self._registry.rebuild(events)

    def _publish(self, event: Event) -> None:
        if self._event_bus is not None:
            self._event_bus.publish(event)
