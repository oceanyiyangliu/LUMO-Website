"""Durable principal identity types."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict

from ocean.core.ids import new_id


class PrincipalType(str, Enum):
    HUMAN = "human"
    AGENT = "agent"
    SYSTEM = "system"


class PrincipalStatus(str, Enum):
    ACTIVE = "active"
    RETIRED = "retired"


@dataclass(frozen=True)
class Principal:
    """Stable identity for an actor in Ocean."""

    type: PrincipalType
    name: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: new_id("principal"))

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise ValueError("principal name must not be empty")
