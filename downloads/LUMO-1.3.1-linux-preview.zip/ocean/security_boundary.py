"""Security/data-flow boundary for autonomous agents."""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import re

class Trust(str, Enum):
    SYSTEM="system"; USER="user"; MISSION="mission"; TOOL="tool"; EXTERNAL="external"; MODEL="model"

@dataclass(frozen=True)
class ContextItem:
    value: str
    trust: Trust
    classification: str="internal"
    source: str=""

@dataclass(frozen=True)
class SecurityDecision:
    allowed: bool
    reasons: tuple[str,...]
    sanitized: str

_SECRET=re.compile(r"(?i)(api[_-]?key|access[_-]?token|password|secret|authorization)\s*[:=]\s*[^\s,;]+")
_INJECTION=re.compile(r"(?is)(ignore\s+(all|any|the|previous)\s+instructions|system\s+message|developer\s+message|reveal\s+(the\s+)?prompt|disable\s+(safety|security|verification)|bypass\s+(approval|permission|policy))")

def redact(text: object)->str:
    return _SECRET.sub(lambda m:m.group(1)+"=<redacted>",str(text))[:100_000]

def external(text: object, source: str="")->ContextItem:
    return ContextItem(redact(text),Trust.EXTERNAL,"untrusted",source)

def inspect(item: ContextItem)->SecurityDecision:
    reasons=[]
    if item.classification=="secret": reasons.append("SECRET_CONTEXT")
    if item.trust is Trust.EXTERNAL and _INJECTION.search(item.value): reasons.append("PROMPT_INJECTION_CONTENT")
    return SecurityDecision(not reasons,tuple(reasons),redact(item.value))

def serialize(*items: ContextItem)->str:
    parts=[]
    for item in items:
        checked=inspect(item)
        value="[external instruction-like content withheld]" if "PROMPT_INJECTION_CONTENT" in checked.reasons else checked.sanitized
        parts.append(f"<{item.trust.value.upper()} source={item.source!r}>\\n{value}\\n</{item.trust.value.upper()}>")
    return "\\n".join(parts)

def assert_no_secret(text: object)->None:
    if _SECRET.search(str(text)): raise ValueError("secret-like material crossed protected boundary")

class SecurityBoundary:
    def prompt(self, system: str, *items: ContextItem)->str:
        assert_no_secret(system)
        return system+"\\n"+serialize(*items)
    def inspect_external(self,text: object,source: str="")->SecurityDecision:
        return inspect(external(text,source))
    def model_action_allowed(self,operation: str)->bool:
        return False

BOUNDARY=SecurityBoundary()
