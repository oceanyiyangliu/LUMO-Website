"""Local HTTP control plane for LUMO.

The API is deliberately small and local-first: durable event history remains
canonical, while this layer exposes read models and mission submission.
"""
from __future__ import annotations

import json
import math
import hashlib
import hmac
import ipaddress
import re
import os
import secrets
import threading
import subprocess
import platform
from dataclasses import asdict
from datetime import datetime, timezone
import socket
import time
import uuid
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable
from urllib.parse import parse_qs, urlparse

from ocean.core.ids import new_id
from ocean.domain.event import Event
from ocean.observability.status import LiveStatusReader
from ocean.observability.metrics import MetricsReader
from ocean.observability.trace import TraceReader
from ocean.service import OceanService
from ocean.shadow import ShadowAgent
from ocean.domain.world import WorldRequirements
from ocean.worlds import BrowserWorldProvider, DesktopWorldProvider, WorldManager
from ocean.fpv import FPVProjector
from ocean.operator import RootOperator
from ocean.platforms import platform_adapter
from ocean.security import KeychainTokenStore
from ocean.accounts import AccountStore
from ocean.email_delivery import EmailDelivery
from ocean.email_outbox import EmailOutbox
from ocean.node import export_root_recovery, restore_root_recovery
from ocean.event_sourcing.replay import EventReplayer
from persistence.serializers.work_graph import WorkGraphSerializer
from ocean.device_registry import DeviceRegistry
from ocean.billing import BillingStore, EntitlementEngine, BillingWebhook, PLANS
from ocean.control_plane_features import MissionFeatureStore, MissionPolicy, MissionMode, MissionCheckpoint, render_template, deterministic_simulation
from ocean.advanced_capabilities import counterfactual
from ocean.lumo_cursor import CursorAction, CursorActionType, CursorContext, LumoCursor, validate_cursor_plan
from ocean.lumo_cursor_adapter import MacOSAccessibilitySurface, VirtualCursorAdapter
from ocean.security import SessionAuthority, BruteForceLimiter
from ocean.api_security import APIAuth
from runtime.types import ExecutionRequest
from ocean.platform_hardening import IdempotencyLedger, WorkerLeaseBook
from ocean.orchestration.intelligence_coordinator import IntelligenceCoordinator, WorkItem, ExecutionMode
from ocean.orchestration.worker_registry import WorkerHandle, WorkerRegistry, WorkerState
from ocean.resources.intelligence_governor import LocalResourceGovernor
from ocean.resources.local_model_manager import LocalModelManager
from ocean.resources.resource_autopilot import ResourceAutopilot
from ocean.bootstrap_intelligence import BootstrapIntelligence
from ocean.setup_autopilot import SetupAutopilot
from ocean.intelligence_catalog import PerformanceLevel, profile as intelligence_profile, build_registry as build_intelligence_registry
from ocean.intelligence_swarm import IntelligenceSwarm
from ocean.startup_state import StartupStateMachine
from ocean.intelligence_handoff import IntelligenceHandoff
from ocean.local_model_client import LocalOllamaResponsesClient
from ocean.resources.intelligence_governor import ResourceRequest
from ocean.web_search import WebSearch


_COMPUTER_MAX_STEPS = 160

_MAX_EVENT_LIMIT = 500
_DEFAULT_EVENT_LIMIT = 100
_ALLOWED_ORIGINS = {"http://localhost:3000", "http://127.0.0.1:3000"}
_API_RATE_WINDOW_SECONDS = 1.0
_API_RATE_MAX_MUTATIONS = 30
_API_MAX_BODY_BYTES = 64 * 1024
_ERROR_PATH_RE = re.compile(r"(?<![A-Za-z0-9:/])/(?:Users|home|tmp|private/(?:Users|tmp|var)|var/folders)/[^\s\"\'<>]+")


class _CancellationGateExecutor:
    """Fail-closed adapter used to invalidate an in-flight computer agent."""

    def __init__(self, underlying, cancelled: Callable[[], bool]):
        self._underlying = underlying
        self._cancelled = cancelled

    def execute(self, request, context=None):
        if self._cancelled():
            from runtime.types import ExecutionResult
            return ExecutionResult.failed("LUMO emergency stop cancelled this World execution")
        return self._underlying.execute(request, context)


class LumoAPI:
    """HTTP application backed by one persistent OceanService."""

    def __init__(self, service: OceanService) -> None:
        self.service = service
        self._login_limiter = BruteForceLimiter(max_failures=5, window_seconds=300)
        self._missions: dict[str, dict[str, Any]] = {}
        self._mission_cancelled: set[str] = set()
        self._mission_threads: dict[str, threading.Thread] = {}
        self._computer_tasks: dict[str, dict[str, Any]] = {}
        self._computer_cancelled: set[str] = set()
        self._computer_paused: set[str] = set()
        self._improvement_tasks: dict[str, dict[str, Any]] = {}
        self._lock = threading.RLock()
        # Computer actions execute inside isolated LUMO Worlds. The lease keeps one
        # computer task active at a time until world-level scheduling is expanded.
        self._computer_lease = threading.Lock()
        self._worker_leases = WorkerLeaseBook()
        self._computer_idempotency = IdempotencyLedger()
        self._intelligence = IntelligenceCoordinator(max_workers=16)
        self._workers = WorkerRegistry()
        self._intelligence_governor = LocalResourceGovernor()
        self._local_model_manager = LocalModelManager()
        # Always-on resource observer. It never force-quits user apps; user-app
        # intervention is ask-by-default and can only become automatic by opt-in.
        self._resource_autopilot = ResourceAutopilot(self)
        self._bootstrap_intelligence = BootstrapIntelligence(self._local_model_manager)
        # Bootstrap is deliberately asynchronous: LUMO can render immediately while the
        # tiny model is provisioned and health-checked in the background.
        self._bootstrap_thread = threading.Thread(target=self._run_bootstrap, name="lumo-bootstrap", daemon=True)
        self._bootstrap_thread.start()
        self._setup_autopilot = SetupAutopilot(self)
        self._intelligence_registry = build_intelligence_registry()
        self._startup_state = StartupStateMachine()
        self._intelligence_handoff = IntelligenceHandoff(self._local_model_manager)
        self._web_search = WebSearch()
        self._emergency_stop = threading.Event()
        self._emergency_stop.set()
        # Safety acknowledgement is durable. A normal Core restart must not silently
        # return an already-released installation to STOPPED; only a new explicit
        # emergency-stop event should re-arm the gate.
        try:
            if self.service.events is not None:
                safety_events = [
                    event for event in self.service.events.history()
                    if event.type in {"EmergencyStopEngaged", "EmergencyStopReleased"}
                    and event.aggregate_id == "lumo"
                ]
                if safety_events and safety_events[-1].type == "EmergencyStopReleased":
                    self._emergency_stop.clear()
        except Exception:
            # Fail closed if the durable safety state cannot be read.
            self._emergency_stop.set()
        self._safety_release_attention_sent = False
        self._recoverable_missions: set[str] = set()
        self._desktop_world_lock = threading.RLock()
        self._desktop_world_id: str | None = None
        self._accounts = AccountStore(self.service._state_dir / "accounts.sqlite3")
        self._active_account_id = self._accounts.ensure_default()["id"]
        self._feedback_lock = threading.RLock()
        self._feedback_path = Path(self.service._state_dir) / "user_feedback.jsonl"
        self._feedback_path.parent.mkdir(parents=True, exist_ok=True)
        self._accounts.bind_root(self._active_account_id, self.service.root_authority.root_id)
        self._billing = BillingStore(self.service._state_dir / "billing.sqlite3")
        self._entitlements = EntitlementEngine(self._billing)
        self._local_device = self._ensure_local_device(self._active_account_id)
        # Keep the local installation's durable device lease alive while Core is running.
        # The registry intentionally marks stale devices offline, so a live packaged Core
        # must heartbeat independently of UI polling.
        self._device_heartbeat_stop = threading.Event()
        self._device_heartbeat_thread = threading.Thread(target=self._device_heartbeat_loop, name="lumo-device-heartbeat", daemon=True)
        self._device_heartbeat_thread.start()
        self._shadow = ShadowAgent(interval=0.75)
        self._worlds = service.worlds
        self._fpv = FPVProjector(service.events, self._worlds)
        self._rate_lock = threading.Lock()
        self._rate_buckets: dict[str, tuple[float, int]] = {}
        self._mission_features = MissionFeatureStore(self.service._state_dir / "mission_features.sqlite3")
        self._sessions = SessionAuthority(secret=(os.getenv("LUMO_API_SESSION_SECRET") or "").encode() or None)
        self._api_auth = APIAuth(self._sessions)
        self._email_delivery = EmailDelivery(account_id=self._active_account_id)
        self._email_outbox = EmailOutbox(self.service._state_dir / "email_outbox.sqlite3", self._email_delivery)
        self._root_operator = RootOperator(self.service)
        # Mission list reads are polled by the UI. Cache the projected read
        # model and advance it only when the event sequence changes; otherwise
        # every 1.5s poll would decrypt the entire durable event log.
        self._mission_read_cache: dict[str, dict[str, dict[str, Any]]] = {}
        self._mission_read_cache_sequence: dict[str, int] = {}
    def _run_bootstrap(self) -> None:
        """Provision and health-check the tiny bootstrap model without blocking startup."""
        try:
            status = self._bootstrap_intelligence.ensure_model(allow_download=True)
            if status.installed and status.fits_now:
                self._bootstrap_intelligence.health_check()
        except Exception:
            # Readiness remains truthful through the bootstrap status object; startup must continue.
            pass

    def allow_mutation(self, client_key: str) -> bool:
        """Bound local mutation throughput to prevent accidental runaway loops."""
        now = time.monotonic()
        with self._rate_lock:
            started, count = self._rate_buckets.get(client_key, (now, 0))
            if now - started >= _API_RATE_WINDOW_SECONDS:
                started, count = now, 0
            if count >= _API_RATE_MAX_MUTATIONS:
                self._rate_buckets[client_key] = (started, count)
                return False
            self._rate_buckets[client_key] = (started, count + 1)
            if len(self._rate_buckets) > 256:
                cutoff = now - (_API_RATE_WINDOW_SECONDS * 2)
                self._rate_buckets = {k: v for k, v in self._rate_buckets.items() if v[0] >= cutoff}
            return True

    def create_session(self, account_id: str, bootstrap_secret: str | None = None) -> dict[str, Any]:
        if account_id not in {a["id"] for a in self._accounts.list()}: raise PermissionError("unknown account")
        expected=os.getenv("LUMO_API_SESSION_BOOTSTRAP_SECRET")
        if not expected or not bootstrap_secret or not hmac.compare_digest(str(bootstrap_secret), expected):
            raise PermissionError("session bootstrap is not authorized")
        token=self._sessions.issue(account_id)
        return {"token":token,"account_id":account_id,"expires_in":3600}

    def signup(self, name: str, email: str, password: str) -> dict[str, Any]:
        if os.getenv("LUMO_API_AUTH_REQUIRED", "0") == "1" and not self._email_delivery.configured:
            raise RuntimeError("transactional email delivery is not configured")
        account = self._accounts.create_user(name, email, password)
        self._accounts.bind_root(account["id"], self.service.root_authority.root_id)
        token = self._accounts.begin_email_verification(account["id"])
        self._email_outbox.enqueue(to=account["email"], subject="Verify your LUMO account", template="verify-email", variables={"token": token, "account_id": account["id"]}, account_id=account["id"])
        return {"account": self._accounts.get(account["id"]), "email_verification_sent": True}

    def local_login(self, *, local_request: bool = False) -> dict[str, Any]:
        # A packaged single-user LUMO install may use the local-login path from
        # loopback to finish first-run configuration before transactional email
        # is configured. Remote/production callers must still use normal auth.
        auth_required = os.getenv("LUMO_API_AUTH_REQUIRED", "0") == "1"
        allow_local_setup = os.getenv("LUMO_LOCAL_INSTALL", "0") == "1"
        if auth_required and not (allow_local_setup and local_request):
            raise PermissionError("local login is disabled when API authentication is required")
        account = self._accounts.get(self._active_account_id)
        token = self._sessions.issue(account["id"])
        return {"token": token, "account_id": account["id"], "expires_in": 3600, "email_verified": account["email_verified"], "local_mode": True}

    def login(self, email: str, password: str, *, attempt_key: str = "global") -> dict[str, Any]:
        key = str(attempt_key or "global")[:300]
        if not self._login_limiter.allowed(key):
            raise PermissionError("too many login attempts; try again later")
        try:
            account = self._accounts.authenticate(email, password)
        except PermissionError:
            self._login_limiter.record_failure(key)
            raise
        if not account["email_verified"]:
            raise PermissionError("email address must be verified before login")
        self.switch_account(account["id"])
        self._login_limiter.clear(key)
        token = self._sessions.issue(account["id"])
        return {
            "token": token,
            "account_id": account["id"],
            "expires_in": 3600,
            "email_verified": account["email_verified"],
            "local_mode": False,
        }

    def change_password(self, current_password: str, new_password: str) -> dict[str, Any]:
        account = self._accounts.authenticate(self._active_account_id, current_password) if "@" not in self._active_account_id else None
        # Local account IDs are not emails; authenticate() accepts email, so use the stored account.
        if account is None:
            current = self._accounts.get(self._active_account_id)
            if not current.get("password_hash") or not self._accounts._password_matches(current_password, current["password_hash"]):
                raise PermissionError("current password is incorrect")
        self._accounts.set_password(self._active_account_id, new_password)
        return {"changed": True}

    def resend_email_verification(self) -> dict[str, Any]:
        account = self._accounts.get(self._active_account_id)
        if not account.get("email"):
            raise ValueError("this account has no email address")
        if account.get("email_verified"):
            return {"sent": False, "already_verified": True}
        token = self._accounts.begin_email_verification(account["id"])
        self._email_outbox.enqueue(to=account["email"], subject="Verify your LUMO account", template="verify-email", variables={"token": token, "account_id": account["id"]}, account_id=account["id"])
        return {"sent": True}

    def delete_account(self, password: str, confirmation: str) -> dict[str, Any]:
        account = self.account()
        if confirmation != account["name"]:
            raise ValueError("account name confirmation does not match")
        if not account.get("password_hash") or not self._accounts._password_matches(password, account["password_hash"]):
            raise PermissionError("password is incorrect")
        account_id = self._active_account_id
        for mission in self.missions():
            if str(mission.get("account_id") or "") == account_id and mission.get("status") in {"running", "recoverable", "accepted"}:
                try: self.cancel_mission(str(mission["id"]))
                except Exception: pass
        for world in list(self.service.worlds.list()):
            if world.account_id == account_id and world.status.value not in {"destroyed", "destroying"}:
                try: self.service.worlds.force_destroy(world.id, reason="account_deleted")
                except Exception: pass
        self._sessions.revoke_account(account_id)
        self.service.devices.delete_account(account_id)
        self.service.nodes.delete_account(account_id)
        self._billing.delete_account(account_id)
        self._accounts.delete(account_id)
        return {"deleted": True, "account_id": account_id}

    def logout(self, token: str) -> dict[str, Any]:
        self._sessions.revoke(token)
        return {"logged_out": True}

    def csrf_token(self, method: str, path: str, session_id: str) -> dict[str, str]:
        if not method or not path or not session_id:
            raise ValueError("method, path, and session_id are required")
        nonce = secrets.token_urlsafe(24)
        return {"nonce": nonce, "token": self._api_auth.csrf(session_id, method, path, nonce)}

    def verify_account_email(self, token: str) -> dict[str, Any]:
        return self._accounts.verify_email(token)

    def request_password_reset(self, email: str) -> dict[str, Any]:
        result = self._accounts.begin_password_reset(email)
        if result:
            account_id, token = result
            account = self._accounts.get(account_id)
            self._email_outbox.enqueue(to=account["email"], subject="Reset your LUMO password", template="password-reset", variables={"token": token, "account_id": account_id}, account_id=account_id)
        return {"accepted": True}

    def complete_password_reset(self, token: str, password: str) -> dict[str, Any]:
        account = self._accounts.reset_password(token, password)
        self._sessions.revoke_account(account["id"])
        return account

    def health(self) -> dict[str, Any]:
        return {"status": "ok", "running": self.service.is_running}

    def startup_state(self) -> dict[str, Any]:
        """Return the canonical startup state derived only from verified facts."""
        readiness = self.readiness()
        intelligence = readiness.get("intelligence", {})
        bootstrap = intelligence.get("bootstrap", {}) if isinstance(intelligence, dict) else {}
        missing = self.missing_setup_permissions()
        facts = {
            "core": self.service.is_running,
            "event_store": self.service.event_store is not None,
            "bootstrap_installed": bool(bootstrap.get("installed")),
            "bootstrap_healthy": bool(bootstrap.get("healthy")),
            "intelligence_ready": bool(intelligence.get("local_intelligence_ready")),
            # macOS TCC grants are capability gates, not launch prerequisites.
            # Keep startup launchable while exposing missing capabilities separately.
            "permissions_ready": not missing,
            "permissions_required": False,
            "optional_permissions": missing,
            "services_ready": bool(readiness.get("autonomous_runtime")),
            # Startup verification proves the release prerequisites; the emergency
            # stop is an intentional post-start safety state and is surfaced separately.
            "verified": bool(readiness.get("release_ready")),
            # Missing TCC grants are optional capability gaps, not startup blockers.
            "blocker": ((readiness.get("degraded_reason") if readiness.get("degraded_reason") != "emergency_stop_engaged" else None) or ("memory" if not bool(intelligence.get("local_intelligence_ready")) and bool(readiness.get("memory", {}).get("memory_pressure")) else None)),
        }
        return self._startup_state.reconcile(facts).__dict__

    def diagnostics(self) -> dict[str, Any]:
        """Produce one user-facing health report from the same readiness sources."""
        readiness = self.readiness()
        intelligence = readiness.get("intelligence", {})
        bootstrap = intelligence.get("bootstrap", {}) if isinstance(intelligence, dict) else {}
        memory = readiness.get("memory", {})
        checks = [
            {"id": "core", "label": "Core", "ok": self.service.is_running, "detail": "Control plane running" if self.service.is_running else "Core stopped"},
            {"id": "event_store", "label": "Event store", "ok": self.service.event_store is not None, "detail": "Durable state available" if self.service.event_store is not None else "Event store unavailable"},
            {"id": "bootstrap", "label": "Bootstrap intelligence", "ok": bool(bootstrap.get("healthy")), "detail": str(bootstrap.get("reason") or bootstrap.get("state") or "unknown")},
            {"id": "models", "label": "Local models", "ok": bool(intelligence.get("local_models")), "detail": f"{len(intelligence.get('local_models', []))} installed"},
            {"id": "memory", "label": "Memory", "ok": not bool(memory.get("memory_pressure")), "detail": f"{memory.get('used_ram_gib', 0):.1f} / {memory.get('physical_ram_gib', 0):.1f} GiB"},
            {"id": "permissions", "label": "Computer permissions", "ok": not bool(self.missing_setup_permissions()), "detail": "All required permissions present" if not self.missing_setup_permissions() else "macOS permissions still required"},
            {"id": "runtime", "label": "Mission runtime", "ok": bool(readiness.get("mission_execution")), "detail": "Mission execution available" if readiness.get("mission_execution") else "Mission execution unavailable"},
            {"id": "safety", "label": "Safety system", "ok": bool(readiness.get("emergency_stop")), "detail": "Emergency stop armed"},
            {"id": "storage", "label": "State storage", "ok": self.service._state_dir.exists(), "detail": str(self.service._state_dir)},
        ]
        return {"overall": "ready" if all(bool(c["ok"]) for c in checks) else "needs_attention", "checks": checks, "startup": self.startup_state(), "generated_at": time.time()}

    def email_status(self) -> dict[str, Any]:
        """Return safe transactional-email diagnostics without exposing credentials."""
        status = self._email_outbox.status()
        status["outbox"] = True
        return status

    def email_process_pending(self) -> dict[str, Any]:
        processed = self._email_outbox.process_pending(limit=50)
        return {"processed": processed, "status": self.email_status()}

    def configure_email_smtp(self, host: str, port: int, tls_mode: str,
                             username: str, password: str, from_address: str) -> dict[str, Any]:
        """Configure LUMO-native SMTP; credentials are stored in macOS Keychain."""
        return self._email_delivery.configure_local_smtp(
            host=host, port=port, tls_mode=tls_mode, username=username,
            password=password, from_address=from_address,
        )

    def test_email_delivery(self, recipient: str) -> dict[str, Any]:
        recipient = str(recipient or "").strip()
        if not recipient or "@" not in recipient:
            raise ValueError("recipient email is required")
        result = self._email_outbox.enqueue(
            to=recipient, subject="LUMO email delivery test", template="notification", variables={},
            account_id=self._active_account_id,
        )
        return {"sent": bool(result.get("sent")), "queued": bool(result.get("queued")), "status": self.email_status()}

    def root_recovery_export(self, password: str) -> dict[str, Any]:
        if not isinstance(password, str) or len(password) < 12:
            raise ValueError("root recovery password must be at least 12 characters")
        recovery_dir = self.service._state_dir / "root-recovery"
        recovery_dir.mkdir(parents=True, exist_ok=True)
        destination = recovery_dir / f"root-{self.service.root_authority.root_id}.lumo-recovery"
        export_root_recovery(self.service.root_authority, destination, password)
        return {"created": True, "root_id": self.service.root_authority.root_id, "path": str(destination)}

    def root_recovery_restore(self, path: str, password: str) -> dict[str, Any]:
        candidate = Path(path).expanduser().resolve()
        recovery_root = (self.service._state_dir / "root-recovery").resolve()
        try:
            candidate.relative_to(recovery_root)
        except ValueError as exc:
            raise PermissionError("Root recovery files must be inside the LUMO recovery directory") from exc
        root_id = restore_root_recovery(self.service.root_authority, candidate, password)
        return {"restored": True, "root_id": root_id}

    def root_console_secret(self) -> str:
        store = KeychainTokenStore("LUMO Root Console")
        account = self.service.root_authority.root_id
        secret = store.get(account)
        if secret is None:
            secret = secrets.token_urlsafe(32)
            store.set(account, secret)
        return secret

    def verify_root_console_secret(self, presented: str | None) -> bool:
        expected = self.root_console_secret()
        return bool(presented) and secrets.compare_digest(str(presented), expected)

    def root_operator(self) -> dict[str, Any]:
        snapshot = self._root_operator.snapshot(self)
        platform = platform_adapter()
        snapshot["platform"] = {
            "os": platform.info.os,
            "architecture": platform.info.architecture,
            "version": platform.info.version,
            "family": platform.info.family,
            "capabilities": platform.capabilities(),
        }
        return snapshot

    def metrics(self) -> dict[str, Any]:
        if self.service.event_store is None:
            raise RuntimeError("event store is unavailable")
        reader = MetricsReader(self.service.event_store)
        return {"events": reader.type_counts(), "sources": reader.source_counts()}

    def trace(self, correlation_id: str) -> list[dict[str, Any]]:
        if not correlation_id or not correlation_id.strip():
            raise ValueError("correlation_id is required")
        if self.service.event_store is None:
            raise RuntimeError("event store is unavailable")
        return [_event_to_dict(item.event, sequence=item.sequence) for item in TraceReader(self.service.event_store).correlated_events(correlation_id.strip())]

    def openapi(self) -> dict[str, Any]:
        """Return the local control-plane contract without exposing secrets."""
        paths = {
            "/api/health": {"get": {}},
            "/api/session": {"post": {}},
            "/api/auth/logout": {"post": {}},
            "/api/auth/local": {"post": {}},
            "/api/session/csrf": {"get": {}},
            "/api/readiness": {"get": {}},
            "/api/startup": {"get": {}},
            "/api/diagnostics": {"get": {}},
            "/api/memory/apps": {"get": {}, "post": {}},
            "/api/resource-autopilot": {"get": {}, "post": {}},
            "/api/emergency-stop": {"get": {}, "post": {}},
            "/api/emergency-stop/release": {"post": {}},
            "/api/accounts": {"get": {}},
            "/api/account": {"get": {}, "post": {}},
            "/api/devices": {"get": {}, "post": {}},
            "/api/events": {"get": {}},
            "/api/missions": {"get": {}, "post": {"headers": ["Idempotency-Key"]}},
            "/api/missions/{mission_id}": {"get": {}},
            "/api/missions/{mission_id}/cancel": {"post": {}},
            "/api/missions/{mission_id}/receipt": {"get": {}},
            "/api/worlds": {"get": {}, "post": {}},
            "/api/computer": {"post": {}},
            "/api/computer/{task_id}/pause": {"post": {}},
            "/api/computer/{task_id}/resume": {"post": {}},
            "/api/computer/{task_id}/takeover": {"post": {}},
            "/api/computer/tasks": {"get": {}},
            "/api/improvements": {"post": {}},
            "/api/billing": {"get": {}},
        }
        return {
            "openapi": "3.0.3",
            "info": {"title": "LUMO Local Control Plane", "version": "1.1.1"},
            "servers": [{"url": "http://127.0.0.1:8765"}],
            "paths": paths,
        }

    def _release_readiness(self) -> dict[str, Any]:
        """Return prerequisites required to safely release the boot safety stop.

        This deliberately excludes the emergency-stop bit itself. The stop is
        the thing being released, so using the full operational readiness flag
        here would create a circular gate.
        """
        blockers: list[str] = []
        if not self.service.is_running:
            blockers.append("service_unavailable")
        if self.service.event_store is None:
            blockers.append("event_store_unavailable")
        if self.service.mission_execution_error is not None:
            blockers.append("mission_execution_unavailable")
        # A packaged local install is the real launch boundary. Development
        # services/tests may intentionally omit macOS TCC and model bootstrap;
        # the signed app must not. This keeps the production gate strict without
        # making low-level service tests depend on the host machine's permissions.
        if os.getenv("LUMO_LOCAL_INSTALL", "0") == "1":
            try:
                missing_permissions = self.missing_setup_permissions()
            except Exception:
                missing_permissions = ["permission_probe_failed"]
            # TCC permissions are capability gates for specific computer-control features,
            # not prerequisites for opening the local control plane. First launch must be
            # usable even when Accessibility/Screen Recording/etc. are still pending.
            # The UI reports these capabilities separately and requests them only when needed.
            bootstrap = self._bootstrap_intelligence.status()
            if not bool(bootstrap.healthy and bootstrap.fits_now):
                blockers.append("bootstrap_intelligence_unavailable")
            devices = self.service.devices.list(self._active_account_id)
            if not any(d.status == "online" for d in devices):
                blockers.append("no_online_device")
        return {"ready": not blockers, "blockers": blockers}

    def _surface_safety_release_attention(self, release_gate: dict[str, Any]) -> None:
        """Notify the persistent companion exactly once per stop cycle."""
        if self._emergency_stop.is_set() and bool(release_gate.get("ready")):
            if self._safety_release_attention_sent:
                return
            self._safety_release_attention_sent = True
            self.service.active_assistant.notify_human_action(
                message="LUMO is ready and safely stopped. I need your safety acknowledgement before I can go live.",
                suggestion="Open LUMO, review the safety acknowledgement, and release me when you are ready.",
                urgency="important", kind="safety_release",
            )
        elif not self._emergency_stop.is_set():
            self._safety_release_attention_sent = False

    def readiness(self) -> dict[str, Any]:
        """Return a truthful, non-sensitive control-plane readiness snapshot."""
        event_store = self.service.event_store
        worlds = [w for w in self._worlds.list() if w.status.value not in {"destroyed", "failed"}]
        devices = self.service.devices.list(self._active_account_id)
        try:
            requested_max = float(os.getenv("LUMO_LOCAL_MAX_MODEL_GIB", "64"))
            local_max = min(64.0, max(0.0, requested_max)) if math.isfinite(requested_max) else 64.0
        except (TypeError, ValueError):
            local_max = 64.0
        mission_execution = self.service.mission_execution_error is None
        emergency_stop = self._emergency_stop.is_set()
        release_gate = self._release_readiness()
        self._surface_safety_release_attention(release_gate)
        ready = bool(release_gate["ready"] and not emergency_stop)
        device_resources = self._intelligence_governor.snapshot()
        level_raw = os.getenv("LUMO_PERFORMANCE_LEVEL", "standard").strip().lower()
        try:
            performance = PerformanceLevel(level_raw)
        except ValueError:
            performance = PerformanceLevel.STANDARD
        performance_policy = intelligence_profile(performance)
        memory = self.memory_status()
        live_inventory = self._local_model_manager.inventory()
        live_names = {item.name for item in live_inventory}
        installed_local = [m for m in self._intelligence_registry.list() if m.privacy == "local" and m.model_id in live_names]
        safe_budget_gib = device_resources.safe_ai_ram_bytes / 1024**3
        # Runtime estimates are intentionally rounded to conservative decimal
        # GiB values (for example 0.85), while the byte-derived budget can land
        # a few bits below that decimal value. Treat that tiny representation
        # gap as equal; it must not make the bootstrap model appear unsafe.
        fit_epsilon_gib = 1e-6
        fitting_local = [m for m in installed_local if (m.runtime_ram_gib or m.size_gib or 0) <= safe_budget_gib + fit_epsilon_gib]
        bootstrap = self._bootstrap_intelligence.status()
        runtime_candidates = [m for m in fitting_local if m.model_id != BootstrapIntelligence.MODEL]
        runtime_candidates.sort(key=lambda m: (m.runtime_ram_gib or m.size_gib or 0), reverse=True)
        recommended_local_model = runtime_candidates[0].model_id if runtime_candidates else BootstrapIntelligence.MODEL if bootstrap.healthy else None
        recommended_runtime_ram = (runtime_candidates[0].runtime_ram_gib or runtime_candidates[0].size_gib) if runtime_candidates else None
        handoff = self._intelligence_handoff.maybe_start(recommended_local_model if recommended_local_model != BootstrapIntelligence.MODEL else None, recommended_runtime_ram)
        minimum_local_ram_gib = min(((m.runtime_ram_gib or m.size_gib or 0) for m in installed_local), default=0.0)
        missing_permissions = self.missing_setup_permissions()
        return {
            "ready": ready,
            "service": "running" if self.service.is_running else "stopped",
            "setup_permissions": {"missing": missing_permissions, "checked": True},
            "event_store": "available" if event_store is not None else "unavailable",
            "emergency_stop": emergency_stop,
            "release_ready": bool(release_gate["ready"]),
            "release_blockers": list(release_gate["blockers"]),
            "autonomous_runtime": self.service._runtime is not None,
            "mission_execution": mission_execution,
            "intelligence_provider": mission_execution,
            "degraded_reason": (
                "emergency_stop_engaged" if emergency_stop else
                "mission_execution_unavailable" if not mission_execution else None
            ),
            "worlds_active": len(worlds),
            "devices_online": sum(1 for d in devices if d.status == "online"),
            "local_model_max_gib": local_max,
            "memory": memory,
            "intelligence": {
                "performance_level": performance.value,
                "standard_provider": "ollama",
                "pro_provider": "ollama",
                "local_ai_ram_budget_gib": round(device_resources.safe_ai_ram_bytes / 1024**3, 2),
                "local_ai_ram_available_gib": round(max(0, device_resources.safe_ai_ram_bytes - sum(r.ram_bytes for r in self._intelligence_governor.reservations())) / 1024**3, 2),
                "max_concurrent_local_workers": self._intelligence_governor.max_concurrent_workers,
                "local_models": [m.model_id for m in installed_local],
                "local_model_inventory_status": "connected" if self._local_model_manager.inventory_error is None else "stale_or_unavailable",
                "local_model_inventory_error": self._local_model_manager.inventory_error,
                "local_models_fitting_now": [m.model_id for m in fitting_local],
                "local_intelligence_ready": bool(fitting_local),
                "minimum_local_model_ram_gib": round(minimum_local_ram_gib, 2),
                "recommended_local_model": recommended_local_model,
                "handoff": {"bootstrap_model": BootstrapIntelligence.MODEL, "runtime_model": recommended_local_model, "automatic_when_memory_allows": True, "state": handoff.state, "active_model": handoff.active_model, "reason": handoff.reason},
                "startup_truth": "inventory_from_ollama",
                "bootstrap": {"model": bootstrap.model, "installed": bootstrap.installed, "fits_now": bootstrap.fits_now, "healthy": bootstrap.healthy, "state": bootstrap.state, "reason": bootstrap.reason},
                "safety": {"ai_cannot_raise_budget": True, "fails_closed_on_unknown_hardware": True, "emergency_stop_authoritative": True},
                "policy": {"max_local_gib": performance_policy.max_local_gib, "max_workers": performance_policy.max_workers, "cloud_allowed": performance_policy.allow_cloud},
                "swarm": IntelligenceSwarm(governor=self._intelligence_governor).snapshot(),
            },
            "api_security": {"loopback_only": True, "browser_origins_restricted": True},
        }

    def memory_status(self) -> dict[str, Any]:
        """Return truthful local memory pressure and user-selectable app candidates."""
        device = self._intelligence_governor.snapshot()
        total = device.physical_ram_bytes
        available = device.available_ram_bytes
        used = max(0, total - available)
        target = max(1, int(total * 0.50))
        pressure = used > target
        apps: list[dict[str, Any]] = []
        # Do not use System Events for routine memory accounting. It requires
        # Automation permission and can block the API or emit noisy AppleScript
        # errors during first launch. Process-table accounting is permission-free.
        if platform.system() == "Darwin":
            try:
                raw = subprocess.check_output(["/bin/ps", "-axo", "pid=,rss=,comm="], text=True, timeout=3)
                grouped: dict[str, dict[str, Any]] = {}
                for line in raw.splitlines():
                    parts = line.strip().split(None, 2)
                    if len(parts) != 3 or not parts[0].isdigit() or not parts[1].isdigit():
                        continue
                    pid, rss_kib, command = int(parts[0]), int(parts[1]), parts[2]
                    if pid <= 0 or rss_kib <= 0:
                        continue
                    # `comm` may point at the main executable or a nested helper.
                    # Walk the path and use the nearest real .app bundle so nested
                    # Electron helpers are attributed to their parent application.
                    prefix = command.split("/Contents/", 1)[0] if "/Contents/" in command else ""
                    app_parts = prefix.split("/") if prefix else []
                    app_index = max((i for i, part in enumerate(app_parts) if part.endswith(".app")), default=-1)
                    if app_index < 0:
                        continue
                    bundle = "/".join(app_parts[:app_index + 1])
                    if not (bundle.startswith("/Applications/") or bundle.startswith(os.path.expanduser("~/Applications/")) or bundle.startswith("/System/Applications/")):
                        continue
                    name = Path(bundle).stem
                    if name in {"LUMO", "Finder", "System Events"}:
                        continue
                    entry = grouped.setdefault(name, {"name": name, "pid": pid, "memory_gib": 0.0, "frontmost": False, "background_only": False, "pids": []})
                    entry["memory_gib"] += rss_kib / 1024 / 1024
                    entry["pids"].append(pid)
                frontmost_name = ""
                try:
                    front = subprocess.run(
                        ["/usr/bin/osascript", "-e", 'tell application "System Events" to get name of first application process whose frontmost is true'],
                        capture_output=True, text=True, timeout=2, check=False,
                    )
                    if front.returncode == 0:
                        frontmost_name = front.stdout.strip()
                except Exception:
                    # Failure to identify the foreground app must make us more
                    # conservative, never more aggressive.
                    frontmost_name = ""
                apps = []
                for item in grouped.values():
                    item["memory_gib"] = round(float(item["memory_gib"]), 2)
                    item["frontmost"] = item["name"] == frontmost_name
                    item["background_only"] = False
                    if item["frontmost"]:
                        item["background_only"] = False
                    # psutil can identify whether an app process is interactive;
                    # absence of that signal must never be treated as idle.
                    try:
                        # Use the process table directly so the packaged Core has
                        # the same classification regardless of optional psutil
                        # availability. Only the main app process matters here.
                        main_pid = int(item.get("pid") or 0)
                        row = subprocess.check_output(["/bin/ps", "-p", str(main_pid), "-o", "state=,%cpu="], text=True, timeout=1).strip().split()
                        state = row[0] if row else "?"
                        cpu = float(row[1]) if len(row) > 1 else 100.0
                        item["background_only"] = (not item["frontmost"]) and state in {"S", "I"} and cpu < 2.0
                        item["cpu_percent"] = round(cpu, 1)
                    except Exception:
                        item["background_only"] = False
                    apps.append(item)
            except Exception:
                # Preserve whatever the permission-free process scan already
                # discovered. One bad process/app must never erase the entire
                # resource inventory and strand first-launch recovery.
                apps = list(locals().get("grouped", {}).values())
                for item in apps:
                    item["memory_gib"] = round(float(item.get("memory_gib", 0) or 0), 2)
                    item.setdefault("frontmost", False)
                    item.setdefault("background_only", False)
        apps.sort(key=lambda item: item["memory_gib"], reverse=True)
        return {
            "physical_ram_gib": round(total / 1024**3, 1),
            "used_ram_gib": round(used / 1024**3, 1),
            "available_ram_gib": round(available / 1024**3, 1),
            "target_used_ram_gib": round(target / 1024**3, 1),
            "memory_pressure": pressure,
            "apps": apps[:8],
        }

    def memory_state(self) -> dict[str, Any]:
        return self.memory_status()

    def resource_autopilot(self) -> dict[str, Any]:
        return self._resource_autopilot.status()

    def set_resource_autopilot_mode(self, mode: str) -> dict[str, Any]:
        return self._resource_autopilot.set_mode(mode)

    def approve_resource_recommendation(self, names: list[str], reopen: bool = False) -> dict[str, Any]:
        return self._resource_autopilot.approve_recommendation(names=names, reopen=reopen)

    def missing_setup_permissions(self) -> list[str]:
        """Return permissions currently required for hands-off computer setup."""
        missing: list[str] = []
        # Native launcher preflights the exact bridge executable before Core
        # starts. Preserve that result so Core's child-process TCC context cannot
        # create a false-negative release gate.
        if os.getenv("LUMO_AX_TRUSTED", "0") == "1":
            return []
        bridge_raw = os.getenv("LUMO_AX_BRIDGE", "").strip()
        bridge = Path(bridge_raw).expanduser() if bridge_raw else (Path(__file__).resolve().parents[1] / "tools" / "LumoAXBridge")
        try:
            if not bridge.exists():
                missing.append("accessibility")
            else:
                probe = subprocess.run([str(bridge), "frontmost"], capture_output=True, text=True, timeout=3, check=False)
                # The bridge is the process that actually performs macOS AX
                # operations. A successful frontmost probe therefore proves the
                # relevant TCC grant; do not treat unrelated stderr text as a
                # permission denial.
                if probe.returncode == 3:
                    missing.append("accessibility")
        except Exception:
            missing.append("accessibility")
        # Screen Recording is a TCC grant to the signed LUMO app. Core is a
        # bundled helper executable, so prefer the native launcher's preflight
        # rather than asking macOS about the helper's own identity.
        if os.getenv("LUMO_SCREEN_TRUSTED", "") == "1":
            return missing
        try:
            cg = ctypes.CDLL("/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics")
            cg.CGPreflightScreenCaptureAccess.restype = ctypes.c_bool
            if not bool(cg.CGPreflightScreenCaptureAccess()):
                missing.append("screen")
        except Exception:
            # Screen permission is not allowed to block normal LUMO bootstrap if
            # the platform probe is unavailable. It will be requested when vision is used.
            pass
        return missing

    def setup_autopilot(self) -> dict[str, Any]:
        return self._setup_autopilot.status()

    def start_setup_autopilot(self, *, manage_memory: bool = True) -> dict[str, Any]:
        return self._setup_autopilot.start(manage_memory=manage_memory)

    def stop_setup_autopilot(self) -> dict[str, Any]:
        return self._setup_autopilot.stop()

    def setup_autopilot_permission(self, decision: str) -> dict[str, Any]:
        return self._setup_autopilot.permission_response(decision)

    def setup_autopilot_memory(self, decision: str, names: list[str] | None = None, restart_names: list[str] | None = None) -> dict[str, Any]:
        return self._setup_autopilot.memory_response(decision, names, restart_names)

    def quit_memory_apps(self, names: list[str]) -> dict[str, Any]:
        """Gracefully quit only explicitly selected visible applications."""
        if not isinstance(names, list) or not names:
            raise ValueError("select at least one application")
        allowed = {str(item.get("name", "")).strip() for item in self.memory_status()["apps"]}
        selected = [str(name).strip() for name in names if str(name).strip() in allowed]
        if not selected:
            raise ValueError("no selected application is available to quit")
        before = self.memory_status()
        before_by_name = {str(item.get("name")): float(item.get("memory_gib", 0) or 0) for item in before.get("apps", [])}
        results = []
        for name in selected:
            try:
                escaped_name = name.replace("\\", "\\\\").replace('"', '\\"')
                completed = subprocess.run(
                    ["osascript", "-e", f'tell application "{escaped_name}" to quit'],
                    check=False, capture_output=True, text=True, timeout=8,
                )
                results.append({"name": name, "requested": completed.returncode == 0,
                                "error": completed.stderr.strip() if completed.returncode else None})
            except Exception as exc:
                results.append({"name": name, "requested": False, "error": str(exc)})
        # Give cooperative applications a short grace period, then verify from
        # the process table that the application actually disappeared. A successful
        # AppleScript request alone is not evidence that memory was reclaimed.
        verified = []
        deadline = time.monotonic() + 5.0
        while time.monotonic() < deadline:
            current = self.memory_status()
            current_names = {str(item.get("name")) for item in current.get("apps", [])}
            verified = [{"name": name, "memory_before_gib": round(before_by_name.get(name, 0.0), 2)} for name in selected if name not in current_names]
            if len(verified) == len(selected):
                break
            time.sleep(0.5)
        after = self.memory_status()
        return {"requested": results, "verified": verified, "memory_before": before, "memory": after}

    def emergency_status(self) -> dict[str, Any]:
        return {"engaged": self._emergency_stop.is_set()}

    def emergency_stop(self) -> dict[str, Any]:
        """Atomically enter the fail-closed state and invalidate live actuators."""
        self._emergency_stop.set()
        with self._lock:
            active_tasks = [
                task_id for task_id, task in self._computer_tasks.items()
                if task.get("state") in {"starting", "queued", "running", "waiting"}
            ]
            self._computer_cancelled.update(active_tasks)
            for task in self._computer_tasks.values():
                if task.get("state") in {"starting", "queued", "running", "waiting"}:
                    task.update(state="stopped", phase="emergency_stop", message="Emergency stop engaged", progress=0.0)
            for mission in self._missions.values():
                if mission.get("state") in {"starting", "running", "resuming"}:
                    mission.update(state="stopped", error="Emergency stop engaged")
        try:
            self.service.active_assistant.stop()
        except Exception:
            pass
        try:
            self.service.power.close()
        except Exception:
            pass
        # Destroy, rather than merely close, every active World. This makes
        # release-after-stop provision a fresh VM/browser instead of reviving a
        # registry entry whose provider resources were already torn down.
        for world in list(self._worlds.list()):
            if world.status.value not in {"destroyed", "failed"}:
                try:
                    self._worlds.force_destroy(world.id, reason="emergency_stop")
                except Exception:
                    pass
        with self._desktop_world_lock:
            self._desktop_world_id = None
        if self.service.events is not None:
            self.service.events.publish(Event(type="EmergencyStopEngaged", aggregate_type="system", aggregate_id="lumo", payload={"reason":"user_emergency_stop"}, source="lumo_api"))
        return self.emergency_status()

    def release_emergency_stop(self, safety_acknowledged: bool = False) -> dict[str, Any]:
        """Release the authoritative stop only through an explicit user action."""
        if safety_acknowledged is not True:
            raise ValueError("safety acknowledgement is required before releasing LUMO")
        release_gate = self._release_readiness()
        if not release_gate["ready"]:
            blockers = ", ".join(release_gate["blockers"])
            raise ValueError(f"LUMO cannot be released yet: {blockers}")
        if not self._emergency_stop.is_set():
            return self.emergency_status()

        self._emergency_stop.clear()
        self._safety_release_attention_sent = False
        if self.service.events is not None:
            self.service.events.publish(Event(
                type="EmergencyStopReleased",
                aggregate_type="system",
                aggregate_id="lumo",
                payload={"reason": "user_release", "account_id": self._active_account_id},
                source="lumo_api",
            ))
        # Recovery is intentionally gated by the same authoritative stop control.
        # A restart may discover durable in-flight missions, but must never begin
        # executing them while the emergency stop is engaged.
        for mission_id in tuple(getattr(self, "_recoverable_missions", ())):
            try:
                self._resume_mission(mission_id)
            except Exception:
                pass
        self._recoverable_missions.clear()
        return self.emergency_status()

    def recover_incomplete_missions(self) -> list[str]:
        """Rehydrate non-terminal mission submissions after process restart.

        Recovery is durable and idempotent: terminal streams are ignored and
        already-running local threads are left alone. Discovered work is held
        behind Emergency Stop until the user explicitly releases it.
        """
        if self.service.events is None:
            return []
        terminal = {"MissionSubmissionCompleted", "MissionSubmissionFailed", "MissionCancelled"}
        accepted: dict[str, dict[str, Any]] = {}
        done: set[str] = set()
        for event in self.service.events.history():
            mission_id = str(event.payload.get("mission_id") or event.aggregate_id or "")
            if not mission_id or event.type not in {"MissionSubmissionAccepted", *terminal}:
                continue
            account_id = str(event.payload.get("account_id") or self._mission_account_id(mission_id) or "")
            if account_id and account_id != self._active_account_id:
                continue
            if event.type == "MissionSubmissionAccepted":
                accepted[mission_id] = dict(event.payload)
            else:
                done.add(mission_id)
        recoverable = []
        for mission_id, payload in accepted.items():
            if mission_id in done:
                continue
            goal = str(payload.get("goal") or "").strip()
            if not goal:
                continue
            with self._lock:
                if mission_id in self._mission_threads:
                    continue
                self._missions.setdefault(mission_id, {
                    **payload, "mission_id": mission_id, "goal": goal,
                    "state": "recoverable", "account_id": self._active_account_id,
                    "message": "Mission recovered after service restart; awaiting Emergency Stop release",
                })
            recoverable.append(mission_id)
        self._recoverable_missions = set(recoverable)
        if not self._emergency_stop.is_set():
            for mission_id in recoverable:
                self._resume_mission(mission_id)
            self._recoverable_missions.clear()
        return recoverable

    def accounts(self) -> list[dict[str, Any]]:
        return self._accounts.list()

    def account(self) -> dict[str, Any]:
        return self._accounts.get(self._active_account_id)

    def update_account_profile(self, *, name: str | None = None, email: str | None = None, profile_picture_ref: str | None = None) -> dict[str, Any]:
        before = self.account()
        updated = self._accounts.update_profile(self._active_account_id, name=name, email=email, profile_picture_ref=profile_picture_ref)
        if email is not None and str(email).strip().casefold() != str(before.get("email") or "").casefold():
            token = self._accounts.begin_email_verification(self._active_account_id)
            updated = self._accounts.get(self._active_account_id)
            if updated.get("email"):
                self._email_outbox.enqueue(to=updated["email"], subject="Verify your new LUMO email", template="verify-email", variables={"token": token, "account_id": self._active_account_id}, account_id=self._active_account_id)
        return updated

    def upload_profile_picture(self, image_base64: str) -> dict[str, Any]:
        import base64
        import binascii
        value = str(image_base64 or "")
        if not value.startswith("data:image/") or ";base64," not in value:
            raise ValueError("profile picture must be a base64 data URL")
        header, encoded = value.split(",", 1)
        mime = header[5:].split(";", 1)[0].lower()
        allowed = {"image/png": (b"\x89PNG\r\n\x1a\n", ".png"), "image/jpeg": (b"\xff\xd8\xff", ".jpg"), "image/webp": (b"RIFF", ".webp")}
        if mime not in allowed:
            raise ValueError("profile picture must be PNG, JPEG, or WebP")
        try:
            raw = base64.b64decode(encoded, validate=True)
        except (ValueError, binascii.Error):
            raise ValueError("invalid profile picture encoding")
        if len(raw) > 2 * 1024 * 1024:
            raise ValueError("profile picture must be 2 MiB or smaller")
        signature, suffix = allowed[mime]
        if not raw.startswith(signature):
            raise ValueError("profile picture content does not match its type")
        directory = self.service._state_dir / "profile_pictures"
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / f"{self._active_account_id}{suffix}"
        path.write_bytes(raw)
        updated = self._accounts.update_profile(self._active_account_id, profile_picture_ref=str(path))
        return {"profile_picture_ref": updated["profile_picture_ref"]}

    def export_account_data(self) -> dict[str, Any]:
        account_id = self._active_account_id
        # Export only tenant-attributed events. The general event reader keeps
        # untagged system events visible for observability, but those must not
        # leak into an account's portable data package.
        events = [event for event in self._account_visible_events() if str((event.payload or {}).get("account_id") or "") == account_id]
        node_rows = [asdict(node) for node in self.service.nodes.list(account_id)]
        return {
            "schema_version": 1,
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "account": self.account(),
            "root": {"root_id": self.service.root_authority.root_id},
            "devices": self.devices(),
            "nodes": node_rows,
            "missions": self.missions(),
            "worlds": self.worlds(),
            "billing": self._entitlements.snapshot(self._active_account_id),
            "adaptive_state": self.adaptive_state(),
            "events": [_event_to_dict(event, sequence=self.service.event_store.sequence(event.id)) for event in events],
        }

    def organization(self) -> dict[str, Any]:
        org_id=f"org_{self._active_account_id}"
        try: org=self.service.tenancy._org(org_id)
        except KeyError:
            org=self.service.tenancy.create_organization(org_id,self._active_account_id,self.account().get("name", "LUMO"))
        teams=self.service.tenancy.db.execute("SELECT id,name FROM teams WHERE organization_id=? ORDER BY name",(org_id,)).fetchall()
        seats=self.service.tenancy.db.execute("SELECT principal_id,role,team_id FROM seats WHERE organization_id=? ORDER BY principal_id",(org_id,)).fetchall()
        return {"id":org.id,"name":org.name,"account_id":org.account_id,"teams":[{"id":r[0],"name":r[1]} for r in teams],"seats":[{"principal_id":r[0],"role":r[1],"team_id":r[2]} for r in seats]}

    def organization_team(self, team_id:str, name:str) -> dict[str,Any]:
        org_id=f"org_{self._active_account_id}"
        self.organization()
        return {"id":self.service.tenancy.add_team(org_id,team_id,name),"name":name,"organization_id":org_id}

    def organization_member(self, principal_id:str, role:str="viewer", team_id:str|None=None) -> dict[str,Any]:
        org_id=f"org_{self._active_account_id}"
        self.organization()
        member=self.service.tenancy.add_member(org_id,principal_id,role,team_id)
        return {"principal_id":member.principal_id,"role":member.role,"team_id":member.team_id,"organization_id":org_id}

    def power(self) -> dict[str, Any]:
        return self.service.power.status()

    def devices(self) -> list[dict[str, Any]]:
        self.service.devices.mark_stale(after_seconds=30.0)
        return [self._device_to_dict(device) for device in self.service.devices.list(self._active_account_id)]

    def register_device(self, body: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(body, dict):
            raise ValueError("request body must be an object")
        name = body.get("name")
        capabilities = body.get("capabilities")
        if name is not None and not isinstance(name, str):
            raise ValueError("device name must be a string")
        if capabilities is not None and not isinstance(capabilities, dict):
            raise ValueError("device capabilities must be an object")
        device = self.service.devices.register(self._active_account_id, name=name, capabilities=capabilities)
        return self._device_to_dict(device)

    def heartbeat_device(self, device_id: str) -> dict[str, Any]:
        current = self.service.devices.get(device_id)
        if current.account_id != self._active_account_id:
            raise KeyError(device_id)
        return self._device_to_dict(self.service.devices.heartbeat(device_id, account_id=self._active_account_id))

    def pair_device(self, ttl_seconds: int = 300) -> dict[str, Any]:
        code = self.service.device_lifecycle.issue_pairing_code(self._active_account_id, ttl_seconds=ttl_seconds)
        return {"code": code, "expires_in": ttl_seconds, "root_id": self.service.root_authority.root_id}

    def revoke_device(self, device_id: str) -> dict[str, Any]:
        current = self.service.devices.get(device_id)
        if current.account_id != self._active_account_id:
            raise KeyError(device_id)
        self.service.device_lifecycle.revoke(self._active_account_id, device_id)
        return self._device_to_dict(self.service.devices.get(device_id))

    @staticmethod
    def _device_to_dict(device) -> dict[str, Any]:
        return {"id": device.id, "account_id": device.account_id, "name": device.name,
                "platform": device.platform, "architecture": device.architecture,
                "capabilities": dict(device.capabilities),
                "capability_source": device.capability_source,
                "trusted_capabilities": DeviceRegistry.trusted_capabilities(device),
                "status": device.status, "last_seen": device.last_seen}

    def _device_heartbeat_loop(self) -> None:
        """Maintain the local installation's online device lease while Core lives."""
        while not self._device_heartbeat_stop.wait(10.0):
            try:
                self.service.devices.heartbeat(self._local_device.id, account_id=self._active_account_id)
            except Exception:
                # Registration can recover a deleted/stale local identity without
                # making the heartbeat thread a startup dependency.
                try:
                    self._local_device = self._ensure_local_device(self._active_account_id)
                except Exception:
                    pass

    def _ensure_local_device(self, account_id: str):
        """Bind this local installation to one durable device identity per account.

        A physical installation may belong to multiple LUMO accounts, but a
        device registry entry is account-owned. Reusing one globally-owned
        device ID across account switches would create a cross-tenant ownership
        conflict and would make the old account appear online.
        """
        identity_path = self.service._state_dir / "installation_device_seed"
        try:
            seed = identity_path.read_text().strip()
        except FileNotFoundError:
            seed = ""
        if not seed:
            import secrets
            seed = secrets.token_hex(32)
            identity_path.write_text(seed)
        digest = hashlib.sha256(f"{seed}:{account_id}".encode()).hexdigest()[:32]
        device_id = f"device_local_{digest}"
        return self.service.devices.register(account_id, name="This Mac", device_id=device_id)

    def switch_account(self, account_id: str) -> dict[str, Any]:
        account = self._accounts.get(str(account_id))
        old_device = self._local_device
        try:
            self.service.devices.heartbeat(old_device.id, status="offline", account_id=old_device.account_id)
        except KeyError:
            pass
        self._active_account_id = account["id"]
        self._local_device = self._ensure_local_device(self._active_account_id)
        return account

    def create_account(self, name: str) -> dict[str, Any]:
        account = self._accounts.create(name)
        old_device = self._local_device
        try:
            self.service.devices.heartbeat(old_device.id, status="offline", account_id=old_device.account_id)
        except KeyError:
            pass
        self._active_account_id = account["id"]
        self._local_device = self._ensure_local_device(self._active_account_id)
        return account

    def billing(self) -> dict[str, Any]:
        snapshot = self._entitlements.snapshot(self._active_account_id)
        snapshot["checkout_urls"] = {plan_id: self._entitlements.checkout_url(plan_id) for plan_id in PLANS}
        return snapshot

    def billing_checkout(self, plan_id: str) -> dict[str, Any]:
        if plan_id not in PLANS:
            raise ValueError(f"unknown plan: {plan_id}")
        if plan_id == "free":
            return {"plan_id": "free", "url": None, "status": "current"}
        url = self._entitlements.checkout_url(plan_id)
        if not url:
            return {"plan_id": plan_id, "url": None, "status": "not_configured", "message": "Configure the hosted checkout URL for this plan before accepting payments."}
        separator = "&" if "?" in url else "?"
        return {"plan_id": plan_id, "url": f"{url}{separator}lumo_account={self._active_account_id}", "status": "ready"}

    def billing_portal(self) -> dict[str, Any]:
        url = os.getenv("LUMO_BILLING_PORTAL_URL")
        if not url:
            return {"url": None, "status": "not_configured"}
        separator = "&" if "?" in url else "?"
        return {"url": f"{url}{separator}lumo_account={self._active_account_id}", "status": "ready"}

    def apply_billing_webhook(self, raw: bytes, signature: str) -> dict[str, Any]:
        if not BillingWebhook.verify(raw, signature):
            raise PermissionError("invalid billing webhook signature")
        payload = json.loads(raw or b"{}")
        event_id = str(payload.get("id") or "")
        if not event_id:
            raise ValueError("billing webhook requires id")
        if not self._billing.record_event(event_id, payload):
            return {"status": "duplicate", "event_id": event_id}
        event_type = str(payload.get("type") or "")
        data = payload.get("data") if isinstance(payload.get("data"), dict) else {}
        account_id = str(data.get("account_id") or payload.get("account_id") or "")
        plan_id = str(data.get("plan_id") or payload.get("plan_id") or "")
        if account_id and plan_id in PLANS:
            self._billing.set_subscription(
                account_id, plan_id=plan_id, status=str(data.get("status") or "active"),
                provider_customer_id=data.get("customer_id"), provider_subscription_id=data.get("subscription_id"),
                current_period_end=data.get("current_period_end"), trial_ends_at=data.get("trial_ends_at"),
            )
        return {"status": "processed", "event_id": event_id, "type": event_type}

    def adaptive_state(self) -> dict[str, Any]:
        return self._accounts.get_adaptive(self._active_account_id)

    def set_adaptive_state(self, key: str, value: Any) -> dict[str, Any]:
        return self._accounts.set_adaptive(self._active_account_id, key, value)

    def record_feedback_usage(self, seconds: float) -> dict[str, Any]:
        """Accumulate foreground usage for the optional 48-hour product check-in."""
        result = self._accounts.increment_adaptive_number(
            self._active_account_id, "feedback_usage_seconds", seconds
        )
        self._accounts.set_adaptive(
            self._active_account_id, "feedback_last_active_at", time.time()
        )
        return result

    def submit_user_feedback(self, *, rating: int | None, text: str, usage_seconds: float = 0) -> dict[str, Any]:
        """Durably route product feedback to Root and the autonomous improvement org."""
        clean_text = str(text or "").strip()
        if len(clean_text) > 8000:
            raise ValueError("feedback is too long")
        clean_rating = None if rating in (None, 0) else int(rating)
        if clean_rating is not None and clean_rating not in range(1, 6):
            raise ValueError("feedback rating must be between 1 and 5")
        record = {
            "id": new_id("feedback"),
            "timestamp": time.time(),
            "account_id": self._active_account_id,
            "root_id": self.service.root_authority.root_id,
            "rating": clean_rating,
            "text": clean_text,
            "usage_seconds": max(0.0, float(usage_seconds or 0)),
            "status": "new",
            "source": "48h_active_assistant_checkin",
        }
        with self._feedback_lock:
            with self._feedback_path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(record, sort_keys=True, ensure_ascii=False) + "\n")
            activity_path = Path(self.service.repository_root).resolve() / ".ocean" / "self_improvement_forever_activity.jsonl"
            activity_path.parent.mkdir(parents=True, exist_ok=True)
            activity = {
                "timestamp": record["timestamp"],
                "event": "user_feedback_received",
                "payload": {
                    "feedback_id": record["id"],
                    "rating": clean_rating,
                    "text": clean_text,
                    "usage_seconds": record["usage_seconds"],
                    "root_id": record["root_id"],
                },
            }
            with activity_path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(activity, sort_keys=True, ensure_ascii=False) + "\n")
        self._accounts.set_adaptive(self._active_account_id, "feedback_48h_submitted", True)
        self._accounts.set_adaptive(self._active_account_id, "feedback_48h_submitted_at", record["timestamp"])
        return {"accepted": True, "feedback_id": record["id"], "routed_to": ["root", "self_improvement"]}

    def feedback_snapshot(self, *, limit: int = 50) -> dict[str, Any]:
        """Return the local feedback inbox for Root/operator inspection."""
        rows: list[dict[str, Any]] = []
        with self._feedback_lock:
            if self._feedback_path.is_file():
                for line in self._feedback_path.read_text(encoding="utf-8").splitlines()[-max(1, limit):]:
                    try:
                        item = json.loads(line)
                    except (ValueError, TypeError):
                        continue
                    if item.get("account_id") == self._active_account_id:
                        rows.append(item)
        return {
            "count": len(rows),
            "unreviewed": sum(1 for item in rows if item.get("status") == "new"),
            "feedback": rows[-max(1, limit):],
        }

    def _owned_world(self, world_id: str):
        getter = getattr(self._worlds, "get", None)
        if not callable(getter):
            # Lightweight test doubles may expose only execute(). The real
            # WorldManager always has get(), so production ownership checks
            # remain mandatory at this boundary.
            return None
        world = getter(world_id)
        if str(world.account_id or "") != self._active_account_id:
            raise KeyError(world_id)
        return world

    def worlds(self, mission_id: str | None = None) -> list[dict[str, Any]]:
        worlds = self._worlds.list(mission_id)
        return [_world_to_dict(world) for world in worlds if str(world.account_id or "") == self._active_account_id]

    def world(self, world_id: str) -> dict[str, Any]:
        return _world_to_dict(self._owned_world(world_id))

    def create_world(self, body: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(body, dict):
            raise ValueError("request body must be an object")
        capabilities = body.get("capabilities", ())
        resources = body.get("resources", {})
        if not isinstance(capabilities, (list, tuple)) or not all(isinstance(x, str) for x in capabilities):
            raise ValueError("capabilities must be an array of strings")
        if not isinstance(resources, dict):
            raise ValueError("resources must be an object")
        persistent = body.get("persistent", True)
        network = body.get("network", True)
        if not isinstance(persistent, bool) or not isinstance(network, bool):
            raise ValueError("persistent and network must be booleans")
        kind = body.get("kind", "browser")
        if not isinstance(kind, str) or not kind.strip():
            raise ValueError("kind must be a non-empty string")
        metadata = body.get("metadata", {})
        if not isinstance(metadata, dict):
            raise ValueError("metadata must be an object")
        mission_id = body.get("mission_id")
        if mission_id is not None and not isinstance(mission_id, str):
            raise ValueError("mission_id must be a string")
        requirements = WorldRequirements(
            capabilities=tuple(capabilities), resources=resources,
            persistent=persistent, network=network,
        )
        active_worlds = len([w for w in self._worlds.list() if str(w.account_id or "") == self._active_account_id and w.status.value not in {"destroyed", "failed"}])
        self._entitlements.check(self._active_account_id, "worlds", current=active_worlds)
        if mission_id is not None:
            self._require_owned_mission(mission_id)
        world = self._worlds.create(
            mission_id=mission_id,
            account_id=self._active_account_id,
            kind=kind, requirements=requirements, metadata=dict(metadata),
        )
        return _world_to_dict(world)

    def reset_world(self, world_id: str) -> dict[str, Any]:
        self._owned_world(world_id)
        return _world_to_dict(self._worlds.reset(world_id))

    def destroy_world(self, world_id: str) -> dict[str, Any]:
        self._owned_world(world_id)
        return _world_to_dict(self._worlds.destroy(world_id))

    def snapshot_world(self, world_id: str) -> dict[str, Any]:
        self._owned_world(world_id)
        return _world_to_dict(self._worlds.snapshot(world_id))

    def clone_world(self, world_id: str, mission_id: str | None = None) -> dict[str, Any]:
        source = self._owned_world(world_id)
        if mission_id is not None:
            self._require_owned_mission(str(mission_id))
        clone = self._worlds.clone(source.id, mission_id=mission_id)
        clone.account_id = self._active_account_id
        return _world_to_dict(clone)

    def shadow_status(self) -> dict[str, Any]:
        return self._shadow.status()

    def assistant_status(self) -> dict[str, Any]:
        return self.service.active_assistant.status()

    def set_assistant(self, enabled: bool) -> dict[str, Any]:
        if not isinstance(enabled, bool):
            raise ValueError("enabled must be a boolean")
        return self.service.active_assistant.start() if enabled else self.service.active_assistant.stop()

    def dismiss_assistant(self) -> dict[str, Any]:
        self.service.active_assistant.dismiss()
        return self.service.active_assistant.status()

    def fpv(self) -> dict[str, Any]:
        return self._fpv.snapshot()

    def alerts(self) -> list[dict[str, Any]]:
        if self.service.events is None:
            return []
        events = self.service.events.history()
        resolved = {str(e.payload.get("action_id")) for e in events if e.type in {"DependencyInstalled", "DependencyInstallFailed", "UserActionResolved"}}
        out = []
        for event in events:
            if event.type not in {"DependencyInstallApprovalRequired", "UserActionRequired"}:
                continue
            action_id = str(event.payload.get("action_id") or event.id)
            mission_id = str(event.payload.get("mission_id") or "")
            if mission_id and self._mission_account_id(mission_id) != self._active_account_id:
                continue
            if action_id in resolved:
                continue
            out.append({"id": action_id, "type": event.type, "at": event.at.isoformat(), "mission_id": event.payload.get("mission_id"), **dict(event.payload)})
        return out[-50:]

    def approve_alert(self, action_id: str) -> dict[str, Any]:
        alert = next((item for item in self.alerts() if item["id"] == action_id), None)
        if alert is None:
            raise KeyError(action_id)
        mission_id = str(alert.get("mission_id") or "")
        if alert["type"] == "DependencyInstallApprovalRequired":
            action = self.service.dependency_recovery.approve(mission_id, action_id)
            if action.status == "completed":
                self._resume_mission(mission_id)
            return {"id": action.action_id, "status": action.status, "message": action.message, "evidence": list(action.evidence)}
        raise ValueError("unsupported alert type")

    def _resume_mission(self, mission_id: str) -> None:
        if self.service.events is None:
            return
        goal = None
        for event in self.service.events.history():
            if event.aggregate_id == mission_id and event.type in {"MissionStarted", "MissionSubmissionAccepted"}:
                goal = event.payload.get("goal")
                if goal:
                    break
        if not goal:
            return
        account_id = self._mission_account_id(mission_id)
        if account_id != self._active_account_id:
            raise KeyError(mission_id)
        with self._lock:
            current = self._missions.get(mission_id)
            if current and current.get("state") == "running":
                return
            self._missions[mission_id] = {"mission_id": mission_id, "goal": goal, "state": "resuming", "account_id": account_id}
        threading.Thread(target=self._run_mission, args=(mission_id, str(goal), 8, account_id), name=f"lumo-resume-{mission_id}", daemon=True).start()

    def resolve_alert(self, action_id: str) -> dict[str, Any]:
        alert = next((item for item in self.alerts() if item["id"] == action_id), None)
        if alert is None:
            raise KeyError(action_id)
        mission_id = str(alert.get("mission_id") or "")
        if self.service.events is not None:
            self.service.events.publish(Event(type="UserActionResolved", aggregate_type="mission", aggregate_id=mission_id, correlation_id=mission_id, source="lumo_api", payload={"mission_id": mission_id, "action_id": action_id}))
        self._resume_mission(mission_id)
        return {"id": action_id, "status": "resolved", "message": "LUMO is resuming the mission."}

    def world_screenshot(self, world_id: str) -> str:
        world = self._owned_world(world_id)
        capability = "desktop" if getattr(world, "kind", "browser") == "desktop" else "browser"
        request = ExecutionRequest(task_id=new_id("world_screenshot"), capability=capability, operation="screenshot", arguments={"timeout": 10}, metadata={"world_id": world_id, "account_id": getattr(world, "account_id", None)}, source="lumo.fpv")
        result = self._worlds.execute(world_id, request)
        if not getattr(result, "success", False):
            raise FileNotFoundError(getattr(result, "error", "world screenshot failed"))
        path = result.result.get("path") if isinstance(result.result, dict) else None
        if not path:
            raise FileNotFoundError("world screenshot was not produced")
        return str(path)

    def set_shadow(self, enabled: bool) -> dict[str, Any]:
        if not isinstance(enabled, bool):
            raise ValueError("enabled must be a boolean")
        return self._shadow.start() if enabled else self._shadow.stop()


    def _account_visible_events(self) -> list[Event]:
        """Return durable events visible to the active account.

        Account-tagged events are tenant-scoped. Legacy/system events without
        an account tag remain visible because they are not attributable to a
        tenant; mission-scoped endpoints still require explicit ownership.
        """
        if self.service.event_store is None:
            raise RuntimeError("event store is unavailable")
        visible: list[Event] = []
        for event in self.service.event_store.list():
            payload = event.payload or {}
            account_id = payload.get("account_id")
            if account_id is None or str(account_id) == self._active_account_id:
                visible.append(event)
        return visible

    def _mission_account_id(self, mission_id: str) -> str | None:
        if self.service.events is None:
            return None
        for event in self.service.events.history("MissionSubmissionAccepted"):
            if event.aggregate_id == mission_id:
                account_id = event.payload.get("account_id")
                return str(account_id) if account_id else None
        return None

    def _require_owned_mission(self, mission_id: str) -> None:
        owner = self._mission_account_id(mission_id)
        if owner is not None and owner != self._active_account_id:
            raise KeyError(mission_id)
        if owner is None:
            raise KeyError(mission_id)

    def mission(self, mission_id: str) -> dict[str, Any]:
        if not mission_id:
            raise ValueError("mission_id is required")
        self._require_owned_mission(mission_id)
        status = self.service.get_status(mission_id)
        if status.status == "unknown" and status.objective_count == 0 and status.last_event_at is None:
            raise KeyError(mission_id)
        return _mission_to_dict(status)

    def mission_graph(self, mission_id: str) -> dict[str, Any]:
        self._require_owned_mission(mission_id)
        if self.service.event_store is None: raise RuntimeError("event store is unavailable")
        replayed=EventReplayer().replay(self._account_visible_events())
        graphs=[g for g in replayed.work_graphs.values() if g.mission_id == mission_id]
        if not graphs: return {"mission_id":mission_id,"nodes":[],"edges":[],"graph_id":None}
        graph=sorted(graphs,key=lambda g:g.id)[-1]
        data=WorkGraphSerializer().serialize(graph)
        return {"mission_id":mission_id,"graph_id":graph.id,"nodes":data["nodes"],"edges":data["edges"]}

    def mission_receipt(self, mission_id: str) -> dict[str, Any]:
        """Build an auditable mission receipt from durable state and evidence."""
        self._require_owned_mission(mission_id)
        if self.service.event_store is None:
            raise RuntimeError("event store is unavailable")
        events = [e for e in self.service.event_store.list() if _event_mission_id(e) == mission_id]
        status = self.service.get_status(mission_id)
        evidence_ids: list[str] = []
        for event in events:
            payload = event.payload or {}
            for key in ("evidence_id", "artifact_id"):
                value = payload.get(key)
                if value and str(value) not in evidence_ids:
                    evidence_ids.append(str(value))
        duration_seconds = None
        if status.started_at is not None and status.completed_at is not None:
            duration_seconds = max(0.0, (status.completed_at - status.started_at).total_seconds())
        return {
            "mission_id": mission_id,
            "status": status.status,
            "progress": status.progress,
            "verification_state": status.verification_state,
            "objective_count": status.objective_count,
            "completed_objectives": status.completed_objectives,
            "failed_objectives": status.failed_objectives,
            "started_at": status.started_at.isoformat() if status.started_at else None,
            "completed_at": status.completed_at.isoformat() if status.completed_at else None,
            "duration_seconds": duration_seconds,
            "event_count": len(events),
            "evidence_ids": evidence_ids,
            "latest_error": status.latest_error,
            "verified_completion": status.status == "completed" and status.verification_state in {"completed", "passed"},
        }

    def missions(self) -> list[dict[str, Any]]:
        if self.service.events is None or self.service.event_store is None:
            raise RuntimeError("service not started")
        account_id = self._active_account_id
        cache = self._mission_read_cache.setdefault(account_id, {})
        store = self.service.event_store
        latest = getattr(store, "latest_sequence", lambda: len(self.service.events.history()))()
        previous = self._mission_read_cache_sequence.get(account_id)

        def project_submission(mission_id: str) -> dict[str, Any]:
            submission = self.submission(mission_id)
            state = str(submission.get("state") or "starting")
            # A submission can survive a Core restart before its execution thread
            # exists again. While the authoritative Emergency Stop is engaged,
            # never present such a durable submission as active/runnable.
            if self._emergency_stop.is_set() and state in {"starting", "running", "resuming"}:
                state = "stopped"
            return {
                "id": mission_id,
                "status": state,
                "progress": 0.0,
                "objective_count": 0,
                "completed_objectives": 0,
                "failed_objectives": 1 if state == "failed" else 0,
                "queued_objectives": 0,
                "active_objectives": 0,
                "verification_state": "failed" if state == "failed" else "idle",
                "current_activity": None,
                "started_at": None,
                "completed_at": None,
                "last_event_at": None,
                "latest_error": submission.get("error"),
                "result": submission.get("result"),
                "objectives": [],
                "metadata": {"goal": submission.get("goal")},
            }

        started_ids = {
            str(event.payload.get("mission_id") or event.aggregate_id)
            for event in self.service.events.history("MissionStarted")
            if (event.payload.get("mission_id") or event.aggregate_id)
            and self._mission_account_id(str(event.payload.get("mission_id") or event.aggregate_id)) == account_id
        }
        submission_ids = {
            str(event.payload.get("mission_id") or event.aggregate_id)
            for event in self.service.events.history("MissionSubmissionAccepted")
            if (event.payload.get("mission_id") or event.aggregate_id)
            and str(event.payload.get("account_id") or "") == account_id
        }

        if previous is None:
            mission_ids = started_ids | submission_ids
            reader = LiveStatusReader(store)
            for mission_id in mission_ids:
                cache[mission_id] = _mission_to_dict(reader.mission(mission_id)) if mission_id in started_ids else project_submission(mission_id)
        elif latest > previous:
            changed: set[str] = set()
            for event in store.list_after_sequence(previous):
                mission_id = event.payload.get("mission_id") or (event.aggregate_id if event.aggregate_type in {"mission", "mission_submission"} else None)
                if mission_id:
                    changed.add(str(mission_id))
            reader = LiveStatusReader(store)
            for mission_id in changed:
                if self._mission_account_id(mission_id) == account_id:
                    cache[mission_id] = _mission_to_dict(reader.mission(mission_id)) if mission_id in started_ids else project_submission(mission_id)
        self._mission_read_cache_sequence[account_id] = latest
        return [cache[mid] for mid in sorted(cache)]

    def events(
        self,
        mission_id: str | None = None,
        *,
        limit: int = _DEFAULT_EVENT_LIMIT,
        after_sequence: int | None = None,
        offset: int = 0,
        recent: bool = False,
    ) -> list[dict[str, Any]]:
        if self.service.events is None:
            raise RuntimeError("service not started")
        if not isinstance(limit, int) or isinstance(limit, bool):
            raise ValueError("limit must be an integer")
        if limit < 1 or limit > _MAX_EVENT_LIMIT:
            raise ValueError(f"limit must be between 1 and {_MAX_EVENT_LIMIT}")
        if not isinstance(offset, int) or isinstance(offset, bool) or offset < 0:
            raise ValueError("offset must be a non-negative integer")
        if after_sequence is not None and (
            not isinstance(after_sequence, int) or isinstance(after_sequence, bool) or after_sequence < 0
        ):
            raise ValueError("after_sequence must be a non-negative integer")
        store = self.service.event_store
        if store is None:
            raise RuntimeError("event store is unavailable")
        if recent and mission_id is None and after_sequence is None:
            recent_getter = getattr(store, "list_recent", None)
            events = list(recent_getter(limit) if callable(recent_getter) else self._account_visible_events()[-limit:])
            events = [
                event for event in events
                if (event.payload or {}).get("account_id") in {None, self._active_account_id}
            ]
        else:
            events = self._account_visible_events()
        if mission_id is not None:
            self._require_owned_mission(mission_id)
            events = [e for e in events if _event_mission_id(e) == mission_id]
        if after_sequence is not None:
            events = [
                event
                for event in events
                if (store.sequence(event.id) or 0) > after_sequence
            ]
            events = events[:limit]
        else:
            events = events[offset : offset + limit]
        return [
            _event_to_dict(event, sequence=store.sequence(event.id))
            for event in events
        ]

    def submit_mission(self, goal: str, *, max_replans: int = 8, idempotency_key: str | None = None) -> str:
        if not isinstance(goal, str):
            raise ValueError("goal must be a string")
        if isinstance(max_replans, bool) or not isinstance(max_replans, int):
            raise ValueError("max_replans must be an integer")
        if max_replans < 0:
            raise ValueError("max_replans must be non-negative")
        goal = goal.strip()
        if not goal:
            raise ValueError("goal is required")
        if idempotency_key is not None:
            idempotency_key = str(idempotency_key).strip()
            if not idempotency_key or len(idempotency_key) > 256:
                raise ValueError("Idempotency-Key must be 1-256 characters")
            if self.service.events is not None:
                for event in self.service.events.history("MissionSubmissionAccepted"):
                    payload = event.payload or {}
                    if (payload.get("account_id") == self._active_account_id
                            and payload.get("idempotency_key") == idempotency_key):
                        return str(payload.get("mission_id") or event.aggregate_id)
        execution_error = self.service.mission_execution_error
        if execution_error is not None:
            raise RuntimeError(execution_error)

        mission_id = new_id("mission")
        # Give the intelligence layer an explicit initial execution classification.
        # This is planning metadata only; execution remains gated by the mission runtime.
        intelligence_item = WorkItem(
            id=mission_id,
            objective=goal,
            estimated_actions=1,
            requires_isolation=False,
            can_parallelize=True,
        )
        _, execution_choice = self._intelligence.schedule((intelligence_item,), set(), user_active=True)
        submission = {
            "mission_id": mission_id,
            "goal": goal,
            "state": "starting",
            "account_id": self._active_account_id,
            "idempotency_key": idempotency_key,
            "execution_mode": execution_choice.mode.value,
            "execution_width": execution_choice.width,
            "execution_reason": execution_choice.reason,
            "host_control_allowed": False,
        }
        with self._lock:
            self._missions[mission_id] = submission
        self._entitlements.consume(self._active_account_id, "missions")
        if self.service.events is not None:
            self.service.events.publish(Event(
                type="MissionSubmissionAccepted", aggregate_type="mission_submission", aggregate_id=mission_id,
                payload=dict(submission), source="lumo_api",
            ))
        account_id = self._active_account_id
        thread = threading.Thread(
            target=self._run_mission,
            args=(mission_id, goal, max_replans, account_id),
            name=f"lumo-api-mission-{mission_id}",
            daemon=True,
        )
        with self._lock:
            self._mission_threads[mission_id] = thread
        thread.start()
        return mission_id

    def mission_policy(self, mission_id: str) -> dict[str, Any]:
        self._require_owned_mission(mission_id)
        policy = self._mission_features.get_policy(mission_id) or MissionPolicy()
        return {"mission_id": mission_id, "priority": policy.priority, "deadline": policy.deadline.isoformat() if policy.deadline else None, "budget": dict(policy.budget), "sla_seconds": policy.sla_seconds, "mode": policy.mode.value, "checkpoint_interval": policy.checkpoint_interval, "privacy": policy.privacy, "device_affinity": list(policy.device_affinity), "world_requirements": dict(policy.world_requirements), "model_requirements": dict(policy.model_requirements), "max_retries": policy.max_retries}

    def set_mission_policy(self, mission_id: str, body: dict[str, Any]) -> dict[str, Any]:
        self._require_owned_mission(mission_id)
        if not isinstance(body, dict): raise ValueError("policy must be an object")
        from datetime import datetime
        deadline = body.get("deadline")
        policy = MissionPolicy(priority=int(body.get("priority", 0)), deadline=datetime.fromisoformat(deadline) if deadline else None, budget=dict(body.get("budget") or {}), sla_seconds=body.get("sla_seconds"), mode=MissionMode(str(body.get("mode", "normal"))), checkpoint_interval=body.get("checkpoint_interval"), privacy=str(body.get("privacy", "standard")), device_affinity=tuple(body.get("device_affinity") or ()), world_requirements=dict(body.get("world_requirements") or {}), model_requirements=dict(body.get("model_requirements") or {}), max_retries=int(body.get("max_retries", 0)))
        self._mission_features.set_policy(mission_id, policy)
        return self.mission_policy(mission_id)

    def mission_checkpoint(self, mission_id: str) -> dict[str, Any]:
        self._require_owned_mission(mission_id)
        submission = self.submission(mission_id)
        policy = self._mission_features.get_policy(mission_id)
        sequence = len(self.service.events.history()) if self.service.events is not None else 0
        checkpoint = MissionCheckpoint.create(mission_id, sequence, {"submission": submission, "policy": self.mission_policy(mission_id) if policy else {}})
        self._mission_features.save_checkpoint(checkpoint)
        return {"mission_id": mission_id, "sequence": checkpoint.sequence, "state_hash": checkpoint.state_hash}

    def mission_branch(self, mission_id: str) -> dict[str, Any]:
        self._require_owned_mission(mission_id)
        checkpoint = self._mission_features.latest_checkpoint(mission_id) or MissionCheckpoint.create(mission_id, 0, {"submission": self.submission(mission_id)})
        branch = self._mission_features.branch(mission_id, checkpoint)
        return {"branch_id": branch.branch_id, "source_mission_id": branch.source_mission_id, "source_checkpoint_sequence": branch.source_checkpoint_sequence}

    def mission_simulate(self, mission_id: str) -> dict[str, Any]:
        self._require_owned_mission(mission_id)
        submission = self.submission(mission_id)
        goal = str(submission.get("goal") or mission_id)
        baseline = deterministic_simulation(goal, steps=1)
        alternative = deterministic_simulation(goal, steps=2)
        comparison = counterfactual(baseline, alternative)
        return {
            **baseline,
            "counterfactual": {
                "changed": comparison.changed,
                "baseline": comparison.baseline,
                "alternative": comparison.alternative,
            },
        }

    def retry_mission(self, mission_id: str) -> dict[str, Any]:
        self._require_owned_mission(mission_id)
        submission = self.submission(mission_id)
        if submission.get("state") not in {"failed", "cancelled", "stopped"}:
            raise ValueError("only failed, cancelled, or stopped missions can be retried")
        goal = str(submission.get("goal") or "").strip()
        if not goal:
            raise ValueError("mission has no retryable goal")
        retry_id = self.submit_mission(goal, max_replans=8, idempotency_key=None)
        with self._lock:
            self._missions[retry_id]["retry_of"] = mission_id
        if self.service.events is not None:
            self.service.events.publish(Event(
                type="MissionRetryRequested", aggregate_type="mission_submission", aggregate_id=retry_id,
                correlation_id=mission_id, payload={"mission_id": retry_id, "retry_of": mission_id, "account_id": self._active_account_id}, source="lumo_api",
            ))
        return self.submission(retry_id)

    def cancel_mission(self, mission_id: str) -> dict[str, Any]:
        """Durably request mission cancellation and stop future execution."""
        self._require_owned_mission(mission_id)
        with self._lock:
            submission = self._missions.get(mission_id)
            if submission is not None and submission.get("state") in {"completed", "failed", "cancelled", "stopped"}:
                return dict(submission)
            self._mission_cancelled.add(mission_id)
            if submission is not None:
                submission.update(state="cancellation_requested", message="Mission cancellation requested")
        if self.service.events is not None:
            self.service.events.publish(Event(
                type="MissionCancellationRequested", aggregate_type="mission", aggregate_id=mission_id,
                correlation_id=mission_id,
                payload={"mission_id": mission_id, "account_id": self._active_account_id}, source="lumo_api",
            ))
        return self.submission(mission_id)

    def _mission_cancel_requested(self, mission_id: str) -> bool:
        with self._lock:
            if mission_id in self._mission_cancelled:
                return True
        if self.service.events is None:
            return False
        return any(
            event.type == "MissionCancellationRequested"
            and (event.aggregate_id == mission_id or event.payload.get("mission_id") == mission_id)
            for event in self.service.events.history()
        )

    @staticmethod
    def _is_action_intent(goal: str) -> bool:
        """Distinguish work requests from ordinary conversation without pretending every utterance is a mission."""
        text = goal.lower().strip()
        action_markers = (
            "build ", "create ", "make ", "write ", "draft ", "design ", "research ",
            "find ", "search ", "analyze ", "analyse ", "compare ", "summarize ",
            "summarise ", "calculate ", "solve ", "plan ", "organize ", "organise ",
            "book ", "schedule ", "send ", "email ", "download ", "upload ",
            "edit ", "debug ", "code ", "fix ", "install ", "configure ",
            "open ", "launch ", "run ", "execute ", "automate ", "set up ",
            "prepare ", "generate ", "produce ", "implement ", "review ",
            "check this", "look into ", "figure out ", "take care of ",
        )
        return any(text.startswith(marker) or f" {marker.strip()} " in f" {text} " for marker in action_markers)

    @staticmethod
    def _is_small_talk(goal: str) -> bool:
        text = re.sub(r"[^a-z0-9!? ]+", "", goal.lower()).strip()
        return text in {
            "hi", "hello", "hey", "yo", "hiya", "good morning", "good afternoon",
            "good evening", "how are you", "how are you?", "whats up", "what's up",
            "what are you doing", "who are you",
        }

    @staticmethod
    def _needs_web_search(goal: str) -> bool:
        text = goal.lower().strip()
        freshness = ("latest", "current", "today", "recent", "right now", "as of ", "news", "what happened")
        lookup = ("who is ", "what is ", "what do you know about ", "tell me about ", "when did ", "where is ")
        return any(token in text for token in freshness) or any(text.startswith(token) for token in lookup)

    @staticmethod
    def _identity_acknowledgement(goal: str) -> str | None:
        """Handle simple user self-identification without asking a tiny local model to resolve identity."""
        text = goal.strip()
        match = re.match(r"^(?:i am|i'm|im)\s+(?:the\s+)?(.+?)[.!?]?$", text, re.I)
        if not match:
            return None
        identity = re.sub(r"\s+", " ", match.group(1)).strip(" .!?")
        if not identity or len(identity) > 120:
            return None
        return f"Got it — you’re {identity}. I’ll keep that context in this conversation."

    def _chat_reply(self, goal: str, history: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        """Use LUMO's admitted local intelligence for conversation, never a fake mission acknowledgement."""
        identity_ack = self._identity_acknowledgement(goal)
        if identity_ack:
            return {"reply": identity_ack, "sources": []}

        if self._is_small_talk(goal):
            text = goal.lower().strip()
            if text in {"who are you"}:
                return {"reply": "I’m LUMO. I can think with you, answer questions, research when freshness matters, and take real work off your hands.", "sources": []}
            if "how are you" in text or "what are you doing" in text or "what's up" in text or "whats up" in text:
                return {"reply": "I’m here and ready. What are you thinking about?", "sources": []}
            return {"reply": "Hey. I’m LUMO. What’s on your mind?", "sources": []}

        bootstrap = self._bootstrap_intelligence.status()
        # Chat is deliberately less restrictive than autonomous execution. The
        # 0.6B bootstrap model is the safe conversational fallback; a failed or
        # not-yet-run health probe must not make ordinary chat appear broken.
        if not bootstrap.installed:
            return {"reply": "I’m here, but my local conversation model is not installed yet.", "sources": []}
        if not bootstrap.fits_now:
            return {"reply": "I’m here. Your Mac is under memory pressure, so I’m keeping local AI unloaded until there is enough safe headroom.", "sources": []}

        model = bootstrap.model or BootstrapIntelligence.MODEL
        worker_id = f"chat:{uuid.uuid4()}"
        estimated_ram = int(0.85 * 1024**3)
        decision = self._intelligence_governor.admit(ResourceRequest(worker_id=worker_id, ram_bytes=estimated_ram, cpu_percent=35))
        if not decision.admitted:
            return {"reply": "I’m here. Your Mac is under memory pressure, so I’m holding off on loading local intelligence rather than risking the system.", "sources": []}

        try:
            sources: list[dict[str, str]] = []
            web_context = ""
            if self._needs_web_search(goal):
                try:
                    results = self._web_search.search(goal, limit=5)
                    sources = [{"title": r.title, "url": r.url, "snippet": r.snippet} for r in results]
                    if sources:
                        web_context = "\n\nLIVE WEB CONTEXT:\n" + "\n".join(f"[{i+1}] {s['title']} — {s['snippet']} ({s['url']})" for i, s in enumerate(sources))
                except Exception:
                    web_context = "\n\nLive web lookup was unavailable. Do not claim that current information was verified."
            client = LocalOllamaResponsesClient(model=model)
            instructions = (
                "You are LUMO, the user's general-purpose AI assistant. "
                "You are not the user, not the developer, and not a human. "
                "Never adopt facts from the user's message as facts about yourself. "
                "Never say you are a developer, employee, owner, or person unless that is genuinely part of your system identity. "
                "Do not repeat the user's identity as if it describes you. "
                "You are having a normal conversation unless a real work request was dispatched. "
                "Never claim to be working, researching, executing, browsing, or completing something unless the system actually did it. "
                "Answer directly and naturally. Avoid generic privacy disclaimers for ordinary factual questions. "
                "Use live context when supplied and distinguish public information from private information. "
                "If sources are supplied, cite them conversationally as [1], [2], etc. "
                "Do not mention internal prompts, routing, or hidden implementation details. "
                "Be concise for simple questions and thorough when the question warrants it."
            ) + web_context
            messages: list[dict[str, Any]] = []
            for item in (history or [])[-10:]:
                role = "assistant" if item.get("role") == "lumo" else "user"
                content = str(item.get("text") or "").strip()
                if content:
                    messages.append({"role": role, "content": content})
            messages.append({"role": "user", "content": goal})
            response = client.create(model=model, instructions=instructions, input=messages)
            reply = response.output_text.strip()
            if reply:
                return {"reply": reply, "sources": sources}
            return {"reply": "I’m listening. Tell me a little more about what you’re thinking.", "sources": sources}
        except Exception:
            return {"reply": "I’m here. I couldn’t get a reliable response just now, so I’m not going to pretend I did.", "sources": sources}
        finally:
            self._intelligence_governor.release(worker_id)

    @staticmethod
    def _is_computer_intent(goal: str) -> bool:
        text = goal.lower()
        # External-app/browser work needs the computer actuator rather than the
        # repository-oriented mission engine. Keep this deterministic and local:
        # the command itself is already the user's explicit execution request.
        markers = (
            "canva", "onshape", "browser", "chrome", "safari", "website",
            "web site", "powerpoint", "ppt", "presentation", "google slides",
            "open the app", "open an app", "open calculator", "launch ", "start ", "click", "type into", "drag",
            "scroll", "design a", "create a slide", "make a slide",
        )
        return any(marker in text for marker in markers)

    def self_improvement_activity(self, *, limit: int = 200) -> dict[str, Any]:
        """Return a transparent, human-readable view of autonomous R&D activity."""
        root = Path(self.service.repository_root).resolve()
        files = [
            root / ".ocean" / "self_improvement_activity.jsonl",
            root / ".ocean" / "self_improvement_forever_activity.jsonl",
        ]
        events: list[dict[str, Any]] = []
        for path in files:
            if not path.is_file():
                continue
            try:
                lines = path.read_text(encoding="utf-8").splitlines()[-max(1, limit):]
            except OSError:
                continue
            for line in lines:
                try:
                    events.append(json.loads(line))
                except (ValueError, TypeError):
                    continue
        events.sort(key=lambda item: float(item.get("timestamp", 0)))
        forever_state = {}
        state_path = root / ".ocean" / "self_improvement_forever.json"
        if state_path.is_file():
            try:
                forever_state = json.loads(state_path.read_text(encoding="utf-8"))
            except (OSError, ValueError, TypeError):
                forever_state = {"state_error": "unreadable"}
        return {
            "transparent": True,
            "events": events[-max(1, limit):],
            "forever_state": forever_state,
            "activity_files": [str(path.relative_to(root)) for path in files if path.is_file()],
        }

    def submit_improvement(self, objective: str, *, test_timeout: float = 120.0) -> str:
        """Queue one bounded self-improvement run in the service process.

        The long-lived service owns the model provider and its credentials;
        callers receive only the durable improvement run identifier.
        """
        if not isinstance(objective, str) or not objective.strip():
            raise ValueError("objective is required")
        if isinstance(test_timeout, bool) or not isinstance(test_timeout, (int, float)) or test_timeout <= 0:
            raise ValueError("test_timeout must be greater than 0")
        if self.service._runtime is None:
            raise RuntimeError(self.service.mission_execution_error or "self-improvement runtime unavailable")

        run_id = new_id("improvement_run")
        candidate_id = new_id("improvement")
        task = {
            "run_id": run_id,
            "candidate_id": candidate_id,
            "objective": objective.strip(),
            "account_id": self._active_account_id,
            "state": "starting",
            "error": None,
            "result": None,
        }
        with self._lock:
            self._improvement_tasks[run_id] = task
        if self.service.events is not None:
            self.service.events.publish(Event(
                type="ImprovementSubmissionAccepted",
                aggregate_type="improvement_run",
                aggregate_id=run_id,
                payload={"run_id": run_id, "candidate_id": candidate_id, "account_id": self._active_account_id, "objective": objective.strip()},
                source="lumo_api",
            ))

        def worker() -> None:
            with self._lock:
                current = self._improvement_tasks.get(run_id)
                if current is not None:
                    current["state"] = "running"
            try:
                result = self.service.run_improvement(
                    objective.strip(),
                    run_id=run_id,
                    candidate_id=candidate_id,
                    test_timeout_seconds=float(test_timeout),
                )
                with self._lock:
                    current = self._improvement_tasks.get(run_id)
                    if current is not None:
                        current.update(
                            state=result.status,
                            result={
                                "status": result.status,
                                "candidate_tests_passed": result.candidate_tests_passed,
                                "promoted_plan_revision_id": result.promoted_plan_revision_id,
                                "workspace_root": result.workspace_root,
                                "error": result.error,
                                "metadata": dict(result.metadata),
                            },
                            error=result.error,
                        )
                if self.service.events is not None:
                    self.service.events.publish(Event(
                        type="ImprovementSubmissionCompleted",
                        aggregate_type="improvement_run",
                        aggregate_id=run_id,
                        payload={"run_id": run_id, "status": result.status, "error": result.error},
                        source="lumo_api",
                    ))
            except Exception as exc:
                with self._lock:
                    current = self._improvement_tasks.get(run_id)
                    if current is not None:
                        current.update(state="failed", error=str(exc))
                if self.service.events is not None:
                    self.service.events.publish(Event(
                        type="ImprovementSubmissionFailed",
                        aggregate_type="improvement_run",
                        aggregate_id=run_id,
                        payload={"run_id": run_id, "error": str(exc)},
                        source="lumo_api",
                    ))

        threading.Thread(target=worker, name=f"lumo-improve-{run_id}", daemon=True).start()
        return run_id

    def _require_owned_improvement(self, run_id: str) -> None:
        with self._lock:
            task = self._improvement_tasks.get(run_id)
            if task is not None:
                if task.get("account_id") != self._active_account_id:
                    raise KeyError(run_id)
                return
        if self.service.events is None:
            raise KeyError(run_id)
        for event in self.service.events.history():
            if event.type == "ImprovementSubmissionAccepted" and event.aggregate_id == run_id:
                if str(event.payload.get("account_id") or "") != self._active_account_id:
                    raise KeyError(run_id)
                return
        raise KeyError(run_id)

    def improvement(self, run_id: str) -> dict[str, Any]:
        if not run_id:
            raise ValueError("run_id is required")
        self._require_owned_improvement(run_id)
        with self._lock:
            task = self._improvement_tasks.get(run_id)
            if task is not None:
                if task.get("account_id") != self._active_account_id:
                    raise KeyError(run_id)
                return dict(task)
        runtime = self.service._runtime
        if runtime is None:
            raise KeyError(run_id)
        run = runtime.runs.get(run_id)
        if run is None:
            raise KeyError(run_id)
        return {
            "run_id": run.id,
            "candidate_id": run.candidate_id,
            "state": run.status.value,
            "error": None,
            "result": {
                "status": run.status.value,
                "promoted_plan_revision_id": run.promoted_plan_revision_id,
                "evaluation": (
                    {
                        "passed": run.evaluation.passed,
                        "score": run.evaluation.score,
                        "evidence": list(run.evaluation.evidence),
                        "metrics": dict(run.evaluation.metrics),
                        "reason": run.evaluation.reason,
                    }
                    if run.evaluation is not None else None
                ),
                "metadata": dict(run.metadata),
            },
        }

    def submit_intent(self, goal: str, mission_id: str | None = None, chat_history: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        """Route a natural-language command, optionally continuing an existing mission thread."""
        if not isinstance(goal, str) or not goal.strip():
            raise ValueError("goal is required")
        goal = goal.strip()

        # Conversation is always available. A stopped LUMO can still talk; the stop only
        # prevents autonomous execution. This is the key distinction between an assistant
        # and a task dispatcher.
        continuation_words = {"continue", "keep going", "go ahead", "do it", "yes", "yep", "proceed", "carry on"}
        conversational = not self._is_action_intent(goal) and not self._is_computer_intent(goal)
        if conversational and (mission_id is None or goal.lower().strip() not in continuation_words):
            chat = self._chat_reply(goal, chat_history)
            return {"kind": "chat", "state": "answered", "reply": chat.get("reply", ""), "sources": chat.get("sources", [])}

        if self._emergency_stop.is_set():
            raise RuntimeError("LUMO emergency stop is engaged; release it before starting work")

        if mission_id:
            mission_id = str(mission_id).strip()
            if not mission_id:
                raise ValueError("mission_id must not be empty")
            self._require_owned_mission(mission_id)
            continuation_id = new_id("continuation")
            account_id = self._active_account_id
            if self.service.events is not None:
                self.service.events.publish(Event(
                    type="MissionContinuationRequested",
                    aggregate_type="mission",
                    aggregate_id=mission_id,
                    payload={
                        "mission_id": mission_id,
                        "continuation_id": continuation_id,
                        "goal": goal,
                        "account_id": account_id,
                    },
                    source="lumo_api",
                ))
            with self._lock:
                submission = self._missions.get(mission_id)
                if submission is not None:
                    submission["state"] = "continuation_requested"
                    submission["latest_goal"] = goal
                active = self._mission_threads.get(mission_id)
                if active is None or not active.is_alive():
                    thread = threading.Thread(
                        target=self._run_mission,
                        args=(mission_id, goal, 8, account_id),
                        name=f"lumo-api-mission-continuation-{mission_id}",
                        daemon=True,
                    )
                    self._mission_threads[mission_id] = thread
                    thread.start()
            return {
                "kind": "mission",
                "mission_id": mission_id,
                "continuation_id": continuation_id,
                "state": "continuing",
            }

        if self._is_computer_intent(goal):
            task_id = self.submit_computer(
                goal, max_steps=120, allow_actions=True, model="auto"
            )
            return {"kind": "computer", "task_id": task_id, "state": "starting"}
        mission_id = self.submit_mission(goal)
        return {"kind": "mission", "mission_id": mission_id, "state": "starting"}

    def _estimate_computer_actions(self, objective: str, max_steps: int) -> int:
        text = objective.lower().strip()
        # Explicitly bounded semantic interactions are Cursor work. Complex
        # browser/editor/build requests remain conservatively isolated.
        simple_markers = (
            "click ", "press ", "select ", "focus ", "set ", "rename ",
            "close ", "dismiss ", "toggle ", "check ", "uncheck ",
        )
        complex_markers = (
            "build ", "create a website", "make a website", "edit a video",
            "presentation", "powerpoint", "canva", "download", "upload",
            "install ", "configure ", "code ", "debug ", "research ",
            "multiple ", "several ", "then ", "and then ",
        )
        if any(marker in text for marker in complex_markers):
            return max(40, min(max_steps, 120))
        if any(text.startswith(marker) for marker in simple_markers):
            return min(max_steps, 6)
        return min(max_steps, 12)

    def _run_cursor_task(self, task_id: str, objective: str, account_id: str) -> None:
        """Execute a bounded semantic UI action without host mouse/keyboard control."""
        try:
            bridge = os.getenv("LUMO_AX_BRIDGE", "").strip()
            if not bridge:
                raise RuntimeError("LUMO_AX_BRIDGE is not configured")
            lower = objective.strip()
            app_match = re.search(r"\bin\s+([A-Za-z0-9 ._-]+?)\s*$", lower, re.IGNORECASE)
            application = app_match.group(1).strip() if app_match else ""
            command = lower[:app_match.start()].strip() if app_match else lower
            if not application:
                probe = subprocess.run([bridge, "frontmost"], capture_output=True, text=True, check=False, timeout=5)
                if probe.returncode != 0 or not probe.stdout.strip():
                    raise RuntimeError("could not determine target application")
                application = probe.stdout.strip()
            click_match = re.match(r"(?:click|press|select|focus|toggle|check|uncheck|dismiss|close)\s+(.+)$", command, re.IGNORECASE)
            set_match = re.match(r"set\s+(.+?)\s+to\s+(.+)$", command, re.IGNORECASE)
            if not click_match and not set_match:
                raise RuntimeError("objective is not a bounded semantic Cursor action")
            surface = MacOSAccessibilitySurface(application, bridge)
            cursor = LumoCursor(CursorContext(
                cursor_id=f"cursor:{task_id}",
                surface="macos.ax",
                application=application,
                user_owned_surface=True,
            ))
            adapter = VirtualCursorAdapter(surface)
            if set_match:
                target_text, new_value = set_match.groups()
                target = f"AXTextField|{target_text.strip().strip(chr(34))}||"
                plan = validate_cursor_plan((
                    CursorAction(CursorActionType.SET_VALUE, target=target, value=new_value),
                ))
            else:
                target_text = click_match.group(1).strip().strip('"')
                target = f"AXButton|{target_text}||"
                plan = validate_cursor_plan((
                    CursorAction(CursorActionType.CLICK, target=target),
                ))
            results = cursor.execute_plan(adapter, plan)
            verified, verification_detail = cursor.verify_plan(adapter, plan, results)
            if not verified:
                detail = next((result.detail for result in results if not result.executed), verification_detail)
                raise RuntimeError(detail)
            cursor.success()
            with self._lock:
                self._computer_tasks[task_id].update(
                    state="completed", phase="verified", progress=1.0,
                    steps=1, message=f"Cursor completed in {application}",
                    cursor_id=cursor.context.cursor_id,
                    cursor_application=application,
                    cursor_detail="; ".join(result.detail for result in results),
                )
            self._workers.transition(f"worker:{task_id}", WorkerState.SUCCEEDED)
        except Exception as exc:
            with self._lock:
                self._computer_tasks[task_id].update(
                    state="failed", phase="cursor_blocked", message=str(exc),
                    progress=0.0,
                )
            self._workers.transition(f"worker:{task_id}", WorkerState.FAILED)

    def _desktop_world(self):
        with self._desktop_world_lock:
            if self._desktop_world_id:
                try:
                    world = self._worlds.get(self._desktop_world_id)
                    if world.status.value != "destroyed" and str(world.account_id or "") == self._active_account_id:
                        return world
                except KeyError:
                    pass
            for world in self._worlds.list():
                if world.kind == "desktop" and world.status.value not in {"destroyed", "failed"} and str(world.account_id or "") == self._active_account_id:
                    self._desktop_world_id = world.id
                    return world
            requirements = WorldRequirements(capabilities=("desktop", "computer"), network=True, persistent=True)
            world = self._worlds.create(kind="desktop", account_id=self._active_account_id, requirements=requirements, metadata={"role": "computer-control"})
            self._desktop_world_id = world.id
            return world

    def submit_computer(self, objective: str, *, max_steps: int = 80, allow_actions: bool = False, model: str = "auto", idempotency_key: str | None = None) -> str:
        if not isinstance(objective, str) or not objective.strip():
            raise ValueError("objective is required")
        if isinstance(max_steps, bool) or not isinstance(max_steps, int) or max_steps < 1 or max_steps > _COMPUTER_MAX_STEPS:
            raise ValueError(f"max_steps must be between 1 and {_COMPUTER_MAX_STEPS}")
        if not isinstance(allow_actions, bool):
            raise ValueError("allow_actions must be a boolean")
        if not isinstance(model, str) or not model.strip():
            raise ValueError("model is required")
        if idempotency_key is not None and (not isinstance(idempotency_key, str) or not idempotency_key.strip()):
            raise ValueError("idempotency_key must be a non-empty string when supplied")
        fingerprint = self._computer_idempotency.fingerprint("submit_computer", {"account_id": self._active_account_id, "objective": objective.strip(), "max_steps": max_steps, "allow_actions": allow_actions, "model": model.strip()}) if idempotency_key else None
        if idempotency_key and self.service.events is not None:
            for event in reversed(self.service.events.history("ComputerTaskSubmitted")):
                if event.payload.get("account_id") == self._active_account_id and event.payload.get("idempotency_key") == idempotency_key:
                    if event.payload.get("fingerprint") != fingerprint:
                        raise RuntimeError("idempotency key reused with different operation")
                    return str(event.payload["task_id"])
        if idempotency_key and fingerprint:
            existing = self._computer_idempotency.get(idempotency_key, fingerprint)
            if existing is not None:
                return str(existing)
        task_id = new_id("computer")
        # Computer work is classified before any actuator is allocated.
        # Small bounded interaction stays in the user's application context via
        # a virtual Cursor; large/isolated work is the only path that creates a
        # desktop World.
        intelligence_item = WorkItem(
            id=task_id,
            objective=objective.strip(),
            estimated_actions=self._estimate_computer_actions(objective, max_steps),
            requires_isolation=False,
            can_parallelize=False,
        )
        _, execution_choice = self._intelligence.schedule((intelligence_item,), set(), user_active=True)
        worker = WorkerHandle(
            worker_id=f"worker:{task_id}",
            mission_id=task_id,
            mode=execution_choice.mode.value,
            metadata={
                "reason": execution_choice.reason,
                "host_control_allowed": execution_choice.host_control_allowed,
                "interruption_free": True,
            },
        )
        self._workers.register(worker)
        with self._lock:
            self._computer_tasks[task_id] = {
                "task_id": task_id, "objective": objective.strip(), "state": "starting",
                "account_id": self._active_account_id,
                "steps": 0, "message": "Computer task queued", "phase": "queued", "progress": 0.0, "last_screenshot": None,
                "execution_mode": execution_choice.mode.value,
                "execution_width": execution_choice.width,
                "execution_reason": execution_choice.reason,
                "host_control_allowed": execution_choice.host_control_allowed,
            }
        if self._emergency_stop.is_set():
            with self._lock:
                self._computer_tasks[task_id].update(state="stopped", phase="emergency_stop", message="Emergency stop engaged")
            return task_id
        self._entitlements.consume(self._active_account_id, "computer_tasks")
        if execution_choice.mode in {ExecutionMode.CURSOR, ExecutionMode.CURSOR_SWARM}:
            self._workers.transition(f"worker:{task_id}", WorkerState.RUNNING)
            with self._lock:
                self._computer_tasks[task_id].update(
                    state="running",
                    phase="cursor",
                    message="LUMO Cursor is working without taking over the physical device",
                )
            thread = threading.Thread(
                target=self._run_cursor_task,
                args=(task_id, objective.strip(), self._active_account_id),
                name=f"lumo-cursor-{task_id}",
                daemon=True,
            )
            thread.start()
            return task_id
        try:
            world = self._desktop_world()
        except Exception as exc:
            with self._lock:
                self._computer_tasks[task_id].update(
                    state="waiting", phase="waiting_for_world",
                    message=f"Waiting for isolated LUMO World: {exc}",
                    world_error=str(exc),
                )
            return task_id
        self._workers.transition(f"worker:{task_id}", WorkerState.RUNNING, world_id=world.id)
        with self._lock:
            self._computer_tasks[task_id]["world_id"] = world.id
            self._computer_tasks[task_id]["world"] = {"id": world.id, "kind": world.kind, "status": world.status.value}
        if self.service.events is not None:
            self.service.events.publish(Event(type="ComputerTaskSubmitted", aggregate_type="computer_task", aggregate_id=task_id, payload={"task_id": task_id, "account_id": self._active_account_id, "objective": objective.strip(), "max_steps": max_steps, "allow_actions": allow_actions, "model": model.strip(), "idempotency_key": idempotency_key, "fingerprint": fingerprint}, source="lumo_api"))
        if idempotency_key and fingerprint:
            self._computer_idempotency.commit(idempotency_key, fingerprint, task_id)
        thread = threading.Thread(
            target=self._run_computer,
            args=(task_id, objective.strip(), max_steps, allow_actions, model.strip(), world.id, self._active_account_id),
            name=f"lumo-computer-{task_id}", daemon=True,
        )
        thread.start()
        return task_id

    def _run_computer(self, task_id: str, objective: str, max_steps: int, allow_actions: bool, model: str, world_id: str, account_id: str) -> None:
        power_lease = None
        lease_acquired = False
        worker_lease = None
        try:
            with self._lock:
                if task_id in self._computer_cancelled or self._emergency_stop.is_set():
                    self._computer_tasks[task_id].update(state="stopped", phase="emergency_stop", message="Emergency stop engaged")
                    return
            from ocean.computer_agent import ComputerUseAgent
            worker_id = f"computer-worker:{threading.get_ident()}"
            worker_lease = self._worker_leases.acquire(task_id, worker_id, 120.0, lease_id=new_id("lease"))
            if self.service.events is not None:
                self.service.events.publish(Event(type="ComputerWorkerLeaseAcquired", aggregate_type="computer_task", aggregate_id=task_id, payload={"task_id": task_id, "account_id": account_id, "lease_id": worker_lease.lease_id, "worker_id": worker_lease.worker_id, "expires_at": worker_lease.expires_at.isoformat()}, source="lumo_api"))
            power_lease = self.service.power.acquire(task_id, account_id=account_id, owner_type="computer_task", owner_id=task_id)
            lease_acquired = self._computer_lease.acquire(timeout=5.0)
            if not lease_acquired:
                with self._lock:
                    self._computer_tasks[task_id].update(state="queued", phase="queued", message="Waiting for the shared computer resource")
                self._computer_lease.acquire()
                lease_acquired = True
            with self._lock:
                if task_id in self._computer_cancelled or self._emergency_stop.is_set():
                    self._computer_tasks[task_id].update(state="stopped", phase="emergency_stop", message="Emergency stop engaged")
                    return
                self._computer_tasks[task_id]["state"] = "running"
                self._computer_tasks[task_id]["message"] = "Inspecting the computer"
            self._workers.transition(f"worker:{task_id}", WorkerState.RUNNING)
            if self.service.events is not None:
                self.service.events.publish(Event(
                    type="ComputerTaskStarted", aggregate_type="computer_task", aggregate_id=task_id,
                    payload={"task_id": task_id, "account_id": account_id, "objective": objective, "max_steps": max_steps, "allow_actions": allow_actions, "model": model},
                    source="computer_agent",
                ))
            def record_step(info: dict[str, Any]) -> None:
                if self.service.events is not None:
                    self.service.events.publish(Event(
                        type="ComputerActionExecuted",
                        aggregate_type="computer_task",
                        aggregate_id=task_id,
                        payload={"task_id": task_id, "account_id": account_id, **info},
                        source="computer_agent",
                    ))
                with self._lock:
                    task = self._computer_tasks[task_id]
                    task["steps"] = int(info.get("step", 0))
                    task["message"] = f"{info.get('operation', 'action')} executed"
                    task["phase"] = "verifying"
                    task["progress"] = max(float(task.get("progress", 0.0)), min(0.96, int(info.get("step", 0)) / max(max_steps, 1)))
            def record_checkpoint(info: dict[str, Any]) -> None:
                if worker_lease is not None:
                    self._worker_leases.heartbeat(worker_lease.lease_id, worker_lease.worker_id, 120.0)
                with self._lock:
                    task = self._computer_tasks[task_id]
                    task["checkpoint"] = info
                    task["checkpoint_at"] = info.get("created_at")
                if self.service.events is not None:
                    self.service.events.publish(Event(
                        type="ComputerTaskCheckpointed", aggregate_type="computer_task", aggregate_id=task_id,
                        payload={"task_id": task_id, "account_id": account_id, "checkpoint": info}, source="computer_agent",
                    ))

            def record_status(info: dict[str, Any]) -> None:
                with self._lock:
                    task = self._computer_tasks[task_id]
                    task["phase"] = info.get("phase", "working")
                    task["message"] = info.get("message", "Working")
                    task["progress"] = float(info.get("progress", task.get("progress", 0.0)))
                    if info.get("reasoning_effort"):
                        task["reasoning_effort"] = info["reasoning_effort"]
                    if info.get("cognition_mode"):
                        task["cognition_mode"] = info["cognition_mode"]
                    if info.get("world"):
                        task["world"] = info["world"]
                if self.service.events is not None:
                    self.service.events.publish(Event(
                        type="ComputerTaskStatusUpdated", aggregate_type="computer_task", aggregate_id=task_id,
                        payload={"task_id": task_id, "account_id": self._task_account(task_id), **info}, source="computer_agent",
                    ))

            world = self._worlds.get(world_id)
            if world.kind != "desktop":
                raise RuntimeError(f"computer task requires a desktop World, got {world.kind!r}")
            guard = lambda: not (self._emergency_stop.is_set() or task_id in self._computer_cancelled)
            agent = ComputerUseAgent(
                model=model,
                max_steps=max_steps,
                allow_actions=allow_actions,
                world_manager=self._worlds,
                world_id=world.id,
                account_id=world.account_id,
                on_step=record_step,
                on_status=record_status,
                execution_guard=guard,
                execution_pause=lambda: task_id in self._computer_paused,
                on_checkpoint=record_checkpoint,
            )
            result = agent.run(objective, mission_id=task_id)
            with self._lock:
                was_cancelled = task_id in self._computer_cancelled
                if not was_cancelled:
                    self._computer_tasks[task_id].update(
                        state=result.status, steps=result.steps, message=result.message,
                        last_screenshot=result.last_screenshot,
                    )
            if was_cancelled:
                self._workers.transition(f"worker:{task_id}", WorkerState.CANCELLED)
            elif result.status == "completed":
                self._workers.transition(f"worker:{task_id}", WorkerState.SUCCEEDED)
            else:
                self._workers.transition(f"worker:{task_id}", WorkerState.FAILED, result=result.status)
            # Cancellation is a terminal control-plane decision. Never publish a
            # later agent result that can replay over the durable cancellation.
            if self.service.events is not None and not was_cancelled:
                self.service.events.publish(Event(
                    type="ComputerTaskCompleted" if result.status == "completed" else "ComputerTaskFinished",
                    aggregate_type="computer_task", aggregate_id=task_id,
                    payload={"task_id": task_id, "status": result.status, "steps": result.steps, "message": result.message, "last_screenshot": result.last_screenshot},
                    source="computer_agent",
                ))
        except Exception as exc:
            self._workers.transition(f"worker:{task_id}", WorkerState.FAILED, error=str(exc))
            with self._lock:
                self._computer_tasks[task_id].update(state="failed", message=str(exc))
            if self.service.events is not None:
                self.service.events.publish(Event(
                    type="ComputerTaskFailed", aggregate_type="computer_task", aggregate_id=task_id,
                    payload={"task_id": task_id, "account_id": self._task_account(task_id), "error": str(exc)}, source="computer_agent",
                ))
        finally:
            if lease_acquired:
                self._computer_lease.release()
            if worker_lease is not None:
                try:
                    self._worker_leases.release(worker_lease.lease_id, worker_lease.worker_id)
                finally:
                    if self.service.events is not None:
                        self.service.events.publish(Event(type="ComputerWorkerLeaseReleased", aggregate_type="computer_task", aggregate_id=task_id, payload={"task_id": task_id, "account_id": account_id, "lease_id": worker_lease.lease_id}, source="lumo_api"))
            if power_lease is not None:
                self.service.power.release(power_lease)
            with self._lock:
                if task_id in self._computer_cancelled and task_id in self._computer_tasks:
                    task = self._computer_tasks[task_id]
                    if task.get("phase") != "cancelled":
                        task.update(state="stopped", phase="emergency_stop", message="Emergency stop engaged")

    def pause_computer(self, task_id: str) -> dict[str, Any]:
        """Cooperatively pause a computer agent between actions."""
        self._require_owned_computer_task(task_id)
        with self._lock:
            task = self._computer_tasks.get(task_id)
            if task is None:
                raise KeyError(task_id)
            if task.get("state") in {"completed", "failed", "stopped", "cancelled"}:
                raise RuntimeError("terminal computer task cannot be paused")
            self._computer_paused.add(task_id)
            task.update(state="paused", phase="paused", message="Computer task paused by user")
        if self.service.events is not None:
            self.service.events.publish(Event(type="ComputerTaskPaused", aggregate_type="computer_task", aggregate_id=task_id, payload={"task_id": task_id, "account_id": self._task_account(task_id)}, source="lumo_api"))
        return dict(self._computer_tasks[task_id])

    def resume_computer(self, task_id: str) -> dict[str, Any]:
        """Resume a paused computer agent without replaying prior actions."""
        self._require_owned_computer_task(task_id)
        with self._lock:
            task = self._computer_tasks.get(task_id)
            if task is None:
                raise KeyError(task_id)
            if task_id not in self._computer_paused:
                return dict(task)
            self._computer_paused.discard(task_id)
            task.update(state="running", phase="resuming", message="Computer task resumed")
        if self.service.events is not None:
            self.service.events.publish(Event(type="ComputerTaskResumed", aggregate_type="computer_task", aggregate_id=task_id, payload={"task_id": task_id, "account_id": self._task_account(task_id)}, source="lumo_api"))
        return dict(self._computer_tasks[task_id])

    def takeover_computer(self, task_id: str) -> dict[str, Any]:
        """Freeze autonomous actions and mark the task ready for manual takeover."""
        self._require_owned_computer_task(task_id)
        with self._lock:
            task = self._computer_tasks.get(task_id)
            if task is None:
                raise KeyError(task_id)
            self._computer_paused.add(task_id)
            task.update(state="paused", phase="human_takeover", message="Autonomous control frozen; human takeover active")
        if self.service.events is not None:
            self.service.events.publish(Event(type="ComputerHumanTakeover", aggregate_type="computer_task", aggregate_id=task_id, payload={"task_id": task_id, "account_id": self._task_account(task_id)}, source="lumo_api"))
        return dict(self._computer_tasks[task_id])

    def cancel_computer(self, task_id: str) -> dict[str, Any]:
        """Cancel one computer task and immediately tear down its World."""
        self._require_owned_computer_task(task_id)
        with self._lock:
            task = self._computer_tasks.get(task_id)
            if task is None:
                raise KeyError(task_id)
            self._computer_cancelled.add(task_id)
            task.update(state="stopped", phase="cancelled", message="Computer task cancelled", progress=0.0)
            world_id = task.get("world_id")
        if world_id:
            try:
                self._worlds.force_destroy(str(world_id), reason="computer_task_cancelled")
            except Exception:
                pass
        if self.service.events is not None:
            self.service.events.publish(Event(
                type="ComputerTaskCancelled", aggregate_type="computer_task", aggregate_id=task_id,
                payload={"task_id": task_id, "world_id": world_id}, source="lumo_api",
            ))
        return self.computer_task(task_id)

    def computer_screenshot(self, task_id: str) -> str:
        task = self.computer_task(task_id)
        path = task.get("last_screenshot")
        if not path:
            raise FileNotFoundError("no screenshot captured yet")
        return str(path)

    def _task_account(self, task_id: str) -> str | None:
        with self._lock:
            task = self._computer_tasks.get(task_id)
            if task is not None:
                return str(task.get("account_id") or "") or None
        return None

    def _require_owned_computer_task(self, task_id: str) -> None:
        with self._lock:
            task = self._computer_tasks.get(task_id)
            if task is not None:
                if task.get("account_id") != self._active_account_id:
                    raise KeyError(task_id)
                return
        for event in self.service.events.history() if self.service.events is not None else ():
            if event.type == "ComputerTaskStarted" and (event.aggregate_id == task_id or event.payload.get("task_id") == task_id):
                if str(event.payload.get("account_id") or "") != self._active_account_id:
                    raise KeyError(task_id)
                return
        raise KeyError(task_id)

    def computer_tasks(self) -> list[dict[str, Any]]:
        """Return the live computer-task read model for the active account.

        This is deliberately sourced from the control-plane task registry, not
        from a bounded event-tape window. A long-running task must never vanish
        from the UI merely because its Started event scrolled out of the recent
        events page.
        """
        with self._lock:
            task_ids = [
                task_id for task_id, task in self._computer_tasks.items()
                if task.get("account_id") == self._active_account_id
            ]
        return [self.computer_task(task_id) for task_id in task_ids]

    def computer_task(self, task_id: str) -> dict[str, Any]:
        self._require_owned_computer_task(task_id)
        with self._lock:
            task = self._computer_tasks.get(task_id)
            if task is not None:
                return dict(task)
        # Rebuild the read model from durable events after process restart.
        if self.service.events is None:
            raise RuntimeError("service not started")
        rebuilt = self._rebuild_computer_task(task_id)
        if rebuilt is None:
            raise KeyError(task_id)
        with self._lock:
            self._computer_tasks[task_id] = dict(rebuilt)
        return rebuilt

    def _rebuild_computer_task(self, task_id: str) -> dict[str, Any] | None:
        task: dict[str, Any] | None = None
        for event in self.service.events.history():
            if event.aggregate_id != task_id and event.payload.get("task_id") != task_id:
                continue
            payload = dict(event.payload)
            if event.type == "ComputerTaskStarted":
                task = {
                    "task_id": task_id,
                    "account_id": payload.get("account_id"),
                    "objective": payload.get("objective", ""),
                    "state": "running",
                    "steps": 0,
                    "message": "Inspecting the computer",
                    "phase": "observing",
                    "progress": 0.02,
                    "last_screenshot": None,
                    "max_steps": payload.get("max_steps"),
                    "allow_actions": payload.get("allow_actions", False),
                    "model": payload.get("model"),
                }
            elif task is not None and event.type == "ComputerActionExecuted":
                task["steps"] = max(int(task.get("steps", 0)), int(payload.get("step", 0)))
                task["message"] = f"{payload.get('operation', 'action')} executed"
                task["phase"] = "verifying"
                task["progress"] = max(float(task.get("progress", 0.0)), min(0.96, task["steps"] / max(int(task.get("max_steps") or 1), 1)))
                result = payload.get("result") or {}
                if isinstance(result, dict) and result.get("path"):
                    task["last_screenshot"] = result["path"]
            elif task is not None and event.type == "ComputerTaskStatusUpdated":
                task["phase"] = payload.get("phase", task.get("phase", "working"))
                task["message"] = payload.get("message", task.get("message", "Working"))
                task["progress"] = float(payload.get("progress", task.get("progress", 0.0)))
            elif task is not None and event.type in {"ComputerTaskCompleted", "ComputerTaskFinished"}:
                task.update(
                    state=payload.get("status", "finished"),
                    steps=int(payload.get("steps", task.get("steps", 0))),
                    message=payload.get("message", "Computer task finished"),
                    last_screenshot=payload.get("last_screenshot") or task.get("last_screenshot"),
                )
            elif task is not None and event.type == "ComputerTaskCancelled":
                task.update(
                    state="stopped",
                    phase="cancelled",
                    message="Computer task cancelled",
                    progress=0.0,
                )
            elif task is not None and event.type == "ComputerTaskCheckpointed":
                checkpoint = payload.get("checkpoint")
                if isinstance(checkpoint, dict):
                    task["checkpoint"] = checkpoint
                    task["checkpoint_at"] = checkpoint.get("created_at")
                    task["phase"] = "checkpointed" if task.get("state") == "running" else task.get("phase", "working")
            elif task is not None and event.type == "ComputerTaskFailed" and task.get("phase") != "cancelled":
                task.update(state="failed", message=payload.get("error", "Computer task failed"))
        return task

    def _run_mission(self, mission_id: str, goal: str, max_replans: int, account_id: str) -> None:
        power_lease = None
        current_goal = goal
        active_continuation_id: str | None = None
        try:
            power_lease = self.service.power.acquire(mission_id)
            while True:
                with self._lock:
                    self._missions[mission_id]["state"] = "running"
                    self._missions[mission_id]["latest_goal"] = current_goal
                result = self.service.run_mission(
                    current_goal, mission_id=mission_id, max_replans=max_replans,
                    account_id=account_id,
                    cancelled=lambda: self._mission_cancel_requested(mission_id),
                )
                result_payload = asdict(result)
                with self._lock:
                    self._missions[mission_id].update(state=result.status, result=result_payload)
                if active_continuation_id and self.service.events is not None:
                    self.service.events.publish(Event(
                        type="MissionContinuationApplied",
                        aggregate_type="mission",
                        aggregate_id=mission_id,
                        payload={
                            "mission_id": mission_id,
                            "continuation_id": active_continuation_id,
                            "account_id": account_id,
                            "status": result.status,
                        },
                        source="lumo_api",
                    ))
                    active_continuation_id = None

                # A follow-up is an event-sourced continuation, not a new mission.
                # Drain exactly one unconsumed request at a time so rapid user edits
                # remain ordered and the same mission id survives the whole thread.
                continuation = None
                if self.service.events is not None:
                    history = self.service.events.history()
                    requests = [
                        event for event in history
                        if event.type == "MissionContinuationRequested"
                        and event.aggregate_id == mission_id
                        and (event.payload or {}).get("account_id") == account_id
                    ]
                    applied = {
                        (event.payload or {}).get("continuation_id")
                        for event in history
                        if event.type == "MissionContinuationApplied"
                        and event.aggregate_id == mission_id
                    }
                    continuation = next(
                        (event for event in requests
                         if (event.payload or {}).get("continuation_id") not in applied),
                        None,
                    )
                if continuation is None:
                    if self.service.events is not None:
                        self.service.events.publish(Event(
                            type="MissionSubmissionCompleted",
                            aggregate_type="mission_submission",
                            aggregate_id=mission_id,
                            payload={
                                "mission_id": mission_id,
                                "account_id": account_id,
                                "state": result.status,
                                "result": result_payload,
                            },
                            source="lumo_api",
                        ))
                    break

                continuation_payload = continuation.payload or {}
                continuation_id = str(continuation_payload.get("continuation_id") or "")
                next_goal = str(continuation_payload.get("goal") or "").strip()
                if not next_goal:
                    if self.service.events is not None:
                        self.service.events.publish(Event(
                            type="MissionContinuationApplied",
                            aggregate_type="mission",
                            aggregate_id=mission_id,
                            payload={
                                "mission_id": mission_id,
                                "continuation_id": continuation_id,
                                "account_id": account_id,
                                "status": "ignored",
                                "reason": "empty continuation goal",
                            },
                            source="lumo_api",
                        ))
                    continue

                if self.service.events is not None:
                    self.service.events.publish(Event(
                        type="MissionContinuationStarted",
                        aggregate_type="mission",
                        aggregate_id=mission_id,
                        payload={
                            "mission_id": mission_id,
                            "continuation_id": continuation_id,
                            "account_id": account_id,
                            "goal": next_goal,
                        },
                        source="lumo_api",
                    ))
                current_goal = next_goal
                active_continuation_id = continuation_id
        except Exception as exc:
            with self._lock:
                self._missions[mission_id].update(state="failed", error=str(exc))
            if self.service.events is not None:
                self.service.events.publish(Event(
                    type="MissionSubmissionFailed", aggregate_type="mission_submission", aggregate_id=mission_id,
                    payload={"mission_id": mission_id, "account_id": account_id, "error": str(exc)}, source="lumo_api",
                ))
        finally:
            if power_lease is not None:
                self.service.power.release(power_lease)
            with self._lock:
                self._mission_threads.pop(mission_id, None)

    def submission(self, mission_id: str) -> dict[str, Any]:
        if not mission_id:
            raise ValueError("mission_id is required")
        with self._lock:
            submission = self._missions.get(mission_id)
            if submission is not None:
                return dict(submission)
        if self.service.events is None:
            raise RuntimeError("service not started")
        rebuilt: dict[str, Any] | None = None
        for event in self.service.events.history():
            if event.aggregate_id != mission_id and event.payload.get("mission_id") != mission_id:
                continue
            if event.type == "MissionSubmissionAccepted":
                rebuilt = dict(event.payload)
            elif event.type == "MissionCancellationRequested":
                rebuilt = {**(rebuilt or {"mission_id": mission_id}), "state": "cancellation_requested", "message": "Mission cancellation requested"}
            elif event.type == "MissionSubmissionCompleted":
                rebuilt = {**(rebuilt or {"mission_id": mission_id}), "state": str(event.payload.get("state") or "completed"), "result": event.payload.get("result")}
            elif event.type == "MissionSubmissionFailed":
                rebuilt = {**(rebuilt or {"mission_id": mission_id}), "state": "failed", "error": event.payload.get("error")}
        if rebuilt is None:
            raise KeyError(mission_id)
        with self._lock:
            self._missions[mission_id] = dict(rebuilt)
        return rebuilt


def _event_mission_id(event) -> str | None:
    if event.aggregate_type == "mission":
        return event.payload.get("mission_id") or event.aggregate_id
    return event.payload.get("mission_id")


def _event_to_dict(event, *, sequence: int | None = None) -> dict[str, Any]:
    return {
        "id": event.id,
        "type": event.type,
        "at": event.at.isoformat(),
        "sequence": event.sequence if sequence is None else sequence,
        "aggregate_type": event.aggregate_type,
        "aggregate_id": event.aggregate_id,
        "payload": dict(event.payload),
        "correlation_id": event.correlation_id,
        "causation_id": event.causation_id,
        "source": event.source,
    }


def _objective_to_dict(objective) -> dict[str, Any]:
    return {
        "id": objective.objective_id,
        "objective": objective.objective,
        "status": objective.status,
        "progress": objective.progress,
        "started_at": objective.started_at.isoformat() if objective.started_at else None,
        "completed_at": objective.completed_at.isoformat() if objective.completed_at else None,
        "error": objective.error,
        "activity": objective.current_activity,
        "metadata": dict(objective.metadata),
    }


def _mission_to_dict(status) -> dict[str, Any]:
    return {
        "id": status.mission_id,
        "status": status.status,
        "progress": status.progress,
        "objective_count": status.objective_count,
        "completed_objectives": status.completed_objectives,
        "failed_objectives": status.failed_objectives,
        "queued_objectives": status.queued_objectives,
        "active_objectives": status.active_objectives,
        "verification_state": status.verification_state,
        "current_activity": status.current_activity,
        "started_at": status.started_at.isoformat() if status.started_at else None,
        "completed_at": status.completed_at.isoformat() if status.completed_at else None,
        "last_event_at": status.last_event_at.isoformat() if status.last_event_at else None,
        "latest_error": status.latest_error,
        "objectives": [_objective_to_dict(o) for o in status.objective_statuses],
        "metadata": dict(status.metadata),
    }


class _RequestBodyTooLarge(ValueError):
    """Raised before reading an HTTP body that exceeds the control-plane cap."""


def _redact_error(error: object) -> str:
    """Return a client-safe error without exposing local filesystem paths."""
    text = str(error)
    text = _ERROR_PATH_RE.sub("[local-path]", text)
    text = re.sub(r"[A-Za-z]:\\[^\s\"\']+", "[local-path]", text)
    return text[:1000]


class _Handler(BaseHTTPRequestHandler):
    server_version = "LUMO/1.1.1"

    @property
    def api(self) -> LumoAPI:
        return self.server.lumo_api  # type: ignore[attr-defined]

    def _redact_error(self, error: object) -> str:
        return _redact_error(error)

    def _require_safe_host(self) -> None:
        """Reject Host headers that do not address this loopback control plane."""
        raw = self.headers.get("Host")
        if not raw:
            raise PermissionError("missing Host header")
        try:
            if "@" in raw:
                raise ValueError("Host header must not contain userinfo")
            hostname = raw
            if hostname.startswith("["):
                hostname = hostname[1:].split("]", 1)[0]
            elif ":" in hostname:
                hostname = hostname.rsplit(":", 1)[0]
            hostname = hostname.strip().lower().rstrip(".")
            if hostname == "localhost":
                return
            if ipaddress.ip_address(hostname).is_loopback:
                return
        except ValueError:
            pass
        raise PermissionError("untrusted Host header")

    def _require_api_auth(self, path: str) -> None:
        if os.getenv("LUMO_API_AUTH_REQUIRED", "0") != "1":
            return
        if path in {"/api/health", "/api/readiness", "/api/session", "/api/auth/signup", "/api/auth/login", "/api/auth/verify-email", "/api/auth/password-reset/request", "/api/auth/password-reset/complete", "/api/auth/local"}:
            return
        session=self.api._api_auth.authenticate(self.headers.get("Authorization"))
        # The current local API has one active account context per process. A
        # bearer token for another tenant must never be able to act against that
        # process-wide context. A future multi-tenant gateway should instead pass
        # the authenticated account as request-scoped context.
        if session.account_id != self.api._active_account_id:
            raise PermissionError("authenticated account does not match active account")
        self._authenticated_session=session
        if self.command in {"POST","PUT","PATCH","DELETE"} and path not in {"/api/session"}:
            nonce=self.headers.get("X-LUMO-CSRF-Nonce", "")
            token=self.headers.get("X-LUMO-CSRF", "")
            if not nonce or not self.api._api_auth.verify_csrf(session.session_id,self.command,path,nonce,token):
                raise PermissionError("invalid CSRF token")

    def _read_body(self, *, max_bytes: int = _API_MAX_BODY_BYTES) -> bytes:
        """Read a bounded HTTP body without trusting a malicious Content-Length."""
        raw_length = self.headers.get("Content-Length")
        if raw_length is None:
            length = 0
        else:
            try:
                length = int(raw_length)
            except (TypeError, ValueError) as exc:
                raise ValueError("invalid Content-Length") from exc
            if length < 0:
                raise ValueError("invalid Content-Length")
        if length > max_bytes:
            raise _RequestBodyTooLarge("request body exceeds safety limit")
        return self.rfile.read(length)

    def _require_safe_origin(self) -> None:
        """Reject browser-originated state changes from untrusted sites.

        The control plane is intentionally local-only, but localhost is still
        reachable by arbitrary web pages. A missing Origin is allowed for
        native/local clients; an explicit browser Origin must be one of LUMO's
        trusted UI origins so a simple POST cannot act as a CSRF actuator.
        """
        origin = self.headers.get("Origin")
        if origin is not None and origin not in _ALLOWED_ORIGINS:
            raise PermissionError("untrusted browser origin")

    def _send(self, status: int, body: Any, *, request_id: str | None = None) -> None:
        request_id = request_id or getattr(self, "_request_id", None) or str(uuid.uuid4())
        data = json.dumps(body, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Request-ID", request_id or str(uuid.uuid4()))
        if status != 204:
            self.send_header("Content-Length", str(len(data)))
        origin = self.headers.get("Origin")
        if origin in _ALLOWED_ORIGINS:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type, Idempotency-Key, X-Request-ID, X-LUMO-CSRF-Nonce, X-LUMO-CSRF")
        self.send_header("Access-Control-Max-Age", "600")
        self.end_headers()
        if status != 204:
            self.wfile.write(data)

    def do_OPTIONS(self) -> None:  # noqa: N802
        try:
            self._require_safe_origin()
            self._send(204, {})
        except PermissionError as exc:
            self._send(403, {"error": self._redact_error(exc), "error_code": "FORBIDDEN"})

    def _send_event_stream(self, events: list[dict[str, Any]], *, content_type: str = "application/x-ndjson") -> None:
        chunks=[]
        if content_type == "text/event-stream":
            for event in events:
                chunks.append(f"id: {event.get('sequence') or event['id']}\ndata: {json.dumps(event,separators=(',',':'))}\n\n".encode())
        else:
            chunks=[(json.dumps(event,separators=(",",":"))+"\n").encode() for event in events]
        self.send_response(200)
        self.send_header("Content-Type", content_type+"; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Transfer-Encoding", "chunked")
        self.end_headers()
        for chunk in chunks:
            self.wfile.write(f"{len(chunk):X}\r\n".encode())
            self.wfile.write(chunk)
            self.wfile.write(b"\r\n")
        self.wfile.write(b"0\r\n\r\n")

    def do_GET(self) -> None:  # noqa: N802
        self._request_id = self.headers.get("X-Request-ID") or str(uuid.uuid4())
        try:
            self._require_safe_host()
            parsed = urlparse(self.path)
            path = parsed.path.rstrip("/")
            self._require_api_auth(path)
            query = parse_qs(parsed.query)
            if path == "/api/root/recovery/export":
                if not self.api.verify_root_console_secret(self.headers.get("X-LUMO-Root-Console-Secret")):
                    raise PermissionError("Root Console authorization required")
                body=json.loads(self._read_body() or b"{}")
                self._send(200, self.api.root_recovery_export(str(body.get("password") or ""))); return
            if path == "/api/root/recovery/restore":
                if not self.api.verify_root_console_secret(self.headers.get("X-LUMO-Root-Console-Secret")):
                    raise PermissionError("Root Console authorization required")
                body=json.loads(self._read_body() or b"{}")
                self._send(200, self.api.root_recovery_restore(str(body.get("path") or ""), str(body.get("password") or ""))); return
            if path == "/api/root/operator":
                # Root telemetry is surfaced inside the authenticated LUMO console.
                # Recovery/export operations remain separately protected.
                self._send(200, self.api.root_operator())
                return
            if path == "/api/metrics":
                self._send(200, self.api.metrics())
                return
            if path == "/api/trace":
                correlation_id = query.get("correlation_id", [None])[0]
                self._send(200, {"events": self.api.trace(correlation_id or "")})
                return
            if path == "/api/openapi.json":
                self._send(200, self.api.openapi())
                return
            if path == "/api/health":
                self._send(200, self.api.health())
                return
            if path == "/api/readiness":
                self._send(200, self.api.readiness())
                return
            if path == "/api/startup":
                self._send(200, self.api.startup_state())
                return
            if path == "/api/diagnostics":
                self._send(200, self.api.diagnostics())
                return
            if path == "/api/email-status":
                self._send(200, self.api.email_status())
                return
            if path == "/api/emergency-stop":
                self._send(200, self.api.emergency_status())
                return
            if path == "/api/account":
                self._send(200, self.api.account())
                return
            if path == "/api/session/csrf":
                session = getattr(self, "_authenticated_session", None)
                if session is None:
                    raise PermissionError("authentication required")
                method = str(query.get("method", ["GET"])[0] or "GET").upper()
                target = str(query.get("path", [""])[0] or "")
                self._send(200, self.api.csrf_token(method, target, session.session_id))
                return
            if path == "/api/accounts":
                self._send(200, {"accounts": self.api.accounts()})
                return
            if path == "/api/power":
                self._send(200, self.api.power())
                return
            if path == "/api/devices":
                self._send(200, {"devices": self.api.devices()})
                return
            if path == "/api/account/adaptive":
                self._send(200, {"state": self.api.adaptive_state()})
                return
            if path == "/api/feedback":
                limit = min(100, max(1, int(query.get("limit", ["50"])[0])))
                self._send(200, self.api.feedback_snapshot(limit=limit))
                return
            if path == "/api/billing":
                self._send(200, self.api.billing())
                return
            if path == "/api/shadow":
                self._send(200, self.api.shadow_status())
                return
            if path == "/api/resource-autopilot":
                self._send(200, self.api.resource_autopilot()); return
            if path == "/api/self-improvement/activity":
                limit = min(500, max(1, int(query.get("limit", ["200"])[0])))
                self._send(200, self.api.self_improvement_activity(limit=limit)); return
            if path == "/api/setup/autopilot":
                self._send(200, self.api.setup_autopilot()); return
            if path == "/api/assistant":
                self._send(200, self.api.assistant_status())
                return
            if path == "/api/fpv":
                self._send(200, self.api.fpv())
                return
            if path == "/api/alerts":
                self._send(200, {"alerts": self.api.alerts()})
                return
            if path.startswith("/api/worlds/") and path.endswith("/screenshot"):
                world_id = path.split("/")[-2]
                screenshot = Path(self.api.world_screenshot(world_id)).resolve()
                data = screenshot.read_bytes()
                self.send_response(200); self.send_header("Content-Type", "image/png"); self.send_header("Content-Length", str(len(data))); self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(data); return
            if path == "/api/worlds":
                mission_id = query.get("mission_id", [None])[0]
                self._send(200, {"worlds": self.api.worlds(mission_id)})
                return
            if path.startswith("/api/worlds/"):
                world_id = path.rsplit("/", 1)[-1]
                self._send(200, self.api.world(world_id))
                return
            if path == "/api/events/stream":
                mission_id = query.get("mission_id", [None])[0]
                after_raw = query.get("after_sequence", [None])[0]
                after_sequence = None if after_raw is None else int(after_raw)
                events = self.api.events(mission_id, limit=_MAX_EVENT_LIMIT, after_sequence=after_sequence)
                self._send_event_stream(events)
                return
            if path == "/api/events":
                mission_id = query.get("mission_id", [None])[0]
                limit = int(query.get("limit", [_DEFAULT_EVENT_LIMIT])[0])
                after_raw = query.get("after_sequence", [None])[0]
                after_sequence = None if after_raw is None else int(after_raw)
                offset = int(query.get("offset", [0])[0])
                recent = query.get("recent", ["0"])[0].lower() in {"1", "true", "yes"}
                self._send(200, {"events": self.api.events(mission_id, limit=limit, after_sequence=after_sequence, offset=offset, recent=recent)})
                return
            if path.startswith("/api/improvements/"):
                run_id = path.rsplit("/", 1)[-1]
                self._send(200, self.api.improvement(run_id))
                return
            if path == "/api/computer/tasks":
                self._send(200, {"tasks": self.api.computer_tasks()})
                return
            if path.startswith("/api/computer/") and path.endswith("/screenshot"):
                task_id = path.split("/")[-2]
                screenshot = Path(self.api.computer_screenshot(task_id)).resolve()
                data = screenshot.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "image/png")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(data)
                return
            if path.startswith("/api/computer/"):
                task_id = path.rsplit("/", 1)[-1]
                self._send(200, self.api.computer_task(task_id))
                return
            if path == "/api/pulse":
                missions = self.api.missions()
                worlds = self.api.worlds()
                devices = self.api.devices()
                tasks = self.api.computer_tasks()
                events = self.api.events(None, limit=100, recent=True)
                readiness = self.api.readiness()
                active_types = {"running", "starting", "queued", "waiting", "resuming", "provisioning"}
                active_missions = [x for x in missions if isinstance(x.get("status"), str) and x.get("status") in active_types]
                active_worlds = [x for x in worlds if x.get("status") not in {"destroyed", "failed"}]
                active_tasks = [x for x in tasks if isinstance(x.get("state"), str) and x.get("state") in active_types]
                worker_map: dict[str, dict[str, Any]] = {}
                terminal_workers: set[str] = set()
                for event in events:
                    payload = event.get("payload") or {}
                    worker_id = str(payload.get("worker_id") or payload.get("agent_id") or "")
                    if not worker_id:
                        continue
                    if event.get("type") in {"WorkerStopped","WorkerCompleted","WorkerFailed","MissionCompleted","MissionFailed","MissionCancelled","MissionStopped"}:
                        terminal_workers.add(worker_id)
                    else:
                        worker_map[worker_id] = {"id": worker_id, "mission_id": payload.get("mission_id"), "world_id": payload.get("world_id"), "state": "active"}
                for worker_id in terminal_workers:
                    worker_map.pop(worker_id, None)
                self._send(200, {"active_missions": active_missions, "active_tasks": active_tasks, "recent_missions": list(reversed(missions[-6:])), "recent_tasks": list(reversed(tasks[-6:])), "active_worlds": active_worlds, "workers": list(worker_map.values()), "events": len(events), "devices": devices, "readiness": readiness, "resource_autopilot": self.api.resource_autopilot(), "core": {"reachable": True, "direct": True}})
                return
            if path == "/api/missions":
                self._send(200, {"missions": self.api.missions()})
                return
            if path.startswith("/api/missions/"):
                parts = path.split("/")
                mission_id = parts[3] if len(parts) > 3 else ""
                if len(parts) == 5 and parts[4] == "stream":
                    stream_events=self.api.events(mission_id, limit=_MAX_EVENT_LIMIT)
                    self._send_event_stream(stream_events, content_type="text/event-stream")
                    return
                if len(parts) == 5 and parts[4] == "graph":
                    self._send(200, self.api.mission_graph(mission_id))
                    return
                if len(parts) == 5 and parts[4] == "receipt":
                    self._send(200, self.api.mission_receipt(mission_id))
                    return
                if len(parts) == 5 and parts[4] == "policy":
                    self._send(200, self.api.mission_policy(mission_id))
                    return
                self._send(200, self.api.mission(mission_id))
                return
            if path.startswith("/api/submissions/"):
                mission_id = path.rsplit("/", 1)[-1]
                self._send(200, self.api.submission(mission_id))
                return
            self._send(404, {"error": "not found"})
        except (ValueError, KeyError) as exc:
            self._send(400 if isinstance(exc, ValueError) else 404, {"error": self._redact_error(exc.args[0] if isinstance(exc, KeyError) and exc.args else exc), "error_code": "INVALID_REQUEST" if isinstance(exc, ValueError) else "NOT_FOUND"})
        except FileNotFoundError as exc:
            self._send(404, {"error": self._redact_error(exc)})
        except PermissionError as exc:
            self._send(403, {"error": self._redact_error(exc), "error_code": "FORBIDDEN"})
        except Exception as exc:
            self._send(500, {"error": "internal server error", "error_code": "INTERNAL_ERROR"})

    def do_POST(self) -> None:  # noqa: N802
        self._request_id = self.headers.get("X-Request-ID") or str(uuid.uuid4())
        try:
            self._require_safe_origin()
            self._require_safe_host()
            client_key = self.client_address[0] if self.client_address else "unknown"
            if not self.api.allow_mutation(client_key):
                self._send(429, {"error": "mutation rate limit exceeded", "error_code": "RATE_LIMITED"})
                return
            parsed = urlparse(self.path)
            self._require_api_auth(parsed.path.rstrip("/"))
            if parsed.path.rstrip("/") == "/api/auth/signup":
                body=json.loads(self._read_body() or b"{}")
                self._send(201,self.api.signup(str(body.get("name") or ""),str(body.get("email") or ""),str(body.get("password") or ""))); return
            if parsed.path.rstrip("/") == "/api/auth/login":
                body=json.loads(self._read_body() or b"{}")
                client = self.client_address[0] if self.client_address else "unknown"
                email = str(body.get("email") or "").strip().casefold()
                self._send(200,self.api.login(email,str(body.get("password") or ""),attempt_key=f"{client}:{email}")); return
            if parsed.path.rstrip("/") == "/api/auth/local":
                client = self.client_address[0] if self.client_address else ""
                local_request = client in {"127.0.0.1", "::1", "::ffff:127.0.0.1"}
                self._send(200, self.api.local_login(local_request=local_request)); return
            if parsed.path.rstrip("/") == "/api/email/smtp":
                if not self.api.verify_root_console_secret(self.headers.get("X-LUMO-Root-Console-Secret")):
                    self._require_api_auth(parsed.path.rstrip("/"))
                body=json.loads(self._read_body() or b"{}")
                self._send(200, self.api.configure_email_smtp(
                    str(body.get("host") or ""), int(body.get("port") or 587),
                    str(body.get("tls_mode") or "starttls"), str(body.get("username") or ""),
                    str(body.get("password") or ""), str(body.get("from_address") or ""),
                )); return
            if parsed.path.rstrip("/") == "/api/email/test":
                if not self.api.verify_root_console_secret(self.headers.get("X-LUMO-Root-Console-Secret")):
                    self._require_api_auth(parsed.path.rstrip("/"))
                body=json.loads(self._read_body() or b"{}")
                self._send(200, self.api.test_email_delivery(str(body.get("recipient") or ""))); return
            if parsed.path.rstrip("/") == "/api/account/profile-picture":
                body=json.loads(self._read_body(max_bytes=3 * 1024 * 1024) or b"{}")
                self._send(200, self.api.upload_profile_picture(str(body.get("data_url") or ""))); return
            if parsed.path.rstrip("/") == "/api/auth/logout":
                authorization = self.headers.get("Authorization", "")
                if not authorization.startswith("Bearer "):
                    raise PermissionError("authentication required")
                self._send(200, self.api.logout(authorization[7:].strip())); return
            if parsed.path.rstrip("/") == "/api/auth/verify-email":
                body=json.loads(self._read_body() or b"{}")
                self._send(200,self.api.verify_account_email(str(body.get("token") or ""))); return
            if parsed.path.rstrip("/") == "/api/auth/password-reset/request":
                body=json.loads(self._read_body() or b"{}")
                self._send(200,self.api.request_password_reset(str(body.get("email") or ""))); return
            if parsed.path.rstrip("/") == "/api/auth/password-reset/complete":
                body=json.loads(self._read_body() or b"{}")
                self._send(200,self.api.complete_password_reset(str(body.get("token") or ""),str(body.get("password") or ""))); return
            if parsed.path.rstrip("/") == "/api/session":
                body=json.loads(self._read_body() or b"{}")
                self._send(200,self.api.create_session(str(body.get("account_id") or ""),body.get("bootstrap_secret"))); return
            if parsed.path.rstrip("/") == "/api/emergency-stop":
                self._send(200, self.api.emergency_stop()); return
            if parsed.path.rstrip("/") == "/api/emergency-stop/release":
                body=json.loads(self._read_body() or b"{}")
                self._send(200, self.api.release_emergency_stop(
                    safety_acknowledged=body.get("safety_acknowledged") is True
                )); return
            if parsed.path.rstrip("/") == "/api/account/delete":
                body=json.loads(self._read_body() or b"{}")
                self._send(200,self.api.delete_account(str(body.get("password") or ""),str(body.get("confirmation") or ""))); return
            if parsed.path.rstrip("/") == "/api/account/password":
                body=json.loads(self._read_body() or b"{}")
                self._send(200,self.api.change_password(str(body.get("current_password") or ""),str(body.get("new_password") or ""))); return
            if parsed.path.rstrip("/") == "/api/account/verify-email/resend":
                self._send(200,self.api.resend_email_verification()); return
            if parsed.path.rstrip("/") == "/api/account/export":
                self._send(200, self.api.export_account_data()); return
            if parsed.path.rstrip("/") == "/api/account":
                body = json.loads(self._read_body() or b"{}")
                if "name" in body or "email" in body or "profile_picture_ref" in body:
                    self._send(200, self.api.update_account_profile(name=body.get("name"), email=body.get("email"), profile_picture_ref=body.get("profile_picture_ref"))); return
                if "account_id" in body:
                    self._send(200, self.api.switch_account(body["account_id"])); return
                if "name" in body:
                    self._send(201, self.api.create_account(body["name"])); return
                raise ValueError("account_id or name is required")
            if parsed.path.rstrip("/") == "/api/devices":
                body = json.loads(self._read_body() or b"{}")
                if not isinstance(body, dict): raise ValueError("request body must be an object")
                self._send(201, self.api.register_device(body)); return
            if parsed.path.startswith("/api/devices/") and parsed.path.endswith("/heartbeat"):
                device_id = parsed.path.split("/")[-2]
                self._send(200, self.api.heartbeat_device(device_id)); return
            if parsed.path.rstrip("/") == "/api/devices/pair":
                body=json.loads(self._read_body() or b"{}")
                self._send(200, self.api.pair_device(int(body.get("ttl_seconds", 300)))); return
            if parsed.path.startswith("/api/devices/") and parsed.path.endswith("/revoke"):
                device_id = parsed.path.split("/")[-2]
                self._send(200, self.api.revoke_device(device_id)); return
            if parsed.path.rstrip("/") == "/api/account/adaptive":
                body = json.loads(self._read_body() or b"{}")
                if not isinstance(body, dict) or "key" not in body or "value" not in body:
                    raise ValueError("key and value are required")
                self._send(200, self.api.set_adaptive_state(body["key"], body["value"])); return
            if parsed.path.rstrip("/") == "/api/feedback/usage":
                body = json.loads(self._read_body() or b"{}")
                if not isinstance(body, dict): raise ValueError("request body must be an object")
                self._send(200, self.api.record_feedback_usage(float(body.get("seconds", 0)))); return
            if parsed.path.rstrip("/") == "/api/feedback":
                body = json.loads(self._read_body() or b"{}")
                if not isinstance(body, dict): raise ValueError("request body must be an object")
                self._send(201, self.api.submit_user_feedback(
                    rating=body.get("rating"),
                    text=str(body.get("text", "")),
                    usage_seconds=float(body.get("usage_seconds", 0) or 0),
                )); return
            if parsed.path.rstrip("/") == "/api/resource-autopilot":
                body = json.loads(self._read_body() or b"{}")
                if not isinstance(body, dict): raise ValueError("request body must be an object")
                mode = str(body.get("mode", "")).strip().lower()
                if mode:
                    self._send(200, self.api.set_resource_autopilot_mode(mode)); return
                names = body.get("names", [])
                if not isinstance(names, list): raise ValueError("names must be a list")
                self._send(200, self.api.approve_resource_recommendation(names, bool(body.get("reopen", False)))); return
            if parsed.path.rstrip("/") == "/api/setup/autopilot":
                body = json.loads(self._read_body() or b"{}")
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                self._send(202, self.api.start_setup_autopilot(manage_memory=bool(body.get("manage_memory", True)))); return
            if parsed.path.rstrip("/") == "/api/setup/autopilot/stop":
                self._send(200, self.api.stop_setup_autopilot()); return
            if parsed.path.rstrip("/") == "/api/setup/autopilot/permission":
                body = json.loads(self._read_body() or b"{}")
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                decision = str(body.get("decision", "")).strip().lower()
                self._send(200, self.api.setup_autopilot_permission(decision)); return
            if parsed.path.rstrip("/") == "/api/setup/autopilot/memory":
                body = json.loads(self._read_body() or b"{}")
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                decision = str(body.get("decision", "")).strip().lower()
                names = body.get("names", [])
                restart_names = body.get("restart_names", [])
                if not isinstance(names, list) or not isinstance(restart_names, list):
                    raise ValueError("names and restart_names must be arrays")
                self._send(200, self.api.setup_autopilot_memory(decision, names, restart_names)); return
            if parsed.path.rstrip("/") == "/api/memory/apps":
                body = json.loads(self._read_body() or b"{}")
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                names = body.get("names", [])
                if not isinstance(names, list) or not all(isinstance(name, str) for name in names):
                    raise ValueError("names must be an array of strings")
                self._send(200, self.api.quit_memory_apps(names)); return
            if parsed.path.rstrip("/") == "/api/billing/checkout":
                body = json.loads(self._read_body() or b"{}")
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                self._send(200, self.api.billing_checkout(str(body.get("plan_id") or ""))); return
            if parsed.path.rstrip("/") == "/api/billing/portal":
                self._send(200, self.api.billing_portal()); return
            if parsed.path.rstrip("/") == "/api/billing/webhook":
                raw = self._read_body(max_bytes=4 * _API_MAX_BODY_BYTES)
                signature = self.headers.get("X-LUMO-Billing-Signature", "")
                self._send(200, self.api.apply_billing_webhook(raw, signature)); return
            if parsed.path.rstrip("/") == "/api/assistant/dismiss":
                self._send(200, self.api.dismiss_assistant())
                return
            if parsed.path.rstrip("/") == "/api/assistant/pause":
                self._send(200, self.api.service.active_assistant.pause_observation()); return
            if parsed.path.rstrip("/") == "/api/assistant/resume":
                self._send(200, self.api.service.active_assistant.resume_observation()); return
            if parsed.path.rstrip("/") == "/api/assistant/policy":
                raw = self._read_body(); body = json.loads(raw or b"{}")
                if not isinstance(body, dict): raise ValueError("request body must be an object")
                self._send(200, self.api.service.active_assistant.set_policy(str(body.get("policy", "helpful")))); return
            if parsed.path.rstrip("/") in {"/api/shadow", "/api/assistant"}:
                raw = self._read_body()
                body = json.loads(raw or b"{}")
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                enabled = body.get("enabled", False)
                self._send(200, self.api.set_shadow(enabled) if parsed.path.rstrip("/") == "/api/shadow" else self.api.set_assistant(enabled))
                return
            if parsed.path.startswith("/api/alerts/") and parsed.path.endswith("/approve"):
                action_id = parsed.path.split("/")[-2]
                self._send(200, self.api.approve_alert(action_id))
                return
            if parsed.path.startswith("/api/alerts/") and parsed.path.endswith("/resolve"):
                action_id = parsed.path.split("/")[-2]
                self._send(200, self.api.resolve_alert(action_id))
                return
            if parsed.path.rstrip("/") == "/api/intent":
                raw = self._read_body()
                body = json.loads(raw or b"{}")
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                history = body.get("chat_history")
                if history is not None and not isinstance(history, list):
                    raise ValueError("chat_history must be a list")
                self._send(200, self.api.submit_intent(
                    body.get("goal"),
                    body.get("mission_id"),
                    history,
                ))
                return
            if parsed.path.startswith("/api/computer/") and parsed.path.endswith("/cancel"):
                task_id = parsed.path.split("/")[-2]
                self._send(200, self.api.cancel_computer(task_id))
                return
            if parsed.path.startswith("/api/computer/") and parsed.path.endswith("/pause"):
                task_id = parsed.path.split("/")[-2]
                self._send(200, self.api.pause_computer(task_id))
                return
            if parsed.path.startswith("/api/computer/") and parsed.path.endswith("/resume"):
                task_id = parsed.path.split("/")[-2]
                self._send(200, self.api.resume_computer(task_id))
                return
            if parsed.path.startswith("/api/computer/") and parsed.path.endswith("/takeover"):
                task_id = parsed.path.split("/")[-2]
                self._send(200, self.api.takeover_computer(task_id))
                return
            if parsed.path.rstrip("/") == "/api/computer":
                raw = self._read_body()
                body = json.loads(raw or b"{}")
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                task_id = self.api.submit_computer(
                    body.get("objective"),
                    max_steps=body.get("max_steps", 80),
                    allow_actions=body.get("allow_actions", False),
                    model=body.get("model", "auto"),
                    idempotency_key=body.get("idempotency_key"),
                )
                self._send(202, {"task_id": task_id, "state": "starting"})
                return
            if parsed.path.rstrip("/") == "/api/improvements":
                raw = self._read_body()
                body = json.loads(raw or b"{}")
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                run_id = self.api.submit_improvement(
                    body.get("objective"),
                    test_timeout=body.get("test_timeout", 120.0),
                )
                self._send(202, {"run_id": run_id, "state": "starting"})
                return
            if parsed.path.rstrip("/") == "/api/worlds":
                body = json.loads(self._read_body() or b"{}")
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                self._send(201, self.api.create_world(body))
                return
            if parsed.path.startswith("/api/worlds/"):
                parts = parsed.path.rstrip("/").split("/")
                if len(parts) == 5 and parts[4] in {"reset", "destroy", "snapshot"}:
                    world_id = parts[3]
                    if parts[4] == "reset":
                        result = self.api.reset_world(world_id)
                    elif parts[4] == "destroy":
                        result = self.api.destroy_world(world_id)
                    else:
                        result = self.api.snapshot_world(world_id)
                    self._send(200, result)
                    return
                if len(parts) == 5 and parts[4] == "clone":
                    body = json.loads(self._read_body() or b"{}")
                    if not isinstance(body, dict):
                        raise ValueError("request body must be an object")
                    result = self.api.clone_world(parts[3], mission_id=body.get("mission_id"))
                    self._send(201, result)
                    return
            mission_parts = parsed.path.rstrip("/").split("/")
            if len(mission_parts) == 5 and mission_parts[1] == "api" and mission_parts[2] == "missions":
                mission_id = mission_parts[3]
                action = mission_parts[4]
                if action == "policy":
                    body = json.loads(self._read_body() or b"{}")
                    self._send(200, self.api.set_mission_policy(mission_id, body)); return
                if action == "checkpoint":
                    self._send(201, self.api.mission_checkpoint(mission_id)); return
                if action == "branch":
                    self._send(201, self.api.mission_branch(mission_id)); return
                if action == "simulate":
                    self._send(200, self.api.mission_simulate(mission_id)); return
                if action == "retry":
                    self._send(201, self.api.retry_mission(mission_id)); return
            if len(mission_parts) == 5 and mission_parts[1] == "api" and mission_parts[2] == "missions" and mission_parts[4] == "cancel":
                self._send(200, self.api.cancel_mission(mission_parts[3]))
                return
            if parsed.path.rstrip("/") != "/api/missions":
                self._send(404, {"error": "not found"})
                return
            raw = self._read_body()
            body = json.loads(raw or b"{}")
            if not isinstance(body, dict):
                raise ValueError("request body must be an object")
            goal = body.get("goal")
            max_replans = body.get("max_replans", 8)
            if isinstance(max_replans, bool) or not isinstance(max_replans, int):
                raise ValueError("max_replans must be an integer")
            idempotency_key = self.headers.get("Idempotency-Key")
            mission_id = self.api.submit_mission(goal, max_replans=max_replans, idempotency_key=idempotency_key)
            self._send(202, {"mission_id": mission_id, "state": "starting"})
        except json.JSONDecodeError:
            self._send(400, {"error": "invalid JSON"})
        except PermissionError as exc:
            self._send(403, {"error": self._redact_error(exc), "error_code": "FORBIDDEN"})
        except _RequestBodyTooLarge as exc:
            self._send(413, {"error": self._redact_error(exc), "error_code": "REQUEST_TOO_LARGE"})
        except (TypeError, ValueError) as exc:
            self._send(400, {"error": self._redact_error(exc), "error_code": "INVALID_REQUEST"})
        except RuntimeError as exc:
            self._send(503, {"error": self._redact_error(exc), "error_code": "SERVICE_NOT_READY"})
        except Exception as exc:
            self._send(500, {"error": "internal server error", "error_code": "INTERNAL_ERROR"})

    def log_message(self, fmt: str, *args) -> None:
        return


class _LoopbackHTTPServer(ThreadingHTTPServer):
    """HTTP server that selects a loopback address family deterministically."""

    def __init__(self, server_address, handler):
        host = server_address[0]
        if ":" in host:
            family = socket.AF_INET6
        elif host == "localhost":
            infos = socket.getaddrinfo(host, server_address[1], socket.AF_UNSPEC, socket.SOCK_STREAM)
            loopback_infos = [info for info in infos if info[4][0] and ipaddress.ip_address(info[4][0]).is_loopback]
            if not loopback_infos:
                raise ValueError("localhost does not resolve to a loopback address")
            family = loopback_infos[0][0]
        else:
            family = socket.AF_INET
        self.address_family = family
        super().__init__(server_address, handler)


class LumoAPIServer:
    """Threaded localhost HTTP server for the LUMO control plane."""

    def __init__(self, service: OceanService, *, host: str = "127.0.0.1", port: int = 8765) -> None:
        # The control plane has no public-network authentication layer yet.
        # Refuse non-loopback binds rather than turning a convenience CLI
        # option into an unauthenticated remote actuator.
        normalized_host = host.strip().lower()
        if normalized_host != "localhost":
            try:
                if not ipaddress.ip_address(normalized_host).is_loopback:
                    raise ValueError(
                        "LUMO control plane is local-only; remote binds require an authenticated gateway"
                    )
            except ValueError as exc:
                if "local-only" in str(exc):
                    raise
                raise ValueError(
                    "LUMO control plane is local-only; remote binds require an authenticated gateway"
                ) from exc
        self.api = LumoAPI(service)
        self.server = _LoopbackHTTPServer((host, port), _Handler)
        self.server.lumo_api = self.api  # type: ignore[attr-defined]
        self.server.daemon_threads = True
        self._serving = threading.Event()
        self._shutdown_requested = threading.Event()
        self._serve_state_lock = threading.RLock()

    @property
    def address(self) -> tuple[str, int]:
        return self.server.server_address

    def serve_forever(self) -> None:
        with self._serve_state_lock:
            if self._shutdown_requested.is_set():
                return
            self._serving.set()
        try:
            self.server.serve_forever(poll_interval=0.2)
        finally:
            self._serving.clear()

    def shutdown(self) -> None:
        # ``BaseServer.shutdown()`` waits for ``serve_forever()`` to be
        # running. Make shutdown safe and idempotent even when a caller owns
        # only a constructed server (common in tests and embedded hosts).
        self._shutdown_requested.set()
        self.api.set_shadow(False)
        self.api._worlds.close()
        self.api._accounts.close()
        self.api._billing.close()
        with self._serve_state_lock:
            serving = self._serving.is_set()
        if serving:
            self.server.shutdown()
        self.server.server_close()


def _world_to_dict(world) -> dict[str, Any]:
    """Serialize a world for API consumers without leaking provider internals."""
    return {
        "id": world.id,
        "kind": world.kind,
        "mission_id": world.mission_id,
        "account_id": world.account_id,
        "status": world.status.value if hasattr(world.status, "value") else str(world.status),
        "capabilities": list(world.capabilities),
        "resources": dict(world.resources),
        "metadata": {
            key: value for key, value in dict(world.metadata).items()
            if key not in {"vnc_port", "instance_dir", "snapshot_path", "executor"}
        },
        "snapshot_id": world.snapshot_id,
        "created_at": world.created_at.isoformat() if world.created_at else None,
        "updated_at": world.updated_at.isoformat() if world.updated_at else None,
    }
