"""Transactional email delivery for LUMO account lifecycle mail.

Delivery is provider-agnostic. LUMO can deliver directly to recipient MX servers
(self-hosted/direct SMTP), or use an optional API/webhook relay as a fallback.
"""
from __future__ import annotations

import hashlib
import hmac
import html
import json
import os
import re
import smtplib
import socket
import ssl
import subprocess
import urllib.error
import urllib.request
from email.message import EmailMessage

from ocean.security import KeychainTokenStore
from ocean.production_readiness import email_delivery_preflight


class EmailDelivery:
    """Deliver account emails through LUMO direct SMTP, Resend, or webhook."""

    def __init__(self, url: str | None = None, secret: str | None = None,
                 resend_api_key: str | None = None, from_address: str | None = None,
                 account_id: str | None = None):
        self.account_id = account_id or os.getenv("LUMO_ACTIVE_ACCOUNT_ID", "").strip()
        self.url = (url or os.getenv("LUMO_EMAIL_WEBHOOK_URL", "")).strip()
        self.secret = (secret or os.getenv("LUMO_EMAIL_WEBHOOK_SECRET", "")).strip()
        self.resend_api_key = (resend_api_key or os.getenv("RESEND_API_KEY", "")).strip()
        self.from_address = (from_address or os.getenv("LUMO_EMAIL_FROM", "")).strip()
        self.public_url = os.getenv("LUMO_PUBLIC_URL", "http://localhost:3000").strip().rstrip("/")
        self.direct_enabled = os.getenv("LUMO_EMAIL_DIRECT_SMTP", "0").strip().lower() in {"1", "true", "yes", "on"}
        self.direct_host = os.getenv("LUMO_EMAIL_SMTP_HOST", "").strip()
        self.direct_port = int(os.getenv("LUMO_EMAIL_SMTP_PORT", "25") or "25")
        self.direct_helo = os.getenv("LUMO_EMAIL_HELO", socket.getfqdn()).strip()
        tls_mode = os.getenv("LUMO_EMAIL_SMTP_TLS_MODE", "").strip().lower()
        self.direct_tls = os.getenv("LUMO_EMAIL_SMTP_TLS", "1").strip().lower() not in {"0", "false", "no", "off"}
        self.direct_tls_mode = tls_mode or ("starttls" if self.direct_tls else "none")
        self.direct_username = os.getenv("LUMO_EMAIL_SMTP_USERNAME", "").strip()
        self.direct_password = os.getenv("LUMO_EMAIL_SMTP_PASSWORD", "")
        self.direct_timeout = float(os.getenv("LUMO_EMAIL_SMTP_TIMEOUT", "20") or "20")
        self.last_attempt_at: float | None = None
        self.last_success_at: float | None = None
        self.last_error: str | None = None
        self.last_template: str | None = None
        self.last_recipient_domain: str | None = None
        self._load_local_smtp_config()

    def _load_local_smtp_config(self) -> None:
        if not self.account_id:
            return
        try:
            raw = KeychainTokenStore("LUMO Email SMTP").get(self.account_id)
            if not raw:
                return
            config = json.loads(raw)
            if not isinstance(config, dict):
                return
            self.direct_enabled = bool(config.get("enabled", True))
            self.direct_host = str(config.get("host") or self.direct_host).strip()
            self.direct_port = int(config.get("port") or self.direct_port)
            self.direct_tls_mode = str(config.get("tls_mode") or self.direct_tls_mode).strip().lower()
            self.direct_tls = self.direct_tls_mode != "none"
            self.direct_username = str(config.get("username") or self.direct_username).strip()
            self.direct_password = str(config.get("password") or self.direct_password)
            self.from_address = str(config.get("from_address") or self.from_address).strip()
        except Exception:
            # A corrupt/unavailable keychain entry must never break LUMO startup.
            return

    def configure_local_smtp(self, *, host: str, port: int, tls_mode: str,
                             username: str, password: str, from_address: str) -> dict[str, object]:
        host = str(host or "").strip()
        username = str(username or "").strip()
        password = str(password or "")
        from_address = str(from_address or "").strip()
        port = int(port)
        tls_mode = str(tls_mode or "starttls").strip().lower()
        if not host or not from_address or not username or not password:
            raise ValueError("SMTP host, sender, username, and password are required")
        if port < 1 or port > 65535:
            raise ValueError("SMTP port is invalid")
        if tls_mode not in {"starttls", "ssl", "implicit_tls", "none"}:
            raise ValueError("unsupported SMTP TLS mode")
        if "@" not in from_address or "@" not in username:
            raise ValueError("SMTP sender and username must be email addresses")
        config = {"enabled": True, "host": host, "port": port, "tls_mode": tls_mode,
                  "username": username, "password": password, "from_address": from_address}
        if not self.account_id:
            raise RuntimeError("active account is required for local SMTP configuration")
        KeychainTokenStore("LUMO Email SMTP").set(self.account_id, json.dumps(config, separators=(",", ":")))
        self.direct_enabled = True
        self.direct_host = host
        self.direct_port = port
        self.direct_tls_mode = tls_mode
        self.direct_tls = tls_mode != "none"
        self.direct_username = username
        self.direct_password = password
        self.from_address = from_address
        self.last_error = None
        return self.status()

    @property
    def direct_configured(self) -> bool:
        return bool(self.direct_enabled and self.from_address and self._sender_domain())

    @property
    def resend_configured(self) -> bool:
        return bool(self.resend_api_key and self.from_address)

    @property
    def webhook_configured(self) -> bool:
        return self.url.startswith("https://") and len(self.secret) >= 16

    @property
    def configured(self) -> bool:
        return self.direct_configured or self.resend_configured or self.webhook_configured

    @property
    def provider(self) -> str:
        if self.direct_configured:
            return "direct_smtp"
        if self.resend_configured:
            return "resend"
        if self.webhook_configured:
            return "webhook"
        return "unconfigured"

    def status(self) -> dict[str, object]:
        return {
            "configured": self.configured,
            "provider": self.provider,
            "direct_smtp": {
                "configured": self.direct_configured,
                "host": self.direct_host or "auto_mx",
                "port": self.direct_port,
                "tls": self.direct_tls,
                "tls_mode": self.direct_tls_mode,
                "authenticated": bool(self.direct_username),
                "helo": self.direct_helo,
                "from": self.from_address or None,
            },
            "resend": {"configured": self.resend_configured, "from": self.from_address or None},
            "webhook": {"configured": self.webhook_configured},
            "preflight": email_delivery_preflight({
                "LUMO_EMAIL_DIRECT_SMTP": "1" if self.direct_enabled else "0",
                "LUMO_EMAIL_SMTP_HOST": self.direct_host,
                "LUMO_EMAIL_SMTP_USERNAME": self.direct_username,
                "LUMO_EMAIL_SMTP_PASSWORD": self.direct_password,
                "LUMO_EMAIL_FROM": self.from_address,
                "RESEND_API_KEY": self.resend_api_key,
                "LUMO_EMAIL_WEBHOOK_URL": self.url,
                "LUMO_EMAIL_WEBHOOK_SECRET": self.secret,
            }),
            "last_delivery": {
                "attempted_at": self.last_attempt_at,
                "succeeded_at": self.last_success_at,
                "error": self.last_error,
                "template": self.last_template,
                "recipient_domain": self.last_recipient_domain,
            },
        }

    def send(self, *, to: str, subject: str, template: str,
             variables: dict[str, str]) -> None:
        self.last_attempt_at = __import__("time").time()
        self.last_template = template
        self.last_recipient_domain = to.rsplit("@", 1)[1].strip().lower() if "@" in to else None
        self.last_error = None
        try:
            if self.direct_configured:
                self._send_direct(to=to, subject=subject, template=template, variables=variables)
            elif self.resend_configured:
                self._send_resend(to=to, subject=subject, template=template, variables=variables)
            elif self.webhook_configured:
                self._send_webhook(to=to, subject=subject, template=template, variables=variables)
            else:
                raise RuntimeError(
                    "transactional email delivery is not configured; "
                    "enable LUMO_EMAIL_DIRECT_SMTP and set LUMO_EMAIL_FROM"
                )
            self.last_success_at = __import__("time").time()
        except Exception as exc:
            self.last_error = str(exc)[:1000]
            raise

    def _sender_domain(self) -> str:
        match = re.search(r"<([^>]+)>", self.from_address)
        address = match.group(1) if match else self.from_address
        return address.rsplit("@", 1)[1].strip().lower() if "@" in address else ""

    def _sender_address(self) -> str:
        match = re.search(r"<([^>]+)>", self.from_address)
        return match.group(1).strip() if match else self.from_address.strip()

    def _mx_hosts(self, domain: str) -> list[str]:
        if self.direct_host:
            return [self.direct_host]
        try:
            proc = subprocess.run(
                ["dig", "+short", "MX", domain],
                capture_output=True, text=True, timeout=5, check=False,
            )
            records: list[tuple[int, str]] = []
            for line in proc.stdout.splitlines():
                parts = line.split()
                if len(parts) >= 2 and parts[0].isdigit():
                    records.append((int(parts[0]), parts[1].rstrip(".")))
            records.sort(key=lambda item: item[0])
            return [host for _, host in records]
        except (OSError, subprocess.SubprocessError):
            return []

    def _send_direct(self, *, to: str, subject: str, template: str,
                     variables: dict[str, str]) -> None:
        recipient_domain = to.rsplit("@", 1)[1].strip().lower() if "@" in to else ""
        if not recipient_domain:
            raise RuntimeError("invalid recipient email address")
        hosts = self._mx_hosts(recipient_domain)
        if not hosts:
            raise RuntimeError(f"no MX records found for {recipient_domain}")

        message = EmailMessage()
        message["From"] = self.from_address
        message["To"] = to
        message["Subject"] = subject
        message["Date"] = __import__("email.utils", fromlist=["formatdate"]).formatdate(localtime=True)
        message["Message-ID"] = __import__("email.utils", fromlist=["make_msgid"]).make_msgid(domain=self._sender_domain())
        message.set_content(self._render_text(template, variables))
        message.add_alternative(self._render_html(template, variables), subtype="html")

        last_error: Exception | None = None
        for host in hosts[:5]:
            try:
                smtp_cls = smtplib.SMTP_SSL if self.direct_tls_mode in {"ssl", "implicit_tls"} else smtplib.SMTP
                with smtp_cls(host, self.direct_port, local_hostname=self.direct_helo, timeout=self.direct_timeout) as smtp:
                    smtp.ehlo(self.direct_helo)
                    if self.direct_tls_mode in {"starttls", "tls"}:
                        if not smtp.has_extn("starttls"):
                            raise RuntimeError("SMTP server does not support STARTTLS")
                        smtp.starttls(context=ssl.create_default_context())
                        smtp.ehlo(self.direct_helo)
                    if self.direct_username:
                        if not self.direct_password:
                            raise RuntimeError("SMTP username is configured but SMTP password is missing")
                        smtp.login(self.direct_username, self.direct_password)
                    smtp.send_message(message, from_addr=self._sender_address(), to_addrs=[to])
                return
            except (OSError, smtplib.SMTPException) as exc:
                last_error = exc
        raise RuntimeError(f"direct SMTP delivery failed for {recipient_domain}: {last_error}")

    def _send_resend(self, *, to: str, subject: str, template: str,
                     variables: dict[str, str]) -> None:
        body = json.dumps({
            "from": self.from_address,
            "to": [to],
            "subject": subject,
            "html": self._render_html(template, variables),
            "text": self._render_text(template, variables),
        }, separators=(",", ":")).encode()
        request = urllib.request.Request(
            "https://api.resend.com/emails", data=body, method="POST",
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {self.resend_api_key}"},
        )
        try:
            with urllib.request.urlopen(request, timeout=15) as response:
                if response.status < 200 or response.status >= 300:
                    raise RuntimeError(f"Resend returned HTTP {response.status}")
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", "replace")[:500]
            raise RuntimeError(f"Resend rejected the email (HTTP {exc.code}): {detail}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"could not reach Resend: {exc.reason}") from exc

    def _send_webhook(self, *, to: str, subject: str, template: str,
                      variables: dict[str, str]) -> None:
        body = json.dumps({"to": to, "subject": subject, "template": template, "variables": variables}, separators=(",", ":")).encode()
        signature = hmac.new(self.secret.encode(), body, hashlib.sha256).hexdigest()
        request = urllib.request.Request(self.url, data=body, method="POST", headers={"Content-Type": "application/json", "X-LUMO-Signature": signature})
        try:
            with urllib.request.urlopen(request, timeout=10) as response:
                if response.status < 200 or response.status >= 300:
                    raise RuntimeError(f"transactional email webhook returned HTTP {response.status}")
        except urllib.error.HTTPError as exc:
            raise RuntimeError(f"transactional email webhook failed (HTTP {exc.code})") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"could not reach transactional email webhook: {exc.reason}") from exc

    def _render_text(self, template: str, variables: dict[str, str]) -> str:
        token = variables.get("token", "")
        if template == "verify-email":
            return f"Verify your LUMO account:\n\n{self.public_url}/verify-email?token={token}\n\nIf you did not create this account, you can ignore this email."
        if template == "password-reset":
            return f"Reset your LUMO password:\n\n{self.public_url}/reset-password?token={token}\n\nIf you did not request this, you can ignore this email."
        return "You have a new notification from LUMO."

    def _render_html(self, template: str, variables: dict[str, str]) -> str:
        token = html.escape(variables.get("token", ""), quote=True)
        if template == "verify-email":
            title, intro, label, path = "Verify your LUMO account", "Confirm your email address to finish setting up LUMO.", "Verify email", "/verify-email?token=" + token
        elif template == "password-reset":
            title, intro, label, path = "Reset your LUMO password", "Use the button below to choose a new password.", "Reset password", "/reset-password?token=" + token
        else:
            title, intro, label, path = "LUMO notification", "You have a new notification from LUMO.", "Open LUMO", ""
        href = html.escape(self.public_url + path, quote=True)
        return ('<!doctype html><html><body style="margin:0;background:#f5f5f7;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;color:#171717;">'
                '<div style="max-width:560px;margin:48px auto;padding:32px;background:#fff;border-radius:20px;">'
                f'<h1 style="margin:0 0 12px;font-size:28px;">{html.escape(title)}</h1>'
                f'<p style="font-size:16px;line-height:1.6;">{html.escape(intro)}</p>'
                f'<p><a href="{href}" style="display:inline-block;padding:12px 18px;background:#111;color:#fff;text-decoration:none;border-radius:10px;">{html.escape(label)}</a></p>'
                '<p style="font-size:13px;color:#777;line-height:1.5;">If you did not request this email, you can safely ignore it.</p>'
                '</div></body></html>')
