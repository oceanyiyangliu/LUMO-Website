"""Hard local-model admission policy for every LUMO local provider.

The policy fails closed when model size cannot be verified. Device-specific
limits can be supplied by the runtime; the artifact ceiling is 64 GiB.
"""
from __future__ import annotations

import json
import math
import os
import urllib.request
import time
from dataclasses import dataclass
from typing import Any, Mapping

from ocean.resources.intelligence_governor import sample_device_resources


@dataclass(frozen=True)
class LocalModelMetadata:
    name: str
    size_bytes: int
    digest: str | None = None
    details: Mapping[str, Any] | None = None

    @property
    def size_gib(self) -> float:
        return self.size_bytes / (1024 ** 3)


class LocalModelAdmission:
    """Resolve and enforce the local model artifact ceiling before execution."""

    def __init__(self, *, base_url: str | None = None, max_gib: float | None = None) -> None:
        self.base_url = (base_url or os.getenv("OLLAMA_HOST", "http://127.0.0.1:11434")).rstrip("/")
        raw = max_gib if max_gib is not None else os.getenv("LUMO_LOCAL_MAX_MODEL_GIB", "64")
        # Artifact admission is separate from the live RAM governor. This
        # ceiling prevents absurdly large local artifacts from being selected;
        # the governor makes the stricter device-specific runtime decision.
        self.max_gib = min(float(raw), 64.0)
        if not math.isfinite(self.max_gib) or self.max_gib <= 0:
            raise ValueError("local model ceiling must be greater than zero")

    def resolve(self, model: str) -> LocalModelMetadata:
        if not isinstance(model, str) or not model.strip():
            raise ValueError("local model name is required")
        request = urllib.request.Request(self.base_url + "/api/tags", method="GET")
        try:
            with urllib.request.urlopen(request, timeout=3) as response:
                payload = json.loads(response.read().decode())
        except Exception as exc:
            raise RuntimeError("cannot verify local model size; refusing local execution") from exc
        models = payload.get("models")
        if not isinstance(models, list):
            raise RuntimeError("local model registry returned invalid metadata; refusing local execution")
        match = next((item for item in models if isinstance(item, dict) and item.get("name") == model), None)
        if match is None:
            raise RuntimeError(f"local model {model!r} is not installed")
        try:
            size = int(match.get("size") or 0)
        except (TypeError, ValueError) as exc:
            raise RuntimeError(f"local model {model!r} has unverifiable size; refusing local execution") from exc
        if size <= 0:
            raise RuntimeError(f"local model {model!r} has unverifiable size; refusing local execution")
        metadata = LocalModelMetadata(
            name=model,
            size_bytes=size,
            digest=str(match.get("digest")) if match.get("digest") else None,
            details=dict(match.get("details") or {}) if isinstance(match.get("details"), dict) else {},
        )
        limit_bytes = int(self.max_gib * (1024 ** 3))
        if size > limit_bytes:
            raise RuntimeError(
                f"local model {model!r} is {metadata.size_gib:.2f} GiB and exceeds the {self.max_gib:g} GiB device limit"
            )

        # Artifact size is not the same thing as live inference memory. Before
        # Ollama is allowed to load anything, require the model to fit the
        # *current* device budget with conservative runtime headroom. This is a
        # hard execution gate, not a UI recommendation, so a provider cannot
        # accidentally bypass the resource governor by calling Ollama directly.
        runtime_multiplier = float(os.getenv("LUMO_LOCAL_RUNTIME_MULTIPLIER", "1.35"))
        runtime_gib = metadata.size_gib * runtime_multiplier

        # RAM contention is a transient scheduler condition, not a permanent
        # model-selection failure. Wait and re-sample rather than terminating
        # an otherwise healthy overnight mission. The hard admission gate stays
        # in force: Ollama is never called until a fresh sample admits the model.
        wait_seconds = max(0.0, float(os.getenv("LUMO_LOCAL_RAM_WAIT_SECONDS", "21600")))
        poll_seconds = max(0.5, float(os.getenv("LUMO_LOCAL_RAM_POLL_SECONDS", "15")))
        deadline = time.monotonic() + wait_seconds
        while True:
            device = sample_device_resources()
            safe_gib = device.safe_ai_ram_bytes / (1024 ** 3)
            if runtime_gib <= safe_gib + 1e-6:
                return metadata
            if time.monotonic() >= deadline:
                raise RuntimeError(
                    f"local model {model!r} needs about {runtime_gib:.2f} GiB runtime headroom, "
                    f"but only {safe_gib:.2f} GiB is currently safe; refusing to load it"
                )
            time.sleep(min(poll_seconds, max(0.5, deadline - time.monotonic())))

    def admit(self, model: str) -> LocalModelMetadata:
        return self.resolve(model)
