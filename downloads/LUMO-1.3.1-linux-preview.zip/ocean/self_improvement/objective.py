from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping


class EvidenceKind(str, Enum):
    TESTS = "tests"
    BENCHMARK = "benchmark"
    STRUCTURAL = "structural"
    BEHAVIORAL = "behavioral"
    PERSISTENCE = "persistence"
    CONCURRENCY = "concurrency"
    VERIFICATION = "verification"
    RESEARCH = "research"
    COMPOSITE = "composite"


@dataclass(frozen=True)
class ObjectiveContract:
    """System-owned contract for an autonomous improvement objective.

    The model can propose implementation details, but this contract remains
    authoritative for identity and acceptance. Benchmarking is optional:
    architectural, persistence and concurrency work can be accepted by the
    evidence that actually proves the requested change.
    """

    objective_id: str
    objective: str
    work_type: str = "implementation"
    acceptance_criteria: tuple[str, ...] = ()
    evidence_policy: tuple[EvidenceKind, ...] = (EvidenceKind.TESTS,)
    required_evidence: tuple[str, ...] = ()
    minimum_improvements: int = 0
    constraints: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.objective_id.strip():
            raise ValueError("objective_id must not be empty")
        if not self.objective.strip():
            raise ValueError("objective must not be empty")
        if not self.work_type.strip():
            raise ValueError("work_type must not be empty")
        if not self.acceptance_criteria:
            raise ValueError("acceptance_criteria must not be empty")
        if any(not item.strip() for item in self.acceptance_criteria):
            raise ValueError("acceptance_criteria must contain non-empty strings")
        if self.minimum_improvements < 0:
            raise ValueError("minimum_improvements must be >= 0")
        if any(not item.strip() for item in self.required_evidence):
            raise ValueError("required_evidence must contain non-empty strings")

    @classmethod
    def legacy(cls, objective: str) -> "ObjectiveContract":
        return cls(
            objective_id=objective,
            objective=objective,
            acceptance_criteria=("candidate tests pass",),
            evidence_policy=(EvidenceKind.TESTS, EvidenceKind.BENCHMARK),
            minimum_improvements=1,
        )

    @property
    def requires(self) -> frozenset[EvidenceKind]:
        return frozenset(self.evidence_policy)
