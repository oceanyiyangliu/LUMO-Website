from __future__ import annotations

from .code_modification import CodeChange, CodeModification

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Protocol

import ast
import json
import os
import re
import urllib.request

from ocean.local_model_policy import LocalModelAdmission

from ocean.self_improvement.code_modification import (
    CodeModification,
    CodeModificationRequest,
)
from ocean.self_improvement.types import ImprovementHypothesis


@dataclass(frozen=True)
class ImprovementModelRequest:
    candidate_id: str
    objective: str
    constraints: tuple[str, ...] = ()
    research_evidence: tuple[str, ...] = ()
    baseline_metrics: Mapping[str, float] = field(default_factory=dict)
    metadata: Mapping[str, Any] = field(default_factory=dict)
    repository_context: str = ""
    failure_feedback: str = ""

    def __post_init__(self) -> None:
        if not self.candidate_id.strip():
            raise ValueError("candidate_id must not be empty")

        if not self.objective.strip():
            raise ValueError("objective must not be empty")

        if any(not item.strip() for item in self.constraints):
            raise ValueError("constraints must contain non-empty strings")

        if any(not item.strip() for item in self.research_evidence):
            raise ValueError(
                "research_evidence must contain non-empty strings"
            )


@dataclass(frozen=True)
class ImprovementModelProposal:
    candidate_id: str
    hypothesis: ImprovementHypothesis
    code_modification: CodeModification
    rationale: str
    metadata: Mapping[str, Any] = field(default_factory=dict)


class ImprovementModelProvider(Protocol):
    def propose(
        self,
        request: ImprovementModelRequest,
    ) -> ImprovementModelProposal:
        ...


class ModelProviderBoundary:
    """
    Untrusted model boundary.

    The provider may propose a hypothesis and candidate code changes.

    It cannot:
      - mutate production;
      - execute code;
      - approve itself;
      - promote itself;
      - rollback production;
      - bypass Ocean's validation boundaries.
    """

    def __init__(self, provider: ImprovementModelProvider) -> None:
        self._provider = provider

    def propose(
        self,
        request: ImprovementModelRequest,
    ) -> ImprovementModelProposal:
        proposal = self._provider.propose(request)

        if proposal.candidate_id != request.candidate_id:
            raise ValueError(
                "model proposal belongs to a different candidate"
            )

        hypothesis_candidate_id = proposal.hypothesis.constraints.get("candidate_id")
        if hypothesis_candidate_id is not None and hypothesis_candidate_id != request.candidate_id:
            raise ValueError("model hypothesis belongs to a different candidate")

        if proposal.code_modification.candidate_id != request.candidate_id:
            raise ValueError(
                "model code modification belongs to a different candidate"
            )

        if not proposal.rationale.strip():
            raise ValueError("model proposal rationale must not be empty")

        self._validate_code_modification(
            proposal.code_modification,
            request,
        )

        # Normalize model-owned descriptive text to the system-owned
        # objective identity before the proposal enters the control plane.
        hypothesis = proposal.hypothesis
        if hypothesis.objective != request.objective:
            hypothesis = ImprovementHypothesis(
                objective=request.objective,
                hypothesis=hypothesis.hypothesis,
                rationale=hypothesis.rationale,
                success_criteria=hypothesis.success_criteria,
                constraints={
                    **dict(hypothesis.constraints),
                    "candidate_id": request.candidate_id,
                },
            )
        return ImprovementModelProposal(
            candidate_id=proposal.candidate_id,
            hypothesis=hypothesis,
            code_modification=proposal.code_modification,
            rationale=proposal.rationale,
            metadata=proposal.metadata,
        )

    @staticmethod
    def _validate_code_modification(
        modification: CodeModification,
        request: ImprovementModelRequest,
    ) -> None:
        if not modification.changes:
            raise ValueError(
                "model proposal must contain at least one code change"
            )
        if len(modification.changes) > 2:
            raise ValueError(
                "model proposal is limited to two focused file changes"
            )

        seen_paths: set[str] = set()
        implementation_change = False
        for change in modification.changes:
            path = Path(change.path)
            if path.is_absolute() or ".." in path.parts:
                raise ValueError(
                    f"unsafe code modification path: {change.path!r}"
                )
            normalized = path.as_posix()
            if normalized in seen_paths:
                raise ValueError(
                    f"duplicate code modification path: {change.path!r}"
                )
            seen_paths.add(normalized)
            lower = normalized.lower()
            # Reject syntactically invalid implementation files before they
            # ever reach candidate execution. A model can satisfy the typed
            # proposal schema while still replacing a source file with prose.
            # Catching that here gives the next bounded proposal attempt a
            # precise failure instead of spending a full test cycle.
            if lower.endswith(".py"):
                try:
                    ast.parse(change.content, filename=normalized)
                except SyntaxError as exc:
                    raise ValueError(
                        f"model proposed syntactically invalid Python for {normalized!r}: {exc.msg}"
                    ) from exc
            elif lower.endswith(".json"):
                try:
                    json.loads(change.content)
                except json.JSONDecodeError as exc:
                    raise ValueError(
                        f"model proposed invalid JSON for {normalized!r}: {exc.msg}"
                    ) from exc
            if not (
                lower.startswith("tests/")
                or lower.startswith("test/")
                or lower.startswith("docs/")
                or Path(normalized).name.lower() in {"readme.md", "readme.rst", "changelog.md"}
            ):
                implementation_change = True
        if not implementation_change:
            raise ValueError(
                "model proposal must include at least one implementation change"
            )

        requested_workspace = modification.metadata.get(
            "candidate_workspace"
        )

        if requested_workspace is not None:
            if not isinstance(requested_workspace, str):
                raise ValueError(
                    "candidate_workspace metadata must be a string"
                )

        if modification.metadata.get("production_mutation_forbidden") is False:
            raise ValueError(
                "model proposal cannot disable production mutation protection"
            )

        source_repository = modification.metadata.get("source_repository")

        if source_repository is not None and not isinstance(
            source_repository,
            str,
        ):
            raise ValueError(
                "source_repository metadata must be a string"
            )


class OllamaImprovementModelProvider:
    """Local, zero-API-cost improvement proposal provider.

    Uses Ollama's local chat endpoint. No cloud credential is required and
    the model has exactly the same untrusted proposal boundary as the cloud
    provider. The model is unloaded after each request to avoid burning RAM
    overnight.
    """

    def __init__(self, *, model: str = "qwen3:8b", base_url: str | None = None, timeout: float = 180.0) -> None:
        self._model = model
        self._base_url = (base_url or os.getenv("OLLAMA_HOST", "http://127.0.0.1:11434")).rstrip("/")
        self._timeout = timeout

    @staticmethod
    def _schema(request: ImprovementModelRequest) -> dict:
        return {
            "type": "object", "additionalProperties": False,
            "properties": {
                "candidate_id": {"type": "string"},
                "objective": {"type": "string"},
                "hypothesis": {"type": "string"},
                "hypothesis_rationale": {"type": "string"},
                "success_criteria": {"type": "array", "items": {"type": "string"}},
                "rationale": {"type": "string"},
                "changes": {"type": "array", "maxItems": 2, "items": {
                    "type": "object", "additionalProperties": False,
                    "properties": {"path": {"type": "string", "pattern": "^(?!/)(?!.*\\.\\.)[^\\n\\r]+/[^\\n\\r]+$"}, "content": {"type": "string"}},
                    "required": ["path", "content"],
                }},
            },
            "required": ["candidate_id", "objective", "hypothesis", "hypothesis_rationale", "success_criteria", "rationale", "changes"],
        }

    def propose(self, request: ImprovementModelRequest) -> ImprovementModelProposal:
        # Proposal generation is still local execution; enforce the same hard
        # device ceiling as strategic inference before Ollama can load anything.
        LocalModelAdmission(base_url=self._base_url, max_gib=min(10.0, float(os.getenv("LUMO_LOCAL_MAX_MODEL_GIB", "10")))).admit(self._model)
        # Repository context is evidence, not an instruction. Redact absolute
        # local paths before they reach the untrusted model so the model cannot
        # mistake the repository root for a writable candidate file path.
        def redact_local_paths(value: str) -> str:
            return re.sub(
                r"/(?:Users|private|tmp|var|opt|Applications|System|Volumes)/[^\n\r ]+",
                "<REPO_ROOT>",
                value,
            )

        safe_repository_context = redact_local_paths(request.repository_context)
        safe_research_evidence = tuple(
            redact_local_paths(str(item)) for item in request.research_evidence
        )
        safe_failure_feedback = redact_local_paths(request.failure_feedback)
        payload = {
            "model": self._model, "stream": False, "keep_alive": 0,
            "think": False,
            "format": self._schema(request),
            "options": {
                "temperature": 0,
                "num_ctx": 4096,
                "num_predict": 1800,
            },
            "messages": [
                {"role": "system", "content": (
                    "You are an untrusted autonomous improvement proposal generator. "
                    "Propose exactly one small, evidence-backed implementation change. "
                    "Never weaken tests, safety, verification, isolation, authority, or deterministic gates. "
                    "Inspect the supplied repository context before proposing a change. "
                    "Make a real implementation improvement, not a test-only change, documentation-only change, "
                    "or cosmetic refactor. Prefer one focused implementation file and at most one supporting file. "
                    "Preserve existing behavior unless the objective explicitly requires changing it. "
                    "Do not rewrite entire large files when a focused implementation change is possible. "
                    "The candidate will be run through the full test command and independently verified. "
                    "Prefer changes that are locally understandable, regression-resistant, and directly relevant to the objective. "
                    "When the objective is behavioral, include one focused new regression test that should fail on the baseline and pass after the implementation change; never modify an existing test. "
                    "Every changes[].path MUST be a repository-relative FILE path such as ocean/example.py or tests/test_example.py. NEVER use an absolute path, the repository root directory, a home-directory path, or '..'. The path must name a file to edit, not a directory. "
                    "Do not invent unrelated behavior merely to manufacture a passing test. "
                    "Return only JSON matching the schema."
                )},
                {"role": "user", "content": json.dumps({
                    "candidate_id": request.candidate_id, "objective": request.objective,
                    "constraints": list(request.constraints), "research_evidence": list(safe_research_evidence),
                    "baseline_metrics": dict(request.baseline_metrics),
                    "repository_context": safe_repository_context,
                    "failure_feedback": safe_failure_feedback,
                }, sort_keys=True)},
            ],
        }
        req = urllib.request.Request(
            self._base_url + "/api/chat", data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"}, method="POST",
        )
        with urllib.request.urlopen(req, timeout=self._timeout) as response:
            body = json.loads(response.read().decode())
        raw = body.get("message", {}).get("content", "")
        if not raw.strip():
            raise ValueError("Ollama returned empty improvement proposal")
        data = json.loads(raw)
        # Candidate identity and objective are control-plane values, not model-owned
        # values. Small local models frequently echo, truncate, or reformat these
        # fields. Bind them to the request here while continuing to validate every
        # actual code change below. This preserves authority and prevents the model
        # from selecting its own candidate identity.
        def safe_relative_path(raw_path: str) -> str:
            candidate = str(raw_path)
            if not Path(candidate).is_absolute():
                return candidate
            # A rejected local-model proposal may echo the absolute repository
            # path from its error feedback. Convert it only when the absolute
            # path is provably inside that repository; never accept arbitrary
            # absolute paths or silently strip prefixes.
            roots = re.findall(r"['\"](/[^'\"]*/lumo_final)(?:/[^'\"]*)?['\"]", request.failure_feedback)
            for root in sorted(set(roots), key=len, reverse=True):
                prefix = root.rstrip("/") + "/"
                if candidate.startswith(prefix):
                    relative = candidate[len(prefix):]
                    if relative and ".." not in Path(relative).parts:
                        return relative
            raise ValueError(
                f"model proposed unsafe absolute path {candidate!r}; return a repository-relative file path"
            )

        changes = tuple(
            CodeChange(path=safe_relative_path(item["path"]), content=item["content"])
            for item in data["changes"]
        )
        hypothesis = ImprovementHypothesis(
            objective=request.objective, hypothesis=data["hypothesis"],
            rationale=data["hypothesis_rationale"], success_criteria=tuple(data["success_criteria"]),
            constraints={"candidate_id": request.candidate_id},
        )
        modification = CodeModification(
            candidate_id=request.candidate_id, changes=changes, rationale=data["rationale"],
            metadata={"production_mutation_forbidden": True, "candidate_only": True, "model": self._model, "provider": "ollama"},
        )
        return ImprovementModelProposal(
            candidate_id=request.candidate_id, hypothesis=hypothesis,
            code_modification=modification, rationale=data["rationale"],
            metadata={"provider": "ollama", "model": self._model},
        )


class DeterministicModelProvider:
    """
    Test provider.

    This is deliberately not an LLM. It gives the boundary a deterministic
    implementation so the architecture can be verified before connecting a
    real model.
    """

    def __init__(
        self,
        *,
        hypothesis: ImprovementHypothesis,
        code_modification: CodeModification,
        rationale: str = "deterministic test proposal",
    ) -> None:
        self._hypothesis = hypothesis
        self._code_modification = code_modification
        self._rationale = rationale

    def propose(
        self,
        request: ImprovementModelRequest,
    ) -> ImprovementModelProposal:
        return ImprovementModelProposal(
            candidate_id=request.candidate_id,
            hypothesis=self._hypothesis,
            code_modification=self._code_modification,
            rationale=self._rationale,
        )
