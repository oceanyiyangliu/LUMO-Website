from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Iterable, Mapping, Optional, Protocol

from ocean.core.clock import SYSTEM_CLOCK
from ocean.core.ids import new_id
from ocean.domain.event import Event
from persistence.repository import Repository


@dataclass(frozen=True)
class ResearchRequest:
    candidate_id: str
    objective: str
    queries: tuple[str, ...] = ()
    constraints: Mapping[str, Any] = field(default_factory=dict)
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.candidate_id.strip():
            raise ValueError("research candidate_id must not be empty")
        if not self.objective.strip():
            raise ValueError("research objective must not be empty")
        if any(not query.strip() for query in self.queries):
            raise ValueError("research queries must contain only non-empty strings")


@dataclass(frozen=True)
class ResearchSource:
    title: str
    uri: str
    source_type: str = "unknown"
    publisher: Optional[str] = None
    published_at: Optional[datetime] = None
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.title.strip():
            raise ValueError("research source title must not be empty")
        if not self.uri.strip():
            raise ValueError("research source uri must not be empty")
        if not self.source_type.strip():
            raise ValueError("research source_type must not be empty")


@dataclass(frozen=True)
class ResearchFinding:
    candidate_id: str
    claim: str
    source: ResearchSource
    confidence: float = 1.0
    evidence: tuple[str, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: new_id("research_finding"))
    at: datetime = field(default_factory=lambda: SYSTEM_CLOCK.now())

    def __post_init__(self) -> None:
        if not self.candidate_id.strip():
            raise ValueError("research finding candidate_id must not be empty")
        if not self.claim.strip():
            raise ValueError("research finding claim must not be empty")
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError("research finding confidence must be between 0 and 1")
        if any(not item.strip() for item in self.evidence):
            raise ValueError("research finding evidence must contain only non-empty strings")


@dataclass(frozen=True)
class ResearchReport:
    candidate_id: str
    findings: tuple[ResearchFinding, ...]
    queries: tuple[str, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)


class ResearchProvider(Protocol):
    def research(self, request: ResearchRequest) -> ResearchReport:
        ...


class ResearchService:
    """Authoritative durable research boundary for self-improvement."""

    def __init__(
        self,
        *,
        findings: Repository[ResearchFinding],
        events,
    ) -> None:
        self._findings = findings
        self._events = events

    @property
    def findings(self) -> Repository[ResearchFinding]:
        return self._findings

    def conduct(
        self,
        request: ResearchRequest,
        provider: ResearchProvider,
    ) -> ResearchReport:
        report = provider.research(request)

        if report.candidate_id != request.candidate_id:
            raise ValueError("research provider returned the wrong candidate")

        findings = tuple(report.findings)

        for finding in findings:
            if finding.candidate_id != request.candidate_id:
                raise ValueError(
                    "research finding belongs to a different candidate"
                )

        seen: set[str] = set()
        for finding in findings:
            if finding.id in seen:
                raise ValueError(
                    f"duplicate research finding in report: {finding.id!r}"
                )
            seen.add(finding.id)

        for finding in findings:
            existing = self._findings.get(finding.id)
            if existing is not None and existing != finding:
                raise ValueError(
                    f"research finding already exists with different content: "
                    f"{finding.id!r}"
                )

        for finding in findings:
            self._findings.save(finding)
            self._events.publish(
                Event(
                    type="ResearchFindingRecorded",
                    payload={
                        "finding_id": finding.id,
                        "candidate_id": finding.candidate_id,
                        "mission_id": request.metadata.get("mission_id"),
                        "claim": finding.claim,
                        "source": {
                            "title": finding.source.title,
                            "uri": finding.source.uri,
                            "source_type": finding.source.source_type,
                            "publisher": finding.source.publisher,
                            "published_at": finding.source.published_at,
                            "metadata": dict(finding.source.metadata),
                        },
                        "confidence": finding.confidence,
                        "evidence": list(finding.evidence),
                        "metadata": dict(finding.metadata),
                        "at": finding.at,
                    },
                    aggregate_type="improvement_candidate",
                    aggregate_id=request.candidate_id,
                )
            )

        return ResearchReport(
            candidate_id=report.candidate_id,
            findings=findings,
            queries=tuple(report.queries or request.queries),
            metadata=dict(report.metadata),
        )

    def for_candidate(self, candidate_id: str) -> tuple[ResearchFinding, ...]:
        return tuple(
            finding
            for finding in self._findings.list()
            if finding.candidate_id == candidate_id
        )

    def evidence_for_candidate(self, candidate_id: str) -> tuple[str, ...]:
        """Return deterministic evidence strings for hypothesis generation."""
        findings = self.for_candidate(candidate_id)
        evidence: list[str] = []

        for finding in findings:
            source = finding.source
            provenance = f"{source.title} ({source.uri})"
            evidence.append(
                f"{finding.claim} "
                f"[confidence={finding.confidence:.3f}; source={provenance}]"
            )
            evidence.extend(finding.evidence)

        return tuple(evidence)

    def summarize_for_candidate(self, candidate_id: str) -> Mapping[str, Any]:
        """Return a stable research summary suitable for planning metadata."""
        findings = self.for_candidate(candidate_id)

        return {
            "candidate_id": candidate_id,
            "finding_count": len(findings),
            "findings": tuple(
                {
                    "id": finding.id,
                    "claim": finding.claim,
                    "confidence": finding.confidence,
                    "evidence": tuple(finding.evidence),
                    "source": {
                        "title": finding.source.title,
                        "uri": finding.source.uri,
                        "source_type": finding.source.source_type,
                        "publisher": finding.source.publisher,
                    },
                }
                for finding in findings
            ),
            "evidence": self.evidence_for_candidate(candidate_id),
        }
