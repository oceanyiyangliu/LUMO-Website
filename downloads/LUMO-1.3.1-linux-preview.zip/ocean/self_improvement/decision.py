from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Optional

from ocean.self_improvement.benchmark import BenchmarkComparisonReport
from ocean.self_improvement.verification import CandidateVerificationContext
from ocean.self_improvement.objective import EvidenceKind, ObjectiveContract


@dataclass(frozen=True)
class ImprovementDecisionRequest:
    candidate_id: str
    verification: CandidateVerificationContext
    benchmark: BenchmarkComparisonReport
    research_evidence: tuple[str, ...] = ()
    required_evidence: tuple[str, ...] = ()
    minimum_improvements: int = 1
    minimum_score: Optional[float] = None
    score: Optional[float] = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    objective_contract: Optional[ObjectiveContract] = None

    def __post_init__(self) -> None:
        if not self.candidate_id.strip():
            raise ValueError("decision candidate_id must not be empty")

        if self.verification.candidate_id != self.candidate_id:
            raise ValueError(
                "verification belongs to a different candidate"
            )

        if self.benchmark.candidate_id != self.candidate_id:
            raise ValueError(
                "benchmark comparison belongs to a different candidate"
            )

        if self.minimum_improvements < 1:
            raise ValueError("minimum_improvements must be >= 1")

        if self.minimum_score is not None and not 0.0 <= self.minimum_score <= 1.0:
            raise ValueError("minimum_score must be between 0 and 1")

        if self.score is not None and not 0.0 <= self.score <= 1.0:
            raise ValueError("score must be between 0 and 1")

        if any(not item.strip() for item in self.required_evidence):
            raise ValueError(
                "required_evidence must contain only non-empty strings"
            )

        if any(not item.strip() for item in self.research_evidence):
            raise ValueError(
                "research_evidence must contain only non-empty strings"
            )


@dataclass(frozen=True)
class ImprovementDecision:
    candidate_id: str
    passed: bool
    reasons: tuple[str, ...]
    required_evidence: tuple[str, ...]
    supplied_evidence: tuple[str, ...]
    improved_metrics: tuple[str, ...]
    regressed_metrics: tuple[str, ...]
    unchanged_metrics: tuple[str, ...]
    score: Optional[float]
    metadata: Mapping[str, Any] = field(default_factory=dict)


class ImprovementDecisionService:
    """
    Deterministic authority for deciding whether a candidate is eligible
    for promotion.

    No model output is trusted as a promotion decision.

    A candidate passes only when:
      - candidate identity matches everywhere;
      - verification passed;
      - verification contains evidence;
      - benchmark comparison passed;
      - there are enough improved metrics;
      - there are no regressions;
      - all required evidence is present;
      - minimum score, when configured, is satisfied.
    """

    def decide(
        self,
        request: ImprovementDecisionRequest,
    ) -> ImprovementDecision:
        reasons: list[str] = []

        if not request.verification.passed:
            reasons.append("candidate verification failed")

        if not request.verification.evidence:
            reasons.append("candidate verification contains no evidence")

        benchmark = request.benchmark
        contract = request.objective_contract
        benchmark_skipped = bool(benchmark.metadata.get("skipped"))
        contract_requires_benchmark = (
            contract is None or EvidenceKind.BENCHMARK in contract.requires
        )
        requires_benchmark = contract_requires_benchmark and not benchmark_skipped

        if contract is not None and EvidenceKind.BENCHMARK in contract.requires and benchmark_skipped:
            reasons.append("objective requires benchmark evidence but benchmark execution was skipped")
        minimum_improvements = (
            request.minimum_improvements
            if contract is None
            else contract.minimum_improvements
        )

        if requires_benchmark:
            if not benchmark.comparisons:
                reasons.append("benchmark comparison contains no metrics")
            if not benchmark.passed:
                reasons.append("benchmark comparison failed")
            if benchmark.regressed_count > 0:
                reasons.append(
                    f"benchmark contains {benchmark.regressed_count} regression(s)"
                )
            if benchmark.improved_count < minimum_improvements:
                reasons.append("candidate does not meet minimum improvement requirement")

        supplied = set(request.research_evidence) | set(request.verification.evidence)

        required = request.required_evidence
        if contract is not None:
            required = tuple(dict.fromkeys((*required, *contract.required_evidence)))

        missing_evidence = tuple(
            item
            for item in required
            if item not in supplied
        )

        if missing_evidence:
            reasons.append("required research evidence is missing")

        if (
            request.minimum_score is not None
            and (
                request.score is None
                or request.score < request.minimum_score
            )
        ):
            reasons.append("candidate score is below the required minimum")

        passed = not reasons

        return ImprovementDecision(
            candidate_id=request.candidate_id,
            passed=passed,
            reasons=tuple(reasons),
            required_evidence=tuple(required),
            supplied_evidence=tuple(sorted(supplied)),
            improved_metrics=tuple(
                item.name
                for item in benchmark.comparisons
                if item.improved and item.promotion_metric
            ),
            regressed_metrics=tuple(
                item.name
                for item in benchmark.comparisons
                if item.promotion_metric and (
                    item.candidate < item.baseline
                    if item.higher_is_better
                    else item.candidate > item.baseline
                )
            ),
            unchanged_metrics=tuple(
                item.name
                for item in benchmark.comparisons
                if item.promotion_metric and (
                    item.candidate == item.baseline
                )
            ),
            score=request.score,
            metadata={
                **dict(request.metadata),
                "minimum_improvements": minimum_improvements,
                "objective_contract": (
                    contract.objective_id if contract is not None else None
                ),
                "minimum_score": request.minimum_score,
            },
        )
