from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Optional

from ocean.core.ids import new_id
from ocean.domain.event import Event
from ocean.domain.verification import Verification
from persistence.repository import Repository


class CandidateVerificationError(ValueError):
    """Raised when candidate verification violates the verification boundary."""


@dataclass(frozen=True)
class CandidateVerificationContext:
    candidate_id: str
    candidate_mission_id: str
    candidate_plan_revision_id: str
    task_id: str
    execution_id: Optional[str]
    verification_id: str
    passed: bool
    evidence: tuple[str, ...]
    metadata: Mapping[str, Any]


class CandidateVerificationService:
    """
    Authoritative evidence boundary for self-improvement candidates.

    Verification is deliberately separate from execution success.
    A candidate becomes eligible for evaluation only through an explicit
    VerificationRecorded event carrying task identity and evidence.
    """

    def __init__(
        self,
        *,
        verifications: Repository[Verification] | None = None,
        events,
    ) -> None:
        self._verifications = verifications
        self._events = events

    def record(
        self,
        *,
        candidate_id: str,
        candidate_mission_id: str,
        candidate_plan_revision_id: str,
        task_id: str,
        passed: bool,
        evidence: tuple[str, ...] = (),
        execution_id: Optional[str] = None,
        method: str = "candidate_verification",
        metadata: Optional[Mapping[str, Any]] = None,
    ) -> CandidateVerificationContext:
        if not candidate_id or not candidate_id.strip():
            raise CandidateVerificationError("candidate_id must be non-empty")

        if not candidate_mission_id or not candidate_mission_id.strip():
            raise CandidateVerificationError(
                "candidate_mission_id must be non-empty"
            )

        if not candidate_plan_revision_id or not candidate_plan_revision_id.strip():
            raise CandidateVerificationError(
                "candidate_plan_revision_id must be non-empty"
            )

        if not task_id or not task_id.strip():
            raise CandidateVerificationError("task_id must be non-empty")

        if not method or not method.strip():
            raise CandidateVerificationError("verification method must be non-empty")

        normalized_evidence = tuple(str(item) for item in evidence)

        if passed and not normalized_evidence:
            raise CandidateVerificationError(
                "passing candidate verification requires evidence"
            )

        verification = Verification(
            task_id=task_id,
            method=method,
            passed=passed,
            evidence=list(normalized_evidence),
            execution_id=execution_id,
        )

        if self._verifications is not None:
            self._verifications.save(verification)

        event_payload = {
            "id": verification.id,
            "verification_id": verification.id,
            "candidate_id": candidate_id,
            "candidate_mission_id": candidate_mission_id,
            "candidate_plan_revision_id": candidate_plan_revision_id,
            "task_id": verification.task_id,
            "method": verification.method,
            "passed": verification.passed,
            "evidence": list(verification.evidence),
            "execution_id": verification.execution_id,
            "metadata": dict(metadata or {}),
        }

        failures = self._events.publish(
            Event(
                type="VerificationRecorded",
                payload=event_payload,
                aggregate_type="candidate_verification",
                aggregate_id=verification.id,
                correlation_id=candidate_id,
                source="self_improvement",
            )
        )

        if failures:
            raise RuntimeError(
                "event handlers failed for 'VerificationRecorded': "
                + "; ".join(str(failure.error) for failure in failures)
            )

        return CandidateVerificationContext(
            candidate_id=candidate_id,
            candidate_mission_id=candidate_mission_id,
            candidate_plan_revision_id=candidate_plan_revision_id,
            task_id=task_id,
            execution_id=execution_id,
            verification_id=verification.id,
            passed=passed,
            evidence=normalized_evidence,
            metadata=dict(metadata or {}),
        )

    def require(self, verification_id: str, candidate_id: Optional[str] = None) -> Verification:
        """Retrieve a persisted Verification.

        Backwards-compatible signature: the primary identifier is verification_id
        (positional or keyword). An optional candidate_id, when supplied, will
        be used to validate that the verification belongs to the candidate by
        inspecting the published VerificationRecorded event payload.

        Lookup strategy:
        - If a verification repository is configured, prefer the repository.
          If the repository does not contain the verification but a
          VerificationRecorded event exists, reconstruct the Verification
          from the event.
        - If no repository is configured, attempt to reconstruct the
          Verification from VerificationRecorded events in the event history.

        Raises CandidateVerificationError when the verification cannot be
        found or when a candidate_id mismatch is detected.
        """
        if not verification_id or not str(verification_id).strip():
            raise CandidateVerificationError("verification_id must be non-empty")

        # Helper to reconstruct a Verification from an event payload
        def _verification_from_payload(payload: Mapping[str, Any]) -> Verification:
            return Verification(
                task_id=str(payload.get("task_id") or ""),
                method=str(payload.get("method") or ""),
                passed=bool(payload.get("passed")),
                evidence=list(payload.get("evidence") or []),
                execution_id=payload.get("execution_id"),
                id=str(payload.get("verification_id") or payload.get("id") or verification_id),
            )

        # If a repository exists, prefer it for authoritative data
        if self._verifications is not None:
            verification = self._verifications.get(verification_id)
            if verification is not None:
                # If a candidate_id was provided, validate via events (if available)
                if candidate_id and self._events is not None:
                    for ev in self._events.history("VerificationRecorded"):
                        if ev.payload.get("verification_id") == verification_id:
                            if ev.payload.get("candidate_id") != candidate_id:
                                raise CandidateVerificationError(
                                    "verification does not belong to candidate"
                                )
                            break
                return verification

            # Repository did not contain the verification; fall back to event history
            if self._events is not None:
                for ev in self._events.history("VerificationRecorded"):
                    if ev.payload.get("verification_id") == verification_id:
                        if candidate_id and ev.payload.get("candidate_id") != candidate_id:
                            raise CandidateVerificationError(
                                "verification does not belong to candidate"
                            )
                        return _verification_from_payload(ev.payload)

            raise CandidateVerificationError(f"unknown verification: {verification_id!r}")

        # No repository configured: reconstruct from the events if possible
        if self._events is None:
            raise CandidateVerificationError(
                "verification repository or events is required to retrieve evidence"
            )

        for ev in self._events.history("VerificationRecorded"):
            if ev.payload.get("verification_id") == verification_id:
                if candidate_id and ev.payload.get("candidate_id") != candidate_id:
                    raise CandidateVerificationError(
                        "verification does not belong to candidate"
                    )
                return _verification_from_payload(ev.payload)

        raise CandidateVerificationError(f"unknown verification: {verification_id!r}")
