"""Cheap, deterministic prioritization for autonomous LUMO improvement.

The self-improvement loop must first fix the product's current bottleneck, not
invent another subsystem. This module intentionally performs only local,
side-effect-free checks and returns one concrete focus objective.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os
import shutil
import subprocess

@dataclass(frozen=True)
class Focus:
    key: str
    objective: str
    reason: str
    urgency: int


def _exists(root: Path, *parts: str) -> bool:
    return (root.joinpath(*parts)).exists()


def detect_focus(root: Path) -> Focus:
    root = root.resolve()
    # Launch/usefulness is the highest-value work until the product can actually
    # get a user from install -> bootstrap -> permissions -> usable UI/control.
    if not _exists(root, "ocean", "setup_autopilot.py"):
        return Focus("setup", "Make LUMO first-launch setup work end-to-end on this Mac using the existing setup and bootstrap architecture; do not add a new subsystem.", "setup autopilot is missing", 1000)
    if not _exists(root, "ocean", "bootstrap_intelligence.py") or not _exists(root, "ocean", "local_model_client.py"):
        return Focus("bootstrap", "Make LUMO's existing local intelligence bootstrap reliably install, select, health-check and hand off to the strongest safe installed model; fix the current path instead of adding another model subsystem.", "bootstrap path is incomplete", 990)
    if not _exists(root, "ocean", "computer_agent.py"):
        return Focus("computer", "Make LUMO's existing computer-use agent reliably control the Mac after setup permissions, with observe-act-verify recovery; do not create another computer-control stack.", "computer agent is missing", 980)
    if not _exists(root, "lumo-ui", "src", "app", "page.tsx"):
        return Focus("ui", "Make the existing LUMO UI launch and expose truthful setup, health, control and recovery state; do not create another UI subsystem.", "primary UI entrypoint is missing", 970)
    if not _exists(root, ".venv", "bin", "lumo"):
        return Focus("cli", "Make the existing LUMO CLI installable and launchable from a clean local checkout; do not add a second launcher.", "CLI executable is missing", 960)
    # Once structural launch pieces exist, target actual runtime evidence rather
    # than speculative features. This is intentionally conservative.
    return Focus(
        "launch-usable",
        "Make LUMO usable and launchable end-to-end on the current Mac. Reproduce the most immediate launch/setup failure using the existing architecture, fix that failure with the smallest reversible change, and verify the complete path. Do not add new subsystems, speculative features, or abstractions unless the failing path demonstrably requires them.",
        "core launch path exists; runtime verification is now the highest-value work",
        900,
    )
