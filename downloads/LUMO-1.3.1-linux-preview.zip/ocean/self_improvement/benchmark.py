from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Mapping, Protocol, Sequence


@dataclass(frozen=True)
class BenchmarkRequest:
    candidate_id: str
    objective: str
    workspace_root: str
    baseline_root: str
    constraints: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.candidate_id.strip():
            raise ValueError("benchmark candidate_id must not be empty")
        if not self.objective.strip():
            raise ValueError("benchmark objective must not be empty")
        if not self.workspace_root.strip():
            raise ValueError("benchmark workspace_root must not be empty")
        if not self.baseline_root.strip():
            raise ValueError("benchmark baseline_root must not be empty")


@dataclass(frozen=True)
class BenchmarkResult:
    name: str
    value: float
    unit: str = ""
    higher_is_better: bool = True
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class BenchmarkReport:
    candidate_id: str
    results: tuple[BenchmarkResult, ...]
    metadata: Mapping[str, Any] = field(default_factory=dict)


class BenchmarkProvider(Protocol):
    def benchmark(self, request: BenchmarkRequest) -> BenchmarkReport:
        ...


@dataclass(frozen=True)
class BenchmarkComparison:
    name: str
    baseline: float
    candidate: float
    delta: float
    improvement_ratio: float
    improved: bool
    unit: str
    higher_is_better: bool
    promotion_metric: bool = True


@dataclass(frozen=True)
class BenchmarkComparisonReport:
    candidate_id: str
    comparisons: tuple[BenchmarkComparison, ...]
    improved_count: int
    regressed_count: int
    unchanged_count: int
    passed: bool
    metadata: Mapping[str, Any] = field(default_factory=dict)


class BenchmarkService:
    """Runs candidate/baseline benchmarks and performs deterministic comparison."""

    def run(
        self,
        *,
        request: BenchmarkRequest,
        provider: BenchmarkProvider,
    ) -> BenchmarkReport:
        report = provider.benchmark(request)

        if report.candidate_id != request.candidate_id:
            raise ValueError(
                "benchmark provider returned the wrong candidate"
            )

        seen: set[str] = set()

        for result in report.results:
            if not result.name.strip():
                raise ValueError("benchmark result name must not be empty")
            if result.name in seen:
                raise ValueError(
                    f"duplicate benchmark result: {result.name!r}"
                )
            seen.add(result.name)

        return report

    def compare(
        self,
        *,
        candidate_id: str,
        baseline: BenchmarkReport,
        candidate: BenchmarkReport,
    ) -> BenchmarkComparisonReport:
        if baseline.candidate_id != candidate_id:
            raise ValueError("baseline benchmark belongs to the wrong candidate")

        if candidate.candidate_id != candidate_id:
            raise ValueError("candidate benchmark belongs to the wrong candidate")

        baseline_by_name = {
            result.name: result
            for result in baseline.results
        }
        candidate_by_name = {
            result.name: result
            for result in candidate.results
        }

        if set(baseline_by_name) != set(candidate_by_name):
            raise ValueError(
                "baseline and candidate benchmarks must contain the same metrics"
            )

        comparisons: list[BenchmarkComparison] = []

        for name in sorted(baseline_by_name):
            before = baseline_by_name[name]
            after = candidate_by_name[name]

            if before.unit != after.unit:
                raise ValueError(
                    f"benchmark unit mismatch for {name!r}"
                )

            if before.higher_is_better != after.higher_is_better:
                raise ValueError(
                    f"benchmark direction mismatch for {name!r}"
                )

            delta = after.value - before.value

            if before.value == 0:
                ratio = 0.0 if delta == 0 else float("inf")
            else:
                ratio = delta / abs(before.value)

            if before.higher_is_better:
                improved = after.value > before.value
            else:
                improved = after.value < before.value

            comparisons.append(
                BenchmarkComparison(
                    name=name,
                    baseline=before.value,
                    candidate=after.value,
                    delta=delta,
                    improvement_ratio=ratio,
                    improved=improved,
                    unit=after.unit,
                    higher_is_better=after.higher_is_better,
                    promotion_metric=bool(after.metadata.get("promotion_metric", True)),
                )
            )

        promotion_comparisons = [item for item in comparisons if item.promotion_metric]
        improved_count = sum(item.improved for item in promotion_comparisons)
        regressed_count = sum(
            (
                item.candidate < item.baseline
                if item.higher_is_better
                else item.candidate > item.baseline
            )
            for item in promotion_comparisons
        )
        unchanged_count = len(promotion_comparisons) - improved_count - regressed_count

        return BenchmarkComparisonReport(
            candidate_id=candidate_id,
            comparisons=tuple(comparisons),
            improved_count=improved_count,
            regressed_count=regressed_count,
            unchanged_count=unchanged_count,
            passed=bool(comparisons) and regressed_count == 0,
            metadata={
                "baseline_metadata": dict(baseline.metadata),
                "candidate_metadata": dict(candidate.metadata),
                "promotion_metrics": [item.name for item in promotion_comparisons],
                "diagnostic_metrics": [item.name for item in comparisons if not item.promotion_metric],
            },
        )
