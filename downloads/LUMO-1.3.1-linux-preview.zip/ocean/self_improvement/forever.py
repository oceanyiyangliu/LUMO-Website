from __future__ import annotations

import fcntl, json, os, signal, threading, time
from dataclasses import dataclass

try:
    import psutil
except ImportError:  # pragma: no cover
    psutil = None
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from .runtime import AutonomousImprovementRuntime, ImprovementBudget
from .observatory import ImprovementObservatory


@dataclass(frozen=True)
class ForeverState:
    cycles: int = 0
    promoted: int = 0
    failed: int = 0
    last_status: str = "never_started"
    last_run_id: str | None = None
    last_candidate_id: str | None = None
    last_error: str | None = None
    last_area_id: str | None = None
    last_area_title: str | None = None
    updated_at: float = 0.0
    area_failures: dict[str, int] | None = None
    area_cooldowns: dict[str, float] | None = None
    completed_areas: list[str] | None = None
    worker_mode: str = "single"
    paused_reason: str | None = None
    last_activity_path: str | None = None
    last_resource_snapshot: dict | None = None


class _ResourceAbort(RuntimeError):
    def __init__(self, reason: str, snapshot: dict):
        super().__init__(reason)
        self.reason = reason
        self.snapshot = snapshot


class _ProgressAbort(RuntimeError):
    def __init__(self, reason: str, elapsed_seconds: float):
        super().__init__(reason)
        self.reason = reason
        self.elapsed_seconds = elapsed_seconds


class ForeverImprovementWorker:
    """Persistent resource-aware evolution worker with failure memory.

    The worker is deliberately conservative: one isolated candidate at a time,
    deterministic gates, durable cooldowns, and no forced machine activity.
    """
    def __init__(self, repository_root: Path, *, objective: str, model: str = "qwen3:0.6b",
                 cycle_delay: float = 30.0, idle_delay: float = 300.0,
                 test_timeout: float = 120.0, on_event: Callable[[str], None] | None = None) -> None:
        if not objective.strip(): raise ValueError("objective must not be empty")
        if cycle_delay < 0 or idle_delay < 0 or test_timeout <= 0: raise ValueError("invalid worker timing")
        self.repository_root = repository_root.resolve(); self.objective = objective.strip(); self.model = model.strip()
        self.cycle_delay = cycle_delay; self.idle_delay = idle_delay; self.test_timeout = test_timeout
        self.on_event = on_event or print
        state_dir = self.repository_root / ".ocean"; state_dir.mkdir(parents=True, exist_ok=True)
        self.state_path = state_dir / "self_improvement_forever.json"
        self.lock_path = state_dir / "self_improvement_forever.lock"
        self._stop = False; self.observatory = ImprovementObservatory(self.repository_root)
        self.activity_path = state_dir / "self_improvement_forever_activity.jsonl"
        self.max_system_cpu = float(os.getenv("LUMO_SELF_IMPROVEMENT_MAX_SYSTEM_CPU", "75"))
        self.min_available_gib = float(os.getenv("LUMO_SELF_IMPROVEMENT_MIN_AVAILABLE_GIB", "5"))
        # Maximum time a cycle may remain completely silent. This is a hang
        # detector, not a test timeout; legitimate work gets the full budget.
        self.progress_timeout = float(os.getenv("LUMO_SELF_IMPROVEMENT_PROGRESS_TIMEOUT", "180"))

    def _activity(self, event: str, **payload) -> None:
        record = {"timestamp": time.time(), "event": event, "payload": payload}
        try:
            with self.activity_path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(record, sort_keys=True, default=str) + "\n")
        except OSError:
            pass
        self.on_event(f"FOREVER {event} {json.dumps(payload, sort_keys=True, default=str)[:1200]}")

    def _machine_safe(self) -> tuple[bool, str, dict]:
        if psutil is None:
            return True, "psutil_unavailable", {}
        try:
            cpu = float(psutil.cpu_percent(interval=0.25))
            available = float(psutil.virtual_memory().available) / 1024**3
            pytest_pids = []
            for proc in psutil.process_iter(["pid", "name", "cmdline"]):
                try:
                    name = (proc.info.get("name") or "").lower()
                    cmd = " ".join(proc.info.get("cmdline") or []).lower()
                    if "pytest" in name or "pytest" in cmd:
                        pytest_pids.append(proc.info["pid"])
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            snapshot = {"cpu_percent": cpu, "available_ram_gib": round(available, 2), "pytest_pids": pytest_pids}
            if cpu >= self.max_system_cpu:
                return False, f"system_cpu_high:{cpu:.1f}%", snapshot
            if available < self.min_available_gib:
                return False, f"ram_low:{available:.2f}GiB", snapshot
            if pytest_pids:
                return False, f"external_pytest_active:{len(pytest_pids)}", snapshot
            return True, "clear", snapshot
        except Exception as exc:
            return False, f"resource_measurement_failed:{type(exc).__name__}", {}

    def _run_with_resource_watchdog(self, runtime, objective: str, budget):
        """Run one autonomous cycle with an in-flight machine safety brake."""
        if psutil is None:
            return runtime.improve_overnight(objective, budget=budget)

        stop_watchdog = threading.Event()
        triggered: dict[str, object] = {}
        started = time.monotonic()

        def _signal_handler(signum, frame):
            kind = str(triggered.get("kind", "resource"))
            if kind == "progress":
                raise _ProgressAbort(
                    str(triggered.get("reason", "cycle_progress_timeout")),
                    float(triggered.get("elapsed_seconds", 0.0)),
                )
            reason = str(triggered.get("reason", "resource_guard_triggered"))
            snapshot = dict(triggered.get("snapshot", {}))
            raise _ResourceAbort(reason, snapshot)

        previous = signal.getsignal(signal.SIGUSR1)
        signal.signal(signal.SIGUSR1, _signal_handler)

        def _watch():
            high_samples = 0
            low_ram_samples = 0
            while not stop_watchdog.wait(0.5):
                elapsed = time.monotonic() - started
                if elapsed >= self.progress_timeout:
                    triggered["kind"] = "progress"
                    triggered["reason"] = f"cycle_progress_timeout:{elapsed:.1f}s"
                    triggered["elapsed_seconds"] = elapsed
                    self._activity(
                        "progress_watchdog_triggered",
                        reason=triggered["reason"],
                        elapsed_seconds=round(elapsed, 1),
                    )
                    try:
                        os.kill(os.getpid(), signal.SIGUSR1)
                    except OSError:
                        pass
                    return
                safe, reason, snapshot = self._machine_safe()
                cpu = float(snapshot.get("cpu_percent", 0.0)) if snapshot else 0.0
                ram = float(snapshot.get("available_ram_gib", 999.0)) if snapshot else 999.0
                high_samples = high_samples + 1 if cpu >= self.max_system_cpu else 0
                low_ram_samples = low_ram_samples + 1 if ram < self.min_available_gib else 0
                if high_samples >= 3 or low_ram_samples >= 3:
                    trigger_reason = reason if reason != "clear" else (
                        f"system_cpu_high:{cpu:.1f}%" if high_samples >= 3 else f"ram_low:{ram:.2f}GiB"
                    )
                    triggered["reason"] = trigger_reason
                    triggered["snapshot"] = snapshot
                    self._activity("in_cycle_safety_abort_requested", reason=trigger_reason, resource_snapshot=snapshot)
                    try:
                        os.kill(os.getpid(), signal.SIGUSR1)
                    except OSError:
                        pass
                    return

        watcher = threading.Thread(target=_watch, name="lumo-self-improvement-resource-watchdog", daemon=True)
        watcher.start()
        try:
            return runtime.improve_overnight(objective, budget=budget)
        finally:
            stop_watchdog.set()
            watcher.join(timeout=1.0)
            signal.signal(signal.SIGUSR1, previous)

    def stop(self) -> None: self._stop = True

    def _load_state(self) -> ForeverState:
        if not self.state_path.is_file(): return ForeverState()
        try:
            data=json.loads(self.state_path.read_text()); defaults=ForeverState()
            return ForeverState(**{key:data.get(key,getattr(defaults,key)) for key in ForeverState.__dataclass_fields__})
        except (OSError, ValueError, TypeError): return ForeverState(last_error="state_recovery_reset")

    def _save_state(self, state: ForeverState) -> None:
        tmp=self.state_path.with_suffix(".tmp"); tmp.write_text(json.dumps(state.__dict__,indent=2,sort_keys=True)); os.replace(tmp,self.state_path)

    def _choose_area(self, state: ForeverState):
        now=time.time(); failures=state.area_failures or {}; cooldowns=state.area_cooldowns or {}; completed=set(state.completed_areas or [])
        areas=self.observatory.backlog(limit=65)
        eligible=[a for a in areas if cooldowns.get(a.area_id,0)<=now]
        if not eligible: eligible=areas
        # Prioritize evidenced/high-value work, but strongly penalize repeated failures.
        def score(a):
            f=failures.get(a.area_id,0); repeat_penalty=min(70,f*22); recent_penalty=12 if a.area_id==state.last_area_id else 0
            completion_bonus=0 if a.area_id in completed else 8
            return a.default_priority+completion_bonus-repeat_penalty-recent_penalty
        return max(eligible,key=score)

    def _cycle(self, state: ForeverState) -> ForeverState:
        snapshot=self.observatory.snapshot(); area=self._choose_area(state)
        objective=(f"Improve LUMO in area {area.area_id}: {area.title}. {area.description} "
                   f"Use evidence signals: {', '.join(area.evidence)}. Inspect first; make one small reversible improvement; "
                   "run focused tests and the regression suite; benchmark baseline versus candidate; promote only with evidence. "
                   "Do not repeat a previously rejected approach; use the prior failure evidence to choose a materially different approach.")
        self._activity("cycle_selected", cycle=state.cycles+1, area_id=area.area_id, area_title=area.title, model=self.model, findings=len(snapshot.findings), objective=objective)
        self.on_event(f"FOREVER cycle={state.cycles+1} area={area.area_id}:{area.title} model={self.model} findings={len(snapshot.findings)}")
        runtime=None; now=time.time(); failures=dict(state.area_failures or {}); cooldowns=dict(state.area_cooldowns or {}); completed=set(state.completed_areas or [])
        try:
            runtime=AutonomousImprovementRuntime(repository_root=self.repository_root,test_timeout_seconds=self.test_timeout,provider_name="ollama",model_name=self.model)
            results=self._run_with_resource_watchdog(runtime, objective, ImprovementBudget(max_wall_seconds=max(self.test_timeout+180,600),max_model_calls=2,max_candidates=1,max_test_timeout_seconds=self.test_timeout))
            result=results[-1] if results else None
            if result is None:
                status="no_result"; error="cycle returned no result"; cid=None; rid=None
            else:
                status=result.status.value if hasattr(result.status,"value") else str(result.status); error=result.error; cid=result.candidate_id; rid=result.run_id
                self._activity("cycle_result", cycle=state.cycles+1, status=status, candidate_id=cid, run_id=rid, error=error, result_metadata=getattr(result, "metadata", {}), decision=str(getattr(result, "decision", None)), benchmark=str(getattr(result, "benchmark", None)), tests_passed=getattr(result, "candidate_tests_passed", None))
            failures[area.area_id]=failures.get(area.area_id,0)+(0 if status=="promoted" else 1)
            if status=="promoted":
                completed.add(area.area_id); cooldowns.pop(area.area_id,None)
            else:
                # Exponential cooldown prevents a broken area monopolizing the forever loop.
                n=failures[area.area_id]; cooldowns[area.area_id]=now+min(86400.0,300.0*(2**min(n-1,8)))
            return ForeverState(cycles=state.cycles+1,promoted=state.promoted+(status=="promoted"),failed=state.failed+(status!="promoted"),
                last_status=status,last_run_id=rid,last_candidate_id=cid,last_error=error,last_area_id=area.area_id,last_area_title=area.title,
                updated_at=now,area_failures=failures,area_cooldowns=cooldowns,completed_areas=sorted(completed),worker_mode="single")
        except _ResourceAbort as exc:
            self._activity("cycle_paused_for_safety", reason=exc.reason, resource_snapshot=exc.snapshot, area_id=area.area_id)
            return ForeverState(cycles=state.cycles,promoted=state.promoted,failed=state.failed,last_status="paused",
                last_error=None,last_area_id=area.area_id,last_area_title=area.title,updated_at=time.time(),
                area_failures=failures,area_cooldowns=cooldowns,completed_areas=sorted(completed),worker_mode="single",
                paused_reason=exc.reason,last_resource_snapshot=exc.snapshot,last_activity_path=str(self.activity_path))
        except _ProgressAbort as exc:
            self._activity(
                "cycle_paused_for_progress",
                reason=exc.reason,
                elapsed_seconds=round(exc.elapsed_seconds, 1),
                area_id=area.area_id,
            )
            return ForeverState(
                cycles=state.cycles,
                promoted=state.promoted,
                failed=state.failed,
                last_status="paused",
                last_error=None,
                last_area_id=area.area_id,
                last_area_title=area.title,
                updated_at=time.time(),
                area_failures=failures,
                area_cooldowns=cooldowns,
                completed_areas=sorted(completed),
                worker_mode="single",
                paused_reason=exc.reason,
                last_resource_snapshot=None,
                last_activity_path=str(self.activity_path),
            )
        except Exception as exc:
            failures[area.area_id]=failures.get(area.area_id,0)+1; n=failures[area.area_id]; cooldowns[area.area_id]=now+min(86400.0,300.0*(2**min(n-1,8)))
            return ForeverState(cycles=state.cycles+1,promoted=state.promoted,failed=state.failed+1,last_status="error",last_error=f"{type(exc).__name__}: {exc}",
                last_area_id=area.area_id,last_area_title=area.title,updated_at=now,area_failures=failures,area_cooldowns=cooldowns,completed_areas=sorted(completed),worker_mode="single")
        finally:
            if runtime is not None: runtime.close()

    def run(self) -> int:
        with self.lock_path.open("w") as lock:
            try: fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError: self.on_event("FOREVER already running; refusing duplicate worker"); return 2
            state=self._load_state(); self._activity("worker_started", pid=os.getpid(), cycles=state.cycles, promoted=state.promoted, failed=state.failed); self.on_event(f"FOREVER resumed cycles={state.cycles} promoted={state.promoted} failed={state.failed}")
            while not self._stop:
                safe, reason, resource_snapshot = self._machine_safe()
                if not safe:
                    self._activity("paused_for_safety", reason=reason, resource_snapshot=resource_snapshot)
                    state=ForeverState(**{**state.__dict__, "last_status":"paused", "paused_reason":reason, "last_resource_snapshot":resource_snapshot, "last_activity_path":str(self.activity_path), "updated_at":time.time()})
                    self._save_state(state)
                    time.sleep(15)
                    continue
                state=self._cycle(state)
                state=ForeverState(**{**state.__dict__, "paused_reason":None, "last_resource_snapshot":resource_snapshot, "last_activity_path":str(self.activity_path)})
                self._save_state(state)
                delay=self.cycle_delay if state.last_status=="promoted" else self.idle_delay
                end=time.monotonic()+delay
                while not self._stop and time.monotonic()<end: time.sleep(min(5.0,max(0.1,end-time.monotonic())))
            return 0
