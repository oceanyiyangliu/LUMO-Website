from __future__ import annotations

import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Optional, Sequence
from concurrent.futures import Future, ThreadPoolExecutor

from ocean.domain.event_bus import EventBus
from ocean.core.ids import new_id
from ocean.domain.decision import Decision
from ocean.domain.event import Event
from ocean.domain.mission import Mission
from ocean.domain.task import Task
from ocean.planning.planner import Planner, PlanningRequest, PlanningResult
from ocean.planning.service import PlanningService
from eventing.sqlite_store import SQLiteEventStore
from persistence.sqlite import SQLiteRepository
from persistence.serializers.decision import DecisionSerializer
from persistence.serializers.improvement import ImprovementRunSerializer
from persistence.serializers.mission import MissionSerializer
from persistence.serializers.plan import PlanRevisionSerializer
from persistence.serializers.research import ResearchFindingSerializer
from persistence.serializers.task import TaskSerializer
from persistence.serializers.verification import VerificationSerializer
from persistence.serializers.work_graph import WorkGraphSerializer

from .benchmark import BenchmarkReport, BenchmarkResult, BenchmarkService
from .code_modification import (
    CandidateWorkspaceService,
    CodeModificationService,
    ProductionCodePromotionService,
)
from .coordinator import (
    AutonomousImprovementCoordinator,
    AutonomousImprovementRequest,
    AutonomousImprovementResult,
)
from .decision import ImprovementDecisionService
from .engine import SelfImprovementEngine
from .model_provider import (
    ImprovementModelProvider,
    ModelProviderBoundary,
    OllamaImprovementModelProvider,
)
from .recovery import ImprovementRecoveryService
from .research import (
    ResearchFinding,
    ResearchProvider,
    ResearchReport,
    ResearchSource,
    ResearchService,
)
from .test_execution import CandidateTestExecutionService
from .objective import EvidenceKind, ObjectiveContract
from .types import ImprovementHypothesis, ImprovementRun, ImprovementStatus
from .verification import CandidateVerificationService
from .repository_context import RepositoryContextService
from .observatory import ImprovementObservatory


class RuntimePlanner:
    """Minimal production planner for improvement missions.

    Planning remains deliberately deterministic at this boundary. The model
    provider proposes the actual improvement; the planner owns the mission
    decision and plan lifecycle.
    """

    def plan(self, request: PlanningRequest) -> PlanningResult:
        return PlanningResult(
            decision=Decision(
                mission_id=request.mission_id,
                kind="self_improvement",
                objective=request.objective,
                rationale="Autonomous improvement runtime execution plan.",
                confidence=1.0,
                evidence=("runtime-created improvement plan",),
            ),
            nodes=(),
            edges=(),
            metadata={"runtime_planner": True},
        )


class RuntimeResearchProvider:
    """Repository-local research provider.

    This deliberately avoids pretending that local repository inspection is
    external research. It provides deterministic evidence that the
    improvement target is the current repository.
    """

    def __init__(self, repository_root: Path) -> None:
        self._repository_root = repository_root

    def research(self, request) -> ResearchReport:
        return ResearchReport(
            candidate_id=request.candidate_id,
            findings=(
                ResearchFinding(
                    candidate_id=request.candidate_id,
                    claim=(
                        f"Improvement target is the repository at "
                        f"{self._repository_root.resolve()}"
                    ),
                    source=ResearchSource(
                        title="Current Ocean Agent OS repository",
                        uri=self._repository_root.resolve().as_uri(),
                        source_type="repository",
                        publisher="Ocean Agent OS",
                    ),
                    confidence=1.0,
                    evidence=(
                        f"repository={self._repository_root.resolve()}",
                        f"objective={request.objective}",
                    ),
                ),
            ),
            queries=request.queries,
            metadata={"runtime_research": True},
        )


_SAFE_CANDIDATE_ENV = frozenset({
    "PATH", "HOME", "TMPDIR", "TMP", "TEMP", "LANG", "LC_ALL", "LC_CTYPE",
    "USER", "LOGNAME", "VIRTUAL_ENV", "SystemRoot", "WINDIR", "COMSPEC",
})


class RuntimeBenchmarkProvider:
    """Deterministic benchmark based on the configured test command."""

    def __init__(self, command: Sequence[str], timeout_seconds: float) -> None:
        self._command = tuple(command)
        self._timeout_seconds = timeout_seconds

    @staticmethod
    def _child_environment(*, disable_pytest_plugins: bool = False) -> dict[str, str]:
        env = {key: value for key, value in os.environ.items() if key in _SAFE_CANDIDATE_ENV}
        # Nested pytest subprocesses must not inherit the parent's active-test
        # marker or coverage orchestration state. Those process-local values
        # can cause recursive collection/plugin behavior under the full suite.
        env.pop("PYTEST_CURRENT_TEST", None)
        env.pop("COVERAGE_PROCESS_START", None)
        # Candidate verification must never inherit the service's cloud
        # credentials. Tests must exercise the repository in a credential-free
        # environment, both for safety and deterministic regression behavior.
        if disable_pytest_plugins:
            env["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
        return env

    def _pytest_test_nodeids(self, workspace: Path) -> set[str]:
        """Collect pytest node IDs deterministically from a workspace."""
        try:
            completed = subprocess.run(
                (sys.executable, "-m", "pytest", "--collect-only", "-q"),
                cwd=workspace,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=self._timeout_seconds,
                check=False,
                env=self._child_environment(disable_pytest_plugins=True),
            )
        except (OSError, subprocess.TimeoutExpired):
            return set()

        if completed.returncode != 0:
            return set()

        return {
            line.strip()
            for line in completed.stdout.splitlines()
            if "::" in line.strip() and not line.strip().startswith("=")
        }

    def benchmark(self, request) -> BenchmarkReport:

        workspace = Path(request.workspace_root)
        baseline = Path(request.baseline_root)

        command = self._executable_command(self._command)
        started = time.perf_counter()
        try:
            completed = subprocess.run(
                command,
                cwd=workspace,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=self._timeout_seconds,
                check=False,
                env=self._child_environment(),
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            return self._failed_report(request, workspace, baseline, command, exc)
        passed = completed.returncode == 0
        duration_ms = (time.perf_counter() - started) * 1000.0

        implementation_files, implementation_lines = self._implementation_delta(
            workspace, baseline
        )

        results = [
            BenchmarkResult(
                name="test_quality",
                value=1.0 if passed else 0.0,
                unit="pass",
                higher_is_better=True,
                metadata={
                    "exit_code": completed.returncode,
                    "stdout": completed.stdout[-4000:],
                    "stderr": completed.stderr[-4000:],
                },
            ),
        ]
        performance_objective = any(
            marker in str(getattr(request, "objective", "")).lower()
            for marker in (
                "speed", "fast", "latency", "performance", "throughput",
                "slow", "overhead", "responsive", "optimiz",
            )
        )
        if performance_objective:
            results.append(
                BenchmarkResult(
                    name="test_duration_ms",
                    value=duration_ms,
                    unit="ms",
                    higher_is_better=False,
                    metadata={"measurement": "subprocess wall-clock duration"},
                )
            )

        differential = self._new_test_differential(workspace, baseline)
        results.append(
            BenchmarkResult(
                name="behavioral_regression_tests",
                value=float(differential["passing_candidate_failing_baseline"]),
                unit="tests",
                higher_is_better=True,
                metadata=differential,
            )
        )

        # Evidence-first repository quality signals. These are deterministic and
        # identical for baseline/candidate, so a candidate cannot gain credit
        # from simply changing more code. Lower is better for defect/legacy
        # counts; unchanged values are neutral.
        try:
            before_obs = ImprovementObservatory(baseline).snapshot()
            after_obs = ImprovementObservatory(workspace).snapshot()
            results.extend((
                BenchmarkResult("repository_findings", float(len(after_obs.findings)), "findings", False, {"baseline": len(before_obs.findings), "promotion_metric": False}),
                BenchmarkResult("todo_count", float(after_obs.todo_count), "markers", False, {"baseline": before_obs.todo_count, "promotion_metric": False}),
                BenchmarkResult("legacy_provider_hits", float(after_obs.stale_provider_hits), "references", False, {"baseline": before_obs.stale_provider_hits, "promotion_metric": False}),
                BenchmarkResult("hardcoded_ui_values", float(after_obs.duplicate_css_values), "declarations", False, {"baseline": before_obs.duplicate_css_values, "promotion_metric": False}),
            ))
        except Exception as exc:
            # A diagnostic benchmark failing is evidence of an observability
            # problem, not permission to silently pass the candidate.
            results.append(BenchmarkResult("observatory_failure", 1.0, "failure", False, {"error": str(exc), "promotion_metric": False}))

        # Change size is provenance, not a success metric. A larger diff is
        # not an improvement and must never be able to buy promotion credit.
        change_metadata = {
            "implementation_changed_files": implementation_files if passed else 0,
            "implementation_changed_lines": implementation_lines if passed else 0,
            "credited_only_when_tests_pass": True,
            "test_only_changes_not_credited": True,
            "promotion_metric": False,
        }

        return BenchmarkReport(
            candidate_id=request.candidate_id,
            results=tuple(results),
            metadata={
                "command": list(self._command),
                "executed_command": list(command),
                "workspace": str(workspace),
                "baseline": str(baseline),
                "change_provenance": change_metadata,
            },
        )

    def _new_test_differential(self, candidate: Path, baseline: Path) -> dict[str, Any]:
        """Prove behavioral change with a candidate-only regression test.

        New tests are evidence only when they pass against the candidate and
        fail against an otherwise identical baseline. Existing tests remain
        immutable at the code-modification boundary, so this gate cannot be
        satisfied by weakening the old suite.
        """
        candidate_ids = self._pytest_test_nodeids(candidate)
        baseline_ids = self._pytest_test_nodeids(baseline)
        new_ids = sorted(candidate_ids - baseline_ids)
        if not new_ids:
            return {
                "new_test_count": 0,
                "passing_candidate_failing_baseline": 0,
                "candidate_new_tests_pass": False,
                "baseline_new_tests_fail": False,
                "new_test_ids": [],
            }

        relative_files = sorted({item.split("::", 1)[0] for item in new_ids})
        with tempfile.TemporaryDirectory(prefix="ocean-baseline-tests-") as temp:
            shadow = Path(temp)
            shutil.copytree(baseline, shadow, dirs_exist_ok=True)
            for relative_name in relative_files:
                source = candidate / relative_name
                target = shadow / relative_name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)

            selected = tuple(new_ids)
            baseline_result = subprocess.run(
                self._executable_command((*self._command, *selected)),
                cwd=shadow,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=self._timeout_seconds,
                check=False,
                env=self._child_environment(disable_pytest_plugins=True),
            )

        candidate_result = subprocess.run(
            self._executable_command((*self._command, *selected)),
            cwd=candidate,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=self._timeout_seconds,
            check=False,
            env=self._child_environment(disable_pytest_plugins=True),
        )
        candidate_pass = candidate_result.returncode == 0
        baseline_fail = baseline_result.returncode != 0
        return {
            "new_test_count": len(new_ids),
            "passing_candidate_failing_baseline": len(new_ids) if candidate_pass and baseline_fail else 0,
            "candidate_new_tests_pass": candidate_pass,
            "baseline_new_tests_fail": baseline_fail,
            "new_test_ids": new_ids,
            "candidate_stdout": candidate_result.stdout[-3000:],
            "baseline_stdout": baseline_result.stdout[-3000:],
        }

    @staticmethod
    def _implementation_delta(candidate: Path, baseline: Path) -> tuple[int, int]:
        """Count changed production-code files/lines, excluding tests/docs."""
        excluded_dirs = {".git", ".venv", ".ocean", "__pycache__", ".pytest_cache", "node_modules"}
        excluded_prefixes = ("test_",)
        implementation_suffixes = {
            ".py", ".pyi", ".swift", ".ts", ".tsx", ".js", ".jsx", ".mjs",
            ".css", ".scss", ".html", ".json", ".toml", ".yaml", ".yml", ".sh",
        }
        candidate_files = {
            p.relative_to(candidate)
            for p in candidate.rglob("*")
            if p.is_file() and not any(part in excluded_dirs for part in p.parts)
        }
        baseline_files = {
            p.relative_to(baseline)
            for p in baseline.rglob("*")
            if p.is_file() and not any(part in excluded_dirs for part in p.parts)
        }
        changed_files = 0
        changed_lines = 0
        for relative in sorted(candidate_files | baseline_files, key=str):
            if relative.parts and (
                relative.parts[0] in {"tests", "test"} or
                relative.name.startswith(excluded_prefixes) or
                relative.suffix.lower() in {".md", ".txt"} or
                relative.suffix.lower() not in implementation_suffixes
            ):
                continue
            before_path = baseline / relative
            after_path = candidate / relative
            try:
                before = before_path.read_text(encoding="utf-8").splitlines() if before_path.is_file() else []
                after = after_path.read_text(encoding="utf-8").splitlines() if after_path.is_file() else []
            except UnicodeDecodeError:
                # Binary implementation assets are valid repository changes, but
                # they cannot be meaningfully line-diffed as UTF-8 source.
                before_bytes = before_path.read_bytes() if before_path.is_file() else b""
                after_bytes = after_path.read_bytes() if after_path.is_file() else b""
                if before_bytes != after_bytes:
                    changed_files += 1
                continue
            if before == after:
                continue
            changed_files += 1
            import difflib
            changed_lines += sum(
                1 for line in difflib.ndiff(before, after)
                if (line.startswith("+ ") or line.startswith("- ")) and not line.startswith("? ")
            )
        return changed_files, changed_lines

    @staticmethod
    def _executable_command(command: Sequence[str]) -> tuple[str, ...]:
        if command[0] == "python" and shutil.which("python") is None:
            return (sys.executable, *command[1:])
        return tuple(command)

    def _failed_report(self, request, workspace, baseline, command, error) -> BenchmarkReport:
        return BenchmarkReport(
            candidate_id=request.candidate_id,
            results=(
                BenchmarkResult(
                    name="test_quality",
                    value=0.0,
                    unit="pass",
                    higher_is_better=True,
                    metadata={"exit_code": None, "stdout": "", "stderr": str(error)},
                ),
            ),
            metadata={
                "command": list(self._command),
                "executed_command": list(command),
                "workspace": str(workspace),
                "baseline": str(baseline),
            },
        )


@dataclass
class ImprovementBudget:
    """Hard limits for long-running self-improvement sessions.

    The defaults are deliberately conservative: local inference, one proposal
    per candidate, and a small experiment count. A session can therefore run
    for hours without silently turning into an unbounded API bill.
    """

    max_wall_seconds: float = 10 * 60 * 60
    max_model_calls: int = 8
    max_candidates: int = 8
    max_test_timeout_seconds: float = 120.0
    max_concurrent_candidates: int = 1
    max_proposal_attempts: int = 2

    def __post_init__(self) -> None:
        if self.max_wall_seconds <= 0:
            raise ValueError("max_wall_seconds must be > 0")
        if self.max_model_calls < 1 or self.max_candidates < 1:
            raise ValueError("model/candidate budgets must be >= 1")
        if self.max_test_timeout_seconds <= 0:
            raise ValueError("max_test_timeout_seconds must be > 0")
        if self.max_concurrent_candidates != 1:
            raise ValueError("overnight improvement currently requires sequential candidates")
        if self.max_proposal_attempts < 1:
            raise ValueError("max_proposal_attempts must be >= 1")



@dataclass
class AutonomousImprovementRuntime:
    """Application boundary that wires the autonomous improvement system."""

    repository_root: Path
    baseline_root: Optional[Path] = None
    test_command: tuple[str, ...] = ("python", "-m", "pytest", "-q")
    test_timeout_seconds: float = 120.0
    provider_name: Optional[str] = None
    model_name: Optional[str] = None

    def __post_init__(self) -> None:
        self.repository_root = self.repository_root.resolve()
        self.baseline_root = (
            self.repository_root
            if self.baseline_root is None
            else self.baseline_root.resolve()
        )

        if not self.repository_root.is_dir():
            raise ValueError(
                f"repository_root does not exist: {self.repository_root}"
            )
        if not self.baseline_root.is_dir():
            raise ValueError(
                f"baseline_root does not exist: {self.baseline_root}"
            )
        if not self.test_command:
            raise ValueError("test_command must not be empty")

        # Packaged LUMO must never mutate its signed application bundle. The
        # native launcher supplies LUMO_STATE_DIR in Application Support; keep
        # development/CLI behavior unchanged when no external state directory
        # is configured.
        configured_state = os.environ.get("LUMO_STATE_DIR", "").strip()
        database_root = Path(configured_state).expanduser() if configured_state else self.repository_root / ".ocean"
        if not database_root.is_absolute():
            database_root = (self.repository_root / database_root).resolve()
        database_path = database_root / "improvement.sqlite3"
        database_path.parent.mkdir(parents=True, exist_ok=True)

        self.database_path = database_path
        self._connection = sqlite3.connect(
            str(database_path),
            check_same_thread=False,
        )

        self.events = EventBus(
            store=SQLiteEventStore(self._connection),
        )

        self.missions = SQLiteRepository(
            self._connection, MissionSerializer(), "missions"
        )
        self.decisions = SQLiteRepository(
            self._connection, DecisionSerializer(), "decisions"
        )
        self.tasks = SQLiteRepository(
            self._connection, TaskSerializer(), "tasks"
        )
        self.work_graphs = SQLiteRepository(
            self._connection, WorkGraphSerializer(), "work_graphs"
        )
        self.plans = SQLiteRepository(
            self._connection, PlanRevisionSerializer(), "plan_revisions"
        )
        self.runs = SQLiteRepository(
            self._connection, ImprovementRunSerializer(), "improvement_runs"
        )
        self.verifications = SQLiteRepository(
            self._connection, VerificationSerializer(), "verifications"
        )
        self.findings = SQLiteRepository(
            self._connection,
            ResearchFindingSerializer(),
            "research_findings",
        )

        self.planning = PlanningService(
            missions=self.missions,
            decisions=self.decisions,
            tasks=self.tasks,
            work_graphs=self.work_graphs,
            plan_revisions=self.plans,
            events=self.events,
        )

        self.planner: Planner = RuntimePlanner()
        self.research_provider: ResearchProvider = RuntimeResearchProvider(
            self.repository_root
        )
        self.benchmark_provider = RuntimeBenchmarkProvider(
            self.test_command,
            self.test_timeout_seconds,
        )

        # Autonomous improvement is local-only. The installed fleet and
        # resource governor choose the model; cloud providers are retired.
        provider_name = (self.provider_name or os.getenv("LUMO_IMPROVEMENT_PROVIDER", "ollama")).strip().lower()
        if provider_name != "ollama":
            raise ValueError("LUMO autonomous improvement is local-only; use provider 'ollama'")
        model_name = self.model_name or os.getenv("LUMO_IMPROVEMENT_MODEL") or "qwen3:0.6b"
        self.model_provider = OllamaImprovementModelProvider(
            model=model_name,
            timeout=float(os.getenv("LUMO_IMPROVEMENT_MODEL_TIMEOUT", "180")),
        )

        self.research = ResearchService(
            findings=self.findings,
            events=self.events,
        )
        verification = CandidateVerificationService(
            verifications=self.verifications,
            events=self.events,
        )
        self.engine = SelfImprovementEngine(
            missions=self.missions,
            plan_revisions=self.plans,
            runs=self.runs,
            planning=self.planning,
            events=self.events,
            decisions=self.decisions,
            work_graphs=self.work_graphs,
            verifications=self.verifications,
        )
        self.repository_context = RepositoryContextService()
        self.production_code = ProductionCodePromotionService()

        self.recovery = ImprovementRecoveryService(
            runs=self.runs,
            events=self.events,
        )

        self.coordinator = AutonomousImprovementCoordinator(
            engine=self.engine,
            research=self.research,
            model=ModelProviderBoundary(provider=self.model_provider),
            code_modification=CodeModificationService(
                workspaces=CandidateWorkspaceService(),
            ),
            test_execution=CandidateTestExecutionService(),
            verification=verification,
            benchmark=BenchmarkService(),
            decision=ImprovementDecisionService(),
            events=self.events,
            production_code=self.production_code,
        )

    def close(self) -> None:
        """Close the durable runtime database connection."""
        connection = getattr(self, "_connection", None)

        if connection is not None:
            connection.close()
            self._connection = None

    def __enter__(self) -> "AutonomousImprovementRuntime":
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        self.close()

    def improve_many(
        self,
        objectives: Sequence[str],
        *,
        max_workers: Optional[int] = None,
        parent_mission_id: Optional[str] = None,
    ) -> tuple[AutonomousImprovementResult, ...]:
        """Run independent improvement candidates concurrently.

        Each candidate receives its own mission, candidate ID and filesystem
        workspace. Durable state remains the source of truth; failures are
        returned per objective instead of cancelling unrelated work.
        """
        normalized = tuple(dict.fromkeys(item.strip() for item in objectives if item and item.strip()))
        if not normalized:
            return ()
        workers = max_workers or min(32, len(normalized))
        if workers <= 0:
            raise ValueError("max_workers must be positive")
        with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="ocean-improve") as pool:
            futures: tuple[Future[AutonomousImprovementResult], ...] = tuple(
                pool.submit(self.improve, objective, parent_mission_id=parent_mission_id)
                for objective in normalized
            )
            return tuple(future.result() for future in futures)

    def improve_overnight(
        self,
        objective: str,
        *,
        budget: ImprovementBudget | None = None,
        parent_mission_id: Optional[str] = None,
    ) -> tuple[AutonomousImprovementResult, ...]:
        """Run a bounded, local-first improvement campaign.

        This is intentionally sequential and budgeted. By default it makes at
        most eight local model calls, one per candidate, for up to ten hours.
        Cloud inference is never selected by this method unless the caller
        explicitly configured the runtime provider to OpenAI.
        """
        budget = budget or ImprovementBudget()
        started = time.monotonic()
        results: list[AutonomousImprovementResult] = []
        failure_history: list[str] = []
        attempts = 0
        model_calls_reserved = 0
        while attempts < budget.max_candidates:
            remaining = budget.max_wall_seconds - (time.monotonic() - started)
            if remaining <= 0:
                break
            remaining_model_calls = budget.max_model_calls - model_calls_reserved
            if remaining_model_calls <= 0:
                break
            proposal_attempts = min(
                budget.max_proposal_attempts,
                remaining_model_calls,
            )
            model_calls_reserved += proposal_attempts
            attempts += 1
            feedback = "\n".join(failure_history[-5:])[-12000:]
            try:
                result = self.improve(
                    objective,
                    parent_mission_id=parent_mission_id,
                    max_proposal_attempts=proposal_attempts,
                    prior_failure_feedback=feedback,
                )
            except Exception as exc:
                failure_history.append(f"campaign attempt {attempts}: {type(exc).__name__}: {exc}")
                continue
            results.append(result)
            if result.status != ImprovementStatus.PROMOTED:
                reason = result.error or ("; ".join(result.decision.reasons) if result.decision else "no promotion")
                failure_history.append(f"candidate {result.candidate_id}: {reason}")
        return tuple(results)

    def improve(
        self,
        objective: str,
        *,
        mission_id: Optional[str] = None,
        improvement_run_id: Optional[str] = None,
        improvement_candidate_id: Optional[str] = None,
        parent_mission_id: Optional[str] = None,
        hypothesis: Optional[str] = None,
        rationale: Optional[str] = None,
        objective_id: Optional[str] = None,
        work_type: str = "implementation",
        acceptance_criteria: Optional[Sequence[str]] = None,
        evidence_policy: Optional[Sequence[EvidenceKind | str]] = None,
        max_proposal_attempts: int = 2,
        prior_failure_feedback: str = "",
    ) -> AutonomousImprovementResult:
        objective = objective.strip()
        if not objective:
            raise ValueError("objective must not be empty")

        improvement_run_id = improvement_run_id or new_id("improvement_run")
        improvement_candidate_id = improvement_candidate_id or new_id("improvement")

        mission = Mission(
            goal=objective,
            metadata={
                "autonomous_improvement": True,
                "runtime": "ocean",
            },
        )

        improvement_task = Task(
            title=f"Implement improvement: {objective}",
            description=(
                "Execute and validate the autonomous improvement objective "
                "within an isolated candidate environment."
            ),
            mission_id=mission.id,
            metadata={
                "autonomous_improvement": True,
                "runtime": "ocean",
                "improvement_objective": objective,
                "parent_mission_id": parent_mission_id,
            },
        )
        mission.add_task(improvement_task.id)

        self.missions.save(mission)
        self.tasks.save(improvement_task)

        self.runs.save(
            ImprovementRun(
                id=improvement_run_id,
                mission_id=mission.id,
                candidate_id=improvement_candidate_id,
                status=ImprovementStatus.CREATED,
                metadata={
                    "runtime": "ocean",
                    "autonomous": True,
                    "objective": objective,
                    "parent_mission_id": parent_mission_id,
                    "hypothesis": (
                        hypothesis.strip()
                        if hypothesis and hypothesis.strip()
                        else None
                    ),
                    "rationale": (
                        rationale.strip()
                        if rationale and rationale.strip()
                        else None
                    ),
                    "repository_root": str(self.repository_root),
                    "baseline_root": str(self.baseline_root),
                    "test_command": list(self.test_command),
                    "test_timeout_seconds": self.test_timeout_seconds,
                    "source_plan_revision_id": None,
                },
            )
        )

        source_decision = self.planning.create_decision(
            mission_id=mission.id,
            kind="baseline",
            objective=objective,
            rationale="Initial autonomous improvement baseline.",
            confidence=1.0,
        )
        source_plan, _ = self.planning.create_plan(
            mission_id=mission.id,
            decision_id=source_decision.id,
            nodes=(),
            edges=(),
            metadata={"autonomous_improvement_baseline": True},
        )
        source_plan = self.planning.propose(
            source_plan.id,
            reason="initial autonomous improvement baseline",
        )
        self.planning.activate(
            source_plan.id,
            reason="initial autonomous improvement baseline",
        )

        repository_context = self.repository_context.build(
            self.repository_root,
            objective,
        )

        improvement_hypothesis = ImprovementHypothesis(
            objective=objective,
            hypothesis=(
                hypothesis.strip()
                if hypothesis and hypothesis.strip()
                else f"Implement a validated improvement for: {objective}"
            ),
            rationale=(
                rationale.strip()
                if rationale and rationale.strip()
                else "Autonomous model-generated improvement proposal."
            ),
            success_criteria=("candidate tests pass",),
        )

        run = self.runs.get(improvement_run_id)
        if run is None:
            raise RuntimeError("failed to persist autonomous improvement run")

        self.runs.save(
            ImprovementRun(
                id=run.id,
                mission_id=run.mission_id,
                candidate_id=run.candidate_id,
                status=run.status,
                evaluation=run.evaluation,
                promoted_plan_revision_id=run.promoted_plan_revision_id,
                metadata={
                    **dict(run.metadata),
                    "source_plan_revision_id": source_plan.id,
                },
            )
        )

        request = AutonomousImprovementRequest(
            mission_id=mission.id,
            objective=objective,
            hypothesis=improvement_hypothesis,
            planner=self.planner,
            model_provider=self.model_provider,
            research_provider=self.research_provider,
            benchmark_provider=self.benchmark_provider,
            repository_root=self.repository_root,
            baseline_root=self.baseline_root,
            research_queries=(objective,),
            test_command=self.test_command,
            test_timeout_seconds=self.test_timeout_seconds,
            required_evidence=(),
            minimum_improvements=1,
            source_plan_revision_id=source_plan.id,
            objective_contract=ObjectiveContract(
                objective_id=(objective_id or improvement_candidate_id),
                objective=objective,
                work_type=work_type,
                acceptance_criteria=tuple(acceptance_criteria or ("candidate tests pass",)),
                evidence_policy=tuple(
                    EvidenceKind(item) if isinstance(item, str) else item
                    for item in (evidence_policy or (EvidenceKind.TESTS, EvidenceKind.BENCHMARK))
                ),
                minimum_improvements=(1 if EvidenceKind.BENCHMARK in tuple(
                    EvidenceKind(item) if isinstance(item, str) else item
                    for item in (evidence_policy or (EvidenceKind.TESTS, EvidenceKind.BENCHMARK))
                ) else 0),
            ),
            metadata={
                "run_id": improvement_run_id,
                "candidate_id": improvement_candidate_id,
                "runtime": "ocean",
                "autonomous": True,
                "parent_mission_id": parent_mission_id,
                "repository_context": repository_context.as_prompt_text(),
                "failure_feedback": prior_failure_feedback,
            },
            max_proposal_attempts=max_proposal_attempts,
        )
        return self.coordinator.run(request)
