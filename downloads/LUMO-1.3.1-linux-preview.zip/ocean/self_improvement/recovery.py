from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from ocean.domain.event import Event
from persistence.repository import Repository

from .types import ImprovementCheckpoint, ImprovementRun, ImprovementStatus


@dataclass(frozen=True)
class RecoveryCandidate:
    run_id: str
    mission_id: str
    candidate_id: str
    status: ImprovementStatus


class ImprovementRecoveryService:
    """Finds durable non-terminal improvement runs after process interruption."""

    def __init__(self, *, runs: Repository[ImprovementRun], events) -> None:
        self._runs = runs
        self._events = events

    def incomplete(self) -> tuple[RecoveryCandidate, ...]:
        candidates = []

        for run in self._runs.list():
            if run.status.terminal:
                continue

            candidates.append(
                RecoveryCandidate(
                    run_id=run.id,
                    mission_id=run.mission_id,
                    candidate_id=run.candidate_id,
                    status=run.status,
                )
            )

        return tuple(candidates)

    def get(self, run_id: str) -> Optional[RecoveryCandidate]:
        run = self._runs.get(run_id)

        if run is None or run.status.terminal:
            return None

        return RecoveryCandidate(
            run_id=run.id,
            mission_id=run.mission_id,
            candidate_id=run.candidate_id,
            status=run.status,
        )

    def checkpoint(
        self,
        *,
        run: ImprovementRun,
        phase: ImprovementStatus,
        context: Optional[dict] = None,
    ) -> ImprovementCheckpoint:
        """Persist a resumable checkpoint on the improvement run."""
        updated = ImprovementRun(
            id=run.id,
            mission_id=run.mission_id,
            candidate_id=run.candidate_id,
            status=run.status,
            evaluation=run.evaluation,
            promoted_plan_revision_id=run.promoted_plan_revision_id,
            metadata={
                **dict(run.metadata),
                "recovery_checkpoint": {
                    "phase": phase.value,
                    "context": dict(context or {}),
                },
            },
        )

        self._runs.save(updated)

        self._events.publish(
            Event(
                type="ImprovementCheckpointCreated",
                payload={
                    "run_id": run.id,
                    "mission_id": run.mission_id,
                    "candidate_id": run.candidate_id,
                    "phase": phase.value,
                    "context": dict(context or {}),
                },
            )
        )

        return ImprovementCheckpoint(
            run_id=run.id,
            phase=phase,
            context=dict(context or {}),
        )

    def mark_recovery_started(self, candidate: RecoveryCandidate) -> None:
        self._events.publish(
            Event(
                type="ImprovementRecoveryStarted",
                payload={
                    "run_id": candidate.run_id,
                    "mission_id": candidate.mission_id,
                    "candidate_id": candidate.candidate_id,
                    "status": candidate.status.value,
                },
            )
        )
