from __future__ import annotations

from dataclasses import dataclass, field, asdict
import json
from pathlib import Path
import time
from typing import Any, Mapping, Optional, Protocol

from ocean.core.ids import new_id
from ocean.domain.event import Event

from ocean.planning.planner import Planner

from .benchmark import (
    BenchmarkComparisonReport,
    BenchmarkProvider,
    BenchmarkReport,
    BenchmarkRequest,
    BenchmarkService,
)
from .code_modification import (
    CodeModificationProvider,
    CodeModificationRequest,
    CodeModificationService,
    CandidateWorkspaceService,
    ProductionCodePromotionService,
)
from .decision import (
    ImprovementDecision,
    ImprovementDecisionRequest,
    ImprovementDecisionService,
)
from .engine import SelfImprovementEngine
from .model_provider import (
    ImprovementModelProvider,
    ImprovementModelRequest,
    ModelProviderBoundary,
)
from .research import (
    ResearchProvider,
    ResearchRequest,
    ResearchService,
)
from .test_execution import (
    CandidateTestExecutionRequest,
    CandidateTestExecutionService,
)
from .objective import EvidenceKind, ObjectiveContract
from .types import (
    ImprovementCandidate,
    ImprovementHypothesis,
    ImprovementRun,
)
from .verification import CandidateVerificationService


@dataclass(frozen=True)
class AutonomousImprovementRequest:
    mission_id: str
    objective: str
    hypothesis: ImprovementHypothesis
    planner: Planner
    model_provider: ImprovementModelProvider
    research_provider: ResearchProvider
    benchmark_provider: BenchmarkProvider
    repository_root: Path
    baseline_root: Path

    research_queries: tuple[str, ...] = ()
    research_constraints: Mapping[str, Any] = field(default_factory=dict)

    code_constraints: Mapping[str, Any] = field(default_factory=dict)
    test_command: tuple[str, ...] = ("python", "-m", "pytest", "-q")
    test_timeout_seconds: float = 120.0

    required_evidence: tuple[str, ...] = ()
    minimum_improvements: int = 1
    minimum_score: Optional[float] = None
    score: Optional[float] = None

    source_plan_revision_id: Optional[str] = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    objective_contract: Optional[ObjectiveContract] = None
    max_proposal_attempts: int = 2

    def __post_init__(self) -> None:
        if not self.mission_id.strip():
            raise ValueError("mission_id must not be empty")
        if not self.objective.strip():
            raise ValueError("objective must not be empty")


@dataclass(frozen=True)
class AutonomousImprovementResult:
    run_id: str
    candidate_id: str
    status: str
    decision: Optional[ImprovementDecision]
    benchmark: Optional[BenchmarkComparisonReport]
    candidate_tests_passed: bool
    promoted_plan_revision_id: Optional[str]
    workspace_root: Optional[str]
    error: Optional[str] = None
    metadata: Mapping[str, Any] = field(default_factory=dict)


class AutonomousImprovementCoordinator:
    """
    Orchestrates the bounded autonomous improvement lifecycle.

    The coordinator is deliberately NOT a safety authority.

    Every dangerous operation is delegated to an existing boundary:

        research
        model proposal
        candidate isolation/planning
        candidate workspace mutation
        candidate test execution
        verification
        benchmark comparison
        deterministic decision
        promotion/rollback

    The model provider remains untrusted.
    Production mutation remains exclusively behind SelfImprovementEngine.
    """

    def __init__(
        self,
        *,
        engine: SelfImprovementEngine,
        research: ResearchService,
        model: ModelProviderBoundary,
        code_modification: CodeModificationService,
        test_execution: CandidateTestExecutionService,
        verification: CandidateVerificationService,
        benchmark: BenchmarkService,
        decision: ImprovementDecisionService,
        events,
        workspace_service: Optional[CandidateWorkspaceService] = None,
        production_code: Optional[ProductionCodePromotionService] = None,
    ) -> None:
        self._engine = engine
        self._research = research
        self._model = model
        self._code_modification = code_modification
        self._test_execution = test_execution
        self._verification = verification
        self._benchmark = benchmark
        self._decision = decision
        self._events = events
        # Human-readable transparency stream: every lifecycle event/checkpoint
        # is mirrored to a durable JSONL activity ledger so the autonomous team
        # is inspectable without reverse-engineering the event database.
        self._activity_path: Path | None = None
        self._workspace_service = workspace_service
        self._production_code = production_code

    def run(
        self,
        request: AutonomousImprovementRequest,
    ) -> AutonomousImprovementResult:
        self._validate_request(request)
        self._activity_path = Path(request.repository_root).resolve() / ".ocean" / "self_improvement_activity.jsonl"
        self._activity_path.parent.mkdir(parents=True, exist_ok=True)
        self._write_activity("run_boundary_entered", {"objective": request.objective, "mission_id": request.mission_id})

        if self._production_code is not None:
            # Recover any filesystem promotion journal left in the applied
            # state by a prior crash before starting another improvement.
            self._production_code.recover_incomplete(request.repository_root)

        candidate_id = str(
            request.metadata.get("candidate_id") or new_id("improvement")
        )
        run_id = str(
            request.metadata.get("run_id") or new_id("improvement_run")
        )

        self._publish(
            "ImprovementAttemptStarted",
            {
                "run_id": run_id,
                "candidate_id": candidate_id,
                "mission_id": request.mission_id,
                "objective": request.objective,
                "metadata": dict(request.metadata),
            },
            request.mission_id,
            run_id,
        )

        research_report = self._research.conduct(
            ResearchRequest(
                candidate_id=candidate_id,
                objective=request.objective,
                queries=request.research_queries,
                constraints=request.research_constraints,
                metadata={
                    **dict(request.metadata),
                    "run_id": run_id,
                },
            ),
            request.research_provider,
        )

        research_evidence = self._research.evidence_for_candidate(
            candidate_id
        )
        self._write_activity("research_completed", {
            "run_id": run_id,
            "candidate_id": candidate_id,
            "finding_count": len(research_report.findings),
            "findings": [getattr(item, "__dict__", str(item)) for item in research_report.findings],
            "queries": list(getattr(research_report, "queries", ())),
        })

        baseline_benchmark = None
        if (
            request.objective_contract is None
            or EvidenceKind.BENCHMARK in request.objective_contract.requires
        ):
            baseline_benchmark = self._benchmark.run(
                request=BenchmarkRequest(
                    candidate_id=candidate_id,
                    objective=request.objective,
                    workspace_root=str(request.baseline_root.resolve()),
                    baseline_root=str(request.baseline_root.resolve()),
                    constraints={"run_id": run_id, "baseline": True},
                ),
                provider=request.benchmark_provider,
            )

        baseline_metrics = {
            result.name: result.value
            for result in (baseline_benchmark.results if baseline_benchmark else ())
        }
        self._write_activity("baseline_benchmarked", {
            "run_id": run_id,
            "candidate_id": candidate_id,
            "metrics": baseline_metrics,
            "report": getattr(baseline_benchmark, "__dict__", None),
        })

        model_request_metadata = {
            **dict(request.metadata),
            "run_id": run_id,
            "research_finding_count": len(research_report.findings),
        }
        failure_feedback = str(request.metadata.get("failure_feedback", ""))
        model_proposal = None
        proposal_errors: list[str] = []
        for attempt in range(request.max_proposal_attempts):
            try:
                model_proposal = self._model.propose(
                    ImprovementModelRequest(
                        candidate_id=candidate_id,
                        objective=request.objective,
                        constraints=tuple(request.hypothesis.constraints.keys()),
                        research_evidence=research_evidence,
                        baseline_metrics=baseline_metrics,
                        metadata={
                            **model_request_metadata,
                            "proposal_attempt": attempt + 1,
                        },
                        repository_context=str(request.metadata.get("repository_context", "")),
                        failure_feedback=failure_feedback,
                    )
                )
                break
            except Exception as exc:
                proposal_errors.append(f"attempt {attempt + 1}: {type(exc).__name__}: {exc}")
                if attempt == request.max_proposal_attempts - 1:
                    reason = "; ".join(proposal_errors)
                    rejected = self._engine.reject_run(
                        run_id=run_id,
                        reason="model proposal failed after bounded retry",
                        metadata={"proposal_errors": proposal_errors},
                    )
                    return AutonomousImprovementResult(
                        run_id=run_id,
                        candidate_id=candidate_id,
                        status=getattr(rejected.status, "value", str(rejected.status)),
                        decision=None,
                        benchmark=None,
                        candidate_tests_passed=False,
                        promoted_plan_revision_id=None,
                        workspace_root=None,
                        error=reason,
                        metadata={"proposal_attempts": len(proposal_errors)},
                    )
                failure_feedback = (
                    "The previous proposal was rejected before candidate execution. "
                    "Correct the failure exactly; do not weaken any safety or verification boundary. "
                    + " | ".join(proposal_errors)
                )
                self._publish(
                    "ImprovementProposalRetryRequested",
                    {
                        "run_id": run_id,
                        "candidate_id": candidate_id,
                        "attempt": attempt + 2,
                        "failure_feedback": failure_feedback,
                    },
                    request.mission_id,
                    run_id,
                )

        if model_proposal is None:
            raise RuntimeError("model proposal was not produced")

        self._write_activity("model_proposal_completed", {
            "run_id": run_id,
            "candidate_id": candidate_id,
            "rationale": model_proposal.rationale,
            "hypothesis": getattr(model_proposal.hypothesis, "__dict__", str(model_proposal.hypothesis)),
            "code_modification": getattr(model_proposal.code_modification, "__dict__", str(model_proposal.code_modification)),
            "proposal_attempts": len(proposal_errors) + 1,
        })

        if model_proposal.hypothesis.objective != request.hypothesis.objective:
            raise ValueError(
                "model proposal objective differs from requested objective"
            )

        candidate = self._engine.create_candidate(
            mission_id=request.mission_id,
            hypothesis=model_proposal.hypothesis,
            planner=request.planner,
            source_plan_revision_id=request.source_plan_revision_id,
            metadata={
                **dict(request.metadata),
                "run_id": run_id,
                "coordinator": "autonomous_improvement_v0_1",
                "model_rationale": model_proposal.rationale,
                "research_evidence": research_evidence,
                "objective_contract": (
                    request.objective_contract.objective_id
                    if request.objective_contract is not None else None
                ),
            },
            candidate_id=candidate_id,
            run_id=run_id,
        )

        # The candidate is the first point at which every preceding stage has
        # a durable identity. Record completed research/proposal facts without
        # persisting untrusted partial model text.
        self._checkpoint(
            run_id,
            "candidate_created",
            {
                "candidate_id": candidate.id,
                "candidate_mission_id": candidate.candidate_mission_id,
                "candidate_plan_revision_id": candidate.candidate_plan_revision_id,
                "research_finding_count": len(research_report.findings),
                "proposal_recorded": True,
            },
        )

        workspace = None

        try:
            workspace, modification = (
                self._code_modification.generate_and_apply(
                    request=CodeModificationRequest(
                        candidate_id=candidate.id,
                        objective=request.objective,
                        repository_root=request.repository_root,
                        constraints={
                            **dict(request.code_constraints),
                            "run_id": run_id,
                        },
                    ),
                    provider=_ProposalCodeModificationProvider(
                        model_proposal.code_modification
                    ),
                )
            )
            self._checkpoint(
                run_id,
                "modification_applied",
                {
                    "candidate_id": candidate.id,
                    "workspace_root": str(workspace.root),
                    "changed_paths": [change.path for change in modification.changes],
                },
            )

            test_result = self._test_execution.run(
                CandidateTestExecutionRequest(
                    candidate_id=candidate.id,
                    workspace_root=str(workspace.root),
                    command=request.test_command,
                    timeout_seconds=request.test_timeout_seconds,
                    metadata={
                        "run_id": run_id,
                        "modification_rationale": modification.rationale,
                    },
                )
            )
            self._checkpoint(
                run_id,
                "test_completed",
                {
                    "candidate_id": candidate.id,
                    "passed": test_result.passed,
                    "exit_code": test_result.exit_code,
                    "timed_out": test_result.timed_out,
                },
            )

            task_id = self._candidate_task_for_verification(candidate)

            verification = self._verification.record(
                candidate_id=candidate.id,
                candidate_mission_id=candidate.candidate_mission_id,
                candidate_plan_revision_id=candidate.candidate_plan_revision_id,
                task_id=task_id,
                passed=test_result.passed,
                evidence=self._test_evidence(test_result),
                execution_id=None,
                method="candidate_test_execution",
                metadata={
                    "run_id": run_id,
                    "exit_code": test_result.exit_code,
                    "timed_out": test_result.timed_out,
                    "duration_seconds": test_result.duration_seconds,
                },
            )
            self._checkpoint(
                run_id,
                "verification_recorded",
                {
                    "candidate_id": candidate.id,
                    "verification_id": verification.verification_id,
                    "passed": verification.passed,
                },
            )

            if not test_result.passed:
                test_diagnostics = {
                    **dict(test_result.metadata),
                    "command": list(test_result.command),
                    "workspace_root": str(test_result.workspace_root),
                    "exit_code": test_result.exit_code,
                    "timed_out": test_result.timed_out,
                    "duration_seconds": test_result.duration_seconds,
                    "stdout": test_result.stdout[-12000:],
                    "stderr": test_result.stderr[-12000:],
                }
                rejection_reason = "candidate test execution failed"
                run = self._engine.reject(
                    candidate_id=candidate.id,
                    reason=rejection_reason,
                    metadata={
                        "run_id": run_id,
                        "test_result": test_diagnostics,
                    },
                )
                self._checkpoint(
                    run_id,
                    "rejected",
                    {"candidate_id": candidate.id, "reason": rejection_reason},
                )
                return AutonomousImprovementResult(
                    run_id=run_id,
                    candidate_id=candidate.id,
                    status=getattr(run.status, "value", str(run.status)),
                    decision=None,
                    benchmark=None,
                    candidate_tests_passed=False,
                    promoted_plan_revision_id=None,
                    workspace_root=str(workspace.root),
                    error="candidate test execution failed",
                    metadata={
                        "test_result": test_diagnostics,
                    },
                )

            evaluation = self._engine.evaluate(
                candidate_id=candidate.id,
                score=request.score if request.score is not None else 0.0,
                verification_id=verification.verification_id,
                metrics={},
                reason="candidate test execution passed",
            )

            if (
                request.objective_contract is None
                or EvidenceKind.BENCHMARK in request.objective_contract.requires
            ):
                candidate_benchmark = self._benchmark.run(
                    request=BenchmarkRequest(
                        candidate_id=candidate.id,
                        objective=request.objective,
                        workspace_root=str(workspace.root),
                        baseline_root=str(request.baseline_root.resolve()),
                        constraints={"run_id": run_id},
                    ),
                    provider=request.benchmark_provider,
                )
                if baseline_benchmark is None:
                    raise RuntimeError("baseline benchmark was not prepared")
                comparison = self._benchmark.compare(
                    candidate_id=candidate.id,
                    baseline=baseline_benchmark,
                    candidate=candidate_benchmark,
                )
            else:
                from .benchmark import BenchmarkComparisonReport
                comparison = BenchmarkComparisonReport(
                    candidate_id=candidate.id,
                    comparisons=(),
                    improved_count=0,
                    regressed_count=0,
                    unchanged_count=0,
                    passed=True,
                    metadata={"skipped": True, "reason": "objective evidence policy"},
                )

            decision = self._decision.decide(
                ImprovementDecisionRequest(
                    candidate_id=candidate.id,
                    verification=verification,
                    benchmark=comparison,
                    research_evidence=research_evidence,
                    required_evidence=request.required_evidence,
                    minimum_improvements=request.minimum_improvements,
                    minimum_score=request.minimum_score,
                    score=request.score,
                    objective_contract=request.objective_contract,
                    metadata={"run_id": run_id},
                )
            )

            self._publish(
                "ImprovementDecisionMade",
                {
                    "run_id": run_id,
                    "candidate_id": candidate.id,
                    "passed": decision.passed,
                    "reasons": list(decision.reasons),
                    "improved_metrics": list(decision.improved_metrics),
                    "regressed_metrics": list(decision.regressed_metrics),
                },
                request.mission_id,
                run_id,
            )
            self._checkpoint(
                run_id,
                "decision_recorded",
                {
                    "candidate_id": candidate.id,
                    "passed": decision.passed,
                    "reasons": list(decision.reasons),
                },
            )

            if not decision.passed:
                run = self._engine.reject(
                    candidate_id=candidate.id,
                    reason="; ".join(decision.reasons),
                )
                self._checkpoint(
                    run_id,
                    "rejected",
                    {"candidate_id": candidate.id, "reason": "; ".join(decision.reasons)},
                )
                self._persist_provenance(request=request, run_id=run_id, candidate_id=candidate.id, model_proposal=model_proposal, workspace=workspace, decision=decision, benchmark=comparison, status="rejected")
                return AutonomousImprovementResult(
                    run_id=run_id,
                    candidate_id=candidate.id,
                    status=getattr(run.status, "value", str(run.status)),
                    decision=decision,
                    benchmark=comparison,
                    candidate_tests_passed=True,
                    promoted_plan_revision_id=None,
                    workspace_root=str(workspace.root),
                    error="; ".join(decision.reasons) if not decision.passed else None,
                    metadata={
                        "research_finding_count": len(research_report.findings),
                    },
                )

            # Filesystem promotion is staged before the logical production-plan
            # transition. This makes the cross-domain commit recoverable: if the
            # process dies after code promotion but before engine promotion, the
            # durable promotion journal can safely compensate the filesystem.
            promotion_receipt = None
            if self._production_code is not None:
                changed_paths = tuple(
                    change.path for change in model_proposal.code_modification.changes
                )
                promotion_receipt = self._production_code.promote(
                    candidate_root=workspace.root,
                    production_root=request.repository_root,
                    changed_paths=changed_paths,
                    run_id=run_id,
                )
                self._checkpoint(
                    run_id,
                    "production_code_promoted",
                    {
                        "candidate_id": candidate.id,
                        "changed_paths": list(promotion_receipt.changed_paths),
                        "backup_root": str(promotion_receipt.backup_root),
                    },
                )

            try:
                promoted = self._engine.promote(
                    candidate_id=candidate.id,
                    reason="autonomous improvement decision passed",
                )
            except Exception:
                if promotion_receipt is not None:
                    self._production_code.rollback(promotion_receipt, cleanup=True)
                raise

            self._checkpoint(
                run_id,
                "promoted",
                {
                    "candidate_id": candidate.id,
                    "promoted_plan_revision_id": promoted.id,
                },
            )

            self._persist_provenance(request=request, run_id=run_id, candidate_id=candidate.id, model_proposal=model_proposal, workspace=workspace, decision=decision, benchmark=comparison, status="promoted")
            run = self._engine._candidate_and_run(candidate.id)[1]
            return AutonomousImprovementResult(
                run_id=run_id,
                candidate_id=candidate.id,
                status=getattr(run.status, "value", str(run.status)),
                decision=decision,
                benchmark=comparison,
                candidate_tests_passed=True,
                promoted_plan_revision_id=promoted.id,
                workspace_root=str(workspace.root),
                metadata={
                    "research_finding_count": len(research_report.findings),
                    "model_rationale": model_proposal.rationale,
                    "code_promotion": bool(promotion_receipt),
                    "objective_contract": (
                        request.objective_contract.objective_id
                        if request.objective_contract is not None else None
                    ),
                },
            )

        except Exception as exc:
            self._publish(
                "ImprovementAttemptFailed",
                {
                    "run_id": run_id,
                    "candidate_id": candidate_id,
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                },
                request.mission_id,
                run_id,
            )
            raise
        finally:
            if workspace is not None:
                self._code_modification.destroy_workspace(workspace)

    @staticmethod
    def _validate_request(
        request: AutonomousImprovementRequest,
    ) -> None:
        if not request.mission_id.strip():
            raise ValueError("mission_id must not be empty")
        if not request.objective.strip():
            raise ValueError("objective must not be empty")
        if request.objective_contract is not None and request.objective_contract.objective != request.objective:
            raise ValueError("objective contract does not match request objective")
        if not request.hypothesis.objective.strip():
            raise ValueError("hypothesis objective must not be empty")
        if not request.repository_root.exists():
            raise ValueError("repository_root does not exist")
        if not request.repository_root.is_dir():
            raise ValueError("repository_root must be a directory")
        if not request.baseline_root.exists():
            raise ValueError("baseline_root does not exist")
        if not request.baseline_root.is_dir():
            raise ValueError("baseline_root must be a directory")
        if not request.test_command:
            raise ValueError("test_command must not be empty")
        if request.max_proposal_attempts < 1:
            raise ValueError("max_proposal_attempts must be >= 1")

    @staticmethod
    def _candidate_task_for_verification(
        candidate: ImprovementCandidate,
    ) -> str:
        mappings = candidate.metadata.get(
            "candidate_task_mappings",
            (),
        )
        if not mappings:
            raise ValueError(
                "candidate has no isolated task mapping for verification"
            )
        first = mappings[0]
        task_id = first.get("candidate_task_id")
        if not task_id:
            raise ValueError(
                "candidate task mapping contains no candidate task ID"
            )
        return str(task_id)

    @staticmethod
    def _test_evidence(result) -> tuple[str, ...]:
        evidence = [
            f"candidate tests passed={result.passed}",
            f"exit_code={result.exit_code}",
            f"timed_out={result.timed_out}",
            f"duration_seconds={result.duration_seconds:.6f}",
        ]
        if result.stdout.strip():
            evidence.append("stdout=" + result.stdout[-4000:])
        if result.stderr.strip():
            evidence.append("stderr=" + result.stderr[-4000:])
        return tuple(evidence)

    def _persist_provenance(self, *, request, run_id: str, candidate_id: str, model_proposal, workspace, decision=None, benchmark=None, status: str) -> None:
        """Persist the engineering evidence before the disposable workspace disappears."""
        try:
            changes = tuple(model_proposal.code_modification.changes)
            diff = self._code_modification.diff(workspace)
            payload = {
                "run_id": run_id,
                "candidate_id": candidate_id,
                "status": status,
                "timestamp": __import__("time").time(),
                "objective": request.objective,
                "hypothesis": getattr(model_proposal, "hypothesis", ""),
                "hypothesis_rationale": getattr(model_proposal, "hypothesis_rationale", ""),
                "success_criteria": list(getattr(model_proposal, "success_criteria", ()) or ()),
                "rationale": getattr(model_proposal, "rationale", ""),
                "changed_paths": [c.path for c in changes],
                "change_count": len(changes),
                "diff": diff[:500_000],
                "diff_truncated": len(diff) > 500_000,
                "decision": {
                    "passed": bool(getattr(decision, "passed", False)),
                    "reasons": list(getattr(decision, "reasons", ()) or ()),
                    "improved_metrics": list(getattr(decision, "improved_metrics", ()) or ()),
                    "regressed_metrics": list(getattr(decision, "regressed_metrics", ()) or ()),
                } if decision is not None else None,
                "benchmark": {
                    "improved_count": int(getattr(benchmark, "improved_count", 0)),
                    "regressed_count": int(getattr(benchmark, "regressed_count", 0)),
                    "unchanged_count": int(getattr(benchmark, "unchanged_count", 0)),
                    "passed": bool(getattr(benchmark, "passed", False)),
                    "comparisons": [asdict(item) for item in getattr(benchmark, "comparisons", ())],
                } if benchmark is not None else None,
            }
            root=request.repository_root / ".ocean" / "improvement_provenance"
            root.mkdir(parents=True, exist_ok=True)
            tmp=root / f"{run_id}.tmp"
            final=root / f"{run_id}.json"
            tmp.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
            tmp.replace(final)
        except Exception as exc:
            # Provenance must never turn a valid production improvement into a
            # failure, but the lifecycle metadata records the failure via logs.
            self._publish("ImprovementProvenanceFailed", {"run_id": run_id, "candidate_id": candidate_id, "error": str(exc)}, request.mission_id, run_id)

    def _publish(
        self,
        event_type: str,
        payload: Mapping[str, Any],
        aggregate_id: str,
        correlation_id: Optional[str] = None,
    ) -> None:
        self._write_activity(event_type, {"aggregate_id": aggregate_id, "correlation_id": correlation_id, **dict(payload)})
        self._events.publish(
            Event(
                type=event_type,
                payload=dict(payload),
                aggregate_type="improvement_run",
                aggregate_id=aggregate_id,
                correlation_id=correlation_id,
                source="self_improvement_coordinator",
            )
        )

    def _write_activity(self, event_type: str, payload: Mapping[str, Any]) -> None:
        record = {"timestamp": time.time(), "event": event_type, "payload": dict(payload)}
        if self._activity_path is None:
            return
        try:
            with self._activity_path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(record, sort_keys=True, default=str) + "\n")
        except OSError:
            # Transparency must never become a reason to block the safety path.
            pass

    def _checkpoint(
        self,
        run_id: str,
        phase: str,
        context: Mapping[str, Any],
    ) -> None:
        """Persist completed, replay-safe lifecycle facts when a run exists."""
        self._write_activity("checkpoint", {"run_id": run_id, "phase": phase, **dict(context)})
        try:
            self._engine.checkpoint(run_id=run_id, phase=phase, context=context)
        except ValueError as exc:
            # Direct coordinator consumers historically create their run at
            # candidate creation. Preserve that API while checkpointing every
            # subsequent stage.
            if "unknown improvement run" not in str(exc):
                raise


class _ProposalCodeModificationProvider:
    """Adapts an already validated model proposal to the code boundary."""

    def __init__(self, modification) -> None:
        self._modification = modification

    def generate(self, request: CodeModificationRequest):
        metadata = {
            **dict(self._modification.metadata),
            "candidate_workspace": str(request.repository_root),
            "source_repository": str(
                request.constraints.get(
                    "source_repository",
                    ""
                )
            ),
            "production_mutation_forbidden": True,
        }

        from .code_modification import CodeModification

        return CodeModification(
            candidate_id=request.candidate_id,
            changes=self._modification.changes,
            rationale=self._modification.rationale,
            metadata=metadata,
        )
