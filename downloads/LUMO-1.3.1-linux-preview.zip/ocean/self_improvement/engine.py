from __future__ import annotations

from typing import Any, Mapping, Optional

from ocean.core.ids import new_id
from ocean.domain.event import Event
from ocean.domain.mission import Mission
from ocean.domain.plan import PlanRevision, PlanStatus
from ocean.domain.verification import Verification
from ocean.domain.work_graph import WorkNode, WorkEdge
from .verification import CandidateVerificationService
from .isolation import CandidateIsolationService
from ocean.planning.service import PlanningService
from ocean.planning.planner import Planner
from persistence.repository import Repository
from persistence.unit_of_work import UnitOfWork

from .types import (
    ImprovementCandidate,
    ImprovementEvaluation,
    ImprovementHypothesis,
    ImprovementRun,
    ImprovementStatus,
)


class SelfImprovementEngine:
    """
    Bounded autonomous improvement control plane.

    This engine does not directly mutate production execution state.
    Candidate plans are created through PlanningService and must pass
    explicit evaluation before promotion.

    The engine owns improvement lifecycle state; existing Ocean systems
    remain authoritative for planning, execution, verification, governance,
    persistence, and event history.
    """

    def __init__(
        self,
        *,
        missions: Repository[Mission],
        plan_revisions: Repository[PlanRevision],
        runs: Repository[ImprovementRun],
        planning: PlanningService,
        events,
        decisions: Optional[Repository] = None,
        work_graphs: Optional[Repository] = None,
        candidate_isolation: Optional[CandidateIsolationService] = None,
        verifications: Optional[Repository[Verification]] = None,
    ) -> None:
        self._missions = missions
        self._plan_revisions = plan_revisions
        self._runs = runs
        self._planning = planning
        self._events = events
        self._decisions = decisions
        self._work_graphs = work_graphs
        self._verifications = verifications
        self._unit_of_work = None
        self._candidate_isolation = (
            candidate_isolation
            if candidate_isolation is not None
            else CandidateIsolationService(
                missions=missions,
                tasks=planning.tasks,
                events=events,
            )
        )
        self._candidate_verification = CandidateVerificationService(
            events=events,
            verifications=verifications,
        )

    def _unit_of_work_for_mutation(self) -> UnitOfWork:
        decisions = self._decisions
        if decisions is None:
            decisions = getattr(self._planning, "decisions", None)

        work_graphs = self._work_graphs
        if work_graphs is None:
            work_graphs = getattr(self._planning, "work_graphs", None)

        tasks = getattr(self._planning, "tasks", None)

        repositories = [
            self._missions,
            self._plan_revisions,
            self._runs,
        ]

        for repository in (decisions, tasks, work_graphs):
            if repository is not None:
                repositories.append(repository)

        return UnitOfWork(repositories)

    def create_candidate(
        self,
        *,
        mission_id: str,
        hypothesis: ImprovementHypothesis,
        planner: Planner,
        source_plan_revision_id: Optional[str] = None,
        metadata: Optional[Mapping[str, Any]] = None,
        candidate_id: Optional[str] = None,
        run_id: Optional[str] = None,
    ) -> ImprovementCandidate:
        mission = self._require_mission(mission_id)

        if source_plan_revision_id is not None:
            source = self._require_plan(source_plan_revision_id)
            if source.mission_id != mission.id:
                raise ValueError("source plan belongs to a different mission")
        else:
            source = self._active_plan(mission.id)

        request_metadata = dict(metadata or {})
        request_metadata.update(
            {
                "self_improvement": True,
                "hypothesis": hypothesis.hypothesis,
                "improvement_objective": hypothesis.objective,
            }
        )

        isolation = self._candidate_isolation.create(
            source_mission=mission,
            task_ids=mission.task_ids,
            metadata=request_metadata,
        )

        candidate_mission = self._require_mission(
            isolation.candidate_mission_id
        )

        plan, _ = self._planning.plan(
            self._planning_request(
                candidate_mission,
                hypothesis,
                {
                    **request_metadata,
                    "source_mission_id": mission.id,
                    "candidate_mission_id": candidate_mission.id,
                },
            ),
            planner,
        )

        if plan.mission_id != candidate_mission.id:
            raise ValueError(
                "candidate planner returned a plan for the wrong mission"
            )

        candidate_metadata = {
            **request_metadata,
            "source_mission_id": mission.id,
            "candidate_mission_id": candidate_mission.id,
            "source_plan_revision_id": source.id if source else None,
            "candidate_plan_revision_id": plan.id,
            "candidate_task_mappings": [
                {
                    "source_task_id": mapping.source_task_id,
                    "candidate_task_id": mapping.candidate_task_id,
                }
                for mapping in isolation.task_mappings
            ],
        }

        candidate = ImprovementCandidate(
            id=candidate_id or new_id("improvement"),
            mission_id=mission.id,
            candidate_mission_id=candidate_mission.id,
            source_plan_revision_id=source.id if source else None,
            candidate_plan_revision_id=plan.id,
            hypothesis=hypothesis,
            metadata=candidate_metadata,
        )

        run = ImprovementRun(
            id=run_id or new_id("improvement_run"),
            mission_id=mission.id,
            candidate_id=candidate.id,
            status=ImprovementStatus.CANDIDATE,
            metadata=candidate_metadata,
        )
        self._runs.save(run)

        self._events.publish(
            Event(
                type="ImprovementCandidateCreated",
                payload={
                    "run_id": run.id,
                    "candidate_id": candidate.id,
                    "mission_id": mission.id,
                    "candidate_mission_id": candidate.candidate_mission_id,
                    "source_plan_revision_id": candidate.source_plan_revision_id,
                    "candidate_plan_revision_id": candidate.candidate_plan_revision_id,
                    "hypothesis": {
                        "objective": hypothesis.objective,
                        "hypothesis": hypothesis.hypothesis,
                        "rationale": hypothesis.rationale,
                        "success_criteria": list(hypothesis.success_criteria),
                        "constraints": dict(hypothesis.constraints),
                    },
                    "metadata": dict(candidate.metadata),
                },
            )
        )

        return candidate

    def checkpoint(
        self,
        *,
        run_id: str,
        phase: str,
        context: Optional[Mapping[str, Any]] = None,
    ) -> ImprovementRun:
        """Persist an execution checkpoint without changing lifecycle status."""
        if not phase.strip():
            raise ValueError("checkpoint phase must not be empty")

        run = self._runs.get(run_id)
        if run is None:
            raise ValueError(f"unknown improvement run: {run_id}")

        replacement = ImprovementRun(
            id=run.id,
            mission_id=run.mission_id,
            candidate_id=run.candidate_id,
            status=run.status,
            evaluation=run.evaluation,
            promoted_plan_revision_id=run.promoted_plan_revision_id,
            metadata={
                **dict(run.metadata),
                "recovery_checkpoint": {
                    "phase": phase,
                    "context": dict(context or {}),
                },
            },
        )
        self._runs.save(replacement)

        self._publish(
            "ImprovementCheckpointCreated",
            {
                "run_id": run.id,
                "candidate_id": run.candidate_id,
                "mission_id": run.mission_id,
                "phase": phase,
                "context": dict(context or {}),
                "status": run.status.value,
            },
            run.mission_id,
        )
        return replacement

    def evaluate(
        self,
        *,
        candidate_id: str,
        score: float,
        verification_id: str,
        metrics: Optional[Mapping[str, float]] = None,
        reason: Optional[str] = None,
    ) -> ImprovementEvaluation:
        candidate, run = self._candidate_and_run(candidate_id)

        if run.status not in {
            ImprovementStatus.CANDIDATE,
            ImprovementStatus.TESTING,
            ImprovementStatus.VERIFIED,
        }:
            raise ValueError(
                f"candidate {candidate_id!r} cannot be evaluated from "
                f"{run.status.value!r}"
            )

        verification = self._candidate_verification.require(
            candidate_id=candidate_id,
            verification_id=verification_id,
        )

        if not verification.evidence:
            raise ValueError(
                "candidate evaluation requires verification evidence"
            )

        evaluation = ImprovementEvaluation(
            candidate_id=candidate.id,
            passed=bool(verification.passed),
            score=float(score),
            evidence=tuple(verification.evidence),
            metrics=dict(metrics or {}),
            reason=reason,
        )

        status = (
            ImprovementStatus.VERIFIED
            if evaluation.passed
            else ImprovementStatus.REJECTED
        )

        replacement = ImprovementRun(
            id=run.id,
            mission_id=run.mission_id,
            candidate_id=run.candidate_id,
            status=status,
            evaluation=evaluation,
            promoted_plan_revision_id=run.promoted_plan_revision_id,
            metadata={
                **dict(run.metadata),
                "verification_id": verification.id,
            },
        )
        self._runs.save(replacement)

        self._publish(
            "ImprovementEvaluated",
            {
                "run_id": run.id,
                "candidate_id": candidate.id,
                "passed": evaluation.passed,
                "score": evaluation.score,
                "evidence": list(evaluation.evidence),
                "metrics": dict(evaluation.metrics),
                "reason": evaluation.reason,
                "status": status.value,
                "verification_id": verification.id,
            },
            run.mission_id,
        )

        return evaluation

    def promote(
        self,
        *,
        candidate_id: str,
        reason: Optional[str] = None,
    ) -> PlanRevision:
        """Materialize a verified candidate as a new production revision.

        Candidate planning artifacts are never activated directly. Promotion
        clones the candidate decision and work graph into the production
        mission, remaps isolated candidate task identities back to their
        production task identities, and performs the complete lifecycle
        transition atomically.
        """
        candidate, run = self._candidate_and_run(candidate_id)
        if run.status is not ImprovementStatus.VERIFIED:
            raise ValueError(
                f"candidate {candidate_id!r} must be verified before promotion"
            )
        if run.evaluation is None or not run.evaluation.passed:
            raise ValueError("candidate has no passing evaluation")

        if self._decisions is None or self._work_graphs is None:
            raise ValueError(
                "promotion requires decisions and work graph repositories"
            )

        candidate_plan = self._require_plan(
            candidate.candidate_plan_revision_id
        )
        if candidate_plan.mission_id != candidate.candidate_mission_id:
            raise ValueError(
                "candidate plan does not belong to candidate mission"
            )

        candidate_graph = self._work_graphs.get(candidate_plan.graph_id)
        if candidate_graph is None:
            raise ValueError(
                f"unknown candidate work graph: {candidate_plan.graph_id!r}"
            )
        if candidate_graph.mission_id != candidate.candidate_mission_id:
            raise ValueError(
                "candidate work graph does not belong to candidate mission"
            )

        candidate_decision = self._decisions.get(candidate_plan.decision_id)
        if candidate_decision is None:
            raise ValueError(
                f"unknown candidate decision: {candidate_plan.decision_id!r}"
            )
        if candidate_decision.mission_id != candidate.candidate_mission_id:
            raise ValueError(
                "candidate decision does not belong to candidate mission"
            )

        active = self._active_plan(candidate.mission_id)
        task_mapping = {
            str(item["candidate_task_id"]): str(item["source_task_id"])
            for item in candidate.metadata.get(
                "candidate_task_mappings",
                [],
            )
        }

        production_nodes = [
            WorkNode(
                kind=node.kind,
                task_id=(
                    task_mapping[node.task_id]
                    if node.task_id is not None
                    else None
                ),
                metadata={
                    **dict(node.metadata),
                    "promoted_from_candidate": candidate.id,
                },
            )
            for node in candidate_graph.nodes
        ]

        node_map = {
            source_node.id: production_node.id
            for source_node, production_node in zip(
                candidate_graph.nodes,
                production_nodes,
            )
        }

        production_edges = [
            WorkEdge(
                source_node_id=node_map[edge.source_node_id],
                target_node_id=node_map[edge.target_node_id],
                kind=edge.kind,
                condition=edge.condition,
            )
            for edge in candidate_graph.edges
        ]

        with self._unit_of_work_for_mutation().transaction():
            production_decision = self._planning.create_decision(
                mission_id=candidate.mission_id,
                kind=candidate_decision.kind,
                objective=candidate_decision.objective,
                rationale=candidate_decision.rationale,
                alternatives=candidate_decision.alternatives,
                selected_option=candidate_decision.selected_option,
                confidence=candidate_decision.confidence,
                evidence=candidate_decision.evidence,
                metadata={
                    **dict(candidate_decision.metadata),
                    "self_improvement_promotion": True,
                    "improvement_candidate_id": candidate.id,
                    "source_candidate_decision_id": candidate_decision.id,
                    "candidate_plan_revision_id": candidate_plan.id,
                },
            )

            production_plan, _ = self._planning.create_plan(
                mission_id=candidate.mission_id,
                decision_id=production_decision.id,
                nodes=production_nodes,
                edges=production_edges,
                parent_revision_id=active.id if active is not None else None,
                reason=reason or "verified self-improvement promoted",
                metadata={
                    **dict(candidate_plan.metadata),
                    "self_improvement_promotion": True,
                    "improvement_candidate_id": candidate.id,
                    "source_candidate_plan_revision_id": candidate_plan.id,
                    "source_candidate_mission_id": candidate.candidate_mission_id,
                },
            )

            proposed = self._planning.propose(
                production_plan.id,
                reason=reason or "verified self-improvement promoted",
            )

            if active is not None:
                self._planning.supersede(
                    active.id,
                    reason=reason or f"superseded by improvement {candidate.id}",
                )

            promoted = self._planning.activate(
                proposed.id,
                reason=reason or "verified self-improvement promoted",
            )

            replacement = ImprovementRun(
                id=run.id,
                mission_id=run.mission_id,
                candidate_id=run.candidate_id,
                status=ImprovementStatus.PROMOTED,
                evaluation=run.evaluation,
                promoted_plan_revision_id=promoted.id,
                metadata={
                    **dict(run.metadata),
                    "production_plan_revision_id": promoted.id,
                    "source_candidate_plan_revision_id": candidate_plan.id,
                },
            )
            self._runs.save(replacement)

        self._publish(
            "ImprovementPromoted",
            {
                "run_id": run.id,
                "candidate_id": candidate.id,
                "plan_revision_id": promoted.id,
                "previous_plan_revision_id": (
                    active.id if active is not None else None
                ),
                "source_candidate_plan_revision_id": candidate_plan.id,
                "reason": reason,
            },
            candidate.mission_id,
        )
        return promoted

    def reject_run(
        self,
        *,
        run_id: str,
        reason: str,
        metadata: Mapping[str, Any] | None = None,
    ) -> ImprovementRun:
        """Terminally reject a run that failed before a candidate existed."""
        if not reason or not reason.strip():
            raise ValueError("rejection reason is required")
        run = self._runs.get(run_id)
        if run is None:
            raise ValueError(f"unknown improvement run: {run_id!r}")
        if run.status.terminal:
            return run

        replacement = ImprovementRun(
            id=run.id,
            mission_id=run.mission_id,
            candidate_id=run.candidate_id,
            status=ImprovementStatus.REJECTED,
            evaluation=run.evaluation,
            promoted_plan_revision_id=run.promoted_plan_revision_id,
            metadata={
                **dict(run.metadata),
                "rejection_reason": reason,
                **dict(metadata or {}),
            },
        )
        self._runs.save(replacement)
        self._publish(
            "ImprovementRejected",
            {
                "run_id": run.id,
                "candidate_id": run.candidate_id,
                "reason": reason,
                "metadata": dict(metadata or {}),
                "pre_candidate": True,
            },
            run.mission_id,
        )
        return replacement

    def reject(
        self,
        *,
        candidate_id: str,
        reason: str,
        metadata: Mapping[str, Any] | None = None,
    ) -> ImprovementRun:
        if not reason or not reason.strip():
            raise ValueError("rejection reason is required")

        candidate, run = self._candidate_and_run(candidate_id)

        if run.status is ImprovementStatus.REJECTED:
            plan = self._require_plan(candidate.candidate_plan_revision_id)
            if plan.status in {PlanStatus.DRAFT, PlanStatus.PROPOSED}:
                self._planning.cancel(plan.id, reason=reason)

            rejection_metadata = dict(metadata or {})
            if rejection_metadata:
                run = ImprovementRun(
                    id=run.id,
                    mission_id=run.mission_id,
                    candidate_id=run.candidate_id,
                    status=run.status,
                    evaluation=run.evaluation,
                    promoted_plan_revision_id=run.promoted_plan_revision_id,
                    metadata={
                        **dict(run.metadata),
                        **rejection_metadata,
                        "rejection_reason": reason,
                    },
                )
                self._runs.save(run)

            self._publish(
                "ImprovementRejected",
                {
                    "run_id": run.id,
                    "candidate_id": candidate.id,
                    "plan_revision_id": plan.id,
                    "reason": reason,
                    "metadata": rejection_metadata,
                    "idempotent": True,
                },
                candidate.mission_id,
            )
            return run

        if run.status not in {
            ImprovementStatus.CANDIDATE,
            ImprovementStatus.TESTING,
            ImprovementStatus.VERIFIED,
        }:
            raise ValueError(
                f"candidate {candidate_id!r} cannot be rejected from "
                f"{run.status.value!r}"
            )

        plan = self._require_plan(candidate.candidate_plan_revision_id)
        if plan.status in {PlanStatus.DRAFT, PlanStatus.PROPOSED}:
            self._planning.cancel(plan.id, reason=reason)

        replacement = ImprovementRun(
            id=run.id,
            mission_id=run.mission_id,
            candidate_id=run.candidate_id,
            status=ImprovementStatus.REJECTED,
            evaluation=run.evaluation,
            promoted_plan_revision_id=run.promoted_plan_revision_id,
            metadata={
                **run.metadata,
                "rejection_reason": reason,
                **dict(metadata or {}),
            },
        )
        self._runs.save(replacement)

        self._publish(
            "ImprovementRejected",
            {
                "run_id": run.id,
                "candidate_id": candidate.id,
                "plan_revision_id": plan.id,
                "reason": reason,
                "metadata": dict(metadata or {}),
            },
            candidate.mission_id,
        )

        return replacement

    def rollback(
        self,
        *,
        candidate_id: str,
        reason: str,
    ) -> PlanRevision:
        """Safely roll back a promoted improvement by creating a new
        production revision from the previously known-good production state.

        Historical revisions are never reactivated. Rollback is itself a
        forward production revision.
        """
        if not reason or not reason.strip():
            raise ValueError("rollback reason is required")

        candidate, run = self._candidate_and_run(candidate_id)

        if run.status is not ImprovementStatus.PROMOTED:
            raise ValueError(
                f"candidate {candidate_id!r} is not promoted"
            )

        if candidate.source_plan_revision_id is None:
            raise ValueError("promoted candidate has no rollback target")

        if run.promoted_plan_revision_id is None:
            raise ValueError(
                "promoted candidate has no promoted production revision"
            )

        if self._decisions is None or self._work_graphs is None:
            raise ValueError(
                "rollback requires decisions and work graph repositories"
            )

        promoted = self._require_plan(run.promoted_plan_revision_id)
        source = self._require_plan(candidate.source_plan_revision_id)

        if promoted.mission_id != candidate.mission_id:
            raise ValueError(
                "promoted production plan belongs to a different mission"
            )

        if source.mission_id != candidate.mission_id:
            raise ValueError(
                "rollback source belongs to a different production mission"
            )

        active = self._active_plan(candidate.mission_id)

        if active is None:
            raise ValueError(
                "rollback requires an active production plan"
            )

        if active.id != promoted.id:
            raise ValueError(
                "cannot rollback stale promotion: promoted revision is no "
                "longer the active production revision"
            )

        source_graph = self._work_graphs.get(source.graph_id)

        if source_graph is None:
            raise ValueError(
                f"unknown rollback source work graph: {source.graph_id!r}"
            )

        if source_graph.mission_id != candidate.mission_id:
            raise ValueError(
                "rollback source work graph belongs to a different mission"
            )

        source_decision = self._decisions.get(source.decision_id)

        if source_decision is None:
            raise ValueError(
                f"unknown rollback source decision: {source.decision_id!r}"
            )

        if source_decision.mission_id != candidate.mission_id:
            raise ValueError(
                "rollback source decision belongs to a different mission"
            )

        with self._unit_of_work_for_mutation().transaction():
            rollback_decision = self._planning.create_decision(
                mission_id=candidate.mission_id,
                kind=source_decision.kind,
                objective=source_decision.objective,
                rationale=source_decision.rationale,
                alternatives=source_decision.alternatives,
                selected_option=source_decision.selected_option,
                confidence=source_decision.confidence,
                evidence=source_decision.evidence,
                metadata={
                    **dict(source_decision.metadata),
                    "rollback": True,
                    "improvement_candidate_id": candidate.id,
                    "rollback_source_plan_revision_id": source.id,
                    "rollback_from_plan_revision_id": promoted.id,
                },
            )

            rollback_nodes = [
                WorkNode(
                    kind=node.kind,
                    task_id=node.task_id,
                    metadata={
                        **dict(node.metadata),
                        "rollback": True,
                        "improvement_candidate_id": candidate.id,
                    },
                )
                for node in source_graph.nodes
            ]

            rollback_node_map = {
                source_node.id: rollback_node.id
                for source_node, rollback_node in zip(
                    source_graph.nodes,
                    rollback_nodes,
                )
            }

            rollback_edges = [
                WorkEdge(
                    source_node_id=rollback_node_map[edge.source_node_id],
                    target_node_id=rollback_node_map[edge.target_node_id],
                    kind=edge.kind,
                    condition=edge.condition,
                )
                for edge in source_graph.edges
            ]

            rollback_plan, _ = self._planning.create_plan(
                mission_id=candidate.mission_id,
                decision_id=rollback_decision.id,
                nodes=rollback_nodes,
                edges=rollback_edges,
                parent_revision_id=promoted.id,
                reason=reason,
                metadata={
                    **dict(source.metadata),
                    "rollback": True,
                    "improvement_candidate_id": candidate.id,
                    "rollback_source_plan_revision_id": source.id,
                    "rollback_from_plan_revision_id": promoted.id,
                },
            )

            proposed = self._planning.propose(
                rollback_plan.id,
                reason=reason,
            )

            rolled_back = self._planning.replace_active(
                proposed.id,
                expected_active_id=promoted.id,
                reason=reason,
            )

            replacement = ImprovementRun(
                id=run.id,
                mission_id=run.mission_id,
                candidate_id=run.candidate_id,
                status=ImprovementStatus.ROLLED_BACK,
                evaluation=run.evaluation,
                promoted_plan_revision_id=run.promoted_plan_revision_id,
                metadata={
                    **dict(run.metadata),
                    "rollback_reason": reason,
                    "rollback_plan_revision_id": rolled_back.id,
                    "rollback_source_plan_revision_id": source.id,
                },
            )
            self._runs.save(replacement)

        self._publish(
            "ImprovementRolledBack",
            {
                "run_id": run.id,
                "candidate_id": candidate.id,
                "from_plan_revision_id": promoted.id,
                "to_plan_revision_id": rolled_back.id,
                "rollback_source_plan_revision_id": source.id,
                "reason": reason,
            },
            candidate.mission_id,
        )

        return rolled_back

    def _planning_request(
        self,
        mission: Mission,
        hypothesis: ImprovementHypothesis,
        metadata: Mapping[str, Any],
    ):
        from ocean.planning.planner import PlanningContext, PlanningRequest

        return PlanningRequest(
            mission_id=mission.id,
            objective=hypothesis.objective,
            context=PlanningContext(
                mission=mission,
                metadata=dict(metadata),
            ),
            revision_reason=f"self-improvement: {hypothesis.hypothesis}",
            metadata=dict(metadata),
        )

    def _candidate_and_run(self, candidate_id: str):
        runs = [
            run
            for run in self._runs.list()
            if run.candidate_id == candidate_id
        ]
        if not runs:
            raise ValueError(f"unknown improvement candidate: {candidate_id!r}")

        run = runs[-1]
        metadata = dict(run.metadata)
        plan_id = metadata.get("candidate_plan_revision_id")

        if plan_id is None:
            raise ValueError("improvement run is missing candidate plan identity")

        candidate = ImprovementCandidate(
            id=candidate_id,
            mission_id=run.mission_id,
            candidate_mission_id=str(
                metadata.get("candidate_mission_id")
                or ""
            ),
            source_plan_revision_id=metadata.get(
                "source_plan_revision_id"
            ),
            candidate_plan_revision_id=str(plan_id),
            hypothesis=ImprovementHypothesis(
                objective=str(metadata.get("improvement_objective", "")),
                hypothesis=str(metadata.get("hypothesis", "")),
                rationale=str(metadata.get("hypothesis_rationale", "")),
            ),
            metadata=metadata,
        )
        return candidate, run

    def _active_plan(self, mission_id: str) -> Optional[PlanRevision]:
        active = [
            plan
            for plan in self._plan_revisions.list()
            if plan.mission_id == mission_id
            and plan.status is PlanStatus.ACTIVE
        ]
        if len(active) > 1:
            raise ValueError(
                f"mission {mission_id!r} has multiple active plans"
            )
        return active[0] if active else None

    def _require_mission(self, mission_id: str) -> Mission:
        mission = self._missions.get(mission_id)
        if mission is None:
            raise ValueError(f"unknown mission: {mission_id!r}")
        return mission

    def _require_plan(self, plan_id: str) -> PlanRevision:
        plan = self._plan_revisions.get(plan_id)
        if plan is None:
            raise ValueError(f"unknown plan revision: {plan_id!r}")
        return plan

    def _publish(
        self,
        event_type: str,
        payload: Mapping[str, Any],
        mission_id: str,
    ) -> None:
        failures = self._events.publish(
            Event(
                type=event_type,
                payload=dict(payload),
                aggregate_type="self_improvement",
                aggregate_id=str(payload.get("candidate_id", mission_id)),
                correlation_id=mission_id,
                source="self_improvement",
            )
        )
        if failures:
            raise RuntimeError(
                f"event handlers failed for {event_type!r}: "
                + "; ".join(str(failure.error) for failure in failures)
            )
