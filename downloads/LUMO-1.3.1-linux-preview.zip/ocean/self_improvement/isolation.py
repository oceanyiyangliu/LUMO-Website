from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Optional

from ocean.domain.event import Event
from ocean.domain.mission import Mission
from ocean.domain.task import Task


@dataclass(frozen=True)
class CandidateTaskMapping:
    source_task_id: str
    candidate_task_id: str


@dataclass(frozen=True)
class CandidateIsolation:
    source_mission_id: str
    candidate_mission_id: str
    task_mappings: tuple[CandidateTaskMapping, ...]

    @property
    def source_task_ids(self) -> frozenset[str]:
        return frozenset(m.source_task_id for m in self.task_mappings)

    @property
    def candidate_task_ids(self) -> frozenset[str]:
        return frozenset(m.candidate_task_id for m in self.task_mappings)

    def candidate_task_for(self, source_task_id: str) -> str:
        for mapping in self.task_mappings:
            if mapping.source_task_id == source_task_id:
                return mapping.candidate_task_id
        raise KeyError(source_task_id)


class CandidateIsolationError(ValueError):
    """Raised when candidate isolation invariants are violated."""


class CandidateIsolationService:
    """
    Creates an isolated candidate mission and task set.

    Isolation is structural:
      - candidate mission has a new identity
      - every candidate task has a new identity
      - candidate tasks reference only the candidate mission
      - dependency edges are rewritten to candidate task IDs
      - production mission/tasks are never mutated
    """

    def __init__(self, *, missions, tasks, events=None) -> None:
        self._missions = missions
        self._tasks = tasks
        self._events = events

    def create(
        self,
        *,
        source_mission: Mission,
        task_ids: Iterable[str],
        metadata: Optional[Mapping[str, Any]] = None,
    ) -> CandidateIsolation:
        source_task_ids = tuple(dict.fromkeys(task_ids))

        if not source_mission.id:
            raise CandidateIsolationError("source mission id is required")

        source_tasks: dict[str, Task] = {}
        for task_id in source_task_ids:
            task = self._tasks.get(task_id)
            if task is None:
                raise CandidateIsolationError(
                    f"unknown source task: {task_id!r}"
                )
            if task.mission_id != source_mission.id:
                raise CandidateIsolationError(
                    f"source task {task_id!r} does not belong to "
                    f"source mission {source_mission.id!r}"
                )
            source_tasks[task_id] = task

        candidate_mission = Mission(
            goal=source_mission.goal,
            metadata={
                **dict(source_mission.metadata),
                **dict(metadata or {}),
                "candidate": True,
                "source_mission_id": source_mission.id,
            },
        )

        if self._missions.get(candidate_mission.id) is not None:
            raise CandidateIsolationError(
                f"candidate mission already exists: {candidate_mission.id!r}"
            )

        id_map = {
            source_id: Task(
                title=source_tasks[source_id].title,
                description=source_tasks[source_id].description,
                mission_id=candidate_mission.id,
                depends_on=set(),
                assignee_type=source_tasks[source_id].assignee_type,
                assignee_id=source_tasks[source_id].assignee_id,
                metadata={
                    **dict(source_tasks[source_id].metadata),
                    "candidate": True,
                    "source_task_id": source_id,
                    "source_mission_id": source_mission.id,
                },
            ).id
            for source_id in source_task_ids
        }

        candidate_tasks: list[Task] = []

        for source_id in source_task_ids:
            source_task = source_tasks[source_id]
            candidate_task = Task(
                title=source_task.title,
                description=source_task.description,
                mission_id=candidate_mission.id,
                depends_on={
                    id_map[dependency]
                    for dependency in source_task.depends_on
                    if dependency in id_map
                },
                assignee_type=source_task.assignee_type,
                assignee_id=source_task.assignee_id,
                metadata={
                    **dict(source_task.metadata),
                    "candidate": True,
                    "source_task_id": source_id,
                    "source_mission_id": source_mission.id,
                },
                id=id_map[source_id],
            )
            candidate_tasks.append(candidate_task)
            candidate_mission.add_task(candidate_task.id)

        # Persist only after the complete isolated graph has been constructed.
        self._missions.save(candidate_mission)
        for task in candidate_tasks:
            self._tasks.save(task)

        if self._events is not None:
            self._events.publish(
                Event(
                    type="CandidateMissionCreated",
                    payload={
                        "candidate_mission_id": candidate_mission.id,
                        "source_mission_id": source_mission.id,
                        "task_ids": list(candidate_mission.task_ids),
                    },
                    aggregate_type="mission",
                    aggregate_id=candidate_mission.id,
                    correlation_id=candidate_mission.id,
                    source="candidate_isolation",
                )
            )

            for source_id, candidate_id in id_map.items():
                candidate_task = self._tasks.get(candidate_id)
                self._events.publish(
                    Event(
                        type="CandidateTaskCreated",
                        payload={
                            "candidate_task_id": candidate_id,
                            "source_task_id": source_id,
                            "candidate_mission_id": candidate_mission.id,
                            "source_mission_id": source_mission.id,
                            "title": candidate_task.title,
                        },
                        aggregate_type="task",
                        aggregate_id=candidate_id,
                        correlation_id=candidate_mission.id,
                        source="candidate_isolation",
                    )
                )

        return CandidateIsolation(
            source_mission_id=source_mission.id,
            candidate_mission_id=candidate_mission.id,
            task_mappings=tuple(
                CandidateTaskMapping(source, candidate)
                for source, candidate in id_map.items()
            ),
        )
