from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Optional

from ocean.domain.mission import Mission
from ocean.domain.plan import PlanRevision
from ocean.self_improvement.isolation import CandidateIsolation


class CandidateExecutionBoundaryError(ValueError):
    """Raised when candidate execution would cross an isolation boundary."""


@dataclass(frozen=True)
class CandidateExecutionContext:
    candidate_mission_id: str
    source_mission_id: str
    candidate_plan_revision_id: str
    source_plan_revision_id: str
    metadata: Mapping[str, Any]


class CandidateExecutionBoundary:
    """
    Safety boundary between self-improvement candidates and production.

    A candidate execution is valid only when:
      - the candidate mission is distinct from production
      - every candidate task belongs to the candidate mission
      - the candidate plan belongs to the candidate mission
      - the source plan belongs to the source mission
      - execution metadata carries both identities
    """

    def validate(
        self,
        *,
        isolation: CandidateIsolation,
        candidate_mission: Mission,
        candidate_plan: PlanRevision,
        source_mission: Mission,
        source_plan: PlanRevision,
    ) -> CandidateExecutionContext:
        if candidate_mission.id == source_mission.id:
            raise CandidateExecutionBoundaryError(
                "candidate mission cannot equal source mission"
            )

        if candidate_plan.mission_id != candidate_mission.id:
            raise CandidateExecutionBoundaryError(
                "candidate plan does not belong to candidate mission"
            )

        if source_plan.mission_id != source_mission.id:
            raise CandidateExecutionBoundaryError(
                "source plan does not belong to source mission"
            )

        if isolation.candidate_mission_id != candidate_mission.id:
            raise CandidateExecutionBoundaryError(
                "isolation candidate mission does not match candidate mission"
            )

        if isolation.source_mission_id != source_mission.id:
            raise CandidateExecutionBoundaryError(
                "isolation source mission does not match source mission"
            )

        if not isolation.candidate_task_ids:
            raise CandidateExecutionBoundaryError(
                "candidate execution requires at least one candidate task"
            )

        if isolation.candidate_task_ids & isolation.source_task_ids:
            raise CandidateExecutionBoundaryError(
                "candidate and source task identities overlap"
            )

        metadata = {
            "candidate_execution": True,
            "candidate_mission_id": candidate_mission.id,
            "source_mission_id": source_mission.id,
            "candidate_plan_revision_id": candidate_plan.id,
            "source_plan_revision_id": source_plan.id,
        }

        return CandidateExecutionContext(
            candidate_mission_id=candidate_mission.id,
            source_mission_id=source_mission.id,
            candidate_plan_revision_id=candidate_plan.id,
            source_plan_revision_id=source_plan.id,
            metadata=metadata,
        )
