from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping, Optional

from .objective import ObjectiveContract


@dataclass(frozen=True)
class ImprovementCheckpoint:
    run_id: str
    phase: ImprovementStatus
    context: Mapping[str, Any] = field(default_factory=dict)


class ImprovementStatus(str, Enum):
    CREATED = "created"
    RESEARCHING = "researching"
    CANDIDATE = "candidate"
    TESTING = "testing"
    VERIFIED = "verified"
    PROMOTED = "promoted"
    REJECTED = "rejected"
    ROLLED_BACK = "rolled_back"

    @property
    def terminal(self) -> bool:
        return self in {
            ImprovementStatus.PROMOTED,
            ImprovementStatus.REJECTED,
            ImprovementStatus.ROLLED_BACK,
        }


@dataclass(frozen=True)
class ImprovementHypothesis:
    objective: str
    hypothesis: str
    rationale: str
    success_criteria: tuple[str, ...] = ()
    constraints: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ImprovementCandidate:
    id: str
    mission_id: str
    candidate_mission_id: str
    source_plan_revision_id: Optional[str]
    candidate_plan_revision_id: str
    hypothesis: ImprovementHypothesis
    metadata: Mapping[str, Any] = field(default_factory=dict)
    objective_contract: Optional[ObjectiveContract] = None


@dataclass(frozen=True)
class ImprovementEvaluation:
    candidate_id: str
    passed: bool
    score: float
    evidence: tuple[str, ...] = ()
    metrics: Mapping[str, float] = field(default_factory=dict)
    reason: Optional[str] = None


@dataclass(frozen=True)
class ImprovementRun:
    id: str
    mission_id: str
    candidate_id: str
    status: ImprovementStatus
    evaluation: Optional[ImprovementEvaluation] = None
    promoted_plan_revision_id: Optional[str] = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
