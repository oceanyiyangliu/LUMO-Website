"""Versioned benchmark registry with anti-gaming checks."""
from __future__ import annotations
from dataclasses import dataclass
import hashlib,json
from typing import Callable,Mapping
@dataclass(frozen=True)
class BenchmarkSpec:
    benchmark_id:str; version:str; command:tuple[str,...]; metrics:tuple[str,...]; immutable:bool=True
    @property
    def fingerprint(self): return hashlib.sha256(json.dumps({"id":self.benchmark_id,"version":self.version,"command":self.command,"metrics":self.metrics},sort_keys=True,separators=(",",":")).encode()).hexdigest()
class BenchmarkRegistry:
    def __init__(self): self._items={}
    def register(self,spec:BenchmarkSpec):
        key=(spec.benchmark_id,spec.version)
        if key in self._items and self._items[key].fingerprint!=spec.fingerprint: raise ValueError("benchmark version is immutable")
        self._items[key]=spec
    def get(self,bid,version): return self._items.get((bid,version))
    def versions(self,bid): return tuple(v for (i,v) in self._items if i==bid)
class AntiGamingGate:
    def validate(self,baseline:Mapping[str,float],candidate:Mapping[str,float],required:tuple[str,...])->tuple[bool,tuple[str,...]]:
        errors=[]
        if set(baseline)!=set(candidate): errors.append("metric set changed")
        for metric in required:
            if metric not in candidate: errors.append(f"required metric missing: {metric}")
            elif metric in baseline and not isinstance(candidate[metric],(int,float)): errors.append(f"non-numeric metric: {metric}")
        return not errors,tuple(errors)
