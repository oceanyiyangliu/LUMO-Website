"""Evidence-first observatory and improvement backlog for LUMO self-improvement.

This module turns the overnight loop from a static code-edit loop into a durable
engineering system: observe -> discover -> prioritize -> measure -> change ->
verify -> compare -> promote -> learn. It is intentionally deterministic at the
control-plane boundary; local models may propose changes but never define truth.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import ast, hashlib, json, re, subprocess, time
from typing import Any, Iterable


@dataclass(frozen=True)
class ImprovementArea:
    area_id: str
    title: str
    category: str
    description: str
    evidence: tuple[str, ...]
    default_priority: int


@dataclass(frozen=True)
class Finding:
    finding_id: str
    area_id: str
    severity: str
    title: str
    evidence: tuple[str, ...]
    suggested_verification: tuple[str, ...]
    fingerprint: str


@dataclass(frozen=True)
class SystemSnapshot:
    timestamp: float
    source_files: int
    source_bytes: int
    test_files: int
    test_count_estimate: int
    todo_count: int
    exception_bare_count: int
    duplicate_css_values: int
    ui_transition_count: int
    stale_provider_hits: int
    architecture_reference_hits: int
    findings: tuple[Finding, ...]


# The complete improvement charter. The entries are deliberately explicit so
# the overnight worker has a stable, inspectable contract instead of relying on
# a prompt to remember product requirements.
AREAS: tuple[ImprovementArea, ...] = tuple(
    ImprovementArea(str(i), title, category, description, evidence, priority)
    for i, (title, category, description, evidence, priority) in enumerate([
        ("Self-awareness", "architecture", "Maintain a machine-readable understanding of subsystems, APIs, state and dependencies.", ("structural",), 95),
        ("Codebase audit", "quality", "Find dead code, duplication, unreachable branches, leaks and architecture smells.", ("structural", "tests"), 90),
        ("Bug hunting", "reliability", "Generate and execute boundary, malformed-input and failure-path tests.", ("behavioral", "tests"), 98),
        ("State machines", "reliability", "Exercise every legal transition plus restart, duplicate and out-of-order events.", ("behavioral", "persistence"), 99),
        ("Performance", "performance", "Measure and improve startup, API, mission, model and UI latency.", ("benchmark",), 85),
        ("Visual UX", "ux", "Inspect rendered UI for density, hierarchy, clipping and interaction friction.", ("behavioral", "composite"), 96),
        ("Visual regression", "ux", "Compare UI baselines and candidate renders with semantic interaction checks.", ("behavioral", "benchmark"), 94),
        ("Design system", "ux", "Normalize spacing, typography, radii, surfaces, controls and responsive tokens.", ("structural", "behavioral"), 80),
        ("Motion design", "ux", "Audit animation timing, easing and state-change communication; remove decorative delay.", ("behavioral", "benchmark"), 82),
        ("Startup experience", "startup", "Instrument native launch, first frame and truthful setup substages.", ("benchmark", "behavioral"), 100),
        ("Intelligence routing", "intelligence", "Choose the smallest capable local model using task, capability and resources.", ("benchmark", "behavioral"), 92),
        ("Model specialization", "intelligence", "Benchmark installed models on actual LUMO workloads.", ("benchmark",), 78),
        ("Model benchmark suite", "intelligence", "Maintain representative planning, coding, vision and tool-use workloads.", ("benchmark",), 78),
        ("Memory optimization", "resources", "Find leaks, oversized caches, duplicate state and unnecessary residency.", ("benchmark", "structural"), 88),
        ("Resource governor", "resources", "Model RAM pressure, headroom, swap and workload requirements.", ("benchmark", "behavioral"), 97),
        ("Graceful app management", "resources", "Select low-disruption background applications and verify graceful exits.", ("behavioral", "persistence"), 96),
        ("Safety audit", "safety", "Continuously test authorization, permission, file and action boundaries.", ("behavioral",), 100),
        ("Emergency Stop", "safety", "Exercise stop during planning, execution, setup, inference and recovery.", ("behavioral", "persistence"), 100),
        ("Permission diagnostics", "safety", "Distinguish granted, denied, pending, revoked and unknown TCC state.", ("behavioral",), 99),
        ("API self-testing", "reliability", "Test endpoint contracts, malformed input, duplicates, concurrency and restart.", ("tests", "behavioral"), 93),
        ("Core/UI contracts", "architecture", "Verify frontend/backend schema and naming compatibility.", ("structural", "tests"), 94),
        ("Event sourcing", "reliability", "Verify commit-before-delivery, ordering, replay and duplicate handling.", ("persistence", "concurrency"), 100),
        ("Mission planning", "missions", "Reject invalid dependencies, cycles, contradictions and impossible acceptance criteria.", ("structural", "behavioral"), 99),
        ("Mission efficiency", "missions", "Measure actions, model calls, replans, latency and outcomes.", ("benchmark",), 84),
        ("Failure learning", "intelligence", "Persist root causes, fixes, verification and recurrence.", ("persistence",), 86),
        ("Regression memory", "intelligence", "Prevent repeatedly trying changes previously rejected or reverted.", ("persistence",), 90),
        ("Evidence scoring", "governance", "Make promotion depend on measurable improvement rather than tests alone.", ("composite",), 100),
        ("A/B validation", "governance", "Run identical workloads against baseline and candidate where measurable.", ("benchmark",), 91),
        ("Experimentation", "governance", "Test explicit engineering hypotheses against real measurements.", ("benchmark",), 88),
        ("Release audit", "release", "Freeze changes and run full install, setup, mission, safety and recovery verification.", ("composite",), 100),
        ("Failure injection", "reliability", "Inject process, service, state and permission failures and verify recovery.", ("behavioral", "persistence"), 98),
        ("Sleep/wake", "platform", "Verify coherent state across sleep and wake.", ("behavioral", "persistence"), 74),
        ("Network resilience", "platform", "Keep local operation robust when network services fail or recover.", ("behavioral",), 70),
        ("Local-only guarantee", "intelligence", "Scan runtime paths for forbidden cloud fallback or hidden remote inference.", ("structural", "behavioral"), 100),
        ("Secret safety", "security", "Detect credential leakage in code, logs and proposed changes.", ("structural",), 100),
        ("Log quality", "observability", "Detect noisy, contradictory, misleading or sensitive logging.", ("structural", "behavioral"), 87),
        ("Truthful status", "ux", "Ensure user-facing states reflect actual authoritative evidence.", ("behavioral",), 100),
        ("Readiness engine", "release", "Require explicit evidence for every launch-critical capability.", ("composite",), 100),
        ("Build system", "release", "Detect stale artifacts, source/package mismatch and build inefficiency.", ("structural", "benchmark"), 95),
        ("macOS integration", "platform", "Test lifecycle, displays, permissions, appearance and native services.", ("behavioral",), 91),
        ("Computer control", "automation", "Verify coordinates, scaling, screenshots, actions and post-action state.", ("behavioral",), 99),
        ("Visual computer use", "automation", "Measure screenshot-decision-action-verification reliability.", ("benchmark", "behavioral"), 96),
        ("User friction", "ux", "Detect repeated clicks, backtracking, cancellations and abandoned flows.", ("behavioral",), 76),
        ("Accessibility", "ux", "Audit keyboard, VoiceOver, contrast, target sizes and reduced motion.", ("behavioral",), 79),
        ("Appearance modes", "ux", "Test light/dark, high contrast, transparency and reduced motion.", ("behavioral",), 76),
        ("Responsive UI", "ux", "Test minimum, normal, large and unusual window sizes.", ("behavioral",), 86),
        ("Documentation", "maintainability", "Keep architecture and operational documentation synchronized with code.", ("structural",), 55),
        ("Dead architecture removal", "maintainability", "Remove obsolete providers, endpoints, services and compatibility shims.", ("structural",), 81),
        ("Dependencies", "maintainability", "Audit unused, duplicated, vulnerable and risky dependencies.", ("structural",), 69),
        ("Crash recovery", "reliability", "Recover Core/UI/workers from crashes without phantom active state.", ("behavioral", "persistence"), 99),
        ("Resource-aware worker", "resources", "Scale self-improvement depth to actual machine headroom.", ("benchmark",), 89),
        ("Proposal quality", "governance", "Require problem, evidence, root cause, change, risk and verification plan.", ("structural",), 100),
        ("Change size limits", "governance", "Escalate or isolate large changes and keep small changes reversible.", ("structural",), 97),
        ("Candidate isolation", "governance", "Keep autonomous candidates out of production until promotion evidence exists.", ("persistence",), 100),
        ("Automatic rollback", "governance", "Rollback candidates that fail tests, runtime, performance or visual gates.", ("behavioral", "persistence"), 100),
        ("Multi-cycle validation", "governance", "Repeat sensitive validation across independent cycles before promotion.", ("benchmark", "behavioral"), 93),
        ("Adversarial review", "governance", "Try to break candidate changes before promotion.", ("behavioral",), 91),
        ("Engineering memory", "intelligence", "Persist durable lessons with evidence and recurrence tracking.", ("persistence",), 92),
        ("Real-world simulation", "reliability", "Simulate setup, mission and computer-use scenarios before release.", ("behavioral",), 94),
        ("Root-cause tracing", "observability", "Trace symptoms through events, state and decisions to root causes.", ("structural", "behavioral"), 93),
        ("Health trending", "observability", "Track latency, failures, resources, regressions and promotion quality over time.", ("benchmark", "persistence"), 88),
        ("Future-state detection", "architecture", "Detect emerging bottlenecks before they become failures.", ("structural", "benchmark"), 73),
        ("Meta improvement", "governance", "Measure and improve the self-improvement process itself.", ("composite",), 100),
        ("Knowledge integrity", "intelligence", "Keep engineering memory provenance-bound, deduplicated and resistant to stale or contradictory lessons.", ("persistence", "structural"), 90),
        ("Launch rehearsal", "release", "Run a complete fresh-install-to-ready rehearsal before any launch claim.", ("composite", "behavioral"), 100),
    ], start=1)
)


class ImprovementObservatory:
    """Deterministic repository observer and durable engineering backlog."""
    def __init__(self, root: Path):
        self.root = root.resolve()
        self.state_dir = self.root / '.ocean' / 'improvement'
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.snapshot_path = self.state_dir / 'latest_snapshot.json'
        self.findings_path = self.state_dir / 'findings.json'
        self.lessons_path = self.state_dir / 'lessons.jsonl'
        self.history_path = self.state_dir / 'history.jsonl'

    def snapshot(self) -> SystemSnapshot:
        source_ext = {'.py','.pyi','.swift','.ts','.tsx','.js','.jsx','.mjs','.css','.scss','.html','.json','.toml','.yaml','.yml','.sh'}
        source=[]; tests=[]; total=0
        for p in self.root.rglob('*'):
            if not p.is_file() or any(part in {'.git','.venv','node_modules','__pycache__','.pytest_cache','.ocean'} for part in p.parts): continue
            if p.suffix.lower() in source_ext:
                source.append(p)
                if p.name.startswith('test_') or 'tests' in p.parts: tests.append(p)
                try: total += p.stat().st_size
                except OSError: pass
        findings=[]; todo=bare=transitions=stale=arch=cssvals=0
        for p in source:
            try: text=p.read_text(errors='replace')
            except OSError: continue
            todo += len(re.findall(r'\b(?:TODO|FIXME|XXX)\b',text,re.I))
            bare += len(re.findall(r'except\\s+Exception\\s*:',text))
            transitions += len(re.findall(r'transition\\s*:',text))
            cssvals += len(re.findall(r'(?i)(?:padding|margin|gap|border-radius)\\s*:\\s*\\d+px',text))
            stale += len(re.findall(r'(?i)(?:openai|OPENAI_API_KEY|active[-_ ]assistant|launchagents)',text))
            arch += len(re.findall(r'(?i)(?:localhost:3000|localhost:8767|api/setup/autopilot)',text))
        if todo: findings.append(self._finding('2','maintenance','medium','Unresolved TODO/FIXME markers',f'{todo} markers found',('targeted tests',)))
        if stale: findings.append(self._finding('34','intelligence','critical','Potential stale cloud/legacy architecture references',f'{stale} references found',('runtime path audit','local-only smoke',)))
        if transitions > 20: findings.append(self._finding('9','ux','medium','High animation/transition surface area',f'{transitions} transition declarations found',('visual regression','reduced-motion check')))
        if cssvals > 40: findings.append(self._finding('8','ux','low','Many hard-coded spacing/radius values',f'{cssvals} declarations found',('design-token audit',)))
        snap=SystemSnapshot(time.time(),len(source),total,len(tests),self._estimate_tests(tests),todo,bare,cssvals,transitions,stale,arch,tuple(findings))
        self.snapshot_path.write_text(json.dumps(self._json(snap),indent=2,sort_keys=True))
        self.history_path.open('a').write(json.dumps(self._json(snap))+"\n")
        self.findings_path.write_text(json.dumps([self._json(x) for x in findings],indent=2,sort_keys=True))
        return snap

    def _estimate_tests(self, files: Iterable[Path]) -> int:
        n=0
        for p in files:
            try: n += len(re.findall(r'^\s*def\s+test_',p.read_text(errors='replace'),re.M))
            except OSError: pass
        return n

    def _finding(self, area_id, severity, level, title, evidence, verification):
        raw=f'{area_id}|{severity}|{title}|{evidence}'
        return Finding(hashlib.sha256(raw.encode()).hexdigest()[:16],area_id,severity,title,(evidence,),tuple(verification),hashlib.sha256(raw.encode()).hexdigest())

    def backlog(self, limit=12) -> list[ImprovementArea]:
        snap=self.snapshot()
        found={f.area_id for f in snap.findings}
        areas=sorted(AREAS,key=lambda a:(0 if a.area_id in found else 1,-a.default_priority))
        return areas[:limit]

    def record_lesson(self, lesson: dict[str,Any]) -> None:
        payload={**lesson,'timestamp':time.time()}
        self.lessons_path.open('a').write(json.dumps(payload,sort_keys=True,default=str)+'\n')

    @staticmethod
    def _json(obj):
        if hasattr(obj,'__dataclass_fields__'): return {k: ImprovementObservatory._json(v) for k,v in asdict(obj).items()}
        if isinstance(obj,tuple): return [ImprovementObservatory._json(x) for x in obj]
        if isinstance(obj,dict): return {k:ImprovementObservatory._json(v) for k,v in obj.items()}
        return obj
