from .engine import SelfImprovementEngine
from .types import (
    ImprovementCandidate,
    ImprovementEvaluation,
    ImprovementHypothesis,
    ImprovementRun,
    ImprovementStatus,
)

__all__ = [
    "SelfImprovementEngine",
    "ImprovementCandidate",
    "ImprovementEvaluation",
    "ImprovementHypothesis",
    "ImprovementRun",
    "ImprovementStatus",
    "AutonomousImprovementCoordinator",
    "AutonomousImprovementRequest",
    "AutonomousImprovementResult",
]

from ocean.self_improvement.isolation import (
    CandidateIsolation,
    CandidateIsolationError,
    CandidateIsolationService,
    CandidateTaskMapping,
)

from ocean.self_improvement.execution_boundary import (
    CandidateExecutionBoundary,
    CandidateExecutionBoundaryError,
    CandidateExecutionContext,
)


from .coordinator import (
    AutonomousImprovementCoordinator,
    AutonomousImprovementRequest,
    AutonomousImprovementResult,
)

from .code_modification import ProductionCodePromotionService
from .repository_context import RepositoryContext, RepositoryContextService
from .objective import EvidenceKind, ObjectiveContract

__all__ += ["EvidenceKind", "ObjectiveContract"]

from .observatory import ImprovementObservatory, ImprovementArea, Finding, SystemSnapshot, AREAS
