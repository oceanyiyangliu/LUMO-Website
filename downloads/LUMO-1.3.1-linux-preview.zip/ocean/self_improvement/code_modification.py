from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Protocol
import difflib
import json
import os
import shutil
import tempfile

from ocean.core.ids import new_id


@dataclass(frozen=True)
class CodeModificationRequest:
    candidate_id: str
    objective: str
    repository_root: Path
    constraints: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.candidate_id.strip():
            raise ValueError("code modification candidate_id must not be empty")
        if not self.objective.strip():
            raise ValueError("code modification objective must not be empty")
        if not self.repository_root.exists():
            raise ValueError("repository root does not exist")
        if not self.repository_root.is_dir():
            raise ValueError("repository root must be a directory")


@dataclass(frozen=True)
class CodeChange:
    path: str
    content: str


@dataclass(frozen=True)
class CodeModification:
    candidate_id: str
    changes: tuple[CodeChange, ...]
    rationale: str = ""
    metadata: Mapping[str, Any] = field(default_factory=dict)


class CodeModificationProvider(Protocol):
    def generate(self, request: CodeModificationRequest) -> CodeModification:
        ...


@dataclass(frozen=True)
class CandidateWorkspace:
    id: str
    candidate_id: str
    root: Path
    source_root: Path


class CandidateWorkspaceService:
    """Creates disposable filesystem isolation for autonomous code changes."""

    def create(
        self,
        *,
        candidate_id: str,
        repository_root: Path,
    ) -> CandidateWorkspace:
        source = repository_root.resolve()
        if not source.exists() or not source.is_dir():
            raise ValueError("repository root must be an existing directory")

        self._validate_source_symlinks(source)

        root = Path(
            tempfile.mkdtemp(
                prefix=f"ocean-candidate-{candidate_id}-"
            )
        ).resolve()

        shutil.copytree(
            source,
            root,
            dirs_exist_ok=True,
            ignore=shutil.ignore_patterns(
                ".git",
                ".venv",
                "__pycache__",
                ".pytest_cache",
                ".ocean",
            ),
        )

        return CandidateWorkspace(
            id=new_id("candidate_workspace"),
            candidate_id=candidate_id,
            root=root,
            source_root=source,
        )

    @staticmethod
    def _validate_source_symlinks(source: Path) -> None:
        """Reject symlinks in autonomous candidate source trees.

        ``copytree(..., symlinks=False)`` can preserve absolute symlink targets
        that resolve outside the candidate copy. Rather than relying on every
        platform's symlink-copy semantics, autonomous improvement workspaces
        fail closed when the source contains any symlink.
        """
        ignored_roots = {".git", ".venv", "__pycache__", ".pytest_cache", ".ocean"}
        for path in source.rglob("*"):
            relative = path.relative_to(source)
            if relative.parts and relative.parts[0] in ignored_roots:
                continue
            if path.is_symlink():
                target = path.resolve(strict=False)
                try:
                    target.relative_to(source)
                except ValueError as exc:
                    raise ValueError(
                        f"symlinks are forbidden in autonomous candidate repositories: "
                        f"{relative!s} -> {target!s}"
                    ) from exc

    def destroy(self, workspace: CandidateWorkspace) -> None:
        root = workspace.root.resolve()
        if root == workspace.source_root:
            raise ValueError("refusing to destroy source repository")
        shutil.rmtree(root, ignore_errors=False)


class CodeModificationService:
    """Applies provider-generated code only inside a candidate workspace."""

    def __init__(self, *, workspaces: CandidateWorkspaceService) -> None:
        self._workspaces = workspaces

    def generate_and_apply(
        self,
        *,
        request: CodeModificationRequest,
        provider: CodeModificationProvider,
    ) -> tuple[CandidateWorkspace, CodeModification]:
        workspace = self._workspaces.create(
            candidate_id=request.candidate_id,
            repository_root=request.repository_root,
        )

        candidate_request = CodeModificationRequest(
            candidate_id=request.candidate_id,
            objective=request.objective,
            repository_root=workspace.root,
            constraints={
                **dict(request.constraints),
                "candidate_workspace": True,
                "source_repository": str(request.repository_root.resolve()),
                "production_mutation_forbidden": True,
            },
        )

        modification = provider.generate(candidate_request)

        if modification.candidate_id != request.candidate_id:
            self._workspaces.destroy(workspace)
            raise ValueError(
                "code modification provider returned the wrong candidate"
            )

        seen: set[str] = set()

        try:
            source_root = workspace.source_root
            implementation_changes = 0
            total_changed_lines = 0
            for change in modification.changes:
                relative = Path(change.path)

                if relative.is_absolute():
                    raise ValueError(
                        f"absolute code modification path forbidden: {change.path!r}"
                    )

                if ".." in relative.parts:
                    raise ValueError(
                        f"path traversal forbidden: {change.path!r}"
                    )

                normalized = relative.as_posix()
                if normalized in seen:
                    raise ValueError(
                        f"duplicate code modification path: {change.path!r}"
                    )
                seen.add(normalized)

                target = (workspace.root / relative).resolve()

                try:
                    target.relative_to(workspace.root)
                except ValueError:
                    raise ValueError(
                        f"code modification escapes candidate workspace: "
                        f"{change.path!r}"
                    )

                if target.exists() and not target.is_file():
                    raise ValueError(
                        f"code modification target is not a file: {change.path!r}"
                    )

                # Existing tests are immutable. A model may add a new test, but
                # it may not edit/delete a baseline test to manufacture a pass.
                source = source_root / relative
                if not source.exists() and not source.parent.is_dir():
                    raise ValueError(
                        f"code modification parent directory does not exist: {change.path!r}"
                    )
                is_test_path = (
                    relative.parts
                    and (relative.parts[0] in {"tests", "test"} or relative.name.startswith("test_"))
                )
                if is_test_path and source.is_file():
                    original = source.read_text(encoding="utf-8")
                    if original != change.content:
                        raise ValueError(
                            f"existing test modification forbidden: {change.path!r}"
                        )

                # Refuse secret/config material and binary-looking payloads at
                # the model boundary. Secrets must never become an artifact of
                # autonomous evolution, even inside a candidate workspace.
                if relative.name in {".env", ".env.local", ".env.production", "id_rsa"}:
                    raise ValueError(f"secret file modification forbidden: {change.path!r}")
                if "BEGIN PRIVATE KEY" in change.content or "OPENAI_API_KEY=" in change.content:
                    raise ValueError("secret material detected in autonomous code proposal")

                before = source.read_text(encoding="utf-8").splitlines() if source.is_file() else []
                after = change.content.splitlines()
                total_changed_lines += sum(
                    1 for line in difflib.ndiff(before, after)
                    if line.startswith("+ ") or line.startswith("- ")
                )
                if not is_test_path:
                    implementation_changes += 1

                # Keep proposals genuinely surgical. Large rewrites are both
                # hard for small local models and difficult to verify safely.
                if len(change.content) > 80_000:
                    raise ValueError(f"code modification is too large: {change.path!r}")

                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(change.content, encoding="utf-8")

            if implementation_changes == 0:
                raise ValueError("proposal contains no implementation change")
            if total_changed_lines > 600:
                raise ValueError(
                    "proposal changes too many lines for a focused autonomous experiment"
                )

            return workspace, modification

        except Exception:
            self._workspaces.destroy(workspace)
            raise

    def destroy_workspace(
        self,
        workspace: CandidateWorkspace,
    ) -> None:
        """Destroy a candidate workspace through the owned workspace service."""
        self._workspaces.destroy(workspace)

    def diff(
        self,
        workspace: CandidateWorkspace,
    ) -> str:
        """Return the candidate-vs-source diff without mutating production."""
        source = workspace.source_root
        candidate = workspace.root

        source_files = {
            path.relative_to(source)
            for path in source.rglob("*")
            if path.is_file()
            and ".git" not in path.parts
            and ".venv" not in path.parts
            and "__pycache__" not in path.parts
            and ".pytest_cache" not in path.parts
        }

        candidate_files = {
            path.relative_to(candidate)
            for path in candidate.rglob("*")
            if path.is_file()
            and ".git" not in path.parts
            and ".venv" not in path.parts
            and "__pycache__" not in path.parts
            and ".pytest_cache" not in path.parts
        }

        output: list[str] = []

        for relative in sorted(source_files | candidate_files, key=str):
            before_path = source / relative
            after_path = candidate / relative

            before = (
                before_path.read_text().splitlines(keepends=True)
                if before_path.exists()
                else []
            )
            after = (
                after_path.read_text().splitlines(keepends=True)
                if after_path.exists()
                else []
            )

            if before == after:
                continue

            output.extend(
                difflib.unified_diff(
                    before,
                    after,
                    fromfile=f"production/{relative}",
                    tofile=f"candidate/{relative}",
                )
            )

        return "".join(output)


@dataclass(frozen=True)
class CodePromotionReceipt:
    run_id: str
    production_root: Path
    backup_root: Path
    changed_paths: tuple[str, ...]


class ProductionCodePromotionService:
    """Promotes validated candidate files with filesystem compensation."""

    _PROTECTED = {".git", ".venv", ".ocean", "__pycache__", ".pytest_cache"}
    _SECRET_NAMES = {".env", ".env.local", ".env.production"}

    def promote(
        self,
        *,
        candidate_root: Path,
        production_root: Path,
        changed_paths: tuple[str, ...],
        run_id: str,
    ) -> CodePromotionReceipt:
        candidate = candidate_root.resolve()
        production = production_root.resolve()
        if candidate == production:
            raise ValueError("candidate and production roots must differ")
        if not candidate.is_dir() or not production.is_dir():
            raise ValueError("candidate and production roots must be directories")
        if not run_id.strip():
            raise ValueError("run_id must not be empty")

        normalized: list[str] = []
        seen: set[str] = set()
        for raw in changed_paths:
            relative = Path(raw)
            if relative.is_absolute() or ".." in relative.parts:
                raise ValueError(f"unsafe production path: {raw!r}")
            if any(part in self._PROTECTED for part in relative.parts):
                raise ValueError(f"protected production path: {raw!r}")
            if relative.name in self._SECRET_NAMES:
                raise ValueError(f"secret file promotion forbidden: {raw!r}")
            value = relative.as_posix()
            if value not in seen:
                seen.add(value)
                normalized.append(value)

        backup = production / ".ocean" / "code_backups" / run_id
        backup.mkdir(parents=True, exist_ok=False)
        manifest: list[dict[str, object]] = []

        try:
            for value in normalized:
                relative = Path(value)
                source = (candidate / relative).resolve()
                target = (production / relative).resolve()
                source.relative_to(candidate)
                target.relative_to(production)
                if not source.is_file():
                    raise ValueError(f"candidate changed file does not exist: {value!r}")

                target_backup = backup / relative
                target_backup.parent.mkdir(parents=True, exist_ok=True)
                existed = target.exists()
                if existed:
                    if not target.is_file():
                        raise ValueError(f"production target is not a file: {value!r}")
                    target_backup.write_bytes(target.read_bytes())

                target.parent.mkdir(parents=True, exist_ok=True)
                temporary = target.with_name(target.name + ".ocean-promotion-tmp")
                temporary.write_bytes(source.read_bytes())
                temporary.replace(target)
                manifest.append({"path": value, "existed": existed})

            manifest_path = backup / "manifest.json"
            manifest_path.write_text(
                json.dumps(manifest, sort_keys=True, indent=2),
                encoding="utf-8",
            )
            state_path = backup / "state.json"
            state_path.write_text(json.dumps({"state": "applied"}), encoding="utf-8")
            self._fsync_file(manifest_path)
            self._fsync_file(state_path)
            self._fsync_dir(backup)
            return CodePromotionReceipt(
                run_id=run_id,
                production_root=production,
                backup_root=backup,
                changed_paths=tuple(normalized),
            )
        except Exception:
            self.rollback(
                CodePromotionReceipt(
                    run_id=run_id,
                    production_root=production,
                    backup_root=backup,
                    changed_paths=tuple(normalized),
                ),
                cleanup=True,
            )
            raise

    def rollback(self, receipt: CodePromotionReceipt, *, cleanup: bool = False) -> None:
        production = receipt.production_root.resolve()
        backup = receipt.backup_root.resolve()
        if not backup.is_dir():
            raise ValueError(f"promotion backup does not exist: {backup}")
        manifest_path = backup / "manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        for item in reversed(manifest):
            relative = Path(str(item["path"]))
            target = (production / relative).resolve()
            target.relative_to(production)
            if bool(item["existed"]):
                source = (backup / relative).resolve()
                source.relative_to(backup)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(source.read_bytes())
            elif target.exists():
                target.unlink()
        if cleanup:
            state_path = backup / "state.json"
            state_path.write_text(json.dumps({"state": "rolled_back"}), encoding="utf-8")
            self._fsync_file(state_path)
            self._fsync_dir(backup)
            shutil.rmtree(backup, ignore_errors=True)

    def recover_incomplete(self, production_root: Path) -> tuple[str, ...]:
        """Compensate filesystem promotions left applied by a crashed run.

        An applied journal without a subsequent logical promotion commit is
        conservatively rolled back. This preserves the invariant that the
        filesystem never remains ahead of the durable improvement lifecycle.
        """
        production = production_root.resolve()
        backup_root = production / ".ocean" / "code_backups"
        if not backup_root.is_dir():
            return ()

        recovered: list[str] = []
        for backup in sorted(backup_root.iterdir(), key=lambda path: path.name):
            if not backup.is_dir():
                continue
            state_path = backup / "state.json"
            manifest_path = backup / "manifest.json"
            if not state_path.is_file() or not manifest_path.is_file():
                continue
            try:
                state = json.loads(state_path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            if state.get("state") != "applied":
                continue
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            receipt = CodePromotionReceipt(
                run_id=backup.name,
                production_root=production,
                backup_root=backup,
                changed_paths=tuple(str(item["path"]) for item in manifest),
            )
            self.rollback(receipt, cleanup=True)
            recovered.append(backup.name)

        return tuple(recovered)

    @staticmethod
    def _fsync_file(path: Path) -> None:
        with path.open("rb") as handle:
            os.fsync(handle.fileno())

    @staticmethod
    def _fsync_dir(path: Path) -> None:
        try:
            fd = os.open(path, os.O_RDONLY)
        except OSError:
            return
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
