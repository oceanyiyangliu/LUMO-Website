from __future__ import annotations

from typing import Any, Optional
from dataclasses import dataclass

# This helper is intentionally additive: it provides a bridge to execute
# research requests through an ExecutionRuntime while leaving the existing
# ResearchService implementation untouched for backward compatibility.


@dataclass
class ResearchRuntimeIntegration:
    execution_runtime: Any

    def conduct_via_runtime(self, request: Any, *, capability_name: str = "research") -> Any:
        """Route a research request through the supplied ExecutionRuntime.

        This method expects the execution_runtime to expose an .execute(request)
        method compatible with runtime.ExecutionRuntime. The exact execution
        request shape varies between deployments; this helper attempts to build
        a conservative, widely accepted request payload and returns the raw
        runtime result for higher-level conversion by callers.

        The helper is deliberately small and permissive: projects can extend it
        to map runtime results into ResearchReport/ResearchFinding domain types.
        """
        # Lazy import to avoid importing runtime types in environments where
        # they are not required by tests that do not wire the runtime.
        try:
            from runtime.types import ExecutionRequest
        except Exception:
            raise RuntimeError("runtime.types.ExecutionRequest is required to route research via runtime")

        execution_id = getattr(request, "execution_id", None) or "research-" + uuid4_hex()

        exec_request = ExecutionRequest(
            task_id=f"research:{getattr(request, 'candidate_id', 'unknown')}",
            capability=capability_name,
            operation="run",
            agent_id="self-improvement",
            arguments={
                **(getattr(request, "queries", {}) or {}),
                "candidate_id": getattr(request, "candidate_id", None),
                "objective": getattr(request, "objective", None),
                "metadata": getattr(request, "metadata", None),
            },
            execution_id=execution_id,
        )

        return self.execution_runtime.execute(exec_request)


def uuid4_hex() -> str:
    import uuid

    return uuid.uuid4().hex
