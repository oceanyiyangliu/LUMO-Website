from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class RepositoryContext:
    tree: str
    files: str

    def as_prompt_text(self) -> str:
        return f"REPOSITORY TREE:\n{self.tree}\n\nREPOSITORY FILES:\n{self.files}"

    def as_routing_prompt_text(self) -> str:
        """Return a compact repository index for capability routing.

        Strategic routing should decide *what kind of work* is needed, not
        inspect source code. Source contents remain available to the worker
        that actually performs research, implementation, testing, or
        verification. Keeping this boundary explicit also prevents small
        local models from mistaking source prose for routing instructions.
        """
        return (
            "REPOSITORY ROUTING INDEX:\n"
            "The repository is available to downstream workers. Use this index "
            "only to understand the repository shape; do not infer task "
            "semantics from source contents.\n"
            f"{self.tree}"
        )


class RepositoryContextService:
    """Build bounded, deterministic source context for the model."""

    _SKIP = {
        ".git", ".venv", ".ocean", "__pycache__", ".pytest_cache",
        ".mypy_cache", ".ruff_cache", "node_modules",
        ".lumo-worlds", "build", "dist", ".next", "coverage",
        ".cache",
    }
    # Agent transcripts and interaction histories are untrusted process context,
    # not repository evidence. Feeding them to an improvement model can cause
    # stale instructions to override the current objective.
    _SKIP_NAME_PREFIXES = (
        ".aider",
        ".claude",
        ".cursor",
    )
    _SKIP_NAME_SUFFIXES = (
        ".history",
        ".history.md",
        ".log",
    )
    _TEXT_SUFFIXES = {
        ".py", ".toml", ".md", ".txt", ".json", ".yaml", ".yml",
        ".ini", ".cfg", ".sh", ".ts", ".tsx", ".js", ".jsx", ".css",
    }

    def __init__(
        self,
        *,
        max_chars: int = 10_000,
        max_file_chars: int = 3_500,
    ) -> None:
        if max_chars <= 0 or max_file_chars <= 0:
            raise ValueError("context limits must be positive")
        self._max_chars = max_chars
        self._max_file_chars = min(max_file_chars, max_chars)

    def build(self, root: Path, objective: str = "") -> RepositoryContext:
        root = root.resolve()
        files = [
            p for p in root.rglob("*")
            if (
                p.is_file()
                and not any(part in self._SKIP for part in p.parts)
                and not any(
                    part.startswith(self._SKIP_NAME_PREFIXES)
                    or part.endswith(self._SKIP_NAME_SUFFIXES)
                    for part in p.relative_to(root).parts
                )
            )
        ]
        files.sort(key=lambda p: str(p.relative_to(root)))

        tree = "\n".join(str(p.relative_to(root)) for p in files)
        if len(tree) > 3_000:
            tree = tree[:2_900] + "\n[FILE TREE TRUNCATED]"
        keywords = {w.lower() for w in objective.split() if len(w) >= 4}
        ranked = sorted(
            files,
            key=lambda p: (
                -sum(k in str(p.relative_to(root)).lower() for k in keywords),
                0 if p.suffix.lower() in self._TEXT_SUFFIXES else 1,
                str(p.relative_to(root)),
            ),
        )

        chunks: list[str] = []
        used = 0
        for path in ranked:
            if path.suffix.lower() not in self._TEXT_SUFFIXES:
                continue
            try:
                text = path.read_text(encoding="utf-8")
            except (UnicodeDecodeError, OSError):
                continue
            relative = path.relative_to(root)
            # Never feed a model a single giant source file. A truncated file
            # is much more useful when the truncation boundary is per-file and
            # the overall context remains comfortably below common local-model
            # context windows.
            content = text[: self._max_file_chars]
            if len(text) > self._max_file_chars:
                content += "\n[FILE TRUNCATED FOR MODEL CONTEXT]"
            chunk = f"\n--- {relative} ---\n{content}"
            remaining = self._max_chars - used
            if remaining <= 0:
                break
            if len(chunk) > remaining:
                chunk = chunk[:remaining] + "\n[CONTEXT TRUNCATED]"
            chunks.append(chunk)
            used += len(chunk)

        return RepositoryContext(tree=tree, files="".join(chunks))
