from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import os
import shutil
import signal
import subprocess
import sys
import time
from typing import Any, Mapping, Optional
import uuid
from datetime import datetime, timezone
import threading

try:
    import psutil
except ImportError:  # pragma: no cover
    psutil = None


_TEST_EXECUTION_LOCK = threading.Lock()


_SAFE_CANDIDATE_ENV = frozenset({
    "PATH", "HOME", "TMPDIR", "TMP", "TEMP", "LANG", "LC_ALL", "LC_CTYPE",
    "USER", "LOGNAME", "VIRTUAL_ENV", "SystemRoot", "WINDIR", "COMSPEC",
})


@dataclass(frozen=True)
class CandidateTestExecutionRequest:
    candidate_id: str
    workspace_root: str
    command: tuple[str, ...] = ("python", "-m", "pytest", "-q")
    timeout_seconds: float = 120.0
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.candidate_id.strip():
            raise ValueError("candidate_id must not be empty")

        if not self.workspace_root.strip():
            raise ValueError("workspace_root must not be empty")

        if not self.command:
            raise ValueError("command must not be empty")

        if any(not part for part in self.command):
            raise ValueError("command must not contain empty arguments")

        if self.timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be > 0")


@dataclass(frozen=True)
class TestExecutionResult:
    candidate_id: str
    command: tuple[str, ...]
    workspace_root: str
    passed: bool
    exit_code: Optional[int]
    timed_out: bool
    stdout: str
    stderr: str
    duration_seconds: float
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def to_evidence(self) -> dict[str, Any]:
        """Return a canonical LUMO evidence dict with provenance and result summary.

        This representation is intentionally plain (dict) so callers can persist
        it into whatever verification/evidence path they use without needing a
        concrete domain type. The keys are stable and exhaustive for evidence
        consumers: mission, objective, agent, capability, action, timestamp,
        execution_id, result (which includes passed/exit_code/timed_out/duration),
        and original_metadata for extra context.
        """
        # Copy metadata to avoid mutating original mapping if it's mutable.
        meta = dict(self.metadata) if self.metadata is not None else {}

        # Provenance keys should exist; default to explicit 'unknown' when not
        # supplied so evidence consumers need not special-case missing keys.
        provenance = {
            "mission": meta.get("mission") or meta.get("mission_id") or "unknown",
            "objective": meta.get("objective") or meta.get("objective_id") or "unknown",
            "agent": meta.get("agent") or meta.get("agent_id") or "unknown",
            "capability": meta.get("capability") or "test_execution",
            "action": meta.get("action") or "execute",
            "timestamp": meta.get("timestamp") or meta.get("started_at") or datetime.now(timezone.utc).isoformat(),
            "execution_id": meta.get("execution_id") or str(uuid.uuid4()),
        }

        result_summary = {
            "passed": self.passed,
            "exit_code": self.exit_code,
            "timed_out": self.timed_out,
            "duration_seconds": self.duration_seconds,
        }

        evidence = {
            "provenance": provenance,
            "result": result_summary,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "metadata": meta,
            "candidate_id": self.candidate_id,
            "command": list(self.command),
            "workspace_root": self.workspace_root,
        }

        return evidence


class CandidateTestExecutionService:
    """
    Executes candidate tests exclusively inside a candidate workspace.

    Without an ExecutionRuntime, this service uses the legacy local subprocess
    path. When an ExecutionRuntime is supplied, it is a mandatory governance
    boundary: candidate tests never fall back to local execution and runtime
    results must satisfy the canonical structured-result contract.
    """

    def __init__(self, execution_runtime: Optional[Any] = None) -> None:
        # execution_runtime is optional to preserve existing behaviour in tests
        # and in callers that haven't adopted the governed capability boundary.
        self.execution_runtime = execution_runtime

    def run(
        self,
        request: CandidateTestExecutionRequest,
    ) -> TestExecutionResult:
        workspace = Path(request.workspace_root).expanduser().resolve()

        if not workspace.exists():
            raise ValueError(
                f"candidate workspace does not exist: {workspace}"
            )

        if not workspace.is_dir():
            raise ValueError(
                f"candidate workspace is not a directory: {workspace}"
            )

        # A configured runtime is a governance boundary, not an optional
        # optimization. Never silently bypass it when it is unavailable or
        # returns an unrecognizable result. Legacy local execution remains
        # available only when no runtime was configured.
        if self.execution_runtime is not None:
            runtime_result = self._run_via_runtime(request, workspace)
            if runtime_result is None:
                raise RuntimeError(
                    "governed candidate test execution returned no result"
                )
            return runtime_result

        # --- Legacy subprocess path used only without a governed runtime ---
        # Self-improvement is deliberately single-flight at the machine level.
        # This prevents a second autonomous test campaign from multiplying CPU
        # load while another candidate is still being verified.
        # Candidate verification is single-flight, but contention is a queueing
        # condition rather than a campaign failure. Waiting preserves the global
        # resource bound without turning healthy concurrency control into a
        # candidate failure.
        queue_timeout = float(os.getenv("LUMO_SELF_IMPROVEMENT_TEST_QUEUE_TIMEOUT_SECONDS", "21600"))
        acquired = _TEST_EXECUTION_LOCK.acquire(timeout=max(0.0, queue_timeout))
        if not acquired:
            return TestExecutionResult(
                candidate_id=request.candidate_id, command=request.command,
                workspace_root=str(workspace), passed=False, exit_code=None,
                timed_out=False, stdout="",
                stderr=("candidate test execution remained queued behind another active campaign "
                        f"for {queue_timeout:.0f}s; retry is safe"),
                duration_seconds=queue_timeout,
                metadata={**dict(request.metadata or {}),
                          "queued_behind_active_campaign": True, "retryable": True,
                          "queue_timeout_seconds": queue_timeout},
            )
        started = time.monotonic()
        timed_out = False
        exit_code: Optional[int] = None
        stdout = ""
        stderr = ""

        environment = {key: value for key, value in os.environ.items() if key in _SAFE_CANDIDATE_ENV}
        # Candidate verification must never inherit cloud credentials from the
        # service that launched it. This keeps the candidate sandbox bounded.
        environment["LUMO_CANDIDATE_TEST"] = "1"
        for key in tuple(environment):
            if key.startswith("PYTEST_") or key.startswith("COVERAGE_"):
                environment.pop(key, None)

        if any(
            Path(part).name.startswith("pytest") or part == "pytest"
            for part in request.command
        ):
            # Candidate tests must not inherit the orchestration harness,
            # coverage plugins, or parent pytest plugins. This prevents nested
            # test execution from deadlocking when LUMO itself is under test.
            environment["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"

        command = self._executable_command(request.command)

        # Pre-generate deterministic provenance pieces where possible so the
        # evidence can be created even for OSError/timeout cases.
        base_metadata = dict(request.metadata) if request.metadata is not None else {}
        execution_id = base_metadata.get("execution_id") or str(uuid.uuid4())
        # Favor an explicit timestamp if present, otherwise current UTC ISO.
        timestamp = base_metadata.get("timestamp") or datetime.now(timezone.utc).isoformat()

        process = None
        try:
            process = subprocess.Popen(
                list(command),
                cwd=workspace,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=environment,
                start_new_session=(os.name != "nt"),
            )
        except OSError as exc:
            _TEST_EXECUTION_LOCK.release()
            duration = time.monotonic() - started

            # Build metadata including required provenance fields so failures
            # remain durable and discoverable as evidence.
            metadata = {
                **base_metadata,
                "working_directory": str(workspace),
                "timeout_seconds": request.timeout_seconds,
                "executed_command": list(command),
                "execution_id": execution_id,
                "timestamp": timestamp,
                # Allow callers to supply mission/objective/agent/capability/action
            }

            return TestExecutionResult(
                candidate_id=request.candidate_id,
                command=request.command,
                workspace_root=str(workspace),
                passed=False,
                exit_code=None,
                timed_out=False,
                stdout="",
                stderr=f"failed to start candidate test command: {exc}",
                duration_seconds=duration,
                metadata=metadata,
            )

        resource_abort = None
        deadline = started + request.timeout_seconds
        max_rss_bytes = int(float(os.getenv("LUMO_SELF_IMPROVEMENT_MAX_RSS_GIB", "3.0")) * 1024**3)
        max_tree_cpu_percent = float(os.getenv("LUMO_SELF_IMPROVEMENT_MAX_TREE_CPU", "220"))
        max_children = int(os.getenv("LUMO_SELF_IMPROVEMENT_MAX_CHILDREN", "24"))
        cpu_breach_since = None
        try:
            while True:
                try:
                    process.wait(timeout=0.5)
                    break
                except subprocess.TimeoutExpired:
                    now = time.monotonic()
                    if now >= deadline:
                        timed_out = True
                        resource_abort = "wall_clock_timeout"
                        break
                    if psutil is not None:
                        try:
                            root = psutil.Process(process.pid)
                            tree = [root, *root.children(recursive=True)]
                            if len(tree) > max_children:
                                resource_abort = f"process_tree_limit:{len(tree)}>{max_children}"
                                break
                            rss = sum(p.memory_info().rss for p in tree if p.is_running())
                            cpu = sum(p.cpu_percent(interval=None) for p in tree if p.is_running())
                            if rss > max_rss_bytes:
                                resource_abort = f"memory_limit:{rss}>{max_rss_bytes}"
                                break
                            if cpu > max_tree_cpu_percent:
                                cpu_breach_since = cpu_breach_since or now
                                if now - cpu_breach_since >= 5.0:
                                    resource_abort = f"cpu_tree_limit:{cpu:.1f}>{max_tree_cpu_percent:.1f}"
                                    break
                            else:
                                cpu_breach_since = None
                        except (psutil.NoSuchProcess, psutil.AccessDenied):
                            pass

            if resource_abort is not None:
                timed_out = resource_abort == "wall_clock_timeout"
                if os.name != "nt":
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                else:
                    process.kill()
            stdout, stderr = process.communicate(timeout=5)
            exit_code = None if timed_out else process.returncode
        except subprocess.TimeoutExpired:
            resource_abort = resource_abort or "cleanup_timeout"
            if os.name != "nt":
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            else:
                process.kill()
            stdout, stderr = process.communicate()
            exit_code = process.returncode

        duration = time.monotonic() - started

        # Merge original metadata with operational fields and canonical provenance
        metadata = {
            **base_metadata,
            "working_directory": str(workspace),
            "timeout_seconds": request.timeout_seconds,
            "executed_command": list(command),
            "execution_id": execution_id,
            "timestamp": timestamp,
            "resource_abort": resource_abort,
            "resource_limits": {
                "max_rss_bytes": max_rss_bytes,
                "max_tree_cpu_percent": max_tree_cpu_percent,
                "max_children": max_children,
            },
        }

        # Provide an explicit "lumo_evidence" entry to make the canonical
        # evidence artifact discoverable for verification/persistence layers.
        result_summary = {
            "passed": (not timed_out and exit_code == 0),
            "exit_code": exit_code,
            "timed_out": timed_out,
            "duration_seconds": duration,
        }

        # Provenance defaults intentionally use conservative 'unknown' values;
        # callers that have mission/objective/agent/capability/action in
        # request.metadata will have them preserved.
        provenance = {
            "mission": metadata.get("mission") or metadata.get("mission_id") or "unknown",
            "objective": metadata.get("objective") or metadata.get("objective_id") or "unknown",
            "agent": metadata.get("agent") or metadata.get("agent_id") or "unknown",
            "capability": metadata.get("capability") or "test_execution",
            "action": metadata.get("action") or "execute",
            "timestamp": metadata.get("timestamp") or timestamp,
            "execution_id": metadata.get("execution_id") or execution_id,
        }

        metadata["lumo_evidence"] = {
            "provenance": provenance,
            "result": result_summary,
            "stdout_head": (stdout or "")[:4096],
            "stderr_head": (stderr or "")[:4096],
        }

        result = TestExecutionResult(
            candidate_id=request.candidate_id,
            command=request.command,
            workspace_root=str(workspace),
            passed=(
                not timed_out
                and exit_code == 0
                and resource_abort is None
            ),
            exit_code=exit_code,
            timed_out=timed_out,
            stdout=stdout,
            stderr=stderr,
            duration_seconds=duration,
            metadata=metadata,
        )
        _TEST_EXECUTION_LOCK.release()
        return result

    def _run_via_runtime(self, request: CandidateTestExecutionRequest, workspace: Path) -> Optional[TestExecutionResult]:
        """Attempt to run the candidate tests using an ExecutionRuntime.

        This method is intentionally defensive: ExecutionRuntime implementations
        can vary; we try to translate the runtime result into a TestExecutionResult
        without making brittle assumptions. If mapping cannot be reasonably
        produced, return None so the caller can fall back to the local path.
        """
        runtime = self.execution_runtime

        # Lazy import types that may not be needed in default tests/runtimes.
        try:
            from runtime.types import ExecutionRequest
        except Exception as exc:
            raise RuntimeError(
                "governed candidate test execution requires runtime.types"
            ) from exc

        # Build an execution request for a governed 'test_execution' capability.
        # The exact capability name is a policy decision; choose a conservative
        # default that can be mapped to a runtime executor.
        execution_id = str(uuid.uuid4())

        exec_request = ExecutionRequest(
            task_id=f"candidate-tests:{request.candidate_id}",
            capability="test_execution",
            operation="run",
            agent_id="self-improvement",
            arguments={
                "workspace_root": str(workspace),
                "command": list(request.command),
                "timeout_seconds": request.timeout_seconds,
                "candidate_id": request.candidate_id,
                **(dict(request.metadata) if request.metadata else {}),
            },
            execution_id=execution_id,
        )

        # Call runtime.execute and translate only the canonical structured result.
        runtime_result = runtime.execute(exec_request)

        # The runtime result must expose a structured result contract. A
        # permissive mapping here could turn an unknown runtime response into
        # a false test result or accidentally bypass governance semantics.
        if not hasattr(runtime_result, "success"):
            raise RuntimeError(
                "governed candidate test execution returned an invalid result"
            )
        success = bool(runtime_result.success)
        result_payload = getattr(runtime_result, "result", None)
        if not isinstance(result_payload, dict):
            raise RuntimeError(
                "governed candidate test execution returned an unstructured result"
            )

        stdout = ""
        stderr = ""
        exit_code = None
        timed_out = False
        duration = 0.0

        if isinstance(result_payload, dict):
            # Commonly an executor will return stdout/stderr/exit_code/duration
            stdout = str(result_payload.get("stdout", ""))
            stderr = str(result_payload.get("stderr", ""))
            exit_code = result_payload.get("exit_code")
            timed_out = bool(result_payload.get("timed_out", False))
            duration = float(result_payload.get("duration_seconds", 0.0) or 0.0)
        # Build metadata similar to subprocess path so evidence consumers see
        # a consistent shape.
        base_metadata = dict(request.metadata) if request.metadata is not None else {}
        timestamp = base_metadata.get("timestamp") or datetime.now(timezone.utc).isoformat()

        metadata = {
            **base_metadata,
            "working_directory": str(workspace),
            "timeout_seconds": request.timeout_seconds,
            "executed_command": list(self._executable_command(request.command)),
            "execution_id": execution_id,
            "timestamp": timestamp,
            "executed_via_runtime": True,
        }

        if exit_code is None:
            raise RuntimeError(
                "governed candidate test execution result is missing exit_code"
            )

        metadata["lumo_evidence"] = {
            "provenance": {
                "mission": metadata.get("mission") or metadata.get("mission_id") or "unknown",
                "objective": metadata.get("objective") or metadata.get("objective_id") or "unknown",
                "agent": metadata.get("agent") or metadata.get("agent_id") or "unknown",
                "capability": metadata.get("capability") or "test_execution",
                "action": metadata.get("action") or "execute",
                "timestamp": metadata.get("timestamp") or timestamp,
                "execution_id": metadata.get("execution_id") or execution_id,
            },
            "result": {
                "passed": success,
                "exit_code": exit_code,
                "timed_out": timed_out,
                "duration_seconds": duration,
            },
            "stdout_head": (stdout or "")[:4096],
            "stderr_head": (stderr or "")[:4096],
        }

        return TestExecutionResult(
            candidate_id=request.candidate_id,
            command=request.command,
            workspace_root=str(workspace),
            passed=success and not timed_out and exit_code == 0,
            exit_code=exit_code,
            timed_out=timed_out,
            stdout=stdout,
            stderr=stderr,
            duration_seconds=duration,
            metadata=metadata,
        )

    @staticmethod
    def _executable_command(command: tuple[str, ...]) -> tuple[str, ...]:
        """Resolve the conventional ``python`` alias without altering evidence.

        A clean environment commonly exposes only ``python3`` or the virtual
        environment's absolute interpreter.  Candidate commands historically
        use ``python``; falling back to the interpreter running LUMO keeps
        those commands reproducible while retaining the original command in
        the durable result.
        """
        if command[0] == "python" and shutil.which("python") is None:
            return (sys.executable, *command[1:])
        return command

    @staticmethod
    def _decode_output(value: Any) -> str:
        if value is None:
            return ""

        if isinstance(value, bytes):
            return value.decode("utf-8", errors="replace")

        return str(value)
