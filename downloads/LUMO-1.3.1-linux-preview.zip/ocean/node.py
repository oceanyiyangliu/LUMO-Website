"""LUMO Root/Node authority and offline lease primitives.

Root owns authority; Nodes own execution. A Node is a LUMO runtime bound to a
device, while a Device describes hardware. This module deliberately keeps the
trust boundary small: durable identity, enrollment, leases, and revocation.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import platform
import secrets
import sqlite3
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from ocean.core.ids import new_id
from ocean.crypto import KeyRing


def _recovery_key(password: str, salt: bytes) -> bytes:
    if not isinstance(password, str) or len(password) < 12:
        raise ValueError("root recovery password must be at least 12 characters")
    return hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**15, r=8, p=1, dklen=32, maxmem=64 * 1024 * 1024)


def export_root_recovery(root: "RootAuthority", destination: str | Path, password: str) -> Path:
    """Create an encrypted, portable backup of Root signing authority."""
    destination = Path(destination).expanduser().resolve()
    payload = {"format": 1, "root_id": root.root_id, "key_ring": json.loads(root.key_ring.path.read_text(encoding="utf-8"))}
    salt = os.urandom(16)
    nonce = os.urandom(12)
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    aad = b"LUMO-ROOT-RECOVERY-v1"
    ciphertext = AESGCM(_recovery_key(password, salt)).encrypt(nonce, json.dumps(payload, sort_keys=True, separators=(",", ":")).encode(), aad)
    destination.parent.mkdir(parents=True, exist_ok=True)
    tmp = destination.with_suffix(destination.suffix + ".tmp")
    tmp.write_text(json.dumps({"format": 1, "salt": base64.b64encode(salt).decode(), "nonce": base64.b64encode(nonce).decode(), "ciphertext": base64.b64encode(ciphertext).decode()}, sort_keys=True), encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, destination)
    os.chmod(destination, 0o600)
    return destination


def restore_root_recovery(root: "RootAuthority", source: str | Path, password: str) -> str:
    """Restore Root signing authority from an encrypted recovery bundle."""
    source = Path(source).expanduser().resolve()
    envelope = json.loads(source.read_text(encoding="utf-8"))
    if envelope.get("format") != 1:
        raise ValueError("unsupported Root recovery format")
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    salt = base64.b64decode(envelope["salt"], validate=True)
    nonce = base64.b64decode(envelope["nonce"], validate=True)
    ciphertext = base64.b64decode(envelope["ciphertext"], validate=True)
    plaintext = AESGCM(_recovery_key(password, salt)).decrypt(nonce, ciphertext, b"LUMO-ROOT-RECOVERY-v1")
    payload = json.loads(plaintext)
    if payload.get("format") != 1 or not isinstance(payload.get("key_ring"), dict):
        raise ValueError("invalid Root recovery payload")
    ring = payload["key_ring"]
    if not ring.get("active") or not isinstance(ring.get("keys"), dict) or ring["active"] not in ring["keys"]:
        raise ValueError("invalid Root key ring")
    root.key_ring.path.parent.mkdir(parents=True, exist_ok=True)
    tmp = root.key_ring.path.with_suffix(root.key_ring.path.suffix + ".restore")
    tmp.write_text(json.dumps(ring, sort_keys=True), encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, root.key_ring.path)
    root.key_ring._load()
    if root.root_id != payload.get("root_id"):
        raise ValueError("Root recovery identity mismatch")
    return root.root_id


@dataclass(frozen=True)
class NodeProfile:
    id: str
    account_id: str
    device_id: str
    name: str
    status: str
    trust: str
    lease_expires_at: float
    capabilities: Mapping[str, Any]


@dataclass(frozen=True)
class NodeLease:
    node_id: str
    issued_at: float
    expires_at: float
    key_id: str
    signature: str


class RootAuthority:
    """Local LUMO Root authority backed by a durable HMAC key ring.

    The root key is local to the user's authoritative machine. Production
    hosted deployments can replace KeyRing with an HSM/KMS-backed signer
    without changing the Node contract.
    """

    def __init__(self, state_dir: str | Path):
        self.state_dir = Path(state_dir)
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.key_ring = KeyRing(self.state_dir / "root.keys")
        self._lock = threading.RLock()

    @property
    def root_id(self) -> str:
        return "root_" + hashlib.sha256(self.key_ring.active_key_id.encode()).hexdigest()[:24]

    def sign(self, payload: Mapping[str, Any]) -> tuple[str, str]:
        raw = json.dumps(dict(payload), sort_keys=True, separators=(",", ":")).encode()
        return self.key_ring.sign(raw)

    def verify(self, payload: Mapping[str, Any], key_id: str, signature: str) -> bool:
        raw = json.dumps(dict(payload), sort_keys=True, separators=(",", ":")).encode()
        return self.key_ring.verify(raw, key_id, signature)

    def issue_lease(self, node_id: str, *, ttl_seconds: float = 900.0) -> NodeLease:
        if not node_id.strip() or ttl_seconds <= 0 or ttl_seconds > 86400:
            raise ValueError("invalid node lease policy")
        now = time.time()
        payload = {"node_id": node_id, "issued_at": now, "expires_at": now + ttl_seconds}
        key_id, signature = self.sign(payload)
        return NodeLease(node_id, now, now + ttl_seconds, key_id, signature)

    def verify_lease(self, lease: NodeLease, *, now: float | None = None) -> bool:
        current = time.time() if now is None else float(now)
        if current >= lease.expires_at:
            return False
        return self.verify(
            {"node_id": lease.node_id, "issued_at": lease.issued_at, "expires_at": lease.expires_at},
            lease.key_id,
            lease.signature,
        )


class NodeRegistry:
    """Durable Root-owned Node registry.

    Enrollment is one-time and account-bound. A node cannot manufacture
    authority by changing its reported capabilities; those remain claims until
    the existing DeviceRegistry promotes them to measured capabilities.
    """

    def __init__(self, path: str | Path, root: RootAuthority):
        self.path = str(path)
        self.root = root
        self._lock = threading.RLock()
        with self._connect() as db:
            db.executescript(
                """
                CREATE TABLE IF NOT EXISTS nodes (
                    id TEXT PRIMARY KEY,
                    account_id TEXT NOT NULL,
                    device_id TEXT NOT NULL,
                    name TEXT NOT NULL,
                    status TEXT NOT NULL,
                    trust TEXT NOT NULL,
                    lease_expires_at REAL NOT NULL,
                    capabilities TEXT NOT NULL,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_nodes_account ON nodes(account_id);
                CREATE TABLE IF NOT EXISTS node_enrollment (
                    token_hash TEXT PRIMARY KEY,
                    account_id TEXT NOT NULL,
                    expires_at REAL NOT NULL,
                    used INTEGER NOT NULL DEFAULT 0
                );
                """
            )

    def _connect(self):
        db = sqlite3.connect(self.path, timeout=30)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("PRAGMA synchronous=NORMAL")
        db.execute("PRAGMA busy_timeout=30000")
        return db

    def issue_enrollment(self, account_id: str, *, ttl_seconds: int = 300) -> str:
        if not account_id.strip() or ttl_seconds <= 0 or ttl_seconds > 3600:
            raise ValueError("invalid enrollment policy")
        token = secrets.token_urlsafe(24)
        digest = hashlib.sha256(token.encode()).hexdigest()
        with self._lock, self._connect() as db:
            db.execute(
                "INSERT INTO node_enrollment(token_hash,account_id,expires_at,used) VALUES(?,?,?,0)",
                (digest, account_id, time.time() + ttl_seconds),
            )
        return token

    def enroll(
        self,
        account_id: str,
        token: str,
        *,
        name: str | None = None,
        device_id: str | None = None,
        capabilities: Mapping[str, Any] | None = None,
    ) -> NodeProfile:
        if not account_id.strip() or not token:
            raise ValueError("account_id and enrollment token are required")
        digest = hashlib.sha256(token.encode()).hexdigest()
        now = time.time()
        with self._lock, self._connect() as db:
            row = db.execute(
                "SELECT account_id,expires_at,used FROM node_enrollment WHERE token_hash=?",
                (digest,),
            ).fetchone()
            if row is None or row["account_id"] != account_id or row["used"] or now >= float(row["expires_at"]):
                raise PermissionError("invalid or expired node enrollment token")
            node_id = new_id("node")
            db.execute("UPDATE node_enrollment SET used=1 WHERE token_hash=?", (digest,))
            db.execute(
                """INSERT INTO nodes
                   (id,account_id,device_id,name,status,trust,lease_expires_at,capabilities,created_at,updated_at)
                   VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (
                    node_id,
                    account_id,
                    device_id or "",
                    name or platform.node(),
                    "online",
                    "trusted",
                    now,
                    json.dumps(dict(capabilities or {}), sort_keys=True),
                    now,
                    now,
                ),
            )
        return self.get(node_id)

    def get(self, node_id: str) -> NodeProfile:
        with self._lock, self._connect() as db:
            row = db.execute("SELECT * FROM nodes WHERE id=?", (node_id,)).fetchone()
        if row is None:
            raise KeyError(node_id)
        return self._row(row)

    def delete_account(self, account_id: str) -> None:
        with self._lock, self._connect() as db:
            db.execute("DELETE FROM nodes WHERE account_id=?", (account_id,))
            db.execute("DELETE FROM node_enrollment WHERE account_id=?", (account_id,))

    def list(self, account_id: str) -> list[NodeProfile]:
        with self._lock, self._connect() as db:
            rows = db.execute(
                "SELECT * FROM nodes WHERE account_id=? ORDER BY name,id", (account_id,)
            ).fetchall()
        return [self._row(row) for row in rows]

    def renew_lease(self, account_id: str, node_id: str, *, ttl_seconds: float = 900.0) -> NodeLease:
        node = self._owned(account_id, node_id)
        if node.status == "revoked" or node.trust != "trusted":
            raise PermissionError("revoked or untrusted node cannot renew its lease")
        lease = self.root.issue_lease(node.id, ttl_seconds=ttl_seconds)
        with self._lock, self._connect() as db:
            db.execute(
                "UPDATE nodes SET status='online',lease_expires_at=?,updated_at=? WHERE id=?",
                (lease.expires_at, time.time(), node_id),
            )
        return lease

    def can_execute(self, account_id: str, node_id: str, *, now: float | None = None) -> bool:
        node = self._owned(account_id, node_id)
        current = time.time() if now is None else float(now)
        return (
            node.status == "online"
            and node.trust == "trusted"
            and current < node.lease_expires_at
        )

    def revoke(self, account_id: str, node_id: str) -> None:
        self._owned(account_id, node_id)
        with self._lock, self._connect() as db:
            db.execute(
                "UPDATE nodes SET status='revoked',trust='revoked',lease_expires_at=0,updated_at=? WHERE id=?",
                (time.time(), node_id),
            )

    def mark_offline_expired(self, *, now: float | None = None) -> int:
        current = time.time() if now is None else float(now)
        with self._lock, self._connect() as db:
            result = db.execute(
                "UPDATE nodes SET status='offline',updated_at=? WHERE status='online' AND lease_expires_at<=?",
                (current, current),
            )
            return result.rowcount

    def update_capabilities(self, account_id: str, node_id: str, capabilities: Mapping[str, Any]) -> NodeProfile:
        self._owned(account_id, node_id)
        # Capability updates are claims. Scheduling must still consult the
        # DeviceRegistry's measured capability set.
        with self._lock, self._connect() as db:
            db.execute(
                "UPDATE nodes SET capabilities=?,updated_at=? WHERE id=?",
                (json.dumps(dict(capabilities), sort_keys=True), time.time(), node_id),
            )
        return self.get(node_id)

    def _owned(self, account_id: str, node_id: str) -> NodeProfile:
        node = self.get(node_id)
        if node.account_id != account_id:
            raise PermissionError("node belongs to another account")
        return node

    @staticmethod
    def _row(row: sqlite3.Row) -> NodeProfile:
        return NodeProfile(
            id=row["id"],
            account_id=row["account_id"],
            device_id=row["device_id"],
            name=row["name"],
            status=row["status"],
            trust=row["trust"],
            lease_expires_at=float(row["lease_expires_at"]),
            capabilities=json.loads(row["capabilities"]),
        )

    def close(self) -> None:
        return None
