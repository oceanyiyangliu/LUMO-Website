"""Local security primitives used by the LUMO control plane."""
from __future__ import annotations

import base64, hashlib, hmac, ipaddress, json, re, secrets, shlex, socket, time
from dataclasses import dataclass
from pathlib import Path
from threading import RLock
from typing import Iterable

_SECRET_KEYS = re.compile(r"(?i)(api[_-]?key|token|secret|password|authorization|cookie)\s*[:=]\s*[^\s,;]+")


def redact_secrets(value: object) -> str:
    text = str(value)
    return _SECRET_KEYS.sub(lambda m: m.group(1) + "=<redacted>", text)


def validate_path(path: str, roots: Iterable[str | Path]) -> Path:
    if not isinstance(path, str) or not path.strip(): raise ValueError("path is required")
    candidate=Path(path).expanduser().resolve(strict=False)
    allowed=[Path(r).expanduser().resolve(strict=False) for r in roots]
    if not any(candidate == root or root in candidate.parents for root in allowed):
        raise PermissionError("path is outside the permitted roots")
    return candidate


def validate_command(argv: list[str], *, max_args: int = 64, max_arg_bytes: int = 4096) -> tuple[str,...]:
    if not isinstance(argv,list) or not argv or len(argv)>max_args: raise ValueError("invalid command argv")
    if any(not isinstance(x,str) or not x or len(x.encode())>max_arg_bytes or "\x00" in x for x in argv): raise ValueError("invalid command argument")
    if any(x in argv[0] for x in (";","&&","||","|",">","<")): raise ValueError("shell syntax is not allowed")
    return tuple(argv)


def resolve_public_ip(host: str) -> set[str]:
    infos=socket.getaddrinfo(host,None,type=socket.SOCK_STREAM)
    addresses={i[4][0] for i in infos}
    if not addresses or any(not ipaddress.ip_address(a).is_global for a in addresses): raise PermissionError("host resolves to non-public address")
    return addresses

@dataclass(frozen=True)
class Session:
    session_id: str
    account_id: str
    issued_at: float
    expires_at: float
    generation: int

class SessionAuthority:
    """HMAC-signed, expiring local sessions with generation-based rotation."""
    def __init__(self, secret: bytes | None = None, ttl_seconds: int = 3600):
        if ttl_seconds <= 0: raise ValueError("ttl_seconds must be positive")
        self._secret=secret or secrets.token_bytes(32); self._ttl=ttl_seconds; self._generation=1; self._revoked=set(); self._revoked_accounts=set(); self._lock=RLock()
    def issue(self, account_id: str, now: float|None=None) -> str:
        if not account_id: raise ValueError("account_id is required")
        with self._lock:
            t=time.time() if now is None else now; sid=secrets.token_urlsafe(18); payload={"sid":sid,"account_id":account_id,"iat":t,"exp":t+self._ttl,"gen":self._generation}; raw=json.dumps(payload,separators=(",",":"),sort_keys=True).encode(); sig=hmac.new(self._secret,raw,hashlib.sha256).digest(); return base64.urlsafe_b64encode(raw+b"."+sig).decode()
    def verify(self, token: str, now: float|None=None) -> Session:
        try:
            blob=base64.urlsafe_b64decode(token.encode())
            if len(blob) < 33 or blob[-33:-32] != b".": raise ValueError("invalid session encoding")
            raw, sig = blob[:-33], blob[-32:]
            payload=json.loads(raw)
        except Exception as exc: raise PermissionError("invalid session") from exc
        expected=hmac.new(self._secret,raw,hashlib.sha256).digest()
        if not hmac.compare_digest(sig,expected): raise PermissionError("invalid session")
        t=time.time() if now is None else now
        with self._lock:
            if payload.get("sid") in self._revoked or payload.get("account_id") in self._revoked_accounts or payload.get("gen") != self._generation or t >= float(payload.get("exp",0)): raise PermissionError("session expired or revoked")
        return Session(str(payload["sid"]),str(payload["account_id"]),float(payload["iat"]),float(payload["exp"]),int(payload["gen"]))
    def revoke(self, token: str) -> None:
        try:
            blob = base64.urlsafe_b64decode(token.encode())
            if len(blob) < 33 or blob[-33:-32] != b".": raise ValueError("invalid session encoding")
            raw, sig = blob[:-33], blob[-32:]
            payload = json.loads(raw)
        except Exception as exc:
            raise PermissionError("invalid session") from exc
        expected = hmac.new(self._secret, raw, hashlib.sha256).digest()
        if not hmac.compare_digest(sig, expected):
            raise PermissionError("invalid session")
        with self._lock:
            if payload.get("gen") != self._generation:
                raise PermissionError("session expired or revoked")
            self._revoked.add(str(payload["sid"]))
    def revoke_account(self, account_id: str) -> None:
        if not account_id: raise ValueError("account_id is required")
        with self._lock: self._revoked_accounts.add(account_id)

    def rotate(self) -> None:
        with self._lock: self._generation += 1; self._secret=secrets.token_bytes(32); self._revoked.clear()

class BruteForceLimiter:
    def __init__(self, max_failures:int=5, window_seconds:float=300):
        if max_failures<=0 or window_seconds<=0: raise ValueError("invalid limiter policy")
        self.max_failures=max_failures; self.window=window_seconds; self._failures={}; self._lock=RLock()
    def allowed(self,key:str,now:float|None=None)->bool:
        t=time.monotonic() if now is None else now
        with self._lock:
            values=[x for x in self._failures.get(key,[]) if t-x<self.window]; self._failures[key]=values; return len(values)<self.max_failures
    def record_failure(self,key:str,now:float|None=None)->None:
        t=time.monotonic() if now is None else now
        with self._lock:
            self._failures.setdefault(key,[]).append(t)
    def clear(self,key:str)->None:
        with self._lock: self._failures.pop(key,None)


@dataclass(frozen=True)
class SecretInventoryItem:
    source: str
    name: str
    classification: str = "secret"


class SecretInventory:
    """Enumerate secret-bearing configuration locations without exposing values."""
    _name_pattern = re.compile(r"(?i)(api[_-]?key|token|secret|password|credential|authorization)")

    def environment(self, environ: dict[str, str] | None = None) -> tuple[SecretInventoryItem, ...]:
        values = environ if environ is not None else __import__("os").environ
        return tuple(SecretInventoryItem("environment", key) for key in sorted(values) if self._name_pattern.search(key))

    def paths(self, roots: Iterable[str | Path]) -> tuple[SecretInventoryItem, ...]:
        found=[]
        for root in roots:
            path=Path(root).expanduser()
            if path.is_file() and self._name_pattern.search(path.name):
                found.append(SecretInventoryItem("filesystem", str(path)))
            elif path.is_dir():
                for child in path.rglob("*"):
                    if child.is_file() and self._name_pattern.search(child.name):
                        found.append(SecretInventoryItem("filesystem", str(child)))
        return tuple(sorted(found,key=lambda item:item.name))


class KeychainTokenStore:
    """Use the native macOS Keychain for long-lived tokens; never fall back to plaintext."""
    def __init__(self, service: str = "LUMO"):
        if not service or any(c in service for c in "\x00\n\r"):
            raise ValueError("invalid keychain service")
        self.service=service

    def _check_platform(self):
        if __import__("platform").system() != "Darwin":
            raise RuntimeError("secure token storage is unavailable on this platform")

    def set(self, account: str, token: str) -> None:
        self._check_platform()
        if not account or not token or "\x00" in account or "\x00" in token:
            raise ValueError("account and token are required")
        __import__("subprocess").run(["/usr/bin/security","add-generic-password","-U","-a",account,"-s",self.service,"-w",token], check=True, stdout=__import__("subprocess").DEVNULL, stderr=__import__("subprocess").DEVNULL, timeout=5)

    def get(self, account: str) -> str | None:
        self._check_platform()
        if not account or "\x00" in account: raise ValueError("account is required")
        result=__import__("subprocess").run(["/usr/bin/security","find-generic-password","-a",account,"-s",self.service,"-w"], check=False, capture_output=True, text=True, timeout=5)
        return result.stdout.strip() if result.returncode == 0 else None

    def delete(self, account: str) -> bool:
        self._check_platform()
        result=__import__("subprocess").run(["/usr/bin/security","delete-generic-password","-a",account,"-s",self.service], check=False, stdout=__import__("subprocess").DEVNULL, stderr=__import__("subprocess").DEVNULL, timeout=5)
        return result.returncode == 0
