"""Virtual LUMO Cursor primitives.
A cursor is an execution pointer, not a second physical mouse.
It emits intent events for an app/world adapter to execute.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from time import time
from typing import Any, Iterable

class CursorActionType(str, Enum):
    CLICK = "click"
    SET_VALUE = "set_value"
    WAIT = "wait"

@dataclass(frozen=True)
class CursorAction:
    """Structured semantic action; never a physical mouse/keyboard command."""
    type: CursorActionType
    target: str | None = None
    value: str | None = None
    reason: str | None = None

    def validate(self) -> None:
        if self.type in {CursorActionType.CLICK, CursorActionType.SET_VALUE} and not self.target:
            raise ValueError("target is required")
        if self.type is CursorActionType.SET_VALUE and self.value is None:
            raise ValueError("value is required")

def validate_cursor_plan(actions: Iterable[CursorAction]) -> tuple[CursorAction, ...]:
    plan = tuple(actions)
    if not plan:
        raise ValueError("cursor plan must not be empty")
    if len(plan) > 16:
        raise ValueError("cursor plan exceeds bounded action limit")
    for action in plan:
        action.validate()
    return plan

class CursorEventType(str, Enum):
    MOVE = "cursor.move"
    HOVER = "cursor.hover"
    CLICK = "cursor.click"
    SET_VALUE = "cursor.set_value"
    WAIT = "cursor.wait"
    SUCCESS = "cursor.success"
    BLOCKED = "cursor.blocked"
    HIDE = "cursor.hide"

@dataclass(frozen=True)
class CursorEvent:
    cursor_id: str
    type: CursorEventType
    target: str | None = None
    payload: dict[str, Any] | None = None
    created_at: float = 0.0

    def __post_init__(self) -> None:
        if not self.cursor_id.strip():
            raise ValueError("cursor_id must not be empty")
        if self.created_at == 0.0:
            object.__setattr__(self, "created_at", time())

@dataclass(frozen=True)
class CursorContext:
    cursor_id: str
    surface: str
    application: str = ""
    world_id: str | None = None
    user_owned_surface: bool = False

class LumoCursor:
    """Stateful virtual cursor with no physical-device capabilities."""

    def __init__(self, context: CursorContext) -> None:
        if context.user_owned_surface and context.world_id:
            raise ValueError("user-owned cursor cannot be bound to a World")
        self.context = context
        self._events: list[CursorEvent] = []

    @property
    def events(self) -> tuple[CursorEvent, ...]:
        return tuple(self._events)

    def emit(self, event_type: CursorEventType, *, target: str | None = None,
             payload: dict[str, Any] | None = None) -> CursorEvent:
        event = CursorEvent(self.context.cursor_id, event_type, target, payload)
        self._events.append(event)
        return event

    def move(self, target: str) -> CursorEvent:
        return self.emit(CursorEventType.MOVE, target=target)

    def hover(self, target: str) -> CursorEvent:
        return self.emit(CursorEventType.HOVER, target=target)

    def click(self, target: str) -> CursorEvent:
        return self.emit(CursorEventType.CLICK, target=target)

    def set_value(self, target: str, value: str) -> CursorEvent:
        return self.emit(CursorEventType.SET_VALUE, target=target, payload={"value": value})

    def wait(self, reason: str) -> CursorEvent:
        return self.emit(CursorEventType.WAIT, payload={"reason": reason})

    def success(self) -> CursorEvent:
        return self.emit(CursorEventType.SUCCESS)

    def blocked(self, reason: str) -> CursorEvent:
        return self.emit(CursorEventType.BLOCKED, payload={"reason": reason})

    def hide(self) -> CursorEvent:
        return self.emit(CursorEventType.HIDE)

    def emit_action(self, action: CursorAction) -> CursorEvent:
        action.validate()
        if action.type is CursorActionType.CLICK:
            return self.click(action.target or "")
        if action.type is CursorActionType.SET_VALUE:
            return self.set_value(action.target or "", action.value or "")
        return self.wait(action.reason or "cursor action wait")

    def execute_plan(self, adapter: Any, actions: Iterable[CursorAction]) -> tuple[Any, ...]:
        results = []
        for action in validate_cursor_plan(actions):
            result = self.execute(adapter, self.emit_action(action))
            results.append(result)
            if hasattr(result, "executed") and not result.executed:
                self.blocked(getattr(result, "detail", "cursor action blocked"))
                break
        return tuple(results)

    def verify_plan(self, adapter: Any, actions: Iterable[CursorAction], results: Iterable[Any]) -> tuple[bool, str]:
        """Verification gate: Cursor may only report success from post-action evidence."""
        planned = validate_cursor_plan(actions)
        observed = tuple(results)
        if len(observed) != len(planned):
            return False, "verification incomplete"
        for result in observed:
            if not getattr(result, "executed", False):
                return False, getattr(result, "detail", "cursor action was not executed")
            event = getattr(result, "event", None)
            if event is not None and event.type in {CursorEventType.CLICK, CursorEventType.SET_VALUE}:
                verification = adapter.verify(event)
                if not verification.executed:
                    return False, verification.detail
        return True, "post-action evidence verified"

    def execute(self, adapter: Any, event: CursorEvent) -> Any:
        """Execute only through an explicit virtual-surface adapter."""
        return adapter.execute(self, event)

class LumoCursorSwarm:
    """Bounded collection of virtual cursors.

    A swarm only emits virtual cursor events. It cannot fall back to host
    mouse/keyboard control.
    """

    def __init__(self, *, max_cursors: int = 8) -> None:
        if max_cursors < 1:
            raise ValueError("max_cursors must be positive")
        self.max_cursors = max_cursors
        self._cursors: dict[str, LumoCursor] = {}

    def spawn(self, context: CursorContext) -> LumoCursor:
        if len(self._cursors) >= self.max_cursors:
            raise RuntimeError("cursor swarm capacity exhausted")
        if context.cursor_id in self._cursors:
            raise ValueError(f"cursor already exists: {context.cursor_id}")
        cursor = LumoCursor(context)
        self._cursors[context.cursor_id] = cursor
        return cursor

    def get(self, cursor_id: str) -> LumoCursor | None:
        return self._cursors.get(cursor_id)

    def release(self, cursor_id: str) -> LumoCursor | None:
        return self._cursors.pop(cursor_id, None)

    @property
    def active_count(self) -> int:
        return len(self._cursors)

    def events(self) -> tuple[CursorEvent, ...]:
        return tuple(event for cursor in self._cursors.values() for event in cursor.events)


__all__ = [
    "CursorAction",
    "CursorActionType",
    "CursorContext",
    "CursorEvent",
    "CursorEventType",
    "LumoCursor",
    "LumoCursorSwarm",
    "validate_cursor_plan",
]
