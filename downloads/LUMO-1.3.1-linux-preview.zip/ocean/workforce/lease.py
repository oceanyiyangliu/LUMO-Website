"""Durable assignment execution leases and liveness coordination."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
from threading import RLock
from typing import Callable, Iterable, Optional, Protocol

from ocean.core.clock import SYSTEM_CLOCK
from ocean.core.ids import new_id
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus


class AssignmentLeaseState(str, Enum):
    ACTIVE = "active"
    RELEASED = "released"
    EXPIRED = "expired"


class StaleAssignmentLeaseError(RuntimeError):
    """Raised when an old attempt tries to mutate lease state."""


class ExecutionCancellation(Protocol):
    def cancel(self) -> None:
        ...


class ReservationReleaser(Protocol):
    def __call__(self, reservation_id: str) -> object:
        ...


class AssignmentFailureHandler(Protocol):
    def __call__(self, assignment_id: str, reason: str) -> object:
        ...


@dataclass
class AssignmentLease:
    lease_id: str
    assignment_id: str
    agent_id: str
    attempt_id: str
    execution_id: Optional[str]
    acquired_at: datetime
    heartbeat_at: datetime
    expires_at: datetime
    state: AssignmentLeaseState = AssignmentLeaseState.ACTIVE
    reason: Optional[str] = None
    reservation_id: Optional[str] = None
    resource_reservation_id: Optional[str] = None

    @property
    def terminal(self) -> bool:
        return self.state is not AssignmentLeaseState.ACTIVE


class AssignmentLeaseCoordinator:
    """Event-sourced ownership and liveness boundary for assignments.

    Lease adoption is explicit. Existing execution paths do not require a
    lease until their caller supplies one, while assignment terminal events
    automatically release an adopted active lease.
    """

    _LEASE_EVENTS = {
        "AssignmentLeaseAcquired",
        "AssignmentLeaseHeartbeat",
        "AssignmentLeaseExpired",
        "AssignmentLeaseReleased",
        "AssignmentReassigned",
    }

    def __init__(
        self,
        *,
        event_bus: EventBus,
        reservation_releaser: ReservationReleaser | None = None,
        resource_reservation_releaser: ReservationReleaser | None = None,
        assignment_failure_handler: AssignmentFailureHandler | None = None,
    ) -> None:
        if event_bus is None:
            raise ValueError("event_bus is required")

        self._event_bus = event_bus
        self._reservation_releaser = reservation_releaser
        self._resource_reservation_releaser = resource_reservation_releaser
        self._assignment_failure_handler = assignment_failure_handler
        self._lock = RLock()
        self._leases: dict[str, AssignmentLease] = {}
        self._reassignments: dict[str, str] = {}
        self._cancellers: dict[str, ExecutionCancellation] = {}
        self._terminal_events: dict[str, Event] = {}
        self._replaying = False

        for event_type in self._LEASE_EVENTS:
            event_bus.subscribe(event_type, self._handle_event)
        event_bus.subscribe("TaskAssignmentCompleted", self._handle_assignment_terminal)
        event_bus.subscribe("TaskAssignmentFailed", self._handle_assignment_terminal)
        event_bus.subscribe("TaskAssignmentCancelled", self._handle_assignment_terminal)
        self.rebuild()

    def acquire(
        self,
        *,
        assignment_id: str,
        agent_id: str,
        attempt_id: str,
        lease_seconds: float,
        execution_id: str | None = None,
        execution_handle: ExecutionCancellation | None = None,
        reservation_id: str | None = None,
        resource_reservation_id: str | None = None,
        lease_id: str | None = None,
        at: datetime | None = None,
    ) -> AssignmentLease:
        if not assignment_id or not agent_id or not attempt_id:
            raise ValueError("assignment, agent, and attempt identities are required")
        if lease_seconds <= 0:
            raise ValueError("lease_seconds must be positive")

        acquired_at = at or SYSTEM_CLOCK.now()
        lease = AssignmentLease(
            lease_id=lease_id or new_id("assignment_lease"),
            assignment_id=assignment_id,
            agent_id=agent_id,
            attempt_id=attempt_id,
            execution_id=execution_id,
            acquired_at=acquired_at,
            heartbeat_at=acquired_at,
            expires_at=acquired_at + timedelta(seconds=lease_seconds),
            reservation_id=reservation_id,
            resource_reservation_id=resource_reservation_id,
        )

        with self._lock:
            existing = self._leases.get(lease.lease_id)
            if existing is not None:
                self._require_identity(existing, lease.attempt_id, lease.agent_id)
                return existing
            self._event_bus.publish(self._event("AssignmentLeaseAcquired", lease))

            if execution_handle is not None:
                self._cancellers[lease.lease_id] = execution_handle

            terminal_event = self._terminal_events.pop(assignment_id, None)
            if terminal_event is not None:
                self._release_reservation(lease)

            return self._leases[lease.lease_id]

    def heartbeat(
        self,
        lease_id: str,
        *,
        attempt_id: str,
        agent_id: str,
        expires_at: datetime | None = None,
        at: datetime | None = None,
    ) -> AssignmentLease:
        with self._lock:
            lease = self._require_active(lease_id, attempt_id, agent_id)
            heartbeat_at = at or SYSTEM_CLOCK.now()
            if heartbeat_at < lease.heartbeat_at:
                raise ValueError("heartbeat cannot move backward")
            if heartbeat_at == lease.heartbeat_at and expires_at in (None, lease.expires_at):
                return lease
            next_expiry = expires_at or lease.expires_at
            if next_expiry <= heartbeat_at:
                raise ValueError("expires_at must be after heartbeat_at")
            self._event_bus.publish(
                self._event(
                    "AssignmentLeaseHeartbeat",
                    lease,
                    heartbeat_at=heartbeat_at,
                    expires_at=next_expiry,
                )
            )
            return self._leases[lease_id]

    def bind_execution_handle(
        self,
        lease_id: str,
        *,
        attempt_id: str,
        agent_id: str,
        execution_handle: ExecutionCancellation,
    ) -> AssignmentLease:
        with self._lock:
            lease = self._require_active(lease_id, attempt_id, agent_id)
            self._cancellers[lease.lease_id] = execution_handle
            return lease

    def set_assignment_failure_handler(
        self,
        handler: AssignmentFailureHandler | None,
    ) -> None:
        with self._lock:
            self._assignment_failure_handler = handler

    def set_reservation_releasers(
        self,
        *,
        workforce: ReservationReleaser | None = None,
        resource: ReservationReleaser | None = None,
    ) -> None:
        with self._lock:
            self._reservation_releaser = workforce
            self._resource_reservation_releaser = resource

    def release(
        self,
        lease_id: str,
        *,
        attempt_id: str,
        agent_id: str,
        reason: str = "execution completed",
        at: datetime | None = None,
    ) -> AssignmentLease:
        with self._lock:
            lease = self._leases.get(lease_id)
            if lease is None:
                raise KeyError(lease_id)
            self._require_identity(lease, attempt_id, agent_id)
            if lease.state is not AssignmentLeaseState.ACTIVE:
                return lease
            self._event_bus.publish(
                self._event(
                    "AssignmentLeaseReleased",
                    lease,
                    released_at=at or SYSTEM_CLOCK.now(),
                    reason=reason,
                )
            )
            return self._leases[lease_id]

    def expire(
        self,
        lease_id: str,
        *,
        attempt_id: str,
        agent_id: str,
        at: datetime | None = None,
        reason: str = "lease heartbeat expired",
    ) -> AssignmentLease:
        with self._lock:
            lease = self._leases.get(lease_id)
            if lease is None:
                raise KeyError(lease_id)
            self._require_identity(lease, attempt_id, agent_id)
            if lease.state is not AssignmentLeaseState.ACTIVE:
                return lease
            expired_at = at or SYSTEM_CLOCK.now()
            if expired_at < lease.expires_at:
                raise ValueError("lease has not expired")
            self._event_bus.publish(
                self._event(
                    "AssignmentLeaseExpired",
                    lease,
                    expired_at=expired_at,
                    reason=reason,
                )
            )
            return self._leases[lease_id]

    def expire_due(self, *, at: datetime | None = None) -> tuple[AssignmentLease, ...]:
        now = at or SYSTEM_CLOCK.now()
        with self._lock:
            due = sorted(
                (
                    lease
                    for lease in self._leases.values()
                    if lease.state is AssignmentLeaseState.ACTIVE
                    and lease.expires_at <= now
                ),
                key=lambda lease: lease.lease_id,
            )
        return tuple(
            self.expire(
                lease.lease_id,
                attempt_id=lease.attempt_id,
                agent_id=lease.agent_id,
                at=now,
            )
            for lease in due
        )

    def record_reassignment(
        self,
        *,
        source_lease_id: str,
        replacement_assignment_id: str,
        replacement_agent_id: str,
        replacement_attempt_id: str,
        reason: str = "assignment reassigned",
    ) -> None:
        with self._lock:
            source = self._leases.get(source_lease_id)
            if source is None:
                raise KeyError(source_lease_id)
            existing = self._reassignments.get(source_lease_id)
            replacement_key = f"{replacement_assignment_id}:{replacement_attempt_id}"
            if existing is not None:
                if existing != replacement_key:
                    raise StaleAssignmentLeaseError(
                        "lease was already reassigned to another attempt"
                    )
                return
            self._event_bus.publish(
                self._event(
                    "AssignmentReassigned",
                    source,
                    replacement_assignment_id=replacement_assignment_id,
                    replacement_agent_id=replacement_agent_id,
                    replacement_attempt_id=replacement_attempt_id,
                    reason=reason,
                )
            )

    def get(self, lease_id: str) -> AssignmentLease | None:
        with self._lock:
            return self._leases.get(lease_id)

    def active_for_assignment(self, assignment_id: str) -> AssignmentLease | None:
        with self._lock:
            return next(
                (
                    lease
                    for lease in self._leases.values()
                    if lease.assignment_id == assignment_id
                    and lease.state is AssignmentLeaseState.ACTIVE
                ),
                None,
            )

    def can_complete(self, lease_id: str, *, attempt_id: str, agent_id: str) -> bool:
        with self._lock:
            lease = self._leases.get(lease_id)
            if lease is None:
                return False
            if lease.attempt_id != attempt_id or lease.agent_id != agent_id:
                return False
            return lease.state is AssignmentLeaseState.ACTIVE

    def rebuild(self, events: Iterable[Event] | None = None) -> None:
        history = self._event_bus.history() if events is None else events
        with self._lock:
            self._leases.clear()
            self._reassignments.clear()
            self._cancellers.clear()
            self._terminal_events.clear()
            self._replaying = True
            try:
                for event in history:
                    if event.type in self._LEASE_EVENTS:
                        self._apply(event)
            finally:
                self._replaying = False

    def _handle_event(self, event: Event) -> None:
        with self._lock:
            self._apply(event)

    def _handle_assignment_terminal(self, event: Event) -> None:
        assignment_id = event.payload.get("assignment_id")
        execution_id = event.payload.get("execution_id")
        if not assignment_id:
            return
        with self._lock:
            lease = self.active_for_assignment(str(assignment_id))
            if lease is None:
                if not self._replaying:
                    self._terminal_events[str(assignment_id)] = event
                return
            if lease.execution_id is not None and lease.execution_id != execution_id:
                return
            self.release(
                lease.lease_id,
                attempt_id=lease.attempt_id,
                agent_id=lease.agent_id,
                reason=(
                    "assignment execution completed"
                    if event.type == "TaskAssignmentCompleted"
                    else "assignment execution failed"
                ),
            )

    def _apply(self, event: Event) -> None:
        payload = event.payload
        if event.type == "AssignmentLeaseAcquired":
            lease_id = str(payload["lease_id"])
            if lease_id in self._leases:
                return
            self._leases[lease_id] = AssignmentLease(
                lease_id=lease_id,
                assignment_id=str(payload["assignment_id"]),
                agent_id=str(payload["agent_id"]),
                attempt_id=str(payload["attempt_id"]),
                execution_id=payload.get("execution_id"),
                acquired_at=datetime.fromisoformat(payload["acquired_at"]),
                heartbeat_at=datetime.fromisoformat(payload["heartbeat_at"]),
                expires_at=datetime.fromisoformat(payload["expires_at"]),
                reservation_id=payload.get("reservation_id"),
                resource_reservation_id=payload.get("resource_reservation_id"),
            )
            return

        if event.type == "AssignmentLeaseHeartbeat":
            lease = self._leases.get(str(payload["lease_id"]))
            if lease is None or lease.state is not AssignmentLeaseState.ACTIVE:
                return
            lease.heartbeat_at = datetime.fromisoformat(payload["heartbeat_at"])
            lease.expires_at = datetime.fromisoformat(payload["expires_at"])
            return

        if event.type in {"AssignmentLeaseReleased", "AssignmentLeaseExpired"}:
            lease = self._leases.get(str(payload["lease_id"]))
            if lease is None or lease.state is not AssignmentLeaseState.ACTIVE:
                return
            lease.state = (
                AssignmentLeaseState.RELEASED
                if event.type == "AssignmentLeaseReleased"
                else AssignmentLeaseState.EXPIRED
            )
            lease.reason = str(payload.get("reason") or "") or None
            if event.type == "AssignmentLeaseExpired" and not self._replaying:
                cancellation = self._cancellers.get(lease.lease_id)
                if cancellation is not None:
                    cancellation.cancel()
                if self._assignment_failure_handler is not None:
                    self._assignment_failure_handler(
                        lease.assignment_id,
                        lease.reason or "assignment lease expired",
                    )
            self._release_reservation(lease)
            return

        if event.type == "AssignmentReassigned":
            source_lease_id = str(payload["source_lease_id"])
            replacement_key = (
                f"{payload['replacement_assignment_id']}:{payload['replacement_attempt_id']}"
            )
            self._reassignments.setdefault(source_lease_id, replacement_key)

    def _release_reservation(self, lease: AssignmentLease) -> None:
        if self._replaying or self._reservation_releaser is None:
            return
        if lease.reservation_id is not None:
            self._reservation_releaser(lease.reservation_id)
        if (
            lease.resource_reservation_id is not None
            and self._resource_reservation_releaser is not None
        ):
            self._resource_reservation_releaser(lease.resource_reservation_id)

    def _require_active(
        self,
        lease_id: str,
        attempt_id: str,
        agent_id: str,
    ) -> AssignmentLease:
        lease = self._leases.get(lease_id)
        if lease is None:
            raise KeyError(lease_id)
        self._require_identity(lease, attempt_id, agent_id)
        if lease.state is not AssignmentLeaseState.ACTIVE:
            raise StaleAssignmentLeaseError(
                f"lease {lease_id!r} is {lease.state.value!r}"
            )
        return lease

    @staticmethod
    def _require_identity(
        lease: AssignmentLease,
        attempt_id: str,
        agent_id: str,
    ) -> None:
        if lease.attempt_id != attempt_id or lease.agent_id != agent_id:
            raise StaleAssignmentLeaseError(
                f"lease {lease.lease_id!r} does not belong to this attempt"
            )

    @staticmethod
    def _event(event_type: str, lease: AssignmentLease, **extra) -> Event:
        payload = {
            "lease_id": lease.lease_id,
            "assignment_id": lease.assignment_id,
            "agent_id": lease.agent_id,
            "attempt_id": lease.attempt_id,
            "execution_id": lease.execution_id,
            "acquired_at": lease.acquired_at.isoformat(),
            "heartbeat_at": lease.heartbeat_at.isoformat(),
            "expires_at": lease.expires_at.isoformat(),
            "reservation_id": lease.reservation_id,
            "resource_reservation_id": lease.resource_reservation_id,
            **extra,
        }
        for key, value in tuple(payload.items()):
            if isinstance(value, datetime):
                payload[key] = value.isoformat()
        if event_type == "AssignmentReassigned":
            payload["source_lease_id"] = lease.lease_id
        return Event(
            type=event_type,
            payload=payload,
            aggregate_type="assignment_lease",
            aggregate_id=lease.lease_id,
            correlation_id=lease.assignment_id,
            source="workforce_lease",
        )