"""Background lease-expiry sweeper for long-running unattended operation.

The sweeper periodically scans active leases and expires those past their
deadline.  It integrates with :class:`AssignmentLeaseCoordinator` to cancel
stale execution handles and trigger recovery.

Usage::

    sweeper = LeaseExpirySweeper(lease_coordinator=leases, interval_seconds=10)
    sweeper.start()
    # ... later ...
    sweeper.stop()
"""

from __future__ import annotations

import logging
import threading
from typing import Optional

from ocean.workforce.lease import AssignmentLeaseCoordinator

logger = logging.getLogger(__name__)


class LeaseExpirySweeper:
    """Periodically expire overdue leases.

    The sweeper runs a daemon thread that wakes every ``interval_seconds``
    and calls :meth:`AssignmentLeaseCoordinator.expire_due`.  Expired leases
    trigger execution cancellation and assignment failure handling through
    the coordinator's normal event-sourced path.

    The sweeper is safe to instantiate from any thread.  Call
    :meth:`start` to begin background scanning and :meth:`stop` to shut
    down gracefully.
    """

    def __init__(
        self,
        *,
        lease_coordinator: AssignmentLeaseCoordinator,
        interval_seconds: float = 10.0,
        name: str = "ocean-lease-sweeper",
    ) -> None:
        if lease_coordinator is None:
            raise ValueError("lease_coordinator is required")
        if interval_seconds <= 0:
            raise ValueError("interval_seconds must be positive")

        self._lease_coordinator = lease_coordinator
        self._interval = max(0.5, interval_seconds)
        self._name = name
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

    @property
    def interval_seconds(self) -> float:
        return self._interval

    @property
    def is_running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self) -> None:
        """Start the background sweeper thread.

        If the sweeper is already running this is a no-op.
        """
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return

            self._stop_event.clear()
            self._thread = threading.Thread(
                target=self._run_loop,
                name=self._name,
                daemon=True,
            )
            self._thread.start()
            logger.info(
                "lease expiry sweeper started (interval=%.1fs)", self._interval
            )

    def stop(self, timeout: float = 5.0) -> None:
        """Signal the sweeper to stop and wait for the thread to exit."""
        self._stop_event.set()
        with self._lock:
            if self._thread is not None:
                self._thread.join(timeout=timeout)
                self._thread = None
        logger.info("lease expiry sweeper stopped")

    def sweep_once(self) -> int:
        """Perform a single sweep of overdue leases.

        Returns the number of leases expired during this sweep.
        """
        expired = self._lease_coordinator.expire_due()
        if expired:
            logger.info(
                "sweeper expired %d overdue lease(s): %s",
                len(expired),
                [lease.lease_id for lease in expired],
            )
        return len(expired)

    def _run_loop(self) -> None:
        logger.debug("lease sweeper loop running")
        while not self._stop_event.is_set():
            try:
                self.sweep_once()
            except Exception:
                logger.exception("lease sweeper encountered an error")
            self._stop_event.wait(timeout=self._interval)
        logger.debug("lease sweeper loop exiting")
