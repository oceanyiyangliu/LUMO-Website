"""Dynamic agent provisioning."""

from __future__ import annotations

from ocean.domain.agent import Agent
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from runtime.agent_runtime import AgentRuntime

from .lineage import AgentLineageStore
from .policy import WorkforcePolicy
from .types import AgentLineage, AgentSpawnRequest


class WorkforceProvisioner:
    """Provision agents through the canonical AgentController boundary."""

    def __init__(
        self,
        *,
        runtime: AgentRuntime,
        event_bus: EventBus,
        lineage: AgentLineageStore,
        policy: WorkforcePolicy,
    ) -> None:
        if runtime is None:
            raise ValueError("runtime is required")
        if event_bus is None:
            raise ValueError("event_bus is required")
        if lineage is None:
            raise ValueError("lineage is required")
        if policy is None:
            raise ValueError("policy is required")

        self._runtime = runtime
        self._event_bus = event_bus
        self._lineage = lineage
        self._policy = policy

    def provision(self, request: AgentSpawnRequest) -> Agent:
        parent = (
            self._runtime.get(request.parent_agent_id)
            if request.parent_agent_id
            else None
        )

        if request.parent_agent_id and parent is None:
            raise ValueError(
                f"unknown parent agent: {request.parent_agent_id!r}"
            )

        population = len(self._runtime.agents())
        children_count = (
            len(self._lineage.children(parent.id))
            if parent is not None
            else 0
        )

        if not self._policy.allow_spawn(
            population=population,
            request=request,
            parent=parent,
            children_count=children_count,
        ):
            raise PermissionError("workforce spawn denied by policy")

        generation = (
            0
            if parent is None
            else self._lineage.generation(parent.id) + 1
        )

        metadata = dict(request.metadata)
        metadata.setdefault("persistent", request.persistent)
        metadata.setdefault("generation", generation)
        if request.parent_agent_id is not None:
            metadata.setdefault(
                "parent_agent_id",
                request.parent_agent_id,
            )

        metadata.setdefault(
            "max_concurrent_assignments",
            self._policy.config.default_capacity,
        )

        # Canonical domain creation. AgentController owns Agent identity and
        # AgentCreated emission; Workforce must never manufacture Agent IDs.
        agent = self._runtime.controller.create(
            request.name,
            request.role,
            capabilities=set(request.capabilities),
            metadata=metadata,
        )

        # Runtime owns the live registry.
        self._runtime.register(agent)

        lineage = AgentLineage(
            agent_id=agent.id,
            parent_agent_id=request.parent_agent_id,
            generation=generation,
            persistent=request.persistent,
            provenance={
                "source": "workforce",
                "role": request.role,
            },
        )

        self._lineage.register(lineage)

        self._publish(
            "AgentSpawned",
            agent,
            {
                "agent_id": agent.id,
                "parent_agent_id": request.parent_agent_id,
                "generation": generation,
                "persistent": request.persistent,
                "role": request.role,
                "capabilities": sorted(agent.capabilities),
            },
        )

        self._publish(
            "AgentLineageEstablished",
            agent,
            {
                "agent_id": agent.id,
                "parent_agent_id": request.parent_agent_id,
                "generation": generation,
                "persistent": request.persistent,
                "provenance": {
                    "source": "workforce",
                    "role": request.role,
                },
            },
        )

        return agent

    def retire(self, agent_id: str) -> Agent:
        agent = self._runtime.get(agent_id)
        if agent is None:
            raise KeyError(agent_id)

        if not self._policy.should_retire(agent):
            raise PermissionError(
                f"retirement not permitted for agent {agent_id!r}"
            )

        retired = self._runtime.terminate(agent_id)

        self._event_bus.publish(
            Event(
                type="AgentRetired",
                aggregate_type="agent",
                aggregate_id=retired.id,
                source="workforce",
                payload={
                    "agent_id": retired.id,
                    "reason": "policy",
                },
            )
        )
        return retired

    def _publish(
        self,
        event_type: str,
        agent: Agent,
        payload: dict,
    ) -> None:
        self._event_bus.publish(
            Event(
                type=event_type,
                aggregate_type="agent",
                aggregate_id=agent.id,
                source="workforce",
                payload=payload,
            )
        )
