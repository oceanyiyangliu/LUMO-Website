"""Event-backed agent reservation and release."""

from __future__ import annotations

from threading import RLock

from ocean.core.ids import new_id
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus

from runtime.agent_runtime import AgentRuntime

from .policy import WorkforcePolicy
from .types import AgentCapacity, WorkforceReservation


class WorkforceAllocatorImpl:
    """Reservation projection backed by durable workforce events."""

    def __init__(
        self,
        *,
        runtime: AgentRuntime,
        event_bus: EventBus,
        policy: WorkforcePolicy,
    ) -> None:
        if runtime is None:
            raise ValueError("runtime is required")
        if event_bus is None:
            raise ValueError("event_bus is required")
        if policy is None:
            raise ValueError("policy is required")

        self._runtime = runtime
        self._event_bus = event_bus
        self._policy = policy
        self._lock = RLock()
        self._reservations: dict[str, WorkforceReservation] = {}
        self._load: dict[str, int] = {}

        event_bus.subscribe("AgentReserved", self._on_reserved)
        event_bus.subscribe("AgentReservationBound", self._on_bound)
        event_bus.subscribe("AgentReleased", self._on_released)

    def reserve(
        self,
        *,
        agent_id: str,
        task_id: str,
    ) -> WorkforceReservation:
        if not agent_id:
            raise ValueError("agent_id is required")
        if not task_id:
            raise ValueError("task_id is required")

        with self._lock:
            agent = self._runtime.get(agent_id)
            if agent is None:
                raise ValueError(f"unknown agent: {agent_id!r}")

            if agent.status.value not in {"idle", "background"}:
                raise RuntimeError(
                    f"agent {agent_id!r} is not available"
                )

            capacity = AgentCapacity(
                max_concurrent_assignments=self._policy.capacity_for(agent),
                current_assignments=self._load.get(agent_id, 0),
            )
            if not capacity.available:
                raise RuntimeError(
                    f"agent {agent_id!r} has no available capacity"
                )

            reservation = WorkforceReservation(
                reservation_id=new_id("reservation"),
                agent_id=agent_id,
                task_id=task_id,
            )

            self._publish(
                "AgentReserved",
                reservation,
                {
                    "reservation_id": reservation.reservation_id,
                    "agent_id": reservation.agent_id,
                    "task_id": reservation.task_id,
                },
            )
            return reservation

    def bind_assignment(
        self,
        reservation_id: str,
        assignment_id: str,
    ) -> WorkforceReservation:
        if not reservation_id:
            raise ValueError("reservation_id is required")
        if not assignment_id:
            raise ValueError("assignment_id is required")

        with self._lock:
            reservation = self._reservations.get(reservation_id)
            if reservation is None:
                raise KeyError(reservation_id)

            if reservation.assignment_id is not None:
                if reservation.assignment_id != assignment_id:
                    raise ValueError(
                        "reservation already bound to another assignment"
                    )
                return reservation

            self._publish(
                "AgentReservationBound",
                reservation,
                {
                    "reservation_id": reservation.reservation_id,
                    "agent_id": reservation.agent_id,
                    "task_id": reservation.task_id,
                    "assignment_id": assignment_id,
                },
            )

            return WorkforceReservation(
                reservation_id=reservation.reservation_id,
                agent_id=reservation.agent_id,
                task_id=reservation.task_id,
                assignment_id=assignment_id,
            )

    def release(self, reservation_id: str) -> WorkforceReservation:
        with self._lock:
            reservation = self._reservations.get(reservation_id)
            if reservation is None:
                raise KeyError(reservation_id)

            self._publish(
                "AgentReleased",
                reservation,
                {
                    "reservation_id": reservation.reservation_id,
                    "agent_id": reservation.agent_id,
                    "task_id": reservation.task_id,
                    "assignment_id": reservation.assignment_id,
                },
            )
            return reservation

    def get(self, reservation_id: str) -> WorkforceReservation | None:
        with self._lock:
            return self._reservations.get(reservation_id)

    def load(self, agent_id: str) -> int:
        with self._lock:
            return self._load.get(agent_id, 0)

    def rebuild(self) -> None:
        with self._lock:
            self._reservations.clear()
            self._load.clear()
            for event in self._event_bus.history():
                self._apply(event)

    def _on_reserved(self, event: Event) -> None:
        with self._lock:
            self._apply(event)

    def _on_bound(self, event: Event) -> None:
        with self._lock:
            self._apply(event)

    def _on_released(self, event: Event) -> None:
        with self._lock:
            self._apply(event)

    def _apply(self, event: Event) -> None:
        if event.type == "AgentReserved":
            payload = event.payload
            reservation_id = str(payload["reservation_id"])
            if reservation_id in self._reservations:
                return

            reservation = WorkforceReservation(
                reservation_id=reservation_id,
                agent_id=str(payload["agent_id"]),
                task_id=str(payload["task_id"]),
            )
            self._reservations[reservation_id] = reservation
            self._load[reservation.agent_id] = (
                self._load.get(reservation.agent_id, 0) + 1
            )
            return

        if event.type == "AgentReservationBound":
            payload = event.payload
            reservation_id = str(payload["reservation_id"])
            reservation = self._reservations.get(reservation_id)
            if reservation is None:
                raise RuntimeError(
                    f"cannot bind unknown reservation {reservation_id!r}"
                )

            assignment_id = str(payload["assignment_id"])
            if reservation.assignment_id is not None:
                if reservation.assignment_id != assignment_id:
                    raise RuntimeError(
                        f"reservation {reservation_id!r} bound twice"
                    )
                return

            self._reservations[reservation_id] = WorkforceReservation(
                reservation_id=reservation.reservation_id,
                agent_id=reservation.agent_id,
                task_id=reservation.task_id,
                assignment_id=assignment_id,
            )
            return

        if event.type == "AgentReleased":
            payload = event.payload
            reservation_id = str(payload["reservation_id"])
            reservation = self._reservations.pop(reservation_id, None)
            if reservation is None:
                return

            current = self._load.get(reservation.agent_id, 0)
            next_load = max(0, current - 1)
            if next_load:
                self._load[reservation.agent_id] = next_load
            else:
                self._load.pop(reservation.agent_id, None)

    def _publish(
        self,
        event_type: str,
        reservation: WorkforceReservation,
        payload: dict,
    ) -> None:
        self._event_bus.publish(
            Event(
                type=event_type,
                aggregate_type="agent",
                aggregate_id=reservation.agent_id,
                source="workforce",
                payload=payload,
            )
        )
