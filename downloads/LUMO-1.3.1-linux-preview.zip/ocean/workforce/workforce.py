"""Top-level workforce control plane."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from ocean.domain.agent import Agent
from ocean.domain.enums import OrchestrationMode
from ocean.domain.event_bus import EventBus
from runtime.agent_runtime import AgentRuntime

from .allocator import WorkforceAllocatorImpl
from .lineage import AgentLineageStore
from .policy import WorkforcePolicy
from .provisioning import WorkforceProvisioner
from .selection import WorkforceAgentSelector
from .types import (
    AgentSelection,
    AgentSpawnRequest,
    AgentLineage,
    AgentSelectionRequest,
    WorkforcePolicyConfig,
    WorkforceReservation,
)


@dataclass(frozen=True)
class WorkforceSnapshot:
    population: int
    available: int
    running: int
    waiting: int
    background: int
    failed: int
    terminated: int
    reserved: int


class Workforce:
    """Unified API for the dynamic agent workforce."""

    def __init__(
        self,
        *,
        runtime: AgentRuntime,
        event_bus: EventBus,
        policy: WorkforcePolicy | None = None,
        lineage: AgentLineageStore | None = None,
    ) -> None:
        if runtime is None:
            raise ValueError("runtime is required")
        if event_bus is None:
            raise ValueError("event_bus is required")

        self.runtime = runtime
        self.event_bus = event_bus
        self.policy = policy or WorkforcePolicy()
        self.lineage = lineage or AgentLineageStore()

        self.provisioner = WorkforceProvisioner(
            runtime=runtime,
            event_bus=event_bus,
            lineage=self.lineage,
            policy=self.policy,
        )
        self.allocator = WorkforceAllocatorImpl(
            runtime=runtime,
            event_bus=event_bus,
            policy=self.policy,
        )
        self.selector = WorkforceAgentSelector(
            runtime=runtime,
            allocator=self.allocator,
            policy=self.policy,
        )

        self._rebuild_projections()

    def spawn(
        self,
        *,
        name: str,
        role: str,
        capabilities: tuple[str, ...] = (),
        parent_agent_id: Optional[str] = None,
        persistent: bool = True,
        metadata: Optional[dict] = None,
    ) -> Agent:
        return self.provisioner.provision(
            AgentSpawnRequest(
                name=name,
                role=role,
                capabilities=capabilities,
                parent_agent_id=parent_agent_id,
                persistent=persistent,
                metadata=dict(metadata or {}),
            )
        )

    def retire(self, agent_id: str) -> Agent:
        return self.provisioner.retire(agent_id)

    def select(
        self,
        *,
        capability: str,
        preferred_agent_id: Optional[str] = None,
        mode: OrchestrationMode = OrchestrationMode.STANDARD,
        metadata: Optional[dict] = None,
    ) -> AgentSelection:
        return self.selector.select(
            AgentSelectionRequest(
                capability=capability,
                preferred_agent_id=preferred_agent_id,
                mode=mode,
                metadata=dict(metadata or {}),
            )
        )

    def reserve(
        self,
        *,
        agent_id: str,
        task_id: str,
    ) -> WorkforceReservation:
        return self.allocator.reserve(
            agent_id=agent_id,
            task_id=task_id,
        )

    def bind_reservation(
        self,
        reservation_id: str,
        assignment_id: str,
    ) -> WorkforceReservation:
        return self.allocator.bind_assignment(
            reservation_id,
            assignment_id,
        )

    def release(self, reservation_id: str) -> WorkforceReservation:
        return self.allocator.release(reservation_id)

    def rebuild(self) -> None:
        self._rebuild_projections()

    def snapshot(self, runtime: AgentRuntime | None = None) -> WorkforceSnapshot:
        counts = {
            "idle": 0,
            "running": 0,
            "waiting": 0,
            "background": 0,
            "failed": 0,
            "terminated": 0,
        }

        agents = list(self.runtime.agents())
        for agent in agents:
            counts[agent.status.value] = (
                counts.get(agent.status.value, 0) + 1
            )

        return WorkforceSnapshot(
            population=len(agents),
            available=counts["idle"] + counts["background"],
            running=counts["running"],
            waiting=counts["waiting"],
            background=counts["background"],
            failed=counts["failed"],
            terminated=counts["terminated"],
            reserved=sum(
                self.allocator.load(agent.id)
                for agent in agents
            ),
        )

    def _rebuild_projections(self) -> None:
        self.lineage.rebuild(self.event_bus.history())
        self.allocator.rebuild()
