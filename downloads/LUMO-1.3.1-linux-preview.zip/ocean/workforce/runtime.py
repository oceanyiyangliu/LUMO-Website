"""Unified, explicit workforce dispatch and lifecycle coordination."""

from __future__ import annotations

from dataclasses import dataclass
from threading import RLock
from typing import Optional

from ocean.core.ids import new_id
from ocean.domain.agent import Agent
from ocean.domain.assignment import Assignment
from ocean.domain.enums import AgentStatus, AssignmentStatus, OrchestrationMode
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.orchestration.orchestrator import Orchestrator
from ocean.orchestration.types import AssignmentRequest, ExecutionIntent, OrchestrationResult
from ocean.resources.capacity import ResourceCapacityPlane
from runtime.agent_runtime import AgentRuntime
from runtime.types import ExecutionRequest

from .lease import AssignmentLease, AssignmentLeaseCoordinator
from .workforce import Workforce


@dataclass(frozen=True)
class WorkforceDispatch:
    mission_id: str
    objective_id: str
    assignment_id: str
    agent_id: str
    attempt_id: str
    execution_id: str
    lease: AssignmentLease


class WorkforceRuntime:
    """Thin composition boundary for agent assignment and execution liveness.

    It owns no scheduling, governance, execution, or recovery policy. Those
    remain in Scheduler, ExecutionRuntime, AssignmentLeaseCoordinator, and
    RecoveryEngine respectively.
    """

    def __init__(
        self,
        *,
        workforce: Workforce,
        agent_runtime: AgentRuntime,
        orchestrator: Orchestrator,
        leases: AssignmentLeaseCoordinator,
        events: EventBus,
        resources: ResourceCapacityPlane | None = None,
        assignment_failure_handler=None,
    ) -> None:
        self.workforce = workforce
        self.agent_runtime = agent_runtime
        self.orchestrator = orchestrator
        self.leases = leases
        self.events = events
        self.resources = resources
        self._dispatches: dict[str, WorkforceDispatch] = {}
        # Selection, reservation, and lifecycle assignment form one atomic
        # admission phase. Execution itself remains fully concurrent.
        self._admission_lock = RLock()
        self.leases.set_assignment_failure_handler(assignment_failure_handler)
        self.leases.set_reservation_releasers(
            workforce=self.workforce.release,
            resource=self.resources.release if self.resources is not None else None,
        )

        events.subscribe("ScheduledExecutionDispatched", self._on_dispatched)
        events.subscribe("TaskAssignmentCompleted", self._on_terminal)
        events.subscribe("TaskAssignmentFailed", self._on_terminal)
        self.rebuild()

    def dispatch(
        self,
        *,
        mission_id: str,
        objective_id: str,
        task_id: str,
        intent: ExecutionIntent,
        priority: int = 0,
        mode: OrchestrationMode = OrchestrationMode.STANDARD,
        preferred_agent_id: Optional[str] = None,
        lease_seconds: float = 60.0,
        dependencies: set[str] | None = None,
    ) -> WorkforceDispatch:
        attempt_id = new_id("attempt")
        resource_reservation_id = None
        assigned_assignment_id = None
        execution_id = new_id("exec")

        # Admission is intentionally short: once an agent is marked ASSIGNED,
        # execution proceeds outside this lock and remains fully concurrent.
        with self._admission_lock:
            selection = self.workforce.select(
                capability=intent.capability,
                preferred_agent_id=preferred_agent_id,
                mode=mode,
            )
            agent = self.agent_runtime.get(selection.agent_id)
            if agent is None:
                raise KeyError(selection.agent_id)

            workforce_reservation = self.workforce.reserve(
                agent_id=agent.id,
                task_id=task_id,
            )
            try:
                if agent.status is AgentStatus.IDLE:
                    self.agent_runtime.controller.assign(agent, task_id=task_id)

                assigned = self.orchestrator.assign(
                    AssignmentRequest(
                        task_id=task_id,
                        agent_id=agent.id,
                        mission_id=mission_id,
                        mode=mode,
                        priority=priority,
                        metadata={
                            "objective_id": objective_id,
                            "attempt_id": attempt_id,
                        },
                        execution_id=execution_id,
                    )
                )
                if not assigned.success or assigned.assignment_id is None:
                    raise RuntimeError(assigned.error or "assignment failed")
                assigned_assignment_id = assigned.assignment_id
            except Exception:
                if self.workforce.allocator.get(workforce_reservation.reservation_id) is not None:
                    self.workforce.release(workforce_reservation.reservation_id)
                if agent.status is AgentStatus.ASSIGNED:
                    self.agent_runtime.mark_idle(agent.id)
                raise

        try:
            if self.resources is not None:
                admission = self.resources.try_reserve(
                    ExecutionRequest(
                        task_id=task_id,
                        capability=intent.capability,
                        operation=intent.operation,
                        mission_id=mission_id,
                        agent_id=agent.id,
                        execution_id=execution_id,
                        arguments=dict(intent.arguments),
                        resource_limits=intent.resource_limits,
                    )
                )
                if not admission.admitted or admission.reservation is None:
                    raise RuntimeError(admission.reason or "resource admission rejected")
                resource_reservation_id = admission.reservation.reservation_id

            dispatched = self.orchestrator.dispatch(
                assigned.assignment_id,
                intent,
                dependency_execution_ids=set(dependencies or ()),
            )
            if not dispatched.success or dispatched.execution_id is None:
                raise RuntimeError(dispatched.error or "dispatch failed")

            if dispatched.execution_id != execution_id:
                execution_id = dispatched.execution_id

            self.workforce.bind_reservation(
                workforce_reservation.reservation_id,
                assigned.assignment_id,
            )
            lease = self.leases.acquire(
                assignment_id=assigned.assignment_id,
                agent_id=agent.id,
                attempt_id=attempt_id,
                execution_id=execution_id,
                lease_seconds=lease_seconds,
                reservation_id=workforce_reservation.reservation_id,
                resource_reservation_id=resource_reservation_id,
            )
            result = WorkforceDispatch(
                mission_id=mission_id,
                objective_id=objective_id,
                assignment_id=assigned.assignment_id,
                agent_id=agent.id,
                attempt_id=attempt_id,
                execution_id=execution_id,
                lease=lease,
            )
            self._dispatches[assigned.assignment_id] = result
            scheduled = self.agent_runtime.scheduler.get(execution_id)
            current_lease = self.leases.get(lease.lease_id)
            if (
                scheduled is not None
                and scheduled.handle is not None
                and current_lease is not None
                and not current_lease.terminal
            ):
                self.leases.bind_execution_handle(
                    lease.lease_id,
                    attempt_id=attempt_id,
                    agent_id=agent.id,
                    execution_handle=scheduled.handle,
                )
            return result
        except Exception:
            if (
                resource_reservation_id is not None
                and self.resources is not None
                and self.resources.reservation(resource_reservation_id) is not None
            ):
                self.resources.release(resource_reservation_id)
            if self.workforce.allocator.get(workforce_reservation.reservation_id) is not None:
                self.workforce.release(workforce_reservation.reservation_id)
            if agent.status is AgentStatus.ASSIGNED:
                self.agent_runtime.mark_idle(agent.id)
            if assigned_assignment_id is not None:
                assignment = self.orchestrator.ports.assignments.get(
                    assigned_assignment_id
                )
                if assignment is not None and assignment.status is AssignmentStatus.QUEUED:
                    assignment.cancel(reason="workforce dispatch admission failed")
                    self.orchestrator.ports.assignments.save(assignment)
                    self.events.publish(
                        Event(
                            type="TaskAssignmentCancelled",
                            payload={
                                "assignment_id": assignment.id,
                                "task_id": assignment.task_id,
                                "agent_id": assignment.agent_id,
                                "mission_id": assignment.mission_id,
                                "reason": assignment.reason,
                            },
                            aggregate_type="assignment",
                            aggregate_id=assignment.id,
                            correlation_id=assignment.mission_id,
                            source="workforce_runtime",
                        )
                    )
            raise

    def heartbeat(self, dispatch: WorkforceDispatch, *, lease_seconds: float | None = None) -> AssignmentLease:
        lease = dispatch.lease
        from datetime import timedelta
        from ocean.core.clock import SYSTEM_CLOCK

        return self.leases.heartbeat(
            lease.lease_id,
            attempt_id=dispatch.attempt_id,
            agent_id=dispatch.agent_id,
            expires_at=(
                SYSTEM_CLOCK.now() + timedelta(seconds=lease_seconds)
                if lease_seconds is not None
                else None
            ),
        )

    def adopt_assignment(
        self,
        *,
        mission_id: str,
        objective_id: str,
        assignment_id: str,
        attempt_id: str,
        intent: ExecutionIntent,
        lease_seconds: float = 60.0,
    ) -> WorkforceDispatch:
        """Attach workforce ownership to an assignment created by recovery."""
        assignment = self.orchestrator.ports.assignments.get(assignment_id)
        if assignment is None:
            raise KeyError(assignment_id)
        agent = self.agent_runtime.get(assignment.agent_id)
        if agent is None:
            raise KeyError(assignment.agent_id)

        reservation = self.workforce.reserve(
            agent_id=agent.id,
            task_id=assignment.task_id,
        )
        resource_reservation_id = None
        try:
            self.workforce.bind_reservation(reservation.reservation_id, assignment_id)
            if self.resources is not None:
                admission = self.resources.try_reserve(
                    ExecutionRequest(
                        task_id=assignment.task_id,
                        capability=intent.capability,
                        operation=intent.operation,
                        mission_id=mission_id,
                        agent_id=agent.id,
                        execution_id=assignment.execution_id,
                        arguments=dict(intent.arguments),
                        resource_limits=intent.resource_limits,
                    )
                )
                if not admission.admitted or admission.reservation is None:
                    raise RuntimeError(admission.reason or "resource admission rejected")
                resource_reservation_id = admission.reservation.reservation_id
            lease = self.leases.acquire(
                assignment_id=assignment_id,
                agent_id=agent.id,
                attempt_id=attempt_id,
                execution_id=assignment.execution_id,
                lease_seconds=lease_seconds,
                reservation_id=reservation.reservation_id,
                resource_reservation_id=resource_reservation_id,
            )
            return WorkforceDispatch(
                mission_id=mission_id,
                objective_id=objective_id,
                assignment_id=assignment_id,
                agent_id=agent.id,
                attempt_id=attempt_id,
                execution_id=assignment.execution_id or "",
                lease=lease,
            )
        except Exception:
            if (
                resource_reservation_id is not None
                and self.resources is not None
                and self.resources.reservation(resource_reservation_id) is not None
            ):
                self.resources.release(resource_reservation_id)
            if self.workforce.allocator.get(reservation.reservation_id) is not None:
                self.workforce.release(reservation.reservation_id)
            raise

    def reconcile(self, dispatch: WorkforceDispatch, result) -> object:
        if not self.leases.can_complete(
            dispatch.lease.lease_id,
            attempt_id=dispatch.attempt_id,
            agent_id=dispatch.agent_id,
        ):
            return OrchestrationResult(
                success=False,
                assignment_id=dispatch.assignment_id,
                execution_id=dispatch.execution_id,
                error="stale workforce attempt",
            )
        return self.orchestrator.reconcile(dispatch.assignment_id, result)

    def rebuild(self) -> None:
        self.leases.rebuild(self.events.history())
        for event in self.events.history("AgentStateChanged"):
            agent = self.agent_runtime.get(str(event.payload.get("agent_id")))
            if agent is None:
                continue
            agent.status = AgentStatus(str(event.payload["status"]))
            agent.current_task_id = event.payload.get("current_task_id")
        for event in self.events.history("ScheduledExecutionDispatched"):
            self._on_dispatched(event)

    def _on_dispatched(self, event: Event) -> None:
        agent_id = event.payload.get("agent_id")
        task_id = event.payload.get("task_id")
        if not agent_id:
            return
        agent = self.agent_runtime.get(str(agent_id))
        if agent is None:
            return
        if agent.status is AgentStatus.ASSIGNED:
            self.agent_runtime.controller.activate(agent, task_id=task_id)

    def _on_terminal(self, event: Event) -> None:
        agent_id = event.payload.get("agent_id")
        if not agent_id:
            return
        agent = self.agent_runtime.get(str(agent_id))
        if agent is None:
            return
        if agent.status in {AgentStatus.RUNNING, AgentStatus.ASSIGNED}:
            self.agent_runtime.mark_idle(agent.id)