"""Event-derived agent lineage projection."""

from __future__ import annotations

from typing import Dict, Iterable, Optional

from .types import AgentLineage


class AgentLineageStore:
    """Rebuildable operational projection of workforce lineage.

    The event stream is authoritative. This object is deliberately only an
    index/read model and can be reconstructed from AgentLineageEstablished
    events.
    """

    def __init__(self) -> None:
        self._lineages: Dict[str, AgentLineage] = {}

    def register(self, lineage: AgentLineage) -> None:
        existing = self._lineages.get(lineage.agent_id)
        if existing is not None and existing != lineage:
            raise ValueError(
                f"lineage already exists for agent {lineage.agent_id!r}"
            )
        self._lineages[lineage.agent_id] = lineage

    def get(self, agent_id: str) -> Optional[AgentLineage]:
        return self._lineages.get(agent_id)

    def children(self, parent_agent_id: str) -> list[AgentLineage]:
        return [
            lineage
            for lineage in self._lineages.values()
            if lineage.parent_agent_id == parent_agent_id
        ]

    def generation(self, agent_id: str) -> int:
        lineage = self.get(agent_id)
        return 0 if lineage is None else lineage.generation

    def list(self) -> list[AgentLineage]:
        return list(self._lineages.values())

    def clear(self) -> None:
        self._lineages.clear()

    def rebuild(self, events: Iterable) -> None:
        self.clear()
        for event in events:
            if event.type != "AgentLineageEstablished":
                continue
            payload = event.payload
            lineage = AgentLineage(
                agent_id=str(payload["agent_id"]),
                parent_agent_id=payload.get("parent_agent_id"),
                generation=int(payload.get("generation", 0)),
                persistent=bool(payload.get("persistent", True)),
                provenance=dict(payload.get("provenance", {})),
            )
            self.register(lineage)
