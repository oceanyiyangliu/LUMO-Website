"""Capability-aware agent selection."""

from __future__ import annotations

from runtime.agent_runtime import AgentRuntime

from .allocator import WorkforceAllocatorImpl
from .policy import WorkforcePolicy
from .types import AgentSelection, AgentSelectionRequest


class WorkforceAgentSelector:
    """Select the strongest currently available agent for a requirement."""

    def __init__(
        self,
        *,
        runtime: AgentRuntime,
        allocator: WorkforceAllocatorImpl,
        policy: WorkforcePolicy,
    ) -> None:
        self._runtime = runtime
        self._allocator = allocator
        self._policy = policy

    def select(self, request: AgentSelectionRequest) -> AgentSelection:
        candidates = [
            agent
            for agent in self._runtime.agents()
            if agent.status.value in {"idle", "background"}
            and agent.can_perform(request.capability)
            and self._allocator.load(agent.id)
            < self._policy.capacity_for(agent)
        ]

        if request.preferred_agent_id:
            preferred = next(
                (
                    agent
                    for agent in candidates
                    if agent.id == request.preferred_agent_id
                ),
                None,
            )
            if preferred is not None:
                return AgentSelection(
                    agent_id=preferred.id,
                    reason="preferred available capable agent",
                    score=100.0,
                )

        if not candidates:
            raise LookupError(
                f"no available agent supports capability "
                f"{request.capability!r}"
            )

        def score(agent) -> tuple:
            load = self._allocator.load(agent.id)
            generation = int(agent.metadata.get("generation", 0))
            return (
                load,
                -len(agent.capabilities),
                generation,
                agent.id,
            )

        selected = min(candidates, key=score)

        return AgentSelection(
            agent_id=selected.id,
            reason="lowest-load capable agent",
            score=float(
                len(selected.capabilities)
                - self._allocator.load(selected.id)
            ),
        )
