"""Workforce population and provisioning policy."""

from __future__ import annotations

from typing import Iterable, Optional

from ocean.domain.agent import Agent

from .types import AgentSpawnRequest, WorkforcePolicyConfig


class WorkforcePolicy:
    """Authoritative policy gate for workforce mutations."""

    def __init__(self, config: WorkforcePolicyConfig | None = None) -> None:
        self.config = config or WorkforcePolicyConfig()

    def allow_spawn(
        self,
        *,
        population: int,
        request: AgentSpawnRequest,
        parent: Optional[Agent],
        children_count: int,
    ) -> bool:
        if not self.config.allow_spawn:
            return False

        if (
            not request.persistent
            and not self.config.allow_ephemeral
        ):
            return False

        if (
            self.config.max_population is not None
            and population >= self.config.max_population
        ):
            return False

        if (
            parent is not None
            and self.config.max_children_per_agent is not None
            and children_count >= self.config.max_children_per_agent
        ):
            return False

        return True

    def should_retire(self, agent: Agent) -> bool:
        return (
            agent.status.value == "failed"
            and self.config.retire_failed_agents
        )

    def capacity_for(self, agent: Agent) -> int:
        raw = agent.metadata.get(
            "max_concurrent_assignments",
            self.config.default_capacity,
        )
        try:
            value = int(raw)
        except (TypeError, ValueError):
            value = self.config.default_capacity
        return max(1, value)
