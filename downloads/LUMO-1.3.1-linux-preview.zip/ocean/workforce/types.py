"""Core workforce-plane value objects and contracts."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Protocol, Sequence

from ocean.domain.enums import OrchestrationMode


@dataclass(frozen=True)
class AgentLineage:
    """Durable provenance for an agent."""

    agent_id: str
    parent_agent_id: Optional[str] = None
    generation: int = 0
    persistent: bool = True
    provenance: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.agent_id:
            raise ValueError("agent_id is required")
        if self.generation < 0:
            raise ValueError("generation must be non-negative")


@dataclass(frozen=True)
class AgentCapacity:
    """Operational capacity metadata used by workforce allocation."""

    max_concurrent_assignments: int = 1
    current_assignments: int = 0

    def __post_init__(self) -> None:
        if self.max_concurrent_assignments < 1:
            raise ValueError("max_concurrent_assignments must be >= 1")
        if self.current_assignments < 0:
            raise ValueError("current_assignments must be non-negative")

    @property
    def available(self) -> bool:
        return self.current_assignments < self.max_concurrent_assignments


@dataclass(frozen=True)
class WorkforcePolicyConfig:
    """Population and provisioning policy."""

    max_population: Optional[int] = None
    max_children_per_agent: Optional[int] = None
    allow_spawn: bool = True
    allow_ephemeral: bool = True
    retire_failed_agents: bool = False
    default_capacity: int = 1

    def __post_init__(self) -> None:
        if self.max_population is not None and self.max_population < 1:
            raise ValueError("max_population must be >= 1")
        if (
            self.max_children_per_agent is not None
            and self.max_children_per_agent < 0
        ):
            raise ValueError("max_children_per_agent must be non-negative")
        if self.default_capacity < 1:
            raise ValueError("default_capacity must be >= 1")


@dataclass(frozen=True)
class AgentSpawnRequest:
    """Request to provision a new agent."""

    name: str
    role: str
    capabilities: Sequence[str] = ()
    parent_agent_id: Optional[str] = None
    persistent: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("name is required")
        if not self.role:
            raise ValueError("role is required")
        if self.parent_agent_id == "":
            raise ValueError("parent_agent_id cannot be empty")


@dataclass(frozen=True)
class AgentSelectionRequest:
    """Describe workforce requirements for selecting an agent."""

    capability: str
    preferred_agent_id: Optional[str] = None
    mode: OrchestrationMode = OrchestrationMode.STANDARD
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.capability:
            raise ValueError("capability is required")


@dataclass(frozen=True)
class AgentSelection:
    """Result of workforce agent selection."""

    agent_id: str
    reason: str
    score: float = 0.0


@dataclass(frozen=True)
class WorkforceReservation:
    """Durable allocation reservation."""

    reservation_id: str
    agent_id: str
    task_id: str
    assignment_id: Optional[str] = None


class AgentSelector(Protocol):
    def select(self, request: AgentSelectionRequest) -> AgentSelection:
        ...


class AgentProvisioner(Protocol):
    def provision(self, request: AgentSpawnRequest):
        ...


class WorkforceAllocator(Protocol):
    def reserve(self, *, agent_id: str, task_id: str) -> WorkforceReservation:
        ...

    def release(self, reservation_id: str) -> WorkforceReservation:
        ...
