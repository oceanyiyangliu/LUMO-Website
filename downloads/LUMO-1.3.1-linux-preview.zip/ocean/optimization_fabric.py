"""Integrated cost/latency optimization fabric.

This module is deliberately deterministic.  It can recommend cheaper/faster
execution paths, reserve hierarchical budgets, reuse safe observations, and
measure outcomes, but it can never grant authority or weaken verification.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from hashlib import sha256
from threading import RLock
from time import monotonic
from typing import Any, Callable, Mapping, Sequence
import math
import statistics

from .optimization import BudgetGuard, CostLedger, PerformanceLedger, SafeResultCache, SingleFlight, stable_key


@dataclass(frozen=True)
class PriceBand:
    provider: str
    model: str
    input_per_1k: float = 0.0
    output_per_1k: float = 0.0
    cached_input_per_1k: float | None = None
    batch_multiplier: float = 1.0
    effective_from: str = ""
    version: str = "1"
    def __post_init__(self):
        vals=(self.input_per_1k,self.output_per_1k,self.batch_multiplier)
        if any(not math.isfinite(float(v)) or v < 0 for v in vals) or (self.cached_input_per_1k is not None and self.cached_input_per_1k < 0):
            raise ValueError("invalid price band")
        if self.batch_multiplier <= 0: raise ValueError("batch multiplier must be positive")

class PriceBook:
    """Versioned pricing table; historical bands remain queryable."""
    def __init__(self): self._rows=[]; self._lock=RLock()
    def add(self, band: PriceBand) -> None:
        with self._lock: self._rows.append(band)
    def history(self) -> tuple[PriceBand,...]:
        with self._lock: return tuple(self._rows)
    def latest(self, provider: str, model: str) -> PriceBand | None:
        with self._lock:
            rows=[x for x in self._rows if x.provider==provider and x.model==model]
        return rows[-1] if rows else None
    def estimate(self, provider: str, model: str, input_tokens: int, output_tokens: int, *, cached_input_tokens: int=0, batched: bool=False) -> float:
        if min(input_tokens,output_tokens,cached_input_tokens) < 0: raise ValueError("token counts must be non-negative")
        band=self.latest(provider,model)
        if band is None: raise KeyError((provider,model))
        cached=min(input_tokens,cached_input_tokens)
        normal=input_tokens-cached
        total=normal*band.input_per_1k/1000 + cached*(band.cached_input_per_1k if band.cached_input_per_1k is not None else band.input_per_1k)/1000 + output_tokens*band.output_per_1k/1000
        return total*(band.batch_multiplier if batched else 1.0)

@dataclass(frozen=True)
class ExecutionOption:
    """A pre-authorized execution alternative scored before spending resources."""
    name: str
    cost: float = 0.0
    latency_ms: float = 0.0
    reliability: float = 1.0
    deterministic: bool = False
    cached: bool = False

    def __post_init__(self):
        if self.cost < 0 or self.latency_ms < 0 or not 0 <= self.reliability <= 1:
            raise ValueError("invalid execution option")


@dataclass(frozen=True)
class BudgetChoice:
    option: ExecutionOption
    score: float
    reason: str


@dataclass(frozen=True)
class SpendDecision:
    """A cheap, auditable value-of-information gate for the next spend."""
    continue_execution: bool
    expected_value: float
    marginal_cost: float
    expected_net_value: float
    reason: str


class BudgetController:
    """Cheap-first admission and routing with hard budget and safety neutrality.

    The controller never trades away authorization, isolation or verification.
    It minimizes expected spend by preferring cache/deterministic/free paths,
    then chooses the cheapest option that still satisfies the latency/reliability
    constraints. Scoring is deterministic and therefore cheap to execute.
    """
    def choose(self, options: Sequence[ExecutionOption], *, remaining_cost: float,
               deadline_ms: float | None = None, min_reliability: float = 0.99,
               prefer_free: bool = True) -> BudgetChoice:
        if remaining_cost < 0 or (deadline_ms is not None and deadline_ms < 0):
            raise ValueError("invalid budget constraints")
        if not 0 <= min_reliability <= 1:
            raise ValueError("min_reliability must be 0..1")
        eligible = [o for o in options if o.cost <= remaining_cost and o.reliability >= min_reliability
                    and (deadline_ms is None or o.latency_ms <= deadline_ms)]
        if not eligible:
            raise RuntimeError("no execution option fits budget, deadline and reliability constraints")
        def score(o: ExecutionOption) -> tuple[float, float, float, float]:
            # Lexicographic ordering keeps routing deterministic and avoids
            # expensive optimization machinery for a simple admission choice.
            free_rank = 0.0 if prefer_free and (o.cost == 0 or o.cached or o.deterministic) else 1.0
            return (free_rank, o.cost, o.latency_ms, -o.reliability)
        chosen = min(eligible, key=score)
        return BudgetChoice(chosen, float(chosen.cost),
                            "free/cache/deterministic first, then cost, latency, reliability")

    def should_continue(self, *, expected_value: float, marginal_cost: float,
                        success_probability: float = 1.0, remaining_cost: float | None = None,
                        min_roi: float = 1.0) -> "SpendDecision":
        """Stop low-value work before spending it; never overrides hard safety gates.

        Expected value is deliberately supplied by the mission/objective layer rather
        than guessed here. The controller only applies arithmetic, hard affordability,
        and a configurable ROI threshold, making the decision deterministic and cheap.
        """
        values=(expected_value,marginal_cost,success_probability,min_roi)
        if any(not math.isfinite(float(v)) for v in values) or expected_value < 0 or marginal_cost < 0:
            raise ValueError("value and cost inputs must be finite and non-negative")
        if not 0 <= success_probability <= 1 or min_roi < 0:
            raise ValueError("success_probability must be 0..1 and min_roi non-negative")
        if remaining_cost is not None and (not math.isfinite(float(remaining_cost)) or remaining_cost < 0):
            raise ValueError("remaining_cost must be finite and non-negative")
        value = float(expected_value) * float(success_probability)
        cost = float(marginal_cost)
        net = value - cost
        affordable = remaining_cost is None or cost <= float(remaining_cost)
        roi_ok = cost == 0.0 or (value / cost) >= float(min_roi)
        cont = affordable and roi_ok and net >= 0.0
        if not affordable:
            reason = "stop: marginal spend exceeds remaining budget"
        elif not roi_ok:
            reason = "stop: expected value does not meet minimum ROI"
        elif net < 0:
            reason = "stop: expected net value is negative"
        else:
            reason = "continue: expected value justifies marginal spend"
        return SpendDecision(cont,value,cost,net,reason)


@dataclass(frozen=True)
class BudgetForecast:
    remaining: Mapping[str,float]
    projected: Mapping[str,float]
    overrun: Mapping[str,float]
    burn_rate_per_minute: Mapping[str,float]
    safe: bool

class BudgetHierarchy:
    """Account -> mission -> branch reservations with atomic local admission."""
    def __init__(self, limits: Mapping[str,Mapping[str,float]]):
        self._guards={scope:BudgetGuard(values) for scope,values in limits.items()}
        self._lock=RLock()
    def reserve(self, scope_chain: Sequence[str], costs: Mapping[str,float], reservation_id: str):
        if not scope_chain: raise ValueError("scope chain required")
        with self._lock:
            reserved=[]
            try:
                for scope in scope_chain:
                    guard=self._guards.get(scope)
                    if guard is not None:
                        guard.reserve(scope,costs,f"{reservation_id}:{scope}"); reserved.append((guard,f"{reservation_id}:{scope}"))
                return tuple(reserved)
            except Exception:
                for guard,rid in reversed(reserved): guard.release(rid)
                raise
    def commit(self, reservations, actual: Mapping[str,float]):
        """Commit a hierarchy atomically: validate every scope before mutating any."""
        reservations = tuple(reservations)
        actual = {str(k): float(v) for k, v in actual.items()}
        for guard, rid in reservations:
            with guard._lock:
                reservation = guard._reservations.get(rid)
                if reservation is None:
                    raise KeyError(rid)
                for kind, amount in actual.items():
                    if not math.isfinite(amount) or amount < 0:
                        raise ValueError("actual costs must be finite and non-negative")
                    limit = guard._limits.get(kind)
                    if limit is not None and guard._consumed.get(kind, 0.0) + amount > limit + 1e-12:
                        raise RuntimeError(f"budget exceeded for {kind}")
                    reserved = float(reservation.costs.get(kind, 0.0))
                    other_reserved = max(0.0, guard._reserved.get(kind, 0.0) - reserved)
                    if limit is not None and amount - reserved > max(0.0, limit - guard._consumed.get(kind, 0.0) - other_reserved - reserved) + 1e-12:
                        raise RuntimeError(f"postflight budget variance exceeded for {kind}")
        for guard, rid in reservations:
            guard.commit(rid, actual)

    def release(self, reservations):
        for guard,rid in reversed(tuple(reservations)): guard.release(rid)
    def snapshots(self): return {k:v.snapshot() for k,v in self._guards.items()}
    def forecast(self, scope: str, elapsed_minutes: float, horizon_minutes: float=60.0) -> BudgetForecast:
        if elapsed_minutes <= 0 or horizon_minutes < 0: raise ValueError("invalid forecast horizon")
        snap=self._guards[scope].snapshot(); remaining={k:float(v)-float(snap['consumed'].get(k,0))-float(snap['reserved'].get(k,0)) for k,v in snap['limits'].items()}
        rates={k:float(snap['consumed'].get(k,0))/elapsed_minutes for k in snap['limits']}
        projected={k:float(snap['consumed'].get(k,0))+rates[k]*horizon_minutes for k in snap['limits']}
        overrun={k:max(0.0,projected[k]-float(snap['limits'][k])) for k in snap['limits']}
        return BudgetForecast(remaining,projected,overrun,rates,not any(overrun.values()))

@dataclass(frozen=True)
class CachePolicy:
    ttl_seconds: float | None = None
    consequential: bool = False
    require_fresh_state: bool = True
    negative: bool = False

class CacheFabric:
    """Safe cache + single-flight + state fingerprint invalidation."""
    def __init__(self, max_entries=4096): self.cache=SafeResultCache(max_entries); self.flight=SingleFlight(); self._times={}; self._lock=RLock()
    def get(self,key,current_fingerprint,policy:CachePolicy):
        if policy.consequential and policy.require_fresh_state: return None
        with self._lock:
            created=self._times.get(key)
        if policy.ttl_seconds is not None and created is not None and monotonic()-created > policy.ttl_seconds:
            self.cache.invalidate(key); return None
        return self.cache.get(key,current_fingerprint=current_fingerprint,reusable=not policy.consequential)
    def put(self,key,value,fingerprint):
        self.cache.put(key,value,fingerprint=fingerprint)
        with self._lock:self._times[key]=monotonic()
    def invalidate_state(self,fingerprint): return self.cache.invalidate_fingerprint(fingerprint)
    def stats(self): return self.cache.stats()
    def get_or_compute(self,key,current_fingerprint,policy:CachePolicy,fn:Callable[[],Any]):
        cached=self.get(key,current_fingerprint,policy)
        if cached is not None: return cached
        value=self.singleflight(key,fn)
        if value is not None and not policy.consequential: self.put(key,value,current_fingerprint)
        return value
    def singleflight(self,key,fn): return self.flight.run(key,fn)

@dataclass(frozen=True)
class ObservationPlan:
    mode: str
    sources: tuple[str,...]
    resolution: str = "adaptive"
    reason: str = ""

class ObservationPlanner:
    """Prefer deterministic structured state and minimize visual/network work."""
    ORDER=("api","filesystem","accessibility","dom","cli","ocr","vision")
    def choose(self, available: Sequence[str], *, changed: bool=True, roi: bool=False, sensitive: bool=False) -> ObservationPlan:
        avail=set(available)
        if sensitive: avail.discard("vision"); avail.discard("ocr")
        selected=tuple(x for x in self.ORDER if x in avail)
        if not selected: return ObservationPlan("none",(),reason="no permitted observation source")
        mode=selected[0]
        resolution="roi" if roi and "vision" in selected else ("low" if "vision" in selected and changed else "cached")
        return ObservationPlan(mode,selected,resolution,"structured observation before expensive perception")

@dataclass(frozen=True)
class DeadlineDecision:
    objective: str
    timeout_ms: float
    slack_ms: float
    hedged: bool

class LatencyPolicy:
    def decide(self, *, remaining_ms: float, predicted_ms: float, minimum_timeout_ms: float=250.0, max_timeout_ms: float=120000.0) -> DeadlineDecision:
        if remaining_ms < 0 or predicted_ms < 0: raise ValueError("latency values must be non-negative")
        slack=remaining_ms-predicted_ms
        objective="latency" if slack < 0 else "balanced"
        timeout=max(minimum_timeout_ms,min(max_timeout_ms,remaining_ms if remaining_ms else predicted_ms*2))
        return DeadlineDecision(objective,timeout,max(0.0,slack),False)

class ConcurrencyPolicy:
    def choose(self, *, ready:int, cpu_pressure:float=0.0, memory_pressure:float=0.0, interactive:bool=False, max_workers:int=8) -> int:
        if min(ready,max_workers)<0 or not 0<=cpu_pressure<=1 or not 0<=memory_pressure<=1: raise ValueError("invalid concurrency inputs")
        if ready==0:return 0
        pressure=max(cpu_pressure,memory_pressure)
        base=1 if interactive else min(max_workers,ready)
        return max(1,min(base,max_workers, int(round(base*(1-pressure*0.75)))))

@dataclass(frozen=True)
class IncrementalFingerprint:
    path: str
    digest: str
    size: int
    modified_ns: int

class IncrementalIndex:
    def __init__(self): self._items={}; self._lock=RLock()

    def update_if_changed(self, fp: IncrementalFingerprint) -> bool:
        """Atomically detect and record a changed file fingerprint."""
        with self._lock:
            previous=self._items.get(fp.path)
            changed=previous != fp.digest
            self._items[fp.path]=fp.digest
            return changed

    def remove(self, path: str) -> bool:
        with self._lock: return self._items.pop(path,None) is not None
    def fingerprint(self,path:str,content:bytes,modified_ns:int=0)->IncrementalFingerprint:
        return IncrementalFingerprint(path,sha256(content).hexdigest(),len(content),int(modified_ns))
    def changed(self,fp:IncrementalFingerprint)->bool:
        with self._lock:return self._items.get(fp.path)!=fp.digest
    def update(self,fp:IncrementalFingerprint):
        with self._lock:self._items[fp.path]=fp.digest
    def snapshot(self):
        with self._lock:return dict(self._items)

class TestImpactAnalyzer:
    """Conservative changed-file -> affected-test mapping."""
    def __init__(self, graph: Mapping[str,Sequence[str]]): self._graph={str(k):tuple(v) for k,v in graph.items()}
    def affected(self, changed: Sequence[str], all_tests: Sequence[str]) -> tuple[str,...]:
        changed=set(changed); out=[]
        for test in all_tests:
            deps=set(self._graph.get(test,()))
            if not deps or deps & changed: out.append(test)
        return tuple(sorted(out))

TestImpactAnalyzer.__test__ = False


@dataclass(frozen=True)
class BenchmarkSample:
    name: str
    duration_ms: float
    cost: float
    verified: bool

class BenchmarkRegistry:
    def __init__(self): self._rows=[]; self._lock=RLock()
    def pareto_frontier(self, names: Sequence[str] | None = None) -> tuple[str,...]:
        """Return non-dominated benchmark names on cost/latency/quality."""
        names=set(names or [x.name for x in self._rows]); summaries={n:self.summary(n) for n in names}
        out=[]
        for n,a in summaries.items():
            dominated=False
            for m,b in summaries.items():
                if m==n: continue
                no_worse=b['p95_ms']<=a['p95_ms'] and b['avg_cost']<=a['avg_cost'] and b['verified_rate']>=a['verified_rate']
                strictly=b['p95_ms']<a['p95_ms'] or b['avg_cost']<a['avg_cost'] or b['verified_rate']>a['verified_rate']
                if no_worse and strictly: dominated=True; break
            if not dominated: out.append(n)
        return tuple(sorted(out))
    def record(self,sample:BenchmarkSample):
        if sample.duration_ms<0 or sample.cost<0: raise ValueError("benchmark values must be non-negative")
        with self._lock:self._rows.append(sample)
    def summary(self,name=None):
        with self._lock: rows=[x for x in self._rows if name is None or x.name==name]
        if not rows:return {"count":0,"p50_ms":0.0,"p95_ms":0.0,"avg_cost":0.0,"verified_rate":0.0}
        vals=sorted(x.duration_ms for x in rows)
        pct=lambda p: vals[min(len(vals)-1,math.ceil(len(vals)*p)-1)]
        return {"count":len(rows),"p50_ms":pct(.5),"p95_ms":pct(.95),"avg_cost":statistics.fmean(x.cost for x in rows),"verified_rate":statistics.fmean(bool(x.verified) for x in rows)}
    def regression(self,name:str,baseline_p95_ms:float,baseline_cost:float,latency_tolerance:float=.10,cost_tolerance:float=.10)->bool:
        s=self.summary(name)
        return s["count"]==0 or (s["p95_ms"] <= baseline_p95_ms*(1+latency_tolerance) and s["avg_cost"] <= baseline_cost*(1+cost_tolerance))

@dataclass(frozen=True)
class OptimizationGuard:
    safety_invariants: tuple[str,...] = ("authorization","isolation","verification","auditability","kill_switch")
    def validate(self, *, verified: bool, authorized: bool, isolated: bool, auditable: bool, killable: bool) -> None:
        if not all((verified,authorized,isolated,auditable,killable)):
            raise RuntimeError("optimization rejected: safety invariant would be weakened")

class OptimizationFabric:
    """Single composition point for measured, reversible optimization."""
    def __init__(self):
        self.price_book=PriceBook(); self.cache=CacheFabric(); self.observation=ObservationPlanner(); self.latency=LatencyPolicy(); self.concurrency=ConcurrencyPolicy(); self.index=IncrementalIndex(); self.tests=TestImpactAnalyzer({}); self.benchmarks=BenchmarkRegistry(); self.costs=CostLedger(); self.performance=PerformanceLedger(); self.guard=OptimizationGuard()
    def fingerprint(self,*parts:Any)->str:return stable_key(parts)
    def postflight(self,scope:str,estimate:float,actual:float,latency_ms:float,verified:bool)->dict[str,Any]:
        if min(estimate,actual,latency_ms)<0: raise ValueError("postflight values must be non-negative")
        self.costs.record(scope,"actual",actual,estimated=estimate,variance=actual-estimate)
        self.performance.record(scope,latency_ms,verified)
        return {"scope":scope,"estimated_cost":estimate,"actual_cost":actual,"variance":actual-estimate,"verified":verified}
