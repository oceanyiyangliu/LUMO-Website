# LUMO — Autonomous Agent Operating System

LUMO is an autonomous-agent operating system control plane built around **missions, objectives, execution, verification, governance, persistence, and self-evolution** rather than individual model calls.

The Python package remains named `ocean` for compatibility, while the product and CLI are branded **LUMO**.

## Architecture

```text
MISSION
   ↓
STRATEGIC OBJECTIVES
   ↓
OBJECTIVE CONTRACT
   ↓
RESEARCH / DESIGN / IMPLEMENTATION
   ↓
ISOLATED CANDIDATE
   ↓
EXECUTION + TESTS
   ↓
EVIDENCE / VERIFICATION
   ↓
DETERMINISTIC DECISION
   ↓
PROMOTION or REJECTION
   ↓
PERSISTED STATE + EVENTS
   ↓
RECOVERY / ROLLBACK
```

The model is an **untrusted proposal generator**. It does not approve its own work, mutate production directly, bypass verification, or control promotion and rollback.

## Core capabilities

- Independent ready mission objectives execute concurrently with bounded control-plane parallelism while dependency ordering remains deterministic.

- Mission-level strategic decomposition with dependency validation and re-planning.
- Persistent missions, plans, tasks, runs, findings, verifications, and events.
- Concurrent execution infrastructure with bounded worker capacity.
- Candidate workspaces isolated from production and disposable after execution.
- Objective contracts defining acceptance criteria and evidence requirements.
- Deterministic verification and promotion gates.
- Durable candidate failure diagnostics: command, workspace, exit code, timeout, duration, stdout, and stderr.
- SQLite concurrency hardening for shared control-plane access.
- Production-code promotion with per-run filesystem backups and rollback support.
- Autonomous self-improvement runtime with OpenAI as a replaceable proposal provider.
- Recovery checkpoints for interrupted non-terminal improvement runs.

## Safety boundaries

LUMO separates **proposal** from **authority**.

Candidate code is written only into an isolated workspace. Candidate tests execute against that workspace. Production mutation is performed only by the promotion service after deterministic gates succeed. Protected directories and secret files are refused by the production promotion boundary.

Verification is a separate evidence boundary: a successful process exit does not automatically make an improvement eligible for promotion.

## Installation

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

For autonomous model-backed improvement, install the normal package dependencies and provide an API key:

```bash
export OPENAI_API_KEY="..."
```

## CLI

```bash
lumo --help
lumo mission "Build a resilient autonomous scheduler"
lumo mission "Build a resilient autonomous scheduler" --watch
lumo status <mission_id>
lumo improve "Harden self-improvement concurrency"
lumo serve --port 8765
```

The `ocean` console entrypoint is retained as a compatibility alias.

## Local computer-use agent

LUMO can operate the local macOS GUI through a governed computer-use capability. The model decides GUI actions from screenshots while LUMO executes those actions through the runtime capability boundary.

```bash
lumo computer "Open Canva and create a presentation from the provided requirements" --allow-computer-actions
```

GUI control is explicitly opt-in with `--allow-computer-actions`. Without that flag, read-only screenshot inspection remains available but click/type/navigation actions are blocked by the policy plane. The agent is bounded by a maximum action count, translates window-relative vision coordinates into global macOS coordinates, maintains lightweight world context, routes cognition between fast and deep modes, enforces action boundaries, and uses fresh screenshots as visual evidence after consequential actions.

This makes browser/desktop applications such as Canva first-class execution targets without coupling the mission layer to one application.

## Local control-plane API

`lumo serve` starts a localhost-only HTTP control plane backed by the same durable SQLite event store used by the runtime. The UI consumes this API rather than maintaining fake operational state.

```text
GET  /api/health
GET  /api/missions
GET  /api/missions/<mission_id>
GET  /api/events?mission_id=<mission_id>
POST /api/missions  {"goal":"...","max_replans":8}
```

Mission status, activity, and API submission state are reconstructed from persisted events, so the control plane survives API-process restarts. The server binds to `127.0.0.1` by default.

## Self-improvement lifecycle

A normal improvement run is bounded by:

1. System-owned objective and objective contract.
2. Repository-grounded research.
3. Untrusted model proposal.
4. Candidate mission and plan isolation.
5. Disposable candidate workspace.
6. Candidate code modification.
7. Candidate test execution.
8. Objective-specific evidence collection.
9. Deterministic decision.
10. Production promotion or durable rejection.
11. Backup/rollback and recovery state.

For architecture decisions, see `docs/adr/`.

## Development validation

Run the complete test suite:

```bash
python -m compileall -q ocean persistence runtime tests
pytest -q
```

The suite is designed to exercise domain invariants, persistence, eventing, runtime execution, scheduling, mission orchestration, isolation, self-improvement, concurrency, promotion, rollback, recovery, and CLI behavior. CI runs the backend suite across Python 3.10–3.12 and validates the production UI with lint and a Next.js build.

## Repository layout

```text
ocean/
  authorization/       governance and authorization boundaries
  communication/       structured agent communication
  domain/              core domain entities and invariants
  event_sourcing/      event-sourced support
  identity/            identities and principals
  mission_control/     mission-facing control primitives
  orchestration/       mission planning and autonomous build orchestration
  recovery/            autonomous recovery primitives
  self_improvement/    research, candidate isolation, evidence, promotion
  temporal/            temporal coordination and scheduling
  workforce/           resource allocation
persistence/           repository and SQLite persistence boundaries
eventing/              event stores and dispatching
runtime/               execution, supervision, scheduling, and agent runtime
docs/adr/              architecture decision records
tests/                 deterministic system and integration tests
```

## Global evolution and automatic updates

LUMO separates per-user adaptation from global software evolution. User-specific learning remains account-scoped. Global improvements are proposed and tested in an isolated evolution environment, then released as signed artifacts only after independent regression, security, invariant, benchmark, migration, rollback, and verification gates pass.
The release/update primitives are in `ocean/release.py`, `ocean/update_service.py`, `ocean/fleet_rollout.py`, and `ocean/evolution_service.py`. Clients verify Ed25519 signatures and SHA-256 integrity, stage releases safely, atomically activate them, retain the previous release, and support rollback. Fleet rollout uses deterministic 1% → 10% → 50% → 100% cohorts with health gates.
Build a signed release with `scripts/build_release.py`. The signing private key must remain in the release infrastructure secret store and must never ship to clients. The generated public key is safe to embed in client builds.
Production deployment must provide a trusted HTTPS manifest/artifact endpoint and connect it to the fleet rollout service. The local SQLite server remains a single-device/development mode and is not the production multi-user backend.

See `docs/LUMO_ULTIMATE_LAUNCH.md` for the first-launch contract, no-go conditions, continuous-evolution pipeline, and weekend launch sequence.
