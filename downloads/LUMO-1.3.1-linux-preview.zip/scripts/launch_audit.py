#!/usr/bin/env python3
"""Fail-closed local launch audit for LUMO's release candidate."""
from __future__ import annotations
import json, os, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks: dict[str, bool] = {}

def run(*cmd: str) -> bool:
    return subprocess.run(cmd, cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0

checks["doctor"] = run(str(ROOT/".venv/bin/lumo"), "doctor", "--json")
checks["regression"] = run(str(ROOT/".venv/bin/pytest"), "-q", "--disable-warnings", "--maxfail=1")
checks["ui_build"] = subprocess.run(("npm", "run", "build"), cwd=ROOT/"lumo-ui", stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
checks["release_artifact"] = (ROOT/"dist/lumo-1.0.0-rc1.zip").is_file() and (ROOT/"dist/lumo-1.0.0-rc1.manifest.json").is_file()
checks["persistent_release_signing"] = run("/usr/bin/security", "find-generic-password", "-a", os.getenv("LUMO_RELEASE_KEYCHAIN_ACCOUNT", "production"), "-s", "LUMO Release Signing", "-w")
checks["production_env_template"] = (ROOT/"deploy/.env.production.example").is_file()
checks["launch_docs"] = all((ROOT/p).is_file() for p in ("docs/PUBLIC_LAUNCH.md", "docs/PRIVACY_DATA_LIFECYCLE.md", "docs/TERMS_TEMPLATE.md", "docs/ACCEPTABLE_USE.md", "docs/SUPPORT_RUNBOOK.md"))
checks["openai_credential_available"] = bool(os.getenv("OPENAI_API_KEY")) or run("/usr/bin/security", "find-generic-password", "-s", "LUMO OpenAI", "-w")
email_webhook = os.getenv("LUMO_EMAIL_WEBHOOK_URL", "").startswith("https://") and len(os.getenv("LUMO_EMAIL_WEBHOOK_SECRET", "")) >= 16
email_direct = os.getenv("LUMO_EMAIL_DIRECT_SMTP", "").strip().lower() in {"1", "true", "yes", "on"} and bool(os.getenv("LUMO_EMAIL_FROM", "").strip())
email_resend = bool(os.getenv("RESEND_API_KEY", "").strip()) and bool(os.getenv("LUMO_EMAIL_FROM", "").strip())
checks["email_delivery_configured"] = email_direct or email_resend or email_webhook

blocking = [k for k,v in checks.items() if not v]
print(json.dumps({"ready": not blocking, "checks": checks, "blocking": blocking}, indent=2, sort_keys=True))
sys.exit(1 if blocking else 0)
