#!/usr/bin/env python3
"""Build a deterministic LUMO release bundle and signed manifest."""
from __future__ import annotations

import argparse
import base64
import json
import os
import subprocess
import zipfile
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from ocean.release import ReleaseManifest, ReleaseSigner, artifact_digest
from ocean.versioning import LumoVersion


EXCLUDED = {".git", ".venv", ".ocean", ".pytest_cache", "node_modules", "__pycache__", ".next", "build", "coverage", "dist", ".lumo-worlds", "artifacts", "tmp"}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--version", required=True)
    parser.add_argument("--channel", default="stable")
    parser.add_argument("--out", type=Path, default=Path("dist"))
    args = parser.parse_args()
    LumoVersion.parse(args.version)

    root = args.root.resolve()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    artifact = out / f"lumo-{args.version}.zip"
    with zipfile.ZipFile(artifact, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(root.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(root)
            if any(part in EXCLUDED for part in rel.parts):
                continue
            if rel.parts and rel.parts[0] == "dist":
                continue
            archive.write(path, rel.as_posix())
        archive.writestr("VERSION", args.version)

    digest, size = artifact_digest(artifact)
    manifest = ReleaseManifest(args.version, args.channel, digest, size)
    key_text = os.environ.get("LUMO_RELEASE_PRIVATE_KEY_B64")
    key_file = os.environ.get("LUMO_RELEASE_PRIVATE_KEY_FILE")
    keychain_account = os.environ.get("LUMO_RELEASE_KEYCHAIN_ACCOUNT", "production")
    if not key_text and key_file:
        key_text = Path(key_file).read_text(encoding="utf-8").strip()
    if not key_text and os.uname().sysname == "Darwin":
        result = subprocess.run(
            ["/usr/bin/security", "find-generic-password", "-a", keychain_account, "-s", "LUMO Release Signing", "-w"],
            check=False, capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            key_text = result.stdout.strip()
    if not key_text:
        raise SystemExit("persistent release signing key required: set LUMO_RELEASE_PRIVATE_KEY_B64, LUMO_RELEASE_PRIVATE_KEY_FILE, or macOS Keychain LUMO Release Signing")
    private = Ed25519PrivateKey.from_private_bytes(base64.b64decode(key_text, validate=True))
    signer = ReleaseSigner(private)
    envelope = {
        "manifest": manifest.to_dict(),
        "signature": signer.sign(manifest),
        "public_key": base64.b64encode(signer.public_key_bytes).decode(),
    }
    (out / f"lumo-{args.version}.manifest.json").write_text(
        json.dumps(envelope, indent=2, sort_keys=True), encoding="utf-8"
    )
    print(json.dumps({"artifact": str(artifact), "manifest": str(out / f"lumo-{args.version}.manifest.json"), "version": args.version}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
