#!/usr/bin/env python3
"""Read-only packaged-LUMO launch acceptance checks for a live macOS install."""
from __future__ import annotations
import json, subprocess, sys, time, urllib.request
from pathlib import Path

APP = Path.home() / "Applications" / "LUMO.app"
BASE = "http://127.0.0.1:8767"


def get(path: str):
    last_error = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(BASE + path, timeout=5) as r:
                return json.loads(r.read())
        except Exception as exc:
            last_error = exc
            if attempt < 2:
                time.sleep(0.5 * (attempt + 1))
    assert last_error is not None
    raise last_error


def check(name, ok, detail=""):
    print(("PASS" if ok else "FAIL") + f"  {name}" + (f" — {detail}" if detail else ""))
    return ok


def main():
    results = []
    results.append(check("installed app exists", APP.is_dir(), str(APP)))
    sig = subprocess.run(["/usr/bin/codesign", "--verify", "--deep", "--strict", str(APP)], capture_output=True, text=True)
    results.append(check("code signature valid", sig.returncode == 0, sig.stderr.strip()))
    results.append(check("signed bundle has no runtime .ocean", not (APP / "Contents/Resources/LUMO/.ocean").exists()))
    try:
        health = get("/api/health")
        results.append(check("Core health endpoint", True, str(health)))
        readiness = get("/api/readiness")
        results.append(check("Core readiness endpoint", True, f"ready={readiness.get('ready')} emergency_stop={readiness.get('emergency_stop')}"))
        resource = get("/api/resource-autopilot")
        results.append(check("Resource Autopilot endpoint", resource.get("enabled") is True, f"mode={resource.get('mode')} pressure={resource.get('pressure')}"))
        pulse = get("/api/pulse")
        results.append(check("native pulse endpoint", isinstance(pulse, dict) and "resource_autopilot" in pulse, "resource state is exposed"))
        results.append(check("local device online", len(pulse.get("devices", [])) >= 1, str(len(pulse.get("devices", [])))))
    except Exception as exc:
        results.append(check("Core HTTP connectivity", False, repr(exc)))
    ok = all(results)
    print(f"\nRESULT: {'PASS' if ok else 'FAIL'}")
    return 0 if ok else 1

if __name__ == "__main__":
    raise SystemExit(main())
