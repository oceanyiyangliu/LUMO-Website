#!/usr/bin/env python3
"""Validate the platform-neutral LUMO contract on the current host."""
from __future__ import annotations

import json
import platform
import sys

from ocean.platforms import platform_adapter, runtime_state_dir


def main() -> int:
    adapter = platform_adapter()
    print(json.dumps({
        "platform": adapter.info.os,
        "architecture": adapter.info.architecture,
        "version": adapter.info.version,
        "capabilities": adapter.capabilities(),
        "state_dir": str(runtime_state_dir()),
        "python": sys.version.split()[0],
        "host_system": platform.system(),
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
