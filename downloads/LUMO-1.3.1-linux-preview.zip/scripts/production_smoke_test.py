"""Production launch smoke test. Requires an already deployed HTTPS gateway."""
from __future__ import annotations
import argparse
import json
import os
from ocean.production_monitor import ProductionMonitor

p = argparse.ArgumentParser()
p.add_argument("--health-url", default=os.getenv("LUMO_HEALTH_URL", ""))
p.add_argument("--alerts", default=os.getenv("LUMO_ALERT_FILE", ".ocean/production-alerts.jsonl"))
a = p.parse_args()
if not a.health_url:
    raise SystemExit("LUMO_HEALTH_URL is required")
result = ProductionMonitor(a.health_url, a.alerts).check()
print(json.dumps(result, sort_keys=True))
raise SystemExit(0 if result["healthy"] else 1)
