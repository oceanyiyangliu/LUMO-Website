"""Run scalable large-mission reliability benchmarks from a real module entrypoint."""

from __future__ import annotations

import argparse
import json

from ocean.benchmark.large_mission import LargeMissionBenchmark


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--objectives", type=int, default=1000)
    parser.add_argument("--agents", type=int, default=32)
    args = parser.parse_args()
    result = LargeMissionBenchmark(
        objective_count=args.objectives,
        agent_count=args.agents,
    ).run()
    print(json.dumps(result.__dict__, sort_keys=True, default=list))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
