#!/usr/bin/env python3
"""Run one safe LUMO update check for an installed client."""
from __future__ import annotations

import argparse
import os
from pathlib import Path

from ocean.update_service import UpdateClient


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--install-root", type=Path, required=True)
    parser.add_argument("--public-key", required=True, help="base64 Ed25519 public key")
    parser.add_argument("--manifest-url", required=True)
    parser.add_argument("--artifact-url", required=True)
    args = parser.parse_args()

    import base64
    key = base64.b64decode(args.public_key, validate=True)
    client = UpdateClient(args.install_root, key)
    current = client.current.resolve().name if client.current.is_symlink() else None

    def healthy(path: Path) -> bool:
        version = path / "VERSION"
        return version.is_file() and version.read_text(encoding="utf-8").strip() == path.name

    result = client.update_from_url(
        args.manifest_url, args.artifact_url, healthy, current_version=current
    )
    print(result.status, result.version, result.message)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
