#!/usr/bin/env python3
"""LUMO local 1.0 launch gate: 45 product surfaces with concrete evidence."""
from __future__ import annotations
import json, subprocess, sys
try:
    import resource
except ImportError:
    resource = None
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TESTS = ROOT / "tests"
UI = ROOT / "lumo-ui" / "src" / "app"

GATES: list[tuple[str, tuple[str, ...]]] = [
    ("01 transactional email", ("ocean/email_delivery.py", "tests/test_account_auth.py")),
    ("02 authentication lifecycle", ("ocean/accounts.py", "tests/test_authentication.py", "tests/test_account_auth.py")),
    ("03 permission enforcement", ("ocean/security_boundary.py", "tests/test_executor_permission_contract.py")),
    ("04 emergency stop", ("ocean/api.py", "tests/test_advanced_governance.py", "tests/test_safety.py")),
    ("05 worker lifecycle", ("runtime/agent_execution_lifecycle.py", "tests/test_agent_execution_lifecycle.py")),
    ("06 durable mission recovery", ("ocean/resilience.py", "tests/test_crash_recovery.py", "tests/test_recovery.py")),
    ("07 World isolation", ("tests/test_world_isolation_hardening.py", "tests/test_world_network_policy.py")),
    ("08 clean packaged install", ("tools/build_lumo_app.sh", "scripts/launch_acceptance.py")),
    ("09 AI setup", ("ocean/setup_autopilot.py", "tests/test_local_model_manager.py")),
    ("10 resource admission", ("ocean/local_model_policy.py", "tests/test_local_model_policy.py")),
    ("11 self-improvement safety", ("ocean/self_improvement/coordinator.py", "tests/test_self_improvement_code_modification.py")),
    ("12 update and rollback", ("ocean/update_service.py", "tests/test_release_update_evolution.py")),
    ("13 unified Active Assistant", ("ocean/active_assistant.py", "tests/test_active_assistant.py")),
    ("14 smart placement", ("ocean/lumo_cursor.py", "tests/test_active_assistant_runtime.py")),
    ("15 notifications and alerts", ("tests/test_alerts.py", "tests/test_observability.py")),
    ("16 execution receipts", ("tests/test_execution_and_verification.py", "tests/test_artifact_serializer.py")),
    ("17 budget and cost controls", ("ocean/billing.py", "tests/test_budget.py")),
    ("18 recovery diagnostics", ("ocean/diagnostics.py", "tests/test_recovery.py")),
    ("19 user-facing health", ("ocean/api.py", "tests/test_observability_status.py")),
    ("20 offline resilience", ("tests/test_resilience.py", "tests/test_recovery_advanced.py")),
    ("21 filesystem access boundary", ("tests/test_filesystem_capability.py", "tests/test_terminal_security.py")),
    ("22 destructive-action safeguards", ("ocean/safety.py", "tests/test_safety.py")),
    ("23 end-to-end mission flow", ("tests/test_autonomous_operation_e2e.py", "tests/test_planning_integration.py")),
    ("24 macOS packaging", ("tools/LumoApp.swift", "tools/build_lumo_app.sh")),
    ("25 signing verification", ("scripts/launch_acceptance.py", "tools/build_lumo_app.sh")),
    ("26 launch documentation", ("docs/LUMO_ULTIMATE_LAUNCH.md", "docs/PUBLIC_LAUNCH.md")),
    ("27 privacy model", ("ocean/privacy.py", "docs/PRIVACY_DATA_LIFECYCLE.md")),
    ("28 data lifecycle", ("ocean/backup.py", "tests/test_backup_production.py")),
    ("29 settings surface", ("lumo-ui/src/app/page.tsx",)),
    ("30 memory/state semantics", ("persistence/repository.py", "tests/test_persistence.py")),
    ("31 API contract coverage", ("ocean/api.py", "tests/test_api.py", "tests/test_api_fuzz.py")),
    ("32 HTTP hardening", ("ocean/api_security.py", "tests/test_http_hardening.py")),
    ("33 rate limiting", ("ocean/api.py", "tests/test_api_hardening.py")),
    ("34 tenancy isolation", ("ocean/tenancy.py", "tests/test_tenancy.py")),
    ("35 commercial entitlements", ("ocean/billing.py", "tests/test_billing_lifecycle.py")),
    ("36 backup and restore", ("ocean/backup.py", "tests/test_backup_production.py")),
    ("37 observability", ("ocean/production_monitor.py", "tests/test_observability_telemetry.py")),
    ("38 crash/restart recovery", ("tests/test_crash_recovery.py", "tests/test_recovery.py")),
    ("39 lease expiry/reconciliation", ("runtime/supervisor.py", "tests/test_lease_sweeper.py", "tests/test_orchestrator_reconcile.py")),
    ("40 verification independence", ("tests/test_execution_and_verification.py", "tests/test_verification_serializer.py")),
    ("41 candidate isolation", ("tests/test_candidate_isolation.py", "tests/test_candidate_execution_boundary.py")),
    ("42 model non-authority", ("tests/test_self_improvement_model_objective_authority.py", "tests/test_intelligence_governor.py")),
    ("43 secure release artifact", ("ocean/release.py", "scripts/build_release.py", "tests/test_release_update_evolution.py")),
    ("44 first-launch UX", ("lumo-ui/src/app/HumanFirstLaunch.tsx", "lumo-ui/src/app/loading.tsx", "lumo-ui/src/app/error.tsx")),
    ("45 launch acceptance", ("scripts/launch_acceptance.py", "scripts/launch_audit.py")),
]

def exists(rel: str) -> bool:
    return (ROOT / rel).is_file()

def run(cmd: list[str]) -> bool:
    return subprocess.run(cmd, cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0

def main() -> int:
    if resource is not None:
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        target = min(hard, 4096)
        if soft < target:
            try:
                resource.setrlimit(resource.RLIMIT_NOFILE, (target, hard))
            except (OSError, ValueError):
                pass
    results = []
    for name, evidence in GATES:
        missing = [p for p in evidence if not exists(p)]
        results.append({"gate": name, "pass": not missing, "missing": missing, "evidence": list(evidence)})

    # Presence of an email implementation is not the same as a production
    # email provider being configured. Keep this gate runtime-honest: an
    # unconfigured provider is an external release blocker, not a green test.
    try:
        from ocean.production_readiness import email_delivery_preflight
        email = email_delivery_preflight()
        email_gate = next(item for item in results if item["gate"] == "01 transactional email")
        email_gate["pass"] = bool(email["ready"])
        email_gate["missing"] = [] if email["ready"] else [
            f"external transactional-email provider configuration required ({email['provider']})",
            *[f"direct_smtp:{key}" for key in email["direct_smtp"]["missing"]],
            *[f"resend:{key}" for key in email["resend"]["missing"]],
            *[f"webhook:{key}" for key in email["webhook"]["missing"]],
        ]
        email_gate["runtime_preflight"] = email
    except Exception as exc:
        email_gate = next(item for item in results if item["gate"] == "01 transactional email")
        email_gate["pass"] = False
        email_gate["missing"] = [f"email preflight failed: {type(exc).__name__}: {exc}"]
    static_ok = all(r["pass"] for r in results)
    tests_ok = run([str(ROOT / ".venv/bin/python"), "-m", "pytest", "-q", "--disable-warnings", "--maxfail=1"])
    ui_ok = subprocess.run(["npm", "run", "lint"], cwd=ROOT / "lumo-ui", stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
    type_ok = subprocess.run(["npm", "run", "typecheck"], cwd=ROOT / "lumo-ui", stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
    build_ok = subprocess.run(["npm", "run", "build"], cwd=ROOT / "lumo-ui", stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
    results.extend([
        {"gate": "REGRESSION SUITE", "pass": tests_ok, "missing": [], "evidence": ["pytest -q"]},
        {"gate": "UI LINT", "pass": ui_ok, "missing": [], "evidence": ["npm run lint"]},
        {"gate": "UI TYPECHECK", "pass": type_ok, "missing": [], "evidence": ["npm run typecheck"]},
        {"gate": "UI PRODUCTION BUILD", "pass": build_ok, "missing": [], "evidence": ["npm run build"]},
    ])
    report = {"ready": static_ok and tests_ok and ui_ok and type_ok and build_ok, "gates": results}
    print(json.dumps(report, indent=2))
    return 0 if report["ready"] else 2

if __name__ == "__main__":
    raise SystemExit(main())
