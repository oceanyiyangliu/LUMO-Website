#!/usr/bin/env python3
"""Fail-closed production deployment preflight for LUMO."""
from __future__ import annotations
import argparse, hashlib, json, os, stat, sys, zipfile
from pathlib import Path
from ocean.production_readiness import production_config_gates


def load_env(path: Path) -> dict[str, str]:
    env = dict(os.environ)
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith('#') or '=' not in line: continue
        k, v = line.split('=', 1); env[k.strip()] = v.strip().strip('"').strip("'")
    return env


def check_path(name: str, value: str, *, writable_parent=False) -> tuple[bool,str]:
    if not value: return False, f'{name}: missing'
    p=Path(value).expanduser()
    if writable_parent:
        parent=p if p.is_dir() else p.parent
        return parent.exists() and os.access(parent, os.W_OK), f'{name}: {parent}'
    return p.is_file() and os.access(p, os.R_OK), f'{name}: {p}'


def main() -> int:
    ap=argparse.ArgumentParser(); ap.add_argument('--env-file', required=True); ap.add_argument('--artifact'); ap.add_argument('--manifest'); args=ap.parse_args()
    env=load_env(Path(args.env_file)); gates=production_config_gates(env); failures=[]
    for name, ok in gates.items():
        if not ok: failures.append(name)
    for n in ('LUMO_TLS_CERT_FILE','LUMO_TLS_KEY_FILE'):
        ok,msg=check_path(n,env.get(n,'')); print(('PASS ' if ok else 'BLOCK ')+msg)
        if not ok: failures.append(n)
    ok,msg=check_path('LUMO_TENANCY_STORE',env.get('LUMO_TENANCY_STORE',''),writable_parent=True); print(('PASS ' if ok else 'BLOCK ')+msg)
    if not ok: failures.append('tenancy_store_path')
    if args.artifact:
        p=Path(args.artifact); ok=p.is_file() and zipfile.is_zipfile(p)
        print(('PASS ' if ok else 'BLOCK ')+f'artifact: {p}')
        if not ok: failures.append('artifact')
        else: print('ARTIFACT_SHA256 '+hashlib.sha256(p.read_bytes()).hexdigest())
    if args.manifest:
        p=Path(args.manifest); ok=p.is_file()
        if ok:
            try: json.loads(p.read_text())
            except Exception: ok=False
        print(('PASS ' if ok else 'BLOCK ')+f'manifest: {p}')
        if not ok: failures.append('manifest')
    print('LUMO PRODUCTION PREFLIGHT: '+('PASS' if not failures else 'BLOCKED'))
    if failures: print('BLOCKERS: '+', '.join(dict.fromkeys(failures)))
    return 0 if not failures else 2

if __name__ == '__main__': sys.exit(main())
