#!/usr/bin/env python3
"""Create a persistent Ed25519 release key in the macOS Keychain.

The private key never enters the repository. The release builder reads it only
from the Keychain service ``LUMO Release Signing``. Back up the key securely if
this machine is the authoritative release signer.
"""
from __future__ import annotations
import base64
import os
import subprocess
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

account = os.getenv("LUMO_RELEASE_KEYCHAIN_ACCOUNT", "production")
check = subprocess.run(["/usr/bin/security", "find-generic-password", "-a", account, "-s", "LUMO Release Signing", "-w"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
if check.returncode == 0:
    print("LUMO release signing key already exists in Keychain")
    raise SystemExit(0)
private = Ed25519PrivateKey.generate()
raw = private.private_bytes_raw()
b64 = base64.b64encode(raw).decode()
subprocess.run(["/usr/bin/security", "add-generic-password", "-U", "-a", account, "-s", "LUMO Release Signing", "-w", b64], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
print("Created persistent LUMO release signing key in macOS Keychain")
print("Public key:", base64.b64encode(private.public_key().public_bytes_raw()).decode())
print("Account:", account)
