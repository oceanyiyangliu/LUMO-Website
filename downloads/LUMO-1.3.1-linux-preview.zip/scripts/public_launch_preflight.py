#!/usr/bin/env python3
"""Public-launch preflight: deterministic checks for artifacts, versions and external blockers."""
from __future__ import annotations
import json, os, platform, hashlib
from pathlib import Path
from ocean.versioning import LumoVersion

ROOT=Path(__file__).resolve().parents[1]
SITE=ROOT/"lumo-site/public/downloads"

EXPECTED={"macos":"1.1.1","windows":"1.2.1","linux":"1.3.1"}
FILES={
 "macos": SITE/"LUMO-1.1.1-macOS-arm64.zip",
 "windows": SITE/"LUMO-1.2.1-windows-preview.zip",
 "linux": SITE/"LUMO-1.3.1-linux-preview.zip",
}

def sha256(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""): h.update(chunk)
    return h.hexdigest()

def main():
    rows=[]
    for platform_name,version in EXPECTED.items():
        parsed=LumoVersion.parse(version)
        path=FILES[platform_name]
        rows.append({
            "platform":platform_name,"version":version,
            "version_valid":parsed.platform=={"macos":1,"windows":2,"linux":3}[platform_name],
            "artifact_exists":path.is_file(),
            "sha256":sha256(path) if path.is_file() else None,
            "artifact_size":path.stat().st_size if path.is_file() else 0,
        })
    provider=os.getenv("LUMO_EMAIL_PROVIDER","").strip().lower()
    email_ready=bool(provider and (
        (provider=="smtp" and os.getenv("LUMO_EMAIL_SMTP_HOST") and os.getenv("LUMO_EMAIL_SMTP_USERNAME") and os.getenv("LUMO_EMAIL_SMTP_PASSWORD") and os.getenv("LUMO_EMAIL_FROM")) or
        (provider=="resend" and os.getenv("RESEND_API_KEY") and os.getenv("LUMO_EMAIL_FROM")) or
        (provider=="webhook" and os.getenv("LUMO_EMAIL_WEBHOOK_URL") and os.getenv("LUMO_EMAIL_WEBHOOK_SECRET"))
    ))
    report={"host":{"system":platform.system(),"machine":platform.machine()},
            "artifacts":rows,"email":{"provider":provider or None,"ready":email_ready},
            "ready":all(r["version_valid"] and r["artifact_exists"] for r in rows)}
    print(json.dumps(report,indent=2))
    return 0 if report["ready"] else 2

if __name__=="__main__":
    raise SystemExit(main())
