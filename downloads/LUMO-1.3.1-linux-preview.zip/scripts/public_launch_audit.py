#!/usr/bin/env python3
"""Provider-aware, fail-closed public launch audit for LUMO."""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

from ocean.production_readiness import HARD_LAUNCH_GATES, production_config_gates

ROOT = Path(__file__).resolve().parents[1]
PYTHON = ROOT / ".venv/bin/python"


def run_json(cmd: list[str]) -> tuple[bool, dict]:
    completed = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    try:
        payload = json.loads(completed.stdout)
    except json.JSONDecodeError:
        payload = {}
    return completed.returncode == 0, payload


def run(cmd: list[str], cwd: Path = ROOT) -> bool:
    return subprocess.run(cmd, cwd=cwd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0


def main() -> int:
    gates: dict[str, bool] = {}

    gates["doctor"] = run([str(ROOT / ".venv/bin/lumo"), "doctor", "--json"])
    # Use the resource-safe launch regression runner rather than invoking pytest
    # directly. The latter can exhaust macOS' per-process file descriptor limit
    # during pytest's own temp-tree cleanup on large suites.
    gates["regression"] = run_json([str(PYTHON), "scripts/launch_45_gate.py"])[0]
    gates["ui_build"] = run(["npm", "run", "build"], ROOT / "lumo-ui")
    gates["website_build"] = run(["npm", "run", "build"], ROOT / "lumo-site")

    # Product gates are backed by the 45-surface launch gate rather than by
    # file-existence checks. This prevents a missing implementation from being
    # reported as ready merely because a placeholder file exists.
    launch_ok, launch_report = run_json([str(PYTHON), "scripts/launch_45_gate.py"])
    surface_by_name = {
        item.get("gate"): bool(item.get("pass"))
        for item in launch_report.get("gates", [])
        if isinstance(item, dict)
    }
    gates["security"] = all(surface_by_name.get(name, False) for name in (
        "03 permission enforcement", "22 destructive-action safeguards", "32 HTTP hardening", "33 rate limiting"
    ))
    gates["authorization_isolation"] = all(surface_by_name.get(name, False) for name in (
        "03 permission enforcement", "21 filesystem access boundary", "34 tenancy isolation", "41 candidate isolation"
    ))
    gates["durability_recovery"] = all(surface_by_name.get(name, False) for name in (
        "06 durable mission recovery", "28 data lifecycle", "36 backup and restore", "38 crash/restart recovery", "39 lease expiry/reconciliation"
    ))
    gates["verification"] = all(surface_by_name.get(name, False) for name in (
        "16 execution receipts", "40 verification independence", "42 model non-authority"
    ))
    gates["kill_pause_takeover"] = all(surface_by_name.get(name, False) for name in (
        "04 emergency stop", "13 unified Active Assistant", "15 notifications and alerts"
    ))

    # Local release acceptance proves the installed artifact is usable on the
    # current machine. It is deliberately separate from public infrastructure.
    acceptance_ok, acceptance = run_json([str(PYTHON), "scripts/launch_acceptance.py"])
    gates["clean_install"] = acceptance_ok
    gates["backup_restore"] = surface_by_name.get("36 backup and restore", False)
    gates["update_rollback"] = surface_by_name.get("12 update and rollback", False)

    # These are intentionally external deployment gates. The audit must stay
    # red until real credentials, storage, TLS, monitoring and email exist.
    gates.update(production_config_gates(os.environ))

    blocking = [gate for gate in HARD_LAUNCH_GATES if not gates.get(gate, False)]
    report = {
        "ready": not blocking,
        "checks": gates,
        "blocking": blocking,
        "local_evidence": {
            "launch_45_ok": launch_ok,
            "launch_45": launch_report,
            "launch_acceptance_ok": acceptance_ok,
            "launch_acceptance": acceptance,
        },
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if not blocking else 1


if __name__ == "__main__":
    raise SystemExit(main())
