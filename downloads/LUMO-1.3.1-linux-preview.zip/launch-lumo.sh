#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON="$(command -v python3 || true)"
if [[ -z "$PYTHON" ]]; then echo "LUMO needs Python 3.10 or newer. Install Python 3 and run this file again."; exit 1; fi
"$PYTHON" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)' || { echo "LUMO needs Python 3.10 or newer."; exit 1; }
if [[ ! -x ".lumo-preview/bin/python" ]]; then "$PYTHON" -m venv .lumo-preview; fi
".lumo-preview/bin/python" -m pip install --upgrade pip
".lumo-preview/bin/python" -m pip install .
exec ".lumo-preview/bin/python" -m lumo "$@"
