# ADR 0001: Phase 1 domain foundation

## Decision

Implement Task, Mission, Agent, Event, EventBus, Message, Artifact,
Capability(Registry), Policy(Engine), Execution, Observation, and
Verification as a standalone, dependency-free Python package (`ocean/`),
with no dependency on OpenAI, macOS, or any I/O layer.

## Alternatives considered

1. **Start from the old prototype's `Task`/`agent.py` and refactor in
   place.** Rejected per explicit direction: the prototype is disposable
   reference material, not an architectural constraint. Refactoring in
   place would have imported its assumptions (a single hard-coded action
   list, GUI-automation-first execution) into the new foundation.
2. **Use pydantic for validation/schemas instead of stdlib
   dataclasses.** Rejected for Phase 1 specifically: pydantic is a
   reasonable future dependency (schema validation for capability
   input/output contracts in Phase 4), but Phase 1 has no external
   input to validate yet -- everything is constructed in-process. Adding
   it now would violate "dependency freedom" (brief section 65: don't
   add a dependency until it earns its place). Revisit when the
   CapabilityRuntime needs to validate untrusted model-generated
   arguments against `input_schema`.
3. **Async event bus from the start.** Rejected for Phase 1. The
   brief's own phase order puts persistence and the "real" event/state
   system in Phase 2. A synchronous, in-memory `EventBus` lets every
   other Phase 1 test stay deterministic and fast (46 tests run in
   ~0.1s) while keeping the public interface (`subscribe`, `publish`,
   `history`) stable enough that Phase 2 can swap the internals for an
   async/persistent implementation without touching call sites.

## Consequences

- `Task.complete()` is the *only* code path to `TaskStatus.COMPLETED`,
  and it hard-requires a passing `Verification` scoped to that exact
  task id. This makes RULE 11 ("execution success != task success") a
  structural property of the code, not a convention agents are trusted
  to follow.
- `CapabilityRegistry` has no knowledge of what capabilities will
  eventually exist (filesystem, browser, pdf, ...); `describe()`
  produces a plain JSON-serializable dict specifically so the future
  reasoning/planning layer can hand it to a model as ground truth,
  rather than letting the model assume capabilities exist.
- `PolicyEngine` separates "risk level" (declared per-operation by
  capability authors) from "approval decision" (owned centrally, with
  per-operation override hooks). No capability implementation will ever
  need to embed approval logic.
- State machines are table-driven and shared via one generic
  `StateMachine` class rather than one-off `if status == ...` chains
  per entity, so every entity's legal-transition table is auditable in
  one place per file.

## Deferred to later phases (explicitly, not accidentally)

- Persistence / durability across process restarts (Phase 2, brief
  section 33).
- Resource *admission* (queueing/deferring based on availability) --
  Phase 1 only declares `ResourceRequirement`, it doesn't enforce
  anything (Phase 3).
- Binding `CapabilitySpec` metadata to real runtime implementations
  (Phase 4 CapabilityRuntime; Phase 5 macOS adapters).
- Model-provider interface (Phase 6).
