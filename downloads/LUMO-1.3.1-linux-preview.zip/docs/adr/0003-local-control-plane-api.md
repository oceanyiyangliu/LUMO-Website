# ADR 0003 — Local control-plane API

## Status

Accepted for LUMO v0.1.

## Context

LUMO is a mission-oriented autonomous control plane. The web console must
observe durable operational state rather than maintain a second, fabricated
state model. The existing event store and operational status projector already
provide the canonical read model, but there was no HTTP boundary for external
control-plane clients.

## Decision

Add a small standard-library HTTP server in `ocean/api.py` and expose it through
`lumo serve`. The server binds to `127.0.0.1` by default and uses the existing
`OceanService` event store and `LiveStatusReader`.

The initial contract is:

- `GET /api/health` — service health and lifecycle state.
- `GET /api/missions` — durable mission status summaries.
- `GET /api/missions/<id>` — one event-sourced mission read model.
- `GET /api/events?mission_id=<id>` — durable event stream inspection.
- `POST /api/missions` — submit an intent for asynchronous execution.
- `GET /api/submissions/<id>` — startup/submission state before an aggregate exists.

The API is intentionally transport-only. Planning, governance, scheduling,
execution, recovery, and verification remain owned by their existing planes.

## Consequences

The LUMO UI can consume real mission and event state without inventing agents,
objectives, progress, or timestamps. The server has no additional persistence
model for mission state: persisted events remain the source of truth.

The first version is local-only. Authentication, remote deployment, rate
limits, and streaming transport are separate decisions and are not implied by
this API.
