# LUMO Autonomous Evolution Control Plane v1.0

## Status
Implemented and hardened in the v1.0 release snapshot.

## Intent
Make autonomous improvement a first-class, evidence-driven evolution loop rather than a benchmark-only code patcher.

## Guarantees

1. **Objective authority** — the system-owned objective remains authoritative. Model output can provide descriptive hypothesis text but cannot fork objective identity.
2. **Objective-specific evidence** — `ObjectiveContract` declares work type, acceptance criteria and evidence policy. Benchmark improvement is required only when the contract asks for benchmark evidence.
3. **Candidate isolation** — code changes are generated and applied in disposable, uniquely identified workspaces; production mutation is forbidden at the model boundary.
4. **Failure observability** — candidate test failures retain command, workspace, exit code, timeout, duration, stdout and stderr in the improvement result metadata.
5. **Concurrent evolution** — `AutonomousImprovementRuntime.improve_many()` can execute independent improvement candidates concurrently while preserving independent candidate identities and workspaces.
6. **Durable concurrency** — SQLite repositories serialize shared-connection access and enable WAL/busy-timeout/NORMAL synchronous mode for safer concurrent control-plane activity.
7. **Deterministic promotion** — models never approve or promote their own changes; verification and promotion remain deterministic services.

## Evidence model

Supported evidence kinds are tests, benchmark, structural, behavioral, persistence, concurrency, verification, research and composite evidence.

The architecture intentionally separates **evidence** from **improvement**. A candidate can be correct because it satisfies an architectural invariant even when no numeric benchmark improves.

## Non-goals

This release does not grant an LLM unrestricted host access, secret access, production mutation authority, or the ability to bypass governance. Performance is increased through bounded concurrency and storage tuning rather than removing safety boundaries.
