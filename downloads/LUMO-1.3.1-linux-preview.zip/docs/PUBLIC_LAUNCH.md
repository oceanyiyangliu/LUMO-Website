# LUMO Public Launch Runbook

## Launch definition

LUMO is launchable when a fresh user can install it, create/verify an account, establish their Root, configure an intelligence provider, run a real mission, receive a verified result, restart without losing durable state, recover their Root, and delete/export their account according to the published retention policy.

## Technical gates

- Core regression and doctor are green.
- World execution is isolated from the host keyboard, pointer, display, clipboard, and filesystem.
- Root owns authority; Nodes own execution.
- Emergency stop invalidates active actuators and Worlds.
- Authentication, CSRF, session revocation, brute-force protection, email verification, password reset, export, and account deletion are tested.
- A production-signed release artifact verifies on a clean machine.
- Production deployment uses HTTPS, durable storage, monitoring, backups, and managed secrets.
- Transactional email is configured and delivery is tested.
- A real AI-provider mission has passed end-to-end.

## External dependencies

The repository cannot create these resources automatically:

1. transactional email account/domain/webhook;
2. production hosting and DNS/HTTPS;
3. payment processor, if paid plans launch;
4. business/legal identity and support contact;
5. production secret manager and backup destination.

These must be supplied and verified before a public service is advertised as available.

## First public release sequence

1. Configure email delivery and test verification/reset mail.
2. Configure an AI provider through the LUMO Settings/first-launch flow; credentials stay in the platform credential store.
3. Run the fresh-user mission E2E on the release candidate.
4. Run the root recovery and account export/deletion drills.
5. Deploy behind the trusted HTTPS edge.
6. Run the production smoke test and backup/restore drill.
7. Publish Terms, Privacy, AUP, refund/subscription policy if applicable, support contact, and retention/deletion policy after human/legal review.
8. Publish the signed release artifact and checksum/manifest.

## Explicit non-goals for v1

LUMO Computer/Mirror, continuous self-improvement, large stress benchmarks, and broad distributed cloud orchestration are not launch prerequisites.
