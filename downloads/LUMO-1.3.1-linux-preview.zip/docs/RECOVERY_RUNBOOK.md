# LUMO Recovery Runbook

## Scope
Local control-plane recovery for service, event store, workers and Worlds.

## 1. Detect
Run `lumo status` and the readiness endpoint. Check the durable event store
integrity result before restarting execution.

## 2. Stop safely
Engage Emergency Stop before invasive recovery. This prevents new execution,
releases power leases, and destroys active Worlds.

## 3. Preserve evidence
Create a SQLite backup and diagnostic bundle before repairing state. Preserve
incident IDs, event hashes and the last known mission receipt.

## 4. Recover
Restart the service. Rebuild projections from the canonical event stream.
Reconcile expired leases and quarantine any integrity failures.

## 5. Verify
Confirm readiness, event-store integrity, zero unauthorized active assignments,
and no orphaned QEMU processes. Only then release Emergency Stop.

## 6. Disaster recovery
Restore the latest verified database backup, replay events after the snapshot,
verify hash chains, then perform a dry-run mission before resuming autonomous work.

### Power sleep/wake recovery
An active mission owns a power lease. On a host wake boundary, the next power
status/lease reconciliation reasserts the sleep-prevention process if it died.
Display sleep remains permitted. This is intentionally implemented as a
reassertion rather than a hidden permanent wake lock.

### Service reboot recovery
On service construction, durable non-terminal `MissionSubmissionAccepted` streams
are rehydrated as `recoverable`. Emergency Stop remains engaged until an explicit
release; release then resumes recovered missions. Terminal streams are never
restarted. This makes restart recovery idempotent and prevents a crash from
silently becoming a second mission execution.
