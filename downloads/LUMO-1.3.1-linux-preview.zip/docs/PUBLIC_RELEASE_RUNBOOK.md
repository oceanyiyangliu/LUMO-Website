# LUMO Public Release Runbook
1. Provision real production domain, HTTPS edge, auth/tenant store, transactional email, monitoring, backups and secret manager.
2. Create Apple Developer ID Application identity and store notarization credentials in macOS Keychain; never put certificates/private keys in git.
3. Set LUMO_CODESIGN_IDENTITY and LUMO_NOTARY_PROFILE, then run tools/build_public_release.sh.
4. Validate the DMG on a clean supported Mac: Gatekeeper, first launch, signup/login, verification email, Work, permissions, restart, update and rollback.
5. Generate the signed release manifest with tools/release_manifest.py using a production-held Ed25519 private key.
6. Publish DMG and manifest through release storage/CDN. Set NEXT_PUBLIC_LUMO_MAC_DOWNLOAD_URL only after validation.
7. Run scripts/production_preflight.py with the actual production environment and scripts/public_launch_audit.py.
8. Release only when every hard gate is green. Never substitute local/dev evidence for production infrastructure.
