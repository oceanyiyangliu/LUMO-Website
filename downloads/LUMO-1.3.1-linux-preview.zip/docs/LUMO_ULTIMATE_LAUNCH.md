# LUMO Ultimate — First Launch Contract

Target launch: Monday, 21 September 2026.

This is a controlled first release. The release goal is a trustworthy mission loop, not a claim that every possible task is already solved.

## Launch promise

A user can submit a supported multi-step mission. LUMO plans it, executes authorized work, recovers from expected failures, independently verifies the result, exposes evidence, and keeps the user able to pause, stop, or take over.

## Launch gates

- [ ] No silent false success.
- [ ] No authorization overreach.
- [ ] Pause, stop, kill, and takeover work against active execution.
- [ ] No secret exposure.
- [ ] No cross-account data leakage.
- [ ] Candidate and production isolation is enforced.
- [ ] Durable state survives service restart.
- [ ] Recovery and replay are tested.
- [ ] Verification is independent of model claims.
- [ ] Unsupported work fails safely and visibly.
## Production platform

Required before public access:

- [ ] HTTPS termination.
- [ ] Account authentication and session management.
- [ ] Per-account mission/event/artifact isolation.
- [ ] Durable production database and migrations.
- [ ] Durable queue and worker supervision.
- [ ] Secret manager; no provider keys in frontend, prompts, logs, or artifacts.
- [ ] Rate limits and abuse controls.
- [ ] Structured logs, metrics, alerts, and operator dashboard.
- [ ] Automated backups plus a tested restore.
- [ ] Incident and rollback runbook.
- [ ] Terms, privacy, retention, deletion, and support contact.

The local SQLite control plane remains a development/single-device mode. It is not the public multi-user backend.

## Mission lifecycle

OPEN → AUTHENTICATE → SUBMIT → PLAN → AUTHORIZE → EXECUTE → RECOVER IF NEEDED → VERIFY → EVIDENCE → COMPLETE.

The completion contract must be evidence-based. A model response alone is never proof of completion.
## Continuous evolution

LUMO has two separate learning scopes.

### User scope

User-specific preferences, skills, workflow patterns, and mission context remain account-scoped.

### Global scope

Fleet observations identify engineering problems. The evolution environment proposes and tests code changes. Production installations consume signed releases; they do not silently rewrite their own production source.

Pipeline:

OBSERVE → DIAGNOSE → PRIORITIZE → PROPOSE → ISOLATE → IMPLEMENT → TEST → BENCHMARK → SECURITY/INVARIANTS → INDEPENDENT VERIFICATION → SIGN → CANARY → MEASURE → PROMOTE or ROLLBACK.

The model is a proposal generator, never the release authority.
## Automatic updates

Every installation has a release channel and periodically checks a trusted update endpoint.

Client sequence:

1. Fetch signed manifest.
2. Verify Ed25519 signature with an embedded public key.
3. Download artifact over HTTPS.
4. Verify SHA-256 and exact size.
5. Safely extract into a new release directory.
6. Run staged health checks.
7. Atomically switch the current symlink.
8. Preserve the previous release.
9. Report health.
10. Roll back automatically if post-activation health fails.

No update is applied from an unsigned or corrupted artifact.

Fleet rollout stages are 1% → 10% → 50% → 100%. Stable hashing keeps installations in deterministic cohorts.
## Release gates

Every global release must prove:

- regression suite passes;
- security suite passes;
- LUMO hard invariants pass;
- objective-specific benchmark is non-regressive;
- database/data migration is tested;
- rollback is tested;
- verification evidence exists.

Hard governance invariants cannot be traded for cost, latency, rollout speed, or model confidence:

authorization, isolation, verification, auditability, kill switch, secret protection, trust boundaries, and model non-authority.

If a hard gate fails, the release is rejected or rolled back.
## Release channels

- development: evolution environment only;
- canary: smallest production cohort;
- beta: opt-in early users;
- stable: normal users.

A stable release is promoted only after measured fleet health remains within the configured thresholds.

The update service is designed so all users converge on the same signed release instead of accumulating per-user code forks.
## Weekend execution order

### Saturday
1. Freeze architecture and launch scope.
2. Run the complete regression suite.
3. Run security/authorization/isolation/verification/kill tests.
4. Exercise real browser/computer workflows.
5. Test crash, restart, lease expiry, recovery, and replay.
6. Build a production deployment candidate.

### Sunday
1. Fix launch blockers only.
2. Run regression again.
3. Test clean installation.
4. Test database backup and restore.
5. Test update install and rollback.
6. Test canary/freeze/rollback policy.
7. Verify onboarding and account isolation.
8. Final release candidate and launch checklist.

### Monday
1. Production smoke test.
2. Internal launch.
3. Canary release.
4. Monitor.
5. Expand only when gates remain green.
## Current engineering evidence

The repository currently has a broad deterministic regression suite and has passed 1,496 tests in the latest verified run on 19 September 2026.

A 1,000-objective synthetic mission benchmark with 32 agents completed with:
- 1,000/1,000 objectives completed;
- 0 terminal failures;
- 3 recovered objectives;
- 9 retries;
- 1 lease expiration;
- 1 process termination;
- 0 duplicate/stale completions;
- 1,000/1,000 replayed objectives.

A host smoke test also provisioned a real QEMU desktop World, confirmed `isolated=true` and `backend=qemu`, and captured a 640×384 World screenshot through the World VNC path without attaching a host executor. The focused security/isolation/release/backup suite passed 41 tests, and the broader security/authentication/authorization/billing/tenancy suite passed 52 tests.

These are engineering evidence, not proof of universal real-world autonomy. The 10,000-objective run was attempted but not completed and must not be presented as passed.
## New launch infrastructure

Implemented in this release candidate:

- ocean/release.py: signed manifests, Ed25519 verification, artifact hashing, independent release gates.
- ocean/update_service.py: HTTPS update retrieval, signature/integrity verification, safe extraction, atomic activation, rollback.
- ocean/fleet_rollout.py: deterministic cohorts, canary stages, fleet health gates, freeze/rollback, hard evolution gates.
- ocean/evolution_service.py: durable observe → prioritize → improve → gate → canary cycle.
- scripts/lumo_update_check.py: one-shot client updater suitable for a scheduled service.
- tests/test_release_update_evolution.py: release, archive-safety, rollback, rollout, and evolution coverage.

These components are launch infrastructure; the public cloud endpoint and deployment wiring still have to be configured for the actual production environment.
## Final no-go conditions

Do not launch publicly if any of these are unresolved:

- a user can access another user's state;
- an untrusted model can grant itself authority;
- a consequential action cannot be stopped;
- a completion can be marked verified without required evidence;
- a release can be installed without signature/integrity validation;
- an update can leave the installation in a non-bootable half-state;
- rollback has not been tested;
- production secrets can enter model-visible context;
- durable mission state can be silently lost.

Launch means verified useful behavior, not a “done” claim.
