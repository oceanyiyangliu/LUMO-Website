# LUMO Acceptable Use Policy — Launch Draft

**Draft for legal/security review.**

Users must not use LUMO to violate law, obtain unauthorized access to systems or accounts, bypass security controls, distribute malware, abuse third-party services, or direct autonomous agents to cause harm. Users must have authority to access the devices, data, accounts, and services they connect.

LUMO may refuse, pause, isolate, or terminate execution when authorization, safety, abuse, or system-integrity controls are triggered.

The final public policy must define reporting, enforcement, appeals/contact procedures, and jurisdiction-specific requirements.
