# LUMO Launch Support Runbook

## First response

1. Identify LUMO version and installation mode.
2. Ask whether the issue affects account/authentication, intelligence provider, mission execution, World execution, device/Node pairing, billing, or recovery.
3. Never ask a user to paste an API key, password, recovery password, session token, or Root private material into support chat.
4. Capture redacted diagnostics only.

## Safe recovery

- Mission stuck: inspect durable mission status before restarting anything.
- Provider unavailable: reconfigure the provider through LUMO's credential UI; do not request plaintext credentials in tickets.
- World failure: destroy/recover the isolated World rather than falling back to host GUI control.
- Suspected runaway execution: engage emergency stop first.
- Root loss: use the private Root recovery workflow.
- Suspected credential compromise: revoke the affected session/credential and rotate the provider credential.

## Operator boundary

The private Root Console is not a normal-user feature. Operators may use bounded recovery, integrity, World-destruction, lease, rollback, and diagnostic controls. Unrestricted host control is not a supported recovery mechanism.
