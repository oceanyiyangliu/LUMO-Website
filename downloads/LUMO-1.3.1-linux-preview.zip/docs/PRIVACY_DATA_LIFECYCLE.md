# LUMO Data and Privacy Lifecycle — Launch Draft

**Status: draft for human/legal review.** This document describes the intended technical behavior and is not legal advice.

## Local data

A local LUMO installation stores account metadata, Root authority state, device/node state, mission history, World metadata/evidence, billing/usage state, and encrypted event history in its configured state directory.

## Credentials

Long-lived OpenAI credentials on macOS are stored in the macOS Keychain rather than browser storage. Passwords are stored as salted scrypt hashes. Session credentials are revocable and are not intended to be returned to the UI after issuance.

## AI providers

When a cloud intelligence provider is enabled, mission prompts, bounded repository context, and other information necessary for the requested operation may be sent to that provider. LUMO should not claim that data stays local when a cloud provider is selected.

## Worlds

Worlds may contain mission-created files, browser state, screenshots, and other evidence. World resources are isolated execution environments. World destruction is the mechanism for removing their active resources; durable evidence/exports follow the account retention policy.

## Export

The account export endpoint provides account-attributed identity, Root reference, devices, Nodes, missions, Worlds, billing snapshot, adaptive state, and account-attributed events.

## Deletion

Account deletion removes the account identity and account-owned operational stores, revokes sessions, destroys account-owned Worlds, removes Nodes/devices, removes billing records, and deletes the account's OpenAI Keychain credential.

The event history is integrity-protected and encrypted at rest. Before making a public promise of immediate erasure of historical event records, the deployment must choose and document one of: a defined security/audit retention period, cryptographic erasure, or a privacy-redaction mechanism that preserves the integrity guarantees required by the deployment. Do not advertise stronger deletion semantics than the deployed policy actually provides.

## Backups

Backups are separate copies and therefore require their own retention and deletion policy. A user deletion request is not complete until the applicable backup retention rule has been satisfied.

## Training

LUMO must publish the actual policy governing whether LUMO-controlled data is used for model training. Do not infer or advertise a provider's training policy as LUMO's policy.
