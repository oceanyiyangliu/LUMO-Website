# LUMO Public Launch Master

This is the release-control checklist for a genuine public launch. A checkbox is only green when evidence exists; external prerequisites are explicitly marked.

## Release identity
- [x] Canonical version format: CORE.PLATFORM.REVISION
- [x] macOS platform ID 1
- [x] Windows platform ID 2
- [x] Linux platform ID 3
- [x] Platform/version validation in packaging

## Product readiness
- [x] Mission execution
- [x] durable recovery
- [x] resource admission
- [x] emergency stop
- [x] permissions enforcement
- [x] execution receipts
- [x] self-improvement safety
- [x] Active Assistant
- [x] first-launch flow
- [x] privacy/data lifecycle foundations
- [x] update/rollback foundations
- [x] observability/diagnostics foundations

## Intelligence safety
- [x] adaptive memory planning
- [x] small fallback model path
- [x] resource-governed concurrency
- [x] model non-authority boundary
- [ ] fresh-machine low-RAM validation
- [ ] clean-machine model download/recovery validation
- [ ] thermal/resource stress validation

## Platform release
### macOS V1.1.x
- [x] downloadable local arm64 build
- [ ] Developer ID signing
- [ ] hardened runtime production verification
- [ ] notarization and stapling
- [ ] clean-machine Gatekeeper install
- [ ] update/uninstall verification

### Windows V1.2.x
- [x] native-host bootstrap launcher
- [ ] native Windows build
- [ ] signed installer/artifact
- [ ] SmartScreen clean-install test
- [ ] update/uninstall verification
- [ ] ThinkPad end-to-end test

### Linux V1.3.x
- [x] native-host bootstrap launcher
- [ ] native Linux artifact format selected
- [ ] native build on supported distro(s)
- [ ] artifact verification
- [ ] install/update/uninstall verification

## Website
- [x] account-free public site
- [x] platform-specific download routing
- [x] version labels
- [ ] production domain
- [ ] HTTPS deployment
- [ ] production artifact hosting
- [ ] download checksums
- [ ] production release notes
- [ ] accessibility/browser/mobile audit
- [ ] uptime/download monitoring

## Security
- [x] filesystem boundary
- [x] destructive-action safeguards
- [x] model non-authority
- [x] candidate isolation
- [x] release verification foundations
- [ ] external security review
- [ ] fresh-machine permission-denial tests
- [ ] prompt/tool injection adversarial suite
- [ ] crash/log secret-redaction audit

## Accounts and email
- [x] durable email outbox
- [x] verification/reset/change email paths
- [ ] production email provider
- [ ] sender identity
- [ ] SPF/DKIM/DMARC
- [ ] live delivery test

## Updates and recovery
- [x] release manifest infrastructure
- [x] update/rollback code
- [x] crash/restart recovery
- [ ] signed production update test
- [ ] interrupted-update test
- [ ] downgrade/rollback test on every platform

## Support and trust
- [x] privacy/terms/support pages
- [ ] production support channel
- [ ] diagnostic bundle workflow
- [ ] public known-issues page
- [ ] third-party license inventory
- [ ] final legal review

## Launch operations
- [ ] production backups
- [ ] rollback artifact
- [ ] monitoring
- [ ] release hashes recorded
- [ ] release manifest recorded
- [ ] incident procedure
- [ ] release owner/operator runbook
- [ ] final 45-gate run green except explicitly approved external blockers

## Hard blockers
A genuine public launch remains blocked while any of these are unresolved:
1. No production-signed/notarized macOS artifact.
2. No native tested Windows release artifact.
3. No native tested Linux release artifact.
4. No production hosting/domain for the public website and artifacts.
5. Transactional email has no configured production provider if account/email flows are enabled.
6. Fresh-machine end-to-end testing has not passed.
7. A critical launch gate is failing or its evidence is stale.

Never mark an external prerequisite green by simulation or placeholder credentials.
