# LUMO Master Mission — Autonomous Computing Operating System

## Mission

Build LUMO into a coherent autonomous computing operating system/control plane: a system where autonomous intelligence becomes reliable, scalable, composable computing. LUMO must operate on outcomes and intent rather than chats or individual model calls.

Canonical lifecycle:

**Intent → Mission → Planning → Work Graph → Assignment → Workforce → Resources → Execution → Coordination → Trust/Governance → Evidence/Verification → Recovery → Evolution**

This is an engineering mission, not a feature wishlist. Existing modules may be refactored or replaced when necessary.

## Six architectural planes

1. **Intelligence** — model routing, context, memory, reasoning, strategy, learning.
2. **Mission** — durable intent, contracts, objectives, dependencies, acceptance criteria.
3. **Execution** — universal actions, tools, computer control, browser, filesystem, code, applications.
4. **Coordination** — swarms, delegation, scheduling, concurrency, communication, synchronization.
5. **Trust/Governance** — identity, permissions, policy, budgets, approvals, audit, isolation.
6. **Evolution** — learning, workflow mining, self-improvement, evaluation, promotion, rollback.

## Non-negotiable laws

- Events are the source of truth; projections are rebuildable.
- Restart/replay must preserve mission semantics and durable progress.
- Concurrency is fundamental, not an optimization.
- Agents are dynamic configurations, not a fixed list of subclasses.
- Work must be verifiable; success cannot mean merely “the model stopped.”
- Important actions require provenance, policy evaluation, and evidence.
- High-risk computer/external actions require explicit authorization or an applicable durable policy.
- Fail closed rather than silently bypassing governance.
- Budgets and resource constraints are first-class runtime concerns.
- Existing tests are necessary but not sufficient; add integration, restart, failure, race, and real-world smoke coverage.
- Prefer fundamentally strong, robust, scalable, composable architecture over the smallest patch.
- Never weaken a test merely to make the suite green when the failure exposes a real architectural defect.

## Workforce

LUMO must support an elastic workforce containing:

- primary agents
- specialist agents
- swarm agents
- parallel agents
- persistent agents
- background agents
- queued agents
- routine agents
- ghost/latent agents
- shadow agents
- research, planning, critic, verifier, recovery, security, computer and operator configurations

Agents can dynamically spawn, delegate, communicate, specialize, inherit relevant context, become idle, retire, or be recovered. Swarms must support dynamic decomposition, fan-out/fan-in, voting/critique, speculative branches, and resource-aware scaling.

## Resource and budget plane

Every mission/execution should be able to carry budgets and observed consumption for:

- money/API spend
- elapsed time
- model/reasoning effort
- tool calls
- computer actions
- agent population
- concurrency
- storage/network resources where applicable

Scheduling should optimize the user's selected tradeoff among speed, reliability, quality, and cost. Budgets must be durable, auditable, enforceable, and visible in the UI.

## Cost Optimization Brain-Dump — cross-cutting expansion of the 167

Cost is a first-class optimization target alongside quality, reliability, latency, privacy, and safety. LUMO should continuously minimize total cost of ownership and per-mission cost without weakening verification, governance, isolation, or user outcomes. Optimize the full cost surface: model/API spend, compute, memory, storage, network, energy, devices, Worlds, tool calls, agent population, human attention, retries, failures, and operational overhead.

### Model/API spend
- Use deterministic/local computation before invoking a paid model.
- Route each subtask to the cheapest model that can satisfy its quality/risk contract.
- Use tiny/fast models for classification, extraction, routing, formatting, simple transforms, and routine checks.
- Escalate to stronger models only when uncertainty, complexity, consequence, or failed verification warrants it.
- Downgrade model size after repeated evidence that a cheaper model is sufficient for a task class.
- Cache model responses for identical deterministic inputs where privacy and freshness permit.
- Cache reusable reasoning artifacts: plans, decompositions, schemas, summaries, classifications, research findings, and strategy choices.
- Reuse completed objective results instead of asking a model to rediscover them.
- Reuse stable repository/file analysis across missions with invalidation on relevant changes.
- Reuse verified artifacts and evidence rather than regenerating them.
- Avoid sending unchanged context on every model call.
- Send only relevant slices of files, logs, screenshots, history, and state.
- Maintain compact rolling summaries instead of repeatedly transmitting full histories.
- Use hierarchical context: metadata first, relevant excerpts second, full source only on demand.
- Deduplicate semantically equivalent context before inference.
- Compress observations, logs, and screenshots before model transmission when fidelity permits.
- Prefer structured machine-readable state over prose descriptions.
- Use state diffs instead of full state snapshots when reasoning about incremental changes.
- Skip inference when deterministic state comparison already answers the question.
- Skip vision when accessibility/DOM/metadata is sufficient.
- Skip OCR when text is already available through accessibility or DOM extraction.
- Skip repeated screenshots when the state hash is unchanged and no action occurred.
- Batch compatible low-risk reasoning requests into one model call where it reduces overhead without reducing isolation.
- Batch independent extraction/classification work instead of making one call per item.
- Avoid agent-to-agent conversations that merely relay information already in durable state.
- Store canonical facts once and reference them by ID instead of copying them through every agent context.
- Prevent subagents from receiving irrelevant parent context.
- Cap context growth automatically.
- Stop generation as soon as the required structured output is complete.
- Enforce output-token budgets by task class.
- Predict expected token spend before expensive calls and reject or revise plans that exceed budget.
- Use adaptive reasoning depth rather than maximum reasoning for every task.
- Use early-exit criteria when confidence and evidence already satisfy the success contract.
- Do not replan after every minor event; replan only when the plan is stale, blocked, invalidated, or materially improved by new information.
- Avoid regenerating plans that are already durable and valid after restart.
- Do not rerun completed objectives unless their inputs or acceptance conditions changed.
- Do not repeat verification that is already cryptographically or deterministically sufficient.
- Use incremental verification after small changes instead of full verification when safe.
- Escalate from cheap verification to expensive verification only on ambiguity or failure.
- Use disagreement-triggered ensemble verification rather than always using multiple strong models.
- Use deterministic critics/checkers before model-based critics.

### Routing and workload economics
- Treat cost as a planning dimension, not an after-the-fact metric.
- Estimate cost for candidate plans before execution.
- Compare expected cost against expected quality, latency, risk, and recovery cost.
- Optimize expected total cost, including likely retries and failures—not just first-attempt cost.
- Prefer plans with fewer external calls when equivalent outcomes are provable.
- Prefer local execution when it is materially cheaper and meets the mission contract.
- Prefer existing user hardware over unnecessary cloud resources when economics and performance permit.
- Route workloads to idle/low-cost devices while respecting privacy and affinity constraints.
- Consolidate workloads to reduce infrastructure wakeups and setup overhead.
- Use workload-aware scheduling to avoid expensive resources for cheap tasks.
- Defer non-urgent work to lower-cost compute windows when the user permits.
- Use spot/preemptible infrastructure where appropriate and recoverable.
- Keep state portable so work can move between providers/devices when pricing changes.
- Maintain provider price/performance telemetry and use it in routing.
- Detect provider pricing or quota changes and adapt routing policies.
- Support BYOK/local-provider routing where economically appropriate.
- Use provider-specific batching, caching, and prompt-caching features when available.
- Avoid provider calls whose result can be obtained from local indexes, caches, event history, or durable artifacts.

### Agent/workforce cost
- Spawn agents only when parallelism, specialization, isolation, or reliability benefit justifies their cost.
- Prefer one capable agent over many redundant agents for small tasks.
- Dynamically scale swarm size to workload value and remaining budget.
- Scale down idle agents immediately.
- Reuse warm agents when cheaper than repeated initialization.
- Retire agents that repeatedly add no verified value.
- Use specialist agents only for tasks where specialization improves expected outcome enough to justify overhead.
- Use reputation/telemetry to avoid repeatedly assigning expensive work to low-yield agents.
- Prevent duplicate assignments through durable idempotency and task claiming.
- Use fan-out/fan-in only when the expected benefit exceeds coordination overhead.
- Avoid speculative branches when their expected information value is below their compute cost.
- Terminate losing speculative branches early when evidence makes them noncompetitive.
- Allocate larger budgets only to high-value or high-uncertainty branches.
- Learn which workflows are reliably solvable with fewer agents and encode those strategies.

### Tool, computer, browser, and World cost
- Minimize computer actions by choosing semantic actions over exploratory clicking.
- Prefer accessibility/DOM actions over screenshot-based interaction when equivalent.
- Reuse stable UI references rather than repeatedly rediscovering targets.
- Maintain an application/window state graph to avoid redundant navigation.
- Detect unchanged UI state and suppress repeated perception.
- Plan multi-step UI interactions before acting when safe, reducing observation/action round trips.
- Avoid opening or booting a World unless the mission actually requires isolation.
- Reuse an isolated World when policy allows instead of creating a new one for every task.
- Snapshot/restore Worlds instead of reinstalling or rebuilding them.
- Use lightweight World types for lightweight tasks.
- Destroy idle Worlds promptly to release compute/storage.
- Use copy-on-write Worlds to reduce disk usage.
- Deduplicate base images, dependencies, and cached packages.
- Avoid unnecessary browser restarts and repeated authentication flows.
- Reuse browser sessions only within strict security/identity boundaries.
- Cache safe static web resources and parsed page state when freshness permits.
- Avoid repeated downloads/uploads of unchanged artifacts.
- Use local file indexes and hashes to detect unchanged files before processing them.

### Storage, network, and data cost
- Deduplicate artifacts by content hash.
- Store large immutable blobs once and reference them by hash.
- Compress logs, traces, evidence, snapshots, and artifacts according to access/freshness requirements.
- Tier storage into hot, warm, cold, and archive classes.
- Compact event streams and snapshots without losing auditability.
- Retain detailed telemetry for short periods and durable summaries for longer periods.
- Apply configurable retention policies by data value, privacy class, and debugging need.
- Avoid transmitting data between devices when a local operation is sufficient.
- Compress remote payloads and stream only required fields.
- Use incremental synchronization rather than full-state transfer.
- Avoid repeated artifact replication across agents/devices.
- Garbage-collect orphaned Worlds, processes, files, caches, and temporary artifacts.
- Verify cleanup so leaked resources do not silently become recurring costs.

### Failure and recovery economics
- Treat retries as paid operations and include them in cost budgets.
- Use failure classification to avoid retrying non-retryable failures.
- Prefer cheap recovery actions before expensive replanning.
- Reuse checkpoints rather than restarting missions from scratch.
- Verify actual state after crashes so LUMO does not pay for duplicate work.
- Use idempotency to suppress duplicate execution after uncertain failures.
- Learn recovery strategies by failure category and measured cost/success.
- Prefer recovery paths with lower expected cost when verification remains equivalent.
- Set retry/replan budgets independently so one failure mode cannot consume the entire mission budget.
- Use circuit breakers to stop pathological cost explosions.
- Detect loops that burn model/tool/computer budgets without state progress.
- Quarantine degraded providers instead of repeatedly paying for failing calls.
- Preserve useful partial progress so later recovery does not repeat completed work.

### Energy and device economics
- Schedule non-urgent compute around battery, thermal, and power constraints.
- Prefer low-power local processing for simple tasks.
- Avoid keeping displays, GPUs, VMs, or devices awake solely for unnecessary polling.
- Batch background work to reduce repeated wake/sleep cycles.
- Use event-driven triggers instead of frequent polling.
- Measure energy/thermal cost where hardware telemetry permits.
- Treat power consumption as part of execution cost for long-running missions.
- Move workloads to better-powered devices when that reduces total energy/cost without violating policy.

### Cost intelligence and learning
- Record actual cost per mission, objective, plan, agent, model, capability, provider, device, and World.
- Track cost per verified outcome, not merely cost per call/token.
- Track cost of failed work and wasted work separately from productive work.
- Track cost avoided by caching, reuse, local execution, batching, and early exits.
- Build cost baselines for recurring mission templates.
- Detect cost regressions between LUMO versions.
- Automatically identify unusually expensive missions and explain the drivers.
- Learn the cheapest strategy that consistently satisfies each mission class.
- Maintain price/performance/reliability profiles for providers, models, devices, and capabilities.
- Use historical success and cost data to improve future plan selection.
- Run controlled cost experiments during self-improvement.
- Require cost regressions to be justified by measurable quality, reliability, latency, privacy, or safety gains.
- Add cost SLOs and budget alerts.
- Predict end-of-mission cost continuously and intervene before budget exhaustion.
- Give the user a clear breakdown of where money and compute went.
- Expose estimated cost before execution and actual verified cost afterward.

### Product/business cost
- Keep the core control plane lightweight and provider-agnostic.
- Prefer local-first architecture where it reduces recurring infrastructure spend.
- Avoid vendor lock-in that prevents cost-based routing.
- Make expensive infrastructure optional rather than mandatory for basic missions.
- Use autoscaling and scale-to-zero for remote services where practical.
- Separate latency-critical services from batch services so they can use different infrastructure economics.
- Pool shared caches and immutable resources safely across eligible missions/tenants.
- Meter infrastructure utilization so idle capacity is visible.
- Forecast capacity from mission demand instead of overprovisioning.
- Use feature flags to prevent unused expensive subsystems from running.
- Keep observability itself cost-aware: sample high-volume telemetry while retaining complete audit records for security-critical events.

### Cost-optimization brain-dump expansion: additional levers
- Use a two-stage budget gate: cheap deterministic estimate first, paid execution only after expected-value approval.
- Reserve a hard money ceiling plus a soft target; allow bounded underspend/overspend only through explicit policy.
- Maintain per-provider effective price, latency, failure rate, cacheability, and verification-success telemetry rather than using sticker price alone.
- Prefer models/providers with prompt caching, batch APIs, asynchronous pricing, or other lower-cost execution modes when latency permits.
- Use asynchronous/batch execution for non-urgent missions so LUMO can trade latency for lower unit cost.
- Coalesce identical or compatible requests arriving within a short scheduling window.
- Memoize deterministic tool outputs and capability discovery results with explicit freshness/invalidations.
- Build semantic result caches keyed by normalized intent, relevant state, policy, model/provider version, and freshness requirements.
- Use confidence-aware cache reuse; refresh stale or low-confidence results when acceptance criteria demand it.
- Use event-derived state and projections instead of recomputing state with a model.
- Prefer deterministic machinery—indexes, databases, hashes, parsers, ASTs, SQL, rules—before LLM inference.
- Compile recurring natural-language workflows into deterministic executable plans after they are learned and verified.
- Replace repeated model decisions with policy/rule/finite-state execution when the boundary becomes stable and auditable.
- Distill expensive successful workflows into cheaper specialist policies/models when evaluation proves equivalent outcomes.
- Use model cascades: tiny → medium → strong, escalating only on uncertainty or failed checks.
- Use verifier cascades: hash/schema/state check → deterministic test → cheap critic → strong independent verifier.
- Estimate value of information before requesting additional research, agents, screenshots, or model calls.
- Stop research when marginal expected information gain falls below marginal cost.
- Stop parallel exploration when remaining branches cannot change the decision or acceptance result.
- Size verification quorums from risk and disagreement instead of fixed ensemble counts.
- Adapt screenshot resolution and capture only relevant regions when safe.
- Reuse OCR/vision/accessibility results while source state is unchanged.
- Use perceptual hashes/state fingerprints to suppress redundant perception and model calls.
- Predict UI state transitions from recent history, then verify only changed state.
- Prefer application APIs, accessibility APIs, DOM, CLI, filesystem, or structured data over visual control when equivalent.
- Prefer one multi-operation capability call over many round trips when atomicity and verification remain sound.
- Use local indexes for browser research, files, code symbols, and prior evidence before network retrieval.
- Deduplicate concurrent network requests with shared safe caches.
- Use conditional requests, compression, streaming, delta transfers, and range requests for large remote artifacts.
- Share immutable World base images/dependency layers and use copy-on-write per World.
- Prewarm only resources whose measured reuse probability justifies idle cost; otherwise initialize lazily.
- Pool expensive resources only across missions sharing compatible isolation and identity boundaries.
- Add admission control so low-value work cannot consume scarce expensive resources.
- Use deadline slack to select cheaper slower providers without missing constraints.
- Schedule maintenance, indexing, compression, and learning during idle/cheap compute periods.
- Coalesce maintenance jobs and use incremental indexing/compilation.
- Cache deterministic build/test artifacts when source and environment hashes match.
- Run targeted tests first and escalate to full regression only when changed surface or risk warrants it.
- Cancel superseded CI/test jobs and duplicate work automatically.
- Track engineering cost per verified fix, not code volume.
- Measure total cost of ownership including operator time, incident recovery, support, storage, and migration.
- Attribute wasted spend to routing, excess context, redundant perception, duplicate work, failed tools, retries, idle resources, or over-verification.
- Detect cost cliffs, autoscaling thrash, cache stampedes, and runaway spend rates.
- Use hysteresis in autoscaling and single-flight request coalescing.
- Make cross-device handoff/data movement carry explicit cost so load balancing does not create hidden expense.
- Use energy-aware routing and event-driven wakeups instead of frequent polling.
- Adapt heartbeat intervals to risk/lease duration while preserving orphan detection guarantees.
- Tier telemetry/evidence storage and keep expensive detailed traces only as long as useful or required.
- Use negative caching for known deterministic failures where retries add no information.
- Add per-mission, per-account, per-provider, and global spend-rate limits.
- Forecast remaining mission cost continuously from burn rate and remaining graph work.
- Optimize checkpoint frequency by expected recovery cost rather than fixed intervals.
- Quantify verification cost and require expensive verification only when risk/uncertainty justifies it.
- Reuse proof-carrying artifacts/evidence across retries, audits, and downstream missions.
- Make human approvals durable, scoped, and reusable within their policy lifetime to reduce repeated attention cost.
- Batch approval requests when semantics permit, while never combining independently authorized actions merely for convenience.
- Learn safe autonomy boundaries for recurring low-risk workflows so unnecessary prompts decrease.
- Track interruption cost for shadow intelligence and optimize notifications for high-value interventions.
- Offer user-selectable execution tradeoffs such as cheapest-acceptable, balanced, and maximum-quality while preserving safety invariants.
- Show preflight estimates, largest cost drivers, alternatives, and postflight actual-versus-estimated spend.
- Track savings attributable to each optimization rather than assuming a change saved money.
- Run canary cost experiments before global rollout and automatically roll back regressions.
- Use Pareto-front planning across cost, quality, latency, reliability, privacy, and risk rather than cost-only optimization.
- Model the cost of being wrong: a cheap failed action can cost more than a slightly pricier correct action.
- Treat scarce GPU time, device availability, provider quotas, and human attention as resources with shadow prices.
- Forecast demand and pre-position resources only when startup savings exceed idle cost.
- Bound observability cardinality and sample traces by value/risk while retaining complete security-critical audit events.
- Prefer compact/columnar formats for high-volume telemetry where appropriate.
- Avoid unnecessary microservices when an in-process boundary preserves the same authority semantics at lower cost.
- Separate control-plane and data-plane scaling so cheap bookkeeping does not scale with expensive execution resources.
- Use scale-to-zero for optional remote components.
- Keep provider adapters thin and artifacts/checkpoints portable to reduce migration and recomputation costs.
- Minimize cloud egress by processing data near where it already resides when policy permits.
- Account for taxes, currency conversion, minimum charges, storage minimums, API reservation fees, and egress in provider comparisons.
- Detect free-tier/quota exhaustion before crossing into higher pricing bands.
- Split or batch workloads around favorable pricing tiers when this does not increase total cost or risk.
- Avoid provider switching when migration/setup overhead exceeds the price difference.
- Maintain an immutable cost ledger from intent → plan → assignment → provider/device → action → verification → outcome.
- Make every optimization explainable: expected savings, actual savings, quality impact, reliability impact, and rollback path.

### Meta-rule: optimize without weakening LUMO
- Never save money by bypassing authorization, isolation, verification, auditability, or the kill switch.
- Never choose a cheaper model merely because it is cheaper when the mission contract requires stronger capability.
- Every cost optimization should declare what it saves, what assumption makes it safe, and what evidence proves the outcome remains acceptable.
- Cost optimization should be reversible, measurable, continuously evaluated, and subject to regression tests.

## Speed and reliability

Optimize for time-to-useful-result through parallelism, model routing, caching, speculative execution, prefetching, specialization, and asynchronous/background operation.

## Speed Optimization Brain-Dump — cross-cutting expansion of the 167

Speed is a first-class optimization target alongside quality, reliability, cost, privacy, and safety. Optimize for **time-to-useful-verified-result**, not raw model latency. Every speed optimization must preserve authority, isolation, evidence, correctness, and kill semantics.

### Fast-path and runtime ideas
- Deterministic reflex path for obvious low-risk operations.
- Compile common mission patterns into executable plans.
- Keep hot control-plane state in memory while durable state remains authoritative.
- Move noncritical bookkeeping off critical paths.
- Return a durable mission/task ID immediately after accepted submission.
- Stream intermediate status and artifacts instead of waiting for completion.
- Avoid model calls for deterministic routing, policy, state lookup, and known workflows.
- Lazy-load expensive optional subsystems.
- Lazy-create agents, Worlds, browsers, model clients, and device connections.
- Warm only resources with measured reuse probability.
- Parallelize independent startup checks and defer noncritical diagnostics.

### Parallelism and scheduling
- Detect independent DAG branches automatically.
- Fan out immediately when dependencies are satisfied.
- Schedule critical-path work ahead of noncritical work.
- Use deadline slack and earliest-finish scheduling.
- Dynamically resize concurrency from queue depth, resource pressure, provider limits, and risk.
- Avoid over-parallelization when contention costs more than it saves.
- Use work stealing for uneven task durations.
- Keep related tasks on workers with useful warm state/cache affinity.
- Prioritize tasks blocking visible user outcomes.
- Deprioritize background work during interactive missions.
- Use bounded queues and backpressure before saturation.
- Speculate only when expected latency benefit exceeds wasted-work cost.
- Cancel losing speculative branches immediately when evidence makes them unnecessary.

### Model and inference latency
- Route simple work to fast models and hard work to stronger models only when needed.
- Stream model outputs when partial results are useful.
- Run deterministic preprocessing concurrently with inference.
- Prefetch likely next context while current execution runs.
- Cache prompt prefixes and reusable context when provider support permits.
- Minimize prompt serialization and context assembly.
- Use compact structured state instead of verbose prose.
- Adapt reasoning depth to uncertainty and task difficulty.
- Early-exit once the required structured result is complete.
- Cancel inference when acceptance is already satisfied.
- Use deadline-aware provider/model routing.
- Track p50/p95/p99 rather than averages and route around tail-latency degradation.
- Hedge pathological slow requests only when bounded by cost policy.
- Keep local models warm only when reuse beats memory/energy cost.
- Batch compatible inference for throughput-sensitive work.

### Computer and perception speed
- Prefer accessibility/DOM/API/CLI over screenshot vision when equivalent.
- Cache application/window metadata until relevant events change it.
- Capture only changed screen regions when safe.
- Use state hashes to skip identical observations.
- Reuse OCR/vision/accessibility results while source state is unchanged.
- Use low-resolution perception first and escalate only on ambiguity.
- Use region-of-interest vision before full-screen vision.
- Maintain application-specific UI strategies.
- Predict likely UI transitions from recent state history.
- Precompute candidate targets before action time.
- Reuse stable UI references while the state fingerprint remains valid.
- Batch safe observation requests.
- Replace exploratory clicking with semantic multi-action capabilities where safe.
- Verify after meaningful transitions instead of every harmless micro-step when the contract permits.
- Keep consequential actions serialized against fresh state.

### Browser and network speed
- Reuse safe browser sessions within identity/security boundaries.
- Parallelize independent retrieval.
- Reuse DNS/connections/sessions.
- Use conditional requests and local caches.
- Parse only relevant DOM regions.
- Avoid irrelevant page assets/downloads.
- Stream and range-request large resources.
- Deduplicate concurrent URL fetches.
- Cancel obsolete network requests.
- Route around slow/unhealthy endpoints.
- Use local indexes before network retrieval.

### Files, code, and test speed
- Use filesystem event watchers instead of repeated scans.
- Maintain incremental file/content indexes.
- Hash once and reuse hashes until modification.
- Parse only changed files and use AST/symbol indexes for targeted navigation.
- Incrementally rebuild affected modules.
- Cache dependency resolution and compiled artifacts by source/environment hash.
- Run targeted tests first and escalate to full regression when the changed surface or risk warrants it.
- Parallelize independent tests.
- Cache deterministic fixtures/environments safely.
- Cancel superseded builds and duplicate CI jobs.
- Use test-impact analysis to choose the smallest sufficient regression set.
- Keep fast smoke tests separate from deep reliability suites.

### Data, cache, and event-store speed
- Keep hot mission state in bounded caches with durable invalidation/versioning.
- Cache compiled policies, capability contracts, routing decisions, schemas, and provider health.
- Use single-flight loading to prevent cache stampedes.
- Precompute expensive projections and update indexes incrementally.
- Avoid copying large objects; pass durable IDs/references where safe.
- Use zero-copy/memory-mapped paths where beneficial.
- Batch event writes when latency semantics allow.
- Keep event writes sequential and index hot query fields.
- Avoid N+1 event/database lookups.
- Maintain materialized mission-status views.
- Keep transactions short and use optimistic concurrency where conflict is low.
- Move analytics off the operational database.

### Human-perceived speed
- Immediate acknowledgement plus live progress.
- Predict completion time from telemetry.
- Keep interactive commands on a high-priority lane.
- Let background missions continue while the UI remains responsive.
- Preload likely UI views and preserve state across navigation.
- Batch nonurgent notifications.
- Surface blocking reasons instead of appearing frozen.

### Tail latency and cancellation
- Propagate deadlines through every child task.
- Propagate cancellation through the entire execution tree.
- Cancel children when parents are cancelled or deadlines expire.
- Use circuit breakers for slow dependencies, not only failures.
- Add jitter to recurring background work to prevent thundering herds.
- Adapt polling intervals and replace polling with events where possible.
- Detect resource starvation before it becomes user-visible.

### Faster recovery and verification
- Optimize checkpoint frequency by expected recovery cost.
- Persist enough state to resume without unnecessary replanning.
- Verify actual World/application state immediately after restart.
- Prefer deterministic recovery before model diagnosis.
- Keep recovery strategies indexed by failure class.
- Parallelize independent recovery diagnostics.
- Verify using the cheapest sufficient evidence first.
- Use hashes/schema/state checks before model critics.
- Reuse immutable proof/evidence with provenance.
- Run independent verifiers in parallel when safe.
- Precompute acceptance predicates.
- Escalate verification cost only when risk/uncertainty requires it.

### Development and evolution speed
- Identify the smallest affected subsystem from diffs.
- Generate focused regression tests before full-suite execution.
- Run static analysis concurrently with tests.
- Automatically detect disconnected primitives and unused integrations.
- Benchmark before/after major optimizations.
- Keep performance budgets as regression tests.
- Canary new execution strategies before broad rollout.
- Automatically revert measured performance regressions.

### Latency-aware planning
- Optimize expected time × cost, not either metric alone.
- Prefer slower cheaper compute when deadline slack exists.
- Prefer faster compute when waiting has meaningful user cost.
- Include provider queueing/startup time in routing.
- Include human waiting time in mission planning.
- Learn per-mission-class latency/cost Pareto frontiers.
- Use historical performance telemetry for plan selection.

### Meta-rule: speed without weakening LUMO
- Never remove verification, authorization, isolation, auditability, or kill guarantees for speed.
- Never parallelize unsafe shared mutable state without synchronization.
- Never speculate on consequential actions merely to reduce latency.
- Every speed optimization needs a measurable latency target, correctness invariant, and regression test.
- Optimize **time-to-verified-useful-result**, not time until LUMO merely claims completion.

Reliability requires deterministic lifecycle transitions, leases, durable checkpoints, idempotency, retries, failure classification, recovery, verification, and explicit escalation. Track operational reliability metrics and agent/workflow reputation.

## Whole-computer autonomy

With explicit authorization, LUMO should be capable of operating the user's laptop as a governed execution environment: desktop GUI, browser, terminal, filesystem, documents, code, CAD, graphics/creative applications, communication applications, and other installed software.

The universal action model should capture actor, capability, target, parameters, authorization, expected effect, actual effect, cost, reversibility, evidence, and outcome.

Computer automation must support screenshot/vision loops, mouse/keyboard interaction, application launching, browser workflows, file operations, artifact creation, verification, cancellation, timeout, recovery, and durable task history.

## Full automation / operator mode

LUMO should support authorized persistent automation for routine work such as inbox triage, routine email drafting/sending under policy, recurring reports, file organization, monitoring, research checks, administrative workflows, project maintenance, and scheduled missions.

The user should specify outcomes and policies; LUMO should plan and execute the workflow, report what happened, and escalate ambiguity or policy-sensitive decisions.

## Shadow intelligence

Support one or a small number of persistent shadow agents that follow authorized user context and provide active support without requiring constant prompting.

Shadow intelligence should reason over current application/context, active missions, artifacts, deadlines, known preferences, pending work, and operational state. It should decide among observe, ignore, suggest, ask, or act according to policy and interruption preferences.

Privacy is explicit: the user controls what is observable, memorable, actionable, and interruptible.

## Agent POV and observability

Every important agent should expose an operational POV without exposing hidden chain-of-thought:

- current observation/context
- current mission/objective
- current plan step
- action being considered
- action executed
- result
- uncertainty/confidence metadata
- policy/governance status
- evidence
- resource consumption
- failures/recovery

The UI should let the user follow individual agents, swarm topology, inter-agent communication, mission graph, computer screen/evidence, resources, logs, and durable history in real time.

## Mission intelligence

Missions are durable outcome contracts. Plans are living graphs rather than static lists. Nodes may split, merge, retry, become blocked, be superseded, or trigger new missions.

Support:

- dynamic replanning
- speculative execution
- counterfactual/critic agents
- A/B strategy evaluation
- mission blueprints / “mission DNA”
- learned workflows
- demonstration-to-automation
- intent compilation into executable missions

## Governance

Support layered control:

- observe-only
- suggest
- ask-before-action
- autonomous-within-policy
- explicitly authorized autonomy

Users can control capabilities, missions, agents, budgets, interruption policy, external communication, destructive operations, and computer control. Support a durable personal policy/constitution that compiles into enforceable runtime rules.

Before consequential actions, LUMO should be able to reason about likely consequences and present an approval request when required.

## Evidence and verification

Important outcomes must have evidence. Verification should be an independent concern and may inspect:

- screenshots
- files/artifacts
- hashes
- test results
- application state
- API responses
- external confirmations
- user-defined acceptance criteria

Use `action → result → evidence → verification → confidence`, not `action → hope`.

## Self-healing and evolution

LUMO should monitor itself and authorized workflows for failures/degradation. Where policy allows:

**detect → diagnose → repair → test → verify → restore → report**

Self-improvement must remain isolated, governed, tested, journaled, promotable, and rollback-capable. Candidate workspaces must not provide filesystem/symlink escape paths. Prefer governed execution/sandboxing for autonomous candidate code.

Agents and workflows should accumulate reusable knowledge and strategy statistics. Successful strategies can evolve into specialized configurations.

## Product/UI

The dashboard should feel like mission control for an autonomous operating system, not a chat wrapper. It should expose:

- global command/intent entry
- mission graph and status
- swarm/workforce topology
- live agent activity
- Agent POV
- computer-control console and screenshots
- evidence/artifacts
- resource/budget usage
- speed/reliability metrics
- approvals/governance
- scheduled/routine missions
- shadow-agent status
- event timeline/audit
- failures/recovery
- system health
- task history
- capability and policy settings

The UI must consume real APIs/state; do not fabricate live status.

## Ecosystem / platform

Design LUMO so capabilities and mission modules can become composable packages with declared inputs, outputs, capabilities, permissions, budgets, verification requirements, cost, and reliability. A future ecosystem should let developers add capabilities without hard-coding them into the core mission engine.

## Outside-the-box invention mandate

Do not stop at the features explicitly listed here. Continuously ask what primitives a computer operating system designed around autonomous intelligence would need. Explore and implement strong ideas such as:

- intent compiler
- digital twin of the user's computing environment
- latent/ghost intelligence
- agent economy/resource market
- dynamic intelligence scaling
- speculative mission execution
- workflow mining
- demonstration-to-automation
- mission DNA
- agent reputation
- autonomous attention management
- agent immune system / anomaly quarantine
- predictive governance / consequence preview
- reversible autonomy with checkpoints
- strategy evolution and specialization emergence
- privacy-preserving collective learning
- capability/mission package ecosystem

New abstractions are encouraged when they materially improve the system and fit the architecture. Do not add novelty merely for novelty; every invention must improve capability, reliability, controllability, scalability, or user value.

## Runtime cognition architecture

LUMO's intelligence loop is explicitly optimized for both speed and intelligence:

**Observe → World Model → Cognitive Router → Plan/Select → Govern → Act → Observe Delta → Verify → Learn**

The cognitive router uses a fast reflex/tactical path for clear low-risk work and escalates to strategic/critical reasoning when complexity, uncertainty, failure, or consequence warrants it. Consequential GUI actions are serialized against fresh observations; planning and perception may run concurrently when safe. Vision coordinates are normalized from captured-window pixels into global host coordinates so perception and actuation share one coordinate frame.

## Release-completeness contract

A subsystem is considered complete only when its state is durable where required, its authority boundaries are enforceable, its failure/recovery behavior is explicit, its API/CLI surface is real, its user-facing status is observable, and its behavior is covered by deterministic tests plus host smoke tests where applicable.

## Execution protocol

1. Inspect the current repository and architecture before modifying it.
2. Map existing capabilities to this mission.
3. Identify the highest-value architectural gaps.
4. Implement coherent primitives before superficial UI features.
5. Integrate every new primitive end-to-end.
6. Add tests at unit, integration, restart/replay, concurrency, failure, API, and UI levels.
7. Run real capability smoke tests wherever the host permits.
8. Re-audit for TODOs, stubs, fake live behavior, in-memory state that should be durable, governance bypasses, races, and disconnected UI.
9. Fix the discovered gaps rather than documenting them as acceptable when they are actually unfinished.
10. Repeat until remaining limitations are genuine external constraints, not unfinished engineering.

## Definition of FULL LUMO

FULL LUMO is not “all current tests pass.” It means the repository behaves as one coherent autonomous computing system whose user intent can travel through durable mission state, dynamic planning, an elastic workforce, governed resources, real execution, evidence/verification, recovery, and evolution.

A release candidate must have:

- clean repository
- complete automated test suite
- real API and CLI
- durable event/replay semantics
- restart recovery
- robust concurrency
- governed resource/budget accounting
- swarm and persistent/background/routine/ghost/shadow modes
- authorized whole-computer execution
- routine/full-automation workflows
- evidence and verification
- agent POV and operational observability
- exceptional control-plane UI
- secure governance and approval paths
- self-healing/evolution foundations
- installable package and clean-room validation
- documentation matching implementation

**Do not stop merely because the existing backlog is complete. Do not stop at “good enough.” Continue until the strongest practical version of this mission has been implemented, integrated, tested, audited, and released.**
