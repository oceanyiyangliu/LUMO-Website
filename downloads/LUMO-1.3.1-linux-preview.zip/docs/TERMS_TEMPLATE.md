# LUMO Terms of Service — Launch Draft

**Draft for legal review; not a final contract.**

This document should be completed with the legal operating entity, jurisdiction, effective date, support contact, subscription terms, refund rules, limitation of liability, acceptable-use incorporation, dispute terms, and age/eligibility requirements before publication.

Users are responsible for the instructions they give LUMO and for credentials and third-party services they connect. LUMO may restrict or stop execution when safety, authorization, entitlement, provider, or system-integrity controls require it.

If subscriptions are offered, the final terms must state price, billing interval, renewal, cancellation, refunds, taxes, failed-payment handling, downgrades, and applicable regional consumer rights.
