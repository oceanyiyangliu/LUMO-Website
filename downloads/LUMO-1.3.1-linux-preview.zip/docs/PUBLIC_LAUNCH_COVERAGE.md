# LUMO Public Launch Coverage

This matrix separates **implemented/automated evidence** from **external release prerequisites** and **manual validation**. A green local test never substitutes for an external prerequisite.

| Area | Local evidence | External/manual gate |
|---|---|---|
| Website | Next production build | Domain + deployment + public download test |
| Mac distribution | Release builder + manifest tooling | Developer ID, notarization, Gatekeeper clean-Mac test |
| Accounts | Auth/session tests | Production DB, email delivery, real signup/reset E2E |
| Backend | Production config contract | HTTPS, secrets, hosting, monitoring, alerts |
| Local AI | Governor/model/resource tests | Fresh-machine RAM/model failure matrix |
| Work | Durable/concurrency/recovery tests | Human fresh-user workflow |
| Conversation | UI build/typecheck + chat tests | Usability observation |
| Active Assistant | Permission/backend tests | Real permission/restart/latency validation |
| Computer control | Authorization/permission tests | Real permission grant/deny/revoke matrix |
| Memory | Persistence/isolation tests | Backup/restore + user-control validation |
| Root | Root telemetry/control tests | Production auth/authorization + fleet/release/incident drill |
| Updates | Release/update/rollback tests | Signed public artifact + upgrade/rollback on clean Mac |
| Windows/Linux | Platform architecture tests | Native installers and clean-machine validation |
| Safety | 45-surface launch gate | Crash/forced-quit/network/model failure drills |
| Feedback | Usage + feedback API/UI | Production telemetry and support response |
| Backup | Backup/restore tests | Real restore drill and migration validation |
| Privacy/security | Policy/config/security tests | Legal review + dependency/security review |
| Support | Support surface exists | Real contact/diagnostics intake |
| Operations | Production monitor/config contract | Live alert + incident + emergency shutdown drill |
| Legal | Draft public pages | Final legal review and published contact/license details |
| Product polish | UI build/typecheck | Fresh-user walkthrough; no debug/placeholder content |
| Release | Fail-closed audit + release scripts | Code freeze → sign → notarize → publish → clean install |

## Release rule

A release is public only when every applicable external gate has evidence. Mac-first is valid; Windows/Linux must remain explicitly unsupported until their native release gates pass.
