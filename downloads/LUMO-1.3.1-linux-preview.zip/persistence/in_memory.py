from __future__ import annotations

from contextlib import contextmanager
from threading import RLock
from typing import Dict, Generic, Hashable, Iterable, Optional, TypeVar

from .repository import Repository

T = TypeVar("T")


class InMemoryRepository(Repository[T], Generic[T]):
    def __init__(self) -> None:
        self._items: Dict[str, T] = {}
        self._admission_index: Dict[Hashable, str] = {}
        self._lock = RLock()

    def save(self, entity: T) -> T:
        entity_id = getattr(entity, "id")
        with self._lock:
            self._items[entity_id] = entity
        return entity

    def get(self, entity_id: str) -> Optional[T]:
        with self._lock:
            return self._items.get(entity_id)

    def delete(self, entity_id: str) -> bool:
        with self._lock:
            if entity_id not in self._items:
                return False
            del self._items[entity_id]
            for key, indexed_id in list(self._admission_index.items()):
                if indexed_id == entity_id:
                    del self._admission_index[key]
            return True

    def list(self) -> Iterable[T]:
        with self._lock:
            return list(self._items.values())

    @contextmanager
    def transaction(self):
        """Run repository operations atomically with rollback on failure."""
        with self._lock:
            items_snapshot = dict(self._items)
            admission_snapshot = dict(self._admission_index)
            try:
                yield
            except Exception:
                self._items = items_snapshot
                self._admission_index = admission_snapshot
                raise

    def admit(self, key: Hashable, entity: T) -> tuple[T, bool]:
        """Atomically admit one entity for an idempotency key."""
        with self._lock:
            existing_id = self._admission_index.get(key)
            if existing_id is not None:
                existing = self._items.get(existing_id)
                if existing is not None:
                    return existing, False
                del self._admission_index[key]
            entity_id = getattr(entity, "id")
            if entity_id in self._items:
                raise ValueError(f"cannot admit entity with existing id: {entity_id!r}")
            self._items[entity_id] = entity
            self._admission_index[key] = entity_id
            return entity, True
