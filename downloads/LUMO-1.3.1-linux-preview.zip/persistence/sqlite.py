from __future__ import annotations

from contextlib import contextmanager
import json
import re
import sqlite3
from threading import RLock
from typing import Callable, Generic, Iterable, Optional, TypeVar

# Keep live connection objects as keys rather than ``id(connection)``.
# Python may reuse object IDs after a connection is garbage-collected; using the
# integer ID here can make a brand-new SQLite connection inherit another
# connection's lock/transaction state. sqlite3.Connection is hashable by
# identity, so retaining the object itself also keeps the bookkeeping correct.
_CONNECTION_LOCKS: dict[object, RLock] = {}
_MANAGED_CONNECTIONS: set[object] = set()
_AFTER_COMMIT_CALLBACKS: dict[object, list[callable]] = {}

from .repository import Repository
from .serializer import Serializer

T = TypeVar("T")


class SQLiteRepository(Repository[T], Generic[T]):

    def __init__(
        self,
        connection: sqlite3.Connection,
        serializer: Serializer[T],
        table_name: str,
        storage_encoder: Callable[[dict], str] | None = None,
        storage_decoder: Callable[[str], dict] | None = None,
    ) -> None:
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", table_name):
            raise ValueError(f"invalid table name: {table_name!r}")

        self._connection = connection
        self._serializer = serializer
        self._table_name = table_name
        self._lock = _CONNECTION_LOCKS.setdefault(connection, RLock())
        self._storage_encoder = storage_encoder or (lambda data: json.dumps(data))
        self._storage_decoder = storage_decoder or (lambda raw: json.loads(raw))
        with self._lock:
            self._connection.execute("PRAGMA busy_timeout = 30000")
            self._connection.execute("PRAGMA journal_mode = WAL")
            self._connection.execute("PRAGMA synchronous = NORMAL")
            self._create_table()

    def _create_table(self) -> None:
        self._connection.execute(
            f"""
            CREATE TABLE IF NOT EXISTS "{self._table_name}" (
                id TEXT PRIMARY KEY,
                data TEXT NOT NULL
            )
            """
        )
        self._connection.commit()

    def save(self, entity: T) -> T:
        with self._lock:
            return self._save_locked(entity)

    def _save_locked(self, entity: T) -> T:
        data = self._serializer.serialize(entity)
        entity_id = data["id"]

        self._connection.execute(
            f"""
            INSERT INTO "{self._table_name}" (id, data)
            VALUES (?, ?)
            ON CONFLICT(id) DO UPDATE SET data = excluded.data
            """,
            (
                entity_id,
                self._storage_encoder(data),
            ),
        )
        if self._connection not in _MANAGED_CONNECTIONS:
            self._connection.commit()
        return entity

    def after_commit(self, callback) -> None:
        """Run a callback only after the current connection transaction commits.

        This is deliberately connection-scoped rather than repository-scoped:
        UnitOfWork may open the transaction through a different repository on
        the same SQLite connection. Deferred event delivery therefore cannot
        accidentally observe or act on rolled-back state.
        """
        conn_id = self._connection
        with self._lock:
            if conn_id in _MANAGED_CONNECTIONS:
                _AFTER_COMMIT_CALLBACKS.setdefault(conn_id, []).append(callback)
                return
        callback()

    @contextmanager
    def transaction(self):
        """Execute repository operations inside the connection transaction."""
        callbacks: list[callable] = []
        with self._lock:
            conn_id = self._connection
            outermost = conn_id not in _MANAGED_CONNECTIONS
            if outermost:
                self._connection.execute("BEGIN")
                _MANAGED_CONNECTIONS.add(conn_id)
            try:
                yield
            except Exception:
                if outermost:
                    self._connection.rollback()
                    _AFTER_COMMIT_CALLBACKS.pop(conn_id, None)
                raise
            else:
                if outermost:
                    self._connection.commit()
                    callbacks = _AFTER_COMMIT_CALLBACKS.pop(conn_id, [])
            finally:
                if outermost:
                    _MANAGED_CONNECTIONS.discard(conn_id)

        # Delivery occurs after the commit and after releasing the DB lock.
        # Handler failures cannot retroactively turn a committed transaction
        # into a rollback. Durable DeliveryCoordinator remains the retryable
        # path for subscribers that require at-least-once processing.
        for callback in callbacks:
            callback()

    def checkpoint(self, mode: str = "PASSIVE") -> tuple[int, int, int]:
        """Run an explicit WAL checkpoint and return SQLite checkpoint stats."""
        allowed={"PASSIVE","FULL","RESTART","TRUNCATE"}
        mode=str(mode).upper()
        if mode not in allowed:
            raise ValueError(f"unsupported WAL checkpoint mode: {mode!r}")
        with self._lock:
            row=self._connection.execute(f"PRAGMA wal_checkpoint({mode})").fetchone()
        return tuple(int(x) for x in row)

    def get(self, entity_id: str) -> Optional[T]:
        with self._lock:
            return self._get_locked(entity_id)

    def _get_locked(self, entity_id: str) -> Optional[T]:
        row = self._connection.execute(
            f'SELECT data FROM "{self._table_name}" WHERE id = ?',
            (entity_id,),
        ).fetchone()

        if row is None:
            return None

        return self._serializer.deserialize(self._storage_decoder(row[0]))

    def delete(self, entity_id: str) -> bool:
        with self._lock:
            return self._delete_locked(entity_id)

    def _delete_locked(self, entity_id: str) -> bool:
        cursor = self._connection.execute(
            f'DELETE FROM "{self._table_name}" WHERE id = ?',
            (entity_id,),
        )
        if self._connection not in _MANAGED_CONNECTIONS:
            self._connection.commit()
        return cursor.rowcount > 0

    def list(self) -> Iterable[T]:
        with self._lock:
            return self._list_locked()

    def _list_locked(self) -> Iterable[T]:
        rows = self._connection.execute(
            f'SELECT data FROM "{self._table_name}" ORDER BY id'
        ).fetchall()

        return [
            self._serializer.deserialize(self._storage_decoder(row[0]))
            for row in rows
        ]

    def list_insertion_order(self) -> Iterable[T]:
        with self._lock:
            return self._list_insertion_order_locked()

    def _list_insertion_order_locked(self) -> Iterable[T]:
        rows = self._connection.execute(
            f'SELECT data FROM "{self._table_name}" ORDER BY rowid'
        ).fetchall()

        return [
            self._serializer.deserialize(self._storage_decoder(row[0]))
            for row in rows
        ]
