from __future__ import annotations

from datetime import datetime
from typing import Any

from ocean.domain.agent import Agent
from persistence.serializer import Serializer
from ocean.domain.enums import AgentStatus


class AgentSerializer(Serializer[Agent]):
    """Serialize and deserialize Agent domain entities."""

    def serialize(self, entity: Agent) -> dict[str, Any]:
        return {
            "id": entity.id,
            "name": entity.name,
            "role": entity.role,
            "capabilities": sorted(entity.capabilities),
            "metadata": dict(entity.metadata),
            "status": entity.status.value,
            "current_task_id": entity.current_task_id,
            "created_at": entity.created_at.isoformat(),
            "updated_at": entity.updated_at.isoformat(),
        }

    def deserialize(self, data: dict[str, Any]) -> Agent:
        return Agent(
            name=str(data["name"]),
            role=str(data["role"]),
            capabilities=set(data.get("capabilities", [])),
            metadata=dict(data.get("metadata", {})),
            id=str(data["id"]),
            status=AgentStatus(data["status"]),
            current_task_id=data.get("current_task_id"),
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"]),
        )
