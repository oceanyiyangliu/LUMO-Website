from __future__ import annotations

from datetime import datetime
from typing import Any

from persistence.serializer import Serializer

from ocean.domain.enums import AssigneeType, TaskStatus
from ocean.domain.task import Task, TaskTransitionRecord

class TaskSerializer(Serializer[Task]):
    """Serialize and deserialize Task domain entities."""

    def serialize(self, entity: Task) -> dict[str, Any]:
        return {
            "id": entity.id,
            "title": entity.title,
            "description": entity.description,
            "mission_id": entity.mission_id,
            "depends_on": sorted(entity.depends_on),
            "assignee_type": entity.assignee_type.value,
            "assignee_id": entity.assignee_id,
            "metadata": dict(entity.metadata),
            "status": entity.status.value,
            "result": entity.result,
            "verification_id": entity.verification_id,
            "history": [
                {
                    "from_status": (
                        record.from_status.value
                        if record.from_status is not None
                        else None
                    ),
                    "to_status": record.to_status.value,
                    "at": record.at.isoformat(),
                    "reason": record.reason,
                }
                for record in entity.history
            ],
            "created_at": entity.created_at.isoformat(),
            "updated_at": entity.updated_at.isoformat(),
        }

    def deserialize(self, data: dict[str, Any]) -> Task:
        history = [
            TaskTransitionRecord(
                from_status=(
                    TaskStatus(item["from_status"])
                    if item["from_status"] is not None
                    else None
                ),
                to_status=TaskStatus(item["to_status"]),
                at=datetime.fromisoformat(item["at"]),
                reason=item.get("reason"),
            )
            for item in data.get("history", [])
        ]

        return Task(
            title=str(data["title"]),
            description=str(data.get("description", "")),
            mission_id=data.get("mission_id"),
            depends_on=set(data.get("depends_on", [])),
            assignee_type=AssigneeType(data["assignee_type"]),
            assignee_id=data.get("assignee_id"),
            metadata=dict(data.get("metadata", {})),
            id=str(data["id"]),
            status=TaskStatus(data["status"]),
            result=data.get("result"),
            verification_id=data.get("verification_id"),
            history=history,
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"]),
        )
