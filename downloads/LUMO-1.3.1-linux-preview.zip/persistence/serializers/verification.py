from __future__ import annotations

from datetime import datetime
from typing import Any

from ocean.domain.verification import Verification
from persistence.serializer import Serializer


class VerificationSerializer(Serializer[Verification]):
    """Serialize and deserialize Verification domain entities."""

    def serialize(self, entity: Verification) -> dict[str, Any]:
        return {
            "id": entity.id,
            "task_id": entity.task_id,
            "method": entity.method,
            "passed": entity.passed,
            "evidence": list(entity.evidence),
            "execution_id": entity.execution_id,
            "at": entity.at.isoformat(),
        }

    def deserialize(self, data: dict[str, Any]) -> Verification:
        return Verification(
            task_id=str(data["task_id"]),
            method=str(data["method"]),
            passed=bool(data["passed"]),
            evidence=list(data.get("evidence", [])),
            execution_id=data.get("execution_id"),
            id=str(data["id"]),
            at=datetime.fromisoformat(data["at"]),
        )
