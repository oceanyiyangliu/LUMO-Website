from __future__ import annotations

from typing import Any

from ocean.domain.resource import ResourceRequirement
from persistence.serializer import Serializer


class ResourceRequirementSerializer(Serializer[ResourceRequirement]):
    """Serialize and deserialize ResourceRequirement value objects."""

    def serialize(self, entity: ResourceRequirement) -> dict[str, Any]:
        return {
            "kind": entity.kind,
            "amount": entity.amount,
        }

    def deserialize(self, data: dict[str, Any]) -> ResourceRequirement:
        return ResourceRequirement(
            kind=str(data["kind"]),
            amount=float(data.get("amount", 1.0)),
        )
