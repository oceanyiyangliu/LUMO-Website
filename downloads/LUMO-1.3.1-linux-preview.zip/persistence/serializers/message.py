from __future__ import annotations

from datetime import datetime
from typing import Any

from ocean.domain.message import Message
from persistence.serializer import Serializer


class MessageSerializer(Serializer[Message]):
    """Serialize and deserialize Message domain entities."""

    def serialize(self, entity: Message) -> dict[str, Any]:
        return {
            "id": entity.id,
            "sender_id": entity.sender_id,
            "recipient_id": entity.recipient_id,
            "type": entity.type,
            "payload": dict(entity.payload),
            "correlation_id": entity.correlation_id,
            "at": entity.at.isoformat(),
        }

    def deserialize(self, data: dict[str, Any]) -> Message:
        return Message(
            sender_id=str(data["sender_id"]),
            recipient_id=str(data["recipient_id"]),
            type=str(data["type"]),
            payload=dict(data.get("payload", {})),
            correlation_id=data.get("correlation_id"),
            id=str(data["id"]),
            at=datetime.fromisoformat(data["at"]),
        )
