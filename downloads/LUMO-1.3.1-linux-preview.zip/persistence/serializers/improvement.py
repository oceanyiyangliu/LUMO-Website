from __future__ import annotations

from typing import Any

from ocean.self_improvement.types import (
    ImprovementEvaluation,
    ImprovementRun,
    ImprovementStatus,
)
from persistence.serializer import Serializer


class ImprovementRunSerializer(Serializer[ImprovementRun]):
    """Serialize and deserialize autonomous improvement runs."""

    def serialize(self, entity: ImprovementRun) -> dict[str, Any]:
        evaluation = None

        if entity.evaluation is not None:
            evaluation = {
                "candidate_id": entity.evaluation.candidate_id,
                "passed": entity.evaluation.passed,
                "score": entity.evaluation.score,
                "evidence": list(entity.evaluation.evidence),
                "metrics": dict(entity.evaluation.metrics),
                "reason": entity.evaluation.reason,
            }

        return {
            "id": entity.id,
            "mission_id": entity.mission_id,
            "candidate_id": entity.candidate_id,
            "status": entity.status.value,
            "evaluation": evaluation,
            "promoted_plan_revision_id": entity.promoted_plan_revision_id,
            "metadata": dict(entity.metadata),
        }

    def deserialize(self, data: dict[str, Any]) -> ImprovementRun:
        evaluation_data = data.get("evaluation")
        evaluation = None

        if evaluation_data is not None:
            evaluation = ImprovementEvaluation(
                candidate_id=str(evaluation_data["candidate_id"]),
                passed=bool(evaluation_data["passed"]),
                score=float(evaluation_data["score"]),
                evidence=tuple(evaluation_data.get("evidence", [])),
                metrics={
                    str(key): float(value)
                    for key, value in dict(
                        evaluation_data.get("metrics", {})
                    ).items()
                },
                reason=evaluation_data.get("reason"),
            )

        return ImprovementRun(
            id=str(data["id"]),
            mission_id=str(data["mission_id"]),
            candidate_id=str(data["candidate_id"]),
            status=ImprovementStatus(data["status"]),
            evaluation=evaluation,
            promoted_plan_revision_id=data.get("promoted_plan_revision_id"),
            metadata=dict(data.get("metadata", {})),
        )
