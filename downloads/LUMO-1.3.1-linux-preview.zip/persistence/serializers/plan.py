from __future__ import annotations

from datetime import datetime
from typing import Any

from ocean.domain.plan import PlanRevision, PlanStatus
from persistence.serializer import Serializer


class PlanRevisionSerializer(Serializer[PlanRevision]):
    """Serialize and deserialize immutable plan revisions."""

    def serialize(self, entity: PlanRevision) -> dict[str, Any]:
        return {
            "id": entity.id,
            "mission_id": entity.mission_id,
            "revision": entity.revision,
            "decision_id": entity.decision_id,
            "graph_id": entity.graph_id,
            "parent_revision_id": entity.parent_revision_id,
            "status": entity.status.value,
            "reason": entity.reason,
            "metadata": dict(entity.metadata),
            "created_at": entity.created_at.isoformat(),
        }

    def deserialize(self, data: dict[str, Any]) -> PlanRevision:
        return PlanRevision(
            mission_id=str(data["mission_id"]),
            revision=int(data["revision"]),
            decision_id=str(data["decision_id"]),
            graph_id=str(data["graph_id"]),
            parent_revision_id=data.get("parent_revision_id"),
            status=PlanStatus(data.get("status", PlanStatus.DRAFT.value)),
            reason=data.get("reason"),
            metadata=dict(data.get("metadata", {})),
            id=str(data["id"]),
            created_at=datetime.fromisoformat(data["created_at"]),
        )
