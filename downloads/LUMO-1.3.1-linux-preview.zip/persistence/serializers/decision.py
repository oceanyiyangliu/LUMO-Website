from __future__ import annotations

from datetime import datetime
from typing import Any

from ocean.domain.decision import Decision
from persistence.serializer import Serializer


class DecisionSerializer(Serializer[Decision]):
    """Serialize and deserialize immutable planning decisions."""

    def serialize(self, entity: Decision) -> dict[str, Any]:
        return {
            "id": entity.id,
            "mission_id": entity.mission_id,
            "kind": entity.kind,
            "objective": entity.objective,
            "rationale": entity.rationale,
            "alternatives": list(entity.alternatives),
            "selected_option": entity.selected_option,
            "confidence": entity.confidence,
            "evidence": list(entity.evidence),
            "metadata": dict(entity.metadata),
            "created_at": entity.created_at.isoformat(),
        }

    def deserialize(self, data: dict[str, Any]) -> Decision:
        return Decision(
            mission_id=str(data["mission_id"]),
            kind=str(data["kind"]),
            objective=str(data["objective"]),
            rationale=str(data["rationale"]),
            alternatives=tuple(data.get("alternatives", [])),
            selected_option=data.get("selected_option"),
            confidence=(
                float(data["confidence"])
                if data.get("confidence") is not None
                else None
            ),
            evidence=tuple(data.get("evidence", [])),
            metadata=dict(data.get("metadata", {})),
            id=str(data["id"]),
            created_at=datetime.fromisoformat(data["created_at"]),
        )
