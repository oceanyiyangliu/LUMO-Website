from __future__ import annotations

from datetime import datetime
from typing import Any

from persistence.serializer import Serializer
from persistence.serializers.execution_request import ExecutionRequestSerializer

from ocean.temporal.types import (
    MissedSchedulePolicy,
    TemporalRecurrence,
    TemporalSchedule,
    TemporalScheduleKind,
    TemporalScheduleStatus,
)


class TemporalScheduleSerializer(Serializer[TemporalSchedule]):
    def serialize(self, entity: TemporalSchedule) -> dict[str, Any]:
        return {
            "id": entity.id,
            "execution_request": ExecutionRequestSerializer().serialize(
                entity.execution_request
            ),
            "run_at": entity.run_at.isoformat(),
            "kind": entity.kind.value,
            "recurrence": (
                {"interval_seconds": entity.recurrence.interval.total_seconds()}
                if entity.recurrence is not None
                else None
            ),
            "missed_policy": entity.missed_policy.value,
            "priority": entity.priority,
            "metadata": dict(entity.metadata),
            "created_at": entity.created_at.isoformat(),
            "status": entity.status.value,
        }

    def deserialize(self, data: dict[str, Any]) -> TemporalSchedule:
        recurrence_data = data.get("recurrence")
        recurrence = (
            TemporalRecurrence(
                interval=__import__("datetime").timedelta(
                    seconds=float(recurrence_data["interval_seconds"])
                )
            )
            if recurrence_data is not None
            else None
        )

        return TemporalSchedule(
            execution_request=ExecutionRequestSerializer().deserialize(
                dict(data["execution_request"])
            ),
            run_at=datetime.fromisoformat(data["run_at"]),
            kind=TemporalScheduleKind(data.get("kind", "once")),
            recurrence=recurrence,
            missed_policy=MissedSchedulePolicy(
                data.get("missed_policy", "fire_once")
            ),
            priority=int(data.get("priority", 0)),
            metadata=dict(data.get("metadata", {})),
            id=str(data["id"]),
            created_at=datetime.fromisoformat(data["created_at"]),
            status=TemporalScheduleStatus(
                data.get("status", "active")
            ),
        )
