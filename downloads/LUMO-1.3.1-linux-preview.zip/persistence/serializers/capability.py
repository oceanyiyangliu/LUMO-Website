from __future__ import annotations

from typing import Any

from ocean.domain.capability import (
    CapabilityExecutionPolicy,
    CapabilityIsolationPolicy,
    CapabilitySpec,
    OperationSpec,
)
from persistence.serializer import Serializer
from ocean.domain.enums import RiskLevel
from ocean.domain.resource import ResourceRequirement


class CapabilitySerializer(Serializer[CapabilitySpec]):
    """Serialize and deserialize capability specifications."""

    def serialize_resource_requirement(
        self,
        requirement: ResourceRequirement,
    ) -> dict[str, Any]:
        return {
            "kind": requirement.kind,
            "amount": requirement.amount,
        }

    def deserialize_resource_requirement(
        self,
        data: dict[str, Any],
    ) -> ResourceRequirement:
        return ResourceRequirement(
            kind=str(data["kind"]),
            amount=float(data.get("amount", 1.0)),
        )

    def serialize_operation(
        self,
        operation: OperationSpec,
    ) -> dict[str, Any]:
        return {
            "name": operation.name,
            "description": operation.description,
            "input_schema": dict(operation.input_schema),
            "output_schema": dict(operation.output_schema),
            "risk_level": operation.risk_level.value,
            "resource_requirements": [
                self.serialize_resource_requirement(requirement)
                for requirement in operation.resource_requirements
            ],
        }

    def deserialize_operation(
        self,
        data: dict[str, Any],
    ) -> OperationSpec:
        return OperationSpec(
            name=str(data["name"]),
            description=str(data["description"]),
            input_schema=dict(data.get("input_schema", {})),
            output_schema=dict(data.get("output_schema", {})),
            risk_level=RiskLevel(data["risk_level"]),
            resource_requirements=[
                self.deserialize_resource_requirement(requirement)
                for requirement in data.get("resource_requirements", [])
            ],
        )

    def serialize(self, entity: CapabilitySpec) -> dict[str, Any]:
        return {
            "name": entity.name,
            "description": entity.description,
            "operations": {
                name: self.serialize_operation(operation)
                for name, operation in entity.operations.items()
            },
            "execution_strategy": entity.execution_strategy,
            "requires_permissions": sorted(entity.requires_permissions),
            "execution_policy": {
                "isolation": entity.execution_policy.isolation.value,
            },
        }

    def deserialize(self, data: dict[str, Any]) -> CapabilitySpec:
        return CapabilitySpec(
            name=str(data["name"]),
            description=str(data["description"]),
            operations={
                name: self.deserialize_operation(operation)
                for name, operation in data.get("operations", {}).items()
            },
            execution_strategy=str(
                data.get("execution_strategy", "deterministic_local")
            ),
            requires_permissions=set(
                data.get("requires_permissions", [])
            ),
            execution_policy=CapabilityExecutionPolicy(
                isolation=CapabilityIsolationPolicy(
                    data.get("execution_policy", {}).get(
                        "isolation",
                        CapabilityIsolationPolicy.IN_PROCESS_SAFE.value,
                    )
                )
            ),
        )
