from __future__ import annotations

from datetime import datetime
from typing import Any

from ocean.domain.enums import MissionStatus
from ocean.domain.mission import Mission
from persistence.serializer import Serializer


class MissionSerializer(Serializer[Mission]):
    """Serialize and deserialize Mission domain entities."""

    def serialize(self, entity: Mission) -> dict[str, Any]:
        return {
            "id": entity.id,
            "goal": entity.goal,
            "task_ids": list(entity.task_ids),
            "metadata": dict(entity.metadata),
            "status": entity.status.value,
            "created_at": entity.created_at.isoformat(),
            "updated_at": entity.updated_at.isoformat(),
        }

    def deserialize(self, data: dict[str, Any]) -> Mission:
        return Mission(
            goal=str(data["goal"]),
            task_ids=list(data.get("task_ids", [])),
            metadata=dict(data.get("metadata", {})),
            id=str(data["id"]),
            status=MissionStatus(data["status"]),
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"]),
        )
