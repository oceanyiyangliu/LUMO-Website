from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Mapping

from ocean.domain.event import Event

from persistence.serializer import Serializer


class EventSerializer(Serializer[Event]):
    """Serialize and deserialize immutable event records."""

    @classmethod
    def _json_safe(cls, value: Any) -> Any:
        if isinstance(value, datetime):
            return value.isoformat()
        if isinstance(value, Enum):
            return value.value
        if isinstance(value, Mapping):
            return {
                str(key): cls._json_safe(item)
                for key, item in value.items()
            }
        if isinstance(value, (list, tuple)):
            return [cls._json_safe(item) for item in value]
        if isinstance(value, set):
            return [cls._json_safe(item) for item in value]
        return value

    def serialize(self, entity: Event) -> dict[str, Any]:
        return {
            "id": entity.id,
            "type": entity.type,
            "payload": self._json_safe(entity.payload),
            "aggregate_type": entity.aggregate_type,
            "aggregate_id": entity.aggregate_id,
            "version": entity.version,
            "sequence": entity.sequence,
            "causation_id": entity.causation_id,
            "correlation_id": entity.correlation_id,
            "source": entity.source,
            "at": entity.at.isoformat(),
        }

    def deserialize(self, data: dict[str, Any]) -> Event:
        return Event(
            type=str(data["type"]),
            payload=dict(data.get("payload", {})),
            aggregate_type=data.get("aggregate_type"),
            aggregate_id=data.get("aggregate_id"),
            version=int(data.get("version", 1)),
            sequence=(
                int(data["sequence"])
                if data.get("sequence") is not None
                else None
            ),
            causation_id=data.get("causation_id"),
            correlation_id=data.get("correlation_id"),
            source=data.get("source"),
            id=str(data["id"]),
            at=datetime.fromisoformat(data["at"]),
        )
