from __future__ import annotations

from typing import Any

from persistence.serializer import Serializer
from runtime.resources import ExecutionResourceLimits
from runtime.types import ExecutionRequest


class ExecutionResourceLimitsSerializer(Serializer[ExecutionResourceLimits]):
    def serialize(self, entity: ExecutionResourceLimits) -> dict[str, Any]:
        return {
            "timeout_seconds": entity.timeout_seconds,
            "memory_bytes": entity.memory_bytes,
            "cpu_seconds": entity.cpu_seconds,
            "max_output_bytes": entity.max_output_bytes,
            "max_worker_lifetime_seconds": entity.max_worker_lifetime_seconds,
        }

    def deserialize(self, data: dict[str, Any]) -> ExecutionResourceLimits:
        return ExecutionResourceLimits(
            timeout_seconds=data.get("timeout_seconds"),
            memory_bytes=data.get("memory_bytes"),
            cpu_seconds=data.get("cpu_seconds"),
            max_output_bytes=data.get("max_output_bytes"),
            max_worker_lifetime_seconds=data.get(
                "max_worker_lifetime_seconds"
            ),
        )


class ExecutionRequestSerializer(Serializer[ExecutionRequest]):
    def serialize(self, entity: ExecutionRequest) -> dict[str, Any]:
        return {
            "task_id": entity.task_id,
            "capability": entity.capability,
            "operation": entity.operation,
            "agent_id": entity.agent_id,
            "arguments": dict(entity.arguments),
            "correlation_id": entity.correlation_id,
            "causation_id": entity.causation_id,
            "source": entity.source,
            "execution_id": entity.execution_id,
            "metadata": dict(entity.metadata),
            "resource_limits": ExecutionResourceLimitsSerializer().serialize(
                entity.resource_limits
            ),
        }

    def deserialize(self, data: dict[str, Any]) -> ExecutionRequest:
        return ExecutionRequest(
            task_id=str(data["task_id"]),
            capability=str(data["capability"]),
            operation=str(data["operation"]),
            agent_id=data.get("agent_id"),
            arguments=dict(data.get("arguments", {})),
            correlation_id=data.get("correlation_id"),
            causation_id=data.get("causation_id"),
            source=data.get("source"),
            execution_id=data.get("execution_id"),
            metadata=dict(data.get("metadata", {})),
            resource_limits=ExecutionResourceLimitsSerializer().deserialize(
                dict(data.get("resource_limits", {}))
            ),
        )
