from __future__ import annotations

from typing import Any

from ocean.domain.work_graph import (
    WorkEdge,
    WorkEdgeKind,
    WorkGraph,
    WorkNode,
    WorkNodeKind,
)
from persistence.serializer import Serializer


class WorkGraphSerializer(Serializer[WorkGraph]):
    """Serialize and deserialize immutable validated work graphs."""

    @staticmethod
    def serialize_node(node: WorkNode) -> dict[str, Any]:
        return {
            "id": node.id,
            "kind": node.kind.value,
            "task_id": node.task_id,
            "metadata": dict(node.metadata),
        }

    @staticmethod
    def deserialize_node(data: dict[str, Any]) -> WorkNode:
        return WorkNode(
            kind=WorkNodeKind(data["kind"]),
            task_id=data.get("task_id"),
            metadata=dict(data.get("metadata", {})),
            id=str(data["id"]),
        )

    @staticmethod
    def serialize_edge(edge: WorkEdge) -> dict[str, Any]:
        return {
            "id": edge.id,
            "source_node_id": edge.source_node_id,
            "target_node_id": edge.target_node_id,
            "kind": edge.kind.value,
            "condition": edge.condition,
        }

    @staticmethod
    def deserialize_edge(data: dict[str, Any]) -> WorkEdge:
        return WorkEdge(
            source_node_id=str(data["source_node_id"]),
            target_node_id=str(data["target_node_id"]),
            kind=WorkEdgeKind(data["kind"]),
            condition=data.get("condition"),
            id=str(data["id"]),
        )

    def serialize(self, entity: WorkGraph) -> dict[str, Any]:
        return {
            "id": entity.id,
            "mission_id": entity.mission_id,
            "plan_revision_id": entity.plan_revision_id,
            "nodes": [
                self.serialize_node(node)
                for node in entity.nodes
            ],
            "edges": [
                self.serialize_edge(edge)
                for edge in entity.edges
            ],
            "metadata": dict(entity.metadata),
        }

    def deserialize(self, data: dict[str, Any]) -> WorkGraph:
        return WorkGraph(
            mission_id=str(data["mission_id"]),
            plan_revision_id=str(data["plan_revision_id"]),
            nodes=tuple(
                self.deserialize_node(node)
                for node in data.get("nodes", [])
            ),
            edges=tuple(
                self.deserialize_edge(edge)
                for edge in data.get("edges", [])
            ),
            metadata=dict(data.get("metadata", {})),
            id=str(data["id"]),
        )
