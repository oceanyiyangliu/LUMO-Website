from __future__ import annotations

from datetime import datetime
from typing import Any

from ocean.domain.artifact import Artifact
from persistence.serializer import Serializer


class ArtifactSerializer(Serializer[Artifact]):
    """Serialize and deserialize Artifact domain entities."""

    def serialize(self, entity: Artifact) -> dict[str, Any]:
        return {
            "id": entity.id,
            "kind": entity.kind,
            "name": entity.name,
            "uri": entity.uri,
            "produced_by_task_id": entity.produced_by_task_id,
            "produced_by_agent_id": entity.produced_by_agent_id,
            "metadata": dict(entity.metadata),
            "created_at": entity.created_at.isoformat(),
        }

    def deserialize(self, data: dict[str, Any]) -> Artifact:
        return Artifact(
            kind=str(data["kind"]),
            name=str(data["name"]),
            uri=data.get("uri"),
            produced_by_task_id=data.get("produced_by_task_id"),
            produced_by_agent_id=data.get("produced_by_agent_id"),
            metadata=dict(data.get("metadata", {})),
            id=str(data["id"]),
            created_at=datetime.fromisoformat(data["created_at"]),
        )

