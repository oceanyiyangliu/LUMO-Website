from __future__ import annotations

from datetime import datetime
from typing import Any

from ocean.domain.assignment import Assignment
from ocean.domain.enums import AssignmentStatus, OrchestrationMode
from persistence.serializer import Serializer


class AssignmentSerializer(Serializer[Assignment]):
    """Serialize and deserialize Assignment domain entities."""

    def serialize(self, entity: Assignment) -> dict[str, Any]:
        return {
            "id": entity.id,
            "task_id": entity.task_id,
            "agent_id": entity.agent_id,
            "mission_id": entity.mission_id,
            "mode": entity.mode.value,
            "priority": entity.priority,
            "status": entity.status.value,
            "execution_id": entity.execution_id,
            "parent_assignment_id": entity.parent_assignment_id,
            "reason": entity.reason,
            "metadata": dict(entity.metadata),
            "created_at": entity.created_at.isoformat(),
            "updated_at": entity.updated_at.isoformat(),
        }

    def deserialize(self, data: dict[str, Any]) -> Assignment:
        return Assignment(
            task_id=str(data["task_id"]),
            agent_id=str(data["agent_id"]),
            mission_id=data.get("mission_id"),
            mode=OrchestrationMode(data["mode"]),
            priority=int(data.get("priority", 0)),
            status=AssignmentStatus(data["status"]),
            execution_id=data.get("execution_id"),
            parent_assignment_id=data.get("parent_assignment_id"),
            reason=data.get("reason"),
            metadata=dict(data.get("metadata", {})),
            id=str(data["id"]),
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"]),
        )
