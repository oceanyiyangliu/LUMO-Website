from __future__ import annotations

from datetime import datetime
from typing import Any

from ocean.self_improvement.research import ResearchFinding, ResearchSource
from persistence.serializer import Serializer


class ResearchFindingSerializer(Serializer[ResearchFinding]):
    """Serialize and deserialize persisted research findings."""

    def serialize(self, entity: ResearchFinding) -> dict[str, Any]:
        return {
            "id": entity.id,
            "candidate_id": entity.candidate_id,
            "claim": entity.claim,
            "source": {
                "title": entity.source.title,
                "uri": entity.source.uri,
                "source_type": entity.source.source_type,
                "publisher": entity.source.publisher,
                "published_at": (
                    entity.source.published_at.isoformat()
                    if entity.source.published_at is not None
                    else None
                ),
                "metadata": dict(entity.source.metadata),
            },
            "confidence": entity.confidence,
            "evidence": list(entity.evidence),
            "metadata": dict(entity.metadata),
            "at": entity.at.isoformat(),
        }

    def deserialize(self, data: dict[str, Any]) -> ResearchFinding:
        source_data = dict(data["source"])
        published_at = source_data.get("published_at")

        source = ResearchSource(
            title=str(source_data["title"]),
            uri=str(source_data["uri"]),
            source_type=str(source_data["source_type"]),
            publisher=source_data.get("publisher"),
            published_at=(
                datetime.fromisoformat(published_at)
                if published_at is not None
                else None
            ),
            metadata=dict(source_data.get("metadata", {})),
        )

        return ResearchFinding(
            id=str(data["id"]),
            candidate_id=str(data["candidate_id"]),
            claim=str(data["claim"]),
            source=source,
            confidence=float(data["confidence"]),
            evidence=tuple(data.get("evidence", [])),
            metadata=dict(data.get("metadata", {})),
            at=datetime.fromisoformat(data["at"]),
        )
