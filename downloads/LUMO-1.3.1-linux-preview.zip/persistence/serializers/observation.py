from __future__ import annotations

from datetime import datetime
from typing import Any

from ocean.domain.observation import Observation
from persistence.serializer import Serializer


class ObservationSerializer(Serializer[Observation]):
    """Serialize and deserialize Observation domain entities."""

    def serialize(self, entity: Observation) -> dict[str, Any]:
        return {
            "id": entity.id,
            "kind": entity.kind,
            "data": dict(entity.data),
            "task_id": entity.task_id,
            "execution_id": entity.execution_id,
            "at": entity.at.isoformat(),
        }

    def deserialize(self, data: dict[str, Any]) -> Observation:
        return Observation(
            kind=str(data["kind"]),
            data=dict(data.get("data", {})),
            task_id=data.get("task_id"),
            execution_id=data.get("execution_id"),
            id=str(data["id"]),
            at=datetime.fromisoformat(data["at"]),
        )
