from __future__ import annotations

from datetime import datetime
from typing import Any

from ocean.domain.enums import ExecutionStatus, OrchestrationMode
from ocean.domain.execution import Execution
from persistence.serializer import Serializer


class ExecutionSerializer(Serializer[Execution]):
    """Serialize and deserialize Execution domain entities."""

    def serialize(self, entity: Execution) -> dict[str, Any]:
        return {
            "id": entity.id,
            "task_id": entity.task_id,
            "capability": entity.capability,
            "operation": entity.operation,
            "arguments": dict(entity.arguments),
            "agent_id": entity.agent_id,
            "principal_id": entity.principal_id,
            "mission_id": entity.mission_id,
            "mode": entity.mode.value,
            "status": entity.status.value,
            "started_at": (
                entity.started_at.isoformat()
                if entity.started_at is not None
                else None
            ),
            "ended_at": (
                entity.ended_at.isoformat()
                if entity.ended_at is not None
                else None
            ),
            "raw_result": entity.raw_result,
            "error": entity.error,
        }

    def deserialize(self, data: dict[str, Any]) -> Execution:
        return Execution(
            task_id=str(data["task_id"]),
            capability=str(data["capability"]),
            operation=str(data["operation"]),
            arguments=dict(data.get("arguments", {})),
            agent_id=data.get("agent_id"),
            principal_id=data.get("principal_id"),
            mission_id=data.get("mission_id"),
            mode=OrchestrationMode(data.get("mode", "standard")),
            id=str(data["id"]),
            status=ExecutionStatus(data["status"]),
            started_at=(
                datetime.fromisoformat(data["started_at"])
                if data.get("started_at") is not None
                else None
            ),
            ended_at=(
                datetime.fromisoformat(data["ended_at"])
                if data.get("ended_at") is not None
                else None
            ),
            raw_result=data.get("raw_result"),
            error=data.get("error"),
        )

