from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Generic, TypeVar

T = TypeVar("T")


class Serializer(ABC, Generic[T]):
    @abstractmethod
    def serialize(self, entity: T) -> dict[str, Any]:
        ...

    @abstractmethod
    def deserialize(self, data: dict[str, Any]) -> T:
        ...
