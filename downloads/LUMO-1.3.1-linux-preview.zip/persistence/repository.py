from __future__ import annotations

from abc import ABC, abstractmethod
from contextlib import contextmanager
from typing import Generic, Iterable, Iterator, Optional, TypeVar

T = TypeVar("T")


class Repository(ABC, Generic[T]):

    @abstractmethod
    def save(self, entity: T) -> T:
        ...

    @abstractmethod
    def get(self, entity_id: str) -> Optional[T]:
        ...

    @abstractmethod
    def delete(self, entity_id: str) -> bool:
        ...

    @abstractmethod
    def list(self) -> Iterable[T]:
        ...

    @contextmanager
    def transaction(self) -> Iterator[None]:
        """Transaction boundary for atomic multi-repository workflows.

        Repositories that support real transactional storage override this
        method. The default preserves compatibility for non-transactional
        repositories while making the boundary explicit.
        """
        yield
