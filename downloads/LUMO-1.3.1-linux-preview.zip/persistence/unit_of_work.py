from __future__ import annotations

from contextlib import ExitStack
from typing import Iterable

from .repository import Repository


class UnitOfWork:
    """Coordinate one atomic transaction across repositories."""

    def __init__(self, repositories: Iterable[Repository]) -> None:
        self._repositories = []
        for repository in repositories:
            if not any(existing is repository for existing in self._repositories):
                self._repositories.append(repository)

        connections = []
        for repository in self._repositories:
            connection = getattr(repository, "_connection", None)
            if connection is not None and not any(
                existing is connection for existing in connections
            ):
                connections.append(connection)

        if len(connections) > 1:
            raise ValueError(
                "UnitOfWork requires all SQLite repositories to share one "
                "sqlite3.Connection"
            )

    def transaction(self):
        stack = ExitStack()
        for repository in self._repositories:
            stack.enter_context(repository.transaction())
        return stack
