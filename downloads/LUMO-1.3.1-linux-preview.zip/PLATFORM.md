# LUMO platform strategy

LUMO is one product with a platform-neutral Core/UI and thin native OS adapters.

## Shared everywhere

- conversations and Work
- event sourcing and durable state
- intelligence routing and local/cloud model policy
- Library and artifacts
- Workforce/Evolution
- LUMO Root control-plane protocol
- signed release/update protocol

## Native per OS

- application lifecycle and startup
- permissions and privacy APIs
- screen/audio capture
- computer control/accessibility
- notifications
- resource/process integration
- installer, signing and OS update mechanics

macOS currently has the complete native computer-control surface. Windows and Linux have first-class platform state storage, launch boundaries, and capability reporting; their native computer-control surfaces remain explicitly capability-gated until implemented, rather than being falsely advertised as available.

Cross-platform support is validated in layers: the shared Core/adapters are covered by platform adapter contract tests, while native OS capabilities require a real host of that OS for final validation. The website only exposes a platform download when its signed production artifact URL is configured, so an unvalidated platform cannot accidentally be advertised as ready.

Installed builds keep mutable state outside the application bundle using `LUMO_STATE_DIR`. This lets one release/update system replace the immutable application while preserving user state across upgrades.

## Release model

A LUMO release is universal at the product level. Platform-specific artifacts contain the same Core/UI version plus the adapter/runtime required by that OS. The updater verifies the signed manifest and artifact before activation and retains a previous release for rollback.
