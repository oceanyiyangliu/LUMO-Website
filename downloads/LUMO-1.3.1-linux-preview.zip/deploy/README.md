# LUMO deployment

Use `DEPLOYMENT_CONTRACT.md` as the authoritative infrastructure boundary and `.env.production.example` as the non-secret configuration template.

The release candidate can be deployed to a controlled single node once real secrets, TLS material, durable storage, and monitoring are supplied. Public multi-tenant SaaS still requires a hosted persistence adapter and hosted World fleet.
