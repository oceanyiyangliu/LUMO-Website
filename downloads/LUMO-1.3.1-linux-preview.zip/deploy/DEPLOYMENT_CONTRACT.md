# LUMO Production Deployment Contract

This directory is the provider-neutral boundary between the verified LUMO control plane and real infrastructure. It does not pretend that cloud accounts, domains, payment accounts, or hosted World capacity exist.

## Required production inputs

- `LUMO_API_AUTH_REQUIRED=1`
- `LUMO_API_SESSION_BOOTSTRAP_SECRET` (>=16 chars)
- `LUMO_API_SESSION_SECRET` (>=32 chars)
- `LUMO_TENANCY_STORE` pointing at durable writable production storage
- `LUMO_TLS_CERT_FILE` and `LUMO_TLS_KEY_FILE`
- `LUMO_HEALTH_URL` using HTTPS
- `LUMO_ALERT_FILE` on durable writable storage

## Infrastructure contract

1. Terminate TLS at a trusted edge and forward only to the LUMO application listener.
2. Do not expose the localhost-first development server directly without an authenticated TLS edge.
3. Persist tenancy/event data on durable storage with backups. SQLite is acceptable only for a controlled single-node deployment; hosted SaaS should provide a remote database adapter before multi-node operation.
4. World execution must use isolated World providers. Never attach host keyboard, pointer, display, clipboard, or filesystem devices to a customer World.
5. Monitoring must probe an HTTPS health endpoint and persist alert records.
6. Production secrets must come from the provider's secret manager/environment, never from git.
7. Payment webhooks must be authenticated, replay-safe, and reconciled against provider state.
8. Deployment must be reversible to the last signed release artifact.

## Deployment gate

Run `python scripts/production_preflight.py --env-file <file> --artifact dist/lumo-1.0.0-rc1.zip --manifest dist/lumo-1.0.0-rc1.manifest.json` before starting production. A failed gate is a hard stop.

## Still provider-dependent

The repository cannot create these external resources without an actual provider/account/domain:

- hosted database service
- DNS/domain and TLS certificates
- public authentication identity provider, if desired
- hosted World fleet/compute
- monitoring destination and alert transport
- payment processor account/webhooks
- legal/support configuration

## Release signing

The production release public key is pinned in `deploy/RELEASE_PUBLIC_KEY.b64`. The corresponding private key must remain in the release operator's secure key store and must never be committed. Rotate the key only through an explicit release-key rotation procedure that updates the pinned public key and all trusted installers together.
