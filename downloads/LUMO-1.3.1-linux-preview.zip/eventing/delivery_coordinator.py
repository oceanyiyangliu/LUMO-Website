"""Durable event delivery coordinator.

Provides at-least-once delivery of committed events to registered
subscribers with durable cursor persistence.  The coordinator uses its
own independent SQLite connection — never the UnitOfWork connection —
so it can only observe committed events (guaranteed by WAL read
isolation).

Cursor semantic: the cursor is the highest event sequence **successfully
processed** by the subscriber.  A cursor never advances past a failed
handler.  Non-matching events are skipped without advancing the cursor
past them.

Startup catch-up and ongoing delivery use exactly the same polling path.
"""

from __future__ import annotations

import logging
import sqlite3
import time
from dataclasses import dataclass, field
from threading import Event as ThreadingEvent, RLock
from typing import Callable, Iterable, Optional

from ocean.domain.event import Event
from eventing.store import EventStore
from eventing.sqlite_store import SQLiteEventStore

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Subscriber identity
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Subscriber:
    """A logical durable consumer.

    ``subscriber_id`` is the durable identity used as the cursor key.
    ``event_types`` is ``None`` for wildcard (all events) or a frozenset
    of concrete event type strings.  ``handler`` is the callable invoked
    for each matching event.
    """

    subscriber_id: str
    event_types: Optional[frozenset[str]]
    handler: Callable[[Event], None]


# ---------------------------------------------------------------------------
# DeliveryCoordinator
# ---------------------------------------------------------------------------

_DEFAULT_POLL_INTERVAL = 0.1  # seconds
_DEFAULT_MAX_CONSECUTIVE_FAILURES = 5
_BASE_BACKOFF = 1.0  # seconds
_MAX_BACKOFF = 16.0  # seconds
_CURSOR_TABLE = "subscriber_cursors"


class DeliveryCoordinator:
    """Durable event delivery coordinator.

    The coordinator owns an independent ``sqlite3.Connection`` and never
    touches the UnitOfWork connection.  It polls
    ``EventStore.list_after_sequence()`` in a loop, dispatches matching
    events to subscribers, and durably persists cursor advancement only
    after successful handler execution.

    Phase 2 constraint: one active coordinator per logical subscriber.
    """

    def __init__(
        self,
        database_path: str,
        *,
        poll_interval: float = _DEFAULT_POLL_INTERVAL,
        max_consecutive_failures: int = _DEFAULT_MAX_CONSECUTIVE_FAILURES,
    ) -> None:
        self._connection = sqlite3.connect(
            database_path, check_same_thread=False
        )
        self._connection.execute("PRAGMA journal_mode = WAL")
        self._connection.execute("PRAGMA busy_timeout = 30000")
        self._connection.execute("PRAGMA synchronous = NORMAL")

        self._event_store: EventStore = SQLiteEventStore(self._connection)
        self._poll_interval = poll_interval
        self._max_consecutive_failures = max_consecutive_failures

        self._subscribers: dict[str, Subscriber] = {}
        self._active: dict[str, bool] = {}
        self._consecutive_failures: dict[str, int] = {}
        self._shutdown = ThreadingEvent()
        self._lock = RLock()

        self._ensure_cursor_table()

    # ------------------------------------------------------------------
    # Schema
    # ------------------------------------------------------------------

    def _ensure_cursor_table(self) -> None:
        self._connection.execute(
            f"""
            CREATE TABLE IF NOT EXISTS "{_CURSOR_TABLE}" (
                subscriber_id TEXT PRIMARY KEY,
                last_sequence INTEGER NOT NULL,
                updated_at TEXT NOT NULL
            )
            """
        )
        self._connection.commit()

    # ------------------------------------------------------------------
    # Subscriber registration
    # ------------------------------------------------------------------

    def subscribe(
        self,
        subscriber_id: str,
        handler: Callable[[Event], None],
        event_types: Optional[frozenset[str]] = None,
    ) -> None:
        """Register a durable subscriber.

        Raises ``RuntimeError`` if the subscriber is already active in
        this coordinator (Phase 2: one active coordinator per subscriber).
        """
        with self._lock:
            if subscriber_id in self._active:
                raise RuntimeError(
                    f"subscriber {subscriber_id!r} is already active"
                )
            self._subscribers[subscriber_id] = Subscriber(
                subscriber_id=subscriber_id,
                event_types=event_types,
                handler=handler,
            )
            self._active[subscriber_id] = True
            self._consecutive_failures[subscriber_id] = 0

    def unsubscribe(self, subscriber_id: str) -> None:
        """Remove a subscriber and its cursor."""
        with self._lock:
            self._subscribers.pop(subscriber_id, None)
            self._active.pop(subscriber_id, None)
            self._consecutive_failures.pop(subscriber_id, None)
        self._connection.execute(
            f'DELETE FROM "{_CURSOR_TABLE}" WHERE subscriber_id = ?',
            (subscriber_id,),
        )
        self._connection.commit()

    # ------------------------------------------------------------------
    # Cursor persistence
    # ------------------------------------------------------------------

    def _load_cursor(self, subscriber_id: str) -> int:
        row = self._connection.execute(
            f'SELECT last_sequence FROM "{_CURSOR_TABLE}" WHERE subscriber_id = ?',
            (subscriber_id,),
        ).fetchone()
        return 0 if row is None else int(row[0])

    def _save_cursor(self, subscriber_id: str, sequence: int) -> bool:
        """Persist cursor.  Returns True on success, False on contention."""
        try:
            self._connection.execute(
                f"""
                INSERT OR REPLACE INTO "{_CURSOR_TABLE}"
                    (subscriber_id, last_sequence, updated_at)
                VALUES (?, ?, datetime('now'))
                """,
                (subscriber_id, sequence),
            )
            self._connection.commit()
            return True
        except sqlite3.OperationalError as exc:
            logger.warning(
                "cursor write failed for %s: %s", subscriber_id, exc
            )
            try:
                self._connection.rollback()
            except sqlite3.OperationalError:
                pass
            return False

    # ------------------------------------------------------------------
    # Polling loop
    # ------------------------------------------------------------------

    def poll_once(self) -> None:
        """Execute one poll cycle for all active subscribers."""
        with self._lock:
            snapshot = {
                sid: sub
                for sid, sub in self._subscribers.items()
                if self._active.get(sid, False)
            }

        for subscriber_id, subscriber in snapshot.items():
            self._poll_subscriber(subscriber_id, subscriber)

    def _poll_subscriber(
        self, subscriber_id: str, subscriber: Subscriber
    ) -> None:
        cursor = self._load_cursor(subscriber_id)
        events = list(self._event_store.list_after_sequence(cursor))

        if not events:
            return

        last_success_cursor = cursor

        for event in events:
            seq = self._event_store.sequence(event.id)
            if seq is None:
                continue

            # A non-matching event is still safely consumed for this subscriber.
            # Advancing over it prevents a filtered subscriber from rescanning
            # an ever-growing prefix of unrelated events on every poll.
            if not self._matches(subscriber, event):
                last_success_cursor = seq
                continue

            try:
                subscriber.handler(event)
            except Exception as exc:
                logger.error(
                    "handler failed for %s on event %s (seq=%d): %s",
                    subscriber_id,
                    event.id,
                    seq,
                    exc,
                )
                self._record_failure(subscriber_id)
                stopped_at_failure = True
                break

            last_success_cursor = seq
            self._reset_failures(subscriber_id)

        if last_success_cursor > cursor:
            if not self._save_cursor(subscriber_id, last_success_cursor):
                pass  # retry on next poll cycle

    def _matches(self, subscriber: Subscriber, event: Event) -> bool:
        if subscriber.event_types is None:
            return True
        return event.type in subscriber.event_types

    # ------------------------------------------------------------------
    # Failure tracking and backoff
    # ------------------------------------------------------------------

    def _record_failure(self, subscriber_id: str) -> None:
        self._consecutive_failures[subscriber_id] = (
            self._consecutive_failures.get(subscriber_id, 0) + 1
        )

    def _reset_failures(self, subscriber_id: str) -> None:
        self._consecutive_failures[subscriber_id] = 0

    def _backoff_seconds(self, subscriber_id: str) -> float:
        failures = self._consecutive_failures.get(subscriber_id, 0)
        if failures <= 0:
            return 0.0
        capped = min(failures, 10)
        return min(_BASE_BACKOFF * (2 ** (capped - 1)), _MAX_BACKOFF)

    # ------------------------------------------------------------------
    # Run loop
    # ------------------------------------------------------------------

    def run(self) -> None:
        """Run the polling loop until ``shutdown()`` is called."""
        while not self._shutdown.is_set():
            self.poll_once()

            total_backoff = 0.0
            with self._lock:
                for sid in list(self._active):
                    if self._active.get(sid, False):
                        b = self._backoff_seconds(sid)
                        if b > total_backoff:
                            total_backoff = b

            sleep_time = max(self._poll_interval, total_backoff)
            self._shutdown.wait(timeout=sleep_time)

    def shutdown(self) -> None:
        """Signal the polling loop to stop after the current cycle."""
        self._shutdown.set()

    # ------------------------------------------------------------------
    # Introspection (for testing)
    # ------------------------------------------------------------------

    def cursor(self, subscriber_id: str) -> int:
        """Return the persisted cursor for a subscriber."""
        return self._load_cursor(subscriber_id)

    def is_active(self, subscriber_id: str) -> bool:
        return self._active.get(subscriber_id, False)
