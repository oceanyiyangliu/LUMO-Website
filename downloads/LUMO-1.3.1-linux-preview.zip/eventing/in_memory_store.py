from __future__ import annotations

from typing import Dict, Iterable, Optional

from ocean.domain.event import Event

from eventing.store import EventStore


class InMemoryEventStore(EventStore):
    def __init__(self) -> None:
        self._events: Dict[str, Event] = {}
        self._order: list[str] = []
        self._sequences: Dict[str, int] = {}
        self._next_sequence = 1

    def append(self, event: Event) -> Event:
        if event.id not in self._events:
            self._order.append(event.id)
            self._sequences[event.id] = self._next_sequence
            self._next_sequence += 1

        self._events[event.id] = event
        return event

    def get(self, event_id: str) -> Optional[Event]:
        return self._events.get(event_id)

    def sequence(self, event_id: str) -> Optional[int]:
        return self._sequences.get(event_id)

    def list_after_sequence(self, sequence: int) -> Iterable[Event]:
        return [
            self._events[event_id]
            for event_id in self._order
            if self._sequences[event_id] > sequence
        ]

    def list(self, event_type: Optional[str] = None) -> Iterable[Event]:
        events = [self._events[event_id] for event_id in self._order]

        if event_type is None:
            return events

        return [event for event in events if event.type == event_type]
