from __future__ import annotations

from dataclasses import dataclass
import copy
from threading import RLock
from typing import Callable, Dict, List

from ocean.domain.event import Event


EventHandler = Callable[[Event], None]

WILDCARD = "*"


@dataclass(frozen=True)
class DispatchFailure:
    handler: EventHandler
    error: Exception


class EventDispatcher:
    def __init__(self) -> None:
        # mapping event type -> list of handlers
        self._handlers: Dict[str, List[EventHandler]] = {}
        # protect mutations and snapshots of _handlers
        self._lock = RLock()

    def subscribe(self, event_type: str, handler: EventHandler) -> None:
        """Register a handler for an event type. Handlers may be registered
        multiple times (they will be called once per registration).
        """
        with self._lock:
            self._handlers.setdefault(event_type, []).append(handler)

    def unsubscribe(self, event_type: str, handler: EventHandler) -> None:
        """Remove a handler registration. Safe to call even if the handler
        is not present.
        """
        with self._lock:
            handlers = self._handlers.get(event_type)
            if not handlers:
                return

            try:
                handlers.remove(handler)
            except ValueError:
                return

            if not handlers:
                # clean up empty lists to preserve previous behavior
                del self._handlers[event_type]

    def dispatch(self, event: Event) -> List[DispatchFailure]:
        """Dispatch an event synchronously to all matching handlers.

        Threads may concurrently subscribe/unsubscribe or dispatch other
        events. We take a snapshot of the handlers under lock and then
        invoke them without holding the lock to avoid running user code
        while holding internal locks.
        """
        failures: List[DispatchFailure] = []

        # Take a stable snapshot of matching handlers while holding the lock.
        with self._lock:
            handlers: List[EventHandler] = []

            specific = self._handlers.get(event.type)
            if specific:
                handlers.extend(list(specific))

            wildcard = self._handlers.get(WILDCARD)
            if wildcard:
                handlers.extend(list(wildcard))

        # Invoke handlers without holding the lock. Preserve original
        # behavior: exceptions are captured and collected as DispatchFailure,
        # and other handlers still run.
        for handler in handlers:
            try:
                # Every subscriber gets an isolated event object. A handler is
                # application code and must not be able to mutate the event
                # observed by another handler or the durable history.
                handler(copy.deepcopy(event))
            except Exception as exc:  # noqa: BLE001
                failures.append(DispatchFailure(handler, exc))

        return failures
