from __future__ import annotations

from contextlib import contextmanager
import hashlib
import json
from typing import Iterable, Iterator, Optional
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from pathlib import Path
from threading import RLock

from ocean.domain.event import Event
from ocean.crypto import KeyRing, SnapshotCipher

from eventing.store import EventStore
from persistence.serializers.event import EventSerializer
from persistence.sqlite import SQLiteRepository, _CONNECTION_LOCKS, _MANAGED_CONNECTIONS


_EVENT_STORE_LOCKS: dict[object, RLock] = {}


@dataclass(frozen=True)
class EventRetentionPolicy:
    retention_days: int = 365
    archive_after_days: int = 30

    def __post_init__(self):
        if isinstance(self.retention_days,bool) or self.retention_days <= 0: raise ValueError("retention_days must be positive")
        if isinstance(self.archive_after_days,bool) or self.archive_after_days < 0: raise ValueError("archive_after_days must be non-negative")

    def cutoff(self, now: datetime | None = None) -> datetime:
        return (now or datetime.now(timezone.utc)) - timedelta(days=self.retention_days)


class SQLiteEventStore(EventStore):
    def __init__(self, connection, table_name: str = "events", *, encrypt_at_rest: bool = True, key_ring_path: str | Path | None = None) -> None:
        self._connection = connection
        self._serializer = EventSerializer()
        self._encrypt_at_rest = bool(encrypt_at_rest)
        if self._encrypt_at_rest:
            db_path = None
            try:
                row = connection.execute("PRAGMA database_list").fetchone()
                db_path = row[2] if row and row[2] and row[2] != ":memory:" else None
            except Exception:
                db_path = None
            ring_path = Path(key_ring_path) if key_ring_path else (Path(db_path).with_suffix(Path(db_path).suffix + ".keys") if db_path else None)
            self._key_ring = KeyRing(ring_path) if ring_path else KeyRing(Path.cwd() / ".lumo-event-keys")
            self._cipher = SnapshotCipher(self._key_ring)
            def encode(data):
                plain = json.dumps(data, sort_keys=True, separators=(",", ":"), default=str).encode()
                return self._cipher.encrypt(plain, aad=table_name.encode())
            def decode(raw):
                if isinstance(raw, bytes): raw = raw.decode()
                if isinstance(raw, str) and raw.startswith("v1:"):
                    return json.loads(self._cipher.decrypt(raw, aad=table_name.encode()).decode())
                # Legacy plaintext is accepted for migration; new writes are encrypted.
                return json.loads(raw)
            encoder, decoder = encode, decode
        else:
            self._key_ring = None
            self._cipher = None
            encoder = decoder = None
        self._repository = SQLiteRepository(
            connection, self._serializer, table_name,
            storage_encoder=encoder, storage_decoder=decoder,
        )
        self._table_name = table_name
        self._lock = _EVENT_STORE_LOCKS.setdefault(connection, RLock())

        with self._lock:
            self._connection.execute(
                f'''
                CREATE TABLE IF NOT EXISTS "{self._table_name}_sequence" (
                    event_id TEXT PRIMARY KEY,
                    sequence INTEGER NOT NULL UNIQUE
                )
                '''
            )
            self._connection.execute(
                f"""
                CREATE TABLE IF NOT EXISTS "{self._table_name}_integrity" (
                    event_id TEXT PRIMARY KEY,
                    sequence INTEGER NOT NULL UNIQUE,
                    content_hash TEXT NOT NULL,
                    previous_hash TEXT
                )
                """
            )
            # Keep a small unencrypted metadata index so operational reads do
            # not have to decrypt every large event payload (screenshots and
            # artifacts can make the event stream hundreds of MB).
            self._connection.execute(
                f"""
                CREATE TABLE IF NOT EXISTS "{self._table_name}_index" (
                    event_id TEXT PRIMARY KEY,
                    sequence INTEGER NOT NULL UNIQUE,
                    event_type TEXT NOT NULL,
                    aggregate_type TEXT,
                    aggregate_id TEXT
                )
                """
            )
            self._connection.execute(
                f'CREATE INDEX IF NOT EXISTS "{self._table_name}_index_type" ON "{self._table_name}_index" (event_type, sequence)'
            )
            columns = {row[1] for row in self._connection.execute(f'PRAGMA table_info("{self._table_name}_index")').fetchall()}
            if "mission_id" not in columns:
                self._connection.execute(f'ALTER TABLE "{self._table_name}_index" ADD COLUMN mission_id TEXT')
            self._connection.execute(
                f'CREATE INDEX IF NOT EXISTS "{self._table_name}_index_mission" ON "{self._table_name}_index" (mission_id, sequence)'
            )
            self._backfill_integrity()
            if self._encrypt_at_rest:
                self._migrate_plaintext_rows()
            self._backfill_event_index()
            if self._connection not in _MANAGED_CONNECTIONS:
                self._connection.commit()

    def _decode_raw(self, raw):
        if isinstance(raw, bytes): raw = raw.decode()
        if self._encrypt_at_rest and isinstance(raw, str) and raw.startswith("v1:"):
            return json.loads(self._cipher.decrypt(raw, aad=self._table_name.encode()).decode())
        return json.loads(raw)

    def _migrate_plaintext_rows(self) -> None:
        # Do not deserialize the entire event log on every startup. New rows are
        # encrypted and carry the v1: envelope; only legacy plaintext rows need
        # migration. This turns a 25k-event startup scan into an indexed no-op
        # once migration has completed.
        rows = self._connection.execute(
            f'''SELECT id, data FROM "{self._table_name}"
                WHERE CAST(data AS TEXT) NOT LIKE 'v1:%' '''
        ).fetchall()
        for event_id, raw in rows:
            if isinstance(raw, bytes): raw = raw.decode()
            if isinstance(raw, str) and raw.startswith("v1:"): continue
            event = self._serializer.deserialize(json.loads(raw))
            encrypted = self._cipher.encrypt(
                json.dumps(self._serializer.serialize(event), sort_keys=True, separators=(",", ":"), default=str).encode(),
                aad=self._table_name.encode(),
            )
            self._connection.execute(f'UPDATE "{self._table_name}" SET data=? WHERE id=?', (encrypted, event_id))

    def _backfill_event_index(self) -> None:
        """Build operational metadata once; payloads remain encrypted at rest."""
        rows = self._connection.execute(
            f'''
            SELECT e.id, e.data, s.sequence
            FROM "{self._table_name}" AS e
            JOIN "{self._table_name}_sequence" AS s ON e.id = s.event_id
            LEFT JOIN "{self._table_name}_index" AS x ON e.id = x.event_id
            WHERE x.event_id IS NULL
            ORDER BY s.sequence
            '''
        ).fetchall()
        for event_id, raw, sequence in rows:
            event = EventSerializer().deserialize(self._decode_raw(raw))
            mission_id = event.payload.get("mission_id") if isinstance(event.payload, dict) else None
            if mission_id is None and event.aggregate_type == "mission":
                mission_id = event.aggregate_id
            self._connection.execute(
                f'''INSERT INTO "{self._table_name}_index"
                    (event_id, sequence, event_type, aggregate_type, aggregate_id, mission_id)
                    VALUES (?, ?, ?, ?, ?, ?)''',
                (event_id, int(sequence), event.type, event.aggregate_type, event.aggregate_id, mission_id),
            )
        # Existing metadata rows from an earlier index schema need their
        # mission linkage populated as well.
        rows = self._connection.execute(
            f'''SELECT e.id, e.data FROM "{self._table_name}" AS e
                JOIN "{self._table_name}_index" AS x ON e.id=x.event_id
                WHERE x.mission_id IS NULL'''
        ).fetchall()
        for event_id, raw in rows:
            event = EventSerializer().deserialize(self._decode_raw(raw))
            mission_id = event.payload.get("mission_id") if isinstance(event.payload, dict) else None
            if mission_id is None and event.aggregate_type == "mission":
                mission_id = event.aggregate_id
            if mission_id is not None:
                self._connection.execute(
                    f'UPDATE "{self._table_name}_index" SET mission_id=? WHERE event_id=?',
                    (mission_id, event_id),
                )

    @staticmethod
    def _hash_payload(event: Event, sequence: int, previous_hash: str | None) -> str:
        canonical = json.dumps(
            {
                "event": EventSerializer().serialize(event),
                "sequence": sequence,
                "previous_hash": previous_hash,
            },
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        ).encode("utf-8")
        return hashlib.sha256(canonical).hexdigest()

    def _backfill_integrity(self) -> None:
        rows = self._connection.execute(
            f"""
            SELECT e.data, s.sequence
            FROM "{self._table_name}" AS e
            JOIN "{self._table_name}_sequence" AS s ON e.id = s.event_id
            LEFT JOIN "{self._table_name}_integrity" AS i ON e.id = i.event_id
            WHERE i.event_id IS NULL
            ORDER BY s.sequence
            """
        ).fetchall()
        previous = self._connection.execute(
            f'SELECT content_hash FROM "{self._table_name}_integrity" ORDER BY sequence DESC LIMIT 1'
        ).fetchone()
        previous_hash = previous[0] if previous else None
        for raw, sequence in rows:
            event = EventSerializer().deserialize(self._decode_raw(raw))
            content_hash = self._hash_payload(event, int(sequence), previous_hash)
            self._connection.execute(
                f'INSERT INTO "{self._table_name}_integrity" (event_id, sequence, content_hash, previous_hash) VALUES (?, ?, ?, ?)',
                (event.id, int(sequence), content_hash, previous_hash),
            )
            previous_hash = content_hash

    def verify_integrity(self) -> bool:
        with self._lock:
            rows = self._connection.execute(
                f"""
                SELECT e.data, s.sequence, i.content_hash, i.previous_hash
                FROM "{self._table_name}" AS e
                JOIN "{self._table_name}_sequence" AS s ON e.id = s.event_id
                JOIN "{self._table_name}_integrity" AS i ON e.id = i.event_id
                ORDER BY s.sequence
                """
            ).fetchall()
        count_row = self._connection.execute(
            f'SELECT COUNT(*) FROM "{self._table_name}"'
        ).fetchone()
        if count_row is None or int(count_row[0]) != len(rows):
            return False
        previous = None
        expected_sequence = 1
        for raw, sequence, stored_hash, stored_previous in rows:
            if int(sequence) != expected_sequence:
                return False
            event = EventSerializer().deserialize(self._decode_raw(raw))
            if stored_previous != previous:
                return False
            expected = self._hash_payload(event, int(sequence), previous)
            if expected != stored_hash:
                return False
            previous = stored_hash
            expected_sequence += 1
        return True

    def append_if_sequence(self, event: Event, expected_sequence: int) -> Event:
        """Append only if the stream is still at the caller's expected sequence."""
        if isinstance(expected_sequence,bool) or expected_sequence < 0:
            raise ValueError("expected_sequence must be a non-negative integer")
        with self._lock:
            current=int(self._connection.execute(f'SELECT COALESCE(MAX(sequence),0) FROM "{self._table_name}_sequence"').fetchone()[0])
            if current != expected_sequence:
                raise RuntimeError(f"optimistic concurrency conflict: expected {expected_sequence}, current {current}")
            return self.append(event)

    def append(self, event: Event) -> Event:
        # Event data and its authoritative sequence must be committed together.
        # A shared connection can receive concurrent publishes from independent
        # agents, so the read-increment-write sequence is protected as one unit.
        with self._lock:
            existing = self._repository.get(event.id)

            if existing is not None:
                # Event IDs are immutable identity. Re-delivery of the exact
                # same event is idempotent, but reusing an ID for different
                # content would silently rewrite history and corrupt replay.
                incoming = EventSerializer().serialize(event)
                persisted = EventSerializer().serialize(existing)
                if incoming != persisted:
                    raise ValueError(
                        f"event id {event.id!r} already exists with different content"
                    )
                return existing

            if existing is None:
                cursor = self._connection.execute(
                    f'''
                    SELECT COALESCE(MAX(sequence), 0) + 1
                    FROM "{self._table_name}_sequence"
                    '''
                )
                next_sequence = int(cursor.fetchone()[0])

                self._repository.save(event)

                self._connection.execute(
                    f'''
                    INSERT INTO "{self._table_name}_sequence"
                        (event_id, sequence)
                    VALUES (?, ?)
                    ''',
                    (event.id, next_sequence),
                )
                previous = self._connection.execute(
                    f'SELECT content_hash FROM "{self._table_name}_integrity" ORDER BY sequence DESC LIMIT 1'
                ).fetchone()
                previous_hash = previous[0] if previous else None
                content_hash = self._hash_payload(event, next_sequence, previous_hash)
                self._connection.execute(
                    f'INSERT INTO "{self._table_name}_integrity" (event_id, sequence, content_hash, previous_hash) VALUES (?, ?, ?, ?)',
                    (event.id, next_sequence, content_hash, previous_hash),
                )
                self._connection.execute(
                    f'''INSERT INTO "{self._table_name}_index"
                        (event_id, sequence, event_type, aggregate_type, aggregate_id, mission_id)
                        VALUES (?, ?, ?, ?, ?, ?)''',
                    (event.id, next_sequence, event.type, event.aggregate_type, event.aggregate_id,
                 (event.payload.get("mission_id") if isinstance(event.payload, dict) else None)
                 or (event.aggregate_id if event.aggregate_type == "mission" else None)),
                )
                if self._connection not in _MANAGED_CONNECTIONS:
                    self._connection.commit()
            else:
                self._repository.save(event)

        return event

    def archive_before(self, destination: str | Path, cutoff: datetime) -> int:
        """Copy old events to an append-only JSONL archive without deleting history."""
        if cutoff.tzinfo is None: raise ValueError("cutoff must be timezone-aware")
        destination=Path(destination); destination.parent.mkdir(parents=True,exist_ok=True)
        count=0
        with destination.open("a", encoding="utf-8") as out:
            for event in self.list():
                if event.at < cutoff:
                    out.write(json.dumps(EventSerializer().serialize(event),sort_keys=True,separators=(",",":"),default=str)+"\n")
                    count += 1
        return count

    def checkpoint(self, mode: str = "PASSIVE") -> tuple[int, int, int]:
        return self._repository.checkpoint(mode)

    def get(self, event_id: str) -> Optional[Event]:
        with self._lock:
            return self._repository.get(event_id)

    def sequence(self, event_id: str) -> Optional[int]:
        with self._lock:
            row = self._connection.execute(
                f'''
                SELECT sequence
                FROM "{self._table_name}_sequence"
                WHERE event_id = ?
                ''',
                (event_id,),
            ).fetchone()

        return None if row is None else int(row[0])

    def latest_sequence(self) -> int:
        with self._lock:
            row = self._connection.execute(
                f'SELECT COALESCE(MAX(sequence), 0) FROM "{self._table_name}_sequence"'
            ).fetchone()
        return int(row[0]) if row else 0

    def list_after_sequence(self, sequence: int) -> Iterable[Event]:
        with self._lock:
            rows = self._connection.execute(
                f'''
                SELECT e.data
                FROM "{self._table_name}" AS e
                JOIN "{self._table_name}_sequence" AS s
                    ON e.id = s.event_id
                WHERE s.sequence > ?
                ORDER BY s.sequence
                ''',
                (sequence,),
            ).fetchall()

        import json

        return [
            self._serializer.deserialize(self._decode_raw(row[0]))
            for row in rows
        ]

    def list(self, event_type: Optional[str] = None) -> Iterable[Event]:
        with self._lock:
            if event_type is None:
                rows = self._connection.execute(
                    f'''SELECT e.data FROM "{self._table_name}" AS e
                        JOIN "{self._table_name}_sequence" AS s ON e.id=s.event_id
                        ORDER BY s.sequence'''
                ).fetchall()
            else:
                rows = self._connection.execute(
                    f'''SELECT e.data FROM "{self._table_name}" AS e
                        JOIN "{self._table_name}_index" AS x ON e.id=x.event_id
                        WHERE x.event_type=? ORDER BY x.sequence''',
                    (event_type,),
                ).fetchall()
        return [self._serializer.deserialize(self._decode_raw(row[0])) for row in rows]

    def list_by_aggregate_type(self, aggregate_type: str) -> list[Event]:
        """Return only events for one aggregate type using the plaintext index."""
        if not isinstance(aggregate_type, str) or not aggregate_type:
            raise ValueError("aggregate_type must be a non-empty string")
        with self._lock:
            rows = self._connection.execute(
                f'''SELECT e.data FROM "{self._table_name}" AS e
                    JOIN "{self._table_name}_index" AS x ON e.id=x.event_id
                    WHERE x.aggregate_type=? ORDER BY x.sequence''',
                (aggregate_type,),
            ).fetchall()
        return [self._serializer.deserialize(self._decode_raw(row[0])) for row in rows]

    def list_by_mission_id(self, mission_id: str) -> list[Event]:
        """Return only events explicitly associated with one mission."""
        if not isinstance(mission_id, str) or not mission_id:
            raise ValueError("mission_id must be a non-empty string")
        with self._lock:
            rows = self._connection.execute(
                f'''SELECT e.data FROM "{self._table_name}" AS e
                    JOIN "{self._table_name}_index" AS x ON e.id=x.event_id
                    WHERE x.mission_id=? ORDER BY x.sequence''',
                (mission_id,),
            ).fetchall()
        return [self._serializer.deserialize(self._decode_raw(row[0])) for row in rows]

    def list_recent(self, limit: int = 100) -> list[Event]:
        """Return only the newest events without materializing the full log."""
        if isinstance(limit, bool) or not isinstance(limit, int) or limit < 1 or limit > 10000:
            raise ValueError("limit must be an integer between 1 and 10000")
        with self._lock:
            rows = self._connection.execute(
                f'''SELECT e.data FROM "{self._table_name}" AS e
                    JOIN "{self._table_name}_sequence" AS s ON e.id=s.event_id
                    ORDER BY s.sequence DESC LIMIT ?''',
                (limit,),
            ).fetchall()
        return [self._serializer.deserialize(self._decode_raw(row[0])) for row in reversed(rows)]

    def after_commit(self, callback) -> None:
        """Register delivery work for execution only after DB commit."""
        self._repository.after_commit(callback)

    @contextmanager
    def transaction(self) -> Iterator[None]:
        """Execute event-store operations in the shared SQLite transaction.

        Delegating to SQLiteRepository is important: UnitOfWork can enter a
        different repository first, so commit/rollback hooks must remain
        connection-scoped rather than being duplicated here.
        """
        with self._repository.transaction():
            yield
