from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Iterable, Optional

from ocean.domain.event import Event


class EventStore(ABC):
    """Durable ordered append-only event history."""

    @abstractmethod
    def append(self, event: Event) -> Event:
        ...

    @abstractmethod
    def get(self, event_id: str) -> Optional[Event]:
        ...

    @abstractmethod
    def sequence(self, event_id: str) -> Optional[int]:
        """Return the durable sequence assigned to an event."""
        ...

    @abstractmethod
    def list_after_sequence(self, sequence: int) -> Iterable[Event]:
        """Return events strictly after a durable sequence, in order."""
        ...

    @abstractmethod
    def list(self, event_type: Optional[str] = None) -> Iterable[Event]:
        """Return the complete event history in durable order."""
        ...
