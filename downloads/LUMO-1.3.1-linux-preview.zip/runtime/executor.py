from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict, Optional

from .control import ExecutionContext
from .types import ExecutionRequest, ExecutionResult


class CapabilityExecutor(ABC):
    """Mechanism that actually performs a capability operation."""

    @abstractmethod
    def execute(
        self,
        request: ExecutionRequest,
        context: ExecutionContext,
    ) -> ExecutionResult:
        """Perform the requested operation."""
        raise NotImplementedError


class ExecutorRegistry:
    """Maps execution strategies to concrete executors.

    Optionally an ExecutorRegistry may be configured with an authorization
    policy, a resource capacity plane and a capability registry. When any of
    those enforcement artifacts are provided the registry will return an
    enforcing wrapper around the registered executor that performs:
      - capability discovery (does the capability and operation exist?)
      - authorization evaluation (does the principal have required permissions?)
      - resource admission (try to reserve declared resources prior to execution)

    The wrapper releases any created reservation after the executor returns
    (or raises), so callers need not manage reservations themselves.
    """

    def __init__(
        self,
        *,
        auth_policy: "Optional[object]" = None,
        resource_plane: "Optional[object]" = None,
        capabilities: "Optional[object]" = None,
    ) -> None:
        # Keep the simple mapping of strategy -> executor.
        self._executors: Dict[str, CapabilityExecutor] = {}

        # Optional enforcement artifacts. Types are kept loose here to avoid
        # tight import-time coupling; calling code should pass the real
        # instances from the control-plane wiring.
        self._auth_policy = auth_policy
        self._resource_plane = resource_plane
        self._capabilities = capabilities

    def register(
        self,
        strategy: str,
        executor: CapabilityExecutor,
    ) -> None:
        if strategy in self._executors:
            raise ValueError(
                f"executor strategy '{strategy}' already registered"
            )

        self._executors[strategy] = executor

    def get(self, strategy: str) -> CapabilityExecutor:
        try:
            executor = self._executors[strategy]
        except KeyError as exc:
            raise KeyError(
                f"no executor registered for strategy '{strategy}'"
            ) from exc

        # If no enforcement artifacts were provided, return the raw executor
        # unchanged for backwards compatibility.
        if not any((self._auth_policy, self._resource_plane, self._capabilities)):
            return executor

        # Otherwise return a thin enforcing wrapper.
        return _EnforcingExecutor(
            underlying=executor,
            auth_policy=self._auth_policy,
            resource_plane=self._resource_plane,
            capabilities=self._capabilities,
        )


class _EnforcingExecutor(CapabilityExecutor):
    """Wrapper executor that enforces discovery, authorization and
    resource admission before calling the underlying executor.

    The enforcement artifacts are intentionally typed as 'object' to avoid
    circular imports in this module; the wrapper only calls the expected
    methods if the objects are provided. Callers wiring the runtime should
    pass instances of:
      - ocean.authorization.policy.AuthorizationPolicy
      - ocean.resources.capacity.ResourceCapacityPlane
      - ocean.domain.capability.CapabilityRegistry

    The wrapper is intentionally small and deterministic so tests can assert
    failures without needing full integration with isolation subsystems.
    """

    def __init__(
        self,
        *,
        underlying: CapabilityExecutor,
        auth_policy: Optional[object] = None,
        resource_plane: Optional[object] = None,
        capabilities: Optional[object] = None,
    ) -> None:
        self._underlying = underlying
        self._auth_policy = auth_policy
        self._resource_plane = resource_plane
        self._capabilities = capabilities

    def execute(self, request: ExecutionRequest, context: ExecutionContext) -> ExecutionResult:
        # 1) Capability discovery: if a capability registry was supplied
        # ensure the capability and operation exist before proceeding.
        capability_spec = None
        if self._capabilities is not None:
            try:
                # CapabilityRegistry implementations in the codebase expose a
                # get_operation(capability, operation) helper; if it raises
                # KeyError we re-raise with a clearer message here.
                self._capabilities.get_operation(request.capability, request.operation)
                # Fetch the full spec too so authorization (below) can use the
                # SAME canonical permission set that capability discovery and
                # the primary ExecutionRuntime.execute() governance path use,
                # instead of inventing a second, incompatible permission
                # scheme here.
                capability_spec = self._capabilities.get(request.capability)
            except Exception as exc:  # any error during discovery -> fail fast
                raise RuntimeError(
                    f"capability discovery failed for {request.capability!r}.{request.operation!r}: {exc}"
                ) from exc

        # 2) Authorization: if an authorization policy was provided, attempt
        # to evaluate whether the calling principal is permitted to invoke
        # the specific capability.operation. We construct a simple
        # AuthorizationRequest-like object with the common fields expected by
        # the policy implementation. If required data is not available we
        # fail deterministically.
        if self._auth_policy is not None:
            # Determine a principal id. Prefer context.principal_id, then
            # request.agent_id, then context.agent_id. If none exist, deny.
            principal = None
            principal = getattr(context, "principal_id", principal)
            if principal is None:
                principal = getattr(request, "agent_id", principal)
            if principal is None:
                principal = getattr(context, "agent_id", principal)

            if principal is None:
                raise PermissionError("authorization failed: missing principal identity")

            # CANONICAL CONTRACT: the only source of truth for what a
            # principal must hold to invoke a capability is
            # CapabilitySpec.requires_permissions (dot-separated, e.g.
            # "terminal.execute", declared once per capability). This is the
            # same set ExecutionRuntime.execute() passes into
            # GovernanceEngine/AuthorizationEngine on the primary production
            # path (see runtime/runtime.py). Previously this wrapper instead
            # fabricated an operation-scoped permission string of the form
            # f"{capability}:{operation}" (colon-separated, one per
            # operation). That string never matches anything a
            # CapabilitySpec declares or that any policy is configured
            # against, so this code path was either dead (never wired with
            # auth_policy) or, if wired, would deny every single call
            # regardless of the principal's real, correctly-granted
            # permissions -- a duplicate and inconsistent enforcement
            # boundary. We now require the same permission set as the
            # canonical contract.
            if capability_spec is not None:
                required_permissions = frozenset(capability_spec.requires_permissions)
            else:
                # No capability registry was supplied to look up the spec.
                # Fall back to the capability-level dotted convention rather
                # than reintroducing the colon/operation-scoped scheme.
                required_permissions = frozenset({f"{request.capability}.{request.operation}"})

            try:
                # Many AuthorizationPolicy implementations expose an
                # evaluate(request) method that returns (bool, tuple[str,...]).
                # Construct a light-weight object with the expected attributes.
                auth_request = type(
                    "_AuthReq",
                    (),
                    {
                        "principal_id": principal,
                        "required_permissions": tuple(required_permissions),
                    },
                )()

                allowed, info = self._auth_policy.evaluate(auth_request)
            except Exception as exc:
                raise PermissionError(
                    f"authorization evaluation error for principal {principal!r}: {exc}"
                ) from exc

            if not allowed:
                # info is expected to be a tuple/list of messages; use the
                # first entry if present for clarity.
                reason = info[0] if info else "authorization denied"
                raise PermissionError(f"authorization denied: {reason}")

        # 3) Resource admission/reservation: if a resource plane was provided
        # try to reserve declared resources for the execution. If admission
        # fails the underlying executor must not be invoked. If accepted we
        # ensure the reservation is released after the execution finishes.
        reservation_id: Optional[str] = None
        reservation_obj = None

        if self._resource_plane is not None:
            try:
                admission = self._resource_plane.try_reserve(request)
            except Exception as exc:
                raise RuntimeError(f"resource admission error: {exc}") from exc

            if not admission.admitted:
                raise RuntimeError(f"resource admission rejected: {admission.reason}")

            # remember reservation so we can release it later
            reservation_obj = admission.reservation
            reservation_id = reservation_obj.reservation_id

        # 4) Delegate to the underlying executor. Ensure we release any
        # reservation even if the underlying execution raises.
        try:
            result = self._underlying.execute(request, context)
            return result
        finally:
            if reservation_id is not None:
                try:
                    # resource_plane.release may raise; wrap to avoid
                    # masking the original execution error but still surface
                    # problems during cleanup.
                    self._resource_plane.release(reservation_id)
                except Exception as exc:
                    # Release failures are significant but should not hide
                    # the original execution result/exception. Re-raise as a
                    # runtime error to make them visible to callers.
                    raise RuntimeError(
                        f"failed to release resource reservation {reservation_id!r}: {exc}"
                    ) from exc


