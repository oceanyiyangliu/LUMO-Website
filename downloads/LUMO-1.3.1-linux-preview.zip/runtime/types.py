from __future__ import annotations

import json

from dataclasses import dataclass, field

from typing import Any, Dict, Optional

from .resources import ExecutionResourceLimits
from ocean.domain.enums import OrchestrationMode


@dataclass(frozen=True)
class ExecutionRequest:
    task_id: str
    capability: str
    operation: str
    agent_id: Optional[str] = None
    principal_id: Optional[str] = None
    mission_id: Optional[str] = None
    mode: OrchestrationMode = OrchestrationMode.STANDARD
    arguments: Dict[str, Any] = field(default_factory=dict)
    correlation_id: Optional[str] = None
    causation_id: Optional[str] = None
    source: Optional[str] = None
    execution_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    resource_limits: ExecutionResourceLimits = field(
        default_factory=ExecutionResourceLimits
    )

    def __post_init__(self) -> None:
        object.__setattr__(self, "arguments", dict(self.arguments))
        object.__setattr__(self, "metadata", dict(self.metadata))


@dataclass(frozen=True)
class ExecutionResult:
    success: bool
    result: Any = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def succeeded(
        cls,
        result: Any = None,
        *,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "ExecutionResult":
        return cls(
            success=True,
            result=result,
            metadata=dict(metadata or {}),
        )

    @classmethod
    def failed(
        cls,
        error: str,
        *,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "ExecutionResult":
        return cls(
            success=False,
            error=error,
            metadata=dict(metadata or {}),
        )


class ExecutionResultCodec:
    """
    Converts ExecutionResult values to and from the canonical wire format.

    The wire format is JSON-compatible and intentionally independent of
    Runtime, Executor, and IsolationBackend implementation details.
    """

    @staticmethod
    def encode(result: ExecutionResult) -> str:
        payload = {
            "success": result.success,
            "result": result.result,
            "error": result.error,
            "metadata": result.metadata,
        }

        try:
            return json.dumps(payload)
        except (TypeError, ValueError) as exc:
            raise ValueError(
                "execution result is not JSON serializable"
            ) from exc

    @staticmethod
    def decode(payload: str) -> ExecutionResult:
        try:
            data = json.loads(payload)
        except (TypeError, ValueError, json.JSONDecodeError) as exc:
            raise ValueError(
                "invalid execution result payload"
            ) from exc

        if not isinstance(data, dict):
            raise ValueError(
                "execution result payload must decode to an object"
            )

        required = {"success", "result", "error", "metadata"}

        if set(data) != required:
            raise ValueError(
                "execution result payload has invalid fields"
            )

        if not isinstance(data["success"], bool):
            raise ValueError(
                "execution result 'success' must be a boolean"
            )

        if data["error"] is not None and not isinstance(
            data["error"], str
        ):
            raise ValueError(
                "execution result 'error' must be a string or null"
            )

        if not isinstance(data["metadata"], dict):
            raise ValueError(
                "execution result 'metadata' must be an object"
            )

        return ExecutionResult(
            success=data["success"],
            result=data["result"],
            error=data["error"],
            metadata=data["metadata"],
        )
