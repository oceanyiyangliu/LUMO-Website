from __future__ import annotations

from threading import RLock
from typing import Callable, Optional, TypeVar


T = TypeVar("T")


class ExecutionController:
    """Provides atomic terminal-state commitment for one execution."""

    def __init__(self) -> None:
        self._lock = RLock()
        self._terminal = False

    @property
    def is_terminal(self) -> bool:
        with self._lock:
            return self._terminal

    def commit_terminal(self, action: Callable[[], T]) -> Optional[T]:
        """
        Atomically commit the first successful terminal transition.

        The controller lock is held while the terminal action executes, so
        concurrent terminal contenders cannot both commit.

        If the action raises, the terminal state is not committed.
        """
        with self._lock:
            if self._terminal:
                return None

            result = action()
            self._terminal = True
            return result
