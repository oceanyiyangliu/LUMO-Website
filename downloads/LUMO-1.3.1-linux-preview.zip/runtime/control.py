from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Optional

from .resources import ExecutionResourceLimits



class ExecutionCancelled(Exception):
    """Raised when an execution has been cancelled."""


class ExecutionTimedOut(Exception):
    """Raised when an execution exceeds its deadline."""


class CancellationToken:
    """Thread-safe cooperative cancellation primitive."""

    def __init__(self, event: threading.Event | None = None) -> None:
        self._event = event or threading.Event()

    @classmethod
    def from_event(cls, event: threading.Event) -> "CancellationToken":
        """Bind runtime cancellation directly to an owning control event."""
        if not isinstance(event, threading.Event):
            raise TypeError("event must be a threading.Event")
        return cls(event)

    def cancel(self) -> None:
        self._event.set()

    @property
    def is_cancelled(self) -> bool:
        return self._event.is_set()

    def raise_if_cancelled(self) -> None:
        if self.is_cancelled:
            raise ExecutionCancelled("execution cancelled")


@dataclass(frozen=True)
class ExecutionContext:
    """Runtime context supplied to a capability executor."""

    execution_id: str
    cancellation: CancellationToken
    deadline: Optional[float] = None
    resource_limits: ExecutionResourceLimits = ExecutionResourceLimits()

    def raise_if_cancelled(self) -> None:
        self.cancellation.raise_if_cancelled()

    def raise_if_timed_out(self) -> None:
        if self.deadline is not None and time.monotonic() >= self.deadline:
            raise ExecutionTimedOut("execution timed out")

    def check(self) -> None:
        self.raise_if_cancelled()
        self.raise_if_timed_out()
