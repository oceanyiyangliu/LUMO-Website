from __future__ import annotations

from typing import Optional

from ocean.domain.agent import Agent
from ocean.domain.enums import AgentStatus
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus


class AgentController:
    """
    Authoritative lifecycle boundary for Agents.

    Agent objects contain domain state.
    AgentController owns controlled lifecycle transitions and emits
    auditable AgentStateChanged events.
    """

    def __init__(
        self,
        *,
        event_bus: Optional[EventBus] = None,
    ) -> None:
        self._event_bus = event_bus

    def create(
        self,
        name: str,
        role: str,
        *,
        capabilities: Optional[set[str]] = None,
        metadata: Optional[dict] = None,
    ) -> Agent:
        agent = Agent(
            name=name,
            role=role,
            capabilities=set(capabilities or ()),
            metadata=dict(metadata or {}),
        )

        self._publish(
            "AgentCreated",
            agent,
            previous_status=None,
        )

        return agent

    def activate(
        self,
        agent: Agent,
        *,
        task_id: Optional[str] = None,
    ) -> Agent:
        self._transition(
            agent,
            AgentStatus.RUNNING,
            task_id=task_id,
        )
        return agent

    def assign(
        self,
        agent: Agent,
        *,
        task_id: Optional[str] = None,
    ) -> Agent:
        self._transition(
            agent,
            AgentStatus.ASSIGNED,
            task_id=task_id,
        )
        return agent

    def wait(
        self,
        agent: Agent,
        *,
        task_id: Optional[str] = None,
    ) -> Agent:
        effective_task_id = (
            task_id
            if task_id is not None
            else agent.current_task_id
        )

        self._transition(
            agent,
            AgentStatus.WAITING,
            task_id=effective_task_id,
        )
        return agent

    def resume(
        self,
        agent: Agent,
        *,
        task_id: Optional[str] = None,
    ) -> Agent:
        effective_task_id = (
            task_id
            if task_id is not None
            else agent.current_task_id
        )

        self._transition(
            agent,
            AgentStatus.RUNNING,
            task_id=effective_task_id,
        )
        return agent

    def background(self, agent: Agent) -> Agent:
        self._transition(
            agent,
            AgentStatus.BACKGROUND,
            task_id=None,
        )
        return agent

    def idle(self, agent: Agent) -> Agent:
        self._transition(
            agent,
            AgentStatus.IDLE,
            task_id=None,
        )
        return agent

    def fail(self, agent: Agent) -> Agent:
        self._transition(
            agent,
            AgentStatus.FAILED,
            task_id=None,
        )
        return agent

    def terminate(self, agent: Agent) -> Agent:
        self._transition(
            agent,
            AgentStatus.TERMINATED,
            task_id=None,
        )
        return agent

    def _transition(
        self,
        agent: Agent,
        new_status: AgentStatus,
        *,
        task_id: Optional[str],
    ) -> None:
        previous_status = agent.status

        agent.transition(new_status)

        if new_status in {
            AgentStatus.IDLE,
            AgentStatus.BACKGROUND,
            AgentStatus.FAILED,
            AgentStatus.TERMINATED,
        }:
            agent.current_task_id = None
        else:
            agent.current_task_id = task_id

        self._publish(
            "AgentStateChanged",
            agent,
            previous_status=previous_status,
        )

    def _publish(
        self,
        event_type: str,
        agent: Agent,
        *,
        previous_status: Optional[AgentStatus],
    ) -> None:
        if self._event_bus is None:
            return

        payload = {
            "agent_id": agent.id,
            "status": agent.status.value,
            "current_task_id": agent.current_task_id,
        }

        if previous_status is not None:
            payload["previous_status"] = previous_status.value

        self._event_bus.publish(
            Event(
                type=event_type,
                payload=payload,
                aggregate_type="agent",
                aggregate_id=agent.id,
            )
        )
