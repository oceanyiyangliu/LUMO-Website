from __future__ import annotations

import multiprocessing
import os
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from multiprocessing.connection import Connection
from typing import Optional

import psutil

from .control import (
    ExecutionCancelled,
    ExecutionContext,
    ExecutionTimedOut,
)
from .executor import CapabilityExecutor
from .resources import ExecutionResourceLimits
from .types import ExecutionRequest, ExecutionResult, ExecutionResultCodec
from ocean.domain.capability import CapabilityIsolationPolicy, CapabilityRegistry


class IsolationBackend(ABC):
    @abstractmethod
    def execute(
        self,
        executor: CapabilityExecutor,
        request: ExecutionRequest,
        context: ExecutionContext,
    ) -> ExecutionResult:
        raise NotImplementedError


class InProcessIsolationBackend(IsolationBackend):
    def execute(
        self,
        executor: CapabilityExecutor,
        request: ExecutionRequest,
        context: ExecutionContext,
    ) -> ExecutionResult:
        try:
            result = executor.execute(request, context)

            if not isinstance(result, ExecutionResult):
                return ExecutionResult.failed(
                    "executor returned an invalid result",
                    metadata={
                        "failure_type": "invalid_executor_result",
                        "result_type": type(result).__name__,
                    },
                )

            return result

        except Exception as exc:
            return ExecutionResult.failed(
                str(exc),
                metadata={
                    "failure_type": "executor_exception",
                    "exception_type": type(exc).__name__,
                },
            )


class CapabilityIsolationRouter(IsolationBackend):
    """Select existing isolation backends from typed capability policy."""

    def __init__(
        self,
        *,
        capabilities: CapabilityRegistry,
        in_process: IsolationBackend | None = None,
        process: IsolationBackend | None = None,
    ) -> None:
        self._capabilities = capabilities
        self._in_process = in_process or InProcessIsolationBackend()
        self._process = process or ProcessIsolationBackend()

    def execute(
        self,
        executor: CapabilityExecutor,
        request: ExecutionRequest,
        context: ExecutionContext,
    ) -> ExecutionResult:
        policy = self._capabilities.get(request.capability).execution_policy
        backend = (
            self._process
            if policy.isolation is not CapabilityIsolationPolicy.IN_PROCESS_SAFE
            else self._in_process
        )
        return backend.execute(executor, request, context)


@dataclass(frozen=True)
class WorkerExecutionContext:
    execution_id: str
    deadline: Optional[float] = None
    resource_limits: ExecutionResourceLimits = ExecutionResourceLimits()


def _apply_output_limit(
    result: ExecutionResult,
    resource_limits: ExecutionResourceLimits,
) -> ExecutionResult:
    limit = resource_limits.max_output_bytes

    if limit is None:
        return result

    encoded = ExecutionResultCodec.encode(result)

    if len(encoded) <= limit:
        return result

    return ExecutionResult.failed(
        "execution output exceeded resource limit",
        metadata={
            "failure_type": "resource_limit_exceeded",
            "resource": "max_output_bytes",
            "limit": limit,
            "observed": len(encoded),
        },
    )


_SAFE_WORKER_ENV = frozenset({
    "PATH", "HOME", "TMPDIR", "TMP", "TEMP", "LANG", "LC_ALL", "LC_CTYPE",
    "USER", "LOGNAME", "SystemRoot", "WINDIR", "COMSPEC",
})


def _sanitize_worker_environment() -> None:
    """Remove inherited credentials/configuration from isolated capability workers."""
    safe = {key: value for key, value in os.environ.items() if key in _SAFE_WORKER_ENV}
    os.environ.clear()
    os.environ.update(safe)


def _process_worker(
    connection: Connection,
    executor: CapabilityExecutor,
    request: ExecutionRequest,
    context: WorkerExecutionContext,
) -> None:
    _sanitize_worker_environment()
    try:
        result = executor.execute(request, context)

        if not isinstance(result, ExecutionResult):
            result = ExecutionResult.failed(
                "executor returned an invalid result",
                metadata={
                    "failure_type": "invalid_executor_result",
                    "result_type": type(result).__name__,
                },
            )

        result = _apply_output_limit(
            result,
            context.resource_limits,
        )

    except Exception as exc:
        result = ExecutionResult.failed(
            str(exc),
            metadata={
                "failure_type": "executor_exception",
                "exception_type": type(exc).__name__,
            },
        )

    try:
        connection.send(ExecutionResultCodec.encode(result))
    except Exception:
        pass
    finally:
        connection.close()


class ProcessIsolationBackend(IsolationBackend):
    """
    Dedicated process execution boundary.

    The parent owns lifecycle enforcement:
        cancellation
        wall-clock timeout
        CPU budget
        worker lifetime
        termination
        cleanup
    """

    _POLL_INTERVAL_SECONDS = 0.05
    _TERMINATION_GRACE_SECONDS = 0.25

    def __init__(self, *, start_method: str | None = None) -> None:
        if start_method is None:
            start_method = "spawn"

        self._context = multiprocessing.get_context(start_method)

    def execute(
        self,
        executor: CapabilityExecutor,
        request: ExecutionRequest,
        context: ExecutionContext,
    ) -> ExecutionResult:
        parent_connection, child_connection = self._context.Pipe(
            duplex=False
        )

        worker_context = WorkerExecutionContext(
            execution_id=context.execution_id,
            deadline=context.deadline,
            resource_limits=context.resource_limits,
        )

        process = self._context.Process(
            target=_process_worker,
            args=(
                child_connection,
                executor,
                request,
                worker_context,
            ),
        )

        try:
            process.start()
        except Exception as exc:
            child_connection.close()
            parent_connection.close()
            self._cleanup_process(process)
            return ExecutionResult.failed(
                "isolated worker failed to start",
                metadata={
                    "failure_type": "worker_start_failure",
                    "exception_type": type(exc).__name__,
                },
            )

        child_connection.close()

        try:
            try:
                return self._monitor_worker(
                    process=process,
                    connection=parent_connection,
                    context=context,
                )
            except EOFError:
                return ExecutionResult.failed(
                    "isolated worker exited without returning a result",
                    metadata={
                        "failure_type": "worker_crash",
                    },
                )

        finally:
            parent_connection.close()
            self._cleanup_process(process)

    def _monitor_worker(
        self,
        *,
        process: multiprocessing.Process,
        connection: Connection,
        context: ExecutionContext,
    ) -> ExecutionResult:
        try:
            process_info = psutil.Process(process.pid)
        except (psutil.NoSuchProcess, psutil.AccessDenied, ValueError):
            # A very short-lived worker can disappear between process.start()
            # and the first monitor tick. Treat that as a normal worker-crash
            # path instead of leaking a psutil exception out of the runtime.
            process_info = None

        while True:
            if connection.poll(self._POLL_INTERVAL_SECONDS):
                result_data = connection.recv()
                return ExecutionResultCodec.decode(result_data)

            if context.cancellation.is_cancelled:
                self._terminate_worker(process)
                raise ExecutionCancelled()

            if context.deadline is not None:
                if time.monotonic() >= context.deadline:
                    self._terminate_worker(process)
                    raise ExecutionTimedOut()

            cpu_limit = context.resource_limits.cpu_seconds

            if cpu_limit is not None and process_info is not None:
                cpu_seconds = self._cpu_time(process_info)

                if cpu_seconds >= cpu_limit:
                    self._terminate_worker(process)
                    raise ExecutionTimedOut()

            memory_limit = context.resource_limits.memory_bytes
            if memory_limit is not None and process_info is not None:
                memory_bytes = self._memory_usage(process_info)
                if memory_bytes >= memory_limit:
                    self._terminate_worker(process)
                    raise ExecutionTimedOut()

            lifetime_limit = context.resource_limits.max_worker_lifetime_seconds
            if lifetime_limit is not None and process_info is not None:
                try:
                    worker_age = time.time() - process_info.create_time()
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    worker_age = 0.0
                if worker_age >= lifetime_limit:
                    self._terminate_worker(process)
                    raise ExecutionTimedOut()

            if not process.is_alive():
                if connection.poll(0):
                    result_data = connection.recv()
                    return ExecutionResultCodec.decode(result_data)

                return ExecutionResult.failed(
                    "isolated worker exited without returning a result",
                    metadata={
                        "failure_type": "worker_crash",
                    },
                )

    @staticmethod
    def _process_tree(process_info: psutil.Process) -> list[psutil.Process]:
        """Return the worker and its descendants for aggregate accounting.

        Resource limits belong to one execution, not merely its Python
        supervisor process. A capability may legitimately spawn children, so
        measuring only the root would let a subprocess evade CPU/memory limits.
        Accounting is intentionally conservative: RSS is summed across the
        tree, which may over-count shared pages but can never under-enforce
        the requested ceiling because of sharing.
        """
        try:
            return [process_info, *process_info.children(recursive=True)]
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return [process_info]

    @classmethod
    def _cpu_time(cls, process_info: psutil.Process) -> float:
        total = 0.0
        for process in cls._process_tree(process_info):
            try:
                cpu_times = process.cpu_times()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
            total += cpu_times.user + cpu_times.system
        return total

    @classmethod
    def _memory_usage(cls, process_info: psutil.Process) -> int:
        total = 0
        for process in cls._process_tree(process_info):
            try:
                total += process.memory_info().rss
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return total

    def _terminate_worker(
        self,
        process: multiprocessing.Process,
    ) -> None:
        """Terminate the worker and every descendant it created.

        Killing only the multiprocessing worker is insufficient: a capability
        can legitimately spawn a subprocess, and that child would otherwise
        survive cancellation/timeout and continue doing work outside LUMO's
        lifecycle. Descendants are captured before terminating the parent,
        then reaped in bounded phases.
        """
        if process.pid is None:
            return

        try:
            root = psutil.Process(process.pid)
            descendants = root.children(recursive=True)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            descendants = []

        # Stop children first so a surviving child cannot immediately create
        # another process while its parent is being torn down.
        for child in descendants:
            try:
                child.terminate()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass

        if process.is_alive():
            process.terminate()

        survivors = []
        for child in descendants:
            try:
                child.wait(timeout=self._TERMINATION_GRACE_SECONDS)
            except (psutil.TimeoutExpired, psutil.NoSuchProcess):
                survivors.append(child)
            except psutil.AccessDenied:
                pass

        process.join(self._TERMINATION_GRACE_SECONDS)

        if process.is_alive():
            process.kill()
            process.join(self._TERMINATION_GRACE_SECONDS)

        for child in survivors:
            try:
                child.kill()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        for child in survivors:
            try:
                child.wait(timeout=self._TERMINATION_GRACE_SECONDS)
            except (psutil.TimeoutExpired, psutil.NoSuchProcess, psutil.AccessDenied):
                pass

    @staticmethod
    def _cleanup_process(
        process: multiprocessing.Process,
    ) -> None:
        if process.pid is None:
            return

        if process.is_alive():
            process.terminate()

        process.join()
