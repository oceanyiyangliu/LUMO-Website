from __future__ import annotations

from threading import RLock
from typing import Dict, Iterable, Optional

from .handle import ExecutionHandle


class ActiveExecutionRegistry:
    """Thread-safe registry of currently active executions."""

    def __init__(self) -> None:
        self._lock = RLock()
        self._executions: Dict[str, ExecutionHandle] = {}

    def register(self, handle: ExecutionHandle) -> None:
        with self._lock:
            if handle.execution_id in self._executions:
                raise ValueError(
                    f"execution already registered: {handle.execution_id!r}"
                )

            self._executions[handle.execution_id] = handle

    def get(self, execution_id: str) -> Optional[ExecutionHandle]:
        with self._lock:
            return self._executions.get(execution_id)

    def remove(self, execution_id: str) -> Optional[ExecutionHandle]:
        with self._lock:
            return self._executions.pop(execution_id, None)

    def list(self) -> Iterable[ExecutionHandle]:
        with self._lock:
            return list(self._executions.values())
