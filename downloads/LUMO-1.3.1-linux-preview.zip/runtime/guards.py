"""Reusable execution guards for the runtime boundary."""
from __future__ import annotations

import sqlite3
import threading
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class DescriptorLimit:
    max_open_files: int = 256

    def __post_init__(self) -> None:
        if isinstance(self.max_open_files, bool) or self.max_open_files <= 0:
            raise ValueError("max_open_files must be positive")

    def validate(self) -> bool:
        try:
            import resource
            soft, _ = resource.getrlimit(resource.RLIMIT_NOFILE)
        except (ImportError, OSError):
            return False
        return soft >= self.max_open_files


class ExecutionIdempotency:
    """Durable atomic claim/replay table for execution submissions."""

    def __init__(self, path: str | Path) -> None:
        self._db = sqlite3.connect(str(path), check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA busy_timeout=5000")
        self._db.execute(
            "CREATE TABLE IF NOT EXISTS execution_keys ("
            "scope TEXT NOT NULL, key TEXT NOT NULL, execution_id TEXT NOT NULL, "
            "PRIMARY KEY(scope, key))"
        )
        self._db.commit()
        self._lock = threading.RLock()

    def claim(self, scope: str, key: str, execution_id: str) -> tuple[bool, str]:
        if not all(isinstance(v, str) and v for v in (scope, key, execution_id)):
            raise ValueError("scope, key and execution_id are required")
        with self._lock:
            try:
                self._db.execute(
                    "INSERT INTO execution_keys(scope,key,execution_id) VALUES(?,?,?)",
                    (scope, key, execution_id),
                )
                self._db.commit()
                return True, execution_id
            except sqlite3.IntegrityError:
                row = self._db.execute(
                    "SELECT execution_id FROM execution_keys WHERE scope=? AND key=?",
                    (scope, key),
                ).fetchone()
                if row is None:
                    self._db.rollback()
                    raise RuntimeError("idempotency claim conflicted but no owner exists")
                self._db.rollback()
                return False, str(row[0])

    def close(self) -> None:
        with self._lock:
            self._db.close()
