from __future__ import annotations

from threading import RLock
from typing import Iterable, Optional

from ocean.domain.agent import Agent
from ocean.domain.enums import AgentStatus


class AgentRegistry:
    """Thread-safe registry of live Agent identities."""

    def __init__(self) -> None:
        self._lock = RLock()
        self._agents: dict[str, Agent] = {}

    def register(self, agent: Agent) -> None:
        with self._lock:
            if agent.id in self._agents:
                raise ValueError(
                    f"agent already registered: {agent.id!r}"
                )

            self._agents[agent.id] = agent

    def get(self, agent_id: str) -> Optional[Agent]:
        with self._lock:
            return self._agents.get(agent_id)

    def remove(self, agent_id: str) -> Optional[Agent]:
        with self._lock:
            return self._agents.pop(agent_id, None)

    def list(self) -> Iterable[Agent]:
        with self._lock:
            return list(self._agents.values())

    def active(self) -> list[Agent]:
        with self._lock:
            return [
                agent
                for agent in self._agents.values()
                if agent.status != AgentStatus.TERMINATED
            ]

    def available(self) -> list[Agent]:
        with self._lock:
            return [
                agent
                for agent in self._agents.values()
                if agent.status in {
                    AgentStatus.IDLE,
                    AgentStatus.BACKGROUND,
                }
            ]
