from __future__ import annotations

from concurrent.futures import Future, ThreadPoolExecutor
from threading import RLock
from typing import Optional

from ocean.core.ids import new_id

from .control import CancellationToken
from .handle import ExecutionHandle
from .registry import ActiveExecutionRegistry
from .runtime import ExecutionRuntime
from .types import ExecutionRequest, ExecutionResult


class ExecutionSupervisor:
    """
    Owns asynchronous execution workers.

    Scheduling decisions do not belong here. The supervisor only ensures
    that accepted executions are run asynchronously through the Runtime.
    """

    def __init__(
        self,
        runtime: ExecutionRuntime,
        *,
        max_workers: int = 4,
        active_executions: Optional[ActiveExecutionRegistry] = None,
    ) -> None:
        if max_workers <= 0:
            raise ValueError("max_workers must be positive")

        self._runtime = runtime
        self._active_executions = (
            active_executions or runtime.active_executions
        )
        self._executor = ThreadPoolExecutor(
            max_workers=max_workers,
            thread_name_prefix="ocean-exec",
        )
        self._lock = RLock()

        # Futures are retained until observed through future().
        self._futures: dict[str, Future[ExecutionResult]] = {}

        # Execution IDs are unique for the lifetime of this supervisor.
        self._known_execution_ids: set[str] = set()

        self._shutdown = False

    @property
    def active_executions(self) -> ActiveExecutionRegistry:
        return self._active_executions

    def submit(
        self,
        request: ExecutionRequest,
        *,
        cancellation: Optional[CancellationToken] = None,
        timeout_seconds: Optional[float] = None,
    ) -> ExecutionHandle:
        with self._lock:
            if self._shutdown:
                raise RuntimeError("execution supervisor is shut down")

            execution_id = request.execution_id or new_id("exec")

            if execution_id in self._known_execution_ids:
                raise ValueError(
                    f"execution already submitted: {execution_id!r}"
                )

            token = cancellation or CancellationToken()

            handle = ExecutionHandle(
                execution_id=execution_id,
                cancellation=token,
            )

            # Reserve the ID before submitting the worker. This closes the
            # race where a very fast execution completes immediately.
            self._known_execution_ids.add(execution_id)
            self._active_executions.register(handle)

            future = self._executor.submit(
                self._run,
                handle,
                request,
                token,
                timeout_seconds,
            )

            self._futures[execution_id] = future

            future.add_done_callback(
                lambda completed: self._complete(
                    handle,
                    completed,
                )
            )

            return handle

    def _run(
        self,
        handle: ExecutionHandle,
        request: ExecutionRequest,
        cancellation: CancellationToken,
        timeout_seconds: Optional[float],
    ) -> ExecutionResult:
        execution_request = ExecutionRequest(
            task_id=request.task_id,
            capability=request.capability,
            operation=request.operation,
            agent_id=request.agent_id,
            principal_id=request.principal_id,
            mission_id=request.mission_id,
            mode=request.mode,
            arguments=dict(request.arguments),
            correlation_id=request.correlation_id,
            causation_id=request.causation_id,
            source=request.source,
            execution_id=handle.execution_id,
            resource_limits=request.resource_limits,
        )

        return self._runtime.execute(
            execution_request,
            cancellation=cancellation,
            timeout_seconds=timeout_seconds,
        )

    def _complete(
        self,
        handle: ExecutionHandle,
        future: Future[ExecutionResult],
    ) -> None:
        try:
            result = future.result()
        except Exception as exc:
            result = ExecutionResult.failed(
                str(exc),
                metadata={
                    "failure_type": "supervisor_exception",
                    "exception_type": type(exc).__name__,
                },
            )
        finally:
            handle._mark_completed(result)
            self._active_executions.remove(handle.execution_id)

    def future(
        self,
        execution_id: str,
    ) -> Optional[Future[ExecutionResult]]:
        """
        Return the execution future.

        A future remains discoverable after completion until it is explicitly
        observed through this method. This prevents a fast execution from
        disappearing between submit() and future().
        """
        with self._lock:
            return self._futures.pop(execution_id, None)

    def shutdown(self, *, wait: bool = True) -> None:
        with self._lock:
            if self._shutdown:
                return
            self._shutdown = True

        self._executor.shutdown(
            wait=wait,
            cancel_futures=True,
        )
