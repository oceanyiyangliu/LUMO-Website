from __future__ import annotations

from typing import Any

from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from persistence.repository import Repository
from ocean.domain.execution import Execution, ExecutionStatus
from ocean.core.errors import InvalidStateTransition


class ExecutionPersistence:
    """Event-driven persistence adapter for Execution lifecycle.

    Subscribes to execution-related events and persists Execution domain
    entities using the provided Repository[Execution]. Handlers are
    idempotent and tolerant of missing prior persisted state (they will
    create a minimal Execution record if necessary).
    """

    def __init__(self, *, event_bus: EventBus, executions: Repository[Execution]) -> None:
        if event_bus is None:
            raise ValueError("event_bus is required")
        if executions is None:
            raise ValueError("executions repository is required")

        self._bus = event_bus
        self._executions = executions

        # subscribe to the canonical execution lifecycle events
        self._bus.subscribe("ScheduledExecutionQueued", self._handle_queued)
        self._bus.subscribe("ScheduledExecutionDispatched", self._handle_dispatched)
        self._bus.subscribe("ScheduledExecutionCompleted", self._handle_completed)
        self._bus.subscribe("ScheduledExecutionFailed", self._handle_failed)
        self._bus.subscribe("ScheduledExecutionCancelled", self._handle_cancelled)
        self._bus.subscribe("ExecutionTimedOut", self._handle_timed_out)
        self._bus.subscribe("ExecutionCancelled", self._handle_cancelled)

    # --- helpers ---
    def _execution_id_from_event(self, event: Event) -> str | None:
        payload = event.payload or {}
        return (
            payload.get("id")
            or payload.get("execution_id")
            or event.aggregate_id
        )

    def _get_or_create(self, execution_id: str, payload: dict[str, Any]) -> Execution:
        existing = self._executions.get(execution_id)
        if existing is not None:
            return existing

        # build a minimal Execution from available payload data
        execution = Execution(
            task_id=str(payload.get("task_id") or payload.get("task") or ""),
            capability=str(payload.get("capability") or ""),
            operation=str(payload.get("operation") or ""),
            arguments=dict(payload.get("arguments", {})),
            agent_id=payload.get("agent_id"),
            id=str(execution_id),
        )

        # persist initial pending execution
        self._executions.save(execution)
        return execution

    # --- event handlers ---
    def _handle_queued(self, event: Event) -> None:
        payload = event.payload or {}
        execution_id = self._execution_id_from_event(event)
        if not execution_id:
            return

        existing = self._executions.get(execution_id)
        if existing is not None:
            # already persisted; we can update missing metadata if useful,
            # but avoid changing lifecycle state here to keep idempotency.
            return

        execution = Execution(
            task_id=str(payload.get("task_id") or ""),
            capability=str(payload.get("capability") or ""),
            operation=str(payload.get("operation") or ""),
            arguments=dict(payload.get("arguments", {})),
            agent_id=payload.get("agent_id"),
            id=str(execution_id),
        )

        self._executions.save(execution)

    def _handle_dispatched(self, event: Event) -> None:
        payload = event.payload or {}
        execution_id = self._execution_id_from_event(event)
        if not execution_id:
            return

        execution = self._get_or_create(execution_id, payload)

        # idempotent start: only start if still pending
        if execution.status is ExecutionStatus.PENDING:
            try:
                execution.start()
            except InvalidStateTransition:
                # guard against races: if somebody else transitioned
                # ignore the exception and proceed to persist current state
                pass
            finally:
                self._executions.save(execution)

    def _handle_completed(self, event: Event) -> None:
        payload = event.payload or {}
        execution_id = self._execution_id_from_event(event)
        if not execution_id:
            return

        execution = self._get_or_create(execution_id, payload)

        # idempotent succeed: if already succeeded, no-op
        if execution.status is ExecutionStatus.SUCCEEDED:
            return

        # allow completing from RUNNING; if PENDING, try to start then succeed
        try:
            if execution.status is ExecutionStatus.PENDING:
                try:
                    execution.start()
                except InvalidStateTransition:
                    pass

            # set raw_result if available
            result = payload.get("result") if "result" in payload else payload.get("raw_result")
            execution.succeed(result)
        except InvalidStateTransition:
            # cannot succeed from current state; persist existing state and surface no error
            pass
        finally:
            self._executions.save(execution)

    def _handle_failed(self, event: Event) -> None:
        payload = event.payload or {}
        execution_id = self._execution_id_from_event(event)
        if not execution_id:
            return

        execution = self._get_or_create(execution_id, payload)

        # idempotent fail: if already failed, no-op
        if execution.status is ExecutionStatus.FAILED:
            return

        # allow failing from RUNNING; if PENDING, try to start then fail
        try:
            if execution.status is ExecutionStatus.PENDING:
                try:
                    execution.start()
                except InvalidStateTransition:
                    pass

            error = payload.get("error") or payload.get("reason") or "failed"
            execution.fail(str(error))
        except InvalidStateTransition:
            # cannot fail from current state; persist and continue
            pass
        finally:
            self._executions.save(execution)

    def _handle_timed_out(self, event: Event) -> None:
        self._handle_terminal(event, ExecutionStatus.TIMED_OUT, "timed out")

    def _handle_cancelled(self, event: Event) -> None:
        self._handle_terminal(event, ExecutionStatus.CANCELLED, "cancelled")

    def _handle_terminal(
        self,
        event: Event,
        status: ExecutionStatus,
        error: str,
    ) -> None:
        payload = event.payload or {}
        execution_id = self._execution_id_from_event(event)
        if not execution_id:
            return
        execution = self._get_or_create(execution_id, payload)
        if execution.status is status:
            return
        try:
            if execution.status is ExecutionStatus.PENDING:
                execution.start()
            if execution.status is ExecutionStatus.RUNNING:
                if status is ExecutionStatus.TIMED_OUT:
                    execution.time_out()
                else:
                    execution.cancel()
        except InvalidStateTransition:
            pass
        finally:
            self._executions.save(execution)
