from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from threading import Condition, RLock, Thread
from typing import Iterable, Optional

from ocean.core.ids import new_id
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus

from .handle import ExecutionHandle
from .supervisor import ExecutionSupervisor
from .types import ExecutionRequest, ExecutionResult
from .resources import ExecutionResourceLimits
from ocean.domain.enums import OrchestrationMode


class SchedulingState(str, Enum):
    QUEUED = "queued"
    DISPATCHED = "dispatched"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class ScheduledExecution:
    request: ExecutionRequest
    priority: int = 0
    dependencies: set[str] = field(default_factory=set)
    execution_id: Optional[str] = None
    state: SchedulingState = SchedulingState.QUEUED
    enqueue_sequence: int = 0
    handle: Optional[ExecutionHandle] = None

    def __post_init__(self) -> None:
        if self.priority < 0:
            raise ValueError("priority must be non-negative")

        if self.execution_id is None:
            self.execution_id = self.request.execution_id

        if not self.execution_id:
            raise ValueError("scheduled execution requires an execution ID")

        self.dependencies = set(self.dependencies)

        if self.execution_id in self.dependencies:
            raise ValueError(
                "execution cannot depend on itself"
            )

    def cancel(self) -> None:
        if self.state != SchedulingState.QUEUED:
            raise ValueError(
                f"cannot cancel scheduled execution in state "
                f"{self.state.value!r}"
            )

        self.state = SchedulingState.CANCELLED

    def reprioritize(self, priority: int) -> None:
        if priority < 0:
            raise ValueError("priority must be non-negative")

        if self.state != SchedulingState.QUEUED:
            raise ValueError(
                f"cannot reprioritize execution in state "
                f"{self.state.value!r}"
            )

        self.priority = priority


class Scheduler:
    """
    Admission, ordering, capacity, and dispatch layer.

    The Scheduler decides what should run and when it should be dispatched.
    It never executes capability work itself. All execution flows through
    ExecutionSupervisor and therefore through ExecutionRuntime.
    """

    def __init__(
        self,
        supervisor: ExecutionSupervisor,
        *,
        max_concurrent: int = 4,
        event_bus: Optional[EventBus] = None,
        aging_interval: int = 10,
    ) -> None:
        if max_concurrent <= 0:
            raise ValueError("max_concurrent must be positive")

        if aging_interval <= 0:
            raise ValueError("aging_interval must be positive")

        self._supervisor = supervisor
        self._max_concurrent = max_concurrent
        self._event_bus = event_bus
        self._aging_interval = aging_interval

        self._lock = RLock()
        self._condition = Condition(self._lock)

        self._items: dict[str, ScheduledExecution] = {}
        self._completed: set[str] = set()
        self._sequence = 0

        self._running = 0
        # A logical agent is a single execution resource. Multiple agents may
        # run concurrently, but one agent must never receive two active
        # executions at once.
        self._running_agents: set[str] = set()
        self._worker: Optional[Thread] = None
        self._stopping = False
        if self._event_bus is not None:
            self.restore_from_events()

    @property
    def max_concurrent(self) -> int:
        return self._max_concurrent

    @property
    def running(self) -> int:
        with self._lock:
            return self._running

    def has_active_execution_for_agent(self, agent_id: str) -> bool:
        """Return whether the scheduler currently owns an active execution for an agent."""
        normalized = str(agent_id)
        with self._lock:
            return any(
                item.state == SchedulingState.DISPATCHED
                and item.request.agent_id is not None
                and str(item.request.agent_id) == normalized
                for item in tuple(self._items.values())
            )

    def enqueue(
        self,
        request: ExecutionRequest,
        *,
        priority: int = 0,
        dependencies: Optional[Iterable[str]] = None,
    ) -> ScheduledExecution:
        execution_id = request.execution_id or new_id("exec")

        scheduled_request = ExecutionRequest(
            task_id=request.task_id,
            capability=request.capability,
            operation=request.operation,
            agent_id=request.agent_id,
            principal_id=request.principal_id,
            mission_id=request.mission_id,
            mode=request.mode,
            arguments=dict(request.arguments),
            correlation_id=request.correlation_id,
            causation_id=request.causation_id,
            source=request.source,
            execution_id=execution_id,
            resource_limits=request.resource_limits,
        )

        item = ScheduledExecution(
            request=scheduled_request,
            priority=priority,
            dependencies=set(dependencies or ()),
            execution_id=execution_id,
        )

        with self._condition:
            if self._stopping:
                raise ValueError(
                    "scheduler is shutting down; new work is rejected"
                )

            if execution_id in self._items:
                raise ValueError(
                    f"execution already scheduled: {execution_id!r}"
                )

            if execution_id in self._completed:
                raise ValueError(
                    f"execution already completed: {execution_id!r}"
                )

            self._sequence += 1
            item.enqueue_sequence = self._sequence
            self._items[execution_id] = item

            self._publish(
                "ScheduledExecutionQueued",
                item,
            )

            self._condition.notify_all()

        return item

    def restore_from_events(self) -> None:
        """Rebuild scheduler projection from durable scheduler events."""
        if self._event_bus is None:
            return
        with self._condition:
            for event in self._event_bus.history():
                if event.type != "ScheduledExecutionQueued":
                    continue
                payload = event.payload
                execution_id = payload.get("id") or event.aggregate_id
                if not execution_id or execution_id in self._items:
                    continue
                request = ExecutionRequest(
                    task_id=str(payload["task_id"]), capability=str(payload.get("capability", "")),
                    operation=str(payload.get("operation", "")), agent_id=payload.get("agent_id"),
                    principal_id=payload.get("principal_id"), mission_id=payload.get("mission_id"),
                    mode=OrchestrationMode(payload.get("mode", OrchestrationMode.STANDARD.value)), arguments=dict(payload.get("arguments", {})),
                    correlation_id=event.correlation_id, causation_id=event.causation_id,
                    source=event.source, execution_id=str(execution_id),
                    resource_limits=ExecutionResourceLimits(**dict(payload.get("resource_limits", {}))),
                )
                item = ScheduledExecution(request=request, priority=int(payload.get("priority", 0)),
                                          dependencies=set(payload.get("dependencies", [])), execution_id=str(execution_id))
                self._items[str(execution_id)] = item
                self._sequence = max(self._sequence, int(payload.get("enqueue_sequence", 0)))
            for event in self._event_bus.history():
                execution_id = event.aggregate_id
                if event.type == "ScheduledExecutionCompleted":
                    self._completed.add(execution_id)
                item = self._items.get(execution_id)
                if item is None:
                    continue
                if event.type == "ScheduledExecutionDispatched":
                    item.state = SchedulingState.QUEUED
                elif event.type == "ScheduledExecutionCompleted":
                    item.state = SchedulingState.COMPLETED
                    if item.request.agent_id:
                        self._running_agents.discard(str(item.request.agent_id))
                elif event.type == "ScheduledExecutionFailed":
                    item.state = SchedulingState.FAILED
                    if item.request.agent_id:
                        self._running_agents.discard(str(item.request.agent_id))
                elif event.type == "ScheduledExecutionCancelled":
                    item.state = SchedulingState.CANCELLED
                    if item.request.agent_id:
                        self._running_agents.discard(str(item.request.agent_id))
                elif event.type == "ScheduledExecutionReprioritized":
                    item.priority = int(event.payload.get("priority", item.priority))

    def get(
        self,
        execution_id: str,
    ) -> Optional[ScheduledExecution]:
        with self._lock:
            return self._items.get(execution_id)

    def list(self) -> list[ScheduledExecution]:
        with self._lock:
            return list(self._items.values())

    def cancel(self, execution_id: str) -> bool:
        with self._condition:
            item = self._items.get(execution_id)

            if item is None:
                return False

            item.cancel()

            self._publish(
                "ScheduledExecutionCancelled",
                item,
            )

            self._condition.notify_all()
            return True

    def reprioritize(
        self,
        execution_id: str,
        priority: int,
    ) -> ScheduledExecution:
        with self._condition:
            item = self._items.get(execution_id)

            if item is None:
                raise KeyError(execution_id)

            item.reprioritize(priority)

            self._publish(
                "ScheduledExecutionReprioritized",
                item,
                extra={"priority": priority},
            )

            self._condition.notify_all()
            return item

    def dependencies_satisfied(
        self,
        item: ScheduledExecution,
    ) -> bool:
        return item.dependencies.issubset(self._completed)

    def critical_path(self, execution_id: str) -> int:
        """Return dependency depth for deadline-aware scheduling."""
        with self._lock:
            if execution_id not in self._items: raise KeyError(execution_id)
            memo={}
            def depth(eid, visiting):
                if eid in memo: return memo[eid]
                if eid in visiting: raise ValueError("dependency cycle detected")
                node=self._items.get(eid)
                if node is None: return 0
                visiting.add(eid)
                value=1+max((depth(d,visiting) for d in node.dependencies),default=0)
                visiting.remove(eid); memo[eid]=value; return value
            return depth(execution_id,set())

    def dependency_depths(self) -> dict[str,int]:
        with self._lock:
            snapshot = tuple(self._items.values())
        return {item.execution_id:self.critical_path(item.execution_id) for item in snapshot if item.execution_id}

    def eligible(self) -> list[ScheduledExecution]:
        with self._lock:
            candidates = [
                item
                for item in tuple(self._items.values())
                if item.state == SchedulingState.QUEUED
                and self.dependencies_satisfied(item)
                and self._agent_available(item.request.agent_id)
            ]

            return sorted(
                candidates,
                key=self._ordering_key,
            )

    def dispatch_next(self) -> Optional[ScheduledExecution]:
        with self._condition:
            if self._running >= self._max_concurrent:
                return None

            candidates = [
                item
                for item in tuple(self._items.values())
                if item.state == SchedulingState.QUEUED
                and self.dependencies_satisfied(item)
                and self._agent_available(item.request.agent_id)
            ]

            if not candidates:
                return None

            item = min(
                candidates,
                key=self._ordering_key,
            )

            item.state = SchedulingState.DISPATCHED
            self._running += 1
            if item.request.agent_id is not None:
                self._running_agents.add(str(item.request.agent_id))

            try:
                handle = self._supervisor.submit(
                    item.request,
                )
            except Exception:
                item.state = SchedulingState.FAILED
                self._running -= 1
                if item.request.agent_id is not None:
                    self._running_agents.discard(str(item.request.agent_id))

                self._publish(
                    "ScheduledExecutionFailed",
                    item,
                )

                raise

            handle._completion_callback = self._notify_completion
            item.handle = handle

            self._publish(
                "ScheduledExecutionDispatched",
                item,
            )

            self._condition.notify_all()

            return item

    def _notify_completion(self, execution_id: str) -> None:
        """Notify the scheduler that an execution has completed.

        Synchronously reconciles all ready handles so that terminal
        scheduler events (and therefore assignment terminal transitions)
        are published before the caller continues.  This closes the race
        where an adapter thread returns before the scheduler has detected
        the handle completion.
        """
        with self._condition:
            self._reconcile_ready()
            self._condition.notify_all()

    def reconcile(self, execution_id: str) -> ScheduledExecution:
        with self._condition:
            item = self._items.get(execution_id)

            if item is None:
                raise KeyError(execution_id)

            if item.state in {
                SchedulingState.COMPLETED,
                SchedulingState.FAILED,
            }:
                return item

            if item.handle is None:
                raise RuntimeError(
                    "dispatched execution has no execution handle"
                )

            result = item.handle.result

            if result is None:
                future = self._supervisor.future(execution_id)

                if future is None or not future.done():
                    raise RuntimeError(
                        "execution has not completed"
                    )

                result = future.result()
                item.handle.result = result

            self._running -= 1
            if item.request.agent_id is not None:
                self._running_agents.discard(str(item.request.agent_id))

            if result.success:
                item.state = SchedulingState.COMPLETED
                self._completed.add(execution_id)
                event_type = "ScheduledExecutionCompleted"
            else:
                item.state = SchedulingState.FAILED
                event_type = "ScheduledExecutionFailed"

            self._publish(
                event_type,
                item,
                extra={
                    "success": result.success,
                    "error": result.error,
                },
            )

            self._condition.notify_all()

            return item

    def dispatch_available(self) -> list[ScheduledExecution]:
        dispatched: list[ScheduledExecution] = []

        while True:
            item = self.dispatch_next()

            if item is None:
                break

            dispatched.append(item)

        return dispatched

    def start(self) -> None:
        with self._condition:
            if self._worker is not None and self._worker.is_alive():
                return

            self._stopping = False
            self._worker = Thread(
                target=self._run_loop,
                name="ocean-scheduler",
                daemon=True,
            )
            self._worker.start()

    def stop(self, *, wait: bool = True) -> None:
        import sys
        import time
        with self._condition:
            self._stopping = True
            self._stopping_at = time.monotonic()

            # Cancel all pending work so no execution remains orphaned.
            cancelled = []
            for item in list(self._items.values()):
                if item.state == SchedulingState.QUEUED:
                    item.state = SchedulingState.CANCELLED
                    self._publish("ScheduledExecutionCancelled", item)
                    cancelled.append(f"queued:{item.execution_id}")
                elif item.state == SchedulingState.DISPATCHED:
                    if item.handle is not None:
                        item.handle.cancel_silent()
                    item.state = SchedulingState.CANCELLED
                    self._running = max(0, self._running - 1)
                    if item.request.agent_id is not None:
                        self._running_agents.discard(str(item.request.agent_id))
                    self._publish("ScheduledExecutionCancelled", item)
                    cancelled.append(f"dispatched:{item.execution_id}")

            self._condition.notify_all()
            worker = self._worker

        if wait and worker is not None:
            worker.join(timeout=10.0)

        with self._condition:
            self._worker = None

    def _run_loop(self) -> None:
        import time as _time
        while True:
            with self._condition:
                if self._stopping:
                    self._reconcile_ready()
                    if not self._has_dispatched():
                        return
                    elapsed = _time.monotonic() - getattr(self, '_stopping_at', _time.monotonic())
                    if elapsed > 5.0:
                        return
                    self._condition.wait(timeout=0.05)
                    continue

                reconciled = False

                for item in list(self._items.values()):
                    if (
                        item.state == SchedulingState.DISPATCHED
                        and item.handle is not None
                        and item.handle.result is not None
                    ):
                        self._reconcile_completed(item)
                        reconciled = True

                dispatched = self.dispatch_available()

                if not dispatched and not reconciled:
                    self._condition.wait(timeout=0.05)

    def _reconcile_ready(self) -> None:
        for item in list(self._items.values()):
            if (
                item.state == SchedulingState.DISPATCHED
                and item.handle is not None
                and item.handle.result is not None
            ):
                self._reconcile_completed(item)

    def _has_dispatched(self) -> bool:
        return any(
            item.state == SchedulingState.DISPATCHED
            for item in self._items.values()
        )

    def _agent_available(self, agent_id: Optional[str]) -> bool:
        if agent_id is None:
            return True
        normalized = str(agent_id)
        for item in list(self._items.values()):
            if (
                item.state == SchedulingState.DISPATCHED
                and item.request.agent_id is not None
                and str(item.request.agent_id) == normalized
                and item.handle is not None
                and item.handle.result is not None
            ):
                self._reconcile_completed(item)
        return normalized not in self._running_agents

    def _reconcile_completed(
        self,
        item: ScheduledExecution,
    ) -> None:
        import sys
        result = item.handle.result if item.handle else None

        if result is None:
            return

        if self._running <= 0:
            raise RuntimeError(
                "scheduler running count underflow"
            )

        self._running -= 1
        if item.request.agent_id is not None:
            self._running_agents.discard(str(item.request.agent_id))

        if result.success:
            item.state = SchedulingState.COMPLETED
            self._completed.add(item.execution_id)
            event_type = "ScheduledExecutionCompleted"
        else:
            item.state = SchedulingState.FAILED
            event_type = "ScheduledExecutionFailed"

        self._publish(
            event_type,
            item,
            extra={
                "success": result.success,
                "error": result.error,
            },
        )

        self._condition.notify_all()

    def _ordering_key(
        self,
        item: ScheduledExecution,
    ) -> tuple[int, int]:
        """
        Deterministic priority ordering with discrete aging.

        Every aging interval of queue position increases effective priority
        by one. Queue sequence is the deterministic tie-breaker.
        """
        age = max(
            0,
            self._sequence - item.enqueue_sequence,
        ) // self._aging_interval

        effective_priority = item.priority + age

        return (
            -effective_priority,
            item.enqueue_sequence,
        )

    def _publish(
        self,
        event_type: str,
        item: ScheduledExecution,
        *,
        extra: Optional[dict] = None,
    ) -> None:
        if self._event_bus is None:
            return

        payload = {
            "id": item.execution_id,
            "task_id": item.request.task_id,
            "agent_id": item.request.agent_id,
            "priority": item.priority,
            "state": item.state.value,
            "enqueue_sequence": item.enqueue_sequence,
            "dependencies": sorted(item.dependencies),
            "capability": item.request.capability,
            "operation": item.request.operation,
            "arguments": dict(item.request.arguments),
            "principal_id": item.request.principal_id,
            "mission_id": item.request.mission_id,
            "mode": item.request.mode.value,
            "resource_limits": {
                "timeout_seconds": item.request.resource_limits.timeout_seconds,
                "memory_bytes": item.request.resource_limits.memory_bytes,
                "cpu_seconds": item.request.resource_limits.cpu_seconds,
                "max_output_bytes": item.request.resource_limits.max_output_bytes,
                "max_worker_lifetime_seconds": item.request.resource_limits.max_worker_lifetime_seconds,
            },
        }

        if extra:
            payload.update(extra)

        self._event_bus.publish(
            Event(
                type=event_type,
                payload=payload,
                aggregate_type="scheduled_execution",
                aggregate_id=item.execution_id,
                correlation_id=item.request.correlation_id
                or item.execution_id,
                causation_id=item.request.causation_id,
                source=item.request.source,
            )
        )
