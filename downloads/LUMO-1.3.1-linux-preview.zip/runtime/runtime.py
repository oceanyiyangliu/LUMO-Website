from __future__ import annotations

import time

from typing import Optional

from ocean.core.errors import InvalidCapabilityInput, InvalidCapabilityOutput, PolicyViolation

from ocean.core.ids import new_id

from ocean.domain.capability import CapabilityRegistry

from ocean.domain.event import Event

from ocean.domain.event_bus import EventBus

from ocean.domain.execution import Execution

from ocean.domain.policy import PolicyContext, PolicyEngine
from ocean.governance import GovernanceEngine, GovernanceRequest

from .control import (

    CancellationToken,

    ExecutionCancelled,

    ExecutionContext,

    ExecutionTimedOut,

)

from .controller import ExecutionController

from .executor import ExecutorRegistry

from .handle import ExecutionHandle

from .registry import ActiveExecutionRegistry

from .types import ExecutionRequest, ExecutionResult

from .isolation import (
    CapabilityIsolationRouter,
    InProcessIsolationBackend,
    IsolationBackend,
    ProcessIsolationBackend,
)
from ocean.capabilities.validation import validate_input, validate_output
from ocean.domain.capability import CapabilityIsolationPolicy


class ExecutionRuntime:

    """Controls one complete capability execution attempt."""

    def __init__(
        self,
        *,
        capabilities: CapabilityRegistry,
        policy: PolicyEngine,
        executors: ExecutorRegistry,
        event_bus: Optional[EventBus] = None,
        active_executions: Optional[ActiveExecutionRegistry] = None,
        isolation: Optional[IsolationBackend] = None,
        governance: Optional[GovernanceEngine] = None,
    ) -> None:
        self._capabilities = capabilities
        self._policy = policy
        self._governance = governance or GovernanceEngine(policy)
        self._executors = executors
        self._event_bus = event_bus or EventBus()
        self._active_executions = (
            active_executions or ActiveExecutionRegistry()
        )
        self._isolation = isolation or InProcessIsolationBackend()

    @property
    def event_bus(self) -> EventBus:
        return self._event_bus

    @property
    def active_executions(self) -> ActiveExecutionRegistry:
        return self._active_executions

    def submit(
        self,
        request: ExecutionRequest,
        *,

        cancellation: Optional[CancellationToken] = None,
        timeout_seconds: Optional[float] = None,
    ) -> ExecutionHandle:
        """
        Submit an execution for runtime-controlled execution.

        The handle is the control surface for the execution lifecycle.

        The ExecutionSupervisor owns asynchronous execution; this method
        registers the execution handle for direct runtime callers.
        """
        token = cancellation or CancellationToken()

        handle = ExecutionHandle(
            execution_id=request.execution_id or new_id("exec"),
            cancellation=token,
            controller=ExecutionController(),
        )

        self._active_executions.register(handle)
        return handle

    def execute(
        self,
        request: ExecutionRequest,
        *,
        cancellation: Optional[CancellationToken] = None,
        timeout_seconds: Optional[float] = None,
        deadline: Optional[float] = None,
    ) -> ExecutionResult:
        capability = self._capabilities.get(request.capability)
        operation = capability.operation(request.operation)
        try:
            validate_input(request.arguments, operation.input_schema)
        except InvalidCapabilityInput:
            raise

        if (
            capability.execution_policy.isolation
            in {
                CapabilityIsolationPolicy.PROCESS_ISOLATED,
                CapabilityIsolationPolicy.PROCESS_ISOLATED_REQUIRED,
            }
            and not isinstance(
                self._isolation,
                (ProcessIsolationBackend, CapabilityIsolationRouter),
            )
        ):
            raise PolicyViolation(
                f"capability {request.capability!r} requires process isolation"
            )

        policy_context = PolicyContext(
            capability=request.capability,
            operation=request.operation,
            risk_level=operation.risk_level,
            metadata=dict(request.arguments),
        )

        governance_decision = self._governance.evaluate(
            GovernanceRequest(
                policy_context=policy_context,
                principal_id=request.principal_id,
                mode=request.mode,
                task_id=request.task_id,
                agent_id=request.agent_id,
                mission_id=request.mission_id,
                required_permissions=frozenset(
                    capability.requires_permissions
                ),
                metadata={
                    "source": request.source,
                    "correlation_id": request.correlation_id,
                },
            )
        )

        if not governance_decision.executable:
            reason = "; ".join(governance_decision.reasons)
            raise PolicyViolation(
                reason or (
                    f"governance denied execution: "
                    f"{request.capability}.{request.operation}"
                )
            )
        execution_id = request.execution_id or new_id("exec")

        execution = Execution(
            task_id=request.task_id,
            capability=request.capability,
            operation=request.operation,
            arguments=dict(request.arguments),
            agent_id=request.agent_id,
            principal_id=request.principal_id,
            mission_id=request.mission_id,
            mode=request.mode,
            id=execution_id,
        )

        controller = ExecutionController()

        correlation_id = request.correlation_id or execution.id

        created_event = Event(
            type="ExecutionCreated",
            payload={
                "id": execution.id,
                "task_id": execution.task_id,
                "capability": execution.capability,
                "operation": execution.operation,
                "arguments": dict(execution.arguments),
                "agent_id": execution.agent_id,
                "principal_id": execution.principal_id,
                "mission_id": execution.mission_id,
                "mode": execution.mode.value,
            },
            aggregate_type="execution",
            aggregate_id=execution.id,
            causation_id=request.causation_id,
            correlation_id=correlation_id,
            source=request.source,
        )

        self._event_bus.publish(created_event)

        token = cancellation or CancellationToken()

        if token.is_cancelled:
            return self._cancel_execution(
                execution,
                controller=controller,
                causation_id=created_event.id,
                correlation_id=correlation_id,
                source=request.source,
            )

        execution.start()

        started_event = Event(
            type="ExecutionStarted",
            payload={
                "id": execution.id,
            },
            aggregate_type="execution",
            aggregate_id=execution.id,
            causation_id=created_event.id,
            correlation_id=correlation_id,
            source=request.source,
        )

        self._event_bus.publish(started_event)

        execution_deadline = deadline

        # A request-level resource limit is authoritative even when callers
        # omit the legacy timeout_seconds argument. Otherwise a declared
        # timeout could silently become telemetry-only.
        resource_timeout = request.resource_limits.timeout_seconds
        if deadline is None and timeout_seconds is None and resource_timeout is not None:
            timeout_seconds = resource_timeout

        if timeout_seconds is not None and deadline is None:
            if timeout_seconds <= 0:
                return self._timeout_execution(
                    execution,
                    controller=controller,
                    causation_id=started_event.id,
                    correlation_id=correlation_id,
                    source=request.source,
                )

            execution_deadline = time.monotonic() + timeout_seconds

        if execution_deadline is not None and execution_deadline <= time.monotonic():
            return self._timeout_execution(
                execution,
                controller=controller,
                causation_id=started_event.id,
                correlation_id=correlation_id,
                source=request.source,
            )

        context = ExecutionContext(
            execution_id=execution.id,
            cancellation=token,
            deadline=execution_deadline,
            resource_limits=request.resource_limits,
        )

        try:
            strategy = capability.execution_strategy
            executor = self._executors.get(strategy)
        except Exception as exc:
            error = f"executor resolution failed: {exc}"
            self._commit_failure(
                execution,
                error=error,
                causation_id=started_event.id,
                correlation_id=correlation_id,
                source=request.source,
            )
            return ExecutionResult.failed(
                error,
                metadata={
                    "capability": execution.capability,
                    "operation": execution.operation,
                    "execution_id": execution.id,
                    "mission_id": execution.mission_id,
                    "agent_id": execution.agent_id,
                    "failure_type": "executor_resolution_failure",
                },
            )

        executor_request = ExecutionRequest(
            task_id=request.task_id,
            capability=request.capability,
            operation=request.operation,
            agent_id=request.agent_id,
            principal_id=request.principal_id,
            mission_id=request.mission_id,
            mode=request.mode,
            arguments=dict(request.arguments),
            correlation_id=correlation_id,
            causation_id=started_event.id,
            source=request.source,
            execution_id=execution.id,
            resource_limits=request.resource_limits,
        )

        try:
            context.check()
            result = self._isolation.execute(
                executor,
                executor_request,
                context,
            )
            context.check()
        except ExecutionCancelled:
            return self._cancel_execution(
                execution,
                controller=controller,
                causation_id=started_event.id,
                correlation_id=correlation_id,
                source=request.source,
            )

        except ExecutionTimedOut:
            return self._timeout_execution(
                execution,
                controller=controller,
                causation_id=started_event.id,
                correlation_id=correlation_id,
                source=request.source,
            )

        except TimeoutError:
            return self._timeout_execution(
                execution,
                controller=controller,
                causation_id=started_event.id,
                correlation_id=correlation_id,
                source=request.source,
            )

        except Exception as exc:
            error = str(exc)

            committed = controller.commit_terminal(
                lambda: self._commit_failure(
                    execution,
                    error=error,
                    causation_id=started_event.id,
                    correlation_id=correlation_id,
                    source=request.source,
                )
            )

            if committed is None:
                return ExecutionResult.failed(
                    "execution already terminated",
                    metadata={
                        "capability": execution.capability,
                        "operation": execution.operation,
                        "execution_id": execution.id,
                        "mission_id": execution.mission_id,
                        "agent_id": execution.agent_id,
                        "failure_type": "execution_terminal_conflict",
                    },
                )

            return ExecutionResult.failed(
                error,
                metadata={
                    "capability": execution.capability,
                    "operation": execution.operation,
                    "execution_id": execution.id,
                    "mission_id": execution.mission_id,
                    "agent_id": execution.agent_id,
                    "failure_type": "execution_failure",
                },
            )

        result_metadata = {
            "capability": request.capability,
            "operation": request.operation,
            "execution_id": execution.id,
            "mission_id": request.mission_id,
            "agent_id": request.agent_id,
            **dict(result.metadata),
        }
        if result.success:
            try:
                validate_output(result.result, operation.output_schema)
            except InvalidCapabilityOutput as exc:
                error = str(exc)
                committed = controller.commit_terminal(
                    lambda: self._commit_failure(
                        execution,
                        error=error,
                        causation_id=started_event.id,
                        correlation_id=correlation_id,
                        source=request.source,
                    )
                )
                if committed is None:
                    return ExecutionResult.failed(
                        "execution already terminated",
                        metadata={
                            **result_metadata,
                            "failure_type": "execution_terminal_conflict",
                        },
                    )
                return ExecutionResult.failed(
                    error,
                    metadata={
                        **result_metadata,
                        "failure_type": "invalid_capability_output",
                    },
                )
        result = ExecutionResult(
            success=result.success,
            result=result.result,
            error=result.error,
            metadata=result_metadata,
        )

        if result.success:
            verification_event = Event(
                type="ExecutionVerified",
                payload={
                    "id": execution.id,
                    "verification": "output_schema_validated",
                    "evidence": {"kind": "capability_output", "capability": request.capability, "operation": request.operation},
                },
                aggregate_type="execution",
                aggregate_id=execution.id,
                causation_id=started_event.id,
                correlation_id=correlation_id,
                source="execution_verifier",
            )
            try:
                self._event_bus.publish(verification_event)
            except Exception as exc:
                error = f"verification event publication failed: {exc}"
                committed = controller.commit_terminal(
                    lambda: self._commit_failure(
                        execution,
                        error=error,
                        causation_id=started_event.id,
                        correlation_id=correlation_id,
                        source=request.source,
                    )
                )
                if committed is None:
                    return ExecutionResult.failed(
                        "execution already terminated",
                        metadata={
                            **result.metadata,
                            "failure_type": "execution_terminal_conflict",
                        },
                    )
                return ExecutionResult.failed(
                    error,
                    metadata={
                        **result.metadata,
                        "failure_type": "verification_publication_failure",
                    },
                )
            result = ExecutionResult(
                success=True,
                result=result.result,
                error=None,
                metadata={
                    **result.metadata,
                    "verification_state": "verified",
                    "verification_method": "output_schema_validated",
                },
            )
            committed = controller.commit_terminal(
                lambda: self._commit_success(
                    execution,
                    result=result,
                    causation_id=verification_event.id,
                    correlation_id=correlation_id,
                    source=request.source,
                )
            )

            if committed is None:
                return ExecutionResult.failed(
                    "execution already terminated"
                )

        else:
            error = result.error or "execution failed"

            committed = controller.commit_terminal(
                lambda: self._commit_failure(
                    execution,
                    error=error,
                    causation_id=started_event.id,
                    correlation_id=correlation_id,
                    source=request.source,
                )
            )

            if committed is None:
                return ExecutionResult.failed(
                    "execution already terminated"
                )

        return result

    def _commit_success(
        self,
        execution: Execution,
        *,
        result: ExecutionResult,
        causation_id: str,
        correlation_id: str,
        source: Optional[str],
    ) -> bool:
        execution.succeed(result.result)

        self._event_bus.publish(
            Event(
                type="ExecutionSucceeded",
                payload={
                    "id": execution.id,
                    "result": result.result,
                },
                aggregate_type="execution",
                aggregate_id=execution.id,
                causation_id=causation_id,
                correlation_id=correlation_id,
                source=source,
            )
        )

        return True

    def _commit_failure(
        self,
        execution: Execution,
        *,
        error: str,
        causation_id: str,
        correlation_id: str,
        source: Optional[str],
    ) -> bool:
        execution.fail(error)

        self._event_bus.publish(
            Event(
                type="ExecutionFailed",
                payload={
                    "id": execution.id,
                    "error": error,
                },
                aggregate_type="execution",
                aggregate_id=execution.id,
                causation_id=causation_id,
                correlation_id=correlation_id,
                source=source,
            )
        )

        return True

    def _cancel_execution(
        self,
        execution: Execution,
        *,
        controller: ExecutionController,
        causation_id: str,
        correlation_id: str,
        source: Optional[str],
    ) -> ExecutionResult:
        committed = controller.commit_terminal(
            lambda: self._commit_cancellation(
                execution,
                causation_id=causation_id,
                correlation_id=correlation_id,
                source=source,
            )
        )

        if committed is None:
            return ExecutionResult.failed(
                "execution already terminated"
            )

        return ExecutionResult.failed(
            "cancelled",
            metadata={
                "capability": execution.capability,
                "operation": execution.operation,
                "execution_id": execution.id,
                "mission_id": execution.mission_id,
                "agent_id": execution.agent_id,
                "failure_type": "cancelled",
            },
        )

    def _commit_cancellation(
        self,
        execution: Execution,
        *,
        causation_id: str,
        correlation_id: str,
        source: Optional[str],
    ) -> bool:
        execution.cancel()

        self._event_bus.publish(
            Event(
                type="ExecutionCancelled",
                payload={
                    "id": execution.id,
                },
                aggregate_type="execution",
                aggregate_id=execution.id,
                causation_id=causation_id,
                correlation_id=correlation_id,
                source=source,
            )
        )

        return True

    def _timeout_execution(
        self,
        execution: Execution,
        *,
        controller: ExecutionController,
        causation_id: str,
        correlation_id: str,
        source: Optional[str],
    ) -> ExecutionResult:
        committed = controller.commit_terminal(
            lambda: self._commit_timeout(
                execution,
                causation_id=causation_id,
                correlation_id=correlation_id,
                source=source,
            )
        )

        if committed is None:
            return ExecutionResult.failed(
                "execution already terminated"
            )

        return ExecutionResult.failed(
            "timed out",
            metadata={
                "capability": execution.capability,
                "operation": execution.operation,
                "execution_id": execution.id,
                "mission_id": execution.mission_id,
                "agent_id": execution.agent_id,
                "failure_type": "timeout",
                "retryable": True,
            },
        )

    def _commit_timeout(
        self,
        execution: Execution,
        *,
        causation_id: str,
        correlation_id: str,
        source: Optional[str],
    ) -> bool:
        execution.time_out()

        self._event_bus.publish(
            Event(
                type="ExecutionTimedOut",
                payload={
                    "id": execution.id,
                },
                aggregate_type="execution",
                aggregate_id=execution.id,
                causation_id=causation_id,
                correlation_id=correlation_id,
                source=source,
            )
        )

        return True
