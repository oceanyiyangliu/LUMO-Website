from __future__ import annotations

from dataclasses import dataclass, field
from threading import Event
from typing import Callable, Optional

from .control import CancellationToken
from .controller import ExecutionController
from .types import ExecutionResult


@dataclass
class ExecutionHandle:
    execution_id: str
    cancellation: CancellationToken
    controller: ExecutionController = field(default_factory=ExecutionController)
    result: Optional[ExecutionResult] = None
    _completed: Event = field(default_factory=Event, repr=False)
    _completion_callback: Optional[Callable[[str], None]] = field(default=None, repr=False)

    def cancel(self) -> None:
        self.cancellation.cancel()
        if self.result is None:
            self.result = ExecutionResult(
                success=False,
                error="cancelled",
                metadata={"failure_type": "cancelled"},
            )
        self._completed.set()
        if self._completion_callback is not None:
            self._completion_callback(self.execution_id)

    def cancel_silent(self) -> None:
        """Cancel without invoking the completion callback.

        Used by scheduler shutdown to tear down pending work without
        re-entering the scheduler/recovery chain through the callback.
        """
        self.cancellation.cancel()
        if self.result is None:
            self.result = ExecutionResult(
                success=False,
                error="cancelled",
                metadata={"failure_type": "cancelled"},
            )
        self._completed.set()

    @property
    def is_cancelled(self) -> bool:
        return self.cancellation.is_cancelled

    @property
    def is_completed(self) -> bool:
        return self._completed.is_set()

    def wait(self, timeout: Optional[float] = None) -> Optional[ExecutionResult]:
        """Wait for asynchronous execution completion and return its result."""
        self._completed.wait(timeout)
        return self.result

    def _mark_completed(self, result: ExecutionResult) -> None:
        if self.result is None:
            self.result = result
        self._completed.set()
        if self._completion_callback is not None:
            self._completion_callback(self.execution_id)
