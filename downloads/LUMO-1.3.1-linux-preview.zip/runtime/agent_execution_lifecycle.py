from __future__ import annotations

from typing import Optional

from ocean.domain.agent import Agent
from ocean.domain.enums import AgentStatus
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus

from .agent_controller import AgentController
from .agent_registry import AgentRegistry


class AgentExecutionLifecycle:
    """
    Event-driven integration between scheduled execution lifecycle
    and Agent lifecycle state.

    This component does not own Agent state.

    AgentRegistry owns live Agent identity lookup.
    AgentController owns lifecycle transitions.
    EventBus owns execution-event delivery.
    """

    def __init__(
        self,
        *,
        event_bus: EventBus,
        registry: AgentRegistry,
        controller: AgentController,
    ) -> None:
        self._event_bus = event_bus
        self._registry = registry
        self._controller = controller

        self._event_bus.subscribe(
            "ScheduledExecutionDispatched",
            self._handle_dispatched,
        )
        self._event_bus.subscribe(
            "ScheduledExecutionCompleted",
            self._handle_completed,
        )
        self._event_bus.subscribe(
            "ScheduledExecutionFailed",
            self._handle_failed,
        )
        self._event_bus.subscribe(
            "ScheduledExecutionCancelled",
            self._handle_cancelled,
        )
        self._event_bus.subscribe(
            "ExecutionTimedOut",
            self._handle_failed,
        )

    def _handle_dispatched(self, event: Event) -> None:
        agent, task_id = self._resolve_execution(event)

        if agent.status is AgentStatus.RUNNING:
            if agent.current_task_id != task_id:
                raise ValueError(
                    f"agent {agent.id!r} is already running task "
                    f"{agent.current_task_id!r}, cannot dispatch task "
                    f"{task_id!r}"
                )
            return

        self._controller.activate(
            agent,
            task_id=task_id,
        )

    def _handle_completed(self, event: Event) -> None:
        agent, task_id = self._resolve_execution(event)

        self._validate_active_task(agent, task_id)

        if agent.status is AgentStatus.IDLE:
            return

        self._controller.idle(agent)

    def _handle_failed(self, event: Event) -> None:
        agent, task_id = self._resolve_execution(event)

        self._validate_active_task(agent, task_id)

        if agent.status is AgentStatus.IDLE:
            return

        self._controller.idle(agent)

    def _handle_cancelled(self, event: Event) -> None:
        """Release the agent for cancelled scheduled work."""
        self._handle_failed(event)

    def _resolve_execution(self, event: Event) -> tuple[Agent, str]:
        payload = event.payload

        agent_id = payload.get("agent_id")
        if not agent_id:
            raise ValueError(
                f"{event.type} event is missing agent_id"
            )

        task_id = payload.get("task_id")
        if not task_id:
            raise ValueError(
                f"{event.type} event is missing task_id"
            )

        agent = self._registry.get(str(agent_id))
        if agent is None:
            raise KeyError(
                f"unknown agent referenced by {event.type}: "
                f"{agent_id!r}"
            )

        return agent, str(task_id)

    @staticmethod
    def _validate_active_task(
        agent: Agent,
        task_id: str,
    ) -> None:
        if agent.status is AgentStatus.RUNNING:
            if agent.current_task_id != task_id:
                raise ValueError(
                    f"agent {agent.id!r} is running task "
                    f"{agent.current_task_id!r}, but execution event "
                    f"references task {task_id!r}"
                )
            return

        if agent.status is AgentStatus.IDLE:
            return

        raise ValueError(
            f"agent {agent.id!r} cannot reconcile execution for task "
            f"{task_id!r} while in state {agent.status.value!r}"
        )
