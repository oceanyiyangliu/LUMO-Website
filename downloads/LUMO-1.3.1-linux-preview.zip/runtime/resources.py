from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Optional


class ResourceLimitExceeded(Exception):
    """Raised when an execution exceeds an enforced resource limit."""


@dataclass(frozen=True)
class ExecutionResourceLimits:
    """
    Runtime-owned resource limits for one execution.

    Limits describe what an execution is permitted to consume.
    Enforcement belongs to the runtime/isolation layer, not executors.
    """

    timeout_seconds: Optional[float] = None
    memory_bytes: Optional[int] = None
    cpu_seconds: Optional[float] = None
    max_output_bytes: Optional[int] = None
    max_worker_lifetime_seconds: Optional[float] = None

    def __post_init__(self) -> None:
        for name in ("timeout_seconds", "cpu_seconds", "max_worker_lifetime_seconds"):
            value = getattr(self, name)
            if value is not None and (not math.isfinite(value) or value <= 0):
                raise ValueError(f"{name} must be finite and positive")
        for name in ("memory_bytes", "max_output_bytes"):
            value = getattr(self, name)
            if value is not None:
                if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                    raise ValueError(f"{name} must be a positive integer")


@dataclass(frozen=True)
class ExecutionResourceUsage:
    """
    Observed resource consumption for one execution.

    Usage is telemetry, not authority. The runtime/isolation layer remains
    responsible for enforcing limits.
    """

    wall_time_seconds: Optional[float] = None
    cpu_seconds: Optional[float] = None
    peak_memory_bytes: Optional[int] = None
    output_bytes: Optional[int] = None


@dataclass(frozen=True)
class ResourceLimitsExceeded:
    """Structured description of a resource limit being exceeded."""

    resource: str
    limit: float
    observed: float
