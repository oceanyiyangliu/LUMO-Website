from __future__ import annotations

from typing import Iterable, Optional

from ocean.domain.agent import Agent

from .agent_controller import AgentController
from .agent_registry import AgentRegistry
from .scheduler import ScheduledExecution, Scheduler
from .types import ExecutionRequest


class AgentRuntime:
    """
    Operational boundary for long-lived Agents.

    Validates agent identity, lifecycle state, and capabilities before
    submitting work into the Scheduler.
    """

    def __init__(
        self,
        scheduler: Scheduler,
        *,
        registry: Optional[AgentRegistry] = None,
        controller: Optional[AgentController] = None,
    ) -> None:
        self._scheduler = scheduler
        self._registry = registry or AgentRegistry()
        self._controller = controller or AgentController()

    @property
    def registry(self) -> AgentRegistry:
        return self._registry

    @property
    def controller(self) -> AgentController:
        return self._controller

    @property
    def scheduler(self) -> Scheduler:
        return self._scheduler

    def register(self, agent: Agent) -> Agent:
        self._registry.register(agent)
        return agent

    def get(self, agent_id: str) -> Optional[Agent]:
        return self._registry.get(agent_id)

    def agents(self) -> Iterable[Agent]:
        return self._registry.list()

    def submit(
        self,
        agent_id: str,
        request: ExecutionRequest,
        *,
        priority: int = 0,
        dependencies: Optional[Iterable[str]] = None,
    ) -> ScheduledExecution:
        agent = self._registry.get(agent_id)

        if agent is None:
            raise KeyError(f"unknown agent: {agent_id!r}")

        if agent.status not in {
            agent.status.IDLE,
            agent.status.BACKGROUND,
            agent.status.ASSIGNED,
        }:
            raise RuntimeError(
                f"agent {agent_id!r} cannot accept work in state "
                f"{agent.status.value!r}"
            )

        if not agent.can_perform(request.capability):
            raise PermissionError(
                f"agent {agent_id!r} lacks capability "
                f"{request.capability!r}"
            )

        if request.agent_id is not None and request.agent_id != agent_id:
            raise ValueError(
                "request agent_id does not match submitting agent"
            )

        agent_request = ExecutionRequest(
            task_id=request.task_id,
            capability=request.capability,
            operation=request.operation,
            arguments=dict(request.arguments),
            agent_id=agent_id,
            principal_id=request.principal_id,
            mission_id=request.mission_id,
            mode=request.mode,
            correlation_id=request.correlation_id,
            causation_id=request.causation_id,
            source=request.source,
            execution_id=request.execution_id,
            resource_limits=request.resource_limits,
        )

        return self._scheduler.enqueue(
            agent_request,
            priority=priority,
            dependencies=dependencies,
        )

    def mark_idle(self, agent_id: str) -> Agent:
        agent = self._require(agent_id)
        return self._controller.idle(agent)

    def mark_waiting(
        self,
        agent_id: str,
        *,
        task_id: Optional[str] = None,
    ) -> Agent:
        agent = self._require(agent_id)
        return self._controller.wait(
            agent,
            task_id=task_id or agent.current_task_id,
        )

    def mark_background(self, agent_id: str) -> Agent:
        agent = self._require(agent_id)
        return self._controller.background(agent)

    def fail(self, agent_id: str) -> Agent:
        agent = self._require(agent_id)
        return self._controller.fail(agent)

    def terminate(self, agent_id: str) -> Agent:
        agent = self._require(agent_id)
        return self._controller.terminate(agent)

    def _require(self, agent_id: str) -> Agent:
        agent = self._registry.get(agent_id)

        if agent is None:
            raise KeyError(f"unknown agent: {agent_id!r}")

        return agent
