from ocean.domain.event import Event
from ocean.observability.agent_pov import AgentPOVProjector

def test_agent_pov_rebuilds_latest_observable_state():
    events=[
        Event(type="AgentStarted",aggregate_id="a1",payload={"agent_id":"a1","mission_id":"m1","status":"running","activity":"researching"}),
        Event(type="AgentActionExecuted",aggregate_id="a1",payload={"agent_id":"a1","task_id":"t1","action":{"kind":"browser"},"resource_usage":{"tool_calls":2}}),
        Event(type="EvidenceRecorded",aggregate_id="a1",payload={"agent_id":"a1","evidence_id":"ev1"}),
    ]
    p=AgentPOVProjector(); p.rebuild(events); pov=p.get("a1")
    assert pov.status=="running" and pov.task_id=="t1" and pov.evidence_ids==("ev1",) and pov.resource_usage["tool_calls"]==2
