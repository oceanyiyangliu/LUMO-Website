import pytest

from ocean.domain.verification import Verification
from ocean.self_improvement.benchmark import (
    BenchmarkComparison,
    BenchmarkComparisonReport,
)
from ocean.self_improvement.decision import (
    ImprovementDecisionRequest,
    ImprovementDecisionService,
)
from ocean.self_improvement.verification import CandidateVerificationContext


def verification(
    *,
    candidate_id="candidate-1",
    passed=True,
    evidence=("test passed",),
):
    return CandidateVerificationContext(
        candidate_id=candidate_id,
        candidate_mission_id="candidate-mission-1",
        candidate_plan_revision_id="candidate-plan-1",
        task_id="candidate-task-1",
        execution_id="execution-1",
        verification_id="verification-1",
        passed=passed,
        evidence=tuple(evidence),
        metadata={},
    )


def benchmark(
    *,
    candidate_id="candidate-1",
    comparisons=(),
    passed=True,
):
    return BenchmarkComparisonReport(
        candidate_id=candidate_id,
        comparisons=tuple(comparisons),
        improved_count=sum(item.improved for item in comparisons),
        regressed_count=0,
        unchanged_count=0,
        passed=passed,
    )


def comparison(
    name="latency",
    baseline=100,
    candidate=80,
    *,
    higher_is_better=False,
    improved=True,
):
    return BenchmarkComparison(
        name=name,
        baseline=baseline,
        candidate=candidate,
        delta=candidate - baseline,
        improvement_ratio=(candidate - baseline) / abs(baseline),
        improved=improved,
        unit="ms",
        higher_is_better=higher_is_better,
    )


def request(**kwargs):
    values = {
        "candidate_id": "candidate-1",
        "verification": verification(),
        "benchmark": benchmark(
            comparisons=(
                comparison(),
            ),
        ),
        "research_evidence": ("research finding",),
    }
    values.update(kwargs)
    return ImprovementDecisionRequest(**values)


def test_verified_improved_candidate_passes():
    decision = ImprovementDecisionService().decide(request())

    assert decision.passed is True
    assert decision.reasons == ()
    assert decision.improved_metrics == ("latency",)


def test_failed_verification_rejects():
    decision = ImprovementDecisionService().decide(
        request(
            verification=verification(passed=False),
        )
    )

    assert decision.passed is False
    assert "candidate verification failed" in decision.reasons


def test_missing_verification_evidence_rejects():
    decision = ImprovementDecisionService().decide(
        request(
            verification=verification(evidence=()),
        )
    )

    assert decision.passed is False
    assert "candidate verification contains no evidence" in decision.reasons


def test_benchmark_regression_rejects():
    regression = comparison(
        name="latency",
        baseline=100,
        candidate=120,
        higher_is_better=False,
        improved=False,
    )

    report = benchmark(
        comparisons=(regression,),
        passed=False,
    )

    report = BenchmarkComparisonReport(
        candidate_id="candidate-1",
        comparisons=(regression,),
        improved_count=0,
        regressed_count=1,
        unchanged_count=0,
        passed=False,
    )

    decision = ImprovementDecisionService().decide(
        request(benchmark=report)
    )

    assert decision.passed is False
    assert "benchmark comparison failed" in decision.reasons
    assert "benchmark contains 1 regression(s)" in decision.reasons


def test_requires_actual_improvement():
    unchanged = BenchmarkComparison(
        name="accuracy",
        baseline=99,
        candidate=99,
        delta=0,
        improvement_ratio=0,
        improved=False,
        unit="%",
        higher_is_better=True,
    )

    report = BenchmarkComparisonReport(
        candidate_id="candidate-1",
        comparisons=(unchanged,),
        improved_count=0,
        regressed_count=0,
        unchanged_count=1,
        passed=True,
    )

    decision = ImprovementDecisionService().decide(
        request(benchmark=report)
    )

    assert decision.passed is False
    assert (
        "candidate does not meet minimum improvement requirement"
        in decision.reasons
    )


def test_required_research_evidence_is_enforced():
    decision = ImprovementDecisionService().decide(
        request(
            research_evidence=("other evidence",),
            required_evidence=("required finding",),
        )
    )

    assert decision.passed is False
    assert "required research evidence is missing" in decision.reasons


def test_required_research_evidence_can_pass():
    decision = ImprovementDecisionService().decide(
        request(
            research_evidence=("required finding",),
            required_evidence=("required finding",),
        )
    )

    assert decision.passed is True


def test_minimum_score_is_enforced():
    decision = ImprovementDecisionService().decide(
        request(
            score=0.7,
            minimum_score=0.8,
        )
    )

    assert decision.passed is False
    assert "candidate score is below the required minimum" in decision.reasons


def test_score_at_threshold_passes():
    decision = ImprovementDecisionService().decide(
        request(
            score=0.8,
            minimum_score=0.8,
        )
    )

    assert decision.passed is True


def test_candidate_identity_is_enforced():
    with pytest.raises(ValueError):
        request(
            candidate_id="candidate-2",
            verification=verification(
                candidate_id="candidate-1",
            ),
        )


def test_benchmark_identity_is_enforced():
    with pytest.raises(ValueError):
        request(
            benchmark=benchmark(
                candidate_id="candidate-2",
            ),
        )


def test_multiple_regressions_are_reported_deterministically():
    first = comparison(
        name="a",
        baseline=10,
        candidate=20,
        higher_is_better=False,
        improved=False,
    )
    second = comparison(
        name="b",
        baseline=10,
        candidate=20,
        higher_is_better=False,
        improved=False,
    )

    report = BenchmarkComparisonReport(
        candidate_id="candidate-1",
        comparisons=(first, second),
        improved_count=0,
        regressed_count=2,
        unchanged_count=0,
        passed=False,
    )

    decision = ImprovementDecisionService().decide(
        request(benchmark=report)
    )

    assert decision.passed is False
    assert decision.regressed_metrics == ("a", "b")
