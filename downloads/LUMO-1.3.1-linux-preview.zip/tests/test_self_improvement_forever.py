from pathlib import Path
import json

from ocean.self_improvement.forever import ForeverImprovementWorker, ForeverState


def test_forever_state_persists(tmp_path: Path):
    worker = ForeverImprovementWorker(
        tmp_path,
        objective="test objective",
        cycle_delay=0,
        idle_delay=0,
    )
    state = ForeverState(
        cycles=4,
        promoted=2,
        failed=2,
        last_status="rejected",
        last_run_id="run-1",
        last_candidate_id="candidate-1",
        last_error="test",
        updated_at=123.0,
    )
    worker._save_state(state)
    assert worker._load_state() == state


def test_forever_has_local_provider_defaults(tmp_path: Path):
    worker = ForeverImprovementWorker(tmp_path, objective="test")
    assert worker.model == "qwen3:0.6b"
    assert worker.state_path.parent == tmp_path / ".ocean"


def test_forever_state_is_json(tmp_path: Path):
    worker = ForeverImprovementWorker(tmp_path, objective="test")
    worker._save_state(ForeverState(cycles=1))
    data = json.loads(worker.state_path.read_text())
    assert data["cycles"] == 1
