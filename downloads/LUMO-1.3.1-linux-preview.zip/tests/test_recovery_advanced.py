from ocean.recovery.advanced import *

def test_backoff_is_bounded_and_deterministic():
 p=BackoffPolicy(base_seconds=1,max_seconds=10,jitter_ratio=.2); assert p.delay(2,"x")==p.delay(2,"x"); assert p.delay(20,"x")<=10

def test_reaper_zombies_and_degraded_mode():
 w=WorkerHealth("w",0); assert WorkerReaper(5).stale_workers([w],10)==("w",); assert ZombieProcessDetector({1}).unexpected([1,2])==(2,); d=DegradedMode(); d.enter("provider"); assert d.active; d.leave("provider"); assert not d.active


def test_database_recovery_check_reports_healthy_and_can_backup(tmp_path):
    import sqlite3
    from ocean.recovery.advanced import DatabaseRecoveryChecker
    source = tmp_path / "state.sqlite3"
    with sqlite3.connect(source) as db:
        db.execute("create table facts (id integer primary key, value text)")
        db.execute("insert into facts(value) values ('ok')")
    checker = DatabaseRecoveryChecker(source)
    receipt = checker.check()
    assert receipt.status == "healthy"
    backup = checker.backup(tmp_path / "backup.sqlite3")
    assert backup.exists()
