import os
import time
import pytest
from threading import Barrier, Lock, Thread

from ocean.core.errors import InvalidStateTransition, PolicyViolation

from ocean.domain.capability import (
    CapabilityRegistry,
    CapabilitySpec,
    OperationSpec,
)

from ocean.domain.enums import ExecutionStatus, RiskLevel
from ocean.domain.execution import Execution
from ocean.domain.policy import PolicyEngine
from ocean.event_sourcing.replay import EventReplayer
from runtime.control import CancellationToken

from runtime import (
    ActiveExecutionRegistry,
    CapabilityExecutor,
    ExecutionController,
    ExecutionHandle,
    ExecutionRequest,
    ExecutionResult,
    ExecutionRuntime,
    ExecutorRegistry,
)

class SuccessfulExecutor(CapabilityExecutor):
    def execute(self, request, context):
        return ExecutionResult.succeeded(
            {
                "operation": request.operation,
                "arguments": request.arguments,
            }
        )

class CpuBurningExecutor(CapabilityExecutor):
    def execute(self, request, context):
        while True:
            _ = 123456789 * 987654321

class MemoryBurningExecutor(CapabilityExecutor):
    def execute(self, request, context):
        import time

        allocations = []

        while True:
            allocations.append(bytearray(1024 * 1024))
            time.sleep(0.01)

class ChildCpuBurningExecutor(CapabilityExecutor):
    def execute(self, request, context):
        import subprocess
        subprocess.Popen(["/usr/bin/python3", "-c", "while True: pass"])
        while True:
            time.sleep(1)

class LargeOutputExecutor(CapabilityExecutor):
    def execute(self, request, context):
        return ExecutionResult.succeeded(
            {"payload": "x" * 10_000}
        )

class FailingExecutor(CapabilityExecutor):
    def execute(self, request, context):
        return ExecutionResult.failed("controlled failure")

class CancellationHangingExecutor(CapabilityExecutor):
    def execute(self, request, context):
        import time

        while True:
            time.sleep(1)

class RaisingExecutor(CapabilityExecutor):
    def execute(self, request, context):
        raise RuntimeError("executor crashed")


class PidRecordingHangingExecutor(CapabilityExecutor):
    def execute(self, request, context):
        pid_path = request.arguments["pid_path"]
        heartbeat_path = request.arguments["heartbeat_path"]
        with open(pid_path, "w", encoding="utf-8") as handle:
            handle.write(str(os.getpid()))
        while True:
            with open(heartbeat_path, "a", encoding="utf-8") as handle:
                handle.write("beat\n")
            time.sleep(0.01)


class CrashWithoutResultExecutor(CapabilityExecutor):
    def execute(self, request, context):
        os._exit(17)


class NonSerializableExecutor(CapabilityExecutor):
    def __init__(self):
        self._callback = lambda: None

    def execute(self, request, context):
        return ExecutionResult.succeeded("unreachable")


def make_runtime(executor, isolation=None, governance=None):
    capabilities = CapabilityRegistry()

    capabilities.register(
        CapabilitySpec(
            name="test",
            description="Test capability",
            execution_strategy="test_executor",
            operations={
                "run": OperationSpec(
                    name="run",
                    description="Run a test operation",
                    risk_level=RiskLevel.SAFE,
                ),
            },
        )
    )

    executors = ExecutorRegistry()
    executors.register("test_executor", executor)

    return ExecutionRuntime(
        capabilities=capabilities,
        policy=PolicyEngine(),
        executors=executors,
        isolation=isolation,
        governance=governance,
    )

def test_execution_controller_allows_first_terminal_commit():
    controller = ExecutionController()

    result = controller.commit_terminal(lambda: "success")

    assert result == "success"
    assert controller.is_terminal is True

def test_process_isolation_backend_hard_terminates_on_cancellation():
    from runtime.isolation import ProcessIsolationBackend
    from runtime.resources import ExecutionResourceLimits
    from runtime.control import ExecutionContext, ExecutionCancelled

    backend = ProcessIsolationBackend()

    token = CancellationToken()

    context = ExecutionContext(
        execution_id="exec-cancel-test",
        cancellation=token,
        resource_limits=ExecutionResourceLimits(),
    )

    request = ExecutionRequest(
        task_id="task-1",
        capability="test",
        operation="hang",
        execution_id="exec-cancel-test",
    )

    def cancel():
        time.sleep(0.2)
        token.cancel()

    import threading

    cancellation_thread = threading.Thread(
        target=cancel,
        daemon=True,
    )
    cancellation_thread.start()

    with pytest.raises(ExecutionCancelled):
        backend.execute(
            CancellationHangingExecutor(),
            request,
            context,
        )

    cancellation_thread.join(timeout=1)
    assert not cancellation_thread.is_alive()

def test_execution_controller_rejects_second_terminal_commit():
    controller = ExecutionController()

    first = controller.commit_terminal(lambda: "success")
    second = controller.commit_terminal(lambda: "timeout")

    assert first == "success"
    assert second is None
    assert controller.is_terminal is True

class ProcessAwareExecutor(CapabilityExecutor):
    def execute(self, request, context):
        import os

        return ExecutionResult.succeeded(
            {
                "pid": os.getpid(),
                "execution_id": context.execution_id,
            }
        )

def test_execution_controller_allows_exactly_one_concurrent_terminal_commit():
    controller = ExecutionController()
    barrier = Barrier(8)
    results = []
    results_lock = Lock()

    def contender(name):
        barrier.wait()
        result = controller.commit_terminal(lambda: name)
        with results_lock:
            results.append(result)

    threads = [
        Thread(target=contender, args=(f"terminal-{i}",))
        for i in range(8)
    ]

    for thread in threads:
        thread.start()

    for thread in threads:
        thread.join()

    winners = [result for result in results if result is not None]

    assert len(winners) == 1
    assert winners[0].startswith("terminal-")
    assert len(results) == 8
    assert controller.is_terminal is True


def test_runtime_success():
    runtime = make_runtime(SuccessfulExecutor())

    result = runtime.execute(
        ExecutionRequest(
            task_id="task-1",
            capability="test",
            operation="run",
            arguments={"value": 42},
        )
    )

    assert result.success is True
    assert result.result == {
        "operation": "run",
        "arguments": {"value": 42},
    }

def test_runtime_passes_resource_limits_to_execution_context():
    from runtime.resources import ExecutionResourceLimits

    limits = ExecutionResourceLimits(
        timeout_seconds=10,
        memory_bytes=128 * 1024 * 1024,
        cpu_seconds=5,
        max_output_bytes=1024 * 1024,
        max_worker_lifetime_seconds=20,
    )

    observed = {}

    class ResourceObservingExecutor(CapabilityExecutor):
        def execute(self, request, context):
            observed["request_limits"] = request.resource_limits
            observed["context_limits"] = context.resource_limits
            return ExecutionResult.succeeded()

    runtime = make_runtime(ResourceObservingExecutor())

    runtime.execute(
        ExecutionRequest(
            task_id="task-1",
            capability="test",
            operation="run",
            resource_limits=limits,
        )
    )

    assert observed["request_limits"] == limits
    assert observed["context_limits"] == limits


def test_request_resource_timeout_is_enforced_without_legacy_argument():
    from runtime.isolation import ProcessIsolationBackend
    from runtime.resources import ExecutionResourceLimits

    started = time.monotonic()
    result = make_runtime(
        CancellationHangingExecutor(),
        isolation=ProcessIsolationBackend(),
    ).execute(
        ExecutionRequest(
            task_id="task-timeout",
            capability="test",
            operation="run",
            resource_limits=ExecutionResourceLimits(timeout_seconds=0.15),
        )
    )

    assert result.success is False
    assert result.metadata["failure_type"] == "timeout"
    assert time.monotonic() - started < 2.0


def test_resource_float_limits_reject_non_finite_values():
    from runtime.resources import ExecutionResourceLimits

    for field in ("timeout_seconds", "cpu_seconds", "max_worker_lifetime_seconds"):
        with pytest.raises(ValueError):
            ExecutionResourceLimits(**{field: float("nan")})
        with pytest.raises(ValueError):
            ExecutionResourceLimits(**{field: float("inf")})


def test_submit_execution_handle_can_be_removed_from_registry():
    runtime = make_runtime(SuccessfulExecutor())

    handle = runtime.submit(
        ExecutionRequest(
            task_id="task-1",
            capability="test",
            operation="run",
        )
    )

    assert runtime.active_executions.get(handle.execution_id) is handle

    removed = runtime.active_executions.remove(handle.execution_id)

    assert removed is handle
    assert runtime.active_executions.get(handle.execution_id) is None

def test_runtime_emits_execution_lifecycle_events():
    runtime = make_runtime(SuccessfulExecutor())

    result = runtime.execute(
        ExecutionRequest(
            task_id="task-1",
            capability="test",
            operation="run",
        )
    )

    assert result.success

    events = runtime.event_bus.history()

    assert [event.type for event in events] == [
        "ExecutionCreated",
        "ExecutionStarted",
        "ExecutionVerified",
        "ExecutionSucceeded",
    ]


def test_runtime_propagates_correlation_and_causation():
    runtime = make_runtime(SuccessfulExecutor())

    runtime.execute(
        ExecutionRequest(
            task_id="task-1",
            capability="test",
            operation="run",
            correlation_id="corr-1",
            causation_id="cause-1",
            source="scheduler",
        )
    )

    events = runtime.event_bus.history()

    assert events[0].correlation_id == "corr-1"
    assert events[0].causation_id == "cause-1"

    assert events[1].correlation_id == "corr-1"
    assert events[1].causation_id == events[0].id

    assert events[2].correlation_id == "corr-1"
    assert events[2].causation_id == events[1].id


def test_runtime_rejects_human_required_policy():
    capabilities = CapabilityRegistry()

    capabilities.register(
        CapabilitySpec(
            name="important",
            description="Important capability",
            execution_strategy="test_executor",
            operations={
                "run": OperationSpec(
                    name="run",
                    description="Important operation",
                    risk_level=RiskLevel.IMPORTANT,
                ),
            },
        )
    )

    executors = ExecutorRegistry()
    executors.register("test_executor", SuccessfulExecutor())

    from ocean.domain.event_bus import EventBus

    event_bus = EventBus()

    runtime = ExecutionRuntime(
        capabilities=capabilities,
        policy=PolicyEngine(),
        executors=executors,
        event_bus=event_bus,
    )

    with pytest.raises(PolicyViolation):
        runtime.execute(
            ExecutionRequest(
                task_id="task-1",
                capability="important",
                operation="run",
            )
        )

    assert event_bus.history() == []


def test_runtime_handles_structured_executor_failure():
    runtime = make_runtime(FailingExecutor())

    result = runtime.execute(
        ExecutionRequest(
            task_id="task-1",
            capability="test",
            operation="run",
        )
    )

    assert result.success is False
    assert result.error == "controlled failure"

    assert [
        event.type
        for event in runtime.event_bus.history()
    ] == [
        "ExecutionCreated",
        "ExecutionStarted",
        "ExecutionFailed",
    ]


def test_runtime_converts_executor_exception_to_failure():
    runtime = make_runtime(RaisingExecutor())

    result = runtime.execute(
        ExecutionRequest(
            task_id="task-1",
            capability="test",
            operation="run",
        )
    )

    assert result.success is False
    assert result.error == "executor crashed"

    assert [
        event.type
        for event in runtime.event_bus.history()
    ] == [
        "ExecutionCreated",
        "ExecutionStarted",
        "ExecutionFailed",
    ]


def test_request_can_supply_execution_id():
    runtime = make_runtime(SuccessfulExecutor())

    runtime.execute(
        ExecutionRequest(
            task_id="task-1",
            capability="test",
            operation="run",
            execution_id="exec-fixed",
        )
    )

    event = runtime.event_bus.history()[0]

    assert event.payload["id"] == "exec-fixed"


def test_cancelled_execution_emits_execution_cancelled_event():
    runtime = make_runtime(SuccessfulExecutor())

    token = CancellationToken()
    token.cancel()

    result = runtime.execute(
        ExecutionRequest(
            task_id="task-1",
            capability="test",
            operation="run",
        ),
        cancellation=token,
    )

    assert result.success is False
    assert result.error == "cancelled"

    events = runtime.event_bus.history()

    assert [event.type for event in events] == [
        "ExecutionCreated",
        "ExecutionCancelled",
    ]

    assert events[-1].payload["id"] == events[0].payload["id"]
    assert events[-1].causation_id == events[0].id
    assert events[-1].correlation_id == events[0].correlation_id


def test_cancelled_execution_replays_to_cancelled_state():
    runtime = make_runtime(SuccessfulExecutor())

    token = CancellationToken()
    token.cancel()

    runtime.execute(
        ExecutionRequest(
            task_id="task-1",
            capability="test",
            operation="run",
        ),
        cancellation=token,
    )

    events = runtime.event_bus.history()
    state = EventReplayer().replay(events)

    execution_id = events[0].payload["id"]
    execution = state.executions[execution_id]

    assert execution.status == ExecutionStatus.CANCELLED
    assert execution.error == "cancelled"


def test_running_execution_can_be_cancelled():
    cancellation = CancellationToken()

    class CancellingExecutor(CapabilityExecutor):
        def execute(self, request, context):
            cancellation.cancel()
            context.raise_if_cancelled()
            return ExecutionResult.succeeded()

    runtime = make_runtime(CancellingExecutor())

    result = runtime.execute(
        ExecutionRequest(
            task_id="task-1",
            capability="test",
            operation="run",
        ),
        cancellation=cancellation,
    )

    assert result.success is False
    assert result.error == "cancelled"

    events = runtime.event_bus.history()

    assert [event.type for event in events] == [
        "ExecutionCreated",
        "ExecutionStarted",
        "ExecutionCancelled",
    ]


def test_execution_cannot_be_cancelled_after_terminal_state():
    execution = Execution(
        task_id="task-1",
        capability="test",
        operation="run",
    )

    execution.start()
    execution.succeed("done")

    with pytest.raises(InvalidStateTransition):
        execution.cancel()
def test_execution_timeout_emits_execution_timed_out_event():
    runtime = make_runtime(SuccessfulExecutor())

    result = runtime.execute(
        ExecutionRequest(
            task_id="task-1",
            capability="test",
            operation="run",
        ),
        timeout_seconds=0,
    )

    assert result.success is False
    assert result.error == "timed out"

    events = runtime.event_bus.history()

    assert [event.type for event in events] == [
        "ExecutionCreated",
        "ExecutionStarted",
        "ExecutionTimedOut",
    ]

    assert events[-1].payload["id"] == events[0].payload["id"]
    assert events[-1].causation_id == events[1].id
    assert events[-1].correlation_id == events[0].correlation_id


def test_execution_timeout_replays_to_timed_out_state():
    runtime = make_runtime(SuccessfulExecutor())

    runtime.execute(
        ExecutionRequest(
            task_id="task-1",
            capability="test",
            operation="run",
        ),
        timeout_seconds=0,
    )

    events = runtime.event_bus.history()
    state = EventReplayer().replay(events)

    execution_id = events[0].payload["id"]
    execution = state.executions[execution_id]

    assert execution.status == ExecutionStatus.TIMED_OUT
    assert execution.error == "timed out"


def test_execution_cannot_time_out_after_terminal_state():
    execution = Execution(
        task_id="task-1",
        capability="test",
        operation="run",
    )

    execution.start()
    execution.succeed("done")

    with pytest.raises(InvalidStateTransition):
        execution.time_out()
def test_execution_handle_can_cancel():
    token = CancellationToken()

    handle = ExecutionHandle(
        execution_id="exec-1",
        cancellation=token,
    )

    assert handle.is_cancelled is False

    handle.cancel()

    assert handle.is_cancelled is True
def test_active_execution_registry_registers_and_gets_handle():
    registry = ActiveExecutionRegistry()
    token = CancellationToken()

    handle = ExecutionHandle(
        execution_id="exec-1",
        cancellation=token,
    )

    registry.register(handle)

    assert registry.get("exec-1") is handle


def test_active_execution_registry_removes_handle():
    registry = ActiveExecutionRegistry()
    token = CancellationToken()

    handle = ExecutionHandle(
        execution_id="exec-1",
        cancellation=token,
    )

    registry.register(handle)

    removed = registry.remove("exec-1")

    assert removed is handle
    assert registry.get("exec-1") is None


def test_active_execution_registry_lists_active_handles():
    registry = ActiveExecutionRegistry()

    first = ExecutionHandle(
        execution_id="exec-1",
        cancellation=CancellationToken(),
        controller=ExecutionController(),
    )
    second = ExecutionHandle(
        execution_id="exec-2",
        cancellation=CancellationToken(),
        controller=ExecutionController(),
    )

    registry.register(first)
    registry.register(second)

    handles = list(registry.list())

    assert handles == [first, second]


def test_active_execution_registry_rejects_duplicate_execution_ids():
    registry = ActiveExecutionRegistry()

    first = ExecutionHandle(
        execution_id="exec-1",
        cancellation=CancellationToken(),
        controller=ExecutionController(),
    )
    second = ExecutionHandle(
        execution_id="exec-1",
        cancellation=CancellationToken(),
        controller=ExecutionController(),
    )

    registry.register(first)

    with pytest.raises(ValueError):
        registry.register(second)


def test_in_process_isolation_backend_delegates_to_executor():
    from runtime.isolation import InProcessIsolationBackend

    backend = InProcessIsolationBackend()
    executor = SuccessfulExecutor()
    from runtime.control import ExecutionContext

    context = ExecutionContext(
        execution_id="exec-1",
        cancellation=CancellationToken(),
    )
    request = ExecutionRequest(
        task_id="task-1",
        capability="test",
        operation="run",
    )

    result = backend.execute(executor, request, context)

    assert result.success is True
    assert result.result["operation"] == "run"


def test_isolation_backend_preserves_executor_failure():
    from runtime.isolation import InProcessIsolationBackend

    backend = InProcessIsolationBackend()
    executor = FailingExecutor()
    from runtime.control import ExecutionContext

    context = ExecutionContext(
        execution_id="exec-1",
        cancellation=CancellationToken(),
    )
    request = ExecutionRequest(
        task_id="task-1",
        capability="test",
        operation="run",
    )

    result = backend.execute(executor, request, context)

    assert result.success is False
    assert result.error == "controlled failure"
def test_runtime_uses_injected_isolation_backend():
    class RecordingIsolationBackend:
        def __init__(self):
            self.calls = []

        def execute(self, executor, request, context):
            self.calls.append((executor, request, context))
            return executor.execute(request, context)

    isolation = RecordingIsolationBackend()
    runtime = make_runtime(SuccessfulExecutor(), isolation=isolation)

    request = ExecutionRequest(
        task_id="task-1",
        capability="test",
        operation="run",
    )

    result = runtime.execute(request)

    assert result.success is True
    assert len(isolation.calls) == 1
    assert isolation.calls[0][1].execution_id is not None


def test_isolation_backend_contains_executor_exception():
    from runtime.isolation import InProcessIsolationBackend
    from runtime.control import ExecutionContext

    backend = InProcessIsolationBackend()
    executor = RaisingExecutor()

    context = ExecutionContext(
        execution_id="exec-1",
        cancellation=CancellationToken(),
    )

    request = ExecutionRequest(
        task_id="task-1",
        capability="test",
        operation="run",
    )

    result = backend.execute(executor, request, context)

    assert result.success is False
    assert result.error == "executor crashed"
    assert result.metadata["failure_type"] == "executor_exception"
    assert result.metadata["exception_type"] == "RuntimeError"


def test_runtime_preserves_isolation_failure_as_execution_failure():
    runtime = make_runtime(RaisingExecutor())

    result = runtime.execute(
        ExecutionRequest(
            task_id="task-1",
            capability="test",
            operation="run",
        )
    )

    assert result.success is False
    assert result.error == "executor crashed"

    events = runtime.event_bus.history()

    assert [event.type for event in events] == [
        "ExecutionCreated",
        "ExecutionStarted",
        "ExecutionFailed",
    ]

    assert events[-1].payload["error"] == "executor crashed"


def test_isolation_backend_preserves_structured_executor_failure():
    from runtime.isolation import InProcessIsolationBackend
    from runtime.control import ExecutionContext

    backend = InProcessIsolationBackend()
    executor = FailingExecutor()

    context = ExecutionContext(
        execution_id="exec-1",
        cancellation=CancellationToken(),
    )

    request = ExecutionRequest(
        task_id="task-1",
        capability="test",
        operation="run",
    )

    result = backend.execute(executor, request, context)

    assert result.success is False
    assert result.error == "controlled failure"
    assert result.metadata == {}


def test_execution_result_codec_round_trips_success():
    from runtime.types import ExecutionResultCodec

    original = ExecutionResult.succeeded(
        {"value": 42, "items": ["a", "b"]},
        metadata={"executor": "test"},
    )

    encoded = ExecutionResultCodec.encode(original)
    decoded = ExecutionResultCodec.decode(encoded)

    assert decoded == original


def test_execution_result_codec_round_trips_failure():
    from runtime.types import ExecutionResultCodec

    original = ExecutionResult.failed(
        "controlled failure",
        metadata={
            "failure_type": "executor_exception",
            "exception_type": "RuntimeError",
        },
    )

    encoded = ExecutionResultCodec.encode(original)
    decoded = ExecutionResultCodec.decode(encoded)

    assert decoded == original


def test_execution_result_codec_rejects_non_serializable_result():
    from runtime.types import ExecutionResultCodec

    result = ExecutionResult.succeeded(
        object(),
    )

    with pytest.raises(ValueError, match="not JSON serializable"):
        ExecutionResultCodec.encode(result)


def test_execution_result_codec_rejects_invalid_json():
    from runtime.types import ExecutionResultCodec

    with pytest.raises(ValueError, match="invalid execution result payload"):
        ExecutionResultCodec.decode("not-json")


def test_execution_result_codec_rejects_non_object_payload():
    from runtime.types import ExecutionResultCodec

    with pytest.raises(
        ValueError,
        match="must decode to an object",
    ):
        ExecutionResultCodec.decode("[]")


def test_execution_result_codec_rejects_missing_fields():
    from runtime.types import ExecutionResultCodec

    with pytest.raises(
        ValueError,
        match="invalid fields",
    ):
        ExecutionResultCodec.decode(
            '{"success": true, "result": null}'
        )


def test_execution_result_codec_rejects_invalid_success_type():
    from runtime.types import ExecutionResultCodec

    with pytest.raises(
        ValueError,
        match="'success' must be a boolean",
    ):
        ExecutionResultCodec.decode(
            '{"success": "yes", "result": null, "error": null, "metadata": {}}'
        )
def test_process_isolation_backend_executes_in_child_process():
    from runtime.isolation import ProcessIsolationBackend
    from runtime.resources import ExecutionResourceLimits
    from runtime.control import ExecutionContext

    backend = ProcessIsolationBackend()

    token = CancellationToken()
    context = ExecutionContext(
        execution_id="exec-process-test",
        cancellation=token,
        resource_limits=ExecutionResourceLimits(),
    )

    request = ExecutionRequest(
        task_id="task-1",
        capability="test",
        operation="run",
        execution_id="exec-process-test",
    )

    import os

    result = backend.execute(
        ProcessAwareExecutor(),
        request,
        context,
    )

    assert result.success is True
    assert result.result["pid"] != os.getpid()
    assert result.result["execution_id"] == "exec-process-test"
def test_process_isolation_enforces_max_output_bytes():
    from runtime.isolation import ProcessIsolationBackend
    from runtime.resources import ExecutionResourceLimits
    from runtime.control import ExecutionContext

    backend = ProcessIsolationBackend()

    limits = ExecutionResourceLimits(
        max_output_bytes=1_000,
    )

    context = ExecutionContext(
        execution_id="exec-output-limit-test",
        cancellation=CancellationToken(),
        resource_limits=limits,
    )

    request = ExecutionRequest(
        task_id="task-1",
        capability="test",
        operation="large-output",
        execution_id="exec-output-limit-test",
        resource_limits=limits,
    )

    result = backend.execute(
        LargeOutputExecutor(),
        request,
        context,
    )

    assert result.success is False
    assert result.metadata["failure_type"] == "resource_limit_exceeded"
    assert result.metadata["resource"] == "max_output_bytes"
    assert result.metadata["limit"] == 1_000
    assert result.metadata["observed"] > 1_000
def test_process_isolation_enforces_cpu_limit():
    from runtime.isolation import ProcessIsolationBackend
    from runtime.resources import ExecutionResourceLimits
    from runtime.control import ExecutionContext, ExecutionTimedOut

    backend = ProcessIsolationBackend()

    limits = ExecutionResourceLimits(
        cpu_seconds=0.2,
    )

    context = ExecutionContext(
        execution_id="exec-cpu-limit-test",
        cancellation=CancellationToken(),
        resource_limits=limits,
    )

    request = ExecutionRequest(
        task_id="task-1",
        capability="test",
        operation="cpu-burn",
        execution_id="exec-cpu-limit-test",
        resource_limits=limits,
    )

    with pytest.raises(ExecutionTimedOut):
        backend.execute(
            CpuBurningExecutor(),
            request,
            context,
        )


def test_process_isolation_enforces_cpu_limit_across_descendants():
    from runtime.isolation import ProcessIsolationBackend
    from runtime.resources import ExecutionResourceLimits
    from runtime.control import ExecutionContext, ExecutionTimedOut

    limits = ExecutionResourceLimits(cpu_seconds=0.2)
    context = ExecutionContext(
        execution_id="exec-child-cpu-limit-test",
        cancellation=CancellationToken(),
        resource_limits=limits,
    )
    request = ExecutionRequest(
        task_id="task-child-cpu",
        capability="test",
        operation="child-cpu-burn",
        execution_id="exec-child-cpu-limit-test",
        resource_limits=limits,
    )

    with pytest.raises(ExecutionTimedOut):
        ProcessIsolationBackend().execute(ChildCpuBurningExecutor(), request, context)


def test_process_isolation_enforces_memory_limit():
    from runtime.isolation import ProcessIsolationBackend
    from runtime.resources import ExecutionResourceLimits
    from runtime.control import ExecutionContext, ExecutionTimedOut

    backend = ProcessIsolationBackend()

    limits = ExecutionResourceLimits(
        memory_bytes=64 * 1024 * 1024,
    )

    context = ExecutionContext(
        execution_id="exec-memory-limit-test",
        cancellation=CancellationToken(),
        resource_limits=limits,
    )

    request = ExecutionRequest(
        task_id="task-1",
        capability="test",
        operation="memory-burn",
        execution_id="exec-memory-limit-test",
        resource_limits=limits,
    )

    with pytest.raises(ExecutionTimedOut):
        backend.execute(
            MemoryBurningExecutor(),
            request,
            context,
        )


def test_process_isolation_deadline_kills_worker_and_stops_side_effects(tmp_path):
    from runtime.isolation import ProcessIsolationBackend
    from runtime.resources import ExecutionResourceLimits
    from runtime.control import ExecutionContext, ExecutionTimedOut

    pid_path = tmp_path / "worker.pid"
    heartbeat_path = tmp_path / "heartbeat.log"
    backend = ProcessIsolationBackend()
    context = ExecutionContext(
        execution_id="exec-process-death-test",
        cancellation=CancellationToken(),
        deadline=time.monotonic() + 0.3,
        resource_limits=ExecutionResourceLimits(),
    )
    request = ExecutionRequest(
        task_id="task-1",
        capability="test",
        operation="hang",
        execution_id="exec-process-death-test",
        arguments={
            "pid_path": str(pid_path),
            "heartbeat_path": str(heartbeat_path),
        },
    )

    with pytest.raises(ExecutionTimedOut):
        backend.execute(PidRecordingHangingExecutor(), request, context)

    worker_pid = int(pid_path.read_text(encoding="utf-8"))
    assert not __import__("psutil").pid_exists(worker_pid)
    heartbeat_size = heartbeat_path.stat().st_size
    time.sleep(0.1)
    assert heartbeat_path.stat().st_size == heartbeat_size


def test_process_isolation_worker_crash_returns_structured_failure():
    from runtime.isolation import ProcessIsolationBackend
    from runtime.control import ExecutionContext

    result = ProcessIsolationBackend().execute(
        CrashWithoutResultExecutor(),
        ExecutionRequest(
            task_id="task-1",
            capability="test",
            operation="crash",
        ),
        ExecutionContext(
            execution_id="exec-worker-crash-test",
            cancellation=CancellationToken(),
        ),
    )

    assert result.success is False
    assert result.metadata["failure_type"] == "worker_crash"


def test_process_isolation_non_serializable_executor_returns_failure():
    from runtime.isolation import ProcessIsolationBackend
    from runtime.control import ExecutionContext

    result = ProcessIsolationBackend().execute(
        NonSerializableExecutor(),
        ExecutionRequest(
            task_id="task-1",
            capability="test",
            operation="serialize",
        ),
        ExecutionContext(
            execution_id="exec-serialization-test",
            cancellation=CancellationToken(),
        ),
    )

    assert result.success is False
    assert result.metadata["failure_type"] == "worker_start_failure"


def test_governance_denial_prevents_isolated_worker_start(tmp_path):
    from runtime.isolation import ProcessIsolationBackend
    from runtime.control import ExecutionContext

    class DenyingGovernance:
        def evaluate(self, request):
            return type(
                "Decision",
                (),
                {"executable": False, "reasons": ("denied",)},
            )()

    pid_path = tmp_path / "never-started.pid"
    runtime = make_runtime(
        PidRecordingHangingExecutor(),
        isolation=ProcessIsolationBackend(),
        governance=DenyingGovernance(),
    )

    with pytest.raises(Exception, match="denied"):
        runtime.execute(
            ExecutionRequest(
                task_id="task-1",
                capability="test",
                operation="run",
                arguments={
                    "pid_path": str(pid_path),
                    "heartbeat_path": str(tmp_path / "heartbeat.log"),
                },
            )
        )

    assert not pid_path.exists()


def test_execution_supervisor_runs_asynchronously():
    from runtime import ExecutionSupervisor
    import threading

    started = threading.Event()
    release = threading.Event()

    class BlockingExecutor(CapabilityExecutor):
        def execute(self, request, context):
            started.set()
            release.wait(timeout=5)
            return ExecutionResult.succeeded("done")

    runtime = make_runtime(BlockingExecutor())
    supervisor = ExecutionSupervisor(runtime, max_workers=1)

    try:
        handle = supervisor.submit(
            ExecutionRequest(
                task_id="task-1",
                capability="test",
                operation="run",
            )
        )

        assert started.wait(timeout=2)
        assert handle.result is None
        assert supervisor.active_executions.get(handle.execution_id) is handle

        release.set()

        future = supervisor.future(handle.execution_id)
        assert future is not None
        assert future.result(timeout=2).success is True
        assert handle.result is not None
        assert handle.result.success is True
    finally:
        release.set()
        supervisor.shutdown()


def test_execution_supervisor_cleans_up_completed_execution():
    from runtime import ExecutionSupervisor

    runtime = make_runtime(SuccessfulExecutor())
    supervisor = ExecutionSupervisor(runtime, max_workers=1)

    try:
        handle = supervisor.submit(
            ExecutionRequest(
                task_id="task-1",
                capability="test",
                operation="run",
            )
        )

        future = supervisor.future(handle.execution_id)
        assert future is not None
        assert future.result(timeout=2).success is True

        assert handle.result is not None
        assert supervisor.active_executions.get(handle.execution_id) is None
        assert supervisor.future(handle.execution_id) is None
    finally:
        supervisor.shutdown()


def test_execution_supervisor_propagates_runtime_failure():
    from runtime import ExecutionSupervisor

    runtime = make_runtime(FailingExecutor())
    supervisor = ExecutionSupervisor(runtime, max_workers=1)

    try:
        handle = supervisor.submit(
            ExecutionRequest(
                task_id="task-1",
                capability="test",
                operation="run",
            )
        )

        future = supervisor.future(handle.execution_id)
        assert future is not None

        result = future.result(timeout=2)

        assert result.success is False
        assert result.error == "controlled failure"
        assert handle.result == result
    finally:
        supervisor.shutdown()


def test_execution_supervisor_preserves_execution_id():
    from runtime import ExecutionSupervisor

    runtime = make_runtime(SuccessfulExecutor())
    supervisor = ExecutionSupervisor(runtime, max_workers=1)

    try:
        handle = supervisor.submit(
            ExecutionRequest(
                task_id="task-1",
                capability="test",
                operation="run",
                execution_id="exec-fixed",
            )
        )

        assert handle.execution_id == "exec-fixed"

        future = supervisor.future(handle.execution_id)
        assert future is not None
        assert future.result(timeout=2).success is True
    finally:
        supervisor.shutdown()


def test_execution_supervisor_rejects_duplicate_execution_id():
    from runtime import ExecutionSupervisor

    runtime = make_runtime(SuccessfulExecutor())
    supervisor = ExecutionSupervisor(runtime, max_workers=1)

    try:
        first = supervisor.submit(
            ExecutionRequest(
                task_id="task-1",
                capability="test",
                operation="run",
                execution_id="exec-duplicate",
            )
        )

        with pytest.raises(ValueError):
            supervisor.submit(
                ExecutionRequest(
                    task_id="task-2",
                    capability="test",
                    operation="run",
                    execution_id="exec-duplicate",
                )
            )

        future = supervisor.future(first.execution_id)
        assert future is not None
        assert future.result(timeout=2).success is True
    finally:
        supervisor.shutdown()


def test_execution_supervisor_supports_concurrent_executions():
    from runtime import ExecutionSupervisor
    import threading

    first_started = threading.Event()
    second_started = threading.Event()
    release = threading.Event()

    class ConcurrentExecutor(CapabilityExecutor):
        def execute(self, request, context):
            if request.task_id == "task-1":
                first_started.set()
            else:
                second_started.set()

            release.wait(timeout=5)
            return ExecutionResult.succeeded(request.task_id)

    runtime = make_runtime(ConcurrentExecutor())
    supervisor = ExecutionSupervisor(runtime, max_workers=2)

    try:
        first = supervisor.submit(
            ExecutionRequest(
                task_id="task-1",
                capability="test",
                operation="run",
            )
        )
        second = supervisor.submit(
            ExecutionRequest(
                task_id="task-2",
                capability="test",
                operation="run",
            )
        )

        assert first_started.wait(timeout=2)
        assert second_started.wait(timeout=2)

        release.set()

        first_future = supervisor.future(first.execution_id)
        second_future = supervisor.future(second.execution_id)

        assert first_future is not None
        assert second_future is not None

        assert first_future.result(timeout=2).result == "task-1"
        assert second_future.result(timeout=2).result == "task-2"
    finally:
        release.set()
        supervisor.shutdown()


def test_execution_supervisor_enforces_worker_concurrency_limit():
    from runtime import ExecutionSupervisor
    import threading

    first_started = threading.Event()
    second_started = threading.Event()
    release = threading.Event()

    class BlockingExecutor(CapabilityExecutor):
        def execute(self, request, context):
            if request.task_id == "task-1":
                first_started.set()
            else:
                second_started.set()

            release.wait(timeout=5)
            return ExecutionResult.succeeded(request.task_id)

    runtime = make_runtime(BlockingExecutor())
    supervisor = ExecutionSupervisor(runtime, max_workers=1)

    try:
        first = supervisor.submit(
            ExecutionRequest(
                task_id="task-1",
                capability="test",
                operation="run",
            )
        )
        second = supervisor.submit(
            ExecutionRequest(
                task_id="task-2",
                capability="test",
                operation="run",
            )
        )

        assert first_started.wait(timeout=2)

        # The second execution is queued in the supervisor's worker pool.
        assert second_started.wait(timeout=0.2) is False

        release.set()

        first_future = supervisor.future(first.execution_id)
        second_future = supervisor.future(second.execution_id)

        assert first_future is not None
        assert second_future is not None

        assert first_future.result(timeout=2).success is True
        assert second_future.result(timeout=2).success is True
    finally:
        release.set()
        supervisor.shutdown()


def test_execution_supervisor_rejects_submission_after_shutdown():
    from runtime import ExecutionSupervisor

    runtime = make_runtime(SuccessfulExecutor())
    supervisor = ExecutionSupervisor(runtime, max_workers=1)

    supervisor.shutdown()

    with pytest.raises(RuntimeError, match="shut down"):
        supervisor.submit(
            ExecutionRequest(
                task_id="task-1",
                capability="test",
                operation="run",
            )
        )


def test_execution_supervisor_shutdown_is_idempotent():
    from runtime import ExecutionSupervisor

    runtime = make_runtime(SuccessfulExecutor())
    supervisor = ExecutionSupervisor(runtime, max_workers=1)

    supervisor.shutdown()
    supervisor.shutdown()


def test_execution_supervisor_rejects_invalid_worker_count():
    from runtime import ExecutionSupervisor

    runtime = make_runtime(SuccessfulExecutor())

    with pytest.raises(ValueError, match="max_workers"):
        ExecutionSupervisor(runtime, max_workers=0)


class EnvironmentProbeExecutor(CapabilityExecutor):
    def execute(self, request, context):
        return ExecutionResult.succeeded({"secret": os.environ.get("OPENAI_API_KEY")})


def test_process_isolation_scrubs_inherited_credentials(monkeypatch):
    from runtime.isolation import ProcessIsolationBackend
    from runtime.resources import ExecutionResourceLimits
    monkeypatch.setenv("OPENAI_API_KEY", "should-not-cross-process-boundary")
    request = ExecutionRequest(
        task_id="task-env", capability="test", operation="run", execution_id="exec-env"
    )
    context = __import__("runtime.control", fromlist=["ExecutionContext"]).ExecutionContext(
        execution_id="exec-env", cancellation=CancellationToken(),
        resource_limits=ExecutionResourceLimits(),
    )
    result = ProcessIsolationBackend().execute(EnvironmentProbeExecutor(), request, context)
    assert result.success is True
    assert result.result["secret"] is None


def test_runtime_unknown_executor_still_closes_execution():
    capabilities = CapabilityRegistry()
    capabilities.register(
        CapabilitySpec(
            name="test",
            description="Test capability",
            execution_strategy="missing_executor",
            operations={
                "run": OperationSpec(
                    name="run",
                    description="Run",
                    risk_level=RiskLevel.SAFE,
                )
            },
        )
    )
    runtime = ExecutionRuntime(
        capabilities=capabilities,
        policy=PolicyEngine(),
        executors=ExecutorRegistry(),
    )

    result = runtime.execute(
        ExecutionRequest(task_id="task-1", capability="test", operation="run")
    )

    assert result.success is False
    assert result.metadata["failure_type"] == "executor_resolution_failure"
    assert [e.type for e in runtime.event_bus.history()] == [
        "ExecutionCreated",
        "ExecutionStarted",
        "ExecutionFailed",
    ]


def test_runtime_invalid_output_still_closes_execution():
    capabilities = CapabilityRegistry()
    capabilities.register(
        CapabilitySpec(
            name="test",
            description="Test capability",
            execution_strategy="test_executor",
            operations={
                "run": OperationSpec(
                    name="run",
                    description="Run",
                    risk_level=RiskLevel.SAFE,
                    output_schema={
                        "type": "object",
                        "required": ["required_field"],
                    },
                )
            },
        )
    )
    executors = ExecutorRegistry()
    executors.register("test_executor", SuccessfulExecutor())
    runtime = ExecutionRuntime(
        capabilities=capabilities,
        policy=PolicyEngine(),
        executors=executors,
    )

    result = runtime.execute(
        ExecutionRequest(task_id="task-1", capability="test", operation="run")
    )

    assert result.success is False
    assert result.metadata["failure_type"] == "invalid_capability_output"
    assert [e.type for e in runtime.event_bus.history()] == [
        "ExecutionCreated",
        "ExecutionStarted",
        "ExecutionFailed",
    ]
