from ocean.domain.agent import Agent
from ocean.domain.event_bus import EventBus
from ocean.domain.task import Task
from ocean.orchestration.orchestrator import OrchestrationPorts, Orchestrator
from ocean.orchestration.types import AssignmentRequest, ExecutionIntent
from runtime import AgentRuntime, ExecutionSupervisor, Scheduler
from runtime.executor import CapabilityExecutor
from runtime.types import ExecutionResult


class SuccessfulExecutor(CapabilityExecutor):
    def execute(self, request, context):
        return ExecutionResult.succeeded(
            {"execution_id": request.execution_id}
        )


class TaskRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item


class AssignmentRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item

    def list(self):
        return list(self.items.values())

    def transaction(self):
        from contextlib import contextmanager

        @contextmanager
        def _tx():
            yield

        return _tx()


class AgentRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item


class MissionRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item


def make_runtime(executor):
    from tests.test_runtime import make_runtime as build_runtime
    return build_runtime(executor)


def build():
    events = EventBus()
    execution_runtime = make_runtime(SuccessfulExecutor())
    execution_runtime._event_bus = events
    supervisor = ExecutionSupervisor(execution_runtime)
    scheduler = Scheduler(supervisor, event_bus=events)
    agent_runtime = AgentRuntime(scheduler)

    tasks = TaskRepo()
    assignments = AssignmentRepo()
    agents = AgentRepo()
    missions = MissionRepo()

    ports = OrchestrationPorts(
        missions=missions,
        tasks=tasks,
        assignments=assignments,
        agents=agents,
        agent_runtime=agent_runtime,
        events=events,
    )

    return (
        Orchestrator(ports),
        tasks,
        assignments,
        agents,
        agent_runtime,
        scheduler,
        supervisor,
        execution_runtime,
        events,
    )


def test_scheduler_dispatches_orchestrated_execution():
    (
        orchestrator,
        tasks,
        assignments,
        agents,
        agent_runtime,
        scheduler,
        supervisor,
        execution_runtime,
        events,
    ) = build()

    try:
        agent = Agent(
            id="agent-execution",
            name="Execution Agent",
            role="worker",
            capabilities={"test"},
        )
        agents.save(agent)
        agent_runtime.register(agent)

        task = Task(title="Execute operation")
        tasks.save(task)

        created = orchestrator.assign(
            AssignmentRequest(
                task_id=task.id,
                agent_id=agent.id,
            )
        )

        assert created.success

        dispatched = orchestrator.dispatch(
            created.assignment_id,
            ExecutionIntent(
                capability="test",
                operation="run",
            ),
        )

        assert dispatched.success
        assert dispatched.execution_id is not None

        scheduled = scheduler.get(dispatched.execution_id)
        assert scheduled is not None
        assert scheduled.state.value == "queued"

        actual = scheduler.dispatch_next()

        assert actual is scheduled
        assert actual.state.value == "dispatched"

        assignment = assignments.get(created.assignment_id)
        assert assignment is not None
        assert assignment.status.value == "active"
        assert assignment.execution_id == dispatched.execution_id

        assert actual.handle is not None

        result = actual.handle.wait(timeout=2.0)

        assert result is not None
        assert result.success is True

    finally:
        scheduler.stop()
        supervisor.shutdown()


def test_scheduler_dispatch_produces_execution_events():
    (
        orchestrator,
        tasks,
        assignments,
        agents,
        agent_runtime,
        scheduler,
        supervisor,
        execution_runtime,
        events,
    ) = build()

    try:
        agent = Agent(
            id="agent-events",
            name="Event Agent",
            role="worker",
            capabilities={"test"},
        )
        agents.save(agent)
        agent_runtime.register(agent)

        task = Task(title="Event execution")
        tasks.save(task)

        created = orchestrator.assign(
            AssignmentRequest(
                task_id=task.id,
                agent_id=agent.id,
            )
        )

        dispatched = orchestrator.dispatch(
            created.assignment_id,
            ExecutionIntent(
                capability="test",
                operation="run",
            ),
        )

        scheduled = scheduler.dispatch_next()
        assert scheduled is not None
        assert scheduled.handle is not None

        future = supervisor.future(dispatched.execution_id)
        assert future is not None
        assert future.result(timeout=2).success is True

        event_types = [event.type for event in execution_runtime.event_bus.history()]

        assert "ExecutionCreated" in event_types
        assert "ExecutionStarted" in event_types
        assert "ExecutionSucceeded" in event_types

    finally:
        scheduler.stop()
        supervisor.shutdown()
