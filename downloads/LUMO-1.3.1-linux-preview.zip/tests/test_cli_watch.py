from ocean.cli import _persisted_mission_goal, main
from ocean.domain.event import Event
from ocean.orchestration.mission_engine import MissionResult
from eventing.sqlite_store import SQLiteEventStore
import sqlite3


def test_mission_watch_surfaces_persisted_stagnation(monkeypatch, capsys):
    class Store:
        def __init__(self):
            self.events = []

        def list(self, event_type=None):
            if event_type is None:
                return list(self.events)
            return [event for event in self.events if event.type == event_type]

    class Events:
        def __init__(self, store):
            self._store = store

    class RepositoryContext:
        class Context:
            def as_prompt_text(self):
                return "test repository context"

        def build(self, repository_root, objective):
            return self.Context()

    class Runtime:
        def __init__(self, repository_root):
            self.store = Store()
            self.events = Events(self.store)
            self.repository_context = RepositoryContext()
            self.closed = False

        def close(self):
            self.closed = True

    runtime_holder = {}

    def fake_runtime(repository_root):
        runtime = Runtime(repository_root)
        runtime_holder["runtime"] = runtime
        return runtime

    class FakeModel:
        pass

    class FakePlanner:
        def __init__(self, model, repository_context):
            self.model = model
            self.repository_context = repository_context

    class FakeEngine:
        def __init__(self, planner, executor, events):
            self.events = events

        def run(self, goal, *, mission_id, max_replans, contract=None):
            self.events._store.events.extend(
                [
                    Event(
                        id="evt-start",
                        type="MissionStarted",
                        payload={"goal": goal},
                        aggregate_type="mission",
                        aggregate_id=mission_id,
                        version=1,
                        sequence=1,
                        correlation_id=mission_id,
                        source="test",
                    ),
                    Event(
                        id="evt-stagnated",
                        type="MissionReplanStagnated",
                        payload={"error": "no novel objectives remain"},
                        aggregate_type="mission",
                        aggregate_id=mission_id,
                        version=1,
                        sequence=2,
                        correlation_id=mission_id,
                        source="test",
                    ),
                ]
            )
            return MissionResult(
                mission_id=mission_id,
                goal=goal,
                status="replan_stagnated",
                objective_results=(),
                completed_objectives=(),
                remaining_objectives=(),
                metadata={},
            )

    monkeypatch.setattr("ocean.cli.AutonomousImprovementRuntime", fake_runtime)
    monkeypatch.setattr("ocean.cli.build_strategic_model", lambda: FakeModel())
    monkeypatch.setattr("ocean.cli.StrategicMissionPlanner", FakePlanner)
    monkeypatch.setattr("ocean.cli.MissionEngine", FakeEngine)
    monkeypatch.setattr("ocean.cli.time.sleep", lambda _: None)

    print("TEST: entering main")
    exit_code = main(
        [
            "mission",
            "test mission",
            "--watch",
            "--interval",
            "1.0",
        ]
    )

    output = capsys.readouterr().out
    print("TEST EXIT:", exit_code)
    print("TEST OUTPUT:", repr(output))

    assert exit_code == 2
    assert "STATUS STAGNATED" in output
    assert "CURRENT ACTIVITY mission stagnated" in output
    assert "ERROR no novel objectives remain" in output
    assert "status=replan_stagnated" in output
    assert runtime_holder["runtime"].closed is True


def test_mission_cli_wires_runtime_improvement_into_objective_result(monkeypatch, capsys):
    from types import SimpleNamespace

    calls = {}

    class Store:
        def list(self, event_type=None):
            return []

    class Events:
        def __init__(self):
            self._store = Store()

    class RepositoryContext:
        class Context:
            def as_prompt_text(self):
                return "test repository context"

        def build(self, repository_root, objective):
            return self.Context()

    class Runtime:
        def __init__(self, repository_root):
            self.events = Events()
            self.repository_context = RepositoryContext()
            self.closed = False

        def improve(self, objective, *, mission_id=None):
            calls["objective"] = objective
            calls["mission_id"] = mission_id
            return SimpleNamespace(
                status="promoted",
                run_id="run-test",
                candidate_id="candidate-test",
                promoted_plan_revision_id="plan-rev-test",
                error=None,
                candidate_tests_passed=True,
            )

        def close(self):
            self.closed = True

    class FakeModel:
        pass

    class FakePlanner:
        def __init__(self, model, repository_context):
            self.model = model
            self.repository_context = repository_context

    class FakeEngine:
        def __init__(self, planner, executor, events):
            self.executor = executor

        def run(self, goal, *, mission_id, max_replans, contract=None):
            objective = SimpleNamespace(
                objective_id="objective-test",
                objective=goal,
            )
            objective_result = self.executor.execute(
                mission_id,
                objective,
            )
            return MissionResult(
                mission_id=mission_id,
                goal=goal,
                status="completed",
                objective_results=(objective_result,),
                completed_objectives=("objective-test",),
                remaining_objectives=(),
                metadata={},
            )

    monkeypatch.setattr("ocean.cli.AutonomousImprovementRuntime", Runtime)
    monkeypatch.setattr("ocean.cli.build_strategic_model", lambda: FakeModel())
    monkeypatch.setattr("ocean.cli.StrategicMissionPlanner", FakePlanner)
    monkeypatch.setattr("ocean.cli.MissionEngine", FakeEngine)

    exit_code = main(
        [
            "mission",
            "build Ocean autonomously",
        ]
    )

    output = capsys.readouterr().out

    assert exit_code == 0
    assert calls["objective"] == "build Ocean autonomously"
    assert calls["mission_id"]
    assert "status=completed" in output
    assert "objective=objective-test status=promoted" in output
    assert "run_id=run-test" in output
    assert "candidate_id=candidate-test" in output


def test_status_reads_persisted_events_without_openai_credentials(tmp_path, monkeypatch, capsys):
    state_directory = tmp_path / ".ocean"
    state_directory.mkdir()
    connection = sqlite3.connect(state_directory / "state.sqlite3")
    try:
        SQLiteEventStore(connection).append(
            Event(
                type="MissionStarted",
                payload={"mission_id": "mission-1", "goal": "durable status"},
                aggregate_type="mission",
                aggregate_id="mission-1",
            )
        )
    finally:
        connection.close()

    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    assert main(["status", "mission-1"]) == 0
    assert "MISSION mission-1" in capsys.readouterr().out


def test_status_prefers_mission_runtime_event_store(tmp_path, monkeypatch, capsys):
    state_directory = tmp_path / ".ocean"
    state_directory.mkdir()

    # The mission CLI persists its durable event stream in improvement.sqlite3,
    # while the service control plane may also have an unrelated state.sqlite3.
    # Status must follow the mission's actual durable source.
    runtime_connection = sqlite3.connect(state_directory / "improvement.sqlite3")
    try:
        SQLiteEventStore(runtime_connection).append(
            Event(
                type="MissionStarted",
                payload={"mission_id": "mission-runtime", "goal": "runtime-backed mission"},
                aggregate_type="mission",
                aggregate_id="mission-runtime",
            )
        )
        SQLiteEventStore(runtime_connection).append(
            Event(
                type="MissionReplanStagnated",
                payload={"mission_id": "mission-runtime", "error": "no novel objectives remain"},
                aggregate_type="mission",
                aggregate_id="mission-runtime",
            )
        )
    finally:
        runtime_connection.close()

    # Leave a separate service database present to reproduce the production
    # split that previously caused STATUS UNKNOWN after the CLI process exited.
    state_connection = sqlite3.connect(state_directory / "state.sqlite3")
    state_connection.close()

    monkeypatch.chdir(tmp_path)

    assert main(["status", "mission-runtime"]) == 0
    output = capsys.readouterr().out
    assert "MISSION mission-runtime" in output
    assert "STATUS STAGNATED" in output


def test_resume_goal_is_recovered_from_durable_event_history():
    from ocean.domain.event_bus import EventBus

    events = EventBus()
    events.publish(
        Event(
            type="MissionStarted",
            payload={"mission_id": "mission-1", "goal": "resume safely"},
            aggregate_type="mission",
            aggregate_id="mission-1",
        )
    )

    assert _persisted_mission_goal(events._store, "mission-1") == "resume safely"
