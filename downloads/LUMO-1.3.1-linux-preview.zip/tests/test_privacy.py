from datetime import datetime,timezone,timedelta
from ocean.privacy import *

def test_classification_retention_and_local_only():
    p=PrivacyPolicy(provider_mode="local_only"); assert p.classify("api_key")==DataClass.SECRET; assert not p.provider_allowed(DataClass.SECRET); now=datetime.now(timezone.utc); assert p.retention.expired(now-timedelta(days=31),DataClass.SECRET,now)

def test_export_and_deletion_plan():
    s=AccountPrivacyService(); e=s.export("a",[{"x":1}]); assert e.account_id=="a" and len(e.records)==1; assert s.deletion_plan("a",[1,2])["requires_confirmation"]
