from datetime import datetime, timezone

from ocean.domain.enums import MissionStatus
from ocean.domain.mission import Mission
from persistence.serializers.mission import MissionSerializer


def test_mission_serializer_round_trip():
    created_at = datetime(2026, 1, 1, 10, 0, tzinfo=timezone.utc)
    updated_at = datetime(2026, 1, 1, 10, 5, tzinfo=timezone.utc)

    mission = Mission(
        goal="Build Ocean Agent OS",
        task_ids=["task-1", "task-2"],
        metadata={
            "source": "test",
            "important": True,
        },
        id="mission-1",
        status=MissionStatus.ACTIVE,
        created_at=created_at,
        updated_at=updated_at,
    )

    serializer = MissionSerializer()

    serialized = serializer.serialize(mission)
    restored = serializer.deserialize(serialized)

    assert restored == mission


def test_mission_serializer_preserves_task_ids():
    mission = Mission(
        goal="Test task storage",
        task_ids=["task-3", "task-1", "task-2"],
        id="mission-2",
    )

    serializer = MissionSerializer()

    restored = serializer.deserialize(serializer.serialize(mission))

    assert restored.task_ids == ["task-3", "task-1", "task-2"]


def test_mission_serializer_preserves_status():
    mission = Mission(
        goal="Test status",
        id="mission-3",
        status=MissionStatus.PAUSED,
    )

    serializer = MissionSerializer()

    data = serializer.serialize(mission)

    assert data["status"] == MissionStatus.PAUSED.value

    restored = serializer.deserialize(data)

    assert restored.status == MissionStatus.PAUSED
