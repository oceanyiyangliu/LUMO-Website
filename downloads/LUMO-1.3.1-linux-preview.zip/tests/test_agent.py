import pytest

from ocean.core.errors import InvalidStateTransition
from ocean.domain.agent import Agent
from ocean.domain.enums import AgentStatus


def test_agent_starts_idle():
    a = Agent(name="Researcher-1", role="researcher", capabilities={"browser", "documents"})
    assert a.status == AgentStatus.IDLE


def test_agent_can_perform_declared_capability_only():
    a = Agent(name="A", role="general", capabilities={"filesystem"})
    assert a.can_perform("filesystem")
    assert not a.can_perform("browser")


def test_agent_lifecycle_idle_running_waiting_running_idle():
    a = Agent(name="A", role="general")
    a.transition(AgentStatus.RUNNING)
    a.transition(AgentStatus.WAITING)
    a.transition(AgentStatus.RUNNING)
    a.transition(AgentStatus.IDLE)
    assert a.status == AgentStatus.IDLE


def test_agent_terminated_is_terminal():
    a = Agent(name="A", role="general")
    a.transition(AgentStatus.TERMINATED)
    with pytest.raises(InvalidStateTransition):
        a.transition(AgentStatus.IDLE)


def test_agent_cannot_jump_idle_to_waiting_directly():
    a = Agent(name="A", role="general")
    with pytest.raises(InvalidStateTransition):
        a.transition(AgentStatus.WAITING)
