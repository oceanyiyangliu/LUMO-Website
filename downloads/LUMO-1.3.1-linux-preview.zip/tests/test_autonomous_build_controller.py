from __future__ import annotations

from dataclasses import dataclass

from ocean.domain.enums import MissionStatus, TaskStatus
from ocean.domain.event_bus import EventBus
from ocean.domain.mission import Mission
from ocean.domain.plan import PlanRevision
from ocean.domain.task import Task
from ocean.domain.decision import Decision
from ocean.domain.work_graph import WorkNodeKind
from ocean.planning import PlanningService
from ocean.planning.planner import PlanningResult
from ocean.orchestration.autonomous_build_controller import (
    AutonomousBuildController,
    AutonomousBuildObjective,
    AutonomousBuildStatus,
    EventAutonomousBuildStateStore,
    PlanningServiceBuildPlanner,
)
from persistence.in_memory import InMemoryRepository


class FakePlanner:
    def __init__(self, plan_factory):
        self.calls = []
        self.plan_factory = plan_factory

    def plan(self, *, mission, objective, iteration, previous_plan):
        self.calls.append((mission.id, iteration, previous_plan))
        return self.plan_factory(mission, iteration, previous_plan)


class FakePlanCoordinator:
    def __init__(self):
        self.calls = []

    def advance(self, plan_id):
        self.calls.append(plan_id)

        @dataclass(frozen=True)
        class Result:
            queued_node_ids: tuple[str, ...] = ()
            blocked_node_ids: tuple[str, ...] = ()
            errors: dict[str, str] = None

            def __post_init__(self):
                if self.errors is None:
                    object.__setattr__(self, "errors", {})

        return Result(queued_node_ids=("node-1",))


class FakePlanProvider:
    def get(self, plan_revision_id):
        return None


class FakeEvaluator:
    def __init__(self, value=False):
        self.value = value
        self.calls = []

    def evaluate(self, *, objective, mission, tasks, plan):
        self.calls.append((mission.id, tuple(t.id for t in tasks), plan.id if plan else None))
        return self.value


def make_plan(mission, revision, previous=None):
    return PlanRevision(
        mission_id=mission.id,
        revision=revision,
        decision_id=f"decision-{revision}",
        graph_id=f"graph-{revision}",
        parent_revision_id=(
            previous.id
            if revision > 1 and previous is not None
            else None
        ),
    )


def test_controller_creates_mission_and_persists_state():
    events = EventBus()
    missions = InMemoryRepository()
    tasks = InMemoryRepository()
    plans = InMemoryRepository()
    coordinator = FakePlanCoordinator()
    planner = FakePlanner(
        lambda mission, iteration, previous: make_plan(
            mission,
            iteration,
            previous,
        )
    )
    evaluator = FakeEvaluator()

    controller = AutonomousBuildController(
        events=events,
        missions=missions,
        tasks=tasks,
        plans=plans,
        plan_provider=FakePlanProvider(),
        plan_coordinator=coordinator,
        planner=planner,
        success_evaluator=evaluator,
    )

    result = controller.start(
        AutonomousBuildObjective(
            objective="Build Ocean autonomously",
            success_criteria=("objective achieved",),
        )
    )

    assert result.state.status is AutonomousBuildStatus.EXECUTING
    assert missions.get(result.state.mission_id) is not None
    assert plans.get(result.state.plan_revision_id) is not None
    assert coordinator.calls == [result.state.plan_revision_id]
    assert EventAutonomousBuildStateStore(events).get(result.state.mission_id) == result.state


def test_controller_resumes_from_durable_event_state():
    events = EventBus()
    missions = InMemoryRepository()
    tasks = InMemoryRepository()
    plans = InMemoryRepository()

    mission = Mission(goal="Resume build")
    missions.save(mission)

    plan = make_plan(mission, 1)
    plans.save(plan)

    events.publish(
        __import__("ocean.domain.event", fromlist=["Event"]).Event(
            type="AutonomousBuildStateChanged",
            payload={
                "controller_id": "autobuild-1",
                "mission_id": mission.id,
                "objective": mission.goal,
                "status": "executing",
                "iteration": 1,
                "plan_revision_id": plan.id,
                "reason": None,
                "metadata": {},
            },
            aggregate_type="autonomous_build",
            aggregate_id="autobuild-1",
            source="test",
        )
    )

    coordinator = FakePlanCoordinator()
    controller = AutonomousBuildController(
        events=events,
        missions=missions,
        tasks=tasks,
        plans=plans,
        plan_provider=FakePlanProvider(),
        plan_coordinator=coordinator,
        planner=FakePlanner(
            lambda mission, iteration, previous: make_plan(
                mission,
                iteration,
                previous,
            )
        ),
        success_evaluator=FakeEvaluator(),
    )

    result = controller.resume(mission.id)

    assert result.state.id == "autobuild-1"
    assert result.state.mission_id == mission.id
    assert result.state.plan_revision_id == plan.id
    assert coordinator.calls == [plan.id]
    assert len(controller._planner.calls) == 0


def test_controller_does_not_mark_mission_complete_without_objective_success():
    events = EventBus()
    missions = InMemoryRepository()
    tasks = InMemoryRepository()
    plans = InMemoryRepository()

    mission = Mission(goal="Do work")
    missions.save(mission)

    task = Task(
        title="work",
        mission_id=mission.id,
        status=TaskStatus.COMPLETED,
    )
    missions.get(mission.id).add_task(task.id)
    missions.save(mission)
    tasks.save(task)

    plan = make_plan(mission, 1)
    plans.save(plan)

    coordinator = FakePlanCoordinator()
    evaluator = FakeEvaluator(value=False)

    controller = AutonomousBuildController(
        events=events,
        missions=missions,
        tasks=tasks,
        plans=plans,
        plan_provider=FakePlanProvider(),
        plan_coordinator=coordinator,
        planner=FakePlanner(
            lambda mission, iteration, previous: make_plan(
                mission,
                iteration,
                previous,
            )
        ),
        success_evaluator=evaluator,
    )

    result = controller.start(
        AutonomousBuildObjective(
            objective=mission.goal,
            mission_id=mission.id,
        )
    )

    assert result.state.status is not AutonomousBuildStatus.COMPLETED
    assert missions.get(mission.id).status is not MissionStatus.COMPLETED


# New regression test: ensure coordinator advances are idempotent when previously recorded.
def test_resume_is_idempotent_when_coordinator_already_advanced():
    events = EventBus()
    missions = InMemoryRepository()
    tasks = InMemoryRepository()
    plans = InMemoryRepository()

    mission = Mission(goal="Resume once")
    missions.save(mission)

    plan = make_plan(mission, 1)
    plans.save(plan)

    # publish prior state + marker that coordinator already advanced this plan
    events.publish(
        __import__("ocean.domain.event", fromlist=["Event"]).Event(
            type="AutonomousBuildStateChanged",
            payload={
                "controller_id": "autobuild-1",
                "mission_id": mission.id,
                "objective": mission.goal,
                "status": "executing",
                "iteration": 1,
                "plan_revision_id": plan.id,
                "reason": None,
                "metadata": {},
            },
            aggregate_type="autonomous_build",
            aggregate_id="autobuild-1",
            source="test",
        )
    )

    events.publish(
        __import__("ocean.domain.event", fromlist=["Event"]).Event(
            type="PlanCoordinatorAdvanced",
            payload={"plan_revision_id": plan.id},
            aggregate_type="autonomous_build",
            aggregate_id="autobuild-1",
            source="test",
        )
    )

    coordinator = FakePlanCoordinator()
    controller = AutonomousBuildController(
        events=events,
        missions=missions,
        tasks=tasks,
        plans=plans,
        plan_provider=FakePlanProvider(),
        plan_coordinator=coordinator,
        planner=FakePlanner(
            lambda mission, iteration, previous: make_plan(
                mission,
                iteration,
                previous,
            )
        ),
        success_evaluator=FakeEvaluator(),
    )

    result = controller.resume(mission.id)

    # since a durable PlanCoordinatorAdvanced event exists, resume should not re-call advance
    assert coordinator.calls == []
    assert result.state.plan_revision_id == plan.id
