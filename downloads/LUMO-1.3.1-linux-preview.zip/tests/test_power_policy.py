from datetime import datetime, time

import pytest

from ocean.power import PowerPolicyEngine, PowerPreferences


def test_battery_policy_blocks_low_battery():
    engine = PowerPolicyEngine(PowerPreferences(min_battery_percent=30))
    decision = engine.decide(battery_percent=12)
    assert not decision.allowed
    assert "battery_below_minimum" in decision.reasons


def test_thermal_policy_blocks_hot_device():
    engine = PowerPolicyEngine(PowerPreferences(max_temperature_c=80))
    decision = engine.decide(temperature_c=91)
    assert not decision.allowed
    assert "temperature_above_limit" in decision.reasons


def test_quiet_hours_support_cross_midnight():
    engine = PowerPolicyEngine(PowerPreferences(quiet_hours_start=time(22), quiet_hours_end=time(7)))
    assert not engine.decide(now=datetime(2026, 1, 1, 23, 0)).allowed
    assert not engine.decide(now=datetime(2026, 1, 1, 6, 0)).allowed
    assert engine.decide(now=datetime(2026, 1, 1, 12, 0)).allowed


def test_preferences_can_disable_battery_and_low_power_work():
    engine = PowerPolicyEngine(PowerPreferences(allow_on_battery=False, allow_low_power_mode=False))
    decision = engine.decide(on_battery=True, low_power_mode=True)
    assert decision.allowed is False
    assert set(decision.reasons) == {"battery_operation_disabled", "low_power_mode_disabled"}


def test_invalid_preferences_fail_closed():
    with pytest.raises(ValueError):
        PowerPreferences(min_battery_percent=101)
    with pytest.raises(ValueError):
        PowerPreferences(max_temperature_c=151)
