from datetime import datetime, timezone

from ocean.domain.enums import ExecutionStatus
from ocean.domain.execution import Execution
from persistence.serializers.execution import ExecutionSerializer


def test_execution_serializer_round_trip():
    started_at = datetime(2026, 1, 1, 10, 0, tzinfo=timezone.utc)
    ended_at = datetime(2026, 1, 1, 10, 1, tzinfo=timezone.utc)

    execution = Execution(
        task_id="task-1",
        capability="filesystem",
        operation="read_file",
        arguments={
            "path": "/tmp/example.txt",
            "encoding": "utf-8",
        },
        id="exec-1",
        status=ExecutionStatus.SUCCEEDED,
        started_at=started_at,
        ended_at=ended_at,
        raw_result={"content": "hello"},
        error=None,
    )

    serializer = ExecutionSerializer()

    serialized = serializer.serialize(execution)
    restored = serializer.deserialize(serialized)

    assert restored == execution


def test_execution_serializer_preserves_pending_optional_values():
    execution = Execution(
        task_id="task-2",
        capability="computer",
        operation="click",
        id="exec-2",
        status=ExecutionStatus.PENDING,
    )

    serializer = ExecutionSerializer()

    restored = serializer.deserialize(serializer.serialize(execution))

    assert restored.status == ExecutionStatus.PENDING
    assert restored.started_at is None
    assert restored.ended_at is None
    assert restored.raw_result is None
    assert restored.error is None


def test_execution_serializer_preserves_failure():
    execution = Execution(
        task_id="task-3",
        capability="browser",
        operation="open",
        id="exec-3",
        status=ExecutionStatus.FAILED,
        error="example failure",
    )

    serializer = ExecutionSerializer()

    data = serializer.serialize(execution)

    assert data["status"] == ExecutionStatus.FAILED.value
    assert data["error"] == "example failure"

    restored = serializer.deserialize(data)

    assert restored.status == ExecutionStatus.FAILED
    assert restored.error == "example failure"
