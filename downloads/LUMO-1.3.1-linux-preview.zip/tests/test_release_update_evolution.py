from pathlib import Path
import zipfile

import pytest

from ocean.release import ReleaseManifest, ReleaseSigner, ReleaseVerifier, artifact_digest
from ocean.update_service import UpdateClient
from ocean.fleet_rollout import EvolutionReleaseGate, FleetHealth, FleetRollout
from ocean.evolution_service import ContinuousEvolutionService, EvolutionObservation


def make_artifact(path: Path, payload: bytes = b"lumo") -> ReleaseManifest:
    path.write_bytes(payload)
    digest, size = artifact_digest(path)
    return ReleaseManifest("1.0.1", "stable", digest, size, min_version="1.0.0")


def test_release_signature_and_tamper_detection(tmp_path):
    signer = ReleaseSigner()
    manifest = make_artifact(tmp_path / "artifact.zip")
    signature = signer.sign(manifest)
    verifier = ReleaseVerifier(signer.public_key_bytes)
    assert verifier.verify(manifest, signature)
    tampered = ReleaseManifest("1.0.2", manifest.channel, manifest.artifact_sha256, manifest.artifact_size)
    assert not verifier.verify(tampered, signature)
def test_update_is_atomic_and_rollback_is_available(tmp_path):
    signer = ReleaseSigner()
    install = tmp_path / "install"
    artifact = tmp_path / "release.zip"
    with zipfile.ZipFile(artifact, "w") as z:
        z.writestr("VERSION", "1.0.1")
    digest, size = artifact_digest(artifact)
    manifest = ReleaseManifest("1.0.1", "stable", digest, size)
    client = UpdateClient(install, signer.public_key_bytes)
    result = client.apply(manifest, signer.sign(manifest), artifact, lambda p: (p / "VERSION").is_file())
    assert result.status == "updated"
    assert client.current.resolve().name == "1.0.1"

    artifact2 = tmp_path / "release2.zip"
    with zipfile.ZipFile(artifact2, "w") as z:
        z.writestr("VERSION", "1.0.2")
    digest2, size2 = artifact_digest(artifact2)
    manifest2 = ReleaseManifest("1.0.2", "stable", digest2, size2)
    client.apply(manifest2, signer.sign(manifest2), artifact2, lambda p: True)
    rolled = client.rollback(lambda p: True)
    assert rolled.version == "1.0.1"
    assert client.current.resolve().name == "1.0.1"


def test_unsafe_archive_is_rejected(tmp_path):
    signer = ReleaseSigner()
    artifact = tmp_path / "bad.zip"
    with zipfile.ZipFile(artifact, "w") as z:
        z.writestr("../escape", "bad")
    digest, size = artifact_digest(artifact)
    manifest = ReleaseManifest("1.0.1", "stable", digest, size)
    client = UpdateClient(tmp_path / "install", signer.public_key_bytes)
    with pytest.raises(RuntimeError, match="unsafe path"):
        client.apply(manifest, signer.sign(manifest), artifact, lambda p: True)
def test_rollout_freezes_on_bad_health(tmp_path):
    rollout = FleetRollout(tmp_path / "rollout.json")
    bad = FleetHealth(100, crash_rate=0.05, verification_failure_rate=0.0, rollback_rate=0.0)
    assert rollout.stage("1.0.1", "stable", bad) == 0
    assert rollout._read()["status"] == "frozen"


def test_rollout_advances_deterministically(tmp_path):
    rollout = FleetRollout(tmp_path / "rollout.json")
    good = FleetHealth(100, 0.0, 0.0, 0.0)
    assert rollout.stage("1.0.1", "canary", good) == 1
    assert rollout.stage("1.0.1", "canary", good) == 10
    assert rollout.assigned("installation-a", "1.0.1", 10) in {True, False}


def test_release_gate_never_allows_missing_hard_gate():
    decision = EvolutionReleaseGate.decide("1.0.1", {"authorization": True})
    assert decision.action == "reject"
    assert "isolation" in decision.reason
def test_continuous_evolution_selects_and_records_cycle(tmp_path):
    rollout = FleetRollout(tmp_path / "rollout.json")
    service = ContinuousEvolutionService(tmp_path / "evolution.json", rollout)

    observations = [
        EvolutionObservation("browser_recovery", 20, 0.8),
        EvolutionObservation("slow_logging", 50, 0.2),
    ]

    def improve(objective):
        assert "browser_recovery" in objective
        return {
            "authorization": True, "isolation": True, "verification": True,
            "auditability": True, "kill_switch": True, "secret_protection": True,
            "trust_boundary": True, "fleet_sample_size": 100,
            "fleet_crash_rate": 0.0, "fleet_verification_failure_rate": 0.0,
            "fleet_rollback_rate": 0.0,
        }

    cycle = service.run_cycle(observations, "1.0.1", improve)
    assert cycle.outcome == "canary"
    assert cycle.reason == "rollout=1%"
