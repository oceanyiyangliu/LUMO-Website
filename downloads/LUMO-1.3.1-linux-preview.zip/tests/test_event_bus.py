import pytest

from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus


def test_subscriber_receives_matching_event():
    bus = EventBus()
    received = []
    bus.subscribe("task_completed", received.append)
    evt = Event(type="task_completed", payload={"task_id": "task_1"})
    bus.publish(evt)
    assert received == [evt]


def test_subscriber_does_not_receive_other_event_types():
    bus = EventBus()
    received = []
    bus.subscribe("task_completed", received.append)
    bus.publish(Event(type="task_failed"))
    assert received == []


def test_wildcard_subscriber_receives_everything():
    bus = EventBus()
    received = []
    bus.subscribe("*", received.append)
    bus.publish(Event(type="task_completed"))
    bus.publish(Event(type="task_failed"))
    assert len(received) == 2


def test_history_is_retained_and_filterable():
    bus = EventBus()
    bus.publish(Event(type="a"))
    bus.publish(Event(type="b"))
    bus.publish(Event(type="a"))
    assert len(bus.history()) == 3
    assert len(bus.history("a")) == 2


def test_one_broken_handler_does_not_block_others():
    bus = EventBus()
    received = []

    def broken(_evt):
        raise RuntimeError("boom")

    bus.subscribe("x", broken)
    bus.subscribe("x", received.append)
    failures = bus.publish(Event(type="x"))
    assert received  # second handler still ran
    assert len(failures) == 1
    assert isinstance(failures[0].error, RuntimeError)


def test_unsubscribe_stops_delivery():
    bus = EventBus()
    received = []
    bus.subscribe("x", received.append)
    bus.unsubscribe("x", received.append)
    bus.publish(Event(type="x"))
    assert received == []
def test_event_bus_can_use_custom_event_store():
    from eventing.in_memory_store import InMemoryEventStore

    store = InMemoryEventStore()
    bus = EventBus(store=store)

    evt = Event(type="custom", payload={"value": 42})

    bus.publish(evt)

    assert store.get(evt.id) == evt
    assert bus.history() == [evt]
def test_event_bus_can_use_sqlite_event_store():
    import sqlite3

    from eventing.sqlite_store import SQLiteEventStore

    connection = sqlite3.connect(":memory:")
    store = SQLiteEventStore(connection)
    bus = EventBus(store=store)

    evt = Event(type="sqlite_test", payload={"value": 123})

    bus.publish(evt)

    assert store.get(evt.id) == evt
    assert bus.history() == [evt]
def test_event_bus_sqlite_store_persists_across_bus_instances():
    import sqlite3

    from eventing.sqlite_store import SQLiteEventStore

    connection = sqlite3.connect(":memory:")

    store1 = SQLiteEventStore(connection)
    bus1 = EventBus(store=store1)

    evt = Event(type="persistent_test", payload={"value": 999})
    bus1.publish(evt)

    store2 = SQLiteEventStore(connection)
    bus2 = EventBus(store=store2)

    assert bus2.history() == [evt]
    assert store2.get(evt.id) == evt
def test_event_bus_sqlite_history_filters_by_event_type():
    import sqlite3

    from eventing.sqlite_store import SQLiteEventStore

    connection = sqlite3.connect(":memory:")
    store = SQLiteEventStore(connection)
    bus = EventBus(store=store)

    first = Event(type="task_created", payload={"id": 1})
    second = Event(type="task_completed", payload={"id": 2})
    third = Event(type="task_created", payload={"id": 3})

    bus.publish(first)
    bus.publish(second)
    bus.publish(third)

    assert bus.history("task_created") == [first, third]
    assert bus.history("task_completed") == [second]
def test_event_bus_sqlite_history_preserves_insertion_order():
    import sqlite3

    from eventing.sqlite_store import SQLiteEventStore

    connection = sqlite3.connect(":memory:")
    store = SQLiteEventStore(connection)
    bus = EventBus(store=store)

    events = [
        Event(type="ordered", payload={"n": 1}),
        Event(type="ordered", payload={"n": 2}),
        Event(type="ordered", payload={"n": 3}),
    ]

    for event in events:
        bus.publish(event)

    assert bus.history() == events
def test_event_bus_sqlite_store_keeps_event_ids_immutable():
    import sqlite3

    from eventing.sqlite_store import SQLiteEventStore

    connection = sqlite3.connect(":memory:")
    store = SQLiteEventStore(connection)
    bus = EventBus(store=store)

    event_id = "evt_test_immutable"
    first = Event(type="task_updated", payload={"value": 1}, id=event_id)
    conflicting = Event(type="task_updated", payload={"value": 2}, id=event_id, at=first.at)

    bus.publish(first)
    bus.publish(first)

    assert store.get(event_id) == first
    assert bus.history() == [first]

    with pytest.raises(ValueError, match="already exists with different content"):
        bus.publish(conflicting)
    assert store.get(event_id) == first



def test_event_bus_isolates_subscriber_payload_mutation():
    bus = EventBus()
    observed = []

    def mutating_handler(event):
        event.payload["nested"]["value"] = 99

    bus.subscribe("immutable_view", mutating_handler)
    bus.subscribe("immutable_view", observed.append)
    event = Event(type="immutable_view", payload={"nested": {"value": 1}})
    bus.publish(event)

    assert event.payload["nested"]["value"] == 1
    assert observed[0].payload["nested"]["value"] == 1
    assert bus.history()[0].payload["nested"]["value"] == 1
