from ocean.advanced_capabilities import *
def test_state_diff_and_graph():
    d=state_diff({"a":1,"b":2},{"a":2,"c":3}); assert d.changed["a"]==(1,2) and d.removed["b"]==2 and d.added["c"]==3
    g=SemanticStateGraph(); s=SemanticState("x",{"open":True}); g.observe(s); assert g.get("x").fingerprint==s.fingerprint
def test_skills_versions_evaluation_and_contextual_selection():
    r=SkillRegistry(); r.register(Skill("s","demo","1",(),metadata={"keywords":"computer navigation"})); r.register(Skill("s","demo","2",(),metadata={"keywords":"computer navigation"}))
    assert r.get("s").version=="2"
    assert r.evaluate("s","2",lambda _:0.9)==0.9
    assert r.select(goal="navigate the computer",risk="low").version=="2"
def test_undo_and_counterfactual():
    u=UndoManager(); u.register("a",{"op":"restore"}); assert u.inverse("a")["op"]=="restore"; assert counterfactual(1,2).changed
def test_testing_primitives():
    assert metamorphic_check(lambda x:x*2,2,lambda x:x+1,lambda a,b:b-a==2)
    assert property_check(lambda x:x+1,[1,2],lambda x,y:y>x)["passed"]
    assert ChaosHarness().run(["crash","network"])["count"]==2
def test_execution_and_context_primitives():
    t=ExecutionTree(); t.add(ExecutionTreeNode("root",None,"running")); t.add(ExecutionTreeNode("child","root","done")); assert len(t.children("root"))==1
    assert ContextBudget(1).minimize([1,2])==(1,); assert len(ObservationCompressor().compress([{"a":1},{"a":1}]))==1

def test_recovery_learning_retry_and_progress():
    s=RecoveryLearningStore(); s.record("timeout","reassign",True); s.record("timeout","reassign",False); assert s.effectiveness("timeout","reassign")==0.5
    assert verify_retry_allowed(verification_passed=False,evidence_count=0,attempt=0,max_attempts=1)
    assert not verify_retry_allowed(verification_passed=True,evidence_count=1,attempt=0,max_attempts=1)
    p=progress_semantics(2,3); assert p.fraction==2/3 and not p.terminal
