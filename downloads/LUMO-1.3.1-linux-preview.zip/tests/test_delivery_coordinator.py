"""Comprehensive tests for the durable DeliveryCoordinator.

These tests verify:
- cursor table creation and persistence
- new subscriber starts at sequence 0
- startup catch-up
- ongoing polling
- successful handler advances cursor
- failed handler does NOT advance cursor
- failed event is retried
- later events do not overtake failed event
- crash/restart redelivery
- cursor never regresses
- multiple independent subscribers
- non-matching events handled correctly
- committed events visible to DC
- uncommitted UnitOfWork events NOT visible
- cursor write contention
- cursor write failure causes retry
- clean shutdown
- restart/resumption
- durable subscriber independent of EventBus
"""

from __future__ import annotations

import os
import sqlite3
import tempfile
import threading
import time
from dataclasses import dataclass, field
from typing import List, Optional

import pytest

from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from eventing.delivery_coordinator import DeliveryCoordinator, Subscriber
from eventing.sqlite_store import SQLiteEventStore
from persistence.sqlite import SQLiteRepository
from persistence.serializer import Serializer
from persistence.unit_of_work import UnitOfWork


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def db_path():
    fd, path = tempfile.mkstemp(suffix=".sqlite3")
    os.close(fd)
    yield path
    os.unlink(path)


@pytest.fixture
def uow_connection(db_path):
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 30000")
    conn.execute("PRAGMA synchronous = NORMAL")
    return conn


@pytest.fixture
def event_store(uow_connection):
    return SQLiteEventStore(uow_connection)


@pytest.fixture
def coordinator(db_path):
    return DeliveryCoordinator(db_path)


# ---------------------------------------------------------------------------
# 1. Cursor table creation and persistence
# ---------------------------------------------------------------------------


def test_cursor_table_created_on_init(db_path):
    DeliveryCoordinator(db_path)
    conn = sqlite3.connect(db_path)
    tables = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
    ).fetchall()
    table_names = {row[0] for row in tables}
    assert "subscriber_cursors" in table_names
    conn.close()


def test_cursor_persisted_after_advance(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    dc.subscribe("sub1", received.append)
    event_store.append(Event(type="test", payload={"n": 1}))
    dc.poll_once()

    conn = sqlite3.connect(db_path)
    row = conn.execute(
        "SELECT last_sequence FROM subscriber_cursors WHERE subscriber_id = ?",
        ("sub1",),
    ).fetchone()
    conn.close()
    assert row is not None
    assert row[0] == 1


# ---------------------------------------------------------------------------
# 2. New subscriber starts at sequence 0
# ---------------------------------------------------------------------------


def test_new_subscriber_starts_at_zero(db_path):
    dc = DeliveryCoordinator(db_path)
    dc.subscribe("sub1", lambda e: None)
    assert dc.cursor("sub1") == 0


def test_cursor_zero_when_no_events(db_path):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    dc.subscribe("sub1", received.append)
    dc.poll_once()
    assert dc.cursor("sub1") == 0
    assert received == []


# ---------------------------------------------------------------------------
# 3. Startup catch-up
# ---------------------------------------------------------------------------


def test_startup_catchup_delivers_all_past_events(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    for i in range(5):
        event_store.append(Event(type="past", payload={"i": i}))
    dc.subscribe("sub1", received.append)
    dc.poll_once()
    assert len(received) == 5
    assert dc.cursor("sub1") == 5


def test_startup_catchup_from_middle(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    for i in range(10):
        event_store.append(Event(type="old", payload={"i": i}))

    conn = sqlite3.connect(db_path)
    conn.execute(
        "INSERT INTO subscriber_cursors (subscriber_id, last_sequence, updated_at) "
        "VALUES (?, ?, datetime('now'))",
        ("sub1", 5),
    )
    conn.commit()
    conn.close()

    dc.subscribe("sub1", received.append)
    dc.poll_once()
    assert len(received) == 5
    assert dc.cursor("sub1") == 10


# ---------------------------------------------------------------------------
# 4. Ongoing polling
# ---------------------------------------------------------------------------


def test_ongoing_polling_delivers_new_events(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    dc.subscribe("sub1", received.append)

    dc.poll_once()
    assert received == []

    event = Event(type="new", payload={"n": 1})
    event_store.append(event)

    dc.poll_once()
    assert len(received) == 1
    assert received[0].id == event.id
    assert dc.cursor("sub1") == 1


def test_polling_is_idempotent(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    dc.subscribe("sub1", received.append)
    event_store.append(Event(type="test", payload={}))
    dc.poll_once()
    dc.poll_once()
    assert len(received) == 1


# ---------------------------------------------------------------------------
# 5. Successful handler advances cursor
# ---------------------------------------------------------------------------


def test_successful_handler_advances_cursor(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    dc.subscribe("sub1", received.append)

    for i in range(3):
        event_store.append(Event(type="a", payload={"n": i + 1}))

    dc.poll_once()
    assert len(received) == 3
    assert dc.cursor("sub1") == 3


def test_cursor_advances_to_last_matching_event(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    dc.subscribe("sub1", received.append, event_types=frozenset({"target"}))

    for typ, n in [("target", 1), ("other", 2), ("target", 3), ("other", 4), ("target", 5)]:
        event_store.append(Event(type=typ, payload={"n": n}))

    dc.poll_once()
    assert len(received) == 3
    assert dc.cursor("sub1") == 5


# ---------------------------------------------------------------------------
# 6. Failed handler does NOT advance cursor
# ---------------------------------------------------------------------------


def test_failed_handler_does_not_advance_cursor_past_failure(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    call_count = 0

    def failing_handler(event: Event) -> None:
        nonlocal call_count
        call_count += 1
        if event.payload.get("n") == 2:
            raise RuntimeError("handler failure")

    dc.subscribe("sub1", failing_handler)

    for n in [1, 2, 3]:
        event_store.append(Event(type="test", payload={"n": n}))

    dc.poll_once()
    assert call_count == 2
    assert dc.cursor("sub1") == 1


def test_cursor_not_advanced_on_first_event_failure(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    dc.subscribe("sub1", lambda e: (_ for _ in ()).throw(RuntimeError("boom")))
    event_store.append(Event(type="test", payload={"n": 1}))
    dc.poll_once()
    assert dc.cursor("sub1") == 0


# ---------------------------------------------------------------------------
# 7. Failed event is retried
# ---------------------------------------------------------------------------


def test_failed_event_is_retried_on_next_poll(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    attempt = 0

    def flaky_handler(event: Event) -> None:
        nonlocal attempt
        attempt += 1
        if attempt == 1:
            raise RuntimeError("transient failure")
        received.append(event)

    dc.subscribe("sub1", flaky_handler)
    event_store.append(Event(type="test", payload={"n": 1}))

    dc.poll_once()
    assert len(received) == 0
    assert dc.cursor("sub1") == 0

    dc.poll_once()
    assert len(received) == 1
    assert dc.cursor("sub1") == 1


# ---------------------------------------------------------------------------
# 8. Later events do not overtake failed event
# ---------------------------------------------------------------------------


def test_later_events_do_not_overtake_failed_event(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    fail_once = True

    def handler(event: Event) -> None:
        nonlocal fail_once
        if fail_once and event.payload.get("n") == 1:
            fail_once = False
            raise RuntimeError("first event fails")
        received.append(event)

    dc.subscribe("sub1", handler)

    for n in [1, 2, 3]:
        event_store.append(Event(type="test", payload={"n": n}))

    dc.poll_once()
    assert len(received) == 0
    assert dc.cursor("sub1") == 0

    dc.poll_once()
    assert len(received) == 3
    assert dc.cursor("sub1") == 3


# ---------------------------------------------------------------------------
# 9. Crash/restart redelivery
# ---------------------------------------------------------------------------


def test_crash_between_handler_success_and_cursor_commit_redelivers(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    dc.subscribe("sub1", received.append)

    event = Event(type="test", payload={"n": 1})
    event_store.append(event)

    subscriber = dc._subscribers["sub1"]
    subscriber.handler(event)

    assert dc.cursor("sub1") == 0

    dc.poll_once()
    assert len(received) == 2
    assert dc.cursor("sub1") == 1


def test_restart_redelivers_from_last_persisted_cursor(db_path, event_store):
    dc1 = DeliveryCoordinator(db_path)
    received1: List[Event] = []
    dc1.subscribe("sub1", received1.append)

    event_store.append(Event(type="test", payload={"n": 1}))
    event_store.append(Event(type="test", payload={"n": 2}))

    dc1.poll_once()
    assert dc1.cursor("sub1") == 2

    dc2 = DeliveryCoordinator(db_path)
    received2: List[Event] = []
    dc2.subscribe("sub1", received2.append)

    dc2.poll_once()
    assert received2 == []
    assert dc2.cursor("sub1") == 2

    event_store.append(Event(type="test", payload={"n": 3}))
    dc2.poll_once()
    assert len(received2) == 1
    assert dc2.cursor("sub1") == 3


# ---------------------------------------------------------------------------
# 10. Cursor never regresses
# ---------------------------------------------------------------------------


def test_cursor_never_regresses(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    dc.subscribe("sub1", lambda e: None)

    for i in range(10):
        event_store.append(Event(type="test", payload={"i": i}))

    for _ in range(5):
        dc.poll_once()

    assert dc.cursor("sub1") == 10

    dc.poll_once()
    assert dc.cursor("sub1") == 10


def test_cursor_never_regresses_after_failure(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    fail_at = {3}

    def handler(event: Event) -> None:
        if event.payload.get("n") in fail_at:
            raise RuntimeError("fail")

    dc.subscribe("sub1", handler)

    for i in range(5):
        event_store.append(Event(type="test", payload={"n": i + 1}))

    dc.poll_once()
    assert dc.cursor("sub1") == 2

    dc.poll_once()
    assert dc.cursor("sub1") == 2


# ---------------------------------------------------------------------------
# 11. Multiple independent subscribers
# ---------------------------------------------------------------------------


def test_multiple_subscribers_independent_cursors(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received_a: List[Event] = []
    received_b: List[Event] = []

    dc.subscribe("sub_a", received_a.append)
    dc.subscribe("sub_b", received_b.append)

    event_store.append(Event(type="test", payload={"n": 1}))
    event_store.append(Event(type="test", payload={"n": 2}))

    dc.poll_once()

    assert len(received_a) == 2
    assert len(received_b) == 2
    assert dc.cursor("sub_a") == 2
    assert dc.cursor("sub_b") == 2


def test_subscribers_have_different_filters(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received_a: List[Event] = []
    received_b: List[Event] = []

    dc.subscribe("sub_a", received_a.append, event_types=frozenset({"type_a"}))
    dc.subscribe("sub_b", received_b.append, event_types=frozenset({"type_b"}))

    event_store.append(Event(type="type_a", payload={"n": 1}))
    event_store.append(Event(type="type_b", payload={"n": 2}))
    event_store.append(Event(type="type_a", payload={"n": 3}))

    dc.poll_once()

    assert len(received_a) == 2
    assert len(received_b) == 1
    assert dc.cursor("sub_a") == 3
    assert dc.cursor("sub_b") == 3


def test_one_subscriber_failure_does_not_affect_other(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received_ok: List[Event] = []

    dc.subscribe("failing", lambda e: (_ for _ in ()).throw(RuntimeError("always fails")))
    dc.subscribe("ok", received_ok.append)

    event_store.append(Event(type="test", payload={"n": 1}))

    dc.poll_once()

    assert len(received_ok) == 1
    assert dc.cursor("failing") == 0
    assert dc.cursor("ok") == 1


# ---------------------------------------------------------------------------
# 12. Non-matching events
# ---------------------------------------------------------------------------


def test_non_matching_events_skipped(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    dc.subscribe("sub1", received.append, event_types=frozenset({"target"}))

    event_store.append(Event(type="other", payload={"n": 1}))
    event_store.append(Event(type="target", payload={"n": 2}))
    event_store.append(Event(type="other", payload={"n": 3}))

    dc.poll_once()

    assert len(received) == 1
    assert received[0].payload == {"n": 2}
    # The trailing non-matching event is consumed too, so filtered subscribers
    # do not rescan it on every poll.
    assert dc.cursor("sub1") == 3


def test_wildcard_receives_all_events(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    dc.subscribe("sub1", received.append, event_types=None)

    for i in range(5):
        event_store.append(Event(type=f"type_{i}", payload={"i": i}))

    dc.poll_once()

    assert len(received) == 5
    assert dc.cursor("sub1") == 5


# ---------------------------------------------------------------------------
# 13. Committed events visible to DC
# ---------------------------------------------------------------------------


def test_committed_events_visible_to_dc(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    dc.subscribe("sub1", received.append)

    event_store.append(Event(type="test", payload={"n": 1}))

    dc.poll_once()
    assert len(received) == 1


# ---------------------------------------------------------------------------
# 14. Uncommitted UnitOfWork events NOT visible
# ---------------------------------------------------------------------------


def test_uncommitted_events_not_visible_to_dc(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    dc.subscribe("sub1", received.append)

    uow = UnitOfWork([event_store])
    with uow.transaction():
        event_store.append(Event(type="uncommitted", payload={"n": 1}))
        dc.poll_once()
        assert len(received) == 0
        assert dc.cursor("sub1") == 0


def test_rolled_back_events_not_delivered(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    dc.subscribe("sub1", received.append)

    uow = UnitOfWork([event_store])
    with pytest.raises(RuntimeError, match="rollback"):
        with uow.transaction():
            event_store.append(Event(type="doomed", payload={"n": 1}))
            raise RuntimeError("rollback")

    dc.poll_once()
    assert len(received) == 0
    assert dc.cursor("sub1") == 0


# ---------------------------------------------------------------------------
# 15. Cursor write contention
# ---------------------------------------------------------------------------


def test_cursor_write_contention_eventually_succeeds(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    dc.subscribe("sub1", received.append)

    event_store.append(Event(type="test", payload={"n": 1}))

    lock_released = threading.Event()

    def hold_lock():
        conn = sqlite3.connect(db_path, check_same_thread=False)
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA busy_timeout = 30000")
        conn.execute("BEGIN")
        conn.execute(
            "INSERT OR REPLACE INTO subscriber_cursors VALUES (?, ?, datetime('now'))",
            (" contention_lock ", 0),
        )
        lock_released.wait()
        conn.commit()
        conn.close()

    t = threading.Thread(target=hold_lock)
    t.start()
    time.sleep(0.1)

    done = threading.Event()

    def poll_in_background():
        dc.poll_once()
        done.set()

    t2 = threading.Thread(target=poll_in_background)
    t2.start()

    lock_released.set()
    t.join()

    done.wait(timeout=5)
    t2.join()

    assert len(received) == 1
    assert dc.cursor("sub1") == 1


# ---------------------------------------------------------------------------
# 16. Cursor write failure causes retry
# ---------------------------------------------------------------------------


def test_cursor_write_failure_causes_retry(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    dc.subscribe("sub1", received.append)

    event_store.append(Event(type="test", payload={"n": 1}))

    original_save = dc._save_cursor
    call_count = 0

    def failing_save(subscriber_id: str, sequence: int) -> bool:
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return False
        return original_save(subscriber_id, sequence)

    dc._save_cursor = failing_save

    dc.poll_once()
    assert len(received) == 1
    assert dc.cursor("sub1") == 0

    dc.poll_once()
    assert len(received) == 2
    assert dc.cursor("sub1") == 1


# ---------------------------------------------------------------------------
# 17. Clean shutdown
# ---------------------------------------------------------------------------


def test_clean_shutdown(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    dc.subscribe("sub1", lambda e: None)
    event_store.append(Event(type="test", payload={"n": 1}))

    done = threading.Event()

    def run_dc():
        dc.run()
        done.set()

    t = threading.Thread(target=run_dc)
    t.start()

    time.sleep(0.05)
    dc.shutdown()
    done.wait(timeout=5)
    t.join(timeout=5)

    assert dc.cursor("sub1") == 1


def test_shutdown_does_not_leave_partial_cursor(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    dc.subscribe("sub1", received.append)

    for i in range(5):
        event_store.append(Event(type="test", payload={"i": i}))

    dc.poll_once()

    assert len(received) == 5
    assert dc.cursor("sub1") == 5


# ---------------------------------------------------------------------------
# 18. Restart/resumption
# ---------------------------------------------------------------------------


def test_restart_resumes_from_persisted_cursor(db_path, event_store):
    dc1 = DeliveryCoordinator(db_path)
    received1: List[Event] = []
    dc1.subscribe("sub1", received1.append)

    for i in range(3):
        event_store.append(Event(type="test", payload={"i": i}))

    dc1.poll_once()
    assert dc1.cursor("sub1") == 3

    dc2 = DeliveryCoordinator(db_path)
    received2: List[Event] = []
    dc2.subscribe("sub1", received2.append)

    dc2.poll_once()
    assert received2 == []
    assert dc2.cursor("sub1") == 3

    for i in range(3):
        event_store.append(Event(type="test", payload={"i": i + 3}))

    dc2.poll_once()
    assert len(received2) == 3
    assert dc2.cursor("sub1") == 6


# ---------------------------------------------------------------------------
# 19. Durable subscriber independent of EventBus
# ---------------------------------------------------------------------------


def test_durable_subscriber_independent_of_event_bus(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    event_bus_received: List[Event] = []
    dc_received: List[Event] = []

    event_bus = EventBus(store=event_store)
    event_bus.subscribe("test", event_bus_received.append)

    dc.subscribe("sub1", dc_received.append, event_types=frozenset({"test"}))

    event = Event(type="test", payload={"n": 1})
    event_bus.publish(event)

    assert len(event_bus_received) == 1
    assert len(dc_received) == 0

    dc.poll_once()
    assert len(dc_received) == 1


def test_same_event_not_delivered_by_both_paths(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    dc_received: List[Event] = []
    dc.subscribe("sub1", dc_received.append)

    event = Event(type="test", payload={"n": 1})
    event_bus = EventBus(store=event_store)
    event_bus.publish(event)

    dc.poll_once()
    assert len(dc_received) == 1


# ---------------------------------------------------------------------------
# 20. Concurrency: multiple subscribers, sequential processing
# ---------------------------------------------------------------------------


def test_subscribers_processed_sequentially(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    order: List[str] = []

    dc.subscribe("sub_a", lambda e: order.append("a"))
    dc.subscribe("sub_b", lambda e: order.append("b"))

    event_store.append(Event(type="test", payload={"n": 1}))

    dc.poll_once()

    assert "a" in order
    assert "b" in order
    assert order.index("a") < order.index("b")


# ---------------------------------------------------------------------------
# 21. Subscriber unsubscribe
# ---------------------------------------------------------------------------


def test_unsubscribe_removes_subscriber(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    dc.subscribe("sub1", received.append)
    dc.unsubscribe("sub1")

    event_store.append(Event(type="test", payload={"n": 1}))
    dc.poll_once()

    assert received == []


def test_unsubscribe_removes_cursor(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    dc.subscribe("sub1", lambda e: None)
    event_store.append(Event(type="test", payload={"n": 1}))
    dc.poll_once()
    assert dc.cursor("sub1") == 1

    dc.unsubscribe("sub1")

    conn = sqlite3.connect(db_path)
    row = conn.execute(
        "SELECT last_sequence FROM subscriber_cursors WHERE subscriber_id = ?",
        ("sub1",),
    ).fetchone()
    conn.close()
    assert row is None


# ---------------------------------------------------------------------------
# 22. Duplicate subscriber_id rejected
# ---------------------------------------------------------------------------


def test_duplicate_subscriber_id_rejected(db_path):
    dc = DeliveryCoordinator(db_path)
    dc.subscribe("sub1", lambda e: None)

    with pytest.raises(RuntimeError, match="already active"):
        dc.subscribe("sub1", lambda e: None)


# ---------------------------------------------------------------------------
# 23. Handler exception does not crash coordinator
# ---------------------------------------------------------------------------


def test_handler_exception_does_not_crash_coordinator(db_path, event_store):
    dc = DeliveryCoordinator(db_path)

    def broken(event: Event) -> None:
        raise ValueError("handler broke")

    dc.subscribe("sub1", broken)
    event_store.append(Event(type="test", payload={"n": 1}))

    dc.poll_once()
    assert dc.cursor("sub1") == 0


# ---------------------------------------------------------------------------
# 24. Sequence ordering preserved
# ---------------------------------------------------------------------------


def test_events_delivered_in_sequence_order(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[int] = []

    def handler(event: Event) -> None:
        received.append(event.payload["n"])

    dc.subscribe("sub1", handler)

    for i in [5, 3, 1, 4, 2]:
        event_store.append(Event(type="test", payload={"n": i}))

    dc.poll_once()
    assert received == [5, 3, 1, 4, 2]


# ---------------------------------------------------------------------------
# 25. Large batch delivery
# ---------------------------------------------------------------------------


def test_large_batch_delivery(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []
    dc.subscribe("sub1", received.append)

    n = 100
    for i in range(n):
        event_store.append(Event(type="test", payload={"i": i}))

    dc.poll_once()

    assert len(received) == n
    assert dc.cursor("sub1") == n


# ---------------------------------------------------------------------------
# 26. Backoff prevents hot-spin
# ---------------------------------------------------------------------------


def test_backoff_prevents_hot_spin(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    dc._poll_interval = 0.01

    def always_fails(event: Event) -> None:
        raise RuntimeError("fail")

    dc.subscribe("sub1", always_fails)
    event_store.append(Event(type="test", payload={"n": 1}))

    dc.poll_once()
    dc.poll_once()
    dc.poll_once()

    assert dc._consecutive_failures["sub1"] == 3
    assert dc._backoff_seconds("sub1") > 1.0


# ---------------------------------------------------------------------------
# 27. Fresh handler failure resets backoff
# ---------------------------------------------------------------------------


def test_success_resets_backoff(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    fail_count = 0

    def flaky_handler(event: Event) -> None:
        nonlocal fail_count
        fail_count += 1
        if fail_count == 1:
            raise RuntimeError("first fail")

    dc.subscribe("sub1", flaky_handler)

    event_store.append(Event(type="test", payload={"n": 1}))
    event_store.append(Event(type="test", payload={"n": 2}))

    dc.poll_once()
    assert dc._consecutive_failures["sub1"] == 1

    dc.poll_once()
    assert dc._consecutive_failures["sub1"] == 0


# ---------------------------------------------------------------------------
# 28. Subscriber can be re-registered after unsubscribe
# ---------------------------------------------------------------------------


def test_reregister_after_unsubscribe(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received: List[Event] = []

    dc.subscribe("sub1", received.append)
    dc.unsubscribe("sub1")

    dc.subscribe("sub1", received.append)

    event_store.append(Event(type="test", payload={"n": 1}))
    dc.poll_once()

    assert len(received) == 1
    assert dc.cursor("sub1") == 1


def test_only_non_matching_events_advance_cursor(db_path, event_store):
    dc = DeliveryCoordinator(db_path)
    received = []
    dc.subscribe("sub1", received.append, event_types=frozenset({"target"}))
    for i in range(100):
        event_store.append(Event(type="other", payload={"n": i}))

    dc.poll_once()
    assert received == []
    assert dc.cursor("sub1") == 100

    # A second poll has nothing left to scan.
    dc.poll_once()
    assert received == []
    assert dc.cursor("sub1") == 100
