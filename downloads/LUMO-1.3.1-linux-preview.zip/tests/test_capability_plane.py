from __future__ import annotations

import os
import time

import pytest

from ocean.capabilities.git import GitExecutor, git_spec
from ocean.capabilities.http import HttpExecutor, http_spec
from ocean.capabilities.python import PythonExecutor, python_spec
from ocean.core.errors import InvalidCapabilityInput, PolicyViolation, UnknownCapability
from ocean.domain.capability import (
    CapabilityExecutionPolicy,
    CapabilityIsolationPolicy,
    CapabilityRegistry,
    CapabilitySpec,
    OperationSpec,
)
from ocean.domain.enums import ApprovalDecision, RiskLevel
from ocean.governance.capability_discovery import CapabilityDiscovery
from ocean.domain.policy import PolicyEngine
from runtime import ExecutionRequest, ExecutionResult, ExecutionRuntime, ExecutorRegistry
from runtime.control import CancellationToken
from runtime.isolation import InProcessIsolationBackend, ProcessIsolationBackend


class RecordingExecutor:
    calls = 0

    def execute(self, request, context):
        self.calls += 1
        return ExecutionResult.succeeded({"value": request.arguments["value"]})


def make_runtime(registry, executor, *, isolation=None):
    executors = ExecutorRegistry()
    executors.register("test_strategy", executor)
    return ExecutionRuntime(
        capabilities=registry,
        policy=PolicyEngine(),
        executors=executors,
        isolation=isolation,
    )


def test_discovery_inspects_policy_permissions_resources_and_operation_schema():
    registry = CapabilityRegistry()
    registry.register(http_spec())
    discovery = CapabilityDiscovery(registry)

    capability = discovery.capability("http")
    operation = discovery.operation("http", "request")

    assert capability["requires_permissions"] == ["http.request"]
    assert capability["execution_policy"]["isolation"] == "process_isolated_required"
    assert operation["input_schema"]["url"] == "string (required)"
    assert operation["resource_requirements"] == [{"kind": "network", "amount": 1.0}]


def test_dynamic_capability_executes_through_canonical_runtime_and_can_be_removed():
    registry = CapabilityRegistry()
    registry.register(
        CapabilitySpec(
            name="dynamic",
            description="test capability",
            execution_strategy="test_strategy",
            requires_permissions={"dynamic.run"},
            operations={
                "run": OperationSpec(
                    name="run",
                    description="run",
                    input_schema={"value": "integer (required)"},
                    output_schema={"value": "integer"},
                    risk_level=RiskLevel.SAFE,
                )
            },
        )
    )
    executor = RecordingExecutor()
    result = make_runtime(registry, executor).execute(
        ExecutionRequest(task_id="task", capability="dynamic", operation="run", arguments={"value": 7})
    )

    assert result.success is True
    assert result.result == {"value": 7}
    assert result.metadata["capability"] == "dynamic"
    assert result.metadata["operation"] == "run"
    assert result.metadata["execution_id"] is not None
    assert executor.calls == 1

    registry.disable("dynamic")
    with pytest.raises(UnknownCapability):
        make_runtime(registry, executor).execute(
            ExecutionRequest(task_id="task", capability="dynamic", operation="run", arguments={"value": 7})
        )


def test_invalid_input_is_rejected_before_executor():
    registry = CapabilityRegistry()
    registry.register(
        CapabilitySpec(
            name="validated",
            description="validated",
            execution_strategy="test_strategy",
            operations={
                "run": OperationSpec(
                    name="run",
                    description="run",
                    input_schema={"value": "integer (required)"},
                    output_schema={"value": "integer"},
                )
            },
        )
    )
    executor = RecordingExecutor()
    with pytest.raises(InvalidCapabilityInput):
        make_runtime(registry, executor).execute(
            ExecutionRequest(task_id="task", capability="validated", operation="run", arguments={"value": "bad"})
        )
    assert executor.calls == 0


def test_invalid_output_is_reported_without_misclassifying_executor_failure():
    registry = CapabilityRegistry()
    registry.register(
        CapabilitySpec(
            name="bad-output",
            description="bad output",
            execution_strategy="test_strategy",
            operations={
                "run": OperationSpec(
                    name="run",
                    description="run",
                    output_schema={"value": "integer"},
                )
            },
        )
    )

    class BadOutputExecutor:
        def execute(self, request, context):
            return ExecutionResult.succeeded({"value": "wrong"})

    result = make_runtime(registry, BadOutputExecutor()).execute(
        ExecutionRequest(task_id="task", capability="bad-output", operation="run")
    )
    assert result.success is False
    assert result.metadata["failure_type"] == "invalid_capability_output"
    assert result.metadata["capability"] == "bad-output"


def test_required_process_isolation_rejects_in_process_backend():
    registry = CapabilityRegistry()
    registry.register(python_spec())
    executors = ExecutorRegistry()
    executors.register("python_isolated", PythonExecutor())
    runtime = ExecutionRuntime(
        capabilities=registry,
        policy=PolicyEngine(),
        executors=executors,
        isolation=InProcessIsolationBackend(),
    )

    with pytest.raises(PolicyViolation):
        runtime.execute(
            ExecutionRequest(
                task_id="task",
                capability="python",
                operation="execute",
                arguments={"code": "result = 1"},
            )
        )


def test_python_capability_runs_in_process_isolation_with_provenance():
    registry = CapabilityRegistry()
    registry.register(python_spec())
    executors = ExecutorRegistry()
    executors.register("python_isolated", PythonExecutor())
    policy = PolicyEngine()
    policy.register_override(
        "python",
        "execute",
        lambda _context: ApprovalDecision.AUTOMATIC_LOGGED,
    )
    runtime = ExecutionRuntime(
        capabilities=registry,
        policy=policy,
        executors=executors,
        isolation=ProcessIsolationBackend(),
    )

    result = runtime.execute(
        ExecutionRequest(
            task_id="task",
            capability="python",
            operation="execute",
            mission_id="mission",
            agent_id="agent",
            execution_id="python-execution",
            arguments={"code": "result = inputs['value'] + 1", "inputs": {"value": 4}},
        )
    )

    assert result.success is True
    assert result.result == {"result": 5}
    assert result.metadata["capability"] == "python"
    assert result.metadata["operation"] == "execute"
    assert result.metadata["execution_id"] == "python-execution"
    assert result.metadata["mission_id"] == "mission"
    assert result.metadata["agent_id"] == "agent"


def test_git_reference_capability_is_read_only_and_registerable():
    registry = CapabilityRegistry()
    registry.register(git_spec())
    assert {operation.name for operation in registry.get("git").operations.values()} == {
        "status", "diff", "branch", "inspect"
    }
    assert not any("reset" in operation for operation in registry.get("git").operations)


def test_git_status_runs_through_canonical_runtime(tmp_path):
    registry = CapabilityRegistry()
    registry.register(git_spec())
    executors = ExecutorRegistry()
    executors.register("git_local", GitExecutor())
    runtime = ExecutionRuntime(
        capabilities=registry,
        policy=PolicyEngine(),
        executors=executors,
        isolation=InProcessIsolationBackend(),
    )

    result = runtime.execute(
        ExecutionRequest(
            task_id="task",
            capability="git",
            operation="status",
            arguments={"cwd": str(tmp_path)},
        )
    )

    assert result.success is False
    assert result.metadata["capability"] == "git"
    assert result.metadata["operation"] == "status"
    assert result.error is not None


def test_terminal_requires_process_isolation():
    from ocean.capabilities.terminal import terminal_spec
    from ocean.domain.capability import CapabilityIsolationPolicy

    spec = terminal_spec()
    assert spec.execution_policy.isolation is CapabilityIsolationPolicy.PROCESS_ISOLATED_REQUIRED


def test_terminal_cancellation_is_authoritative_even_when_not_marked_cancellable():
    import threading
    import time
    from ocean.capabilities.terminal import TerminalExecutor
    from runtime.control import ExecutionContext, CancellationToken
    from runtime.types import ExecutionRequest

    token = CancellationToken()
    context = ExecutionContext(execution_id="exec-terminal-cancel", cancellation=token)
    request = ExecutionRequest(
        task_id="task-terminal-cancel",
        capability="terminal",
        operation="run",
        arguments={"command": ["/bin/sleep", "10"], "cancellable": False},
    )

    timer = threading.Timer(0.15, token.cancel)
    timer.start()
    started = time.monotonic()
    try:
        result = TerminalExecutor().execute(request, context)
    finally:
        timer.cancel()

    assert time.monotonic() - started < 2.0
    assert result.success is False
    assert result.error == "cancelled"


def test_universal_action_cannot_bypass_execution_runtime():
    from ocean.execution.universal_adapter import UniversalAction, execute_universal_action

    action = UniversalAction(id="ua-1", capability="terminal", operation="run")
    with pytest.raises(TypeError, match="ExecutionRuntime"):
        execute_universal_action(action, object())


def test_terminal_cancellation_probe_failure_fails_closed():
    from ocean.capabilities.terminal import TerminalExecutor
    from runtime.types import ExecutionRequest

    class BrokenContext:
        def should_cancel(self):
            raise RuntimeError("control plane unavailable")

    request = ExecutionRequest(
        task_id="task-terminal-fail-closed",
        capability="terminal",
        operation="run",
        arguments={"command": ["/usr/bin/true"]},
    )
    result = TerminalExecutor().execute(request, BrokenContext())
    assert result.success is False
    assert result.error == "cancelled"


def test_terminal_kills_process_group_on_cancellation():
    import os
    import threading
    import time
    import psutil
    from ocean.capabilities.terminal import TerminalExecutor
    from runtime.control import CancellationToken, ExecutionContext
    from runtime.types import ExecutionRequest

    if not hasattr(os, "killpg"):
        return
    token = CancellationToken()
    context = ExecutionContext(execution_id="exec-terminal-tree", cancellation=token)
    marker = "/tmp/lumo-terminal-child-alive"
    command = ["/bin/sh", "-c", f"(sleep 30) & echo $$ > {marker}; wait"]
    timer = threading.Timer(0.2, token.cancel)
    timer.start()
    try:
        result = TerminalExecutor().execute(ExecutionRequest(
            task_id="task-terminal-tree", capability="terminal", operation="run",
            arguments={"command": command},
        ), context)
    finally:
        timer.cancel()
    assert result.error == "cancelled"
    time.sleep(0.1)
    if os.path.exists(marker):
        child_pid = int(open(marker).read().strip())
        assert not psutil.pid_exists(child_pid)
        os.unlink(marker)


def test_python_capability_rejects_host_escape_syntax():
    from ocean.capabilities.python import PythonExecutor
    request = ExecutionRequest(
        task_id="python-escape", capability="python", operation="execute",
        arguments={"code": "result = ().__class__.__base__.__subclasses__()"},
    )
    result = PythonExecutor().execute(request, None)
    assert result.success is False
    assert result.metadata["failure_type"] == "capability_failure"
    assert "unsupported Python syntax" in result.error


def test_python_capability_rejects_import_and_calls():
    from ocean.capabilities.python import PythonExecutor
    for code in ("import os\nresult = 1", "result = open('x', 'w')"):
        result = PythonExecutor().execute(ExecutionRequest(
            task_id="python-unsafe", capability="python", operation="execute",
            arguments={"code": code},
        ), None)
        assert result.success is False
