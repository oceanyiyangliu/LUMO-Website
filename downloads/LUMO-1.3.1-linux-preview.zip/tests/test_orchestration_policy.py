from ocean.domain.enums import OrchestrationMode
from ocean.orchestration.policy import (
    BackgroundOrchestrationPolicy,
    OrchestrationPolicyRegistry,
    ParallelOrchestrationPolicy,
    QueuedOrchestrationPolicy,
    StandardOrchestrationPolicy,
)
from ocean.orchestration.types import AssignmentRequest


def request(mode=OrchestrationMode.STANDARD):
    return AssignmentRequest(
        task_id="task-1",
        agent_id="agent-1",
        mode=mode,
    )


def test_standard_policy():
    policy = StandardOrchestrationPolicy()

    assert policy.mode == OrchestrationMode.STANDARD
    assert policy.admission(request()).allowed is True
    assert policy.routing(request()).agent_id == "agent-1"
    assert policy.concurrency().max_parallel_assignments == 1
    assert policy.recovery().retry_allowed is True


def test_parallel_policy_allows_concurrency():
    policy = ParallelOrchestrationPolicy()

    assert policy.mode == OrchestrationMode.PARALLEL
    assert policy.concurrency().max_parallel_assignments is None


def test_background_policy_allows_background_execution():
    policy = BackgroundOrchestrationPolicy()

    assert policy.mode == OrchestrationMode.BACKGROUND
    assert policy.concurrency().allow_background is True


def test_queued_policy_defers_execution():
    policy = QueuedOrchestrationPolicy()

    assert policy.mode == OrchestrationMode.QUEUED
    assert policy.concurrency().max_parallel_assignments == 0
    assert policy.concurrency().allow_queued is True


def test_policy_registry_resolves_modes():
    registry = OrchestrationPolicyRegistry()

    assert registry.supports(OrchestrationMode.STANDARD)
    assert registry.supports(OrchestrationMode.PARALLEL)
    assert registry.supports(OrchestrationMode.BACKGROUND)
    assert registry.supports(OrchestrationMode.QUEUED)

    assert registry.get(
        OrchestrationMode.PARALLEL
    ).mode == OrchestrationMode.PARALLEL

def test_all_autonomous_modes_have_policies():
    from ocean.domain.enums import OrchestrationMode
    from ocean.orchestration.policy import OrchestrationPolicyRegistry
    registry=OrchestrationPolicyRegistry()
    for mode in (OrchestrationMode.SWARM, OrchestrationMode.SHADOW, OrchestrationMode.ROUTINE, OrchestrationMode.GHOST, OrchestrationMode.SPECULATIVE):
        assert registry.supports(mode)
