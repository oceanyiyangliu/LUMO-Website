from __future__ import annotations

import threading
import time

from ocean.reflex import AdaptiveReflexController, ReflexDecision, ReflexLoop, ReflexPolicy


def test_reflex_loop_reacts_only_when_state_changes():
    states = iter([0, 0, 1, 1, 2, 2, 3])
    actions = []
    loop = ReflexLoop(
        observe=lambda: next(states),
        policy=ReflexPolicy(lambda state: ReflexDecision(f"act-{state}")),
        act=actions.append,
        target_hz=100,
        max_hz=240,
    )
    telemetry = loop.run(duration=0.055)
    assert actions == ["act-0", "act-1", "act-2"]
    assert telemetry.cycles >= 4
    assert telemetry.observations == telemetry.cycles
    assert telemetry.state == "stopped"


def test_reflex_loop_can_be_stopped_from_another_thread():
    observed = []
    holder = {}

    def observe():
        observed.append(time.perf_counter())
        return len(observed)

    loop = ReflexLoop(
        observe=observe,
        policy=ReflexPolicy(lambda state: ReflexDecision(None)),
        act=lambda _action: None,
        target_hz=120,
        max_hz=240,
    )
    thread = threading.Thread(target=lambda: holder.setdefault("result", loop.run()))
    thread.start()
    time.sleep(0.035)
    loop.stop()
    thread.join(timeout=1.0)
    assert not thread.is_alive()
    assert holder["result"].cycles > 0


def test_reflex_loop_does_not_accumulate_schedule_drift_when_over_budget():
    timestamps = []

    def observe():
        timestamps.append(time.perf_counter())
        time.sleep(0.004)
        return len(timestamps)

    loop = ReflexLoop(
        observe=observe,
        policy=ReflexPolicy(lambda state: ReflexDecision(None)),
        act=lambda _action: None,
        target_hz=100,
        max_hz=240,
    )
    telemetry = loop.run(duration=0.035)
    assert telemetry.cycles >= 3
    assert telemetry.average_cycle_ms >= 4


def test_adaptive_reflex_controller_backs_off_when_overloaded():
    controller = AdaptiveReflexController(target_hz=100, ceiling_hz=240)
    assert controller.tune(0.009) < 100


def test_adaptive_reflex_controller_scales_up_when_cheap():
    controller = AdaptiveReflexController(target_hz=60, ceiling_hz=240)
    assert controller.tune(0.001) > 60
