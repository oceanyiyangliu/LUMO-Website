from ocean.safety import *

def test_scoped_stop_and_receipt():
    s=StopAuthority(); r=s.engage("mission","m1","operator"); assert s.blocked(mission_id="m1"); assert not s.blocked(mission_id="m2"); assert r.acknowledgement_required; s.release("mission","m1"); assert not s.blocked(mission_id="m1")

def test_global_stop_and_breakers():
    s=StopAuthority(); s.engage(); assert s.blocked(mission_id="m2"); s.release(); assert not s.blocked(mission_id="m2")
    b=FailureCircuitBreaker(2,100); assert b.record_failure("x",0) is False; assert b.record_failure("x",1) is True; assert not b.allow("x"); b.reset("x"); assert b.allow("x")
    assert ResourceCircuitBreaker(10).allow(9); assert not ResourceCircuitBreaker(10).allow(11); assert RunawayDetector(3).check(3); assert not RunawayDetector(3).check(4)


def test_safety_circuit_breakers_and_simulator():
    from ocean.safety import ApprovalTimeoutCircuitBreaker, ModelLoopCircuitBreaker, NetworkAnomalyCircuitBreaker, SafetyInvariantDashboard, SafetyPolicySimulator, StopAuthority
    stop=StopAuthority(); simulator=SafetyPolicySimulator(stop)
    assert simulator.evaluate(operation="read")["allowed"]
    assert not simulator.evaluate(operation="delete",irreversible=True)["allowed"]
    net=NetworkAnomalyCircuitBreaker(2,100); assert net.record("net",0) is False; assert net.record("net",1) is True
    loop=ModelLoopCircuitBreaker(2,100); loop.record_loop("a","same",0); assert loop.record_loop("a","same",1)
    assert ApprovalTimeoutCircuitBreaker(5).expired(0,5)
    assert SafetyInvariantDashboard(stop).status()["healthy"]

def test_network_anomaly_breaker_has_named_operation():
    from ocean.safety import NetworkAnomalyCircuitBreaker
    b=NetworkAnomalyCircuitBreaker(threshold=2, window_seconds=60)
    assert not b.record_anomaly('api'); assert b.record_anomaly('api')
