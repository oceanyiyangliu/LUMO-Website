from datetime import datetime, timezone

from ocean.domain.artifact import Artifact
from persistence.serializers.artifact import ArtifactSerializer


def test_artifact_serializer_round_trip():
    created_at = datetime(2026, 2, 1, 9, 30, tzinfo=timezone.utc)

    artifact = Artifact(
        kind="document",
        name="research-report.pdf",
        uri="file:///workspace/research-report.pdf",
        produced_by_task_id="task-1",
        produced_by_agent_id="agent-1",
        metadata={
            "format": "pdf",
            "pages": 12,
        },
        id="artifact-1",
        created_at=created_at,
    )

    serializer = ArtifactSerializer()

    serialized = serializer.serialize(artifact)
    restored = serializer.deserialize(serialized)

    assert restored == artifact


def test_artifact_serializer_preserves_optional_fields():
    artifact = Artifact(
        kind="dataset",
        name="results.json",
        id="artifact-2",
    )

    serializer = ArtifactSerializer()

    restored = serializer.deserialize(serializer.serialize(artifact))

    assert restored.uri is None
    assert restored.produced_by_task_id is None
    assert restored.produced_by_agent_id is None


def test_artifact_serializer_preserves_metadata():
    artifact = Artifact(
        kind="image",
        name="screenshot.png",
        metadata={
            "width": 1440,
            "height": 900,
            "source": "computer",
        },
        id="artifact-3",
    )

    serializer = ArtifactSerializer()

    data = serializer.serialize(artifact)

    assert data["metadata"] == {
        "width": 1440,
        "height": 900,
        "source": "computer",
    }

    restored = serializer.deserialize(data)

    assert restored.metadata == artifact.metadata

