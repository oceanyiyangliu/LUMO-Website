from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.orchestration.mission_engine import (
    MissionEngine,
    MissionContract,
    MissionObjective,
    MissionObjectiveResult,
    MissionPlan,
)


class StaticPlanner:
    def __init__(self, plans):
        self.plans = iter(plans)

    def plan(
        self,
        mission_id,
        goal,
        *,
        completed_objectives=(),
        previous_results=(),
    ):
        return next(self.plans)


class RecordingExecutor:
    def __init__(self, statuses):
        self.statuses = iter(statuses)
        self.calls = []

    def execute(self, mission_id, objective):
        self.calls.append(objective.objective)
        status, error = next(self.statuses)
        return MissionObjectiveResult(
            objective_id=objective.objective_id,
            objective=objective.objective,
            status=status,
            error=error,
        )


def plan(objective_id, objective):
    return MissionPlan(
        mission_id="mission-test",
        goal="test mission",
        objectives=(
            MissionObjective(
                objective_id=objective_id,
                objective=objective,
            ),
        ),
    )


EMPTY_PLAN = MissionPlan(
    mission_id="mission-test",
    goal="test mission",
    objectives=(),
)


def test_exact_duplicate_replan_stagnates_before_second_execution():
    planner = StaticPlanner(
        [
            plan("o1", "Update the repository ignore rules"),
            plan("o2", "Update the repository ignore rules"),
        ]
    )
    executor = RecordingExecutor(
        [
            (
                "rejected",
                "candidate does not meet minimum improvement requirement",
            ),
        ]
    )

    result = MissionEngine(
        planner=planner,
        executor=executor,
    ).run("test mission", max_replans=8)

    assert result.status == "replan_stagnated"
    assert executor.calls == ["Update the repository ignore rules"]
    assert len(result.objective_results) == 1


def test_near_duplicate_replan_stagnates_before_second_execution():
    planner = StaticPlanner(
        [
            plan(
                "o1",
                'Add ".architecture_backup" to .gitignore',
            ),
            plan(
                "o2",
                'Add ".architecture_backup/" to the repository .gitignore',
            ),
        ]
    )
    executor = RecordingExecutor(
        [
            (
                "rejected",
                "candidate does not meet minimum improvement requirement",
            ),
        ]
    )

    result = MissionEngine(
        planner=planner,
        executor=executor,
    ).run("test mission", max_replans=8)

    assert result.status == "replan_stagnated"
    assert len(executor.calls) == 1


def test_novel_replan_is_allowed_to_execute():
    planner = StaticPlanner(
        [
            plan("o1", "Improve repository ignore rules"),
            plan(
                "o2",
                "Add mission-level objective quality gating to prevent "
                "low-value autonomous replanning",
            ),
            EMPTY_PLAN,
        ]
    )
    executor = RecordingExecutor(
        [
            (
                "rejected",
                "candidate does not meet minimum improvement requirement",
            ),
            ("completed", None),
        ]
    )

    result = MissionEngine(
        planner=planner,
        executor=executor,
    ).run("test mission", max_replans=8)

    assert result.status == "completed"
    assert len(executor.calls) == 2
    assert result.completed_objectives == ("o2",)


def test_independent_ready_objectives_execute_in_parallel():
    import threading
    import time

    started = []
    lock = threading.Lock()
    release = threading.Event()

    planner = StaticPlanner(
        [
            MissionPlan(
                mission_id="mission-test",
                goal="test mission",
                objectives=(
                    MissionObjective(objective_id="o1", objective="First"),
                    MissionObjective(objective_id="o2", objective="Second"),
                ),
            ),
            EMPTY_PLAN,
        ]
    )

    class ParallelExecutor:
        def execute(self, mission_id, objective):
            with lock:
                started.append(objective.objective_id)
            release.wait(timeout=2)
            return MissionObjectiveResult(
                objective_id=objective.objective_id,
                objective=objective.objective,
                status="completed",
            )

    executor = ParallelExecutor()
    result_holder = {}

    def run():
        result_holder["result"] = MissionEngine(
            planner=planner,
            executor=executor,
            max_concurrent_objectives=2,
        ).run("test mission")

    thread = threading.Thread(target=run)
    thread.start()

    deadline = time.monotonic() + 1.5
    while len(started) < 2 and time.monotonic() < deadline:
        time.sleep(0.01)

    release.set()
    thread.join(timeout=3)

    assert not thread.is_alive()
    assert sorted(started) == ["o1", "o2"]
    assert result_holder["result"].status == "completed"


def test_completed_duplicate_replan_stagnates_before_reexecution():
    planner = StaticPlanner(
        [
            plan("o1", "Audit SQLite concurrency hardening"),
            plan("o2", "Perform an audit of SQLite concurrency hardening"),
        ]
    )
    executor = RecordingExecutor([("completed", None)])

    result = MissionEngine(
        planner=planner,
        executor=executor,
    ).run("test mission", max_replans=8)

    assert result.status == "replan_stagnated"
    assert executor.calls == ["Audit SQLite concurrency hardening"]


def test_successful_replanning_is_bounded():
    planner = StaticPlanner(
        [
            plan("o1", "First useful task"),
            plan("o2", "Build telemetry dashboard"),
            plan("o3", "Validate scheduler isolation"),
            plan("o4", "Document release provenance"),
        ]
    )
    executor = RecordingExecutor(
        [("completed", None)] * 4,
    )

    result = MissionEngine(
        planner=planner,
        executor=executor,
    ).run("test mission", max_replans=2)

    assert result.status == "replan_limit_reached"
    assert executor.calls == [
        "First useful task",
        "Build telemetry dashboard",
        "Validate scheduler isolation",
    ]
    assert result.metadata["replans"] == 2


def contract_plan(objective_id, objective, work_type):
    return MissionPlan(
        mission_id="mission-test",
        goal="test mission",
        objectives=(
            MissionObjective(
                objective_id=objective_id,
                objective=objective,
                work_type=work_type,
            ),
        ),
    )


def test_mission_contract_requires_missing_outcome_classes_before_completion():
    planner = StaticPlanner(
        [
            contract_plan("r1", "Audit the repository", "research"),
            contract_plan("i1", "Implement the selected fix", "implementation"),
            contract_plan("t1", "Run focused tests", "testing"),
            contract_plan("v1", "Verify and report the result", "verification"),
            EMPTY_PLAN,
        ]
    )
    executor = RecordingExecutor([
        ("completed", None),
        ("completed", None),
        ("completed", None),
        ("completed", None),
    ])

    result = MissionEngine(
        planner=planner,
        executor=executor,
    ).run(
        "Research, implement, test, verify, and report the improvement",
        max_replans=8,
        contract=MissionContract(
            required_work_types=("research", "implementation", "testing", "verification"),
        ),
    )

    assert result.status == "completed"
    assert result.metadata["contract_satisfied"] is True
    assert result.metadata["covered_work_types"] == [
        "implementation", "research", "testing", "verification"
    ]


def test_mission_contract_does_not_treat_audit_only_work_as_done():
    planner = StaticPlanner(
        [
            contract_plan("r1", "Audit the repository", "research"),
            contract_plan("r2", "Perform another repository audit", "research"),
        ]
    )
    executor = RecordingExecutor([("completed", None), ("completed", None)])

    result = MissionEngine(
        planner=planner,
        executor=executor,
    ).run(
        "Audit the repository and implement safe improvements",
        max_replans=1,
        contract=MissionContract(required_work_types=("research", "implementation")),
    )

    assert result.status == "mission_contract_unsatisfied"
    assert result.metadata["missing_work_types"] == ["implementation"]


def test_contract_from_goal_detects_explicit_lifecycle_stages():
    contract = MissionContract.from_goal(
        "Audit the codebase, identify improvements, implement safe fixes, test them, verify the evidence, and report what changed"
    )
    assert contract.required_work_types == ("research", "implementation", "testing", "verification")


def test_contract_from_goal_does_not_infer_design_from_planning_language():
    contract = MissionContract.from_goal(
        "Plan the mission, produce concrete objectives, execute them, and verify the evidence"
    )
    assert "design" not in contract.required_work_types
    assert "verification" in contract.required_work_types


def test_contract_from_goal_does_not_treat_implementation_noun_as_implementation_intent():
    contract = MissionContract.from_goal(
        "Inspect the mission engine implementation and produce an evidence-backed report without modifying files"
    )
    assert contract.mutation_policy == "read_only"
    assert "research" in contract.required_work_types
    assert "implementation" not in contract.required_work_types
    assert "verification" in contract.required_work_types


def test_retryable_failure_resumes_from_persisted_plan_without_replanning(tmp_path):
    """A restart retries unfinished work without repeating the model plan."""
    import sqlite3

    from eventing.sqlite_store import SQLiteEventStore
    from ocean.domain.event_bus import EventBus

    mission_id = "durable-recovery"
    objective = MissionObjective(
        objective_id="recoverable",
        objective="Retry the transient candidate failure",
    )
    plan = MissionPlan(mission_id=mission_id, goal="recover safely", objectives=(objective,))

    class Planner:
        def __init__(self):
            self.calls = 0

        def plan(self, *args, **kwargs):
            self.calls += 1
            return plan

    class FailingExecutor:
        def execute(self, _mission_id, item):
            return MissionObjectiveResult(
                objective_id=item.objective_id,
                objective=item.objective,
                status="rejected",
                error="temporary worker outage",
                metadata={"retryable": True},
            )

    class SuccessfulExecutor:
        def __init__(self):
            self.calls = []

        def execute(self, _mission_id, item):
            self.calls.append(item.objective_id)
            return MissionObjectiveResult(
                objective_id=item.objective_id,
                objective=item.objective,
                status="completed",
                metadata={"verified": True, "evidence": ["recovered locally"]},
            )

    connection = sqlite3.connect(tmp_path / "state.sqlite3", check_same_thread=False)
    try:
        events = EventBus(store=SQLiteEventStore(connection))
        planner = Planner()
        first = MissionEngine(planner=planner, executor=FailingExecutor(), events=events).run(
            "recover safely", mission_id=mission_id, max_replans=0
        )
        assert first.status == "replan_limit_reached"

        recovered_executor = SuccessfulExecutor()
        recovered = MissionEngine(
            planner=planner,
            executor=recovered_executor,
            events=events,
        ).run("recover safely", mission_id=mission_id, max_replans=1)

        assert recovered.status == "completed"
        assert recovered_executor.calls == ["recoverable"]
        assert planner.calls == 2  # initial plan plus final completion check only
        assert events.history("ObjectiveRejected")[0].payload["metadata"]["retryable"] is True
        # The restart used the original persisted plan for the retry; the
        # second proposal is the normal final completion check.
        assert len(events.history("MissionPlanProposed")) == 2
    finally:
        connection.close()


def test_known_dag_executes_independent_work_concurrently_then_integrates_once():
    import threading
    import time

    mission_id = "parallel-dag"
    plan = MissionPlan(
        mission_id=mission_id,
        goal="parallel improvement",
        objectives=(
            MissionObjective(objective_id="research", objective="Inspect subsystem"),
            MissionObjective(objective_id="tests", objective="Add regression coverage"),
            MissionObjective(
                objective_id="integrate",
                objective="Integrate verified changes",
                dependencies=("research", "tests"),
            ),
        ),
    )

    class Planner:
        def __init__(self):
            self.calls = 0

        def plan(self, *_args, **_kwargs):
            self.calls += 1
            return plan if self.calls == 1 else MissionPlan(mission_id, "parallel improvement", ())

    class Executor:
        def __init__(self):
            self.started = []
            self.finished = []
            self.lock = threading.Lock()
            self.release = threading.Event()

        def execute(self, _mission_id, objective):
            with self.lock:
                self.started.append(objective.objective_id)
            if objective.objective_id != "integrate":
                self.release.wait(timeout=2)
            with self.lock:
                self.finished.append(objective.objective_id)
            return MissionObjectiveResult(
                objective_id=objective.objective_id,
                objective=objective.objective,
                status="completed",
                metadata={"verified": True, "evidence": [objective.objective_id]},
            )

    planner = Planner()
    executor = Executor()
    holder = {}
    worker = threading.Thread(
        target=lambda: holder.setdefault(
            "result",
            MissionEngine(planner=planner, executor=executor, max_concurrent_objectives=2).run(
                "parallel improvement", mission_id=mission_id
            ),
        )
    )
    worker.start()
    deadline = time.monotonic() + 1.5
    while len(executor.started) < 2 and time.monotonic() < deadline:
        time.sleep(0.01)
    assert sorted(executor.started) == ["research", "tests"]
    executor.release.set()
    worker.join(timeout=3)

    assert not worker.is_alive()
    assert holder["result"].status == "completed"
    assert executor.finished[-1] == "integrate"
    assert planner.calls == 2


def test_unexpected_runtime_exception_is_persisted_as_recoverable_failure():
    events = EventBus()

    class ExplodingPlanner:
        def plan(self, mission_id, goal, *, completed_objectives=(), previous_results=()):
            raise RuntimeError("planner transport exploded")

    engine = MissionEngine(
        planner=ExplodingPlanner(),
        executor=RecordingExecutor([]),
        events=events,
    )

    try:
        engine.run("exercise failure durability", mission_id="mission-crash-proof")
    except RuntimeError as exc:
        assert str(exc) == "planner transport exploded"
    else:
        raise AssertionError("expected planner failure")

    failures = [
        event for event in events.history()
        if event.type == "MissionFailed"
        and event.aggregate_id == "mission-crash-proof"
    ]
    assert len(failures) == 1
    assert failures[0].payload["recoverable"] is True
    assert "planner transport exploded" in failures[0].payload["error"]



def test_resuming_cancelled_mission_is_terminal_and_does_not_reexecute():
    events = EventBus()
    objective = MissionObjective(
        objective_id="cancelled-objective",
        objective="should never run again",
    )
    plan = MissionPlan(
        mission_id="mission-cancelled",
        goal="cancelled mission",
        objectives=(objective,),
    )

    class StaticPlanner:
        def plan(self, mission_id, goal, **kwargs):
            return plan

    executor = RecordingExecutor([MissionObjectiveResult(
        objective_id=objective.objective_id,
        objective=objective.objective,
        status="completed",
    )])
    engine = MissionEngine(
        planner=StaticPlanner(),
        executor=executor,
        events=events,
    )
    events.publish(Event(
        type="MissionStarted",
        payload={"mission_id": "mission-cancelled", "goal": plan.goal},
        aggregate_type="mission",
        aggregate_id="mission-cancelled",
    ))
    events.publish(Event(
        type="MissionPlanProposed",
        payload=engine._plan_payload(plan),
        aggregate_type="mission",
        aggregate_id="mission-cancelled",
    ))
    events.publish(Event(
        type="MissionCancelled",
        payload={"mission_id": "mission-cancelled", "reason": "operator requested stop"},
        aggregate_type="mission",
        aggregate_id="mission-cancelled",
    ))

    result = engine.run(plan.goal, mission_id=plan.mission_id)

    assert result.status == "cancelled"
    assert executor.calls == []


def test_contract_gap_is_passed_to_planner_as_structured_feedback():
    class Planner:
        def __init__(self):
            self.calls = []

        def plan(self, mission_id, goal, *, completed_objectives=(), previous_results=()):
            self.calls.append(tuple(previous_results))
            if len(self.calls) == 1:
                return contract_plan("research", "Research the repository", "research")
            return contract_plan("implementation", "Implement the selected improvement", "implementation")

    executor = RecordingExecutor([("completed", None), ("completed", None)])
    planner = Planner()
    result = MissionEngine(planner=planner, executor=executor).run(
        "Research and implement the improvement",
        max_replans=2,
        contract=MissionContract(required_work_types=("research", "implementation")),
    )

    assert result.status == "completed"
    gap = [r for r in planner.calls[1] if r.objective_id == "planner_contract_gap"]
    assert len(gap) == 1
    assert gap[0].status == "planner_feedback"
    assert gap[0].metadata["missing_work_types"] == ("implementation",)


def test_contract_from_goal_does_not_require_computer_for_ordinary_app_language():
    contract = MissionContract.from_goal(
        "Improve the app authentication flow, implement the fix, test it, and verify the result"
    )
    assert "computer" not in contract.required_work_types
    assert contract.required_work_types == ("implementation", "testing", "verification")


def test_planner_control_feedback_ids_are_never_executable():
    planner = StaticPlanner([
        MissionPlan(
            mission_id="mission-test",
            goal="test mission",
            objectives=(
                MissionObjective(
                    objective_id="planner_contract_gap",
                    objective="Planner runtime feedback",
                    work_type="integration",
                ),
            ),
        ),
        contract_plan("real", "Implement the actual improvement", "implementation"),
        EMPTY_PLAN,
    ])
    executor = RecordingExecutor([("completed", None)])

    result = MissionEngine(planner=planner, executor=executor).run(
        "Implement the improvement",
        max_replans=2,
        contract=MissionContract(required_work_types=("implementation",)),
    )

    assert result.status == "completed"
    assert executor.calls == ["Implement the actual improvement"]


def test_every_returned_terminal_result_is_durably_projectable(tmp_path):
    """A direct MissionResult return must never leave status stuck in replanning."""
    import sqlite3

    from eventing.sqlite_store import SQLiteEventStore
    from ocean.domain.event_bus import EventBus
    from ocean.observability.status import OperationalStatusProjector

    class EmptyPlanner:
        def plan(self, *args, **kwargs):
            return EMPTY_PLAN

    connection = sqlite3.connect(tmp_path / "state.sqlite3", check_same_thread=False)
    try:
        store = SQLiteEventStore(connection)
        bus = EventBus(store=store)
        result = MissionEngine(planner=EmptyPlanner(), executor=RecordingExecutor([]), events=bus).run(
            "implement the improvement",
            mission_id="terminal-projection",
            max_replans=1,
            contract=MissionContract(required_work_types=("implementation",)),
        )
        assert result.status == "mission_contract_unsatisfied"
        status = OperationalStatusProjector(store).mission("terminal-projection")
        assert status.status == "mission_contract_unsatisfied"
        assert status.current_activity == "mission contract unsatisfied"
    finally:
        connection.close()
