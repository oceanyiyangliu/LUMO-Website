from datetime import datetime, timezone

from ocean.domain.observation import Observation
from persistence.serializers.observation import ObservationSerializer


def test_observation_serializer_round_trip():
    at = datetime(2026, 1, 1, 12, 30, tzinfo=timezone.utc)

    observation = Observation(
        kind="screenshot",
        data={
            "width": 1440,
            "height": 900,
            "description": "Desktop state",
        },
        task_id="task-1",
        execution_id="exec-1",
        id="obs-1",
        at=at,
    )

    serializer = ObservationSerializer()

    serialized = serializer.serialize(observation)
    restored = serializer.deserialize(serialized)

    assert restored == observation


def test_observation_serializer_preserves_optional_ids():
    observation = Observation(
        kind="system_state",
        data={"cpu": 42},
        id="obs-2",
    )

    serializer = ObservationSerializer()

    restored = serializer.deserialize(serializer.serialize(observation))

    assert restored.task_id is None
    assert restored.execution_id is None


def test_observation_serializer_preserves_timestamp():
    at = datetime(2026, 5, 10, 8, 15, 30, tzinfo=timezone.utc)

    observation = Observation(
        kind="event",
        id="obs-3",
        at=at,
    )

    serializer = ObservationSerializer()

    data = serializer.serialize(observation)

    assert data["at"] == "2026-05-10T08:15:30+00:00"

    restored = serializer.deserialize(data)

    assert restored.at == at
