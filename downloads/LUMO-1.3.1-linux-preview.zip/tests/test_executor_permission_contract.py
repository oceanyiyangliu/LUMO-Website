"""Regression test for the runtime/executor.py permission-contract bug.

Root cause (found in review, prior to fix):
    ocean.capabilities.terminal.terminal_spec() / filesystem.filesystem_spec()
    declare a single, dot-separated, capability-level permission, e.g.
    "terminal.execute" or "filesystem.read". This is the canonical contract:
    runtime/runtime.py's ExecutionRuntime.execute() (the real production
    path) passes exactly `capability.requires_permissions` into
    GovernanceEngine -> AuthorizationEngine.

    runtime/executor.py's `_EnforcingExecutor` (used only when an
    ExecutorRegistry is constructed with auth_policy/resource_plane/
    capabilities kwargs) instead fabricated a *second*, incompatible
    permission string: f"{capability}:{operation}" (colon-separated,
    one distinct string per operation, e.g. "terminal:run" and
    "terminal:execute" as two different permissions for one capability).

    That string never matches anything any CapabilitySpec declares or any
    policy is configured against. If this wrapper is ever wired into a real
    ExecutorRegistry, it silently denies every authorized call (or requires
    maintaining a second, drifting set of per-operation grants) instead of
    enforcing the same contract as the primary execution path.

This test builds a minimal stand-in capability registry/spec and a
StaticAuthorizationPolicy granted only the canonical
`capability.requires_permissions` set, then asserts the enforcing wrapper
authorizes correctly-permissioned calls and rejects everything else --
without ever needing a colon-joined "capability:operation" grant.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, FrozenSet, Set

import pytest

from runtime.executor import CapabilityExecutor, ExecutorRegistry
from runtime.types import ExecutionRequest, ExecutionResult

from ocean.authorization.policy import StaticAuthorizationPolicy


@dataclass(frozen=True)
class _FakeOperation:
    name: str


@dataclass(frozen=True)
class _FakeCapabilitySpec:
    name: str
    requires_permissions: Set[str] = field(default_factory=set)

    def operation(self, name: str) -> _FakeOperation:
        return _FakeOperation(name=name)


class _FakeCapabilityRegistry:
    """Minimal stand-in for ocean.domain.capability.CapabilityRegistry."""

    def __init__(self, specs: Dict[str, _FakeCapabilitySpec]) -> None:
        self._specs = specs

    def get(self, name: str) -> _FakeCapabilitySpec:
        return self._specs[name]

    def get_operation(self, capability: str, operation: str) -> _FakeOperation:
        return self._specs[capability].operation(operation)


class _RecordingExecutor(CapabilityExecutor):
    def __init__(self) -> None:
        self.calls = 0

    def execute(self, request: ExecutionRequest, context) -> ExecutionResult:
        self.calls += 1
        return ExecutionResult(success=True, result={"ok": True}, error=None)


def _build_registry(principal_permissions: FrozenSet[str]):
    capabilities = _FakeCapabilityRegistry(
        {
            "terminal": _FakeCapabilitySpec(
                name="terminal", requires_permissions={"terminal.execute"}
            )
        }
    )
    auth_policy = StaticAuthorizationPolicy(
        {"agent-1": principal_permissions}
    )
    underlying = _RecordingExecutor()
    registry = ExecutorRegistry(
        auth_policy=auth_policy,
        resource_plane=None,
        capabilities=capabilities,
    )
    registry.register("deterministic_local", underlying)
    return registry, underlying


def _make_request(operation: str) -> ExecutionRequest:
    return ExecutionRequest(
        task_id="task-1",
        capability="terminal",
        operation=operation,
        agent_id="agent-1",
        arguments={"command": ["true"]},
    )


def test_canonical_capability_level_permission_authorizes_run():
    # Principal holds exactly the spec's declared permission -- the ONLY
    # grant any real policy configuration would use.
    registry, underlying = _build_registry(frozenset({"terminal.execute"}))
    executor = registry.get("deterministic_local")

    result = executor.execute(_make_request("run"), context=None)

    assert result.success is True
    assert underlying.calls == 1


def test_canonical_capability_level_permission_authorizes_execute_alias():
    registry, underlying = _build_registry(frozenset({"terminal.execute"}))
    executor = registry.get("deterministic_local")

    result = executor.execute(_make_request("execute"), context=None)

    assert result.success is True
    assert underlying.calls == 1


def test_missing_permission_is_rejected():
    registry, underlying = _build_registry(frozenset())  # no grants at all

    executor = registry.get("deterministic_local")

    with pytest.raises(PermissionError):
        executor.execute(_make_request("run"), context=None)

    assert underlying.calls == 0


def test_stale_operation_scoped_grant_no_longer_required_or_recognized():
    # A principal granted only the OLD, buggy colon-joined per-operation
    # string must NOT be treated as authorized: that string is not part of
    # the canonical contract. This pins the fix -- before the fix, a grant
    # of "terminal.execute" alone (the canonical, correct grant) would have
    # been silently rejected because the wrapper checked for "terminal:run"
    # instead.
    registry, underlying = _build_registry(frozenset({"terminal:run"}))
    executor = registry.get("deterministic_local")

    with pytest.raises(PermissionError):
        executor.execute(_make_request("run"), context=None)

    assert underlying.calls == 0
