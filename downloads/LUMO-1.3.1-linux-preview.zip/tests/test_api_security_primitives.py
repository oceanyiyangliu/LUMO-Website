import pytest
from ocean.api_security import *
from ocean.security import SessionAuthority

def test_auth_csrf_and_cursor():
    s=SessionAuthority(secret=b"x"*32); tok=s.issue("a"); sess=APIAuth(s).authenticate("Bearer "+tok); n="n"; csrf=APIAuth.csrf(sess.session_id,"POST","/x",n); assert APIAuth.verify_csrf(sess.session_id,"POST","/x",n,csrf)
    c=CursorCodec(b"y"*32); cur=c.encode(7,"a"); assert c.decode(cur,"a")==7
    with pytest.raises(ValueError): c.decode(cur,"b")

def test_content_negotiation_and_enrollment():
    assert negotiate_content_type("application/json")=="application/json"
    with pytest.raises(ValueError): negotiate_content_type("text/html")
    e=DeviceEnrollmentAuthority(); code=e.issue("a"); assert e.consume(code,"a"); assert not e.consume(code,"a")
