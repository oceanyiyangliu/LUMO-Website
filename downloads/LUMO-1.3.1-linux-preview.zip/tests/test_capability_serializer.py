from ocean.domain.capability import CapabilitySpec, OperationSpec
from ocean.domain.enums import RiskLevel
from ocean.domain.resource import ResourceRequirement
from persistence.serializers.capability import CapabilitySerializer


def test_capability_serializer_round_trip():
    capability = CapabilitySpec(
        name="filesystem",
        description="Local filesystem operations",
        operations={
            "read_file": OperationSpec(
                name="read_file",
                description="Read a file",
                input_schema={
                    "path": "string",
                },
                output_schema={
                    "content": "string",
                },
                risk_level=RiskLevel.LOW,
                resource_requirements=[
                    ResourceRequirement(
                        kind="filesystem",
                        amount=1,
                    ),
                    ResourceRequirement(
                        kind="disk_io",
                        amount=0.5,
                    ),
                ],
            ),
            "delete_file": OperationSpec(
                name="delete_file",
                description="Delete a file",
                input_schema={
                    "path": "string",
                },
                output_schema={
                    "deleted": "boolean",
                },
                risk_level=RiskLevel.HIGH,
            ),
        },
        execution_strategy="deterministic_local",
        requires_permissions={
            "filesystem.read",
            "filesystem.write",
        },
    )

    serializer = CapabilitySerializer()

    serialized = serializer.serialize(capability)
    restored = serializer.deserialize(serialized)

    assert restored == capability


def test_capability_serializer_preserves_nested_resource_requirements():
    capability = CapabilitySpec(
        name="computer",
        description="Computer interaction",
        operations={
            "click": OperationSpec(
                name="click",
                description="Click at a screen coordinate",
                resource_requirements=[
                    ResourceRequirement(
                        kind="computer_control",
                        amount=1.0,
                    ),
                    ResourceRequirement(
                        kind="agent_slot",
                        amount=1.0,
                    ),
                ],
            )
        },
    )

    serializer = CapabilitySerializer()

    data = serializer.serialize(capability)

    resources = data["operations"]["click"]["resource_requirements"]

    assert resources == [
        {
            "kind": "computer_control",
            "amount": 1.0,
        },
        {
            "kind": "agent_slot",
            "amount": 1.0,
        },
    ]

    restored = serializer.deserialize(data)

    restored_resources = restored.operations[
        "click"
    ].resource_requirements

    assert restored_resources == [
        ResourceRequirement(
            kind="computer_control",
            amount=1.0,
        ),
        ResourceRequirement(
            kind="agent_slot",
            amount=1.0,
        ),
    ]


def test_capability_serializer_preserves_permissions_and_risk():
    capability = CapabilitySpec(
        name="browser",
        description="Browser operations",
        operations={
            "open": OperationSpec(
                name="open",
                description="Open a URL",
                risk_level=RiskLevel.IMPORTANT,
            )
        },
        execution_strategy="gui",
        requires_permissions={
            "network",
            "browser",
        },
    )

    serializer = CapabilitySerializer()

    data = serializer.serialize(capability)

    assert data["execution_strategy"] == "gui"
    assert data["requires_permissions"] == [
        "browser",
        "network",
    ]
    assert data["operations"]["open"]["risk_level"] == RiskLevel.IMPORTANT.value

    restored = serializer.deserialize(data)

    assert restored.execution_strategy == "gui"
    assert restored.requires_permissions == {
        "network",
        "browser",
    }
    assert restored.operations["open"].risk_level == RiskLevel.IMPORTANT
