from ocean.resilience import DependencyRecovery, DependencyRequirement

class Events:
    def __init__(self): self.items=[]
    def publish(self, event): self.items.append(event)

def test_dependency_recovery_emits_approval_for_vscode(monkeypatch):
    events=Events()
    recovery=DependencyRecovery(events=events)
    monkeypatch.setattr("shutil.which", lambda command: None)
    actions=recovery.recover("m1", (DependencyRequirement("Visual Studio Code", command="code", auto_install=True),))
    assert actions[0].requires_user is True
    assert actions[0].status == "blocked_pending_user"
    assert any(e.type == "DependencyInstallApprovalRequired" for e in events.items)
