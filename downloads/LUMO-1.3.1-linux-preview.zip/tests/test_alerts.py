from ocean.observability.metrics import AlertEngine

def test_alert_severity_dedup_and_suppression():
 e=AlertEngine(10); a=e.observe("x","warning","bad",0); assert a.count==1; assert e.observe("x","error","worse",5) is None; a=e.observe("x","critical","worse",11); assert a.count==2 and a.severity=="critical"; e.suppress("y",20); assert e.observe("y","error","x",10) is None
