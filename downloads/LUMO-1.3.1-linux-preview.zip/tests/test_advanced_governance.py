from datetime import datetime,timezone,timedelta
from ocean.advanced_governance import *

def test_scopes_approvals_policy_and_denials():
    g=ScopedGrant("p","a",mission_id="m",permissions=frozenset({"run"})); assert g.valid(); assert not ScopedGrant("p","b").valid() is False
    r=ApprovalReceipt("id","p","delete",RiskBand.HIGH,datetime.now(timezone.utc),datetime.now(timezone.utc)+timedelta(seconds=1)); assert r.valid()
    assert escalate_risk(RiskBand.HIGH,{"irreversible":True}) is RiskBand.CRITICAL
    assert normalize_denial(["invalid CSRF token"])==("CSRF_INVALID",)

def test_invariant_checker_fails_closed():
    c=GovernanceInvariantChecker(); v=c.check(emergency_stop=True,executing=True,verified=False); assert "EMERGENCY_STOP_EXECUTION" in v and "MISSING_GRANT" in v and "UNVERIFIED_EXECUTION" in v
