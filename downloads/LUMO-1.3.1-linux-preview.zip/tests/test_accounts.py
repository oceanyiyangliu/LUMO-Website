from ocean.accounts import AccountStore


def test_accounts_are_durable_and_adaptive_state_isolated(tmp_path):
    path = tmp_path / "accounts.sqlite3"
    store = AccountStore(path)
    first = store.ensure_default("Ocean")
    second = store.create("Builder")
    store.set_adaptive(first["id"], "style", {"density": "compact"})
    store.set_adaptive(second["id"], "style", {"density": "spacious"})
    assert store.get_adaptive(first["id"])["style"]["density"] == "compact"
    assert store.get_adaptive(second["id"])["style"]["density"] == "spacious"
    store.close()


def test_adaptive_usage_increment_is_atomic_and_bounded(tmp_path):
    store = AccountStore(tmp_path / "accounts.sqlite3")
    account = store.ensure_default("Ocean")
    first = store.increment_adaptive_number(account["id"], "feedback_usage_seconds", 60)
    second = store.increment_adaptive_number(account["id"], "feedback_usage_seconds", 30)
    assert first["value"] == 60.0
    assert second["value"] == 90.0
    assert store.get_adaptive(account["id"])["feedback_usage_seconds"] == 90.0
    store.close()


def test_adaptive_usage_rejects_negative_or_excessive_increments(tmp_path):
    store = AccountStore(tmp_path / "accounts.sqlite3")
    account = store.ensure_default("Ocean")
    import pytest
    with pytest.raises(ValueError):
        store.increment_adaptive_number(account["id"], "feedback_usage_seconds", -1)
    with pytest.raises(ValueError):
        store.increment_adaptive_number(account["id"], "feedback_usage_seconds", 3601)
    store.close()


def test_accounts_survive_store_reopen(tmp_path):
    path = tmp_path / "accounts.sqlite3"
    store = AccountStore(path)
    account = store.create("Persistent")
    store.set_adaptive(account["id"], "onboarding.completed", True)
    store.close()
    reopened = AccountStore(path)
    assert reopened.get(account["id"])["name"] == "Persistent"
    assert reopened.get_adaptive(account["id"])["onboarding.completed"] is True
    reopened.close()
