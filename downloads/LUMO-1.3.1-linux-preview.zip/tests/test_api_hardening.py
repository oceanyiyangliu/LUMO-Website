from pathlib import Path
import pytest
from ocean.api import LumoAPI
from ocean.service import OceanService


def test_mutation_rate_limit_is_bounded(tmp_path):
    service = OceanService(repository_root=tmp_path)
    api = LumoAPI(service)
    for _ in range(30):
        assert api.allow_mutation("127.0.0.1") is True
    assert api.allow_mutation("127.0.0.1") is False


def test_mutation_rate_limit_is_per_client(tmp_path):
    service = OceanService(repository_root=tmp_path)
    api = LumoAPI(service)
    for _ in range(30):
        assert api.allow_mutation("127.0.0.1") is True
    assert api.allow_mutation("::1") is True


def test_rate_limit_bucket_expires(tmp_path, monkeypatch):
    service = OceanService(repository_root=tmp_path)
    api = LumoAPI(service)
    monkeypatch.setattr("ocean.api.time.monotonic", lambda: 0.0)
    for _ in range(30):
        api.allow_mutation("127.0.0.1")
    assert api.allow_mutation("127.0.0.1") is False
    monkeypatch.setattr("ocean.api.time.monotonic", lambda: 2.0)
    assert api.allow_mutation("127.0.0.1") is True


def test_client_error_redaction_hides_local_paths(tmp_path):
    service = OceanService(repository_root=tmp_path)
    api = LumoAPI(service)
    from ocean.api import _redact_error
    rendered = _redact_error(f"failed at {tmp_path}/secret/file.txt")
    assert str(tmp_path) not in rendered
    assert "[local-path]" in rendered


def test_control_plane_rejects_untrusted_host_header(tmp_path):
    import http.client
    import threading
    from ocean.api import LumoAPIServer
    service = OceanService(repository_root=tmp_path)
    service.start()
    server = LumoAPIServer(service, port=0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        conn = http.client.HTTPConnection(server.address[0], server.address[1], timeout=2)
        conn.request("GET", "/api/health", headers={"Host": "evil.example"})
        response = conn.getresponse()
        assert response.status == 403
        conn.close()
    finally:
        server.shutdown()
        thread.join(timeout=2)
        service.stop()


def test_mission_idempotency_key_reuses_durable_submission(tmp_path, monkeypatch):
    service = OceanService(repository_root=tmp_path)
    service.start()
    try:
        service._runtime = object()
        api = LumoAPI(service)
        api.release_emergency_stop(safety_acknowledged=True)
        monkeypatch.setattr(api, "_run_mission", lambda *args: None)
        first = api.submit_mission("same goal", idempotency_key="k-1")
        second = api.submit_mission("same goal", idempotency_key="k-1")
        assert second == first
    finally:
        service.stop()


def test_control_plane_rejects_host_userinfo(tmp_path):
    import http.client
    import threading
    from ocean.api import LumoAPIServer
    service = OceanService(repository_root=tmp_path)
    service.start()
    server = LumoAPIServer(service, port=0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        conn = http.client.HTTPConnection(server.address[0], server.address[1], timeout=2)
        conn.request("GET", "/api/health", headers={"Host": "attacker@localhost"})
        assert conn.getresponse().status == 403
        conn.close()
    finally:
        server.shutdown(); thread.join(timeout=2); service.stop()


def test_control_plane_rejects_oversized_body_before_read(tmp_path):
    import http.client
    import threading
    from ocean.api import LumoAPIServer, _API_MAX_BODY_BYTES
    service = OceanService(repository_root=tmp_path)
    service.start()
    server = LumoAPIServer(service, port=0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        conn = http.client.HTTPConnection(server.address[0], server.address[1], timeout=2)
        conn.request("POST", "/api/account", body=b"", headers={"Content-Length": str(_API_MAX_BODY_BYTES + 1)})
        response = conn.getresponse()
        assert response.status == 413
        assert response.read()
        conn.close()
    finally:
        server.shutdown(); thread.join(timeout=2); service.stop()


def test_root_recovery_api_round_trip(tmp_path):
    from ocean.api import LumoAPI
    from ocean.service import OceanService
    service = OceanService(repository_root=tmp_path)
    service.start()
    api = LumoAPI(service)
    root_id = service.root_authority.root_id
    exported = api.root_recovery_export("launch recovery password")
    assert exported["created"] is True
    assert exported["root_id"] == root_id
    assert Path(exported["path"]).is_file()
    assert api.root_recovery_restore(exported["path"], "launch recovery password")["root_id"] == root_id
    with pytest.raises(PermissionError):
        api.root_recovery_restore(str(tmp_path / "outside.lumo-recovery"), "launch recovery password")
    service.stop()


def test_emergency_release_is_stable_and_idempotent(tmp_path):
    service = OceanService(repository_root=tmp_path)
    service.start()
    try:
        service._runtime = object()
        api = LumoAPI(service)
        assert api.emergency_status()["engaged"] is True
        first = api.release_emergency_stop(safety_acknowledged=True)
        assert first["engaged"] is False
        # A readiness refresh immediately after release must not re-engage the stop.
        assert api.readiness()["emergency_stop"] is False
        second = api.release_emergency_stop(safety_acknowledged=True)
        assert second["engaged"] is False
        assert api.readiness()["ready"] is True
    finally:
        service.stop()
