import pytest
from ocean.evolution_controls import CanaryController, CanaryPolicy

def test_canary_assignment_is_stable_and_quality_gated():
    c=CanaryController(CanaryPolicy(traffic_percent=50,min_samples=10,max_failure_rate=.1))
    assert c.assign('same')==c.assign('same')
    assert c.evaluate(samples=5,failures=0).promote is False
    assert c.evaluate(samples=10,failures=2).rollback is True
    assert c.evaluate(samples=10,failures=0).promote is True
    with pytest.raises(ValueError): CanaryPolicy(traffic_percent=0)
