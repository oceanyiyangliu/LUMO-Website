import pytest

from ocean.core.ids import new_id


def test_new_id_has_prefix_and_is_unique():
    a = new_id("task")
    b = new_id("task")
    assert a.startswith("task_")
    assert b.startswith("task_")
    assert a != b


def test_new_id_rejects_bad_prefix():
    with pytest.raises(ValueError):
        new_id("bad prefix!")
