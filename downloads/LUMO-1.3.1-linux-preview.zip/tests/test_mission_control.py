from __future__ import annotations

from dataclasses import dataclass

import pytest

from ocean.core.errors import InvalidStateTransition
from ocean.domain.assignment import Assignment
from ocean.domain.enums import (
    AssignmentStatus,
    MissionStatus,
    OrchestrationMode,
    TaskStatus,
)
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.domain.mission import Mission
from ocean.domain.plan import PlanRevision, PlanStatus
from ocean.domain.task import Task
from ocean.mission_control.control import MissionControl
from ocean.planning.planner import PlanningResult
from ocean.orchestration.execution_plan_runner import ExecutionPlanRunResult


class Repo:
    def __init__(self):
        self.items = {}

    def save(self, entity):
        self.items[entity.id] = entity
        return entity

    def get(self, entity_id):
        return self.items.get(entity_id)

    def delete(self, entity_id):
        return self.items.pop(entity_id, None) is not None

    def list(self):
        return list(self.items.values())


class FakePlanning:
    def __init__(self):
        self.calls = []

    def plan(self, request, planner):
        self.calls.append((request, planner))
        return ("plan", "graph")

    def propose(self, plan_id, *, reason=None):
        return ("proposed", plan_id, reason)

    def activate(self, plan_id, *, reason=None):
        return ("active", plan_id, reason)


class FakeProvider:
    def __init__(self, executable=None):
        self.executable = executable
        self.calls = []

    def get(self, plan_revision_id):
        self.calls.append(plan_revision_id)
        return self.executable


class FakeRunner:
    def __init__(self):
        self.calls = []

    def start(self, plan, *, mode=None, priority=0):
        self.calls.append((plan, mode, priority))
        return ExecutionPlanRunResult(
            plan_revision_id="plan-1",
            assignment_ids={"node-1": "assignment-1"},
            execution_ids={"node-1": "execution-1"},
            queued_node_ids=("node-1",),
            blocked_node_ids=(),
            errors=(),
        )


def build_control():
    events = EventBus()
    missions = Repo()
    tasks = Repo()
    assignments = Repo()
    plans = Repo()
    planning = FakePlanning()
    provider = FakeProvider(executable="execution-plan")
    runner = FakeRunner()

    control = MissionControl(
        missions=missions,
        tasks=tasks,
        assignments=assignments,
        plan_revisions=plans,
        planning=planning,
        execution_plans=provider,
        execution_runner=runner,
        agent_resolver=lambda step: "agent-1",
        events=events,
    )

    return (
        control,
        events,
        missions,
        tasks,
        assignments,
        plans,
        planning,
        provider,
        runner,
    )


def test_create_persists_mission_and_publishes_event():
    control, events, missions, *_ = build_control()

    observed = []
    events.subscribe("MissionCreated", observed.append)

    mission = control.create(goal="Build a spacecraft")

    assert missions.get(mission.id) is mission
    assert mission.status is MissionStatus.PLANNING
    assert observed[0].payload["goal"] == "Build a spacecraft"
    assert observed[0].aggregate_id == mission.id


def test_activate_pause_resume_cancel_follow_domain_lifecycle():
    control, *_ = build_control()
    mission = control.create(goal="Mission")

    control.activate(mission.id)
    assert mission.status is MissionStatus.ACTIVE

    control.pause(mission.id)
    assert mission.status is MissionStatus.PAUSED

    control.resume(mission.id)
    assert mission.status is MissionStatus.ACTIVE

    control.cancel(mission.id)
    assert mission.status is MissionStatus.CANCELLED


def test_invalid_lifecycle_transition_is_rejected():
    control, *_ = build_control()
    mission = control.create(goal="Mission")

    with pytest.raises(InvalidStateTransition):
        control.pause(mission.id)


def test_plan_delegates_to_planning_service():
    control, _, _, _, _, _, planning, *_ = build_control()
    mission = control.create(goal="Build")

    planner = object()
    result = control.plan(
        mission.id,
        planner=planner,
    )

    assert result == ("plan", "graph")
    assert planning.calls[0][0].mission_id == mission.id
    assert planning.calls[0][0].objective == "Build"


def test_start_plan_requires_active_mission_and_active_plan():
    control, _, _, _, _, plans, _, provider, runner = build_control()
    mission = control.create(goal="Build")

    plan = PlanRevision(
        mission_id=mission.id,
        revision=1,
        decision_id="decision-1",
        graph_id="graph-1",
        status=PlanStatus.ACTIVE,
        id="plan-1",
    )
    plans.save(plan)

    with pytest.raises(ValueError):
        control.start_plan(plan.id)

    control.activate(mission.id)
    result = control.start_plan(plan.id, priority=7)

    assert result.success
    assert provider.calls == ["plan-1"]
    assert runner.calls == [("execution-plan", None, 7)]


def test_progress_is_reconstructed_from_durable_repositories():
    control, _, missions, tasks, assignments, *_ = build_control()

    mission = control.create(goal="Build")

    t1 = Task(
        title="A",
        mission_id=mission.id,
        id="task-1",
        status=TaskStatus.COMPLETED,
    )
    t2 = Task(
        title="B",
        mission_id=mission.id,
        id="task-2",
        status=TaskStatus.PENDING,
    )

    tasks.save(t1)
    tasks.save(t2)

    assignments.save(
        Assignment(
            task_id=t2.id,
            agent_id="agent-1",
            mission_id=mission.id,
            status=AssignmentStatus.QUEUED,
            id="assignment-1",
        )
    )

    progress = control.progress(mission.id)

    assert progress.total_tasks == 2
    assert progress.completed_tasks == 1
    assert progress.pending_tasks == 1
    assert progress.queued_assignments == 1
    assert not progress.terminal_success


def test_mission_completes_only_after_tasks_are_completed():
    control, _, missions, tasks, *_ = build_control()

    mission = control.create(goal="Build")
    control.activate(mission.id)

    task = Task(
        title="Deliver",
        mission_id=mission.id,
        id="task-1",
        status=TaskStatus.COMPLETED,
    )
    tasks.save(task)

    result = control.reconcile_completion(mission.id)

    assert result.success
    assert missions.get(mission.id).status is MissionStatus.COMPLETED


def test_execution_success_does_not_complete_task():
    control, events, missions, tasks, assignments, *_ = build_control()

    mission = control.create(goal="Build")
    control.activate(mission.id)

    task = Task(
        title="Verify me",
        mission_id=mission.id,
        id="task-1",
        status=TaskStatus.PENDING,
    )
    tasks.save(task)

    assignment = Assignment(
        task_id=task.id,
        agent_id="agent-1",
        mission_id=mission.id,
        status=AssignmentStatus.COMPLETED,
        execution_id="execution-1",
        id="assignment-1",
    )
    assignments.save(assignment)

    failures = events.publish(
        Event(
            type="TaskAssignmentCompleted",
            payload={
                "assignment_id": assignment.id,
                "task_id": task.id,
                "mission_id": mission.id,
                "execution_id": "execution-1",
            },
        )
    )

    assert failures == []
    assert tasks.get(task.id).status is TaskStatus.PENDING
    assert missions.get(mission.id).status is MissionStatus.ACTIVE


def test_failed_assignment_is_observed_without_implicit_retry():
    control, events, missions, tasks, assignments, *_ = build_control()

    mission = control.create(goal="Build")
    control.activate(mission.id)

    task = Task(
        title="Failure",
        mission_id=mission.id,
        id="task-1",
        status=TaskStatus.FAILED,
    )
    tasks.save(task)

    assignment = Assignment(
        task_id=task.id,
        agent_id="agent-1",
        mission_id=mission.id,
        status=AssignmentStatus.FAILED,
        execution_id="execution-1",
        id="assignment-1",
    )
    assignments.save(assignment)

    failures = events.publish(
        Event(
            type="TaskAssignmentFailed",
            payload={"assignment_id": assignment.id},
        )
    )

    assert failures == []
    assert missions.get(mission.id).status is MissionStatus.ACTIVE


def test_replan_updates_durable_mission_and_emits_event():
    control, events, missions, tasks, *_ = build_control()

    mission = control.create(goal="Old goal")

    observed = []
    events.subscribe("MissionReplanned", observed.append)

    control.replan(
        mission.id,
        goal="New goal",
        metadata={"reason": "new information"},
    )

    stored = missions.get(mission.id)

    assert stored.goal == "New goal"
    assert stored.metadata["reason"] == "new information"
    assert observed[0].payload["goal"] == "New goal"


def test_create_rejects_unknown_task():
    control, *_ = build_control()

    with pytest.raises(ValueError):
        control.create(
            goal="Build",
            task_ids=["missing-task"],
        )
