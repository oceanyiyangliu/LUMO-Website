from __future__ import annotations

from types import SimpleNamespace

from ocean.orchestration.autonomous_build import (
    AutonomousWorkType,
    RuntimeAutonomousBuildExecutor,
)
from ocean.orchestration.mission_engine import MissionObjective


def objective(kind, *, dependencies=()):
    return MissionObjective(
        objective_id=f"{kind}-1",
        objective=f"Do {kind}",
        work_type=kind,
        acceptance_criteria=(f"{kind} evidence exists",),
        dependencies=tuple(dependencies),
        metadata={"autonomous_build": True},
    )


class FakeEvents:
    def __init__(self, events=()):
        self._events = list(events)

    def history(self, event_type=None):
        if event_type is None:
            return list(self._events)
        return [e for e in self._events if e.type == event_type]

    def publish(self, event):
        self._events.append(event)
        return []


class FakeMissions:
    def __init__(self):
        self.items = {}

    def get(self, key):
        return self.items.get(key)

    def save(self, value):
        self.items[value.id] = value


class FakeResearch:
    def __init__(self):
        self.calls = []

    def conduct(self, request, provider):
        self.calls.append((request, provider))
        return SimpleNamespace(findings=(SimpleNamespace(id="finding-1"),))

    def evidence_for_candidate(self, candidate_id):
        return (f"finding={candidate_id}",)


class FakePlanning:
    def __init__(self):
        self.calls = []

    def create_decision(self, **kwargs):
        self.calls.append(kwargs)
        return SimpleNamespace(id="decision-1")


class FakeBenchmarkProvider:
    def __init__(self, quality=1.0):
        self.quality = quality
        self.calls = []

    def benchmark(self, request):
        self.calls.append(request)
        return SimpleNamespace(
            results=(
                SimpleNamespace(
                    name="test_quality",
                    value=self.quality,
                    metadata={"exit_code": 0 if self.quality else 1},
                ),
            ),
            metadata={"command": ["pytest", "-q"]},
        )


class FakeRuntime:
    def __init__(self):
        self.missions = FakeMissions()
        self.events = FakeEvents()
        self.research = FakeResearch()
        self.research_provider = object()
        self.planning = FakePlanning()
        self.benchmark_provider = FakeBenchmarkProvider()
        self.repository_root = "/repo"
        self.baseline_root = "/repo"
        self.improve_calls = []

    def improve(self, objective, **kwargs):
        self.improve_calls.append((objective, kwargs))
        return SimpleNamespace(
            status="promoted",
            run_id="run-1",
            candidate_id="candidate-1",
            promoted_plan_revision_id="plan-1",
            candidate_tests_passed=True,
            decision=SimpleNamespace(passed=True, improved_metrics=("metric",)),
            error=None,
        )


class FakeStrategicModel:
    def __init__(self):
        self.calls = []

    def decompose(self, **kwargs):
        self.calls.append(kwargs)
        return (objective("implementation"),)


def executor():
    runtime = FakeRuntime()
    model = FakeStrategicModel()
    router = RuntimeAutonomousBuildExecutor(
        runtime=runtime,
        strategic_model=model,
        repository_context="repo context",
    )
    return router, runtime, model


def test_work_type_enum_covers_autonomous_build_work():
    assert {item.value for item in AutonomousWorkType} == {
        "research",
        "design",
        "implementation",
        "testing",
        "integration",
        "verification",
        "browser",
        "computer",
        "artifact",
    }


def test_implementation_routes_only_to_improvement_pipeline():
    router, runtime, model = executor()
    result = router.execute("mission-1", objective("implementation"))

    assert result.status == "promoted"
    assert result.metadata["verified"] is True
    assert runtime.improve_calls
    assert runtime.improve_calls[0][1]["evidence_policy"] == ("tests",)
    assert not runtime.research.calls
    assert not model.calls


def test_integration_routes_through_strategic_capabilities():
    runtime = FakeRuntime()

    class IntegrationModel(FakeStrategicModel):
        def decompose(self, **kwargs):
            self.calls.append(kwargs)
            return (
                MissionObjective(
                    objective_id="research-step",
                    objective="Inspect the current integration state",
                    work_type="research",
                    acceptance_criteria=("research evidence exists",),
                ),
            )

    model = IntegrationModel()
    router = RuntimeAutonomousBuildExecutor(
        runtime=runtime,
        strategic_model=model,
        repository_context="repo context",
    )
    result = router.execute("mission-1", objective("integration"))

    assert result.status == "completed"
    assert result.metadata["verified"] is True
    assert model.calls
    assert runtime.research.calls
    assert not runtime.improve_calls


def test_integration_propagates_structured_missing_contract_outcomes():
    runtime = FakeRuntime()

    class ContractAwareModel(FakeStrategicModel):
        def decompose(self, **kwargs):
            self.calls.append(kwargs)
            return (
                MissionObjective(
                    objective_id="verify-step",
                    objective="Produce behavioral evidence for the integration objective",
                    work_type="verification",
                    acceptance_criteria=("verified evidence exists",),
                ),
            )

    model = ContractAwareModel()
    router = RuntimeAutonomousBuildExecutor(
        runtime=runtime,
        strategic_model=model,
        repository_context="repo context",
    )
    routed = objective("integration")
    routed = MissionObjective(
        **{**routed.__dict__, "metadata": {
            **dict(routed.metadata),
            "mission_required_work_types": ("testing", "integration", "verification"),
            "mission_missing_work_types": ("testing", "verification"),
            "mission_covered_work_types": ("integration",),
        }}
    )

    result = router.execute("mission-1", routed)

    assert result.status == "completed"
    prompt = model.calls[0]["goal"]
    assert "Required outcome classes" in prompt
    assert "Missing outcome classes: ('testing', 'verification')" in prompt
    assert "MUST contribute verified evidence" in prompt
    assert "verification" in result.metadata["routed_work_types"]


def test_integration_rejects_successful_route_that_misses_contract_gap():
    runtime = FakeRuntime()

    class WrongOutcomeModel(FakeStrategicModel):
        def decompose(self, **kwargs):
            self.calls.append(kwargs)
            return (objective("research"),)

    model = WrongOutcomeModel()
    router = RuntimeAutonomousBuildExecutor(
        runtime=runtime,
        strategic_model=model,
        repository_context="repo context",
    )
    routed = MissionObjective(
        **{**objective("integration").__dict__, "metadata": {
            "mission_required_work_types": ("testing", "verification"),
            "mission_missing_work_types": ("testing", "verification"),
            "mission_covered_work_types": (),
        }}
    )

    result = router.execute("mission-1", routed)

    assert result.status == "rejected"
    assert result.metadata["mission_contract_gap"] is True
    assert result.metadata["routed_work_types"] == ["research"]
    assert "missing mission outcome" in result.error


def test_integration_recovers_from_failed_route_with_model_feedback():
    runtime = FakeRuntime()

    class RecoveringRuntime(FakeRuntime):
        def improve(self, objective, **kwargs):
            self.improve_calls.append((objective, kwargs))
            return SimpleNamespace(
                status="failed",
                run_id="run-failed",
                candidate_id="candidate-failed",
                promoted_plan_revision_id=None,
                candidate_tests_passed=False,
                decision=None,
                error="candidate test execution failed",
                metadata={"test_result": {"stderr": "external prerequisite required"}},
            )

    runtime = RecoveringRuntime()

    class RecoveringModel(FakeStrategicModel):
        def decompose(self, **kwargs):
            self.calls.append(kwargs)
            if len(self.calls) == 1:
                return (objective("implementation"),)
            assert kwargs["previous_results"]
            return (objective("research"),)

    model = RecoveringModel()
    router = RuntimeAutonomousBuildExecutor(
        runtime=runtime,
        strategic_model=model,
        repository_context="repo context",
    )
    result = router.execute("mission-1", objective("integration"))

    assert result.status == "completed"
    assert result.metadata["verified"] is True
    assert len(model.calls) == 2
    # The integration boundary now refuses source mutation until an observed
    # non-mutating route has been selected, so the first unsafe proposal never
    # reaches the code-improvement runtime.
    assert len(runtime.improve_calls) == 0
    assert runtime.research.calls
    assert "may not mutate local source/config" in str(model.calls[1]["previous_results"][0].error)


def test_research_does_not_enter_improvement_pipeline():
    router, runtime, _ = executor()
    result = router.execute("mission-1", objective("research"))

    assert result.status == "completed"
    assert result.metadata["verified"] is True
    assert runtime.research.calls
    assert not runtime.improve_calls


def test_design_does_not_enter_improvement_pipeline():
    router, runtime, model = executor()
    result = router.execute("mission-1", objective("design"))

    assert result.status == "completed"
    assert result.metadata["verified"] is True
    assert runtime.planning.calls
    assert model.calls
    assert not runtime.improve_calls


def test_testing_does_not_enter_improvement_pipeline():
    router, runtime, _ = executor()
    result = router.execute("mission-1", objective("testing"))

    assert result.status == "completed"
    assert result.metadata["verified"] is True
    assert runtime.benchmark_provider.calls
    assert not runtime.improve_calls


def test_verification_requires_verified_dependency_evidence():
    router, runtime, _ = executor()
    dependency = objective("implementation")
    dependency_event = SimpleNamespace(
        type="ObjectiveCompleted",
        payload={
            "mission_id": "mission-1",
            "objective_id": dependency.objective_id,
            "metadata": {
                "verified": True,
                "evidence": ["implementation verified"],
            },
        },
    )
    runtime.events = FakeEvents([dependency_event])

    verification = MissionObjective(
        objective_id="verification-1",
        objective="Verify implementation",
        work_type="verification",
        dependencies=(dependency.objective_id,),
        acceptance_criteria=("all dependencies are verified",),
        metadata={"autonomous_build": True},
    )

    result = router.execute("mission-1", verification)

    assert result.status == "completed"
    assert result.metadata["verified"] is True
    assert "verified_dependency=implementation-1" in result.metadata["evidence"]
    assert not runtime.improve_calls


def test_verification_rejects_unverified_dependency():
    router, runtime, _ = executor()
    dependency = objective("research")
    runtime.events = FakeEvents(
        [
            SimpleNamespace(
                type="ObjectiveCompleted",
                payload={
                    "mission_id": "mission-1",
                    "objective_id": dependency.objective_id,
                    "metadata": {"verified": False},
                },
            )
        ]
    )
    verification = MissionObjective(
        objective_id="verification-1",
        objective="Verify research",
        work_type="verification",
        dependencies=(dependency.objective_id,),
        acceptance_criteria=("dependency is verified",),
        metadata={"autonomous_build": True},
    )

    result = router.execute("mission-1", verification)

    assert result.status == "rejected"
    assert result.metadata["verified"] is False


def test_read_only_integration_cannot_route_to_mutating_capabilities():
    runtime = FakeRuntime()
    model = FakeStrategicModel()
    router = RuntimeAutonomousBuildExecutor(
        runtime=runtime,
        strategic_model=model,
        repository_context="repo context",
    )
    read_only_objective = MissionObjective(
        objective_id="audit-1",
        objective="Audit the repository without modifying it",
        work_type="integration",
        metadata={"mission_mutation_policy": "read_only"},
    )

    result = router.execute("mission-1", read_only_objective)

    assert result.status in {"failed", "rejected"}
    assert not runtime.improve_calls
    assert not runtime.research.calls
