from datetime import datetime, timedelta, timezone
from ocean.power_schedule import WakeScheduler

def test_wake_scheduler_fails_closed_off_mac(monkeypatch):
    monkeypatch.setattr('ocean.power_schedule.platform.system',lambda:'Linux')
    assert WakeScheduler().schedule(datetime.now(timezone.utc)+timedelta(hours=1)) is False
    assert WakeScheduler().verify() is False
