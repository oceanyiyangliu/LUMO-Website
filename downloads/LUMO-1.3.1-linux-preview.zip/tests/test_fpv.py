from ocean.domain.event import Event
from ocean.fpv import FPVProjector

class Worlds:
    def list(self): return []

def test_fpv_projects_mission_and_agent_without_hidden_reasoning():
    events=type("Events",(),{"history":lambda self: [
        Event(type="MissionStarted",aggregate_type="mission",aggregate_id="m1",payload={"mission_id":"m1","goal":"build"}),
        Event(type="AgentStarted",aggregate_type="mission",aggregate_id="m1",payload={"mission_id":"m1","agent_id":"a1","objective_id":"o1","status":"running","activity":"coding"}),
    ]})()
    snapshot=FPVProjector(events,Worlds()).snapshot()
    assert {n["type"] for n in snapshot["nodes"]} == {"mission","agent"}
    assert any(e["kind"] == "contains" for e in snapshot["edges"])
