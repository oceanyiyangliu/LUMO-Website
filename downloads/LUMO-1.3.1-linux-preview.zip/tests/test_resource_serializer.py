from ocean.domain.resource import ResourceRequirement
from persistence.serializers.resource import ResourceRequirementSerializer


def test_resource_requirement_serializer_round_trip():
    requirement = ResourceRequirement(
        kind="cpu",
        amount=2.5,
    )

    serializer = ResourceRequirementSerializer()

    serialized = serializer.serialize(requirement)
    restored = serializer.deserialize(serialized)

    assert restored == requirement


def test_resource_requirement_serializer_preserves_default_amount():
    requirement = ResourceRequirement(
        kind="network",
    )

    serializer = ResourceRequirementSerializer()

    data = serializer.serialize(requirement)

    assert data["amount"] == 1.0

    restored = serializer.deserialize(data)

    assert restored.amount == 1.0


def test_resource_requirement_serializer_preserves_kind():
    requirement = ResourceRequirement(
        kind="model_tokens",
        amount=5000,
    )

    serializer = ResourceRequirementSerializer()

    data = serializer.serialize(requirement)

    assert data["kind"] == "model_tokens"
    assert data["amount"] == 5000

    restored = serializer.deserialize(data)

    assert restored.kind == "model_tokens"
    assert restored.amount == 5000.0
