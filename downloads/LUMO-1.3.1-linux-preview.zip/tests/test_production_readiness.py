from ocean.production_readiness import evaluate_launch_gates, format_launch_report


def test_launch_report_is_fail_closed():
    report = evaluate_launch_gates({"doctor": True, "regression": True})
    assert not report.ready
    assert "security" in report.blocking
    assert "production_auth" in report.blocking
    assert "LUMO LAUNCH: BLOCKED" in format_launch_report(report)


def test_launch_report_ready_only_when_every_gate_is_true():
    gates = {
        "doctor": True, "regression": True, "security": True,
        "authorization_isolation": True, "durability_recovery": True,
        "verification": True, "kill_pause_takeover": True,
        "clean_install": True, "backup_restore": True,
        "update_rollback": True, "production_auth": True,
        "production_tenant_store": True, "production_secrets": True,
        "https_gateway": True, "monitoring_alerts": True,
        "email_delivery": True,
    }
    report = evaluate_launch_gates(gates)
    assert report.ready
    assert report.blocking == ()
