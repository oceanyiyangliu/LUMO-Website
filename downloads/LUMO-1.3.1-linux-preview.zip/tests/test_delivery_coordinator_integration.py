"""Phase 3 integration tests: DeliveryCoordinator crash recovery.

Proves that durable events survive process crashes and are delivered
by the DeliveryCoordinator on restart via the same polling mechanism
used for ongoing delivery.
"""

from __future__ import annotations

import os
import sqlite3
import tempfile
import threading
import time
from typing import List

import pytest

from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from eventing.delivery_coordinator import DeliveryCoordinator
from eventing.sqlite_store import SQLiteEventStore


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def db_path():
    fd, path = tempfile.mkstemp(suffix=".sqlite3")
    os.close(fd)
    yield path
    os.unlink(path)


@pytest.fixture
def event_bus(db_path):
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 30000")
    conn.execute("PRAGMA synchronous = NORMAL")
    return EventBus(store=SQLiteEventStore(conn))


# ---------------------------------------------------------------------------
# 1. TaskAssignmentFailed persists and DC delivers after "crash"
# ---------------------------------------------------------------------------


def test_task_assignment_failed_delivered_after_crash(db_path, event_bus):
    """A TaskAssignmentFailed event persisted by EventBus is delivered
    by the DeliveryCoordinator after a simulated process crash."""
    delivered: List[Event] = []

    # Phase 1: "normal operation" — publish event, but no handler runs
    # (simulating crash before dispatch)
    event = Event(
        type="TaskAssignmentFailed",
        payload={
            "assignment_id": "asgn-001",
            "task_id": "task-001",
            "mission_id": "mission-001",
            "agent_id": "agent-001",
            "error": "timeout",
        },
        aggregate_type="assignment",
        aggregate_id="asgn-001",
        causation_id="asgn-001",
        correlation_id="mission-001",
        source="orchestrator",
    )
    event_bus.publish(event)

    # Phase 2: "process crash" — no DeliveryCoordinator was running
    # Phase 3: "restart" — create new DC and register handler
    dc = DeliveryCoordinator(db_path)
    dc.subscribe(
        "recovery_engine",
        delivered.append,
        event_types=frozenset({"TaskAssignmentFailed"}),
    )

    dc.poll_once()

    assert len(delivered) == 1
    assert delivered[0].type == "TaskAssignmentFailed"
    assert delivered[0].payload["assignment_id"] == "asgn-001"
    assert dc.cursor("recovery_engine") == 1


# ---------------------------------------------------------------------------
# 2. Startup catch-up repairs missed delivery
# ---------------------------------------------------------------------------


def test_startup_catchup_repairs_missed_delivery(db_path, event_bus):
    """Multiple events published before DC starts are all delivered
    on the first poll cycle (startup catch-up)."""
    delivered: List[Event] = []

    # Publish 5 events (simulating a busy period before DC was started)
    for i in range(5):
        event_bus.publish(
            Event(
                type="TaskAssignmentFailed",
                payload={"assignment_id": f"asgn-{i:03d}", "attempt": i},
                aggregate_type="assignment",
                aggregate_id=f"asgn-{i:03d}",
            )
        )

    # DC starts fresh — should catch up on all 5
    dc = DeliveryCoordinator(db_path)
    dc.subscribe("recovery", delivered.append, event_types=frozenset({"TaskAssignmentFailed"}))

    dc.poll_once()

    assert len(delivered) == 5
    assert dc.cursor("recovery") == 5


# ---------------------------------------------------------------------------
# 3. Durable subscriber NOT invoked by both EventBus and DC
# ---------------------------------------------------------------------------


def test_durable_subscriber_not_invoked_by_both_paths(db_path, event_bus):
    """When a durable subscriber is registered with DC (not EventBus),
    it is only invoked by DC polling, not by EventBus.publish()."""
    dc_delivered: List[Event] = []
    bus_delivered: List[Event] = []

    # Register ONLY with DC
    dc = DeliveryCoordinator(db_path)
    dc.subscribe("recovery", dc_delivered.append, event_types=frozenset({"TaskAssignmentFailed"}))

    # Register a different handler with EventBus (ephemeral)
    event_bus.subscribe("TaskAssignmentFailed", bus_delivered.append)

    event = Event(
        type="TaskAssignmentFailed",
        payload={"assignment_id": "asgn-001"},
        aggregate_type="assignment",
        aggregate_id="asgn-001",
    )
    event_bus.publish(event)

    # EventBus handler was called synchronously
    assert len(bus_delivered) == 1

    # DC handler was NOT called (no polling yet)
    assert len(dc_delivered) == 0

    # DC polls and delivers
    dc.poll_once()
    assert len(dc_delivered) == 1


# ---------------------------------------------------------------------------
# 4. Cursor advancement and at-least-once semantics
# ---------------------------------------------------------------------------


def test_cursor_advances_only_after_successful_delivery(db_path, event_bus):
    """Cursor advances to the last successfully delivered event."""
    delivered: List[Event] = []

    for i in range(3):
        event_bus.publish(
            Event(
                type="TaskAssignmentFailed",
                payload={"assignment_id": f"asgn-{i:03d}"},
                aggregate_type="assignment",
                aggregate_id=f"asgn-{i:03d}",
            )
        )

    dc = DeliveryCoordinator(db_path)
    dc.subscribe("recovery", delivered.append, event_types=frozenset({"TaskAssignmentFailed"}))

    dc.poll_once()

    assert len(delivered) == 3
    assert dc.cursor("recovery") == 3


def test_at_least_once_redelivery_after_cursor_failure(db_path, event_bus):
    """If cursor write fails, event is re-delivered on next poll."""
    delivered: List[Event] = []

    event_bus.publish(
        Event(
            type="TaskAssignmentFailed",
            payload={"assignment_id": "asgn-001"},
            aggregate_type="assignment",
            aggregate_id="asgn-001",
        )
    )

    dc = DeliveryCoordinator(db_path)
    dc.subscribe("recovery", delivered.append, event_types=frozenset({"TaskAssignmentFailed"}))

    # Patch cursor write to fail on first attempt
    original_save = dc._save_cursor
    call_count = 0

    def failing_save(subscriber_id: str, sequence: int) -> bool:
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return False
        return original_save(subscriber_id, sequence)

    dc._save_cursor = failing_save

    # First poll: handler runs, cursor write fails
    dc.poll_once()
    assert len(delivered) == 1
    assert dc.cursor("recovery") == 0

    # Second poll: event re-delivered (at-least-once)
    dc.poll_once()
    assert len(delivered) == 2
    assert dc.cursor("recovery") == 1


# ---------------------------------------------------------------------------
# 5. RecoveryEngine subscribe parameter
# ---------------------------------------------------------------------------


def test_recovery_engine_subscribe_false_does_not_register_with_bus():
    """RecoveryEngine with subscribe=False does not register with EventBus."""
    from ocean.domain.assignment import Assignment
    from ocean.domain.enums import AssignmentStatus, OrchestrationMode
    from ocean.domain.task import Task
    from ocean.orchestration.orchestrator import Orchestrator, OrchestrationPorts
    from ocean.recovery.engine import RecoveryEngine
    from persistence.in_memory import InMemoryRepository

    events = EventBus()
    assignments = InMemoryRepository()
    tasks = InMemoryRepository()
    agents = InMemoryRepository()
    agent_runtime = type("Fake", (), {"submit": lambda *a, **k: None})()

    ports = OrchestrationPorts(
        events=events,
        assignments=assignments,
        tasks=tasks,
        missions=InMemoryRepository(),
        agents=agents,
        agent_runtime=agent_runtime,
    )
    orchestrator = Orchestrator(ports, subscribe=False)

    # RecoveryEngine with subscribe=False
    engine = RecoveryEngine(
        event_bus=events,
        assignments=assignments,
        tasks=tasks,
        orchestrator=orchestrator,
        subscribe=False,
    )

    # Publish TaskAssignmentFailed — handler should NOT be called
    handler_called = []
    # No handler registered, so no call

    events.publish(
        Event(
            type="TaskAssignmentFailed",
            payload={"assignment_id": "test"},
            aggregate_type="assignment",
            aggregate_id="test",
        )
    )

    # If handler was registered, it would have been called and likely raised
    # (because assignment doesn't exist). Since no error, handler was not registered.
    # This is sufficient proof that subscribe=False works.


def test_recovery_engine_subscribe_true_registers_with_bus():
    """RecoveryEngine with subscribe=True (default) registers with EventBus."""
    from ocean.domain.assignment import Assignment
    from ocean.domain.enums import AssignmentStatus, OrchestrationMode
    from ocean.domain.task import Task
    from ocean.orchestration.orchestrator import Orchestrator, OrchestrationPorts
    from ocean.recovery.engine import RecoveryEngine
    from persistence.in_memory import InMemoryRepository

    events = EventBus()
    assignments = InMemoryRepository()
    tasks = InMemoryRepository()
    agents = InMemoryRepository()
    agent_runtime = type("Fake", (), {"submit": lambda *a, **k: None})()

    ports = OrchestrationPorts(
        events=events,
        assignments=assignments,
        tasks=tasks,
        missions=InMemoryRepository(),
        agents=agents,
        agent_runtime=agent_runtime,
    )
    orchestrator = Orchestrator(ports, subscribe=False)

    engine = RecoveryEngine(
        event_bus=events,
        assignments=assignments,
        tasks=tasks,
        orchestrator=orchestrator,
    )

    # The handler is registered. Publishing TaskAssignmentFailed with
    # a missing assignment will cause the handler to return IGNORE,
    # which is a normal path (no exception).
    events.publish(
        Event(
            type="TaskAssignmentFailed",
            payload={"assignment_id": "nonexistent"},
            aggregate_type="assignment",
            aggregate_id="nonexistent",
        )
    )


# ---------------------------------------------------------------------------
# 6. Multiple event types with type filtering
# ---------------------------------------------------------------------------


def test_type_filtering_delivers_only_matching_events(db_path, event_bus):
    """DC with event_types filter only delivers matching events."""
    delivered: List[Event] = []

    # Publish mixed event types
    event_bus.publish(Event(type="TaskAssignmentFailed", payload={"a": 1}, aggregate_type="assignment", aggregate_id="a1"))
    event_bus.publish(Event(type="TaskAssignmentCompleted", payload={"a": 2}, aggregate_type="assignment", aggregate_id="a2"))
    event_bus.publish(Event(type="TaskAssignmentFailed", payload={"a": 3}, aggregate_type="assignment", aggregate_id="a3"))

    dc = DeliveryCoordinator(db_path)
    dc.subscribe("recovery", delivered.append, event_types=frozenset({"TaskAssignmentFailed"}))

    dc.poll_once()

    assert len(delivered) == 2
    assert all(e.type == "TaskAssignmentFailed" for e in delivered)
    assert dc.cursor("recovery") == 3  # cursor advances past all events


# ---------------------------------------------------------------------------
# 7. Wildcard subscriber receives all events
# ---------------------------------------------------------------------------


def test_wildcard_subscriber_receives_all_event_types(db_path, event_bus):
    """DC with event_types=None receives all events."""
    delivered: List[Event] = []

    event_bus.publish(Event(type="TaskAssignmentFailed", payload={}, aggregate_type="assignment", aggregate_id="a"))
    event_bus.publish(Event(type="MissionCompleted", payload={}, aggregate_type="mission", aggregate_id="m"))
    event_bus.publish(Event(type="TaskAssignmentCompleted", payload={}, aggregate_type="assignment", aggregate_id="b"))

    dc = DeliveryCoordinator(db_path)
    dc.subscribe("observer", delivered.append, event_types=None)

    dc.poll_once()

    assert len(delivered) == 3
    assert dc.cursor("observer") == 3


# ---------------------------------------------------------------------------
# 8. Concurrent publish and poll
# ---------------------------------------------------------------------------


def test_concurrent_publish_and_poll(db_path, event_bus):
    """Events published during polling are picked up on the next cycle."""
    delivered: List[Event] = []

    dc = DeliveryCoordinator(db_path)
    dc.subscribe("recovery", delivered.append, event_types=frozenset({"TaskAssignmentFailed"}))

    # Publish some events
    for i in range(3):
        event_bus.publish(
            Event(
                type="TaskAssignmentFailed",
                payload={"i": i},
                aggregate_type="assignment",
                aggregate_id=f"a{i}",
            )
        )

    # Poll delivers the first batch
    dc.poll_once()
    assert len(delivered) == 3

    # More events published after poll
    for i in range(3, 6):
        event_bus.publish(
            Event(
                type="TaskAssignmentFailed",
                payload={"i": i},
                aggregate_type="assignment",
                aggregate_id=f"a{i}",
            )
        )

    # Next poll delivers the second batch
    dc.poll_once()
    assert len(delivered) == 6
    assert dc.cursor("recovery") == 6


# ---------------------------------------------------------------------------
# 9. Restart preserves cursor and resumes correctly
# ---------------------------------------------------------------------------


def test_restart_preserves_cursor_and_resumes(db_path, event_bus):
    """After restart, DC resumes from the persisted cursor."""
    # First run: deliver some events
    delivered1: List[Event] = []
    dc1 = DeliveryCoordinator(db_path)
    dc1.subscribe("recovery", delivered1.append, event_types=frozenset({"TaskAssignmentFailed"}))

    for i in range(3):
        event_bus.publish(
            Event(
                type="TaskAssignmentFailed",
                payload={"i": i},
                aggregate_type="assignment",
                aggregate_id=f"a{i}",
            )
        )

    dc1.poll_once()
    assert len(delivered1) == 3
    assert dc1.cursor("recovery") == 3

    # Second run: new DC instance (simulating restart)
    delivered2: List[Event] = []
    dc2 = DeliveryCoordinator(db_path)
    dc2.subscribe("recovery", delivered2.append, event_types=frozenset({"TaskAssignmentFailed"}))

    # No new events — no delivery
    dc2.poll_once()
    assert len(delivered2) == 0
    assert dc2.cursor("recovery") == 3

    # New events — delivered from cursor 3
    event_bus.publish(
        Event(
            type="TaskAssignmentFailed",
            payload={"i": 3},
            aggregate_type="assignment",
            aggregate_id="a3",
        )
    )

    dc2.poll_once()
    assert len(delivered2) == 1
    assert delivered2[0].payload["i"] == 3
    assert dc2.cursor("recovery") == 4


# ---------------------------------------------------------------------------
# 10. Idempotent handler with duplicate delivery
# ---------------------------------------------------------------------------


def test_idempotent_handler_survives_duplicate_delivery(db_path, event_bus):
    """An idempotent handler correctly processes events even when
    delivered multiple times (at-least-once semantics)."""
    processed_ids: set[str] = set()
    delivery_count: List[str] = []

    def idempotent_handler(event: Event) -> None:
        aid = event.payload["assignment_id"]
        delivery_count.append(aid)
        processed_ids.add(aid)  # idempotent: set add is idempotent

    event_bus.publish(
        Event(
            type="TaskAssignmentFailed",
            payload={"assignment_id": "asgn-001"},
            aggregate_type="assignment",
            aggregate_id="asgn-001",
        )
    )

    dc = DeliveryCoordinator(db_path)
    dc.subscribe("recovery", idempotent_handler, event_types=frozenset({"TaskAssignmentFailed"}))

    # Patch cursor write to FAIL before any polling
    # This simulates: handler succeeds but cursor write crashes
    dc._save_cursor = lambda sid, seq: False

    # First delivery attempt: handler runs, cursor write fails
    dc.poll_once()
    assert len(delivery_count) == 1
    assert dc.cursor("recovery") == 0  # cursor not advanced

    # Second delivery attempt: event re-delivered (at-least-once)
    dc.poll_once()
    assert len(delivery_count) == 2
    assert processed_ids == {"asgn-001"}  # idempotent


# ---------------------------------------------------------------------------
# 11. Non-matching events do not advance cursor past them
# ---------------------------------------------------------------------------


def test_non_matching_events_skipped_cursor_correct(db_path, event_bus):
    """Events that don't match the subscriber's filter are skipped,
    and the cursor advances to the last matching event's sequence."""
    delivered: List[Event] = []

    # Publish: match, skip, match, skip, match
    event_bus.publish(Event(type="TaskAssignmentFailed", payload={"n": 1}, aggregate_type="assignment", aggregate_id="a1"))
    event_bus.publish(Event(type="MissionCompleted", payload={"n": 2}, aggregate_type="mission", aggregate_id="m1"))
    event_bus.publish(Event(type="TaskAssignmentFailed", payload={"n": 3}, aggregate_type="assignment", aggregate_id="a2"))
    event_bus.publish(Event(type="TaskAssignmentCompleted", payload={"n": 4}, aggregate_type="assignment", aggregate_id="a3"))
    event_bus.publish(Event(type="TaskAssignmentFailed", payload={"n": 5}, aggregate_type="assignment", aggregate_id="a4"))

    dc = DeliveryCoordinator(db_path)
    dc.subscribe("recovery", delivered.append, event_types=frozenset({"TaskAssignmentFailed"}))

    dc.poll_once()

    assert len(delivered) == 3
    assert [e.payload["n"] for e in delivered] == [1, 3, 5]
    assert dc.cursor("recovery") == 5
