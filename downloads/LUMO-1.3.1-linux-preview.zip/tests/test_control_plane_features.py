from datetime import datetime, timedelta, timezone

import pytest

from ocean.control_plane_features import (
    MissionCheckpoint,
    MissionFeatureStore,
    MissionMode,
    MissionPolicy,
    MissionTemplate,
    deterministic_simulation,
    render_template,
)


def test_policy_validates_deadline_and_reports_expiry():
    now = datetime.now(timezone.utc)
    policy = MissionPolicy(deadline=now + timedelta(seconds=10), mode=MissionMode.DRY_RUN)
    assert policy.deadline_status(now) == "active"
    assert policy.mode is MissionMode.DRY_RUN
    assert policy.deadline_status(now + timedelta(seconds=11)) == "expired"


def test_checkpoint_is_integrity_bound(tmp_path):
    checkpoint = MissionCheckpoint.create("m1", 3, {"status": "active", "done": ["a"]})
    assert checkpoint.verify()
    store = MissionFeatureStore(tmp_path / "features.sqlite3")
    assert store.save_checkpoint(checkpoint) == checkpoint
    assert store.latest_checkpoint("m1") == checkpoint

    tampered = MissionCheckpoint(checkpoint.mission_id, checkpoint.sequence, checkpoint.state_hash, {"status": "tampered"}, checkpoint.created_at)
    with pytest.raises(ValueError, match="integrity"):
        store.save_checkpoint(tampered)


def test_templates_are_durable_and_missing_variables_fail(tmp_path):
    store = MissionFeatureStore(tmp_path / "features.sqlite3")
    template = MissionTemplate("research", "Research", "Research {topic} for {audience}")
    store.register_template(template)
    loaded = store.template("research")
    assert loaded == template
    assert render_template(loaded, {"topic": "AI", "audience": "students"}) == "Research AI for students"
    with pytest.raises(ValueError, match="missing template variable"):
        render_template(loaded, {"topic": "AI"})


def test_branch_and_idempotency_are_durable(tmp_path):
    store = MissionFeatureStore(tmp_path / "features.sqlite3")
    cp = MissionCheckpoint.create("m1", 1, {"x": 1})
    branch = store.branch("m1", cp)
    assert branch.source_mission_id == "m1"
    assert store.claim_idempotency("mission", "k1", "m1") == (True, "m1")
    assert store.claim_idempotency("mission", "k1", "m2") == (False, "m1")


def test_simulation_has_no_execution_side_effects():
    a = deterministic_simulation("do work", steps=3)
    b = deterministic_simulation("do work", steps=3)
    assert a == b
    assert a["would_execute"] is False
    assert a["effects"] == []


def test_policy_rejects_non_finite_budget_values():
    import math
    for value in (math.nan, math.inf, -math.inf):
        with pytest.raises(ValueError, match="budget"):
            MissionPolicy(budget={"tokens": value})


def test_policy_rejects_non_finite_sla():
    import math
    for value in (math.nan, math.inf, -math.inf):
        with pytest.raises(ValueError, match="sla_seconds"):
            MissionPolicy(sla_seconds=value)
