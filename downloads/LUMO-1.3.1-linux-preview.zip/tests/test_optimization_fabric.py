import threading
from ocean.optimization_fabric import PriceBook,PriceBand,BudgetHierarchy,CacheFabric,CachePolicy,ObservationPlanner,LatencyPolicy,ConcurrencyPolicy,IncrementalIndex,TestImpactAnalyzer,BenchmarkRegistry,BenchmarkSample,OptimizationGuard,OptimizationFabric

def test_price_history_and_estimate():
 p=PriceBook();p.add(PriceBand('p','m',1,2,cached_input_per_1k=.2)); assert p.estimate('p','m',1000,500,cached_input_tokens=500)==1.6

def test_hierarchical_budget_is_atomic():
 b=BudgetHierarchy({'account':{'money':5},'mission':{'money':4}}); r=b.reserve(('account','mission'),{'money':3},'x'); b.commit(r,{'money':2}); assert b.snapshots()['account']['consumed']['money']==2

def test_hierarchical_budget_rolls_back_on_child_failure():
 b=BudgetHierarchy({'account':{'money':5},'mission':{'money':1}})
 try:b.reserve(('account','mission'),{'money':2},'x')
 except RuntimeError:pass
 assert b.snapshots()['account']['reserved'].get('money',0)==0

def test_cache_consequential_requires_fresh_state():
 c=CacheFabric();c.put('k','v','s');assert c.get('k','s',CachePolicy())=='v';assert c.get('k','s',CachePolicy(consequential=True)) is None

def test_observation_prefers_structured_and_sensitive_avoids_vision():
 p=ObservationPlanner().choose(['vision','ocr','accessibility','filesystem'],sensitive=True);assert p.mode=='filesystem' and 'vision' not in p.sources

def test_latency_and_concurrency_policies():
 assert LatencyPolicy().decide(remaining_ms=10,predicted_ms=50).objective=='latency'; assert ConcurrencyPolicy().choose(ready=8,cpu_pressure=1.0,max_workers=8)==2

def test_incremental_index_and_impact():
 i=IncrementalIndex();fp=i.fingerprint('a',b'x');assert i.changed(fp);i.update(fp);assert not i.changed(fp)
 t=TestImpactAnalyzer({'test_a':['a'],'test_b':['b']});assert t.affected(['a'],['test_a','test_b'])==('test_a',)

def test_benchmark_regression():
 b=BenchmarkRegistry();b.record(BenchmarkSample('x',10,1,True));b.record(BenchmarkSample('x',20,1,True));assert b.summary('x')['p95_ms']==20;assert b.regression('x',20,1)

def test_guard_rejects_safety_regression():
 try:OptimizationGuard().validate(verified=False,authorized=True,isolated=True,auditable=True,killable=True)
 except RuntimeError:pass
 else:raise AssertionError

def test_fabric_postflight_measures_actual_vs_estimate():
 f=OptimizationFabric();r=f.postflight('m',1,1.2,30,True);assert abs(r['variance']-.2)<1e-12


def test_get_or_compute_caches_deterministic_result():
    from ocean.optimization_fabric import CacheFabric, CachePolicy
    c=CacheFabric(); calls=[]
    def fn(): calls.append(1); return {"ok":True}
    assert c.get_or_compute("k","state",CachePolicy(ttl_seconds=60),fn)=={"ok":True}
    assert c.get_or_compute("k","state",CachePolicy(ttl_seconds=60),fn)=={"ok":True}
    assert len(calls)==1

def test_incremental_atomic_update_and_remove():
    from ocean.optimization_fabric import IncrementalIndex
    c=IncrementalIndex(); fp=c.fingerprint('a',b'1')
    assert c.update_if_changed(fp); assert not c.update_if_changed(fp)
    assert c.remove('a'); assert not c.remove('a')

def test_benchmark_pareto_frontier():
    from ocean.optimization_fabric import BenchmarkRegistry, BenchmarkSample
    b=BenchmarkRegistry(); b.record(BenchmarkSample('cheap',100,1,True)); b.record(BenchmarkSample('fast',50,2,True)); b.record(BenchmarkSample('bad',200,3,False))
    assert set(b.pareto_frontier()) == {'cheap','fast'}

def test_budget_postflight_variance_respects_other_reservations():
    from ocean.optimization import BudgetGuard
    b=BudgetGuard({'money':10}); b.reserve('m1',{'money':4},'r1'); b.reserve('m2',{'money':4},'r2')
    try: b.commit('r1',{'money':7})
    except RuntimeError: pass
    else: raise AssertionError('under-reservation consumed capacity held by another reservation')

def test_budget_postflight_variance_can_use_unreserved_headroom():
    from ocean.optimization import BudgetGuard
    b=BudgetGuard({'money':10}); b.reserve('m1',{'money':4},'r1'); assert b.commit('r1',{'money':6}) == {'money':6}


def test_budget_controller_prefers_free_cache_or_deterministic_paths():
    from ocean.optimization_fabric import BudgetController, ExecutionOption
    c = BudgetController()
    choice = c.choose((
        ExecutionOption("paid", cost=0.01, latency_ms=5),
        ExecutionOption("cache", cost=0.0, latency_ms=1, cached=True),
        ExecutionOption("slow", cost=0.0, latency_ms=20),
    ), remaining_cost=1)
    assert choice.option.name == "cache"


def test_budget_controller_hard_constraints_never_buy_their_way_out():
    from ocean.optimization_fabric import BudgetController, ExecutionOption
    c = BudgetController()
    try:
        c.choose((ExecutionOption("cheap", cost=0, latency_ms=100, reliability=1),),
                 remaining_cost=1, deadline_ms=10)
    except RuntimeError:
        pass
    else:
        raise AssertionError("budget routing ignored hard deadline")


def test_budget_reservation_is_idempotent():
    from ocean.optimization import BudgetGuard
    b = BudgetGuard({"money": 5})
    first = b.reserve("m", {"money": 2}, "same")
    second = b.reserve("m", {"money": 2}, "same")
    assert first == second
    assert b.remaining("money") == 3


def test_hierarchical_commit_validates_all_scopes_before_mutating():
    from ocean.optimization_fabric import BudgetHierarchy
    b = BudgetHierarchy({"account": {"money": 10}, "mission": {"money": 5}})
    reservations = b.reserve(("account", "mission"), {"money": 4}, "atomic")
    try:
        b.commit(reservations, {"money": 6})
    except RuntimeError:
        pass
    else:
        raise AssertionError("expected child budget rejection")
    assert b.snapshots()["account"]["consumed"].get("money", 0) == 0
    assert b.snapshots()["mission"]["consumed"].get("money", 0) == 0


def test_budget_controller_stops_bad_value_of_information():
    from ocean.optimization_fabric import BudgetController
    d = BudgetController().should_continue(expected_value=1, marginal_cost=2, success_probability=1, remaining_cost=5)
    assert not d.continue_execution and d.expected_net_value == -1


def test_budget_controller_accounts_for_success_probability_and_hard_budget():
    from ocean.optimization_fabric import BudgetController
    c = BudgetController()
    assert c.should_continue(expected_value=10, marginal_cost=2, success_probability=.5, remaining_cost=2, min_roi=2).continue_execution
    assert not c.should_continue(expected_value=10, marginal_cost=3, success_probability=1, remaining_cost=2).continue_execution
