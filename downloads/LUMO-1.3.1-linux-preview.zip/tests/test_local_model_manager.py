from ocean.resources.local_model_manager import InstalledLocalModel, LocalModelManager


def test_installed_model_size():
    item = InstalledLocalModel("qwen3:8b", 5 * 1024**3)
    assert item.size_gib == 5


def test_inventory_parses_ollama(monkeypatch):
    class Response:
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def read(self):
            return b'{"models":[{"name":"qwen3:8b","size":5368709120,"digest":"abc"}]}'
    monkeypatch.setattr("urllib.request.urlopen", lambda *args, **kwargs: Response())
    items = LocalModelManager().inventory()
    assert [x.name for x in items] == ["qwen3:8b"]
    assert items[0].digest == "abc"


def test_ensure_installed_fails_closed_without_download(monkeypatch):
    manager = LocalModelManager()
    monkeypatch.setattr(manager, "inventory", lambda: ())
    try:
        manager.ensure_installed("qwen3:4b")
    except RuntimeError as exc:
        assert "download is disabled" in str(exc)
    else:
        raise AssertionError("missing model must fail closed")

def test_standard_pack_is_defined():
    assert LocalModelManager.DEFAULT_PACK == ("qwen3:4b", "qwen3:8b", "qwen2.5vl:7b", "devstral:24b", "qwen3:30b-a3b")

