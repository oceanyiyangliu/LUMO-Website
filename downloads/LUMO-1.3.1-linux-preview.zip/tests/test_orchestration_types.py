import pytest

from ocean.domain.enums import OrchestrationMode
from ocean.orchestration.types import (
    AssignmentRequest,
    OrchestrationResult,
    ReconciliationResult,
    RecoveryDecision,
)


def test_assignment_request_defaults_are_valid():
    request = AssignmentRequest(
        task_id="task-1",
        agent_id="agent-1",
    )

    assert request.task_id == "task-1"
    assert request.agent_id == "agent-1"
    assert request.mode == OrchestrationMode.STANDARD
    assert request.priority == 0
    assert request.metadata == {}


@pytest.mark.parametrize(
    "kwargs",
    [
        {"task_id": "", "agent_id": "agent-1"},
        {"task_id": "task-1", "agent_id": ""},
        {"task_id": "task-1", "agent_id": "agent-1", "priority": -1},
        {
            "task_id": "task-1",
            "agent_id": "agent-1",
            "parent_assignment_id": "",
        },
    ],
)
def test_assignment_request_rejects_invalid_values(kwargs):
    with pytest.raises(ValueError):
        AssignmentRequest(**kwargs)


def test_assignment_request_supports_all_orchestration_fields():
    request = AssignmentRequest(
        task_id="task-1",
        agent_id="agent-1",
        mission_id="mission-1",
        mode=OrchestrationMode.PARALLEL,
        priority=7,
        parent_assignment_id="assignment-1",
        reason="specialist routing",
        metadata={"role": "research"},
    )

    assert request.mission_id == "mission-1"
    assert request.mode == OrchestrationMode.PARALLEL
    assert request.priority == 7
    assert request.parent_assignment_id == "assignment-1"
    assert request.reason == "specialist routing"
    assert request.metadata == {"role": "research"}


def test_orchestration_result():
    result = OrchestrationResult(
        success=True,
        assignment_id="assignment-1",
        execution_id="execution-1",
    )

    assert result.success is True
    assert result.assignment_id == "assignment-1"
    assert result.execution_id == "execution-1"


def test_reconciliation_result():
    result = ReconciliationResult(
        assignment_id="assignment-1",
        status="completed",
        task_status="running",
        execution_id="execution-1",
        success=True,
    )

    assert result.assignment_id == "assignment-1"
    assert result.status == "completed"
    assert result.task_status == "running"
    assert result.success is True


def test_recovery_decision():
    decision = RecoveryDecision(
        action="reassign",
        assignment_id="assignment-1",
        agent_id="agent-2",
        reason="previous agent failed",
    )

    assert decision.action == "reassign"
    assert decision.assignment_id == "assignment-1"
    assert decision.agent_id == "agent-2"
    assert decision.reason == "previous agent failed"
