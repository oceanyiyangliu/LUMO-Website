import pytest

from ocean.core.errors import InvalidStateTransition
from ocean.domain.enums import MissionStatus
from ocean.domain.mission import Mission


def test_mission_starts_planning():
    m = Mission(goal="prepare my competition application")
    assert m.status == MissionStatus.PLANNING


def test_mission_task_ids_are_deduplicated_and_ordered():
    m = Mission(goal="x")
    m.add_task("task_1")
    m.add_task("task_2")
    m.add_task("task_1")
    assert m.task_ids == ["task_1", "task_2"]


def test_mission_valid_lifecycle():
    m = Mission(goal="x")
    m.transition(MissionStatus.ACTIVE)
    m.transition(MissionStatus.COMPLETED)
    assert m.is_terminal()


def test_mission_failed_can_resume_to_active():
    m = Mission(goal="x")
    m.transition(MissionStatus.ACTIVE)
    m.transition(MissionStatus.FAILED)
    m.transition(MissionStatus.ACTIVE)
    assert m.status == MissionStatus.ACTIVE


def test_mission_cannot_skip_to_completed_from_planning():
    m = Mission(goal="x")
    with pytest.raises(InvalidStateTransition):
        m.transition(MissionStatus.COMPLETED)
