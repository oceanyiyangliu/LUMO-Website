import pytest
from ocean.resources.intelligence_governor import DeviceResources, LocalResourceGovernor, ResourceRequest


def sample():
    return DeviceResources(16*1024**3, 12*1024**3, 6*1024**3, 10, None, None)


def test_hard_ai_ram_budget_rejects_over_budget():
    g=LocalResourceGovernor(sampler=sample, max_concurrent_workers=4)
    ok=g.admit(ResourceRequest('a', 5*1024**3))
    assert ok.admitted
    denied=g.admit(ResourceRequest('b', 2*1024**3))
    assert not denied.admitted
    assert 'RAM budget' in denied.reason


def test_concurrency_limit_is_independent_of_ram():
    g=LocalResourceGovernor(sampler=sample, max_concurrent_workers=1)
    assert g.admit(ResourceRequest('a', 1*1024**3)).admitted
    assert not g.admit(ResourceRequest('b', 1*1024**3)).admitted
    g.release('a')
    assert g.admit(ResourceRequest('b', 1*1024**3)).admitted


def test_governor_fails_closed_when_sampling_fails():
    def broken(): raise RuntimeError('unknown')
    g=LocalResourceGovernor(sampler=broken)
    with pytest.raises(RuntimeError, match='unknown'):
        g.admit(ResourceRequest('a', 1))


def test_active_budget_tracks_current_available_ram():
    samples = iter((
        DeviceResources(32*1024**3, 24*1024**3, 20*1024**3, 10, None, None),
        DeviceResources(32*1024**3, 10*1024**3, 6*1024**3, 10, None, None),
    ))
    g = LocalResourceGovernor(sampler=lambda: next(samples), max_concurrent_workers=4)
    first = g.snapshot()
    second = g.snapshot()
    assert first.safe_ai_ram_bytes > second.safe_ai_ram_bytes
    assert second.safe_ai_ram_bytes == 6*1024**3
