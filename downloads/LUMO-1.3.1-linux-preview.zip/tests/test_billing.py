from ocean.billing import BillingStore, EntitlementEngine, PLANS


def test_free_entitlements_are_durable(tmp_path):
    store = BillingStore(tmp_path / "billing.sqlite3")
    engine = EntitlementEngine(store)
    snapshot = engine.snapshot("account_1")
    assert snapshot["plan"]["id"] == "free"
    assert snapshot["limits"]["missions"] == 25
    store.consume("account_1", "missions", 2)
    assert engine.snapshot("account_1")["usage"]["missions"] == 2
    store.close()


def test_plan_upgrade_changes_limits(tmp_path):
    store = BillingStore(tmp_path / "billing.sqlite3")
    engine = EntitlementEngine(store)
    store.set_subscription("account_1", plan_id="pro")
    assert engine.snapshot("account_1")["plan"]["id"] == "pro"
    assert engine.snapshot("account_1")["limits"]["computer_tasks"] == 100
    store.close()


def test_usage_limit_fails_closed(tmp_path):
    store = BillingStore(tmp_path / "billing.sqlite3")
    engine = EntitlementEngine(store)
    for _ in range(25):
        store.consume("account_1", "missions")
    try:
        engine.check("account_1", "missions")
        raise AssertionError("expected limit")
    except PermissionError as exc:
        assert "upgrade" in str(exc).lower()
    store.close()


def test_duplicate_webhook_is_idempotent(tmp_path):
    store = BillingStore(tmp_path / "billing.sqlite3")
    assert store.record_event("evt_1", {"type": "subscription.updated"})
    assert not store.record_event("evt_1", {"type": "subscription.updated"})
    store.close()


def test_all_public_plans_have_positive_capacity():
    assert {"free", "pro", "team", "business", "enterprise"} <= set(PLANS)
    assert all(plan.worlds > 0 for plan in PLANS.values())


def test_atomic_metered_entitlement_rejects_the_overspend(tmp_path):
    store = BillingStore(tmp_path / "billing.sqlite3")
    engine = EntitlementEngine(store)
    for _ in range(25):
        engine.consume("account_1", "missions")
    with __import__("pytest").raises(PermissionError):
        engine.consume("account_1", "missions")
    assert engine.snapshot("account_1")["usage"]["missions"] == 25
    store.close()

def test_billing_audit_export_and_revenue_metrics(tmp_path):
    store = BillingStore(tmp_path / "billing.sqlite3")
    store.set_subscription("acct-1", plan_id="pro", status="active")
    store.set_subscription("acct-2", plan_id="team", status="active")
    store.record_event("evt-1", {"type": "invoice.paid"})
    audit = store.audit_export("acct-1")
    assert audit["account_id"] == "acct-1"
    assert audit["events"][0]["event_id"] == "evt-1"
    metrics = store.revenue_metrics()
    assert metrics["active_subscriptions"] == 2
    assert metrics["mrr_cents"] == 2900 + 9900
    store.close()

def test_billing_outage_is_non_destructive(tmp_path):
    store = BillingStore(tmp_path / "billing.sqlite3")
    store.set_subscription("acct-1", plan_id="pro", status="active")
    state = store.payment_outage("acct-1", reason="provider timeout")
    assert state["outage"] is True
    assert store.subscription("acct-1")["plan_id"] == "pro"
    assert any(e["payload"]["type"] == "billing.outage" for e in store.audit_export("acct-1")["events"])
    store.close()
