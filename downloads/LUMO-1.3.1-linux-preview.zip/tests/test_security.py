import pytest
from ocean.security import *


def test_sessions_expire_revoke_and_rotate():
    a=SessionAuthority(secret=b"x"*32,ttl_seconds=10)
    token=a.issue("acct",now=100)
    assert a.verify(token,now=109).account_id=="acct"
    with pytest.raises(PermissionError): a.verify(token,now=110)
    token=a.issue("acct",now=100); a.revoke(token)
    with pytest.raises(PermissionError): a.verify(token,now=101)
    token=a.issue("acct",now=100); a.rotate()
    with pytest.raises(PermissionError): a.verify(token,now=101)


def test_limiter_and_redaction():
    l=BruteForceLimiter(2,100); l.record_failure("x",0); l.record_failure("x",1)
    assert not l.allowed("x",2); l.clear("x"); assert l.allowed("x",2)
    assert "sk_live" not in redact_secrets("api_key=sk_live")


def test_path_and_command_guards(tmp_path):
    root=tmp_path/"root"; root.mkdir(); assert validate_path(str(root/"a"),[root]).parent==root
    with pytest.raises(PermissionError): validate_path(str(tmp_path/"outside"),[root])
    assert validate_command(["git","status"])
    with pytest.raises(ValueError): validate_command(["echo;rm"])


def test_secret_inventory_never_reads_secret_values():
    from ocean.security import SecretInventory
    inventory = SecretInventory()
    items = inventory.environment({"OPENAI_API_KEY": "super-secret", "NORMAL": "x"})
    assert [item.name for item in items] == ["OPENAI_API_KEY"]
    assert all("super-secret" not in item.name for item in items)


def test_keychain_store_fails_closed_off_macos(monkeypatch):
    from ocean.security import KeychainTokenStore
    monkeypatch.setattr("platform.system", lambda: "Linux")
    store = KeychainTokenStore()
    with pytest.raises(RuntimeError, match="secure token storage"):
        store.set("acct", "token")
