import pytest

from ocean.intelligence_router import (
    IntelligenceRouter,
    ModelManifest,
    ModelRegistry,
    RouteRequest,
)


def test_router_records_tokens_cost_and_latency():
    registry = ModelRegistry([ModelManifest("m", "p", cost_per_1k_tokens=2.0)])
    router = IntelligenceRouter(registry)
    observation = router.record_usage("m", latency_ms=120, input_tokens=100, output_tokens=50)
    assert observation.total_tokens == 150
    telemetry = router.telemetry("m")
    assert telemetry["tokens"] == 150
    assert telemetry["estimated_cost"] == pytest.approx(0.3)
    assert telemetry["avg_latency_ms"] == 120


def test_router_rejects_invalid_usage_metrics():
    router = IntelligenceRouter(ModelRegistry([ModelManifest("m", "p")]))
    with pytest.raises(ValueError):
        router.record_usage("m", latency_ms=float("nan"), input_tokens=1, output_tokens=1)
    with pytest.raises(ValueError):
        router.record_usage("m", latency_ms=1, input_tokens=-1, output_tokens=1)


def test_router_can_require_device_memory_and_gpu():
    registry = ModelRegistry([
        ModelManifest("local", "ollama", frozenset({"gpu"}), size_gib=4),
        ModelManifest("cpu", "cloud", frozenset(), size_gib=None),
    ])
    router = IntelligenceRouter(registry)
    receipt = router.route(RouteRequest(require_gpu=True, max_memory_bytes=8 * 1024**3))
    assert receipt.model_id == "local"
