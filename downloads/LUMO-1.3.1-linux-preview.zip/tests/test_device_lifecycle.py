import pytest
from ocean.device_registry import DeviceRegistry, DeviceLifecycleController

def test_device_drain_maintenance_revoke_and_health(tmp_path):
    r=DeviceRegistry(tmp_path/"devices.sqlite3"); d=r.register("a",name="mac")
    c=DeviceLifecycleController(r)
    assert c.can_schedule("a",d.id)
    c.set_mode("a",d.id,"drain"); assert not c.can_schedule("a",d.id)
    c.set_mode("a",d.id,"active"); c.record_health("a",d.id,battery_percent=80,temperature_c=40)
    assert c.health("a",d.id)["battery_percent"]==80
    with pytest.raises(ValueError): c.record_health("a",d.id,battery_percent=101)
    c.revoke("a",d.id); assert not c.can_schedule("a",d.id)


def test_pairing_code_is_one_time_and_account_bound(tmp_path):
    from ocean.device_registry import DeviceLifecycleController, DeviceRegistry
    registry = DeviceRegistry(tmp_path / "devices.sqlite3")
    lifecycle = DeviceLifecycleController(registry)
    code = lifecycle.issue_pairing_code("acct")
    assert lifecycle.redeem_pairing_code("other", code) is False
    assert lifecycle.redeem_pairing_code("acct", code) is True
    assert lifecycle.redeem_pairing_code("acct", code) is False
