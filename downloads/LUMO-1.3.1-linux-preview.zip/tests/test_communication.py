from datetime import timedelta

import pytest

from ocean.core.clock import SYSTEM_CLOCK
from ocean.domain.event_bus import EventBus
from ocean.domain.message import Message
from ocean.communication import (
    DeliveryStatus,
    MessageBroker,
    MessageEnvelope,
    MessageRouter,
)


def test_message_domain_remains_structured():
    message = Message(
        sender_id="agent-a",
        recipient_id="agent-b",
        type="task_result",
        payload={"value": 42},
    )

    assert message.sender_id == "agent-a"
    assert message.recipient_id == "agent-b"
    assert message.type == "task_result"
    assert message.payload["value"] == 42


def test_send_persists_before_delivery():
    events = EventBus()
    broker = MessageBroker(event_bus=events)
    broker.register_agent("agent-b")

    message = Message(
        sender_id="agent-a",
        recipient_id="agent-b",
        type="research_result",
        payload={"result": "ok"},
    )

    receipt = broker.send(message)

    assert receipt.status == DeliveryStatus.DELIVERED
    history = events.history()
    assert history[0].type == "MessageSent"
    assert history[1].type == "MessageDelivered"


def test_message_is_available_in_recipient_mailbox():
    broker = MessageBroker(event_bus=EventBus())
    broker.register_agent("b")

    message = Message(
        sender_id="a",
        recipient_id="b",
        type="request",
    )

    broker.send(message)

    assert [m.message.id for m in broker.pending("b")] == []


def test_acknowledgement_requires_delivery():
    broker = MessageBroker(event_bus=EventBus())
    mailbox = broker.mailbox("b")

    message = Message(sender_id="a", recipient_id="b", type="request")
    envelope = MessageEnvelope(message=message)
    mailbox.enqueue(envelope)

    with pytest.raises(ValueError):
        mailbox.acknowledge(message.id)


def test_acknowledgement_is_durable():
    events = EventBus()
    broker = MessageBroker(event_bus=events)
    broker.register_agent("b")

    message = Message(sender_id="a", recipient_id="b", type="request")
    broker.send(message)
    receipt = broker.acknowledge("b", message.id)

    assert receipt.status == DeliveryStatus.ACKNOWLEDGED
    assert events.history()[-1].type == "MessageAcknowledged"


def test_duplicate_send_is_idempotent_at_mailbox():
    broker = MessageBroker(event_bus=EventBus())
    mailbox = broker.mailbox("b")

    message = Message(sender_id="a", recipient_id="b", type="request")
    envelope = MessageEnvelope(message=message)

    first = mailbox.enqueue(envelope)
    second = mailbox.enqueue(envelope)

    assert first.message_id == second.message_id
    assert len(mailbox.pending()) == 1


def test_unknown_recipient_is_rejected_before_persistence():
    events = EventBus()
    broker = MessageBroker(event_bus=events)

    message = Message(sender_id="a", recipient_id="missing", type="request")

    with pytest.raises(KeyError):
        broker.send(message)

    assert events.history() == []


def test_router_broadcast_creates_distinct_recipient_messages():
    router = MessageRouter()
    router.register("a", object())
    router.register("b", object())

    original = Message(
        sender_id="root",
        recipient_id="a",
        type="notice",
        payload={"x": 1},
    )
    envelope = MessageEnvelope(message=original)

    copies = router.broadcast(envelope, ["a", "b"])

    assert [copy.message.recipient_id for copy in copies] == ["a", "b"]
    assert copies[0].message.id != copies[1].message.id
    assert copies[0].message.payload == copies[1].message.payload


def test_broker_rebuilds_mailbox_from_durable_history():
    events = EventBus()
    broker = MessageBroker(event_bus=events)
    broker.register_agent("b")

    message = Message(
        sender_id="a",
        recipient_id="b",
        type="request",
        payload={"value": 42},
    )

    broker.send(message)
    broker.acknowledge("b", message.id)

    rebuilt = MessageBroker(event_bus=events)
    rebuilt.rebuild()

    receipt = rebuilt.mailbox("b").receipt(message.id)
    assert receipt.status == DeliveryStatus.ACKNOWLEDGED
    assert receipt.message_id == message.id


def test_broker_rebuilds_rejected_message():
    events = EventBus()
    broker = MessageBroker(event_bus=events)
    broker.register_agent("b")

    message = Message(
        sender_id="a",
        recipient_id="b",
        type="request",
    )

    broker.send(message)
    broker.reject("b", message.id, "unsupported request")

    rebuilt = MessageBroker(event_bus=events)
    rebuilt.rebuild()

    receipt = rebuilt.mailbox("b").receipt(message.id)
    assert receipt.status == DeliveryStatus.REJECTED
    assert receipt.reason == "unsupported request"


def test_expired_message_is_durable():
    from datetime import timedelta

    events = EventBus()
    broker = MessageBroker(event_bus=events)
    broker.register_agent("b")

    expires_at = SYSTEM_CLOCK.now() - timedelta(seconds=1)

    message = Message(
        sender_id="a",
        recipient_id="b",
        type="request",
    )

    receipt = broker.send(
        message,
        expires_at=expires_at,
    )

    assert receipt.status == DeliveryStatus.EXPIRED
    assert events.history()[-1].type == "MessageExpired"

    rebuilt = MessageBroker(event_bus=events)
    rebuilt.rebuild()

    assert (
        rebuilt.mailbox("b").receipt(message.id).status
        == DeliveryStatus.EXPIRED
    )


def test_duplicate_send_does_not_append_second_message_lifecycle():
    events = EventBus()
    broker = MessageBroker(event_bus=events)
    broker.register_agent("b")

    message = Message(
        sender_id="a",
        recipient_id="b",
        type="request",
    )

    broker.send(message)
    broker.send(message)

    assert [
        event.type
        for event in events.history()
        if event.payload.get("message_id") == message.id
    ] == [
        "MessageSent",
        "MessageDelivered",
    ]


def test_duplicate_acknowledgement_is_idempotent():
    events = EventBus()
    broker = MessageBroker(event_bus=events)
    broker.register_agent("b")

    message = Message(
        sender_id="a",
        recipient_id="b",
        type="request",
    )

    broker.send(message)
    first = broker.acknowledge("b", message.id)
    second = broker.acknowledge("b", message.id)

    assert first.status == DeliveryStatus.ACKNOWLEDGED
    assert second.status == DeliveryStatus.ACKNOWLEDGED

    assert [
        event.type
        for event in events.history()
        if event.payload.get("message_id") == message.id
    ] == [
        "MessageSent",
        "MessageDelivered",
        "MessageAcknowledged",
    ]


def test_rejected_message_cannot_be_acknowledged():
    events = EventBus()
    broker = MessageBroker(event_bus=events)
    broker.register_agent("b")

    message = Message(
        sender_id="a",
        recipient_id="b",
        type="request",
    )

    broker.send(message)
    broker.reject("b", message.id, "rejected")

    with pytest.raises(ValueError):
        broker.acknowledge("b", message.id)


def test_rebuild_preserves_pending_messages():
    events = EventBus()
    broker = MessageBroker(event_bus=events)
    broker.register_agent("b")

    message = Message(
        sender_id="a",
        recipient_id="b",
        type="request",
    )

    envelope = MessageEnvelope(message=message)
    broker.mailbox("b").enqueue(envelope)

    rebuilt = MessageBroker(event_bus=events)
    rebuilt.rebuild()

    assert [m.message.id for m in rebuilt.pending("b")] == []
