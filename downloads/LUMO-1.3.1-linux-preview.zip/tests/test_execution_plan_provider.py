from __future__ import annotations

from dataclasses import dataclass

import pytest

from ocean.domain.plan import PlanRevision
from ocean.domain.task import Task
from ocean.domain.work_graph import WorkGraph, WorkNode, WorkNodeKind
from ocean.execution.compiler import ExecutionIntentResolver, ExecutionPlan
from ocean.orchestration.execution_plan_provider import (
    RepositoryExecutionPlanProvider,
)
from ocean.orchestration.types import ExecutionIntent
from persistence.in_memory import InMemoryRepository


@dataclass
class FakeResolver(ExecutionIntentResolver):
    calls: list[str]

    def resolve(self, task: Task) -> ExecutionIntent:
        self.calls.append(task.id)
        return ExecutionIntent(
            capability="test",
            operation="run",
            arguments={"task_id": task.id},
        )


def make_state():
    plan_revisions = InMemoryRepository()
    work_graphs = InMemoryRepository()
    tasks = InMemoryRepository()

    task_a = Task(
        id="task-a",
        title="Task A",
        mission_id="mission-1",
    )
    task_b = Task(
        id="task-b",
        title="Task B",
        mission_id="mission-1",
    )
    unrelated = Task(
        id="task-unrelated",
        title="Unrelated",
        mission_id="mission-2",
    )

    tasks.save(task_a)
    tasks.save(task_b)
    tasks.save(unrelated)

    graph = WorkGraph(
        id="graph-1",
        mission_id="mission-1",
        plan_revision_id="plan-1",
        nodes=(
            WorkNode(
                id="node-a",
                kind=WorkNodeKind.TASK,
                task_id="task-a",
            ),
            WorkNode(
                id="node-b",
                kind=WorkNodeKind.TASK,
                task_id="task-b",
            ),
        ),
        edges=(),
    )

    plan = PlanRevision(
        id="plan-1",
        mission_id="mission-1",
        revision=1,
        decision_id="decision-1",
        graph_id="graph-1",
    )

    work_graphs.save(graph)
    plan_revisions.save(plan)

    return plan_revisions, work_graphs, tasks, plan, graph, task_a, task_b


def make_provider():
    (
        plan_revisions,
        work_graphs,
        tasks,
        plan,
        graph,
        task_a,
        task_b,
    ) = make_state()

    resolver = FakeResolver([])
    provider = RepositoryExecutionPlanProvider(
        plan_revisions=plan_revisions,
        work_graphs=work_graphs,
        tasks=tasks,
        resolver=resolver,
    )

    return provider, resolver, plan, graph, task_a, task_b


def test_requires_dependencies():
    _, work_graphs, tasks, _, _, _, _ = make_state()
    resolver = FakeResolver([])

    with pytest.raises(
        ValueError,
        match="plan_revisions is required",
    ):
        RepositoryExecutionPlanProvider(
            plan_revisions=None,
            work_graphs=work_graphs,
            tasks=tasks,
            resolver=resolver,
        )


def test_reconstructs_execution_plan_from_durable_state():
    provider, resolver, plan, graph, task_a, task_b = make_provider()

    result = provider.get(plan.id)

    assert isinstance(result, ExecutionPlan)
    assert result.mission_id == "mission-1"
    assert result.plan_revision_id == plan.id
    assert [step.node_id for step in result.steps] == [
        "node-a",
        "node-b",
    ]
    assert [step.task_id for step in result.steps] == [
        "task-a",
        "task-b",
    ]
    assert resolver.calls == [task_a.id, task_b.id]


def test_filters_tasks_to_plan_mission():
    provider, resolver, plan, _, _, _ = make_provider()

    result = provider.get(plan.id)

    assert len(result.steps) == 2
    assert resolver.calls == ["task-a", "task-b"]


def test_rejects_unknown_plan_revision():
    provider, _, _, _, _, _ = make_provider()

    with pytest.raises(
        ValueError,
        match="unknown plan revision",
    ):
        provider.get("missing-plan")


def test_rejects_missing_work_graph():
    provider, _, plan, _, _, _ = make_provider()

    provider.work_graphs.delete(plan.graph_id)

    with pytest.raises(
        ValueError,
        match="references unknown work graph",
    ):
        provider.get(plan.id)


def test_rejects_graph_from_wrong_mission():
    provider, _, plan, graph, _, _ = make_provider()

    wrong_graph = WorkGraph(
        id=graph.id,
        mission_id="mission-2",
        plan_revision_id=plan.id,
        nodes=graph.nodes,
        edges=graph.edges,
    )
    provider.work_graphs.save(wrong_graph)

    with pytest.raises(
        ValueError,
        match="belongs to mission",
    ):
        provider.get(plan.id)


def test_rejects_graph_referencing_different_plan_revision():
    provider, _, plan, graph, _, _ = make_provider()

    wrong_graph = WorkGraph(
        id=graph.id,
        mission_id=graph.mission_id,
        plan_revision_id="different-plan",
        nodes=graph.nodes,
        edges=graph.edges,
    )
    provider.work_graphs.save(wrong_graph)

    with pytest.raises(
        ValueError,
        match="references plan revision",
    ):
        provider.get(plan.id)


def test_preserves_compiler_dependency_semantics():
    (
        plan_revisions,
        work_graphs,
        tasks,
        plan,
        _,
        task_a,
        task_b,
    ) = make_state()

    graph = WorkGraph(
        id="graph-2",
        mission_id="mission-1",
        plan_revision_id=plan.id,
        nodes=(
            WorkNode(
                id="node-a",
                kind=WorkNodeKind.TASK,
                task_id=task_a.id,
            ),
            WorkNode(
                id="node-b",
                kind=WorkNodeKind.TASK,
                task_id=task_b.id,
            ),
        ),
        edges=(),
    )

    work_graphs.save(graph)

    plan = PlanRevision(
        id="plan-2",
        mission_id="mission-1",
        revision=2,
        decision_id="decision-1",
        graph_id=graph.id,
        parent_revision_id="plan-1",
    )
    plan_revisions.save(plan)

    # Replace the graph with a dependency-bearing graph.
    from ocean.domain.work_graph import WorkEdge, WorkEdgeKind

    graph = WorkGraph(
        id="graph-2",
        mission_id="mission-1",
        plan_revision_id=plan.id,
        nodes=graph.nodes,
        edges=(
            WorkEdge(
                id="edge-a-b",
                source_node_id="node-a",
                target_node_id="node-b",
                kind=WorkEdgeKind.DEPENDENCY,
            ),
        ),
    )
    work_graphs.save(graph)

    resolver = FakeResolver([])
    provider = RepositoryExecutionPlanProvider(
        plan_revisions=plan_revisions,
        work_graphs=work_graphs,
        tasks=tasks,
        resolver=resolver,
    )

    result = provider.get(plan.id)

    assert result.dependencies("node-a") == ()
    assert result.dependencies("node-b") == ("node-a",)
