from ocean.power import PowerGuardian


def test_power_capabilities_are_conservative():
    capabilities = PowerGuardian.capabilities()
    assert capabilities["display_sleep_allowed"] is True
    assert capabilities["cold_boot"] is False
    assert "wake_from_sleep" in capabilities


def test_release_removes_lease_and_stops_process(monkeypatch):
    guardian = PowerGuardian()
    started = []

    class FakeProcess:
        pid = 123
        def poll(self):
            return None
        def terminate(self):
            started.append("terminate")
        def wait(self, timeout):
            started.append(("wait", timeout))
        def kill(self):
            started.append("kill")

    monkeypatch.setattr("subprocess.Popen", lambda *args, **kwargs: FakeProcess())
    lease = guardian.acquire("mission-1")
    assert guardian.status()["active"] is True
    guardian.release(lease)
    assert guardian.status()["active"] is False
    assert "terminate" in started


def test_duplicate_release_is_idempotent(monkeypatch):
    guardian = PowerGuardian()
    monkeypatch.setattr("subprocess.Popen", lambda *args, **kwargs: type("P", (), {"pid": 1, "poll": lambda s: None, "terminate": lambda s: None, "wait": lambda s, timeout: None})())
    lease = guardian.acquire("same")
    guardian.release(lease)
    guardian.release(lease)
    assert guardian.status()["leases"] == []


def test_status_does_not_claim_sleep_blocking_when_enforcement_is_unavailable(monkeypatch):
    guardian = PowerGuardian()
    monkeypatch.setattr("ocean.power.platform.system", lambda: "Linux")
    lease = guardian.acquire("unsupported-host")
    status = guardian.status()
    assert status["enforcement_available"] is False
    assert status["active"] is True
    assert status["system_sleep_blocked"] is False
    guardian.release(lease)


def test_active_work_reasserts_power_after_sleep_wake_boundary(monkeypatch):
    guardian = PowerGuardian()
    calls = []
    class FakeProcess:
        pid = 9
        def __init__(self): self.dead = False
        def poll(self): return 1 if self.dead else None
        def terminate(self): calls.append("terminate")
        def wait(self, timeout): calls.append(("wait", timeout))
        def kill(self): calls.append("kill")
    processes = []
    def fake_popen(*args, **kwargs):
        process = FakeProcess(); processes.append(process); return process
    monkeypatch.setattr("ocean.power.platform.system", lambda: "Darwin")
    monkeypatch.setattr("ocean.power.os.path.exists", lambda path: True)
    monkeypatch.setattr("ocean.power.subprocess.Popen", fake_popen)
    lease = guardian.acquire("mission-wake")
    assert len(processes) == 1
    # Simulate the host waking after its assertion process was interrupted.
    processes[0].dead = True
    status = guardian.status()
    assert status["active"] is True
    assert len(processes) == 2
    assert status["system_sleep_blocked"] is True
    guardian.release(lease)
