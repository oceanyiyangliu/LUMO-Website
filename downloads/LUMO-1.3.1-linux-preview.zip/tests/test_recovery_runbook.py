from pathlib import Path

def test_recovery_runbook_covers_stop_preserve_recover_verify():
    text=Path('docs/RECOVERY_RUNBOOK.md').read_text()
    for term in ('Emergency Stop','SQLite backup','canonical event stream','hash chains','orphaned QEMU'):
        assert term in text
