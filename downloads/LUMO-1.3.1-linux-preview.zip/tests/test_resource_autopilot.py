from ocean.resources.resource_autopilot import ResourceAutopilot


def make_autopilot():
    # Avoid starting the background observer; these tests exercise its pure
    # recommendation policy deterministically.
    return ResourceAutopilot.__new__(ResourceAutopilot)


def test_no_pressure_means_no_user_app_intervention():
    ap = make_autopilot()
    assert ap._build_recommendation({"memory_pressure": False, "available_ram_gib": 4, "apps": []}, 1.5) is None


def test_only_background_apps_are_candidates_and_ollama_is_protected():
    ap = make_autopilot()
    rec = ap._build_recommendation({
        "memory_pressure": True,
        "available_ram_gib": 0.7,
        "apps": [
            {"name": "Ollama", "memory_gib": 2.0, "background_only": True},
            {"name": "Chrome", "memory_gib": 1.5, "background_only": False},
            {"name": "Spotify", "memory_gib": 0.8, "background_only": True},
        ],
    }, 0.8)
    assert rec is not None
    assert [x["name"] for x in rec["apps"]] == ["Spotify"]


def test_protected_desktop_apps_are_never_candidates():
    ap = make_autopilot()
    rec = ap._build_recommendation({
        "memory_pressure": True,
        "available_ram_gib": 0.5,
        "apps": [
            {"name": "Finder", "memory_gib": 2.0, "background_only": True},
            {"name": "System Settings", "memory_gib": 2.0, "background_only": True},
        ],
    }, 0.5)
    assert rec is not None
    assert rec["apps"] == []
