import pytest

from ocean.domain.mission import Mission
from ocean.domain.plan import PlanRevision
from ocean.domain.task import Task
from ocean.self_improvement.execution_boundary import (
    CandidateExecutionBoundary,
    CandidateExecutionBoundaryError,
)
from ocean.self_improvement.isolation import CandidateIsolationService
from persistence.in_memory import InMemoryRepository


def build():
    return InMemoryRepository(), InMemoryRepository()


def setup_candidate():
    missions, tasks = build()

    source = Mission(goal="Production objective")
    source_task = Task(
        title="Production task",
        mission_id=source.id,
    )
    source.add_task(source_task.id)

    missions.save(source)
    tasks.save(source_task)

    isolation = CandidateIsolationService(
        missions=missions,
        tasks=tasks,
    ).create(
        source_mission=source,
        task_ids=[source_task.id],
    )

    candidate = missions.get(isolation.candidate_mission_id)
    assert candidate is not None

    source_plan = PlanRevision(
        mission_id=source.id,
        revision=1,
        decision_id="decision-source",
        graph_id="graph-source",
    )

    candidate_plan = PlanRevision(
        mission_id=candidate.id,
        revision=1,
        decision_id="decision-candidate",
        graph_id="graph-candidate",
    )

    return source, candidate, source_plan, candidate_plan, isolation


def test_candidate_execution_context_is_structurally_isolated():
    source, candidate, source_plan, candidate_plan, isolation = setup_candidate()

    context = CandidateExecutionBoundary().validate(
        isolation=isolation,
        candidate_mission=candidate,
        candidate_plan=candidate_plan,
        source_mission=source,
        source_plan=source_plan,
    )

    assert context.candidate_mission_id == candidate.id
    assert context.source_mission_id == source.id
    assert context.candidate_plan_revision_id == candidate_plan.id
    assert context.source_plan_revision_id == source_plan.id
    assert context.metadata["candidate_execution"] is True


def test_candidate_plan_cannot_belong_to_production_mission():
    source, candidate, source_plan, _, isolation = setup_candidate()

    invalid_plan = PlanRevision(
        mission_id=source.id,
        revision=2,
        decision_id="decision-invalid",
        graph_id="graph-invalid",
        parent_revision_id=source_plan.id,
    )

    with pytest.raises(
        CandidateExecutionBoundaryError,
        match="candidate plan does not belong",
    ):
        CandidateExecutionBoundary().validate(
            isolation=isolation,
            candidate_mission=candidate,
            candidate_plan=invalid_plan,
            source_mission=source,
            source_plan=source_plan,
        )


def test_source_plan_cannot_belong_to_candidate_mission():
    source, candidate, _, candidate_plan, isolation = setup_candidate()

    invalid_source_plan = PlanRevision(
        mission_id=candidate.id,
        revision=1,
        decision_id="decision-invalid-source",
        graph_id="graph-invalid-source",
    )

    with pytest.raises(
        CandidateExecutionBoundaryError,
        match="source plan does not belong",
    ):
        CandidateExecutionBoundary().validate(
            isolation=isolation,
            candidate_mission=candidate,
            candidate_plan=candidate_plan,
            source_mission=source,
            source_plan=invalid_source_plan,
        )


def test_candidate_mission_cannot_equal_source_mission():
    source, _, source_plan, candidate_plan, isolation = setup_candidate()

    with pytest.raises(
        CandidateExecutionBoundaryError,
        match="candidate mission cannot equal source",
    ):
        CandidateExecutionBoundary().validate(
            isolation=isolation,
            candidate_mission=source,
            candidate_plan=candidate_plan,
            source_mission=source,
            source_plan=source_plan,
        )


def test_boundary_rejects_empty_candidate_task_set():
    source, candidate, source_plan, candidate_plan, _ = setup_candidate()

    empty_isolation = type(
        "Isolation",
        (),
        {
            "candidate_mission_id": candidate.id,
            "source_mission_id": source.id,
            "candidate_task_ids": frozenset(),
            "source_task_ids": frozenset(),
        },
    )()

    with pytest.raises(
        CandidateExecutionBoundaryError,
        match="at least one candidate task",
    ):
        CandidateExecutionBoundary().validate(
            isolation=empty_isolation,
            candidate_mission=candidate,
            candidate_plan=candidate_plan,
            source_mission=source,
            source_plan=source_plan,
        )
