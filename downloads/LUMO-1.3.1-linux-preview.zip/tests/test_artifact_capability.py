from __future__ import annotations

from pathlib import Path

from ocean.capabilities.artifact import create_presentation, verify_presentation
from ocean.orchestration.mission_engine import MissionContract


def test_presentation_artifact_is_real_and_reopen_verified(tmp_path: Path):
    path = tmp_path / "deck.pptx"
    result = create_presentation(
        output_path=path,
        title="Example Deck",
        slides=[
            {"title": "Overview", "bullets": ["A", "B"], "speaker_notes": "Notes"},
            {"title": "Evidence", "bullets": ["C"], "speaker_notes": "More notes"},
            {"title": "Conclusion", "bullets": ["D"], "speaker_notes": "Done"},
        ],
    )
    assert result["verified"] is True
    assert result["slide_count"] == 3
    assert path.is_file()
    reopened = verify_presentation(path, expected_title="Example Deck")
    assert reopened["verified"] is True


def test_presentation_goal_requires_artifact_outcome():
    contract = MissionContract.from_goal("Build a PowerPoint presentation about a public figure")
    assert "artifact" in contract.required_work_types
