import pytest

from ocean.domain.enums import AssigneeType, MissionStatus
from eventing.in_memory_store import InMemoryEventStore
from ocean.domain.event import Event
from ocean.event_sourcing.replay import EventReplayer, ReplayError

def test_replayer_can_replay_from_event_store():
    from eventing.in_memory_store import InMemoryEventStore

    store = InMemoryEventStore()

    store.append(
        Event(
            type="MissionCreated",
            payload={
                "id": "mission-1",
                "goal": "Test mission",
                "task_ids": [],
                "metadata": {},
            },
        )
    )

    replayer = EventReplayer()

    state = replayer.replay_from_store(store)

    assert "mission-1" in state.missions
    assert state.missions["mission-1"].goal == "Test mission"


def test_replayer_can_replay_only_events_after_a_sequence():
    from eventing.in_memory_store import InMemoryEventStore

    store = InMemoryEventStore()

    store.append(
        Event(
            type="MissionCreated",
            payload={
                "id": "mission-1",
                "goal": "First mission",
                "task_ids": [],
                "metadata": {},
            },
        )
    )

    store.append(
        Event(
            type="MissionCreated",
            payload={
                "id": "mission-2",
                "goal": "Second mission",
                "task_ids": [],
                "metadata": {},
            },
        )
    )

    replayer = EventReplayer()

    state = replayer.replay_from_store(store, after_sequence=1)

    assert "mission-1" not in state.missions
    assert "mission-2" in state.missions

def test_replayer_replays_mission_activation():
    store = InMemoryEventStore()

    store.append(
        Event(
            type="MissionCreated",
            payload={
                "id": "mission-1",
                "goal": "Test mission",
                "task_ids": [],
                "metadata": {},
            },
        )
    )

    store.append(
        Event(
            type="MissionActivated",
            payload={"id": "mission-1"},
        )
    )

    state = EventReplayer().replay_from_store(store)

    assert state.missions["mission-1"].status.value == "active"


def test_replayer_rejects_mission_activation_for_unknown_mission():
    events = [
        Event(
            type="MissionActivated",
            payload={"id": "missing-mission"},
        )
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)
def test_replayer_replays_mission_pause():
    store = InMemoryEventStore()

    store.append(
        Event(
            type="MissionCreated",
            payload={
                "id": "mission-1",
                "goal": "Test mission",
                "task_ids": [],
                "metadata": {},
            },
        )
    )

    store.append(
        Event(
            type="MissionActivated",
            payload={"id": "mission-1"},
        )
    )

    store.append(
        Event(
            type="MissionPaused",
            payload={"id": "mission-1"},
        )
    )

    state = EventReplayer().replay_from_store(store)

    assert state.missions["mission-1"].status.value == "paused"


def test_replayer_rejects_mission_pause_for_unknown_mission():
    events = [
        Event(
            type="MissionPaused",
            payload={"id": "missing-mission"},
        )
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)
def test_replayer_replays_mission_resume():
    store = InMemoryEventStore()

    store.append(
        Event(
            type="MissionCreated",
            payload={
                "id": "mission-1",
                "goal": "Test mission",
                "task_ids": [],
                "metadata": {},
            },
        )
    )

    store.append(
        Event(
            type="MissionActivated",
            payload={"id": "mission-1"},
        )
    )

    store.append(
        Event(
            type="MissionPaused",
            payload={"id": "mission-1"},
        )
    )

    store.append(
        Event(
            type="MissionResumed",
            payload={"id": "mission-1"},
        )
    )

    state = EventReplayer().replay_from_store(store)

    assert state.missions["mission-1"].status.value == "active"

def test_replayer_replays_task_queue():
    events = [
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Test task",
                "description": "Test description",
                "mission_id": "mission-1",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        ),
        Event(
            type="TaskReadied",
            payload={"id": "task-1"},
        ),
        Event(
            type="TaskQueued",
            payload={"id": "task-1"},
        ),
    ]

    state = EventReplayer().replay(events)

    assert state.tasks["task-1"].status.value == "queued"


def test_replayer_rejects_task_queue_for_unknown_task():
    events = [
        Event(
            type="TaskQueued",
            payload={"id": "missing-task"},
        )
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)
def test_replayer_rejects_mission_resume_for_unknown_mission():
    events = [
        Event(
            type="MissionResumed",
            payload={"id": "missing-mission"},
        )
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)
def test_replayer_replays_mission_completion():
    store = InMemoryEventStore()

    store.append(
        Event(
            type="MissionCreated",
            payload={
                "id": "mission-1",
                "goal": "Test mission",
                "task_ids": [],
                "metadata": {},
            },
        )
    )

    store.append(
        Event(
            type="MissionActivated",
            payload={"id": "mission-1"},
        )
    )

    store.append(
        Event(
            type="MissionCompleted",
            payload={"id": "mission-1"},
        )
    )

    state = EventReplayer().replay_from_store(store)

    assert state.missions["mission-1"].status.value == "completed"


def test_replayer_rejects_mission_completion_for_unknown_mission():
    events = [
        Event(
            type="MissionCompleted",
            payload={"id": "missing-mission"},
        )
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)
def test_replayer_replays_mission_failure():
    store = InMemoryEventStore()

    store.append(
        Event(
            type="MissionCreated",
            payload={
                "id": "mission-1",
                "goal": "Test mission",
                "task_ids": [],
                "metadata": {},
            },
        )
    )

    store.append(
        Event(
            type="MissionActivated",
            payload={"id": "mission-1"},
        )
    )

    store.append(
        Event(
            type="MissionFailed",
            payload={"id": "mission-1"},
        )
    )

    state = EventReplayer().replay_from_store(store)

    assert state.missions["mission-1"].status.value == "failed"


def test_replayer_rejects_mission_failure_for_unknown_mission():
    events = [
        Event(
            type="MissionFailed",
            payload={"id": "missing-mission"},
        )
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)
def test_replayer_replays_mission_cancellation():
    store = InMemoryEventStore()

    store.append(
        Event(
            type="MissionCreated",
            payload={
                "id": "mission-1",
                "goal": "Test mission",
                "task_ids": [],
                "metadata": {},
            },
        )
    )

    store.append(
        Event(
            type="MissionActivated",
            payload={"id": "mission-1"},
        )
    )

    store.append(
        Event(
            type="MissionCancelled",
            payload={"id": "mission-1"},
        )
    )

    state = EventReplayer().replay_from_store(store)

    assert state.missions["mission-1"].status.value == "cancelled"


def test_replayer_rejects_mission_cancellation_for_unknown_mission():
    events = [
        Event(
            type="MissionCancelled",
            payload={"id": "missing-mission"},
        )
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)
def test_replayer_replays_task_creation():
    events = [
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Test task",
                "description": "Test description",
                "mission_id": "mission-1",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        )
    ]

    state = EventReplayer().replay(events)

    task = state.tasks["task-1"]

    assert task.id == "task-1"
    assert task.title == "Test task"
    assert task.description == "Test description"
    assert task.mission_id == "mission-1"
    assert task.status.value == "pending"


def test_replayer_rejects_duplicate_task_creation():
    events = [
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Test task",
                "description": "Test description",
                "mission_id": "mission-1",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        ),
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Duplicate task",
                "description": "Duplicate",
                "mission_id": "mission-1",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        ),
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)
def test_replayer_replays_task_ready():
    events = [
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Test task",
                "description": "Test description",
                "mission_id": "mission-1",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        ),
        Event(
            type="TaskReadied",
            payload={"id": "task-1"},
        ),
    ]

    state = EventReplayer().replay(events)

    assert state.tasks["task-1"].status.value == "ready"


def test_replayer_rejects_task_ready_for_unknown_task():
    events = [
        Event(
            type="TaskReadied",
            payload={"id": "missing-task"},
        )
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)
def test_replayer_replays_task_start():
    events = [
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Test task",
                "description": "Test description",
                "mission_id": "mission-1",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        ),
        Event(type="TaskReadied", payload={"id": "task-1"}),
        Event(type="TaskQueued", payload={"id": "task-1"}),
        Event(type="TaskStarted", payload={"id": "task-1"}),
    ]

    state = EventReplayer().replay(events)

    assert state.tasks["task-1"].status.value == "running"


def test_replayer_rejects_task_start_for_unknown_task():
    events = [
        Event(type="TaskStarted", payload={"id": "missing-task"})
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)
def test_replayer_replays_task_waiting():
    events = [
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Test task",
                "description": "Test description",
                "mission_id": "mission-1",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        ),
        Event(type="TaskReadied", payload={"id": "task-1"}),
        Event(type="TaskQueued", payload={"id": "task-1"}),
        Event(type="TaskStarted", payload={"id": "task-1"}),
        Event(type="TaskWaiting", payload={"id": "task-1"}),
    ]

    state = EventReplayer().replay(events)

    assert state.tasks["task-1"].status.value == "waiting"


def test_replayer_rejects_task_waiting_for_unknown_task():
    events = [
        Event(type="TaskWaiting", payload={"id": "missing-task"})
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)
def test_replayer_replays_task_blocked():
    events = [
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Test task",
                "description": "Test description",
                "mission_id": "mission-1",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        ),
        Event(type="TaskBlocked", payload={"id": "task-1"}),
    ]

    state = EventReplayer().replay(events)

    assert state.tasks["task-1"].status.value == "blocked"


def test_replayer_rejects_task_blocked_for_unknown_task():
    events = [
        Event(type="TaskBlocked", payload={"id": "missing-task"})
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)
def test_replayer_replays_task_paused():
    events = [
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Test task",
                "description": "Test description",
                "mission_id": "mission-1",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        ),
        Event(type="TaskReadied", payload={"id": "task-1"}),
        Event(type="TaskQueued", payload={"id": "task-1"}),
        Event(type="TaskStarted", payload={"id": "task-1"}),
        Event(type="TaskPaused", payload={"id": "task-1"}),
    ]

    state = EventReplayer().replay(events)

    assert state.tasks["task-1"].status.value == "paused"


def test_replayer_rejects_task_pause_for_unknown_task():
    events = [
        Event(type="TaskPaused", payload={"id": "missing-task"})
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)
def test_replayer_replays_task_unblocked():
    events = [
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Test task",
                "description": "Test description",
                "mission_id": "mission-1",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        ),
        Event(type="TaskBlocked", payload={"id": "task-1"}),
        Event(type="TaskUnblocked", payload={"id": "task-1"}),
    ]

    state = EventReplayer().replay(events)

    assert state.tasks["task-1"].status.value == "ready"


def test_replayer_rejects_task_unblock_for_unknown_task():
    events = [
        Event(type="TaskUnblocked", payload={"id": "missing-task"})
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)
def test_replayer_replays_task_failure():
    events = [
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Test task",
                "description": "Test description",
                "mission_id": "mission-1",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        ),
        Event(type="TaskReadied", payload={"id": "task-1"}),
        Event(type="TaskQueued", payload={"id": "task-1"}),
        Event(type="TaskStarted", payload={"id": "task-1"}),
        Event(type="TaskFailed", payload={"id": "task-1"}),
    ]

    state = EventReplayer().replay(events)

    assert state.tasks["task-1"].status.value == "failed"


def test_replayer_rejects_task_failure_for_unknown_task():
    events = [
        Event(type="TaskFailed", payload={"id": "missing-task"})
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)
def test_replayer_replays_task_cancellation():
    events = [
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Test task",
                "description": "Test description",
                "mission_id": "mission-1",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        ),
        Event(type="TaskCancelled", payload={"id": "task-1"}),
    ]

    state = EventReplayer().replay(events)

    assert state.tasks["task-1"].status.value == "cancelled"


def test_replayer_rejects_task_cancellation_for_unknown_task():
    events = [
        Event(type="TaskCancelled", payload={"id": "missing-task"})
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)
def test_replayer_replays_task_replan():
    events = [
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Original task",
                "description": "Original description",
                "mission_id": "mission-1",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        ),
        Event(
            type="TaskReplanned",
            payload={
                "id": "task-1",
                "title": "Replanned task",
                "description": "Updated description",
                "depends_on": ["task-0"],
                "assignee_type": "human",
                "assignee_id": "human-1",
                "metadata": {"priority": "high"},
            },
        ),
    ]

    state = EventReplayer().replay(events)

    task = state.tasks["task-1"]

    assert task.title == "Replanned task"
    assert task.description == "Updated description"
    assert task.depends_on == {"task-0"}
    assert task.assignee_type == AssigneeType.HUMAN
    assert task.assignee_id == "human-1"
    assert task.metadata == {"priority": "high"}
    assert task.status.value == "pending"


def test_replayer_rejects_task_replan_for_unknown_task():
    events = [
        Event(
            type="TaskReplanned",
            payload={
                "id": "missing-task",
                "title": "Replanned task",
                "description": "Updated description",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        )
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)
def test_replayer_replays_task_completed_with_passing_verification():
    events = [
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Complete task",
                "description": "Task description",
                "mission_id": "mission-1",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        ),
        Event(
            type="TaskReadied",
            payload={"id": "task-1"},
        ),
        Event(
            type="TaskQueued",
            payload={"id": "task-1"},
        ),
        Event(
            type="TaskStarted",
            payload={"id": "task-1"},
        ),
        Event(
            type="VerificationRecorded",
            payload={
                "id": "verification-1",
                "task_id": "task-1",
                "method": "automated check",
                "passed": True,
                "evidence": ["all requirements satisfied"],
                "execution_id": "execution-1",
            },
        ),
        Event(
            type="TaskCompleted",
            payload={
                "task_id": "task-1",
                "verification_id": "verification-1",
            },
        ),
    ]

    state = EventReplayer().replay(events)

    task = state.tasks["task-1"]

    assert task.status.value == "completed"
    assert task.verification_id == "verification-1"


def test_replayer_rejects_task_completed_with_unknown_verification():
    events = [
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Complete task",
                "description": "",
                "mission_id": "mission-1",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        ),
        Event(
            type="TaskReadied",
            payload={"id": "task-1"},
        ),
        Event(
            type="TaskQueued",
            payload={"id": "task-1"},
        ),
        Event(
            type="TaskStarted",
            payload={"id": "task-1"},
        ),
        Event(
            type="TaskCompleted",
            payload={
                "task_id": "task-1",
                "verification_id": "missing-verification",
            },
        ),
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)


def test_replayer_rejects_task_completed_with_failing_verification():
    events = [
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Complete task",
                "description": "",
                "mission_id": "mission-1",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        ),
        Event(
            type="TaskReadied",
            payload={"id": "task-1"},
        ),
        Event(
            type="TaskQueued",
            payload={"id": "task-1"},
        ),
        Event(
            type="TaskStarted",
            payload={"id": "task-1"},
        ),
        Event(
            type="VerificationRecorded",
            payload={
                "id": "verification-1",
                "task_id": "task-1",
                "method": "automated check",
                "passed": False,
                "evidence": ["requirements not satisfied"],
                "execution_id": "execution-1",
            },
        ),
        Event(
            type="TaskCompleted",
            payload={
                "task_id": "task-1",
                "verification_id": "verification-1",
            },
        ),
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)


def test_replayer_rejects_task_completed_with_verification_for_different_task():
    events = [
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Complete task",
                "description": "",
                "mission_id": "mission-1",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        ),
        Event(
            type="TaskReadied",
            payload={"id": "task-1"},
        ),
        Event(
            type="TaskQueued",
            payload={"id": "task-1"},
        ),
        Event(
            type="TaskStarted",
            payload={"id": "task-1"},
        ),
        Event(
            type="VerificationRecorded",
            payload={
                "id": "verification-1",
                "task_id": "task-999",
                "method": "automated check",
                "passed": True,
                "evidence": ["valid"],
                "execution_id": "execution-1",
            },
        ),
        Event(
            type="TaskCompleted",
            payload={
                "task_id": "task-1",
                "verification_id": "verification-1",
            },
        ),
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)
# ----------------------------------------------------------------------
# AgentStateChanged
# ----------------------------------------------------------------------


def test_replayer_replays_agent_state_change():
    events = [
        Event(
            type="AgentCreated",
            payload={
                "id": "agent-1",
                "name": "Ocean",
                "role": "researcher",
                "capabilities": ["research"],
                "metadata": {},
            },
        ),
        Event(
            type="AgentStateChanged",
            payload={
                "id": "agent-1",
                "status": "running",
                "current_task_id": "task-1",
            },
        ),
    ]

    state = EventReplayer().replay(events)

    agent = state.agents["agent-1"]

    assert agent.status.value == "running"
    assert agent.current_task_id == "task-1"


def test_replayer_rejects_agent_state_change_for_unknown_agent():
    events = [
        Event(
            type="AgentStateChanged",
            payload={
                "id": "missing-agent",
                "status": "running",
            },
        )
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)


def test_replayer_rejects_invalid_agent_state_transition():
    events = [
        Event(
            type="AgentCreated",
            payload={
                "id": "agent-1",
                "name": "Ocean",
                "role": "researcher",
                "capabilities": [],
                "metadata": {},
            },
        ),
        Event(
            type="AgentStateChanged",
            payload={
                "id": "agent-1",
                "status": "terminated",
            },
        ),
        Event(
            type="AgentStateChanged",
            payload={
                "id": "agent-1",
                "status": "running",
            },
        ),
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)


# ----------------------------------------------------------------------
# MissionReplanned
# ----------------------------------------------------------------------


def test_replayer_replays_mission_replan():
    events = [
        Event(
            type="MissionCreated",
            payload={
                "id": "mission-1",
                "goal": "Original goal",
                "task_ids": ["task-1"],
                "metadata": {"phase": "initial"},
            },
        ),
        Event(
            type="MissionReplanned",
            payload={
                "id": "mission-1",
                "goal": "Updated goal",
                "task_ids": ["task-2", "task-3"],
                "metadata": {"phase": "replanned"},
            },
        ),
    ]

    state = EventReplayer().replay(events)

    mission = state.missions["mission-1"]

    assert mission.goal == "Updated goal"
    assert mission.task_ids == ["task-2", "task-3"]
    assert mission.metadata == {"phase": "replanned"}
    assert mission.status == MissionStatus.PLANNING


def test_replayer_rejects_mission_replan_for_unknown_mission():
    events = [
        Event(
            type="MissionReplanned",
            payload={
                "id": "missing-mission",
                "goal": "New goal",
                "task_ids": [],
                "metadata": {},
            },
        )
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)


# ----------------------------------------------------------------------
# TaskAddedToMission
# ----------------------------------------------------------------------


def test_replayer_replays_task_added_to_mission():
    events = [
        Event(
            type="MissionCreated",
            payload={
                "id": "mission-1",
                "goal": "Test mission",
                "task_ids": [],
                "metadata": {},
            },
        ),
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Test task",
                "description": "",
                "mission_id": "mission-1",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        ),
        Event(
            type="TaskAddedToMission",
            payload={
                "mission_id": "mission-1",
                "task_id": "task-1",
            },
        ),
    ]

    state = EventReplayer().replay(events)

    assert state.missions["mission-1"].task_ids == ["task-1"]


def test_replayer_does_not_duplicate_task_added_to_mission():
    events = [
        Event(
            type="MissionCreated",
            payload={
                "id": "mission-1",
                "goal": "Test mission",
                "task_ids": [],
                "metadata": {},
            },
        ),
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Test task",
                "description": "",
                "mission_id": "mission-1",
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": "agent-1",
                "metadata": {},
            },
        ),
        Event(
            type="TaskAddedToMission",
            payload={
                "mission_id": "mission-1",
                "task_id": "task-1",
            },
        ),
        Event(
            type="TaskAddedToMission",
            payload={
                "mission_id": "mission-1",
                "task_id": "task-1",
            },
        ),
    ]

    state = EventReplayer().replay(events)

    assert state.missions["mission-1"].task_ids == ["task-1"]


def test_replayer_rejects_task_added_to_unknown_mission():
    events = [
        Event(
            type="TaskCreated",
            payload={
                "id": "task-1",
                "title": "Test task",
                "description": "",
                "mission_id": None,
                "depends_on": [],
                "assignee_type": "agent",
                "assignee_id": None,
                "metadata": {},
            },
        ),
        Event(
            type="TaskAddedToMission",
            payload={
                "mission_id": "missing-mission",
                "task_id": "task-1",
            },
        ),
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)


def test_replayer_rejects_task_added_to_mission_with_unknown_task():
    events = [
        Event(
            type="MissionCreated",
            payload={
                "id": "mission-1",
                "goal": "Test mission",
                "task_ids": [],
                "metadata": {},
            },
        ),
        Event(
            type="TaskAddedToMission",
            payload={
                "mission_id": "mission-1",
                "task_id": "missing-task",
            },
        ),
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)


# ----------------------------------------------------------------------
# Execution lifecycle
# ----------------------------------------------------------------------


def _execution_created_event() -> Event:
    return Event(
        type="ExecutionCreated",
        payload={
            "id": "execution-1",
            "task_id": "task-1",
            "capability": "research",
            "operation": "search",
            "arguments": {"query": "test"},
        },
    )


def test_replayer_replays_execution_start():
    events = [
        _execution_created_event(),
        Event(
            type="ExecutionStarted",
            payload={"id": "execution-1"},
        ),
    ]

    state = EventReplayer().replay(events)

    assert state.executions["execution-1"].status.value == "running"


def test_replayer_rejects_execution_start_for_unknown_execution():
    events = [
        Event(
            type="ExecutionStarted",
            payload={"id": "missing-execution"},
        )
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)


def test_replayer_replays_execution_success():
    events = [
        _execution_created_event(),
        Event(
            type="ExecutionStarted",
            payload={"id": "execution-1"},
        ),
        Event(
            type="ExecutionSucceeded",
            payload={
                "id": "execution-1",
                "raw_result": {"answer": 42},
            },
        ),
    ]

    state = EventReplayer().replay(events)

    execution = state.executions["execution-1"]

    assert execution.status.value == "succeeded"
    assert execution.raw_result == {"answer": 42}


def test_replayer_rejects_execution_success_for_unknown_execution():
    events = [
        Event(
            type="ExecutionSucceeded",
            payload={
                "id": "missing-execution",
                "raw_result": "result",
            },
        )
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)


def test_replayer_replays_execution_failure():
    events = [
        _execution_created_event(),
        Event(
            type="ExecutionStarted",
            payload={"id": "execution-1"},
        ),
        Event(
            type="ExecutionFailed",
            payload={
                "id": "execution-1",
                "error": "capability failed",
            },
        ),
    ]

    state = EventReplayer().replay(events)

    execution = state.executions["execution-1"]

    assert execution.status.value == "failed"
    assert execution.error == "capability failed"


def test_replayer_rejects_execution_failure_for_unknown_execution():
    events = [
        Event(
            type="ExecutionFailed",
            payload={
                "id": "missing-execution",
                "error": "failure",
            },
        )
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)


def test_replayer_replays_execution_timeout():
    events = [
        _execution_created_event(),
        Event(
            type="ExecutionStarted",
            payload={"id": "execution-1"},
        ),
        Event(
            type="ExecutionTimedOut",
            payload={"id": "execution-1"},
        ),
    ]

    state = EventReplayer().replay(events)

    execution = state.executions["execution-1"]

    assert execution.status.value == "timed_out"
    assert execution.error == "timed out"


def test_replayer_rejects_execution_timeout_for_unknown_execution():
    events = [
        Event(
            type="ExecutionTimedOut",
            payload={"id": "missing-execution"},
        )
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)


def test_replayer_rejects_execution_success_before_execution_start():
    events = [
        _execution_created_event(),
        Event(
            type="ExecutionSucceeded",
            payload={
                "id": "execution-1",
                "raw_result": "result",
            },
        ),
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)


def test_replayer_rejects_execution_failure_before_execution_start():
    events = [
        _execution_created_event(),
        Event(
            type="ExecutionFailed",
            payload={
                "id": "execution-1",
                "error": "failure",
            },
        ),
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)


def test_replayer_rejects_execution_timeout_before_execution_start():
    events = [
        _execution_created_event(),
        Event(
            type="ExecutionTimedOut",
            payload={"id": "execution-1"},
        ),
    ]

    with pytest.raises(ReplayError):
        EventReplayer().replay(events)


def test_self_improvement_lifecycle_replays_deterministically():
    from ocean.domain.event import Event
    from ocean.event_sourcing.replay import EventReplayer
    from ocean.self_improvement.types import ImprovementStatus

    events = [
        Event(
            type="ImprovementCandidateCreated",
            payload={
                "run_id": "run-1",
                "candidate_id": "candidate-1",
                "mission_id": "mission-1",
                "candidate_mission_id": "candidate-mission-1",
                "source_plan_revision_id": "plan-1",
                "candidate_plan_revision_id": "candidate-plan-1",
                "hypothesis": {
                    "objective": "improve planner",
                    "hypothesis": "candidate is better",
                    "rationale": "benchmark evidence",
                    "success_criteria": ["pass regression"],
                    "constraints": {"max_latency_ms": 100},
                },
                "metadata": {
                    "candidate_mission_id": "candidate-mission-1",
                    "candidate_plan_revision_id": "candidate-plan-1",
                },
            },
        ),
        Event(
            type="ImprovementEvaluated",
            payload={
                "run_id": "run-1",
                "candidate_id": "candidate-1",
                "passed": True,
                "score": 0.95,
                "evidence": ["regression suite passed"],
                "metrics": {"latency_ms": 42.0},
                "reason": "better than baseline",
                "status": "verified",
                "verification_id": "verif-1",
            },
        ),
        Event(
            type="ImprovementPromoted",
            payload={
                "run_id": "run-1",
                "candidate_id": "candidate-1",
                "plan_revision_id": "production-plan-2",
                "previous_plan_revision_id": "production-plan-1",
                "source_candidate_plan_revision_id": "candidate-plan-1",
                "reason": "verified improvement",
            },
        ),
        Event(
            type="ImprovementRolledBack",
            payload={
                "run_id": "run-1",
                "candidate_id": "candidate-1",
                "from_plan_revision_id": "production-plan-2",
                "to_plan_revision_id": "production-plan-3",
                "rollback_source_plan_revision_id": "production-plan-1",
                "reason": "post-promotion regression",
            },
        ),
    ]

    state = EventReplayer().replay(events)
    run = state.improvement_runs["run-1"]

    assert run.candidate_id == "candidate-1"
    assert run.mission_id == "mission-1"
    assert run.status is ImprovementStatus.ROLLED_BACK
    assert run.promoted_plan_revision_id == "production-plan-2"
    assert run.evaluation is not None
    assert run.evaluation.passed is True
    assert run.evaluation.score == 0.95
    assert run.evaluation.evidence == ("regression suite passed",)
    assert run.evaluation.metrics == {"latency_ms": 42.0}
    assert run.metadata["verification_id"] == "verif-1"
    assert run.metadata["rollback_plan_revision_id"] == "production-plan-3"


def test_self_improvement_checkpoint_replays_into_run_metadata():
    from ocean.domain.event import Event
    from ocean.event_sourcing.replay import EventReplayer

    events = [
        Event(
            type="ImprovementCandidateCreated",
            payload={
                "run_id": "run-checkpoint",
                "candidate_id": "candidate-checkpoint",
                "mission_id": "mission-checkpoint",
                "hypothesis": {
                    "objective": "improve scheduler",
                    "hypothesis": "recover safely",
                    "rationale": "checkpoint test",
                },
            },
        ),
        Event(
            type="ImprovementCheckpointCreated",
            payload={
                "run_id": "run-checkpoint",
                "candidate_id": "candidate-checkpoint",
                "mission_id": "mission-checkpoint",
                "phase": "production_code_promoted",
                "context": {"changed_paths": ["runtime/scheduler.py"]},
            },
        ),
    ]

    state = EventReplayer().replay(events)
    run = state.improvement_runs["run-checkpoint"]
    assert run.metadata["recovery_checkpoint"] == {
        "phase": "production_code_promoted",
        "context": {"changed_paths": ["runtime/scheduler.py"]},
    }


def test_self_improvement_coordinator_events_replay_as_auxiliary_facts():
    from ocean.domain.event import Event
    from ocean.event_sourcing.replay import EventReplayer

    state = EventReplayer().replay([
        Event(type="ImprovementAttemptStarted", payload={"run_id": "run-1"}),
        Event(type="ImprovementDecisionMade", payload={"run_id": "run-1", "passed": False}),
        Event(type="ImprovementAttemptFailed", payload={"run_id": "run-1", "error": "boom"}),
    ])

    assert len(state.auxiliary_events["ImprovementAttemptStarted"]) == 1
    assert len(state.auxiliary_events["ImprovementDecisionMade"]) == 1
    assert len(state.auxiliary_events["ImprovementAttemptFailed"]) == 1


def test_self_improvement_replay_rejects_invalid_promotion_transition():
    from ocean.domain.event import Event
    from ocean.event_sourcing.replay import EventReplayer, ReplayError

    events = [
        Event(
            type="ImprovementCandidateCreated",
            payload={
                "run_id": "run-1",
                "candidate_id": "candidate-1",
                "mission_id": "mission-1",
                "candidate_mission_id": "candidate-mission-1",
                "candidate_plan_revision_id": "candidate-plan-1",
                "hypothesis": {
                    "objective": "objective",
                    "hypothesis": "hypothesis",
                    "rationale": "rationale",
                },
            },
        ),
        Event(
            type="ImprovementPromoted",
            payload={
                "run_id": "run-1",
                "candidate_id": "candidate-1",
                "plan_revision_id": "production-plan-1",
            },
        ),
    ]

    with pytest.raises(ReplayError, match="invalid ImprovementPromoted"):
        EventReplayer().replay(events)


def test_mission_replay_debugger_is_read_only_and_deterministic():
    from datetime import datetime, timezone
    from ocean.domain.event import Event
    from ocean.event_sourcing.replay import EventReplayer

    mission_id = "m-debug"
    events = [
        Event(type="MissionCreated", aggregate_type="mission", aggregate_id=mission_id,
              payload={"mission_id": mission_id, "goal": "debug me", "task_ids": []},
              at=datetime.now(timezone.utc)),
        Event(type="MissionStarted", aggregate_type="mission", aggregate_id=mission_id,
              payload={"mission_id": mission_id}, at=datetime.now(timezone.utc)),
    ]
    debugger = EventReplayer()
    first = debugger.debug_mission(events, mission_id)
    second = debugger.debug_mission(events, mission_id)
    assert first == second
    assert first["event_count"] == 2
    assert first["state"]["status"] == "active"
