from __future__ import annotations

from ocean.domain.event_bus import EventBus
from ocean.domain.mission import Mission
from ocean.domain.plan import PlanRevision, PlanStatus
from ocean.self_improvement import (
    ImprovementHypothesis,
    ImprovementStatus,
    SelfImprovementEngine,
)
from persistence.repository import Repository


class MemoryRepository(Repository):
    def __init__(self):
        self.items = {}

    def save(self, entity):
        self.items[entity.id] = entity
        return entity

    def get(self, entity_id):
        return self.items.get(entity_id)

    def delete(self, entity_id):
        return self.items.pop(entity_id, None) is not None

    def list(self):
        return list(self.items.values())


def test_candidate_evaluation_rejection_is_durable():
    missions = MemoryRepository()
    plans = MemoryRepository()
    runs = MemoryRepository()
    mission = Mission(goal="improve planner")
    missions.save(mission)
    events = EventBus()

    class FakePlanning:
        def plan(self, request, planner):
            plan = PlanRevision(
                mission_id=request.mission_id,
                revision=1,
                decision_id="decision-1",
                graph_id="graph-1",
            )
            plans.save(plan)
            return plan, object()

        def cancel(self, plan_id, reason=None):
            plan = plans.get(plan_id)
            replacement = PlanRevision(
                mission_id=plan.mission_id,
                revision=plan.revision,
                decision_id=plan.decision_id,
                graph_id=plan.graph_id,
                status=PlanStatus.CANCELLED,
                id=plan.id,
                created_at=plan.created_at,
            )
            plans.save(replacement)
            return replacement

    class FakeIsolation:
        def create(self, *, source_mission, task_ids, metadata=None):
            candidate_mission = Mission(
                goal=source_mission.goal,
                metadata={
                    "candidate": True,
                    "source_mission_id": source_mission.id,
                },
            )
            missions.save(candidate_mission)

            from ocean.self_improvement.isolation import CandidateIsolation

            return CandidateIsolation(
                source_mission_id=source_mission.id,
                candidate_mission_id=candidate_mission.id,
                task_mappings=(),
            )

    engine = SelfImprovementEngine(
        missions=missions,
        plan_revisions=plans,
        runs=runs,
        planning=FakePlanning(),
        events=events,
        candidate_isolation=FakeIsolation(),
    )

    candidate = engine.create_candidate(
        mission_id=mission.id,
        hypothesis=ImprovementHypothesis(
            objective="improve planner",
            hypothesis="candidate planner is better",
            rationale="test",
        ),
        planner=object(),
    )

    from ocean.domain.verification import Verification
    from ocean.self_improvement.verification import CandidateVerificationService

    verifications = MemoryRepository()
    verification = Verification(
        task_id="candidate-task-1",
        method="candidate_regression_test",
        passed=False,
        evidence=["benchmark regression detected"],
        execution_id="execution-1",
    )
    verifications.save(verification)

    engine._candidate_verification = CandidateVerificationService(
        verifications=verifications,
        events=events,
    )

    evaluation = engine.evaluate(
        candidate_id=candidate.id,
        verification_id=verification.id,
        score=0.2,
        reason="candidate regressed",
    )

    assert evaluation.passed is False

    stored_runs = [
        run for run in runs.list()
        if run.candidate_id == candidate.id
    ]
    assert stored_runs
    stored_run = stored_runs[-1]
    assert stored_run is not None
    assert stored_run.status is ImprovementStatus.REJECTED


