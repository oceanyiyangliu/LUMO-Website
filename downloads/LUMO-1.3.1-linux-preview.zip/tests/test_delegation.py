from datetime import timedelta

import pytest

from ocean.core.clock import SYSTEM_CLOCK
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.event_sourcing.replay import EventReplayer, ReplayError
from ocean.delegation import (
    AuthorityEngine,
    DelegationController,
    DelegationGrant,
    DelegationRegistry,
    DelegationStatus,
)


def test_grant_has_stable_identity_and_active_status():
    grant = DelegationGrant(
        delegator_id="principal-a",
        delegate_id="principal-b",
        permissions=frozenset({"research.read"}),
    )
    assert grant.id.startswith("delegation_")
    assert grant.status is DelegationStatus.ACTIVE


def test_grant_rejects_empty_delegator():
    with pytest.raises(ValueError):
        DelegationGrant("", "principal-b", frozenset({"research.read"}))


def test_grant_rejects_empty_delegate():
    with pytest.raises(ValueError):
        DelegationGrant("principal-a", "", frozenset({"research.read"}))


def test_grant_rejects_self_delegation():
    with pytest.raises(ValueError):
        DelegationGrant("principal-a", "principal-a", frozenset({"research.read"}))


def test_grant_rejects_empty_permissions():
    with pytest.raises(ValueError):
        DelegationGrant("principal-a", "principal-b", frozenset())


def test_grant_rejects_blank_permission():
    with pytest.raises(ValueError):
        DelegationGrant("principal-a", "principal-b", frozenset({""}))


def test_grant_rejects_expiration_before_creation():
    created = SYSTEM_CLOCK.now()
    with pytest.raises(ValueError):
        DelegationGrant(
            "principal-a",
            "principal-b",
            frozenset({"research.read"}),
            created_at=created,
            expires_at=created,
        )


def test_grant_expiry_is_deterministic():
    created = SYSTEM_CLOCK.now()
    expires = created + timedelta(minutes=5)
    grant = DelegationGrant(
        "principal-a",
        "principal-b",
        frozenset({"research.read"}),
        created_at=created,
        expires_at=expires,
    )
    assert grant.expired(created + timedelta(minutes=4)) is False
    assert grant.expired(expires) is True


def test_registry_registers_and_resolves_active_grant():
    registry = DelegationRegistry()
    grant = DelegationGrant("principal-a", "principal-b", frozenset({"research.read"}))
    registry.register(grant)
    assert registry.get(grant.id) is grant
    assert registry.require(grant.id) is grant
    assert registry.incoming("principal-b") == (grant,)
    assert registry.outgoing("principal-a") == (grant,)


def test_registry_rejects_duplicate_grant():
    registry = DelegationRegistry()
    grant = DelegationGrant(
        "principal-a", "principal-b", frozenset({"research.read"}), id="delegation-1"
    )
    registry.register(grant)
    with pytest.raises(ValueError):
        registry.register(grant)


def test_registry_rejects_unknown_grant():
    with pytest.raises(KeyError):
        DelegationRegistry().require("delegation-missing")


def test_registry_revoke_removes_active_grant():
    registry = DelegationRegistry()
    grant = DelegationGrant("principal-a", "principal-b", frozenset({"research.read"}))
    registry.register(grant)
    revoked = registry.revoke(grant.id)
    assert revoked.id == grant.id
    assert revoked.status is DelegationStatus.REVOKED
    assert registry.get(grant.id) is None


def test_controller_creation_publishes_durable_event():
    events = EventBus()
    controller = DelegationController(event_bus=events)
    grant = controller.create(
        "principal-a",
        "principal-b",
        {"research.read", "research.write"},
        metadata={"source": "test"},
    )
    history = events.history()
    assert len(history) == 1
    assert history[0].type == "DelegationCreated"
    assert history[0].aggregate_type == "delegation"
    assert history[0].aggregate_id == grant.id
    assert history[0].payload["delegation_id"] == grant.id
    assert set(history[0].payload["permissions"]) == {"research.read", "research.write"}


def test_controller_revoke_publishes_durable_event():
    events = EventBus()
    controller = DelegationController(event_bus=events)
    grant = controller.create("principal-a", "principal-b", {"research.read"})
    controller.revoke(grant.id)
    assert [event.type for event in events.history()] == [
        "DelegationCreated",
        "DelegationRevoked",
    ]


def test_authority_resolves_active_permissions():
    registry = DelegationRegistry()
    grant = DelegationGrant(
        "principal-a",
        "principal-b",
        frozenset({"research.read", "research.write"}),
    )
    registry.register(grant)
    authority = AuthorityEngine(registry)
    assert authority.permissions("principal-b") == frozenset({"research.read", "research.write"})
    assert authority.can("principal-b", "research.read") is True
    assert authority.can("principal-b", "admin.delete") is False


def test_authority_ignores_expired_permissions():
    created = SYSTEM_CLOCK.now()
    registry = DelegationRegistry()
    grant = DelegationGrant(
        "principal-a",
        "principal-b",
        frozenset({"research.read"}),
        created_at=created,
        expires_at=created + timedelta(minutes=1),
    )
    registry.register(grant)
    authority = AuthorityEngine(registry)
    assert authority.can("principal-b", "research.read", now=created + timedelta(minutes=2)) is False


def test_authority_can_delegate_only_permissions_it_possesses():
    registry = DelegationRegistry()
    registry.register(
        DelegationGrant(
            "principal-a",
            "principal-b",
            frozenset({"research.read"}),
        )
    )
    authority = AuthorityEngine(registry)
    assert authority.can_delegate("principal-b", {"research.read"}) is True
    assert authority.can_delegate("principal-b", {"research.write"}) is False
    assert authority.can_delegate("principal-b", {"research.read", "research.write"}) is False


def test_authority_allows_empty_delegation_request():
    authority = AuthorityEngine(DelegationRegistry())
    assert authority.can_delegate("principal-a", set()) is True


def test_registry_rebuilds_from_created_event():
    event = Event(
        type="DelegationCreated",
        aggregate_type="delegation",
        aggregate_id="delegation-1",
        payload={
            "delegation_id": "delegation-1",
            "delegator_id": "principal-a",
            "delegate_id": "principal-b",
            "permissions": ["research.read"],
            "constraints": {"scope": "project-x"},
            "parent_grant_id": None,
            "expires_at": None,
            "metadata": {"source": "test"},
            "created_at": SYSTEM_CLOCK.now().isoformat(),
        },
    )
    registry = DelegationRegistry()
    registry.rebuild([event])
    grant = registry.require("delegation-1")
    assert grant.delegator_id == "principal-a"
    assert grant.delegate_id == "principal-b"
    assert grant.permissions == frozenset({"research.read"})
    assert grant.constraints == {"scope": "project-x"}


def test_registry_rebuild_applies_revocation():
    created = Event(
        type="DelegationCreated",
        payload={
            "delegation_id": "delegation-1",
            "delegator_id": "principal-a",
            "delegate_id": "principal-b",
            "permissions": ["research.read"],
            "created_at": SYSTEM_CLOCK.now().isoformat(),
        },
    )
    revoked = Event(
        type="DelegationRevoked",
        payload={"delegation_id": "delegation-1"},
    )
    registry = DelegationRegistry()
    registry.rebuild([created, revoked])
    assert registry.get("delegation-1") is None


def test_replayer_replays_delegation_after_principals_exist():
    now = SYSTEM_CLOCK.now().isoformat()
    events = [
        Event(
            type="PrincipalCreated",
            payload={
                "principal_id": "principal-a",
                "type": "human",
                "name": "operator",
                "metadata": {},
            },
        ),
        Event(
            type="PrincipalCreated",
            payload={
                "principal_id": "principal-b",
                "type": "agent",
                "name": "worker",
                "metadata": {},
            },
        ),
        Event(
            type="DelegationCreated",
            payload={
                "delegation_id": "delegation-1",
                "delegator_id": "principal-a",
                "delegate_id": "principal-b",
                "permissions": ["research.read"],
                "created_at": now,
            },
        ),
    ]
    state = EventReplayer().replay(events)
    assert state.delegations["delegation-1"].permissions == frozenset({"research.read"})


def test_replayer_rejects_unknown_delegator():
    event = Event(
        type="DelegationCreated",
        payload={
            "delegation_id": "delegation-1",
            "delegator_id": "principal-missing",
            "delegate_id": "principal-b",
            "permissions": ["research.read"],
            "created_at": SYSTEM_CLOCK.now().isoformat(),
        },
    )
    with pytest.raises(ReplayError):
        EventReplayer().replay([event])


def test_replayer_rejects_unknown_delegate():
    events = [
        Event(
            type="PrincipalCreated",
            payload={
                "principal_id": "principal-a",
                "type": "human",
                "name": "operator",
                "metadata": {},
            },
        ),
        Event(
            type="DelegationCreated",
            payload={
                "delegation_id": "delegation-1",
                "delegator_id": "principal-a",
                "delegate_id": "principal-missing",
                "permissions": ["research.read"],
                "created_at": SYSTEM_CLOCK.now().isoformat(),
            },
        ),
    ]
    with pytest.raises(ReplayError):
        EventReplayer().replay(events)


def test_replayer_rejects_duplicate_delegation_creation():
    payload = {
        "delegation_id": "delegation-1",
        "delegator_id": "principal-a",
        "delegate_id": "principal-b",
        "permissions": ["research.read"],
        "created_at": SYSTEM_CLOCK.now().isoformat(),
    }
    events = [
        Event(type="PrincipalCreated", payload={"principal_id": "principal-a", "type": "human", "name": "a", "metadata": {}}),
        Event(type="PrincipalCreated", payload={"principal_id": "principal-b", "type": "agent", "name": "b", "metadata": {}}),
        Event(type="DelegationCreated", payload=payload),
        Event(type="DelegationCreated", payload=payload),
    ]
    with pytest.raises(ReplayError):
        EventReplayer().replay(events)


def test_replayer_replays_delegation_revocation():
    now = SYSTEM_CLOCK.now().isoformat()
    events = [
        Event(type="PrincipalCreated", payload={"principal_id": "principal-a", "type": "human", "name": "a", "metadata": {}}),
        Event(type="PrincipalCreated", payload={"principal_id": "principal-b", "type": "agent", "name": "b", "metadata": {}}),
        Event(type="DelegationCreated", payload={
            "delegation_id": "delegation-1",
            "delegator_id": "principal-a",
            "delegate_id": "principal-b",
            "permissions": ["research.read"],
            "created_at": now,
        }),
        Event(type="DelegationRevoked", payload={"delegation_id": "delegation-1"}),
    ]
    state = EventReplayer().replay(events)
    assert "delegation-1" not in state.delegations
