from ocean.planning.advanced import *


def profiles():
    return discover_capabilities([CapabilityProfile("terminal", ("run",), privacy="local", max_context=1000), CapabilityProfile("http", ("request",), privacy="remote", max_context=1000)])


def test_discovery_and_validation():
    c=PlanCandidate("p1", ({"capability":"terminal","operation":"run","estimated_latency_seconds":2,"estimated_cost":1},), confidence=.8)
    d=validate_plan(c,profiles(),PlanConstraints(required_capabilities=frozenset({"terminal"}),privacy="local_only",max_latency_seconds=3,max_cost=2))
    assert d.valid and d.deadline_feasible and d.budget_feasible


def test_validation_rejects_unknown_and_budget():
    c=PlanCandidate("p1", ({"capability":"missing"},{"capability":"http","estimated_cost":9}))
    d=validate_plan(c,profiles(),PlanConstraints(max_cost=2))
    assert not d.valid
    assert any("unknown capability" in e for e in d.errors)
    assert any("cost" in e for e in d.errors)


def test_diff_and_receipt_are_deterministic():
    a=PlanCandidate("a",({"capability":"terminal"},))
    b=PlanCandidate("b",({"capability":"terminal"},{"capability":"http"}))
    d=diff_plans(a,b)
    assert d["fingerprint_changed"]
    diag=validate_plan(a,profiles(),PlanConstraints())
    assert deterministic_plan_receipt(a,diag)["fingerprint"] == a.fingerprint

def test_explainable_plan_score_and_approval_gate():
    c=PlanCandidate("p",({"capability":"terminal"},),confidence=.7); d=validate_plan(c,profiles(),PlanConstraints()); score=score_plan(c,d); assert score.total()>0; assert PlanApprovalGate(True,"external side effect").executable() is False
