from pathlib import Path

from ocean.platforms import LinuxAdapter, MacOSAdapter, WindowsAdapter


def test_macos_state_layout():
    adapter = MacOSAdapter()
    assert adapter.info.os == "macos"
    assert adapter.app_data_dir().parts[-2:] == ("Application Support", "LUMO")
    assert adapter.cache_dir().parts[-2:] == ("Caches", "LUMO")


def test_windows_state_layout(monkeypatch):
    monkeypatch.setenv("LOCALAPPDATA", r"C:\Users\Test\AppData\Local")
    adapter = WindowsAdapter()
    assert adapter.info.os == "windows"
    assert str(adapter.app_data_dir()).endswith("LUMO")
    assert str(adapter.config_dir()).endswith("LUMO/Config") or str(adapter.config_dir()).endswith(r"LUMO\Config")


def test_linux_respects_xdg(monkeypatch):
    monkeypatch.setenv("XDG_DATA_HOME", "/tmp/lumo-data")
    monkeypatch.setenv("XDG_CACHE_HOME", "/tmp/lumo-cache")
    monkeypatch.setenv("XDG_CONFIG_HOME", "/tmp/lumo-config")
    adapter = LinuxAdapter()
    assert adapter.info.os == "linux"
    assert adapter.app_data_dir() == Path("/tmp/lumo-data/LUMO")
    assert adapter.cache_dir() == Path("/tmp/lumo-cache/LUMO")
    assert adapter.config_dir() == Path("/tmp/lumo-config/LUMO")
