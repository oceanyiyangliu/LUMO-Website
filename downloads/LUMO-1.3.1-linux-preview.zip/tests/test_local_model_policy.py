import json
from unittest.mock import patch

import pytest

from ocean.local_model_policy import LocalModelAdmission
from ocean.resources.intelligence_governor import DeviceResources


class Response:
    def __init__(self, payload):
        self.payload = payload

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def read(self):
        return json.dumps(self.payload).encode()


def fake_urlopen(payload):
    return Response(payload)


def test_admission_accepts_model_at_or_below_limit():
    payload = {"models": [{"name": "qwen3:8b", "size": 8 * 1024**3, "digest": "sha"}]}
    roomy_device = DeviceResources(16 * 1024**3, 15 * 1024**3, 12 * 1024**3, 10, None, True)
    with patch("urllib.request.urlopen", return_value=fake_urlopen(payload)), patch("ocean.local_model_policy.sample_device_resources", return_value=roomy_device):
        metadata = LocalModelAdmission(max_gib=10).admit("qwen3:8b")
    assert metadata.name == "qwen3:8b"
    assert metadata.size_bytes == 8 * 1024**3


def test_admission_rejects_model_when_live_ram_is_too_low():
    payload = {"models": [{"name": "qwen3:8b", "size": 8 * 1024**3}]}
    constrained_device = DeviceResources(16 * 1024**3, 4 * 1024**3, 2 * 1024**3, 10, None, True)
    with patch("urllib.request.urlopen", return_value=fake_urlopen(payload)), patch("ocean.local_model_policy.sample_device_resources", return_value=constrained_device), patch.dict("os.environ", {"LUMO_LOCAL_RAM_WAIT_SECONDS": "0"}):
        with pytest.raises(RuntimeError, match="currently safe"):
            LocalModelAdmission(max_gib=10).admit("qwen3:8b")


def test_admission_waits_for_transient_ram_pressure(monkeypatch):
    payload = {"models": [{"name": "qwen3:0.6b", "size": int(0.6 * 1024**3)}]}
    blocked = DeviceResources(16 * 1024**3, 2 * 1024**3, 0, 10, None, True)
    admitted = DeviceResources(16 * 1024**3, 8 * 1024**3, 2 * 1024**3, 10, None, True)
    samples = iter((blocked, admitted))
    monkeypatch.setattr("ocean.local_model_policy.sample_device_resources", lambda: next(samples))
    monkeypatch.setenv("LUMO_LOCAL_RAM_WAIT_SECONDS", "2")
    monkeypatch.setenv("LUMO_LOCAL_RAM_POLL_SECONDS", "0.01")
    with patch("urllib.request.urlopen", return_value=fake_urlopen(payload)):
        metadata = LocalModelAdmission(max_gib=10).admit("qwen3:0.6b")
    assert metadata.name == "qwen3:0.6b"


def test_admission_rejects_model_over_hard_limit():
    payload = {"models": [{"name": "large", "size": 10 * 1024**3 + 1}]}
    with patch("urllib.request.urlopen", return_value=fake_urlopen(payload)):
        with pytest.raises(RuntimeError, match="exceeds the 10 GiB device limit"):
            LocalModelAdmission(max_gib=10).admit("large")


def test_admission_fails_closed_when_size_is_missing():
    payload = {"models": [{"name": "unknown", "size": 0}]}
    with patch("urllib.request.urlopen", return_value=fake_urlopen(payload)):
        with pytest.raises(RuntimeError, match="unverifiable size"):
            LocalModelAdmission(max_gib=10).admit("unknown")


def test_admission_fails_closed_when_registry_is_unreachable():
    with patch("urllib.request.urlopen", side_effect=OSError("offline")):
        with pytest.raises(RuntimeError, match="cannot verify local model size"):
            LocalModelAdmission(max_gib=10).admit("qwen3:8b")


def test_admission_rejects_missing_model():
    with patch("urllib.request.urlopen", return_value=fake_urlopen({"models": []})):
        with pytest.raises(RuntimeError, match="not installed"):
            LocalModelAdmission(max_gib=10).admit("missing")


def test_environment_cannot_raise_hard_ceiling(monkeypatch):
    monkeypatch.setenv("LUMO_LOCAL_MAX_MODEL_GIB", "64")
    admission = LocalModelAdmission(base_url="http://127.0.0.1:1")
    assert admission.max_gib == 64.0
