import pytest

from ocean.production_readiness import email_delivery_preflight, production_config_gates, validate_production_config


def test_production_config_fails_closed_when_missing():
    gates = production_config_gates({})
    assert gates == {
        "production_auth": False,
        "production_secrets": False,
        "production_tenant_store": False,
        "https_gateway": False,
        "monitoring_alerts": False,
        "email_delivery": False,
    }
    with pytest.raises(RuntimeError, match="production configuration is incomplete"):
        validate_production_config({})


def test_production_config_accepts_complete_configuration():
    env = {
        "LUMO_API_AUTH_REQUIRED": "1",
        "LUMO_API_SESSION_SECRET": "s" * 32,
        "LUMO_API_SESSION_BOOTSTRAP_SECRET": "b" * 16,
        "LUMO_TENANCY_STORE": "/srv/lumo/tenancy.sqlite3",
        "LUMO_TLS_CERT_FILE": "/etc/lumo/fullchain.pem",
        "LUMO_TLS_KEY_FILE": "/etc/lumo/privkey.pem",
        "LUMO_HEALTH_URL": "https://lumo.example/health",
        "LUMO_ALERT_FILE": "/var/log/lumo/alerts.jsonl",
            "LUMO_EMAIL_WEBHOOK_URL": "https://mail.example/lumo",
            "LUMO_EMAIL_WEBHOOK_SECRET": "e" * 16,
    }
    assert all(production_config_gates(env).values())
    validate_production_config(env)


def test_production_config_does_not_expose_secret_values():
    env = {
        "LUMO_API_AUTH_REQUIRED": "1",
        "LUMO_API_SESSION_SECRET": "super-secret-session-value-that-is-long-enough",
        "LUMO_API_SESSION_BOOTSTRAP_SECRET": "super-secret-bootstrap",
        "LUMO_TENANCY_STORE": "/srv/lumo/tenancy.sqlite3",
    }
    gates = production_config_gates(env)
    rendered = repr(gates)
    assert "super-secret" not in rendered


def test_direct_smtp_gate_requires_real_provider_credentials():
    env = {
        "LUMO_API_AUTH_REQUIRED": "1",
        "LUMO_API_SESSION_SECRET": "s" * 32,
        "LUMO_API_SESSION_BOOTSTRAP_SECRET": "b" * 16,
        "LUMO_EMAIL_DIRECT_SMTP": "1",
        "LUMO_EMAIL_FROM": "noreply@example.com",
    }
    assert not production_config_gates(env)["email_delivery"]
    preflight = email_delivery_preflight(env)
    assert not preflight["ready"]
    assert "LUMO_EMAIL_SMTP_HOST" in preflight["direct_smtp"]["missing"]
    assert "LUMO_EMAIL_SMTP_PASSWORD" in preflight["direct_smtp"]["missing"]


def test_email_preflight_does_not_expose_secret_values():
    env = {"RESEND_API_KEY": "super-secret-key", "LUMO_EMAIL_FROM": "noreply@example.com"}
    rendered = repr(email_delivery_preflight(env))
    assert "super-secret-key" not in rendered
    assert email_delivery_preflight(env)["provider"] == "resend"
