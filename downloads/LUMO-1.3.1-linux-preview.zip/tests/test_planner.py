import pytest

from ocean.domain.decision import Decision
from ocean.domain.mission import Mission
from ocean.domain.task import Task
from ocean.planning.planner import (
    Planner,
    PlanningContext,
    PlanningRequest,
    PlanningResult,
)


def context():
    mission = Mission(
        goal="Build an autonomous research system",
        id="mission-1",
    )
    task = Task(
        title="Research architecture",
        description="Investigate architecture options.",
        mission_id=mission.id,
        id="task-1",
    )
    return mission, task


def decision():
    return Decision(
        mission_id="mission-1",
        kind="strategy",
        objective="Build an autonomous research system",
        rationale="Parallel research reduces elapsed time.",
        id="decision-1",
    )


def test_planning_context_is_constructed_from_mission_state():
    mission, task = context()

    ctx = PlanningContext(
        mission=mission,
        tasks=(task,),
        metadata={"mode": "parallel"},
    )

    assert ctx.mission is mission
    assert ctx.tasks == (task,)
    assert ctx.metadata["mode"] == "parallel"


def test_planning_request_requires_matching_context():
    mission, task = context()

    request = PlanningRequest(
        mission_id=mission.id,
        objective="Create the best execution plan",
        context=PlanningContext(
            mission=mission,
            tasks=(task,),
        ),
    )

    assert request.mission_id == mission.id
    assert request.context.mission.id == mission.id


def test_planning_request_rejects_mismatched_context():
    mission, task = context()

    other = Mission(
        goal="Other mission",
        id="mission-2",
    )

    with pytest.raises(ValueError, match="does not match"):
        PlanningRequest(
            mission_id=mission.id,
            objective="Plan the mission",
            context=PlanningContext(
                mission=other,
                tasks=(task,),
            ),
        )


def test_planning_result_contains_decision_and_work_structure():
    result = PlanningResult(
        decision=decision(),
        nodes=("node-1",),
        edges=("edge-1",),
        metadata={"strategy": "parallel"},
    )

    assert result.decision.id == "decision-1"
    assert result.nodes == ("node-1",)
    assert result.edges == ("edge-1",)


def test_planning_result_requires_decision():
    with pytest.raises(ValueError, match="decision is required"):
        PlanningResult(
            decision=None,
            nodes=(),
            edges=(),
        )


def test_planner_protocol_defines_plan_operation():
    assert getattr(Planner, "plan")
