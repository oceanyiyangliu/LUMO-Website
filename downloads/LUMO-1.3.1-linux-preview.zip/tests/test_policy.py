from ocean.domain.enums import ApprovalDecision, RiskLevel
from ocean.domain.policy import PolicyContext, PolicyEngine


def test_default_risk_mapping():
    engine = PolicyEngine()
    assert engine.evaluate(
        PolicyContext("filesystem", "create_folder", RiskLevel.SAFE)
    ) == ApprovalDecision.AUTOMATIC
    assert engine.evaluate(
        PolicyContext("filesystem", "delete_file", RiskLevel.IMPORTANT)
    ) == ApprovalDecision.USER_CONFIRMATION_REQUIRED
    assert engine.evaluate(
        PolicyContext("network", "wire_transfer", RiskLevel.HIGH)
    ) == ApprovalDecision.EXPLICIT_APPROVAL_REQUIRED


def test_requires_human_helper():
    engine = PolicyEngine()
    assert engine.requires_human(ApprovalDecision.EXPLICIT_APPROVAL_REQUIRED)
    assert not engine.requires_human(ApprovalDecision.AUTOMATIC_LOGGED)


def test_override_can_escalate_beyond_default_risk_level():
    engine = PolicyEngine()

    def deleting_outside_tmp_is_high_risk(ctx: PolicyContext) -> ApprovalDecision:
        path = ctx.metadata.get("path", "")
        if path.startswith("/tmp"):
            return ApprovalDecision.AUTOMATIC_LOGGED
        return ApprovalDecision.EXPLICIT_APPROVAL_REQUIRED

    engine.register_override("filesystem", "delete_file", deleting_outside_tmp_is_high_risk)

    tmp_ctx = PolicyContext("filesystem", "delete_file", RiskLevel.IMPORTANT, {"path": "/tmp/scratch.txt"})
    home_ctx = PolicyContext("filesystem", "delete_file", RiskLevel.IMPORTANT, {"path": "/Users/me/Documents/thesis.docx"})

    assert engine.evaluate(tmp_ctx) == ApprovalDecision.AUTOMATIC_LOGGED
    assert engine.evaluate(home_ctx) == ApprovalDecision.EXPLICIT_APPROVAL_REQUIRED


def test_override_does_not_affect_unrelated_operations():
    engine = PolicyEngine()
    engine.register_override("filesystem", "delete_file", lambda ctx: ApprovalDecision.DENIED)
    result = engine.evaluate(PolicyContext("filesystem", "create_folder", RiskLevel.SAFE))
    assert result == ApprovalDecision.AUTOMATIC
