from datetime import timedelta

import pytest

from ocean.authentication import (
    AuthenticationEngine,
    AuthenticationRequest,
    CredentialController,
    CredentialRegistry,
    CredentialStatus,
)
from ocean.core.clock import SYSTEM_CLOCK
from ocean.domain.event_bus import EventBus


def test_credential_identity_and_defaults():
    c = __import__("ocean.authentication", fromlist=["Credential"]).Credential(
        principal_id="p1",
        kind="test",
    )
    assert c.principal_id == "p1"
    assert c.kind == "test"
    assert c.status is CredentialStatus.ACTIVE
    assert c.id.startswith("credential_")


@pytest.mark.parametrize(
    "kwargs",
    [
        {"principal_id": "", "kind": "test"},
        {"principal_id": "p1", "kind": ""},
    ],
)
def test_credential_rejects_invalid_identity(kwargs):
    Credential = __import__("ocean.authentication", fromlist=["Credential"]).Credential
    with pytest.raises(ValueError):
        Credential(**kwargs)


def test_credential_rejects_expiration_before_creation():
    Credential = __import__("ocean.authentication", fromlist=["Credential"]).Credential
    created = SYSTEM_CLOCK.now()
    with pytest.raises(ValueError):
        Credential(
            principal_id="p1",
            kind="test",
            created_at=created,
            expires_at=created,
        )


def test_credential_expiration():
    Credential = __import__("ocean.authentication", fromlist=["Credential"]).Credential
    created = SYSTEM_CLOCK.now()
    c = Credential(
        principal_id="p1",
        kind="test",
        created_at=created,
        expires_at=created + timedelta(seconds=10),
    )
    assert not c.expired(created + timedelta(seconds=9))
    assert c.expired(created + timedelta(seconds=10))


def test_registry_register_get_and_require():
    Credential = __import__("ocean.authentication", fromlist=["Credential"]).Credential
    registry = CredentialRegistry()
    c = Credential(principal_id="p1", kind="test")
    registry.register(c)
    assert registry.get(c.id) == c
    assert registry.require(c.id) == c


def test_registry_rejects_duplicate():
    Credential = __import__("ocean.authentication", fromlist=["Credential"]).Credential
    registry = CredentialRegistry()
    c = Credential(principal_id="p1", kind="test")
    registry.register(c)
    with pytest.raises(KeyError):
        registry.register(c)


def test_registry_revoke_removes_active_credential():
    Credential = __import__("ocean.authentication", fromlist=["Credential"]).Credential
    registry = CredentialRegistry()
    c = Credential(principal_id="p1", kind="test")
    registry.register(c)
    revoked = registry.revoke(c.id)
    assert revoked.status is CredentialStatus.REVOKED
    assert registry.get(c.id) is None


def test_authentication_unknown_credential():
    engine = AuthenticationEngine(CredentialRegistry(), lambda proof, credential, metadata: True)
    result = engine.authenticate(AuthenticationRequest("missing", "proof"))
    assert not result.authenticated
    assert result.principal_id is None
    assert result.reasons == ("unknown credential",)


def test_authentication_invalid_proof():
    Credential = __import__("ocean.authentication", fromlist=["Credential"]).Credential
    registry = CredentialRegistry()
    c = Credential(principal_id="p1", kind="test")
    registry.register(c)
    engine = AuthenticationEngine(registry, lambda proof, credential, metadata: proof == "correct")
    result = engine.authenticate(AuthenticationRequest(c.id, "wrong"))
    assert not result.authenticated
    assert result.reasons == ("invalid credential proof",)


def test_authentication_success_returns_principal():
    Credential = __import__("ocean.authentication", fromlist=["Credential"]).Credential
    registry = CredentialRegistry()
    c = Credential(principal_id="p1", kind="test")
    registry.register(c)
    engine = AuthenticationEngine(registry, lambda proof, credential, metadata: proof == "correct")
    result = engine.authenticate(AuthenticationRequest(c.id, "correct"))
    assert result.authenticated
    assert result.principal_id == "p1"


def test_authentication_expired_credential():
    Credential = __import__("ocean.authentication", fromlist=["Credential"]).Credential
    created = SYSTEM_CLOCK.now()
    c = Credential(
        principal_id="p1",
        kind="test",
        created_at=created - timedelta(seconds=10),
        expires_at=created - timedelta(seconds=1),
    )
    registry = CredentialRegistry()
    registry.register(c)
    engine = AuthenticationEngine(registry, lambda proof, credential, metadata: True)
    result = engine.authenticate(AuthenticationRequest(c.id, "anything"))
    assert not result.authenticated
    assert result.reasons == ("credential expired",)


def test_verifier_failure_does_not_escape_boundary():
    Credential = __import__("ocean.authentication", fromlist=["Credential"]).Credential
    registry = CredentialRegistry()
    c = Credential(principal_id="p1", kind="test")
    registry.register(c)

    def verifier(proof, credential, metadata):
        raise RuntimeError("boom")

    result = AuthenticationEngine(registry, verifier).authenticate(
        AuthenticationRequest(c.id, "anything")
    )
    assert not result.authenticated
    assert result.reasons == ("credential verification failed",)


def test_controller_publishes_credential_created():
    Credential = __import__("ocean.authentication", fromlist=["Credential"]).Credential
    registry = CredentialRegistry()
    bus = EventBus()
    controller = CredentialController(registry, bus)
    c = controller.create(principal_id="p1", kind="test")
    assert registry.require(c.id) == c
    event = bus.history()[-1]
    assert event.type == "CredentialCreated"
    assert event.payload["credential_id"] == c.id
    assert event.payload["principal_id"] == "p1"
    assert "proof" not in event.payload
    assert "secret" not in event.payload


def test_controller_revoke_publishes_event():
    Credential = __import__("ocean.authentication", fromlist=["Credential"]).Credential
    registry = CredentialRegistry()
    bus = EventBus()
    controller = CredentialController(registry, bus)
    c = controller.create(principal_id="p1", kind="test")
    controller.revoke(c.id)
    event = bus.history()[-1]
    assert event.type == "CredentialRevoked"
    assert event.payload["credential_id"] == c.id


def test_registry_rebuild_created_and_revoked():
    Credential = __import__("ocean.authentication", fromlist=["Credential"]).Credential
    registry = CredentialRegistry()
    bus = EventBus()
    controller = CredentialController(registry, bus)
    c = controller.create(principal_id="p1", kind="test")
    controller.revoke(c.id)

    rebuilt = CredentialRegistry()
    rebuilt.rebuild(bus.history())
    assert rebuilt.get(c.id) is None


def test_authentication_request_is_immutable():
    request = AuthenticationRequest("credential_1", "proof")
    with pytest.raises(Exception):
        request.credential_id = "other"


def test_authentication_decision_failed_property():
    from ocean.authentication import AuthenticationDecision
    assert not AuthenticationDecision(True, "p1").failed
    assert AuthenticationDecision(False).failed

from ocean.domain.event import Event
from ocean.event_sourcing.replay import EventReplayer, ReplayError
from ocean.identity import Principal, PrincipalType


def test_replay_credential_created_after_principal():
    principal = Principal(type=PrincipalType.AGENT, name="agent")
    credential = __import__("ocean.authentication", fromlist=["Credential"]).Credential(
        principal_id=principal.id,
        kind="test",
    )

    events = [
        Event(
            type="PrincipalCreated",
            payload={
                "principal_id": principal.id,
                "type": principal.type.value,
                "name": principal.name,
                "metadata": {},
            },
        ),
        Event(
            type="CredentialCreated",
            payload={
                "credential_id": credential.id,
                "principal_id": credential.principal_id,
                "kind": credential.kind,
                "metadata": {},
                "expires_at": credential.expires_at,
                "created_at": credential.created_at,
            },
        ),
    ]

    state = EventReplayer().replay(events)
    assert state.credentials[credential.id].principal_id == principal.id


def test_replay_rejects_credential_for_unknown_principal():
    Credential = __import__("ocean.authentication", fromlist=["Credential"]).Credential
    credential = Credential(principal_id="missing", kind="test")

    event = Event(
        type="CredentialCreated",
        payload={
            "credential_id": credential.id,
            "principal_id": credential.principal_id,
            "kind": credential.kind,
            "metadata": {},
            "expires_at": credential.expires_at,
            "created_at": credential.created_at,
        },
    )

    with pytest.raises(ReplayError, match="unknown principal"):
        EventReplayer().replay([event])


def test_replay_rejects_duplicate_credential_creation():
    principal = Principal(type=PrincipalType.AGENT, name="agent")
    credential = __import__("ocean.authentication", fromlist=["Credential"]).Credential(
        principal_id=principal.id,
        kind="test",
    )

    principal_event = Event(
        type="PrincipalCreated",
        payload={
            "principal_id": principal.id,
            "type": principal.type.value,
            "name": principal.name,
            "metadata": {},
        },
    )
    credential_event = Event(
        type="CredentialCreated",
        payload={
            "credential_id": credential.id,
            "principal_id": credential.principal_id,
            "kind": credential.kind,
            "metadata": {},
            "expires_at": credential.expires_at,
            "created_at": credential.created_at,
        },
    )

    with pytest.raises(ReplayError, match="duplicate credential"):
        EventReplayer().replay(
            [principal_event, credential_event, credential_event]
        )


def test_replay_credential_revoked():
    principal = Principal(type=PrincipalType.AGENT, name="agent")
    credential = __import__("ocean.authentication", fromlist=["Credential"]).Credential(
        principal_id=principal.id,
        kind="test",
    )

    events = [
        Event(
            type="PrincipalCreated",
            payload={
                "principal_id": principal.id,
                "type": principal.type.value,
                "name": principal.name,
                "metadata": {},
            },
        ),
        Event(
            type="CredentialCreated",
            payload={
                "credential_id": credential.id,
                "principal_id": credential.principal_id,
                "kind": credential.kind,
                "metadata": {},
                "expires_at": credential.expires_at,
                "created_at": credential.created_at,
            },
        ),
        Event(
            type="CredentialRevoked",
            payload={
                "credential_id": credential.id,
                "principal_id": credential.principal_id,
            },
        ),
    ]

    state = EventReplayer().replay(events)
    assert credential.id not in state.credentials


def test_replay_rejects_unknown_credential_revocation():
    event = Event(
        type="CredentialRevoked",
        payload={"credential_id": "missing"},
    )

    with pytest.raises(ReplayError, match="unknown credential"):
        EventReplayer().replay([event])
