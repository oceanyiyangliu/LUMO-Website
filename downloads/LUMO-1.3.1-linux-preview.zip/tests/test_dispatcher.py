from ocean.domain.event import Event

from eventing.dispatcher import EventDispatcher


def test_matching_handler_receives_event():
    dispatcher = EventDispatcher()
    received = []

    dispatcher.subscribe("task_created", received.append)

    event = Event(type="task_created")
    failures = dispatcher.dispatch(event)

    assert received == [event]
    assert failures == []


def test_handler_does_not_receive_other_event_types():
    dispatcher = EventDispatcher()
    received = []

    dispatcher.subscribe("task_created", received.append)

    dispatcher.dispatch(Event(type="task_failed"))

    assert received == []


def test_multiple_handlers_receive_event():
    dispatcher = EventDispatcher()
    received = []

    dispatcher.subscribe("task_created", received.append)
    dispatcher.subscribe("task_created", received.append)

    event = Event(type="task_created")
    dispatcher.dispatch(event)

    assert received == [event, event]


def test_broken_handler_does_not_block_other_handlers():
    dispatcher = EventDispatcher()
    received = []

    def broken(_event):
        raise RuntimeError("boom")

    dispatcher.subscribe("task_created", broken)
    dispatcher.subscribe("task_created", received.append)

    failures = dispatcher.dispatch(Event(type="task_created"))

    assert received
    assert len(failures) == 1
    assert isinstance(failures[0].error, RuntimeError)


def test_unsubscribe_stops_delivery():
    dispatcher = EventDispatcher()
    received = []

    dispatcher.subscribe("task_created", received.append)
    dispatcher.unsubscribe("task_created", received.append)

    dispatcher.dispatch(Event(type="task_created"))

    assert received == []


def test_unsubscribe_missing_handler_is_safe():
    dispatcher = EventDispatcher()

    dispatcher.unsubscribe("task_created", lambda _event: None)

    assert dispatcher.dispatch(Event(type="task_created")) == []
def test_wildcard_handler_receives_everything():
    dispatcher = EventDispatcher()
    received = []

    dispatcher.subscribe("*", received.append)

    dispatcher.dispatch(Event(type="task_completed"))
    dispatcher.dispatch(Event(type="task_failed"))

    assert len(received) == 2
