from ocean.billing import BillingLifecycle, BillingLifecycleProjector

def test_billing_lifecycle_projection():
    p=BillingLifecycleProjector(); s=BillingLifecycle("active","pro")
    s=p.apply(s,{"type":"payment.failed"}); assert s.payment_state=="failed" and s.invoice_state=="open"
    s=p.apply(s,{"type":"grace.started","grace_until":"tomorrow"}); assert s.grace_until=="tomorrow"
    s=p.apply(s,{"type":"refund.created"}); assert s.refunded and s.payment_state=="refunded"


def test_stripe_checkout_adapter_uses_configured_price_and_never_logs_secret(monkeypatch):
    from ocean.billing import StripeBillingProvider
    captured = {}
    class Response:
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def read(self, n=-1): return b'{"id":"cs_test","url":"https://checkout.stripe.test/cs"}'
    def fake_urlopen(request, timeout):
        captured["url"] = request.full_url
        captured["auth"] = request.headers["Authorization"]
        captured["body"] = request.data.decode()
        captured["timeout"] = timeout
        return Response()
    monkeypatch.setenv("STRIPE_PRICE_ID_PRO", "price_test")
    monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)
    provider = StripeBillingProvider("sk_test_secret")
    result = provider.create_checkout(account_id="acct_1", plan_id="pro", success_url="https://lumo.example/success", cancel_url="https://lumo.example/cancel")
    assert result["id"] == "cs_test"
    assert "price_test" in captured["body"]
    assert "acct_1" in captured["body"]
    assert captured["auth"] == "Bearer sk_test_secret"
    assert "sk_test_secret" not in captured["body"]
    assert captured["timeout"] == 15


def test_stripe_tax_adapter_posts_tax_calculation(monkeypatch):
    from ocean.billing import StripeBillingProvider
    captured = {}
    class Response:
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def read(self, n=-1): return b'{"id":"taxcalc_1","tax_amount_exclusive":100}'
    def fake_urlopen(request, timeout):
        captured["path"] = request.full_url
        captured["body"] = request.data.decode()
        return Response()
    monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)
    result = StripeBillingProvider("sk_test_secret").calculate_tax(amount_cents=2900, currency="USD", account_id="acct_1")
    assert result["id"] == "taxcalc_1"
    assert captured["path"].endswith("/v1/tax/calculations")
    assert "2900" in captured["body"]
