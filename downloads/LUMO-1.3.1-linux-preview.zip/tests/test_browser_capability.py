from __future__ import annotations

from pathlib import Path

import pytest

from ocean.capabilities.browser import PlaywrightBrowserExecutor, browser_spec
from ocean.domain.capability import CapabilityIsolationPolicy
from ocean.domain.enums import RiskLevel
from runtime.types import ExecutionRequest


def test_browser_spec_is_dom_based_and_isolated():
    spec = browser_spec()
    assert spec.name == "browser"
    assert spec.requires_permissions == {"browser.use"}
    assert spec.execution_policy.isolation is CapabilityIsolationPolicy.IN_PROCESS_SAFE
    assert set(spec.operations) == {"navigate", "accessibility_snapshot", "click_role", "fill_role", "click", "fill", "extract", "screenshot"}
    assert spec.operation("extract").risk_level is RiskLevel.LOW
    assert spec.operation("click").risk_level is RiskLevel.HIGH


def test_browser_workers_get_distinct_persistent_profiles(tmp_path: Path):
    first = PlaywrightBrowserExecutor(worker_id="alpha", root=tmp_path)
    second = PlaywrightBrowserExecutor(worker_id="beta", root=tmp_path)
    try:
        assert first.profile_dir != second.profile_dir
        assert first.profile_dir.parent == second.profile_dir.parent == tmp_path
    finally:
        first.close()
        second.close()


def test_browser_rejects_non_http_urls(tmp_path: Path):
    worker = PlaywrightBrowserExecutor(worker_id="validation", root=tmp_path)
    try:
        result = worker.execute(
            ExecutionRequest(task_id="t", capability="browser", operation="navigate", arguments={"url": "file:///etc/passwd"}),
            None,
        )
        assert result.success is False
        assert "http://" in (result.error or "")
    finally:
        worker.close()


def test_browser_blocks_unsafe_page_schemes():
    from ocean.capabilities.browser import PlaywrightBrowserExecutor
    import pytest

    for url in ("file:///etc/hosts", "chrome://settings", "javascript:alert(1)"):
        with pytest.raises(RuntimeError):
            PlaywrightBrowserExecutor._assert_safe_page_url(url)


def test_browser_allows_web_page_schemes():
    from ocean.capabilities.browser import PlaywrightBrowserExecutor
    for url in ("https://example.com", "http://example.com", "about:blank"):
        PlaywrightBrowserExecutor._assert_safe_page_url(url)


def test_browser_blocks_private_network_targets():
    from ocean.capabilities.browser import PlaywrightBrowserExecutor
    import pytest
    for url in (
        "http://127.0.0.1:8765/api/health",
        "http://localhost:3000",
        "http://10.0.0.1",
        "http://192.168.1.1",
        "http://169.254.169.254/latest/meta-data/",
        "http://[::1]:8765/",
    ):
        with pytest.raises(RuntimeError):
            PlaywrightBrowserExecutor._assert_safe_page_url(url)


def test_browser_blocks_url_userinfo():
    from ocean.capabilities.browser import PlaywrightBrowserExecutor
    import pytest
    with pytest.raises(RuntimeError):
        PlaywrightBrowserExecutor._assert_safe_page_url("https://user:pass@example.com/")
