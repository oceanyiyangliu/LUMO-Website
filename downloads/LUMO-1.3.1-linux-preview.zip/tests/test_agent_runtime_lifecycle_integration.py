import time

from ocean.domain.agent import Agent
from ocean.domain.enums import AgentStatus
from ocean.domain.event_bus import EventBus

from runtime import (
    AgentController,
    AgentExecutionLifecycle,
    AgentRegistry,
    AgentRuntime,
    ExecutionRequest,
    ExecutionSupervisor,
    Scheduler,
)

from tests.test_runtime import make_runtime
from tests.test_scheduler import SuccessfulExecutor


def make_request(*, execution_id="exec-1"):
    return ExecutionRequest(
        task_id="task-1",
        capability="compute",
        operation="run",
        execution_id=execution_id,
    )


def make_stack():
    bus = EventBus()

    execution_runtime = make_runtime(SuccessfulExecutor())
    supervisor = ExecutionSupervisor(
        execution_runtime,
        max_workers=4,
    )

    scheduler = Scheduler(
        supervisor,
        event_bus=bus,
    )

    registry = AgentRegistry()
    controller = AgentController(event_bus=bus)

    runtime = AgentRuntime(
        scheduler,
        registry=registry,
        controller=controller,
    )

    lifecycle = AgentExecutionLifecycle(
        event_bus=bus,
        registry=registry,
        controller=controller,
    )

    agent = Agent(
        id="agent-1",
        name="Test Agent",
        role="worker",
        capabilities={"compute"},
    )
    registry.register(agent)

    return (
        bus,
        runtime,
        scheduler,
        supervisor,
        lifecycle,
        agent,
    )


def test_submit_queues_without_activating_agent():
    (
        bus,
        runtime,
        scheduler,
        supervisor,
        lifecycle,
        agent,
    ) = make_stack()

    try:
        item = runtime.submit(
            agent.id,
            make_request(),
        )

        assert item.state.value == "queued"
        assert agent.status == AgentStatus.IDLE
        assert agent.current_task_id is None
    finally:
        supervisor.shutdown()


def test_dispatch_activates_agent_through_event_bus():
    (
        bus,
        runtime,
        scheduler,
        supervisor,
        lifecycle,
        agent,
    ) = make_stack()

    try:
        runtime.submit(
            agent.id,
            make_request(),
        )

        assert agent.status == AgentStatus.IDLE

        item = scheduler.dispatch_next()

        assert item is not None
        assert item.state.value == "dispatched"
        assert agent.status == AgentStatus.RUNNING
        assert agent.current_task_id == "task-1"
    finally:
        supervisor.shutdown()


def test_completion_returns_agent_to_idle_through_event_bus():
    (
        bus,
        runtime,
        scheduler,
        supervisor,
        lifecycle,
        agent,
    ) = make_stack()

    try:
        runtime.submit(
            agent.id,
            make_request(),
        )

        item = scheduler.dispatch_next()

        assert item is not None
        assert agent.status == AgentStatus.RUNNING

        deadline = time.monotonic() + 2.0
        while item.handle is None or item.handle.result is None:
            if time.monotonic() >= deadline:
                raise AssertionError(
                    "execution did not complete within timeout"
                )
            time.sleep(0.001)

        scheduler.reconcile(item.execution_id)

        assert agent.status == AgentStatus.IDLE
        assert agent.current_task_id is None
    finally:
        supervisor.shutdown()


def test_failed_execution_returns_agent_to_idle():
    (
        bus,
        runtime,
        scheduler,
        supervisor,
        lifecycle,
        agent,
    ) = make_stack()

    try:
        runtime.submit(
            agent.id,
            make_request(),
        )

        item = scheduler.dispatch_next()

        assert item is not None
        assert agent.status == AgentStatus.RUNNING

        deadline = time.monotonic() + 2.0
        while item.handle is None or item.handle.result is None:
            if time.monotonic() >= deadline:
                raise AssertionError(
                    "execution did not complete within timeout"
                )
            time.sleep(0.001)

        scheduler.reconcile(item.execution_id)

        assert agent.status == AgentStatus.IDLE
        assert agent.current_task_id is None
    finally:
        supervisor.shutdown()


def test_scheduler_events_contain_agent_id():
    bus = EventBus()

    execution_runtime = make_runtime(SuccessfulExecutor())
    supervisor = ExecutionSupervisor(execution_runtime)

    scheduler = Scheduler(
        supervisor,
        event_bus=bus,
    )

    try:
        request = make_request()
        request = ExecutionRequest(
            task_id=request.task_id,
            capability=request.capability,
            operation=request.operation,
            execution_id=request.execution_id,
            agent_id="agent-1",
        )

        scheduler.enqueue(request)

        event = bus.history("ScheduledExecutionQueued")[0]

        assert event.payload["agent_id"] == "agent-1"
    finally:
        supervisor.shutdown()
