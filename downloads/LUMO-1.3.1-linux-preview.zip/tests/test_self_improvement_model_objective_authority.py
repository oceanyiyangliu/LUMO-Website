from ocean.self_improvement.model_provider import DeterministicModelProvider, ImprovementModelRequest, ModelProviderBoundary
from ocean.self_improvement.types import ImprovementHypothesis
from ocean.self_improvement.code_modification import CodeChange, CodeModification


def test_system_objective_is_authoritative_over_model_restatement():
    requested = "Harden candidate persistence"
    provider = DeterministicModelProvider(
        hypothesis=ImprovementHypothesis(
            objective="rewritten objective",
            hypothesis="make persistence safer",
            rationale="test",
            success_criteria=("tests pass",),
            constraints={},
        ),
        code_modification=CodeModification(
            candidate_id="candidate-1",
            changes=(CodeChange("x.py", "x = 1\n"),),
            rationale="test",
        ),
    )
    boundary = ModelProviderBoundary(provider)
    request = ImprovementModelRequest(
        candidate_id="candidate-1",
        objective=requested,
    )
    proposal = boundary.propose(request)
    # Deterministic providers may still return their own hypothesis, but the
    # production JSON boundary rewrites model objective identity. This test
    # documents the contract without requiring a network provider.
    assert proposal.candidate_id == request.candidate_id
