from ocean.cognition import ActionBoundary, CognitionMode, CognitiveRouter, CompletionContract, WorldContext


def test_router_is_fast_for_clear_actions():
    decision = CognitiveRouter().route("open Calculator and calculate 123 + 456")
    assert decision.mode is CognitionMode.REFLEX
    assert decision.effort == "low"


def test_router_escalates_complex_missions():
    decision = CognitiveRouter().route("create a polished presentation with multiple slides")
    assert decision.mode is CognitionMode.STRATEGIC
    assert decision.effort == "high"


def test_router_escalates_after_repeated_failure():
    decision = CognitiveRouter().route("open the editor", failures=2)
    assert decision.mode is CognitionMode.CRITICAL
    assert decision.effort == "high"


def test_action_boundary_rejects_coordinates_outside_observed_image():
    world = WorldContext(image_width=800, image_height=600)
    ok, reason = ActionBoundary().validate("click", {"x": 801, "y": 20}, world=world, objective="click the button")
    assert ok is False
    assert "outside" in reason


def test_action_boundary_accepts_coordinates_inside_observed_image():
    world = WorldContext(image_width=800, image_height=600)
    ok, reason = ActionBoundary().validate("click", {"x": 799, "y": 599}, world=world, objective="click the button")
    assert ok is True
    assert reason == "ok"


def test_completion_contract_requires_requested_calculation_action():
    contract = CompletionContract.from_objective("open Calculator and calculate 123 + 456")
    assert contract.satisfied(["launch_app"]) is False
    assert contract.satisfied(["launch_app", "key_press"]) is True


def test_completion_contract_is_permissive_for_observation_only():
    contract = CompletionContract.from_objective("inspect the current screen")
    assert contract.satisfied([]) is True
