from __future__ import annotations

from dataclasses import dataclass

import pytest

from ocean.domain.assignment import Assignment
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.domain.enums import AssignmentStatus
from ocean.execution.compiler import ExecutionPlan, ExecutionStep
from ocean.orchestration.execution_plan_coordinator import (
    ExecutionPlanCoordinator,
)
from ocean.orchestration.execution_plan_runner import (
    ExecutionPlanRunResult,
)
from ocean.orchestration.types import ExecutionIntent
from persistence.in_memory import InMemoryRepository


@dataclass
class FakeProvider:
    plan: ExecutionPlan

    def get(self, plan_revision_id: str) -> ExecutionPlan:
        assert plan_revision_id == self.plan.plan_revision_id
        return self.plan


class FakeRunner:
    def __init__(self):
        self.calls = []

    def start_frontier(
        self,
        plan,
        *,
        completed_node_ids,
        node_execution_ids,
        submitted_node_ids,
        mode=None,
        priority=0,
    ):
        self.calls.append(
            {
                "plan": plan,
                "completed_node_ids": set(completed_node_ids),
                "node_execution_ids": dict(node_execution_ids),
                "submitted_node_ids": set(submitted_node_ids),
                "mode": mode,
                "priority": priority,
            }
        )
        return ExecutionPlanRunResult(
            plan_revision_id=plan.plan_revision_id
        )


def make_plan() -> ExecutionPlan:
    intent = ExecutionIntent(
        capability="test",
        operation="run",
    )

    return ExecutionPlan(
        mission_id="mission-1",
        plan_revision_id="plan-1",
        steps=(
            ExecutionStep(
                node_id="node-a",
                task_id="task-a",
                intent=intent,
            ),
            ExecutionStep(
                node_id="node-b",
                task_id="task-b",
                intent=intent,
                depends_on_node_ids=("node-a",),
            ),
            ExecutionStep(
                node_id="node-c",
                task_id="task-c",
                intent=intent,
                depends_on_node_ids=("node-b",),
            ),
        ),
    )


def make_assignment(
    *,
    node_id: str,
    execution_id: str,
    status: AssignmentStatus,
) -> Assignment:
    return Assignment(
        task_id=f"task-{node_id[-1]}",
        agent_id="agent-1",
        mission_id="mission-1",
        status=status,
        execution_id=execution_id,
        metadata={
            "execution_plan_id": "plan-1",
            "execution_node_id": node_id,
        },
    )


def make_coordinator(assignments):
    events = EventBus()
    provider = FakeProvider(make_plan())
    runner = FakeRunner()

    coordinator = ExecutionPlanCoordinator(
        events=events,
        assignments=assignments,
        plan_provider=provider,
        runner=runner,
    )

    return coordinator, events, runner


def test_requires_dependencies():
    with pytest.raises(ValueError, match="events is required"):
        ExecutionPlanCoordinator(
            events=None,
            assignments=InMemoryRepository(),
            plan_provider=FakeProvider(make_plan()),
            runner=FakeRunner(),
        )


def test_ignores_non_plan_assignment():
    assignments = InMemoryRepository()
    assignment = Assignment(
        task_id="task-normal",
        agent_id="agent-1",
        status=AssignmentStatus.COMPLETED,
        execution_id="exec-normal",
    )
    assignments.save(assignment)

    coordinator, events, runner = make_coordinator(assignments)

    events.publish(
        Event(
            type="TaskAssignmentCompleted",
            payload={"assignment_id": assignment.id},
            aggregate_type="assignment",
            aggregate_id=assignment.id,
        )
    )

    assert runner.calls == []


def test_completed_assignment_advances_next_frontier():
    assignments = InMemoryRepository()

    assignment = make_assignment(
        node_id="node-a",
        execution_id="exec-a",
        status=AssignmentStatus.COMPLETED,
    )
    assignments.save(assignment)

    coordinator, events, runner = make_coordinator(assignments)

    events.publish(
        Event(
            type="TaskAssignmentCompleted",
            payload={"assignment_id": assignment.id},
            aggregate_type="assignment",
            aggregate_id=assignment.id,
        )
    )

    assert len(runner.calls) == 1
    call = runner.calls[0]

    assert call["completed_node_ids"] == {"node-a"}
    assert call["node_execution_ids"] == {"node-a": "exec-a"}
    assert call["submitted_node_ids"] == {"node-a"}


def test_progress_is_reconstructed_from_all_completed_assignments():
    assignments = InMemoryRepository()

    first = make_assignment(
        node_id="node-a",
        execution_id="exec-a",
        status=AssignmentStatus.COMPLETED,
    )
    second = make_assignment(
        node_id="node-b",
        execution_id="exec-b",
        status=AssignmentStatus.COMPLETED,
    )

    assignments.save(first)
    assignments.save(second)

    coordinator, _, runner = make_coordinator(assignments)

    coordinator.advance("plan-1")

    call = runner.calls[0]

    assert call["completed_node_ids"] == {"node-a", "node-b"}
    assert call["node_execution_ids"] == {
        "node-a": "exec-a",
        "node-b": "exec-b",
    }
    assert call["submitted_node_ids"] == {"node-a", "node-b"}


def test_active_assignment_does_not_count_as_completed():
    assignments = InMemoryRepository()

    assignment = make_assignment(
        node_id="node-a",
        execution_id="exec-a",
        status=AssignmentStatus.ACTIVE,
    )
    assignments.save(assignment)

    coordinator, _, runner = make_coordinator(assignments)

    coordinator.advance("plan-1")

    assert runner.calls[0]["completed_node_ids"] == set()
    assert runner.calls[0]["node_execution_ids"] == {}


def test_failed_assignment_does_not_advance_dependencies():
    assignments = InMemoryRepository()

    assignment = make_assignment(
        node_id="node-a",
        execution_id="exec-a",
        status=AssignmentStatus.FAILED,
    )
    assignments.save(assignment)

    coordinator, _, runner = make_coordinator(assignments)

    coordinator.advance("plan-1")

    assert runner.calls[0]["completed_node_ids"] == set()


def test_completed_assignment_requires_execution_id():
    assignments = InMemoryRepository()

    assignment = Assignment(
        task_id="task-a",
        agent_id="agent-1",
        mission_id="mission-1",
        status=AssignmentStatus.COMPLETED,
        metadata={
            "execution_plan_id": "plan-1",
            "execution_node_id": "node-a",
        },
    )
    assignments.save(assignment)

    coordinator, _, _ = make_coordinator(assignments)

    with pytest.raises(ValueError, match="has no execution ID"):
        coordinator.advance("plan-1")


def test_missing_plan_node_metadata_is_rejected():
    assignments = InMemoryRepository()

    assignment = Assignment(
        task_id="task-a",
        agent_id="agent-1",
        mission_id="mission-1",
        status=AssignmentStatus.COMPLETED,
        execution_id="exec-a",
        metadata={"execution_plan_id": "plan-1"},
    )
    assignments.save(assignment)

    coordinator, events, _ = make_coordinator(assignments)

    failures = events.publish(
        Event(
            type="TaskAssignmentCompleted",
            payload={"assignment_id": assignment.id},
            aggregate_type="assignment",
            aggregate_id=assignment.id,
        )
    )

    assert len(failures) == 1
    assert "missing execution_node_id" in str(failures[0].error)


def test_missing_plan_id_metadata_is_rejected():
    assignments = InMemoryRepository()

    assignment = Assignment(
        task_id="task-a",
        agent_id="agent-1",
        mission_id="mission-1",
        status=AssignmentStatus.COMPLETED,
        execution_id="exec-a",
        metadata={"execution_node_id": "node-a"},
    )
    assignments.save(assignment)

    coordinator, events, _ = make_coordinator(assignments)

    failures = events.publish(
        Event(
            type="TaskAssignmentCompleted",
            payload={"assignment_id": assignment.id},
            aggregate_type="assignment",
            aggregate_id=assignment.id,
        )
    )

    assert len(failures) == 1
    assert "missing execution_plan_id" in str(failures[0].error)


def test_conflicting_completed_execution_ids_are_rejected():
    assignments = InMemoryRepository()

    first = make_assignment(
        node_id="node-a",
        execution_id="exec-a",
        status=AssignmentStatus.COMPLETED,
    )
    second = make_assignment(
        node_id="node-a",
        execution_id="exec-other",
        status=AssignmentStatus.COMPLETED,
    )

    assignments.save(first)
    assignments.save(second)

    coordinator, _, _ = make_coordinator(assignments)

    with pytest.raises(ValueError, match="conflicting completed execution IDs"):
        coordinator.advance("plan-1")


def test_unknown_plan_id_is_rejected():
    assignments = InMemoryRepository()
    coordinator, _, _ = make_coordinator(assignments)

    with pytest.raises(AssertionError):
        coordinator.advance("different-plan")


def test_empty_plan_id_is_rejected():
    assignments = InMemoryRepository()
    coordinator, _, _ = make_coordinator(assignments)

    with pytest.raises(ValueError, match="plan_revision_id must be non-empty"):
        coordinator.advance("")


# ---------------------------------------------------------------------------
# Failure handling tests
# ---------------------------------------------------------------------------


def make_coordinator_with_orchestrator(assignments, *, max_retries=3):
    """Build a coordinator wired to a mock orchestrator for retry tests."""

    class FakeOrchestrator:
        def __init__(self):
            self.dispatch_calls = []

        def dispatch(self, assignment_id, intent, *, dependency_execution_ids=None):
            self.dispatch_calls.append(
                {
                    "assignment_id": assignment_id,
                    "intent": intent,
                    "dependency_execution_ids": dependency_execution_ids,
                }
            )

            from ocean.orchestration.types import OrchestrationResult

            return OrchestrationResult(
                success=True,
                assignment_id=assignment_id,
                execution_id=f"exec-retry-{assignment_id}",
            )

    events = EventBus()
    provider = FakeProvider(make_plan())
    runner = FakeRunner()
    orchestrator = FakeOrchestrator()

    coordinator = ExecutionPlanCoordinator(
        events=events,
        assignments=assignments,
        plan_provider=provider,
        runner=runner,
        orchestrator=orchestrator,
        max_retries=max_retries,
    )

    return coordinator, events, runner, orchestrator


def test_failed_plan_assignment_creates_retry():
    assignments = InMemoryRepository()

    assignment = make_assignment(
        node_id="node-a",
        execution_id="exec-a",
        status=AssignmentStatus.FAILED,
    )
    assignments.save(assignment)

    coordinator, events, _, orchestrator = make_coordinator_with_orchestrator(
        assignments
    )

    events.publish(
        Event(
            type="TaskAssignmentFailed",
            payload={"assignment_id": assignment.id},
            aggregate_type="assignment",
            aggregate_id=assignment.id,
        )
    )

    retry_assignments = [
        a
        for a in assignments.list()
        if a.metadata.get("plan_retry") is True
    ]
    assert len(retry_assignments) == 1

    retry = retry_assignments[0]
    assert retry.parent_assignment_id == assignment.id
    assert retry.task_id == assignment.task_id
    assert retry.agent_id == assignment.agent_id
    assert retry.metadata["execution_plan_id"] == "plan-1"
    assert retry.metadata["execution_node_id"] == "node-a"
    assert retry.metadata["plan_retry_attempt"] == 0

    retry_events = [
        e for e in events.history() if e.type == "PlanNodeRetryScheduled"
    ]
    assert len(retry_events) == 1
    assert retry_events[0].payload["attempt"] == 0

    assert len(orchestrator.dispatch_calls) == 1
    assert orchestrator.dispatch_calls[0]["assignment_id"] == retry.id
    assert orchestrator.dispatch_calls[0]["dependency_execution_ids"] == set()


def test_failure_without_orchestrator_does_not_retry():
    assignments = InMemoryRepository()

    assignment = make_assignment(
        node_id="node-a",
        execution_id="exec-a",
        status=AssignmentStatus.FAILED,
    )
    assignments.save(assignment)

    coordinator, events, runner = make_coordinator(assignments)

    coordinator._handle_assignment_failed(
        Event(
            type="TaskAssignmentFailed",
            payload={"assignment_id": assignment.id},
            aggregate_type="assignment",
            aggregate_id=assignment.id,
        )
    )

    retry_assignments = [
        a
        for a in coordinator.assignments.list()
        if a.metadata.get("plan_retry") is True
    ]
    assert len(retry_assignments) == 0


def test_non_plan_assignment_failure_is_ignored():
    assignments = InMemoryRepository()

    assignment = Assignment(
        task_id="task-normal",
        agent_id="agent-1",
        status=AssignmentStatus.FAILED,
        execution_id="exec-normal",
    )
    assignments.save(assignment)

    coordinator, events, _, orchestrator = make_coordinator_with_orchestrator(
        assignments
    )

    events.publish(
        Event(
            type="TaskAssignmentFailed",
            payload={"assignment_id": assignment.id},
            aggregate_type="assignment",
            aggregate_id=assignment.id,
        )
    )

    assert len(orchestrator.dispatch_calls) == 0


def test_retry_budget_is_enforced():
    assignments = InMemoryRepository()

    assignment = make_assignment(
        node_id="node-a",
        execution_id="exec-a",
        status=AssignmentStatus.FAILED,
    )
    assignments.save(assignment)

    coordinator, events, _, orchestrator = make_coordinator_with_orchestrator(
        assignments, max_retries=2
    )

    for i in range(5):
        events.publish(
            Event(
                type="TaskAssignmentFailed",
                payload={"assignment_id": assignment.id},
                aggregate_type="assignment",
                aggregate_id=assignment.id,
            )
        )

    retry_assignments = [
        a
        for a in assignments.list()
        if a.metadata.get("plan_retry") is True
    ]
    assert len(retry_assignments) == 2

    assert len(orchestrator.dispatch_calls) == 2


def test_max_retries_zero_means_no_retry():
    assignments = InMemoryRepository()

    assignment = make_assignment(
        node_id="node-a",
        execution_id="exec-a",
        status=AssignmentStatus.FAILED,
    )
    assignments.save(assignment)

    coordinator, events, _, orchestrator = make_coordinator_with_orchestrator(
        assignments, max_retries=0
    )

    events.publish(
        Event(
            type="TaskAssignmentFailed",
            payload={"assignment_id": assignment.id},
            aggregate_type="assignment",
            aggregate_id=assignment.id,
        )
    )

    assert len(orchestrator.dispatch_calls) == 0


def test_failed_node_still_blocks_dependents_after_retries_exhausted():
    assignments = InMemoryRepository()

    failed = make_assignment(
        node_id="node-a",
        execution_id="exec-a",
        status=AssignmentStatus.FAILED,
    )
    assignments.save(failed)

    coordinator, _, runner, _ = make_coordinator_with_orchestrator(
        assignments, max_retries=1
    )

    for _ in range(3):
        coordinator._handle_assignment_failed(
            Event(
                type="TaskAssignmentFailed",
                payload={"assignment_id": failed.id},
                aggregate_type="assignment",
                aggregate_id=failed.id,
            )
        )

    coordinator.advance("plan-1")

    assert runner.calls[0]["completed_node_ids"] == set()


def test_retry_attempts_counter_tracks_per_node():
    assignments = InMemoryRepository()

    failed_a = make_assignment(
        node_id="node-a",
        execution_id="exec-a",
        status=AssignmentStatus.FAILED,
    )
    failed_b = make_assignment(
        node_id="node-b",
        execution_id="exec-b",
        status=AssignmentStatus.FAILED,
    )
    assignments.save(failed_a)
    assignments.save(failed_b)

    coordinator, events, _, orchestrator = make_coordinator_with_orchestrator(
        assignments, max_retries=2
    )

    for _ in range(3):
        events.publish(
            Event(
                type="TaskAssignmentFailed",
                payload={"assignment_id": failed_a.id},
                aggregate_type="assignment",
                aggregate_id=failed_a.id,
            )
        )

    for _ in range(3):
        events.publish(
            Event(
                type="TaskAssignmentFailed",
                payload={"assignment_id": failed_b.id},
                aggregate_type="assignment",
                aggregate_id=failed_b.id,
            )
        )

    assert coordinator._node_attempts["node-a"] == 2
    assert coordinator._node_attempts["node-b"] == 2

    retry_a = [
        a
        for a in assignments.list()
        if a.metadata.get("execution_node_id") == "node-a"
        and a.metadata.get("plan_retry") is True
    ]
    retry_b = [
        a
        for a in assignments.list()
        if a.metadata.get("execution_node_id") == "node-b"
        and a.metadata.get("plan_retry") is True
    ]
    assert len(retry_a) == 2
    assert len(retry_b) == 2


def test_retry_preserves_plan_metadata():
    assignments = InMemoryRepository()

    original = make_assignment(
        node_id="node-a",
        execution_id="exec-a",
        status=AssignmentStatus.FAILED,
    )
    original.metadata["custom_key"] = "custom_value"
    assignments.save(original)

    coordinator, events, _, _ = make_coordinator_with_orchestrator(assignments)

    events.publish(
        Event(
            type="TaskAssignmentFailed",
            payload={"assignment_id": original.id},
            aggregate_type="assignment",
            aggregate_id=original.id,
        )
    )

    retry = [
        a
        for a in assignments.list()
        if a.metadata.get("plan_retry") is True
    ][0]

    assert retry.metadata["execution_plan_id"] == "plan-1"
    assert retry.metadata["execution_node_id"] == "node-a"
    assert retry.metadata["custom_key"] == "custom_value"
    assert retry.metadata["plan_retry"] is True
    assert retry.metadata["plan_retry_attempt"] == 0


def test_retry_event_payload_contains_plan_identity():
    assignments = InMemoryRepository()

    assignment = make_assignment(
        node_id="node-a",
        execution_id="exec-a",
        status=AssignmentStatus.FAILED,
    )
    assignments.save(assignment)

    coordinator, events, _, _ = make_coordinator_with_orchestrator(assignments)

    events.publish(
        Event(
            type="TaskAssignmentFailed",
            payload={"assignment_id": assignment.id},
            aggregate_type="assignment",
            aggregate_id=assignment.id,
        )
    )

    retry_event = [
        e for e in events.history() if e.type == "PlanNodeRetryScheduled"
    ][0]

    assert retry_event.payload["execution_plan_id"] == "plan-1"
    assert retry_event.payload["execution_node_id"] == "node-a"
    assert retry_event.payload["failed_assignment_id"] == assignment.id
    assert retry_event.payload["attempt"] == 0
    assert retry_event.payload["max_retries"] == 3


def test_dispatch_failure_marks_retry_assignment_failed():
    assignments = InMemoryRepository()

    assignment = make_assignment(
        node_id="node-a",
        execution_id="exec-a",
        status=AssignmentStatus.FAILED,
    )
    assignments.save(assignment)

    events = EventBus()
    provider = FakeProvider(make_plan())
    runner = FakeRunner()

    class FailingDispatchOrchestrator:
        def dispatch(self, assignment_id, intent, *, dependency_execution_ids=None):
            from ocean.orchestration.types import OrchestrationResult

            return OrchestrationResult(
                success=False,
                error="agent unavailable",
            )

    coordinator = ExecutionPlanCoordinator(
        events=events,
        assignments=assignments,
        plan_provider=provider,
        runner=runner,
        orchestrator=FailingDispatchOrchestrator(),
        max_retries=3,
    )

    events.publish(
        Event(
            type="TaskAssignmentFailed",
            payload={"assignment_id": assignment.id},
            aggregate_type="assignment",
            aggregate_id=assignment.id,
        )
    )

    retry = [
        a
        for a in assignments.list()
        if a.metadata.get("plan_retry") is True
    ][0]

    assert retry.status is AssignmentStatus.CANCELLED
    assert "agent unavailable" in (retry.reason or "")
