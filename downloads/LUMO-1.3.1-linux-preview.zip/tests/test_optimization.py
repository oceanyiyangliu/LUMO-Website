import pytest
from ocean.optimization import BudgetGuard, SafeResultCache, SingleFlight, DeterministicFastPath, PerformanceLedger, stable_key

def test_budget_two_stage_reservation_and_release():
    b=BudgetGuard({"money":10,"tokens":100})
    b.reserve("m",{"money":6},"r1")
    assert b.remaining("money")==4
    b.commit("r1",{"money":5})
    assert b.remaining("money")==5

def test_budget_rejects_overcommit():
    b=BudgetGuard({"money":5})
    b.reserve("m",{"money":5},"r1")
    with pytest.raises(RuntimeError): b.reserve("m",{"money":0.01},"r2")

def test_cache_requires_matching_state_fingerprint():
    c=SafeResultCache(); c.put("k","value",fingerprint="a")
    assert c.get("k",current_fingerprint="a")=="value"
    assert c.get("k",current_fingerprint="b") is None
    assert c.get("k",current_fingerprint="a",reusable=False) is None
    assert c.stats()["hits"]==1

def test_single_flight_and_fast_path():
    calls=[]; f=SingleFlight()
    assert f.run("x",lambda: calls.append(1) or 42)==42
    assert calls==[1]
    p=DeterministicFastPath(); p.register("lookup",lambda key: key.upper())
    assert p.execute("lookup",risk="low",authorized=True,kwargs={"key":"a"}).result=="A"
    assert not p.execute("lookup",risk="medium",authorized=True,kwargs={"key":"a"}).handled

def test_performance_ledger_percentiles_and_key_stability():
    l=PerformanceLedger()
    for x in [1,2,3,4,100]: l.record("op",x)
    s=l.summary("op"); assert s["p50_ms"]==3 and s["p95_ms"]==100
    assert stable_key({"b":2,"a":1})==stable_key({"a":1,"b":2})

def test_single_flight_coalesces_concurrent_calls():
    import threading, time
    sf=SingleFlight(); calls=[]; results=[]
    def work():
        calls.append(1); time.sleep(.03); return 9
    def runner(): results.append(sf.run("same",work))
    threads=[threading.Thread(target=runner) for _ in range(8)]
    for t in threads:t.start()
    for t in threads:t.join()
    assert results==[9]*8 and len(calls)==1

def test_cost_ledger_attribution():
    from ocean.optimization import CostLedger
    l=CostLedger(); l.record("mission-1","model",.4); l.record("mission-1","vision",.2); l.record("mission-2","model",.8)
    assert l.total(scope="mission-1")==pytest.approx(.6)
    assert l.breakdown(scope="mission-1")=={"model":.4,"vision":.2}

def test_objective_switches_to_latency_when_deadline_has_no_slack():
    from ocean.optimization import choose_objective
    d=choose_objective(objective="cost",cost=1,latency_ms=50,deadline_slack_ms=-1)
    assert d.objective=="latency"
