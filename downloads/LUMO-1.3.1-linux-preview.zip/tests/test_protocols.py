import pytest
from ocean.protocols import ProtocolFrame, ProtocolNegotiator, StreamPartitioner, device_frame, cloud_frame, world_frame

def test_version_negotiation_partitioning_and_signed_frames():
    assert ProtocolNegotiator({1,2}).negotiate([1,2])==2
    with pytest.raises(RuntimeError): ProtocolNegotiator({1}).negotiate([3])
    assert StreamPartitioner(8).partition('mission-1')==StreamPartitioner(8).partition('mission-1')
    secret=b'x'*32
    for frame in (device_frame('d',1,{'x':1},secret),cloud_frame('a',2,{'x':2},secret),world_frame('w',3,{'x':3},secret)):
        assert frame.verify(secret)
        assert not frame.verify(b'y'*32)
