import pytest
from ocean.capabilities.http import HttpExecutor
from runtime.types import ExecutionRequest


def req(args):
    return ExecutionRequest(task_id="t", capability="http", operation="request", arguments=args)


def test_http_rejects_unsafe_method_and_headers():
    executor = HttpExecutor()
    for args in ({"url":"https://example.com", "method":"TRACE"},
                 {"url":"https://example.com", "headers":{"X-Test":"a\nb"}}):
        with pytest.raises(ValueError):
            executor.execute(req(args), None)


def test_http_rejects_oversized_request_body():
    with pytest.raises(ValueError, match="1MB"):
        HttpExecutor().execute(req({"url":"https://example.com", "body":"x" * 1_000_001}), None)
