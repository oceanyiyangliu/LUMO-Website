import pytest
import os
from ocean.security import SessionAuthority
from ocean.api_security import APIAuth

def test_api_auth_requires_bearer_and_csrf():
    a=APIAuth(SessionAuthority(secret=b"x"*32)); tok=a.sessions.issue("acct"); sess=a.authenticate("Bearer "+tok); nonce="n"; csrf=a.csrf(sess.session_id,"POST","/api/x",nonce); assert a.verify_csrf(sess.session_id,"POST","/api/x",nonce,csrf)


def test_authenticated_session_cannot_cross_active_account(tmp_path, monkeypatch):
    monkeypatch.setenv("LUMO_API_AUTH_REQUIRED", "1")
    from ocean.api import LumoAPI
    from ocean.service import OceanService
    from ocean.api import _Handler
    service = OceanService(repository_root=tmp_path)
    service.start()
    try:
        api = LumoAPI(service)
        first = api.account()["id"]
        second = api.create_account("Second")["id"]
        api.switch_account(first)
        token = api._sessions.issue(second)
        class FakeHandler:
            pass
        h = FakeHandler()
        h.api = api
        h.headers = {"Authorization": "Bearer " + token}
        h.command = "GET"
        with pytest.raises(PermissionError, match="active account"):
            _Handler._require_api_auth(h, "/api/account")
    finally:
        service.stop()
