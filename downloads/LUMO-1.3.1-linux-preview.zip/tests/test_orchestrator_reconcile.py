from ocean.domain.agent import Agent
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.domain.task import Task
from ocean.orchestration.orchestrator import OrchestrationPorts, Orchestrator
from ocean.orchestration.types import AssignmentRequest, ExecutionIntent
from runtime.types import ExecutionResult


class TaskRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item


class AssignmentRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item

    def list(self):
        return list(self.items.values())

    def transaction(self):
        from contextlib import contextmanager

        @contextmanager
        def _tx():
            yield

        return _tx()


class AgentRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item


class MissionRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item


class RuntimeStub:
    def submit(self, agent_id, request, *, priority=0, dependencies=None):
        class Scheduled:
            execution_id = request.execution_id

        return Scheduled()

    def mark_idle(self, agent_id):
        return None

    def mark_waiting(self, agent_id, *, task_id=None):
        return None

    def mark_background(self, agent_id):
        return None


def build():
    tasks = TaskRepo()
    assignments = AssignmentRepo()
    agents = AgentRepo()
    missions = MissionRepo()
    events = EventBus()

    ports = OrchestrationPorts(
        missions=missions,
        tasks=tasks,
        assignments=assignments,
        agents=agents,
        agent_runtime=RuntimeStub(),
        events=events,
    )

    return (
        Orchestrator(ports),
        tasks,
        assignments,
        agents,
        missions,
        events,
    )


def make_assignment(orchestrator, tasks, assignments, agents):
    agent = Agent(
        id="agent-reconcile",
        name="Reconcile Agent",
        role="worker",
        capabilities={"test"},
    )
    agents.save(agent)

    task = Task(title="Reconcile task")
    tasks.save(task)

    created = orchestrator.assign(
        AssignmentRequest(
            task_id=task.id,
            agent_id=agent.id,
        )
    )

    assert created.success

    dispatched = orchestrator.dispatch(
        created.assignment_id,
        ExecutionIntent(
            capability="test",
            operation="run",
        ),
    )

    assert dispatched.success

    assignment = assignments.get(created.assignment_id)

    dispatch_event = Event(
        type="ScheduledExecutionDispatched",
        payload={
            "id": dispatched.execution_id,
            "task_id": task.id,
            "agent_id": agent.id,
            "priority": assignment.priority,
            "state": "dispatched",
        },
        aggregate_type="scheduled_execution",
        aggregate_id=dispatched.execution_id,
        causation_id=created.assignment_id,
        source="scheduler",
    )

    failures = orchestrator.ports.events.publish(dispatch_event)
    assert failures == []

    return task, assignments.get(created.assignment_id)


def test_reconcile_rejects_unknown_assignment():
    orchestrator, tasks, assignments, agents, missions, events = build()

    result = orchestrator.reconcile(
        "missing-assignment",
        ExecutionResult.succeeded("ok"),
    )

    assert result.success is False
    assert "unknown assignment" in result.error


def test_successful_execution_completes_assignment():
    orchestrator, tasks, assignments, agents, missions, events = build()

    task, assignment = make_assignment(
        orchestrator,
        tasks,
        assignments,
        agents,
    )

    result = orchestrator.reconcile(
        assignment.id,
        ExecutionResult.succeeded({"answer": 42}),
    )

    assert result.success is True
    assert result.assignment_id == assignment.id
    assert result.execution_id == assignment.execution_id
    assert result.success is True

    stored = assignments.get(assignment.id)
    assert stored.status.value == "completed"
    assert stored.execution_id == assignment.execution_id


def test_failed_execution_fails_assignment():
    orchestrator, tasks, assignments, agents, missions, events = build()

    task, assignment = make_assignment(
        orchestrator,
        tasks,
        assignments,
        agents,
    )

    result = orchestrator.reconcile(
        assignment.id,
        ExecutionResult.failed("controlled failure"),
    )

    assert result.success is False
    assert result.assignment_id == assignment.id
    assert result.execution_id == assignment.execution_id
    assert result.error == "controlled failure"

    stored = assignments.get(assignment.id)
    assert stored.status.value == "failed"


def test_reconcile_does_not_complete_task():
    orchestrator, tasks, assignments, agents, missions, events = build()

    task, assignment = make_assignment(
        orchestrator,
        tasks,
        assignments,
        agents,
    )

    orchestrator.reconcile(
        assignment.id,
        ExecutionResult.succeeded("operation result"),
    )

    stored_task = tasks.get(task.id)

    assert stored_task.status.value != "completed"
    assert stored_task.result is None


def test_reconcile_emits_assignment_completed_event():
    orchestrator, tasks, assignments, agents, missions, events = build()

    task, assignment = make_assignment(
        orchestrator,
        tasks,
        assignments,
        agents,
    )

    orchestrator.reconcile(
        assignment.id,
        ExecutionResult.succeeded("ok"),
    )

    event_types = [event.type for event in events.history()]

    assert "TaskAssignmentCompleted" in event_types

    completed = [
        event
        for event in events.history()
        if event.type == "TaskAssignmentCompleted"
    ][-1]

    assert completed.payload["assignment_id"] == assignment.id
    assert completed.payload["execution_id"] == assignment.execution_id


def test_reconcile_emits_assignment_failed_event():
    orchestrator, tasks, assignments, agents, missions, events = build()

    task, assignment = make_assignment(
        orchestrator,
        tasks,
        assignments,
        agents,
    )

    orchestrator.reconcile(
        assignment.id,
        ExecutionResult.failed("controlled failure"),
    )

    event_types = [event.type for event in events.history()]

    assert "TaskAssignmentFailed" in event_types

    failed = [
        event
        for event in events.history()
        if event.type == "TaskAssignmentFailed"
    ][-1]

    assert failed.payload["assignment_id"] == assignment.id
    assert failed.payload["execution_id"] == assignment.execution_id
    assert failed.payload["error"] == "controlled failure"
