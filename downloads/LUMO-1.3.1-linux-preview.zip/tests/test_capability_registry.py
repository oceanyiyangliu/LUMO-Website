import pytest

from ocean.core.errors import DuplicateRegistration, UnknownCapability, UnknownOperation
from ocean.domain.capability import CapabilityRegistry, CapabilitySpec, OperationSpec
from ocean.domain.enums import RiskLevel


def filesystem_capability() -> CapabilitySpec:
    return CapabilitySpec(
        name="filesystem",
        description="Local filesystem operations",
        execution_strategy="deterministic_local",
        operations={
            "create_folder": OperationSpec(
                name="create_folder",
                description="Create a directory",
                risk_level=RiskLevel.SAFE,
            ),
            "delete_file": OperationSpec(
                name="delete_file",
                description="Delete a file",
                risk_level=RiskLevel.IMPORTANT,
            ),
        },
    )


def test_register_and_get():
    reg = CapabilityRegistry()
    reg.register(filesystem_capability())
    cap = reg.get("filesystem")
    assert cap.name == "filesystem"
    assert set(cap.operations) == {"create_folder", "delete_file"}


def test_duplicate_registration_rejected():
    reg = CapabilityRegistry()
    reg.register(filesystem_capability())
    with pytest.raises(DuplicateRegistration):
        reg.register(filesystem_capability())


def test_unknown_capability_raises():
    reg = CapabilityRegistry()
    with pytest.raises(UnknownCapability):
        reg.get("browser")


def test_unknown_operation_raises():
    reg = CapabilityRegistry()
    reg.register(filesystem_capability())
    with pytest.raises(UnknownOperation):
        reg.get_operation("filesystem", "format_disk")


def test_describe_is_a_plain_serializable_dict():
    reg = CapabilityRegistry()
    reg.register(filesystem_capability())
    desc = reg.describe()
    assert desc["filesystem"]["operations"]["delete_file"]["risk_level"] == "important"
    # must be JSON-safe: no enums, no objects
    import json
    json.dumps(desc)


def test_adding_a_new_capability_requires_no_registry_code_changes():
    """Regression guard for RULE 9 / brief section 28: registering a brand
    new capability must be possible with zero changes to CapabilityRegistry
    itself."""
    reg = CapabilityRegistry()
    reg.register(filesystem_capability())
    pdf_capability = CapabilitySpec(
        name="pdf",
        description="PDF manipulation",
        operations={
            "merge": OperationSpec(name="merge", description="Merge PDFs"),
        },
    )
    reg.register(pdf_capability)
    assert {c.name for c in reg.list_capabilities()} == {"filesystem", "pdf"}
