import pytest

from ocean.domain.agent import Agent
from ocean.domain.enums import AgentStatus
from ocean.domain.event_bus import EventBus

from runtime import (
    AgentController,
    AgentExecutionLifecycle,
    AgentRegistry,
    AgentRuntime,
    ExecutionRequest,
    ExecutionSupervisor,
    Scheduler,
)
from tests.test_scheduler import BlockingExecutor, SuccessfulExecutor


def make_request(
    *,
    execution_id=None,
    capability="compute",
):
    return ExecutionRequest(
        task_id="task-1",
        capability=capability,
        operation="run",
        execution_id=execution_id,
    )


def make_agent(
    *,
    agent_id="agent-1",
    capabilities=None,
):
    return Agent(
        id=agent_id,
        name="Test Agent",
        role="worker",
        capabilities=set(capabilities or {"compute"}),
    )


def make_runtime(executor=None):

    from ocean.domain.capability import (
        CapabilityRegistry,
        CapabilitySpec,
        OperationSpec,
    )
    from ocean.domain.policy import PolicyEngine
    from ocean.domain.enums import RiskLevel
    from runtime import ExecutionRuntime, ExecutorRegistry

    executor = executor or SuccessfulExecutor()

    capabilities = CapabilityRegistry()
    capabilities.register(
        CapabilitySpec(
            name="compute",
            description="Test compute capability",
            execution_strategy="test_executor",
            operations={
                "run": OperationSpec(
                    name="run",
                    description="Run a test operation",
                    risk_level=RiskLevel.SAFE,
                ),
            },
        )
    )

    executors = ExecutorRegistry()
    executors.register("test_executor", executor)

    return ExecutionRuntime(
        capabilities=capabilities,
        policy=PolicyEngine(),
        executors=executors,
    )

def make_stack(executor=None):
    executor = executor or SuccessfulExecutor()

    bus = EventBus()
    supervisor = ExecutionSupervisor(
        make_runtime(executor),
        max_workers=4,
    )
    scheduler = Scheduler(
        supervisor,
        event_bus=bus,
    )
    registry = AgentRegistry()
    controller = AgentController(event_bus=bus)
    runtime = AgentRuntime(
        scheduler,
        registry=registry,
        controller=controller,
    )
    lifecycle = AgentExecutionLifecycle(
        event_bus=bus,
        registry=registry,
        controller=controller,
    )

    return runtime, scheduler, supervisor

def test_agent_controller_creates_agent():
    controller = AgentController()

    agent = controller.create(
        "Alice",
        "researcher",
        capabilities={"research"},
    )

    assert agent.name == "Alice"
    assert agent.role == "researcher"
    assert agent.capabilities == {"research"}
    assert agent.status == AgentStatus.IDLE


def test_agent_controller_emits_creation_event():
    bus = EventBus()
    controller = AgentController(event_bus=bus)

    agent = controller.create(
        "Alice",
        "researcher",
    )

    events = bus.history()

    assert len(events) == 1
    assert events[0].type == "AgentCreated"
    assert events[0].payload["agent_id"] == agent.id


def test_agent_controller_activates_agent():
    controller = AgentController()
    agent = Agent("Alice", "worker")

    controller.activate(agent, task_id="task-1")

    assert agent.status == AgentStatus.RUNNING
    assert agent.current_task_id == "task-1"


def test_agent_controller_waits():
    controller = AgentController()
    agent = Agent("Alice", "worker")
    controller.activate(agent, task_id="task-1")

    controller.wait(agent)

    assert agent.status == AgentStatus.WAITING
    assert agent.current_task_id == "task-1"


def test_agent_controller_resumes():
    controller = AgentController()
    agent = Agent("Alice", "worker")
    controller.activate(agent, task_id="task-1")
    controller.wait(agent)

    controller.resume(agent)

    assert agent.status == AgentStatus.RUNNING
    assert agent.current_task_id == "task-1"


def test_agent_controller_backgrounds_idle_agent():
    controller = AgentController()
    agent = Agent("Alice", "worker")

    controller.background(agent)

    assert agent.status == AgentStatus.BACKGROUND
    assert agent.current_task_id is None


def test_agent_controller_failure_clears_task():
    controller = AgentController()
    agent = Agent("Alice", "worker")
    controller.activate(agent, task_id="task-1")

    controller.fail(agent)

    assert agent.status == AgentStatus.FAILED
    assert agent.current_task_id is None


def test_agent_controller_termination_is_terminal():
    controller = AgentController()
    agent = Agent("Alice", "worker")

    controller.terminate(agent)

    assert agent.status == AgentStatus.TERMINATED
    assert agent.current_task_id is None

    from ocean.core.errors import InvalidStateTransition

    with pytest.raises(InvalidStateTransition):
        controller.idle(agent)


def test_agent_controller_emits_state_change():
    bus = EventBus()
    controller = AgentController(event_bus=bus)
    agent = Agent("Alice", "worker")

    controller.activate(agent, task_id="task-1")

    event = bus.history()[0]

    assert event.type == "AgentStateChanged"
    assert event.payload["agent_id"] == agent.id
    assert event.payload["previous_status"] == "idle"
    assert event.payload["status"] == "running"
    assert event.payload["current_task_id"] == "task-1"


def test_agent_registry_registers_and_gets():
    registry = AgentRegistry()
    agent = make_agent()

    registry.register(agent)

    assert registry.get(agent.id) is agent


def test_agent_registry_rejects_duplicate():
    registry = AgentRegistry()
    agent = make_agent()

    registry.register(agent)

    with pytest.raises(ValueError):
        registry.register(agent)


def test_agent_registry_removes():
    registry = AgentRegistry()
    agent = make_agent()

    registry.register(agent)

    assert registry.remove(agent.id) is agent
    assert registry.get(agent.id) is None


def test_agent_registry_active_excludes_terminated():
    registry = AgentRegistry()

    active = make_agent(agent_id="active")
    terminated = make_agent(agent_id="terminated")
    terminated.status = AgentStatus.TERMINATED

    registry.register(active)
    registry.register(terminated)

    assert [agent.id for agent in registry.active()] == ["active"]


def test_agent_registry_available_contains_idle_and_background():
    registry = AgentRegistry()

    idle = make_agent(agent_id="idle")
    background = make_agent(agent_id="background")
    running = make_agent(agent_id="running")
    running.status = AgentStatus.RUNNING

    registry.register(idle)
    registry.register(background)
    registry.register(running)

    controller = AgentController()
    controller.background(background)

    assert {
        agent.id for agent in registry.available()
    } == {"idle", "background"}


def test_agent_runtime_registers_agent():
    runtime, scheduler, supervisor = make_stack()

    try:
        agent = make_agent()

        runtime.register(agent)

        assert runtime.get(agent.id) is agent
    finally:
        supervisor.shutdown()


def test_agent_runtime_rejects_unknown_agent():
    runtime, scheduler, supervisor = make_stack()

    try:
        with pytest.raises(KeyError):
            runtime.submit(
                "missing",
                make_request(),
            )
    finally:
        supervisor.shutdown()


def test_agent_runtime_rejects_missing_capability():
    runtime, scheduler, supervisor = make_stack()

    try:
        runtime.register(make_agent(capabilities={"research"}))

        with pytest.raises(PermissionError):
            runtime.submit(
                "agent-1",
                make_request(capability="compute"),
            )
    finally:
        supervisor.shutdown()


def test_agent_runtime_rejects_terminated_agent():
    runtime, scheduler, supervisor = make_stack()

    try:
        agent = make_agent()
        agent.status = AgentStatus.TERMINATED
        runtime.register(agent)

        with pytest.raises(RuntimeError):
            runtime.submit(
                agent.id,
                make_request(),
            )
    finally:
        supervisor.shutdown()


def test_agent_runtime_submits_without_activating_agent():

    runtime, scheduler, supervisor = make_stack()
    try:
        agent = make_agent()
        runtime.register(agent)
        item = runtime.submit(
            agent.id,
            make_request(execution_id="exec-1"),
        )
        assert item.execution_id == "exec-1"
        assert item.request.agent_id == agent.id
        assert item.state.value == "queued"
        assert agent.status == AgentStatus.IDLE
        assert agent.current_task_id is None
    finally:
        supervisor.shutdown()

def test_agent_runtime_rejects_mismatched_agent_id():
    runtime, scheduler, supervisor = make_stack()

    try:
        agent = make_agent()
        runtime.register(agent)

        request = ExecutionRequest(
            task_id="task-1",
            capability="compute",
            operation="run",
            agent_id="different-agent",
        )

        with pytest.raises(ValueError):
            runtime.submit(agent.id, request)
    finally:
        supervisor.shutdown()


def test_agent_runtime_can_return_agent_to_idle():

    runtime, scheduler, supervisor = make_stack()
    try:
        agent = make_agent()
        runtime.register(agent)
        runtime.submit(
            agent.id,
            make_request(),
        )
        scheduler.dispatch_next()
        runtime.mark_idle(agent.id)
        assert agent.status == AgentStatus.IDLE
        assert agent.current_task_id is None
    finally:
        supervisor.shutdown()

def test_agent_runtime_waits_and_resumes_agent():

    executor = BlockingExecutor()
    runtime, scheduler, supervisor = make_stack(executor)

    try:
        agent = make_agent()
        runtime.register(agent)

        runtime.submit(
            agent.id,
            make_request(),
        )

        scheduler.dispatch_next()

        assert executor.started.wait(timeout=2)
        assert agent.status == AgentStatus.RUNNING

        runtime.mark_waiting(agent.id)
        assert agent.status == AgentStatus.WAITING

        runtime.controller.resume(
            agent,
            task_id=agent.current_task_id,
        )
        assert agent.status == AgentStatus.RUNNING
    finally:
        executor.release.set()
        supervisor.shutdown()

def test_agent_runtime_backgrounds_agent():
    runtime, scheduler, supervisor = make_stack()

    try:
        agent = make_agent()
        runtime.register(agent)

        runtime.mark_background(agent.id)

        assert agent.status == AgentStatus.BACKGROUND
    finally:
        supervisor.shutdown()


def test_agent_runtime_failure_and_termination():

    executor = BlockingExecutor()
    runtime, scheduler, supervisor = make_stack(executor)

    try:
        agent = make_agent()
        runtime.register(agent)

        runtime.submit(
            agent.id,
            make_request(),
        )

        scheduler.dispatch_next()

        assert executor.started.wait(timeout=2)
        assert agent.status == AgentStatus.RUNNING

        runtime.fail(agent.id)
        assert agent.status == AgentStatus.FAILED

        runtime.controller.idle(agent)
        assert agent.status == AgentStatus.IDLE

        runtime.terminate(agent.id)
        assert agent.status == AgentStatus.TERMINATED
    finally:
        executor.release.set()
        supervisor.shutdown()
