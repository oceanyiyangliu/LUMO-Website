from pathlib import Path

import pytest

from ocean.domain.capability import CapabilityRegistry, CapabilitySpec, OperationSpec
from ocean.domain.enums import RiskLevel
from ocean.governance.capability_discovery import CapabilityDiscovery
from ocean.capabilities.filesystem import filesystem_spec


def pdf_capability() -> CapabilitySpec:
    return CapabilitySpec(
        name="pdf",
        description="PDF manipulation",
        operations={
            "merge": OperationSpec(name="merge", description="Merge PDFs"),
        },
    )


def test_discover_includes_operations_and_permissions():
    reg = CapabilityRegistry()
    reg.register(filesystem_spec())

    discovery = CapabilityDiscovery(reg)
    desc = discovery.discover()

    assert "filesystem" in desc

    fs = desc["filesystem"]
    assert fs["execution_strategy"] == "deterministic_local"
    # filesystem_spec declares a single required permission 'filesystem.read'
    assert fs["requires_permissions"] == ["filesystem.read"]

    # operations are present and deterministically listed
    assert set(fs["operations"]) == {"read_file", "list_directory", "file_exists", "search_files"}

    # risk_level is a JSON-safe primitive
    assert fs["operations"]["read_file"]["risk_level"] in {"low", "safe", "important", "high"}


def test_discover_deterministic_ordering():
    # Register in reverse order and ensure output is alphabetically sorted
    reg = CapabilityRegistry()
    reg.register(CapabilitySpec(name="zzz", description="z", operations={}))
    reg.register(CapabilitySpec(name="aaa", description="a", operations={}))

    discovery = CapabilityDiscovery(reg)
    desc = discovery.discover()

    assert list(desc.keys()) == ["aaa", "zzz"]


def test_governance_predicate_filters_capabilities():
    reg = CapabilityRegistry()
    reg.register(filesystem_spec())
    reg.register(pdf_capability())

    # deny visibility for the 'pdf' capability
    def allow(name, requester):
        return name != "pdf"

    discovery = CapabilityDiscovery(reg, allow_disclosure=allow)
    desc = discovery.discover()

    assert "filesystem" in desc
    assert "pdf" not in desc
