import pytest

from ocean.self_improvement.benchmark import (
    BenchmarkReport,
    BenchmarkRequest,
    BenchmarkResult,
    BenchmarkService,
)


class Provider:
    def __init__(self, report):
        self.report = report
        self.request = None

    def benchmark(self, request):
        self.request = request
        return self.report


def report(candidate_id, *results):
    return BenchmarkReport(
        candidate_id=candidate_id,
        results=tuple(results),
    )


def result(
    name,
    value,
    *,
    unit="",
    higher_is_better=True,
):
    return BenchmarkResult(
        name=name,
        value=value,
        unit=unit,
        higher_is_better=higher_is_better,
    )


def request():
    return BenchmarkRequest(
        candidate_id="candidate-1",
        objective="Improve scheduler",
        workspace_root="/candidate",
        baseline_root="/production",
    )


def test_benchmark_request_validates_identity():
    with pytest.raises(ValueError):
        BenchmarkRequest(
            candidate_id="",
            objective="Improve",
            workspace_root="/candidate",
            baseline_root="/production",
        )


def test_run_rejects_wrong_candidate():
    provider = Provider(
        report(
            "candidate-2",
            result("latency", 10, unit="ms"),
        )
    )

    with pytest.raises(ValueError):
        BenchmarkService().run(
            request=request(),
            provider=provider,
        )


def test_run_rejects_duplicate_metrics():
    provider = Provider(
        report(
            "candidate-1",
            result("latency", 10, unit="ms"),
            result("latency", 11, unit="ms"),
        )
    )

    with pytest.raises(ValueError):
        BenchmarkService().run(
            request=request(),
            provider=provider,
        )


def test_compare_detects_improvement():
    service = BenchmarkService()

    baseline = report(
        "candidate-1",
        result("latency", 100, unit="ms", higher_is_better=False),
        result("throughput", 100, unit="ops/s"),
    )
    candidate = report(
        "candidate-1",
        result("latency", 80, unit="ms", higher_is_better=False),
        result("throughput", 120, unit="ops/s"),
    )

    comparison = service.compare(
        candidate_id="candidate-1",
        baseline=baseline,
        candidate=candidate,
    )

    assert comparison.passed is True
    assert comparison.improved_count == 2
    assert comparison.regressed_count == 0
    assert comparison.unchanged_count == 0
    assert comparison.comparisons[0].name == "latency"


def test_compare_detects_regression():
    service = BenchmarkService()

    baseline = report(
        "candidate-1",
        result("latency", 100, unit="ms", higher_is_better=False),
    )
    candidate = report(
        "candidate-1",
        result("latency", 120, unit="ms", higher_is_better=False),
    )

    comparison = service.compare(
        candidate_id="candidate-1",
        baseline=baseline,
        candidate=candidate,
    )

    assert comparison.passed is False
    assert comparison.improved_count == 0
    assert comparison.regressed_count == 1


def test_compare_detects_unchanged_metric():
    service = BenchmarkService()

    baseline = report(
        "candidate-1",
        result("accuracy", 99, unit="%"),
    )
    candidate = report(
        "candidate-1",
        result("accuracy", 99, unit="%"),
    )

    comparison = service.compare(
        candidate_id="candidate-1",
        baseline=baseline,
        candidate=candidate,
    )

    assert comparison.passed is True
    assert comparison.unchanged_count == 1


def test_compare_requires_matching_metrics():
    service = BenchmarkService()

    baseline = report(
        "candidate-1",
        result("latency", 100, unit="ms"),
    )
    candidate = report(
        "candidate-1",
        result("throughput", 100, unit="ops/s"),
    )

    with pytest.raises(ValueError):
        service.compare(
            candidate_id="candidate-1",
            baseline=baseline,
            candidate=candidate,
        )


def test_compare_requires_matching_units():
    service = BenchmarkService()

    baseline = report(
        "candidate-1",
        result("latency", 100, unit="ms"),
    )
    candidate = report(
        "candidate-1",
        result("latency", 0.1, unit="seconds"),
    )

    with pytest.raises(ValueError):
        service.compare(
            candidate_id="candidate-1",
            baseline=baseline,
            candidate=candidate,
        )


def test_compare_requires_matching_direction():
    service = BenchmarkService()

    baseline = report(
        "candidate-1",
        result("latency", 100, higher_is_better=False),
    )
    candidate = report(
        "candidate-1",
        result("latency", 80, higher_is_better=True),
    )

    with pytest.raises(ValueError):
        service.compare(
            candidate_id="candidate-1",
            baseline=baseline,
            candidate=candidate,
        )


def test_compare_is_deterministic():
    service = BenchmarkService()

    baseline = report(
        "candidate-1",
        result("z_metric", 10),
        result("a_metric", 20),
    )
    candidate = report(
        "candidate-1",
        result("z_metric", 11),
        result("a_metric", 21),
    )

    first = service.compare(
        candidate_id="candidate-1",
        baseline=baseline,
        candidate=candidate,
    )
    second = service.compare(
        candidate_id="candidate-1",
        baseline=baseline,
        candidate=candidate,
    )

    assert first == second
    assert [item.name for item in first.comparisons] == [
        "a_metric",
        "z_metric",
    ]


def test_zero_baseline_improvement_ratio_is_safe():
    service = BenchmarkService()

    baseline = report(
        "candidate-1",
        result("throughput", 0),
    )
    candidate = report(
        "candidate-1",
        result("throughput", 10),
    )

    comparison = service.compare(
        candidate_id="candidate-1",
        baseline=baseline,
        candidate=candidate,
    )

    assert comparison.passed is True
    assert comparison.comparisons[0].improvement_ratio == float("inf")
