from ocean.benchmark.large_mission import LargeMissionBenchmark


def test_large_mission_benchmark_exercises_full_stack():
    result = LargeMissionBenchmark().run()

    assert result.objectives == 30
    assert result.completed_objectives == 30
    assert result.failed_objectives == 0
    assert result.peak_concurrent_objectives >= 8
    assert result.agents_used == 10
    assert result.retries >= 3
    assert result.lease_expirations >= 1
    assert result.process_terminations >= 1
    assert result.resource_contention_events >= 1
    assert result.recovered_objectives >= 3
    assert result.duplicate_or_stale_completions == 0
    assert result.replay_completed_objectives == 30
    assert result.event_count > result.objectives
    assert result.wall_clock_seconds < 30