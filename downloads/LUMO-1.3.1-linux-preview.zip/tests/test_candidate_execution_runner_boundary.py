import pytest

from ocean.execution.compiler import ExecutionPlan, ExecutionStep
from ocean.orchestration.execution_plan_runner import ExecutionPlanRunner
from ocean.self_improvement.execution_boundary import (
    CandidateExecutionBoundary,
    CandidateExecutionBoundaryError,
    CandidateExecutionContext,
)


class FakeResolver:
    def resolve(self, step):
        return "agent-1"


class FakeOrchestrator:
    def __init__(self):
        self.assign_calls = []
        self.dispatch_calls = []

    def assign(self, request):
        self.assign_calls.append(request)

        class Result:
            success = True
            assignment_id = "assignment-1"
            error = None

        return Result()

    def dispatch(self, assignment_id, intent, *, dependency_execution_ids):
        self.dispatch_calls.append(
            (assignment_id, intent, dependency_execution_ids)
        )

        class Result:
            success = True
            execution_id = "execution-1"
            error = None

        return Result()


def make_plan(
    *,
    mission_id="candidate-mission",
    plan_revision_id="candidate-plan",
):
    step = ExecutionStep(
        node_id="node-1",
        task_id="candidate-task",
        intent="test",
    )
    return ExecutionPlan(
        mission_id=mission_id,
        plan_revision_id=plan_revision_id,
        steps=(step,),
    )


def context(**overrides):
    data = {
        "candidate_mission_id": "candidate-mission",
        "source_mission_id": "production-mission",
        "candidate_plan_revision_id": "candidate-plan",
        "source_plan_revision_id": "production-plan",
        "metadata": {
            "candidate_execution": True,
            "candidate_mission_id": "candidate-mission",
            "source_mission_id": "production-mission",
            "candidate_plan_revision_id": "candidate-plan",
            "source_plan_revision_id": "production-plan",
        },
    }
    data.update(overrides)
    return CandidateExecutionContext(**data)


def test_valid_candidate_context_is_enforced_and_forwarded():
    orchestrator = FakeOrchestrator()
    runner = ExecutionPlanRunner(orchestrator, FakeResolver())

    result = runner.start(
        make_plan(),
        candidate_execution=context(),
    )

    assert result.success
    assert len(orchestrator.assign_calls) == 1
    assert len(orchestrator.dispatch_calls) == 1
    metadata = orchestrator.assign_calls[0].metadata
    assert metadata["candidate_execution"] is True
    assert metadata["candidate_mission_id"] == "candidate-mission"


def test_candidate_plan_mismatch_blocks_assignment_and_dispatch():
    orchestrator = FakeOrchestrator()
    runner = ExecutionPlanRunner(orchestrator, FakeResolver())

    result = runner.start(
        make_plan(plan_revision_id="wrong-plan"),
        candidate_execution=context(),
    )

    assert not result.success
    assert result.queued_node_ids == ()
    assert orchestrator.assign_calls == []
    assert orchestrator.dispatch_calls == []


def test_candidate_mission_mismatch_blocks_assignment_and_dispatch():
    orchestrator = FakeOrchestrator()
    runner = ExecutionPlanRunner(orchestrator, FakeResolver())

    result = runner.start(
        make_plan(mission_id="production-mission"),
        candidate_execution=context(),
    )

    assert not result.success
    assert result.queued_node_ids == ()
    assert orchestrator.assign_calls == []
    assert orchestrator.dispatch_calls == []


def test_incomplete_candidate_metadata_blocks_assignment_and_dispatch():
    orchestrator = FakeOrchestrator()
    runner = ExecutionPlanRunner(orchestrator, FakeResolver())

    invalid = context(
        metadata={
            "candidate_execution": True,
            "candidate_mission_id": "candidate-mission",
        }
    )

    result = runner.start(
        make_plan(),
        candidate_execution=invalid,
    )

    assert not result.success
    assert orchestrator.assign_calls == []
    assert orchestrator.dispatch_calls == []


def test_production_execution_remains_unchanged():
    orchestrator = FakeOrchestrator()
    runner = ExecutionPlanRunner(orchestrator, FakeResolver())

    result = runner.start(make_plan())

    assert result.success
    assert len(orchestrator.assign_calls) == 1
    assert len(orchestrator.dispatch_calls) == 1
    assert "candidate_execution" not in orchestrator.assign_calls[0].metadata


def test_candidate_boundary_rejects_source_identity():
    boundary = CandidateExecutionBoundary()

    with pytest.raises(CandidateExecutionBoundaryError):
        boundary.validate(
            isolation=type(
                "Isolation",
                (),
                {
                    "candidate_mission_id": "same",
                    "source_mission_id": "same",
                    "candidate_task_ids": frozenset({"candidate-task"}),
                    "source_task_ids": frozenset({"source-task"}),
                },
            )(),
            candidate_mission=type("Mission", (), {"id": "same"})(),
            candidate_plan=type(
                "Plan",
                (),
                {"id": "candidate-plan", "mission_id": "same"},
            )(),
            source_mission=type("Mission", (), {"id": "same"})(),
            source_plan=type(
                "Plan",
                (),
                {"id": "source-plan", "mission_id": "same"},
            )(),
        )
