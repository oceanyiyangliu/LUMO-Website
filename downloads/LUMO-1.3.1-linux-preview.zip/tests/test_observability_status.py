from datetime import datetime, timezone

from eventing.in_memory_store import InMemoryEventStore

from ocean.domain.event import Event
from ocean.observability.status import OperationalStatusProjector


def event(event_type, *, mission_id="mission-1", **payload):
    return Event(
        type=event_type,
        payload={"mission_id": mission_id, **payload},
        aggregate_type="mission",
        aggregate_id=mission_id,
        at=datetime.now(timezone.utc),
    )


def test_projector_derives_running_mission_and_objective_progress():
    events = [
        event("MissionStarted"),
        event(
            "ObjectiveStarted",
            objective_id="O1",
            objective="Improve recovery",
        ),
        event(
            "ObjectiveProgressed",
            objective_id="O1",
            progress=0.5,
            activity="running tests",
        ),
    ]

    status = OperationalStatusProjector.from_events("mission-1", events)

    assert status.status == "running"
    assert status.progress == 0.5
    assert status.objective_count == 1
    assert status.active_objectives == 1
    assert status.objective_statuses[0].current_activity == "running tests"


def test_projector_marks_completed_objective_and_mission():
    events = [
        event("MissionStarted"),
        event("ObjectiveStarted", objective_id="O1"),
        event(
            "ObjectiveCompleted",
            objective_id="O1",
            objective="Improve recovery",
            status="promoted",
            run_id="run-1",
            candidate_id="candidate-1",
            promoted_plan_revision_id="plan-rev-1",
        ),
        event("MissionCompleted"),
    ]

    status = OperationalStatusProjector.from_events("mission-1", events)

    assert status.status == "completed"
    assert status.progress == 1.0
    assert status.completed_objectives == 1
    assert status.objective_statuses[0].status == "completed"


def test_projector_preserves_failure_reason():
    events = [
        event("MissionStarted"),
        event("ObjectiveStarted", objective_id="O1"),
        event(
            "ObjectiveRejected",
            objective_id="O1",
            objective="Improve recovery",
            status="rejected",
            error="candidate does not meet minimum improvement requirement",
            run_id="run-1",
            candidate_id="candidate-1",
        ),
    ]

    status = OperationalStatusProjector.from_events("mission-1", events)

    assert status.failed_objectives == 1
    assert status.latest_error == (
        "candidate does not meet minimum improvement requirement"
    )
    assert status.objective_statuses[0].error == (
        "candidate does not meet minimum improvement requirement"
    )


def test_live_reader_rebuilds_status_from_store():
    store = InMemoryEventStore()
    store.append(event("MissionStarted"))
    store.append(event("ObjectiveStarted", objective_id="O1"))

    status = OperationalStatusProjector(store).mission("mission-1")

    assert status.status == "running"
    assert status.active_objectives == 1



def test_projector_surfaces_all_mission_terminal_and_waiting_states():
    cases = {
        "MissionCancelled": "cancelled",
        "MissionDeadLettered": "dead_lettered",
        "MissionBlockedPendingUser": "blocked_pending_user",
        "MissionRetryScheduled": "retrying",
    }
    for event_type, expected in cases.items():
        status = OperationalStatusProjector.from_events(
            "mission-1",
            [event("MissionStarted"), event(event_type, error="state detail")],
        )
        assert status.status == expected
        assert status.latest_error == "state detail"
