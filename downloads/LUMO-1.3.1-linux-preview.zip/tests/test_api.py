"""Tests for the local LUMO HTTP control plane."""
from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.request

from ocean.api import LumoAPI, LumoAPIServer
from ocean.service import OceanService
from ocean.domain.event import Event


def _request(url: str, method: str = "GET", body=None):
    data = None if body is None else json.dumps(body).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=2) as response:
            return response.status, json.loads(response.read())
    except urllib.error.HTTPError as exc:
        return exc.code, json.loads(exc.read())


def test_health_and_events(tmp_path):
    service = OceanService(repository_root=tmp_path)
    service.start()
    server = LumoAPIServer(service, port=0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://{server.address[0]}:{server.address[1]}"
    try:
        status, body = _request(base + "/api/health")
        assert status == 200
        assert body == {"status": "ok", "running": True}

        status, body = _request(base + "/api/events")
        assert status == 200
        assert body["events"] == []
    finally:
        server.shutdown()
        thread.join(timeout=2)
        service.stop()


def test_mission_status_is_event_sourced(tmp_path):
    service = OceanService(repository_root=tmp_path)
    service.start()
    assert service.events is not None
    service.events.publish(
        __import__("ocean.domain.event", fromlist=["Event"]).Event(
            type="MissionSubmissionAccepted",
            aggregate_type="mission_submission",
            aggregate_id="mission-test",
            payload={"mission_id": "mission-test", "account_id": __import__("ocean.accounts", fromlist=["AccountStore"]).AccountStore(service._state_dir / "accounts.sqlite3").ensure_default()["id"]},
        )
    )
    service.events.publish(
        __import__("ocean.domain.event", fromlist=["Event"]).Event(
            type="MissionStarted",
            aggregate_type="mission",
            aggregate_id="mission-test",
            payload={"mission_id": "mission-test", "goal": "test"},
        )
    )
    server = LumoAPIServer(service, port=0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://{server.address[0]}:{server.address[1]}"
    try:
        status, body = _request(base + "/api/missions/mission-test")
        assert status == 200
        assert body["id"] == "mission-test"
        assert body["status"] == "running"
    finally:
        server.shutdown()
        thread.join(timeout=2)
        service.stop()


def test_submit_mission_validates_and_records_submission(tmp_path):
    service = OceanService(repository_root=tmp_path)
    service.start()
    server = LumoAPIServer(service, port=0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://{server.address[0]}:{server.address[1]}"
    try:
        status, body = _request(base + "/api/missions", "POST", {"goal": "test mission"})
        assert status == 202
        assert body.get("mission_id")
        assert body["state"] == "starting"
        assert service.events is not None
        assert any(
            event.type == "MissionSubmissionAccepted"
            for event in service.events.history("MissionSubmissionAccepted")
        )

        status, body = _request(base + "/api/missions", "POST", {})
        assert status == 400
        assert "goal" in body["error"]

        status, body = _request(base + "/api/submissions/does-not-exist")
        assert status == 404
        assert body["error"] == "does-not-exist"
    finally:
        server.shutdown()
        thread.join(timeout=2)
        service.stop()


def test_mission_not_found_and_event_pagination(tmp_path):
    service = OceanService(repository_root=tmp_path)
    service.start()
    assert service.events is not None
    from ocean.domain.event import Event

    account_id = __import__("ocean.accounts", fromlist=["AccountStore"]).AccountStore(service._state_dir / "accounts.sqlite3").ensure_default()["id"]
    service.events.publish(Event(
        type="MissionSubmissionAccepted",
        aggregate_type="mission_submission",
        aggregate_id="mission-page",
        payload={"mission_id": "mission-page", "account_id": account_id},
    ))
    for i in range(3):
        service.events.publish(Event(
            type="MissionStarted" if i == 0 else "ObjectiveProgressed",
            aggregate_type="mission" if i == 0 else "objective",
            aggregate_id="mission-page" if i == 0 else f"objective-{i}",
            payload={
                "mission_id": "mission-page",
                "objective_id": f"objective-{i}",
                "progress": i / 2,
            },
        ))

    server = LumoAPIServer(service, port=0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://{server.address[0]}:{server.address[1]}"
    try:
        status, body = _request(base + "/api/missions/missing")
        assert status == 404
        assert "missing" in body["error"]

        status, body = _request(base + "/api/events?mission_id=mission-page&limit=2")
        assert status == 200
        assert len(body["events"]) == 2

        status, body = _request(base + "/api/events?mission_id=mission-page&offset=3&limit=2")
        assert status == 200
        assert len(body["events"]) == 1

        status, body = _request(base + "/api/events?limit=0")
        assert status == 400
        status, body = _request(base + "/api/events?offset=-1")
        assert status == 400
    finally:
        server.shutdown()
        thread.join(timeout=2)
        service.stop()


def test_event_pagination_uses_durable_sequence(tmp_path):
    service = OceanService(repository_root=tmp_path)
    service.start()
    assert service.events is not None
    from ocean.api import LumoAPI
    from ocean.domain.event import Event

    for i in range(4):
        service.events.publish(Event(
            type="TestEvent",
            aggregate_type="mission",
            aggregate_id="mission-sequence",
            payload={"mission_id": "mission-sequence", "index": i},
        ))

    try:
        api = LumoAPI(service)
        first = api.events(limit=2)
        assert [event["sequence"] for event in first] == [1, 2]

        after_two = api.events(after_sequence=2, limit=10)
        assert [event["payload"]["index"] for event in after_two] == [2, 3]
        assert [event["sequence"] for event in after_two] == [3, 4]
    finally:
        service.stop()


def test_computer_api_requires_task_and_reports_status(tmp_path, monkeypatch):
    service = OceanService(repository_root=tmp_path)
    service.start()
    server = LumoAPIServer(service, port=0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://{server.address[0]}:{server.address[1]}"
    try:
        status, body = _request(base + "/api/computer", "POST", {"objective": "open a design app", "max_steps": 3, "allow_actions": False})
        assert status == 202
        task_id = body["task_id"]
        assert task_id.startswith("computer_")
        status, task = _request(base + f"/api/computer/{task_id}")
        assert status == 200
        assert task["task_id"] == task_id

        status, body = _request(base + "/api/computer", "POST", {"objective": "x", "max_steps": 0})
        assert status == 400
        status, body = _request(base + "/api/computer/missing")
        assert status == 404
    finally:
        server.shutdown()
        thread.join(timeout=2)
        service.stop()


def test_computer_task_read_model_rebuilds_from_durable_events(tmp_path):
    service = OceanService(repository_root=tmp_path)
    service.start()
    assert service.events is not None
    from ocean.api import LumoAPI
    from ocean.domain.event import Event

    task_id = "computer-restart"
    account_id = LumoAPI(service).account()["id"]
    service.events.publish(Event(
        type="ComputerTaskStarted",
        aggregate_type="computer_task",
        aggregate_id=task_id,
        payload={
            "task_id": task_id,
            "account_id": account_id,
            "objective": "open the editor",
            "max_steps": 12,
            "allow_actions": True,
            "model": "computer-use-preview",
        },
    ))
    service.events.publish(Event(
        type="ComputerActionExecuted",
        aggregate_type="computer_task",
        aggregate_id=task_id,
        payload={
            "task_id": task_id,
            "account_id": account_id,
            "step": 2,
            "operation": "screenshot",
            "success": True,
            "result": {"path": "/tmp/lumo-restart-proof.png"},
        },
    ))
    service.events.publish(Event(
        type="ComputerTaskCompleted",
        aggregate_type="computer_task",
        aggregate_id=task_id,
        payload={
            "task_id": task_id,
            "account_id": account_id,
            "status": "completed",
            "steps": 2,
            "message": "verified",
            "last_screenshot": "/tmp/lumo-restart-proof.png",
        },
    ))

    try:
        api = LumoAPI(service)
        rebuilt = api.computer_task(task_id)
        assert rebuilt["state"] == "completed"
        assert rebuilt["steps"] == 2
        assert rebuilt["objective"] == "open the editor"
        assert rebuilt["last_screenshot"] == "/tmp/lumo-restart-proof.png"
        assert api.computer_screenshot(task_id) == "/tmp/lumo-restart-proof.png"
    finally:
        service.stop()


def test_cors_allows_only_local_lumo_ui_origins(tmp_path):
    service = OceanService(repository_root=tmp_path)
    service.start()
    server = LumoAPIServer(service, port=0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://{server.address[0]}:{server.address[1]}"
    try:
        for origin in ("http://localhost:3000", "http://127.0.0.1:3000"):
            request = urllib.request.Request(base + "/api/health", headers={"Origin": origin})
            with urllib.request.urlopen(request, timeout=2) as response:
                assert response.headers["Access-Control-Allow-Origin"] == origin
                assert response.headers["Vary"] == "Origin"

        request = urllib.request.Request(base + "/api/health", headers={"Origin": "http://evil.test"})
        with urllib.request.urlopen(request, timeout=2) as response:
            assert response.headers.get("Access-Control-Allow-Origin") is None
    finally:
        server.shutdown()
        thread.join(timeout=2)
        service.stop()


def test_world_screenshot_uses_execution_result_success_flag(tmp_path):
    service = OceanService(repository_root=tmp_path)
    service.start()
    from ocean.api import LumoAPI
    from runtime.types import ExecutionResult
    api = LumoAPI(service)
    screenshot = tmp_path / "world.png"
    screenshot.write_bytes(b"png")

    class Worlds:
        def execute(self, world_id, request):
            return ExecutionResult.succeeded({"path": str(screenshot)})

    api._worlds = Worlds()
    try:
        assert api.world_screenshot("world-test") == str(screenshot)
    finally:
        service.stop()


def test_world_http_lifecycle(tmp_path):
    service = OceanService(repository_root=tmp_path)
    service.start()
    server = LumoAPIServer(service, port=0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://{server.address[0]}:{server.address[1]}"
    created_id = clone_id = None
    try:
        status, world = _request(base + "/api/worlds", "POST", {"kind": "browser", "persistent": True})
        assert status == 201
        created_id = world["id"]
        assert world["status"] == "ready"

        status, world = _request(base + f"/api/worlds/{created_id}/snapshot", "POST", {})
        assert status == 200
        assert world["snapshot_id"]

        status, world = _request(base + f"/api/worlds/{created_id}/reset", "POST", {})
        assert status == 200
        assert world["snapshot_id"] is None

        status, clone = _request(base + f"/api/worlds/{created_id}/clone", "POST", {})
        assert status == 201
        clone_id = clone["id"]
        assert clone["metadata"]["cloned_from"] == created_id

        status, world = _request(base + f"/api/worlds/{created_id}/destroy", "POST", {})
        assert status == 200 and world["status"] == "destroyed"
        status, world = _request(base + f"/api/worlds/{clone_id}/destroy", "POST", {})
        assert status == 200 and world["status"] == "destroyed"
    finally:
        server.shutdown()
        thread.join(timeout=2)
        service.stop()


def test_account_boundary_hides_missions_and_worlds(tmp_path):
    service = OceanService(repository_root=tmp_path)
    service.start()
    from ocean.api import LumoAPI
    from ocean.domain.event import Event
    api = LumoAPI(service)
    account_a = api.account()["id"]
    mission_id = "mission-account-a"
    service.events.publish(Event(
        type="MissionSubmissionAccepted", aggregate_type="mission_submission",
        aggregate_id=mission_id,
        payload={"mission_id": mission_id, "account_id": account_a, "goal": "A"},
    ))
    service.events.publish(Event(
        type="MissionStarted", aggregate_type="mission", aggregate_id=mission_id,
        payload={"mission_id": mission_id, "goal": "A"},
    ))
    world = api.create_world({"kind": "browser", "metadata": {"marker": "A"}})
    account_b = api.create_account("Account B")
    assert account_b["id"] != account_a
    assert api.account()["id"] == account_b["id"]
    try:
        import pytest
        with pytest.raises(KeyError):
            api.mission(mission_id)
        with pytest.raises(KeyError):
            api.world(world["id"])
        assert api.missions() == []
        assert api.worlds() == []
    finally:
        service.stop()


def test_control_plane_rejects_non_loopback_bind(tmp_path):
    service = OceanService(repository_root=tmp_path)
    service.start()
    try:
        import pytest
        with pytest.raises(ValueError, match="local-only"):
            LumoAPIServer(service, host="0.0.0.0", port=0)
        with pytest.raises(ValueError, match="local-only"):
            LumoAPIServer(service, host="192.168.1.10", port=0)
    finally:
        service.stop()


def test_control_plane_accepts_loopback_ipv6(tmp_path):
    service = OceanService(repository_root=tmp_path)
    service.start()
    server = LumoAPIServer(service, host="::1", port=0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        assert server.address[0] == "::1"
    finally:
        server.shutdown()
        thread.join(timeout=2)
        service.stop()


def test_control_plane_rejects_untrusted_browser_origin_for_state_changes(tmp_path):
    service = OceanService(repository_root=tmp_path)
    service.start()
    server = LumoAPIServer(service, port=0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        import http.client
        conn = http.client.HTTPConnection(server.address[0], server.address[1], timeout=2)
        body = b'{"enabled":true}'
        conn.request("POST", "/api/assistant", body=body, headers={
            "Content-Type": "application/json",
            "Origin": "https://evil.example",
            "Content-Length": str(len(body)),
        })
        response = conn.getresponse()
        assert response.status == 403
        conn.close()
    finally:
        server.shutdown()
        thread.join(timeout=2)
        service.stop()


def test_control_plane_accepts_trusted_ui_origin_for_state_changes(tmp_path):
    service = OceanService(repository_root=tmp_path)
    service.start()
    server = LumoAPIServer(service, port=0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        import http.client
        conn = http.client.HTTPConnection(server.address[0], server.address[1], timeout=2)
        body = b'{"enabled":false}'
        conn.request("POST", "/api/assistant", body=body, headers={
            "Content-Type": "application/json",
            "Origin": "http://localhost:3000",
            "Content-Length": str(len(body)),
        })
        response = conn.getresponse()
        assert response.status in {200, 500}
        conn.close()
    finally:
        server.shutdown()
        thread.join(timeout=2)
        service.stop()


def test_readiness_is_truthful_and_non_sensitive(tmp_path, monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    service = OceanService(repository_root=tmp_path)
    service.start()
    try:
        from ocean.api import LumoAPI
        api = LumoAPI(service)
        data = api.readiness()
        assert data["ready"] is False
        assert data["service"] == "running"
        assert data["event_store"] == "available"
        assert data["mission_execution"] is True
        assert data["degraded_reason"] != "mission_execution_unavailable"
        assert data["local_model_max_gib"] <= 64.0
        assert data["api_security"]["loopback_only"] is True
        assert "OPENAI_API_KEY" not in repr(data)
    finally:
        service.stop()


def test_mission_receipt_contains_durable_evidence(tmp_path):
    service = OceanService(repository_root=tmp_path)
    service.start()
    from ocean.api import LumoAPI
    from ocean.domain.event import Event
    api = LumoAPI(service)
    account_id = api.account()["id"]
    service.events.publish(Event(type="MissionSubmissionAccepted", aggregate_type="mission_submission", aggregate_id="receipt-1", payload={"mission_id":"receipt-1", "account_id":account_id, "goal":"test"}))
    service.events.publish(Event(type="MissionStarted", aggregate_type="mission", aggregate_id="receipt-1", payload={"mission_id":"receipt-1"}))
    service.events.publish(Event(type="EvidenceRecorded", aggregate_type="mission", aggregate_id="receipt-1", payload={"mission_id":"receipt-1", "evidence_id":"evidence-1"}))
    receipt = api.mission_receipt("receipt-1")
    assert receipt["mission_id"] == "receipt-1"
    assert receipt["status"] == "running"
    assert receipt["event_count"] == 3
    assert receipt["evidence_ids"] == ["evidence-1"]
    service.stop()


def test_http_mission_cancel_route_is_available(tmp_path):
    service = OceanService(repository_root=tmp_path)
    service.start()
    server = LumoAPIServer(service, port=0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://{server.address[0]}:{server.address[1]}"
    try:
        api = server.api
        account_id = api.account()["id"]
        from ocean.domain.event import Event
        service.events.publish(Event(type="MissionSubmissionAccepted", aggregate_type="mission_submission", aggregate_id="cancel-route", payload={"mission_id":"cancel-route", "account_id":account_id, "goal":"test"}))
        status, body = _request(base + "/api/missions/cancel-route/cancel", "POST", {})
        assert status == 200
        assert body["mission_id"] == "cancel-route"
        assert body["state"] == "cancellation_requested"
    finally:
        server.shutdown()
        thread.join(timeout=2)
        service.stop()


def test_incomplete_missions_are_recovered_after_api_restart(tmp_path):
    service1 = OceanService(repository_root=tmp_path)
    service1.start()
    try:
        api1 = LumoAPI(service1)
        # Persist the same accepted submission shape used by the HTTP path.
        mission_id = "mission-reboot-recovery"
        api1._missions[mission_id] = {"mission_id": mission_id, "goal": "resume this mission", "state": "running", "account_id": api1.account()["id"]}
        service1.events.publish(Event(type="MissionSubmissionAccepted", aggregate_type="mission_submission", aggregate_id=mission_id, payload={"mission_id": mission_id, "goal": "resume this mission", "account_id": api1.account()["id"]}, source="test"))
    finally:
        service1.stop()

    service2 = OceanService(repository_root=tmp_path)
    service2.start()
    try:
        api2 = LumoAPI(service2)
        recovered = api2.recover_incomplete_missions()
        assert mission_id in recovered
        assert api2.submission(mission_id)["state"] == "recoverable"
        assert mission_id in api2._recoverable_missions
    finally:
        service2.stop()
