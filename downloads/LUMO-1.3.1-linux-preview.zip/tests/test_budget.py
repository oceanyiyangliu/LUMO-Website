from ocean.resources.budget import Budget, BudgetLedger
from ocean.domain.event_bus import EventBus

def test_budget_authorizes_and_tracks_consumption():
    ledger=BudgetLedger(); b=ledger.create("m1", {"money": 2, "tool_calls": 3})
    assert b.remaining("money")==2
    assert ledger.authorize("m1", {"money":1.5})==(True,None)
    ledger.consume("m1", {"money":1.5,"tool_calls":2}, execution_id="e1")
    assert ledger.get("m1").remaining("money")==0.5

def test_budget_rejects_over_limit():
    ledger=BudgetLedger(); ledger.create("m1", {"money": 1})
    ok, reason=ledger.authorize("m1", {"money":1.01})
    assert not ok and "budget exceeded" in reason

def test_budget_rebuilds_from_events():
    events=EventBus(); ledger=BudgetLedger(events); ledger.create("m1", {"money":2}); ledger.consume("m1", {"money":0.75})
    rebuilt=BudgetLedger(events)
    rebuilt.rebuild(events.history())
    assert rebuilt.get("m1").consumed["money"]==0.75


def test_budget_rejects_non_finite_limits_and_costs():
    import math
    import pytest
    for value in (math.nan, math.inf, -math.inf):
        with pytest.raises(ValueError):
            Budget("m1", {"money": value})
    ledger = BudgetLedger(); ledger.create("m1", {"money": 10})
    for value in (math.nan, math.inf, -math.inf):
        ok, _ = ledger.authorize("m1", {"money": value})
        assert ok is False
