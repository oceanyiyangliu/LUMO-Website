from ocean.crypto import KeyRing
from ocean.worlds.secure_snapshot import SnapshotCipher

def test_encrypted_snapshot_roundtrip_and_rotation(tmp_path):
    ring=KeyRing(tmp_path/'keys.json'); cipher=SnapshotCipher(ring)
    original=b'world disk evidence'
    envelope=cipher.encrypt(original)
    assert cipher.decrypt(envelope)==original
    old=envelope.key_id; ring.rotate()
    assert cipher.encrypt(original).key_id != old
    assert cipher.decrypt(envelope)==original
