from __future__ import annotations

from datetime import datetime, timedelta, timezone

from ocean.platform_hardening import WorkerLeaseBook


def test_worker_lease_rejects_cross_worker_live_lease():
    book = WorkerLeaseBook()
    now = datetime.now(timezone.utc)
    book.acquire("task-1", "worker-a", 60, lease_id="lease-a", now=now)
    try:
        book.acquire("task-1", "worker-b", 60, lease_id="lease-b", now=now)
    except RuntimeError as exc:
        assert "already leased" in str(exc)
    else:
        raise AssertionError("cross-worker lease was accepted")


def test_worker_lease_can_be_reclaimed_after_expiry():
    book = WorkerLeaseBook()
    now = datetime.now(timezone.utc)
    book.acquire("task-1", "worker-a", 1, lease_id="lease-a", now=now)
    later = now + timedelta(seconds=2)
    lease = book.acquire("task-1", "worker-b", 60, lease_id="lease-b", now=later)
    assert lease.worker_id == "worker-b"
