import sqlite3

from eventing.sqlite_store import SQLiteEventStore
from ocean.domain.event import Event


def test_event_store_builds_and_verifies_hash_chain(tmp_path):
    conn = sqlite3.connect(tmp_path / "events.sqlite3")
    store = SQLiteEventStore(conn)
    store.append(Event(type="One", payload={"n": 1}))
    store.append(Event(type="Two", payload={"n": 2}))
    assert store.verify_integrity() is True


def test_event_store_detects_tampered_payload(tmp_path):
    conn = sqlite3.connect(tmp_path / "events.sqlite3")
    store = SQLiteEventStore(conn, encrypt_at_rest=False)
    event = Event(type="One", payload={"n": 1})
    store.append(event)
    import json
    data = json.loads(conn.execute('SELECT data FROM events WHERE id=?', (event.id,)).fetchone()[0])
    data['payload']['n'] = 999
    conn.execute('UPDATE events SET data=? WHERE id=?', (json.dumps(data), event.id))
    conn.commit()
    assert store.verify_integrity() is False

def test_event_store_encrypts_payload_at_rest_and_reads_it(tmp_path):
    conn = sqlite3.connect(tmp_path / "encrypted.sqlite3")
    store = SQLiteEventStore(conn)
    event = Event(type="Secret", payload={"token": "TOP-SECRET", "n": 7})
    store.append(event)
    raw = conn.execute("SELECT data FROM events WHERE id=?", (event.id,)).fetchone()[0]
    assert raw.startswith("v1:")
    assert "TOP-SECRET" not in raw
    assert store.get(event.id) == event
    assert store.verify_integrity() is True


def test_event_store_migrates_legacy_plaintext_rows(tmp_path):
    path = tmp_path / "legacy.sqlite3"
    conn = sqlite3.connect(path)
    plain = SQLiteEventStore(conn, encrypt_at_rest=False)
    event = Event(type="Legacy", payload={"value": "old"})
    plain.append(event)
    plain.close = lambda: None
    encrypted = SQLiteEventStore(conn, encrypt_at_rest=True)
    raw = conn.execute("SELECT data FROM events WHERE id=?", (event.id,)).fetchone()[0]
    assert raw.startswith("v1:")
    assert encrypted.get(event.id) == event
