import pytest
from ocean.intelligence_router import *

def test_router_is_capability_privacy_and_size_aware():
    from ocean.resources.intelligence_governor import DeviceResources, LocalResourceGovernor
    governor=LocalResourceGovernor(sampler=lambda: DeviceResources(16*1024**3, 12*1024**3, 9*1024**3, 10, None, None))
    r=ModelRegistry([ModelManifest("big-local","ollama",frozenset({"reasoning"}),1000,20,0,12,"local"),ModelManifest("small-local","ollama",frozenset({"reasoning"}),1000,30,0,8,"local"),ModelManifest("cloud","cloud",frozenset({"reasoning","vision"}),2000,100,1,None,"cloud")])
    out=IntelligenceRouter(r, governor=governor).route(RouteRequest(capabilities=frozenset({"reasoning"}),local_only=True)); assert out.model_id=="small-local"
    with pytest.raises(RuntimeError): IntelligenceRouter(r).route(RouteRequest(capabilities=frozenset({"vision"}),local_only=True))

def test_unknown_local_size_fails_closed():
    r=ModelRegistry([ModelManifest("unknown","ollama",frozenset({"reasoning"}),1000,1,0,None,"local")])
    with pytest.raises(RuntimeError): IntelligenceRouter(r).route(RouteRequest(capabilities=frozenset({"reasoning"}),local_only=True))
