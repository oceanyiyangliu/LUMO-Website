from ocean.intelligence_swarm import IntelligenceSwarm, ROLES

def test_swarm_defines_specialists():
    names={r.name for r in ROLES}
    assert {"planner","coder","vision","researcher","critic"}.issubset(names)

def test_swarm_is_adaptive_and_does_not_require_resident_models():
    snap=IntelligenceSwarm().snapshot()
    assert snap["adaptive"] is True
    assert snap["resident_models"] == 0
    assert snap["parallelism"] >= 1
