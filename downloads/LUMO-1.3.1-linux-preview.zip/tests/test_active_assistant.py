from ocean.active_assistant import ActiveAssistant

def test_active_assistant_is_safe_and_disabled_by_default():
    assistant = ActiveAssistant()
    assert assistant.status()["enabled"] is False
    assert assistant.status()["attention"] is None
    assistant.dismiss()
    assert assistant.status()["state"] == "idle"


def test_active_assistant_capture_uses_current_execution_request_contract(monkeypatch):
    assistant = ActiveAssistant()
    class FakeExecutor:
        def execute(self, request, context):
            assert request.task_id.startswith("assistant-screen-")
            assert request.capability == "computer"
            assert request.operation == "screenshot"
            from runtime.types import ExecutionResult
            return ExecutionResult.succeeded({"path": "/tmp/screen.png", "application": "Google Chrome", "window": ""})
    assistant._executor = FakeExecutor()
    assert assistant._capture() == ("/tmp/screen.png", "Google Chrome", "")


def test_context_confidence_is_nonzero_after_observation():
    assistant = ActiveAssistant()
    assistant._digest = "old"
    assistant._emit({"context_confidence": 0.72})
    assert assistant.status()["context_confidence"] == 0.72

def test_enabling_assistant_never_starts_host_observation(monkeypatch):
    assistant = ActiveAssistant()
    calls = []

    def forbidden_capture():
        calls.append(True)
        raise AssertionError("host capture must be explicitly resumed")

    monkeypatch.setattr(assistant, "_capture", forbidden_capture)
    status = assistant.start()
    assert status["enabled"] is True
    assert status["observation_paused"] is True
    assert status["state"] == "ready"
    assert calls == []


def test_observation_requires_explicit_resume(monkeypatch):
    assistant = ActiveAssistant()
    calls = []

    def fake_capture():
        calls.append(True)
        assistant.stop()
        return None

    monkeypatch.setattr(assistant, "_capture", fake_capture)
    assistant.start()
    assert calls == []
    assistant.resume_observation()
    assistant._thread.join(timeout=2.0)
    assert calls

def test_authoritative_human_action_is_visible_without_screen_observation():
    assistant = ActiveAssistant()
    status = assistant.notify_human_action(
        message="LUMO is ready and needs your release decision.",
        suggestion="Review the safety acknowledgement and release LUMO when ready.",
        kind="safety_release",
    )
    assert status["state"] == "attention"
    assert status["observation_paused"] is True
    assert status["attention"]["kind"] == "safety_release"
    assert status["attention"]["message"].startswith("LUMO is ready")


def test_duplicate_authoritative_attention_does_not_spam_history():
    assistant = ActiveAssistant()
    first = assistant.notify_human_action(message="Review one thing.", kind="setup")
    second = assistant.notify_human_action(message="Review one thing.", kind="setup")
    assert first["attention_count"] == second["attention_count"] == 1
    assert len(second["attention"]) > 0
