from __future__ import annotations

import pytest

from ocean.domain.agent import Agent
from ocean.domain.assignment import Assignment
from ocean.domain.enums import AgentStatus, AssignmentStatus, OrchestrationMode
from ocean.domain.mission import Mission
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.domain.task import Task
from ocean.orchestration.orchestrator import Orchestrator, OrchestrationPorts
from ocean.orchestration.types import ExecutionIntent, OrchestrationResult
from ocean.recovery.engine import RecoveryEngine
from ocean.recovery.policy import DefaultRecoveryPolicy
from ocean.recovery.types import RecoveryAction
from ocean.workforce import AssignmentLeaseCoordinator, AssignmentLeaseState
from runtime.types import ExecutionResult
from persistence.in_memory import InMemoryRepository


class FakeRuntime:
    def __init__(self):
        self.calls = []
        self.next_id = 0

    def submit(self, agent_id, request, *, priority=0, dependencies=None):
        from runtime.scheduler import ScheduledExecution

        self.next_id += 1
        execution_id = f"execution-{self.next_id}"
        scheduled = ScheduledExecution(
            request=request,
            priority=priority,
            dependencies=set(dependencies or ()),
            execution_id=execution_id,
        )
        self.calls.append(
            (agent_id, request, priority, tuple(dependencies or ()))
        )
        return scheduled

    def mark_idle(self, agent_id):
        return None

    def mark_waiting(self, agent_id):
        return None

    def mark_background(self, agent_id):
        return None


class Resolver:
    def __init__(self, agent_id):
        self.agent_id = agent_id
        self.calls = []

    def resolve(self, *, task, failed_assignment, attempt):
        self.calls.append((task.id, failed_assignment.id, attempt))
        return self.agent_id


class IntentProvider:
    def __init__(self, intent=None):
        self.intent = intent or ExecutionIntent(
            capability="test",
            operation="execute",
            arguments={"value": 1},
        )
        self.calls = []

    def get(self, *, assignment, task):
        self.calls.append((assignment.id, task.id))
        return self.intent


def build():
    events = EventBus()

    missions = InMemoryRepository()
    tasks = InMemoryRepository()
    assignments = InMemoryRepository()
    agents = InMemoryRepository()

    runtime = FakeRuntime()

    agent_a = Agent(name="A", role="worker", status=AgentStatus.IDLE)
    agent_b = Agent(name="B", role="worker", status=AgentStatus.IDLE)

    agents.save(agent_a)
    agents.save(agent_b)

    ports = OrchestrationPorts(
        missions=missions,
        tasks=tasks,
        assignments=assignments,
        agents=agents,
        agent_runtime=runtime,
        events=events,
    )
    orchestrator = Orchestrator(ports)

    task = Task(title="Do work")
    tasks.save(task)

    return (
        events,
        tasks,
        assignments,
        orchestrator,
        task,
        agent_a,
        agent_b,
    )


def failed_assignment(*, task, agent, assignments):
    assignment = Assignment(
        task_id=task.id,
        agent_id=agent.id,
        mode=OrchestrationMode.STANDARD,
        status=AssignmentStatus.ACTIVE,
    )
    assignment.bind_execution("execution-original")
    assignment.fail(reason="execution failed")
    assignments.save(assignment)
    return assignment


def test_retry_creates_new_assignment_without_mutating_failed_source():
    events, tasks, assignments, orchestrator, task, agent_a, agent_b = build()

    source = failed_assignment(
        task=task,
        agent=agent_a,
        assignments=assignments,
    )

    recovery = RecoveryEngine(
        event_bus=events,
        assignments=assignments,
        tasks=tasks,
        orchestrator=orchestrator,
        execution_intent_provider=IntentProvider(),
        policy=DefaultRecoveryPolicy(
            retry_allowed=True,
            reassign_allowed=False,
            max_retries=1,
        ),
    )

    result = recovery.recover(source.id)

    assert result.success is True
    assert result.action is RecoveryAction.RETRY
    assert result.replacement_assignment_id is not None

    replacement = assignments.get(result.replacement_assignment_id)

    assert replacement is not None
    assert replacement.parent_assignment_id == source.id
    assert replacement.agent_id == agent_a.id
    assert replacement.status is AssignmentStatus.QUEUED

    unchanged = assignments.get(source.id)
    assert unchanged.status is AssignmentStatus.FAILED


def test_expired_lease_hands_assignment_to_existing_recovery_engine():
    events, tasks, assignments, orchestrator, task, agent_a, agent_b = build()
    source = Assignment(
        task_id=task.id,
        agent_id=agent_a.id,
        mode=OrchestrationMode.STANDARD,
        status=AssignmentStatus.ACTIVE,
    )
    source.bind_execution("execution-original")
    assignments.save(source)

    recovery = RecoveryEngine(
        event_bus=events,
        assignments=assignments,
        tasks=tasks,
        orchestrator=orchestrator,
        execution_intent_provider=IntentProvider(),
        policy=DefaultRecoveryPolicy(
            retry_allowed=True,
            reassign_allowed=False,
            max_retries=1,
        ),
    )
    coordinator = AssignmentLeaseCoordinator(
        event_bus=events,
        assignment_failure_handler=lambda assignment_id, reason: orchestrator.reconcile(
            assignment_id,
            ExecutionResult.failed(reason),
        ),
    )
    lease = coordinator.acquire(
        assignment_id=source.id,
        agent_id=source.agent_id,
        attempt_id="attempt-original",
        execution_id=source.execution_id,
        lease_seconds=1,
    )

    expired = coordinator.expire(
        lease.lease_id,
        attempt_id="attempt-original",
        agent_id=source.agent_id,
        at=lease.expires_at,
    )

    assert expired.state is AssignmentLeaseState.EXPIRED
    assert assignments.get(source.id).status is AssignmentStatus.FAILED
    replacements = [
        assignment
        for assignment in assignments.list()
        if assignment.parent_assignment_id == source.id
    ]
    assert len(replacements) == 1
    replacement = replacements[0]
    replacement_lease = coordinator.acquire(
        assignment_id=replacement.id,
        agent_id=replacement.agent_id,
        attempt_id="attempt-replacement",
        execution_id="execution-replacement",
        lease_seconds=10,
    )

    assert replacement_lease.lease_id != lease.lease_id
    assert coordinator.can_complete(
        lease.lease_id,
        attempt_id="attempt-original",
        agent_id=source.agent_id,
    ) is False
    assert coordinator.can_complete(
        replacement_lease.lease_id,
        attempt_id="attempt-replacement",
        agent_id=replacement.agent_id,
    ) is True


def test_reassign_uses_resolver_after_retry_budget_is_exhausted():
    events, tasks, assignments, orchestrator, task, agent_a, agent_b = build()

    source = failed_assignment(
        task=task,
        agent=agent_a,
        assignments=assignments,
    )

    resolver = Resolver(agent_b.id)

    recovery = RecoveryEngine(
        event_bus=events,
        assignments=assignments,
        tasks=tasks,
        orchestrator=orchestrator,
        execution_intent_provider=IntentProvider(),
        policy=DefaultRecoveryPolicy(
            retry_allowed=False,
            reassign_allowed=True,
            max_retries=0,
        ),
        agent_resolver=resolver,
    )

    result = recovery.recover(source.id)

    assert result.success is True
    assert result.action is RecoveryAction.REASSIGN
    assert resolver.calls == [(task.id, source.id, 0)]

    replacement = assignments.get(result.replacement_assignment_id)
    assert replacement.agent_id == agent_b.id
    assert replacement.parent_assignment_id == source.id


def test_exhausted_policy_creates_no_replacement():
    events, tasks, assignments, orchestrator, task, agent_a, agent_b = build()

    source = failed_assignment(
        task=task,
        agent=agent_a,
        assignments=assignments,
    )

    recovery = RecoveryEngine(
        event_bus=events,
        assignments=assignments,
        tasks=tasks,
        orchestrator=orchestrator,
        execution_intent_provider=IntentProvider(),
        policy=DefaultRecoveryPolicy(
            retry_allowed=False,
            reassign_allowed=False,
            max_retries=0,
        ),
    )

    result = recovery.recover(source.id)

    assert result.success is False
    assert result.action is RecoveryAction.EXHAUSTED
    assert len(list(assignments.list())) == 1


def test_non_failed_assignment_is_ignored():
    events, tasks, assignments, orchestrator, task, agent_a, agent_b = build()

    assignment = Assignment(
        task_id=task.id,
        agent_id=agent_a.id,
        mode=OrchestrationMode.STANDARD,
        status=AssignmentStatus.QUEUED,
    )
    assignments.save(assignment)

    recovery = RecoveryEngine(
        event_bus=events,
        assignments=assignments,
        tasks=tasks,
        orchestrator=orchestrator,
    )

    result = recovery.recover(assignment.id)

    assert result.action is RecoveryAction.IGNORE
    assert result.success is False


def test_missing_assignment_is_ignored():
    events, tasks, assignments, orchestrator, task, agent_a, agent_b = build()

    recovery = RecoveryEngine(
        event_bus=events,
        assignments=assignments,
        tasks=tasks,
        orchestrator=orchestrator,
    )

    result = recovery.recover("assignment-missing")

    assert result.action is RecoveryAction.IGNORE
    assert result.success is False


def test_failure_event_triggers_recovery():
    events, tasks, assignments, orchestrator, task, agent_a, agent_b = build()

    source = failed_assignment(
        task=task,
        agent=agent_a,
        assignments=assignments,
    )

    RecoveryEngine(
        event_bus=events,
        assignments=assignments,
        tasks=tasks,
        orchestrator=orchestrator,
        policy=DefaultRecoveryPolicy(
            retry_allowed=True,
            reassign_allowed=False,
            max_retries=1,
        ),
        execution_intent_provider=IntentProvider(),
    )

    failures = events.publish(
        Event(
            type="TaskAssignmentFailed",
            payload={
                "assignment_id": source.id,
                "task_id": task.id,
                "agent_id": agent_a.id,
            },
            aggregate_type="assignment",
            aggregate_id=source.id,
            causation_id=source.id,
        )
    )

    assert failures == []

    all_assignments = list(assignments.list())
    assert len(all_assignments) == 2
    assert any(
        a.parent_assignment_id == source.id
        for a in all_assignments
    )


def test_recovery_preserves_mission_and_priority_lineage():
    events, tasks, assignments, orchestrator, task, agent_a, agent_b = build()

    mission = Mission(
        goal="Recovery lineage test",
        task_ids=[task.id],
        id="mission-1",
    )
    task.mission_id = mission.id
    tasks.save(task)
    orchestrator.ports.missions.save(mission)

    source = Assignment(
        task_id=task.id,
        agent_id=agent_a.id,
        mission_id="mission-1",
        mode=OrchestrationMode.STANDARD,
        priority=7,
        status=AssignmentStatus.ACTIVE,
    )
    source.bind_execution("execution-original")
    source.fail(reason="failed")
    assignments.save(source)

    recovery = RecoveryEngine(
        event_bus=events,
        assignments=assignments,
        tasks=tasks,
        orchestrator=orchestrator,
        execution_intent_provider=IntentProvider(),
        policy=DefaultRecoveryPolicy(
            retry_allowed=True,
            reassign_allowed=False,
            max_retries=1,
        ),
    )

    result = recovery.recover(source.id)
    replacement = assignments.get(result.replacement_assignment_id)

    assert replacement.mission_id == "mission-1"
    assert replacement.priority == 7
    assert replacement.parent_assignment_id == source.id
    assert replacement.metadata["recovery"] is True
    assert replacement.metadata["recovery_action"] == "retry"


def test_reassignment_without_resolver_exhausts_cleanly():
    events, tasks, assignments, orchestrator, task, agent_a, agent_b = build()

    source = failed_assignment(
        task=task,
        agent=agent_a,
        assignments=assignments,
    )

    recovery = RecoveryEngine(
        event_bus=events,
        assignments=assignments,
        tasks=tasks,
        orchestrator=orchestrator,
        execution_intent_provider=IntentProvider(),
        policy=DefaultRecoveryPolicy(
            retry_allowed=False,
            reassign_allowed=True,
            max_retries=0,
        ),
    )

    result = recovery.recover(source.id)

    assert result.success is False
    assert result.action is RecoveryAction.EXHAUSTED
    assert "no resolver" in result.reason


def test_recovery_never_reuses_failed_assignment_id():
    events, tasks, assignments, orchestrator, task, agent_a, agent_b = build()

    source = failed_assignment(
        task=task,
        agent=agent_a,
        assignments=assignments,
    )

    recovery = RecoveryEngine(
        event_bus=events,
        assignments=assignments,
        tasks=tasks,
        orchestrator=orchestrator,
        execution_intent_provider=IntentProvider(),
        policy=DefaultRecoveryPolicy(
            retry_allowed=True,
            reassign_allowed=False,
            max_retries=1,
        ),
    )

    result = recovery.recover(source.id)

    assert result.replacement_assignment_id != source.id
    assert assignments.get(source.id).status is AssignmentStatus.FAILED
