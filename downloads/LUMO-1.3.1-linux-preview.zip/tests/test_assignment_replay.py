import pytest

from ocean.domain.event import Event
from ocean.event_sourcing.replay import EventReplayer, ReplayError
from ocean.domain.enums import AssignmentStatus, OrchestrationMode


def event(event_type, **payload):
    return Event(
        type=event_type,
        payload=payload,
        aggregate_type="assignment",
        aggregate_id=payload.get("assignment_id", "assignment-1"),
    )


def created(**overrides):
    payload = {
        "assignment_id": "assignment-1",
        "task_id": "task-1",
        "agent_id": "agent-1",
        "mission_id": "mission-1",
        "mode": OrchestrationMode.PARALLEL.value,
        "priority": 10,
        "parent_assignment_id": "assignment-parent",
        "reason": "recovery",
        "metadata": {"attempt": 2},
    }
    payload.update(overrides)
    return event("TaskAssignmentCreated", **payload)


def test_replayer_replays_assignment_creation():
    state = EventReplayer().replay([
        created(),
    ])

    assignment = state.assignments["assignment-1"]

    assert assignment.id == "assignment-1"
    assert assignment.task_id == "task-1"
    assert assignment.agent_id == "agent-1"
    assert assignment.mission_id == "mission-1"
    assert assignment.mode is OrchestrationMode.PARALLEL
    assert assignment.priority == 10
    assert assignment.parent_assignment_id == "assignment-parent"
    assert assignment.reason == "recovery"
    assert assignment.metadata == {"attempt": 2}
    assert assignment.status is AssignmentStatus.CREATED


def test_replayer_replays_assignment_queue():
    state = EventReplayer().replay([
        created(),
        event(
            "TaskAssignmentQueued",
            assignment_id="assignment-1",
            reason="orchestration admitted",
        ),
    ])

    assert state.assignments["assignment-1"].status is AssignmentStatus.QUEUED
    assert state.assignments["assignment-1"].reason == "orchestration admitted"


def test_replayer_replays_assignment_activation():
    state = EventReplayer().replay([
        created(),
        event(
            "TaskAssignmentQueued",
            assignment_id="assignment-1",
        ),
        event(
            "TaskAssignmentActivated",
            assignment_id="assignment-1",
            task_id="task-1",
            agent_id="agent-1",
            mission_id="mission-1",
            execution_id="execution-1",
        ),
    ])

    assignment = state.assignments["assignment-1"]

    assert assignment.status is AssignmentStatus.ACTIVE
    assert assignment.execution_id == "execution-1"


def test_replayer_replays_assignment_completion():
    state = EventReplayer().replay([
        created(),
        event("TaskAssignmentQueued", assignment_id="assignment-1"),
        event(
            "TaskAssignmentActivated",
            assignment_id="assignment-1",
            execution_id="execution-1",
        ),
        event(
            "TaskAssignmentCompleted",
            assignment_id="assignment-1",
            execution_id="execution-1",
            result={"answer": 42},
        ),
    ])

    assignment = state.assignments["assignment-1"]

    assert assignment.status is AssignmentStatus.COMPLETED
    assert assignment.execution_id == "execution-1"


def test_replayer_replays_assignment_failure():
    state = EventReplayer().replay([
        created(),
        event("TaskAssignmentQueued", assignment_id="assignment-1"),
        event(
            "TaskAssignmentActivated",
            assignment_id="assignment-1",
            execution_id="execution-1",
        ),
        event(
            "TaskAssignmentFailed",
            assignment_id="assignment-1",
            execution_id="execution-1",
            error="controlled failure",
        ),
    ])

    assignment = state.assignments["assignment-1"]

    assert assignment.status is AssignmentStatus.FAILED
    assert assignment.reason == "controlled failure"
    assert assignment.execution_id == "execution-1"


@pytest.mark.parametrize(
    "terminal_event, expected_status",
    [
        (
            "TaskAssignmentSuperseded",
            AssignmentStatus.SUPERSEDED,
        ),
        (
            "TaskAssignmentCancelled",
            AssignmentStatus.CANCELLED,
        ),
    ],
)
def test_replayer_replays_assignment_terminal_transitions(
    terminal_event,
    expected_status,
):
    state = EventReplayer().replay([
        created(),
        event("TaskAssignmentQueued", assignment_id="assignment-1"),
        event(
            "TaskAssignmentActivated",
            assignment_id="assignment-1",
            execution_id="execution-1",
        ),
        event(
            terminal_event,
            assignment_id="assignment-1",
            reason="terminal transition",
        ),
    ])

    assert state.assignments["assignment-1"].status is expected_status
    assert state.assignments["assignment-1"].reason == "terminal transition"


def test_replayer_rejects_duplicate_assignment_creation():
    with pytest.raises(ReplayError, match="already exists"):
        EventReplayer().replay([
            created(),
            created(),
        ])


@pytest.mark.parametrize(
    "event_type",
    [
        "TaskAssignmentQueued",
        "TaskAssignmentActivated",
        "TaskAssignmentCompleted",
        "TaskAssignmentFailed",
        "TaskAssignmentSuperseded",
        "TaskAssignmentCancelled",
    ],
)
def test_replayer_rejects_assignment_event_for_unknown_assignment(
    event_type,
):
    payload = {
        "assignment_id": "missing-assignment",
    }

    if event_type == "TaskAssignmentActivated":
        payload["execution_id"] = "execution-1"

    if event_type in {
        "TaskAssignmentFailed",
        "TaskAssignmentSuperseded",
        "TaskAssignmentCancelled",
    }:
        payload["reason"] = "test"

    with pytest.raises(ReplayError, match="unknown assignment"):
        EventReplayer().replay([
            event(event_type, **payload),
        ])


def test_replayer_rejects_assignment_activation_before_queue():
    with pytest.raises(ReplayError, match="invalid TaskAssignmentActivated"):
        EventReplayer().replay([
            created(),
            event(
                "TaskAssignmentActivated",
                assignment_id="assignment-1",
                execution_id="execution-1",
            ),
        ])


def test_replayer_rejects_assignment_completion_before_activation():
    with pytest.raises(ReplayError, match="invalid TaskAssignmentCompleted"):
        EventReplayer().replay([
            created(),
            event(
                "TaskAssignmentQueued",
                assignment_id="assignment-1",
            ),
            event(
                "TaskAssignmentCompleted",
                assignment_id="assignment-1",
            ),
        ])


def test_replayer_rejects_assignment_failure_before_activation():
    with pytest.raises(ReplayError, match="invalid TaskAssignmentFailed"):
        EventReplayer().replay([
            created(),
            event(
                "TaskAssignmentQueued",
                assignment_id="assignment-1",
            ),
            event(
                "TaskAssignmentFailed",
                assignment_id="assignment-1",
                error="failure",
            ),
        ])
