from __future__ import annotations

from ocean.domain.agent import Agent
from ocean.domain.enums import AgentStatus
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from runtime.agent_controller import AgentController
from runtime.agent_execution_lifecycle import AgentExecutionLifecycle
from runtime.agent_registry import AgentRegistry


def make_lifecycle():
    bus = EventBus()
    registry = AgentRegistry()
    controller = AgentController(event_bus=bus)

    lifecycle = AgentExecutionLifecycle(
        event_bus=bus,
        registry=registry,
        controller=controller,
    )

    agent = Agent(
        name="Alice",
        role="worker",
        capabilities={"research"},
    )
    registry.register(agent)

    return bus, registry, controller, lifecycle, agent


def dispatch_event(agent, execution_id="exec-1", task_id="task-1"):
    return Event(
        type="ScheduledExecutionDispatched",
        payload={
            "id": execution_id,
            "agent_id": agent.id,
            "task_id": task_id,
        },
        aggregate_type="scheduled_execution",
        aggregate_id=execution_id,
    )


def completion_event(agent, execution_id="exec-1", task_id="task-1"):
    return Event(
        type="ScheduledExecutionCompleted",
        payload={
            "id": execution_id,
            "agent_id": agent.id,
            "task_id": task_id,
        },
        aggregate_type="scheduled_execution",
        aggregate_id=execution_id,
    )


def failure_event(agent, execution_id="exec-1", task_id="task-1"):
    return Event(
        type="ScheduledExecutionFailed",
        payload={
            "id": execution_id,
            "agent_id": agent.id,
            "task_id": task_id,
            "error": "execution failed",
        },
        aggregate_type="scheduled_execution",
        aggregate_id=execution_id,
    )


def test_dispatch_event_activates_agent():
    bus, _, _, _, agent = make_lifecycle()

    assert agent.status is AgentStatus.IDLE

    failures = bus.publish(dispatch_event(agent))

    assert failures == []
    assert agent.status is AgentStatus.RUNNING
    assert agent.current_task_id == "task-1"


def test_completion_event_returns_agent_to_idle():
    bus, _, _, _, agent = make_lifecycle()

    bus.publish(dispatch_event(agent))
    failures = bus.publish(completion_event(agent))

    assert failures == []
    assert agent.status is AgentStatus.IDLE
    assert agent.current_task_id is None


def test_failure_event_returns_agent_to_idle_without_marking_agent_failed():
    bus, _, _, _, agent = make_lifecycle()

    bus.publish(dispatch_event(agent))
    failures = bus.publish(failure_event(agent))

    assert failures == []
    assert agent.status is AgentStatus.IDLE
    assert agent.current_task_id is None


def test_duplicate_dispatch_event_is_idempotent():
    bus, _, _, _, agent = make_lifecycle()

    event = dispatch_event(agent)

    first_failures = bus.publish(event)
    second_failures = bus.publish(event)

    assert first_failures == []
    assert second_failures == []
    assert agent.status is AgentStatus.RUNNING
    assert agent.current_task_id == "task-1"


def test_dispatch_for_unknown_agent_is_rejected():
    bus, _, _, _, _ = make_lifecycle()

    failures = bus.publish(
        Event(
            type="ScheduledExecutionDispatched",
            payload={
                "id": "exec-1",
                "agent_id": "missing-agent",
                "task_id": "task-1",
            },
            aggregate_type="scheduled_execution",
            aggregate_id="exec-1",
        )
    )

    assert len(failures) == 1
    assert isinstance(failures[0].error, KeyError)


def test_completion_for_wrong_task_is_rejected():
    bus, _, _, _, agent = make_lifecycle()

    bus.publish(dispatch_event(agent))

    failures = bus.publish(
        completion_event(
            agent,
            execution_id="exec-1",
            task_id="different-task",
        )
    )

    assert len(failures) == 1
    assert isinstance(failures[0].error, ValueError)
    assert agent.status is AgentStatus.RUNNING
    assert agent.current_task_id == "task-1"


def test_failure_for_wrong_task_is_rejected():
    bus, _, _, _, agent = make_lifecycle()

    bus.publish(dispatch_event(agent))

    failures = bus.publish(
        failure_event(
            agent,
            execution_id="exec-1",
            task_id="different-task",
        )
    )

    assert len(failures) == 1
    assert isinstance(failures[0].error, ValueError)
    assert agent.status is AgentStatus.RUNNING
    assert agent.current_task_id == "task-1"
