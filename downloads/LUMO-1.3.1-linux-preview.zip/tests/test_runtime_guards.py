import pytest

from runtime.guards import DescriptorLimit, ExecutionIdempotency

def test_descriptor_limit_validates():
    assert DescriptorLimit(1).validate()

def test_execution_idempotency_is_atomic(tmp_path):
    s = ExecutionIdempotency(tmp_path / "i.sqlite3")
    assert s.claim("a", "k", "e1") == (True, "e1")
    assert s.claim("a", "k", "e2") == (False, "e1")
    s.close()


def test_execution_idempotency_rejects_invalid_claims(tmp_path):
    s = ExecutionIdempotency(tmp_path / "i.sqlite3")
    for values in (("", "k", "e"), ("a", "", "e"), ("a", "k", "")):
        with pytest.raises(ValueError):
            s.claim(*values)
    s.close()
