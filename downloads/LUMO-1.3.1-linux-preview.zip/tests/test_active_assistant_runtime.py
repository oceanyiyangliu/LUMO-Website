from __future__ import annotations

from types import SimpleNamespace

from ocean.assistant_runtime import (
    ActionBudget, ActionClassifier, ActionRisk, BudgetState, EvidenceLedger,
    LoopDetector, MissionVerifier, PlanLedger, requires_human_confirmation,
)
from ocean.cognition import CompletionContract


def test_action_risk_and_confirmation_gate():
    assert ActionClassifier.classify("click", {"x": 1, "y": 2}) is ActionRisk.LOW
    assert ActionClassifier.classify("delete", {}) is ActionRisk.HIGH
    assert requires_human_confirmation("publish", {})


def test_budget_enforces_runtime_action_and_keystroke_limits():
    budget = ActionBudget(max_actions=2, max_runtime_seconds=60, max_keystrokes=3)
    state = BudgetState()
    assert state.allow("click", budget)[0]
    state.record("click")
    state.record("type_text", key_count=3)
    assert not state.allow("click", budget)[0]


def test_loop_detector_detects_identical_state():
    detector = LoopDetector()
    for _ in range(3):
        detector.observe("same", "wait")
    detected, reason = detector.observe("same", "wait")
    assert detected
    assert "visual" in reason


def test_loop_detector_detects_action_cycle():
    detector = LoopDetector()
    sequence = ["click", "wait", "click", "wait", "click", "wait"]
    result = (False, "")
    for operation in sequence:
        result = detector.observe(operation, operation)
    assert result[0]


def test_plan_ledger_tracks_dependencies_and_revisions():
    plan = PlanLedger("make a file")
    plan.add("write", "write file")
    plan.add("verify", "verify file", ("write",))
    assert [node.node_id for node in plan.ready()] == ["root", "write"]
    plan.update("write", status="completed")
    assert [node.node_id for node in plan.ready()] == ["root", "verify"]
    assert plan.revision >= 3


def test_verifier_requires_contract_evidence():
    contract = CompletionContract.from_objective("create a design")
    ledger = EvidenceLedger()
    ok, missing = MissionVerifier.verify(contract, [], ledger)
    assert not ok
    assert missing
    ledger.add("action", {"operation": "click"}, source="runtime", confidence=1.0)
    ledger.add("screen", {"application": "Test", "window": "Design"}, source="screenshot", confidence=0.95)
    ok, _ = MissionVerifier.verify(contract, ["click"], ledger)
    assert ok


def test_evidence_ledger_is_bounded_by_confidence_predicate():
    ledger = EvidenceLedger()
    ledger.add("file", {"path": "x.pdf"}, source="filesystem", confidence=.9)
    assert ledger.has("file", lambda value: value["path"].endswith(".pdf"), .8)
    assert not ledger.has("file", minimum_confidence=.95)


def test_active_assistant_status_marks_sensitive_context(monkeypatch):
    from ocean.active_assistant import ActiveAssistant
    assistant = ActiveAssistant(enabled=False)
    assert assistant._is_sensitive("Keychain", "Passwords")
    assert not assistant._is_sensitive("Calculator", "Calculator")
    history = assistant.history()
    assert "contexts" in history and "attention" in history


def test_action_telemetry_redacts_secret_fields_and_bounds_long_text():
    from ocean.assistant_runtime import redact_arguments, redact_error
    value = redact_arguments({"password": "secret", "nested": {"api_key": "abc"}, "text": "x" * 3000})
    assert value["password"] == "[REDACTED]"
    assert value["nested"]["api_key"] == "[REDACTED]"
    assert value["text"].endswith("…[TRUNCATED]")
    assert "[REDACTED]" in redact_error("token=supersecret")


def test_accessibility_tools_are_registered():
    from ocean.capabilities.computer import computer_spec
    spec = computer_spec()
    assert "accessibility_snapshot" in spec.operations
    assert "click_element" in spec.operations
    assert spec.operations["accessibility_snapshot"].risk_level.value == "low"
