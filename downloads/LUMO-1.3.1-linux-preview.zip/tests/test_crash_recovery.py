"""Crash/restart recovery tests for LUMO OS Phase 2.

These tests simulate actual process crashes and restarts using SQLite
event persistence to verify durable recovery semantics.
"""

from __future__ import annotations

import sqlite3
import tempfile
import threading
import time
from pathlib import Path

import pytest

from ocean.domain.event import Event
from ocean.domain.mission import Mission
from ocean.orchestration.mission_engine import (
    MissionEngine,
    MissionContract,
    MissionObjective,
    MissionObjectiveResult,
    MissionPlan,
)
from eventing.sqlite_store import SQLiteEventStore
from ocean.domain.event_bus import EventBus


class SharedExecutor:
    """Shared executor for restart test (same instance across restarts)."""
    
    def __init__(self, hang_objective_ids=None):
        self.calls = {}
        self.hang_objective_ids = set(hang_objective_ids or [])
        self._gate = threading.Event()

    def execute(self, _mission_id, objective):
        oid = objective.objective_id
        self.calls[oid] = self.calls.get(oid, 0) + 1
        if oid in self.hang_objective_ids:
            self._gate.wait(timeout=2.0)
        return MissionObjectiveResult(
            objective_id=oid,
            objective=objective.objective,
            status="completed",
            metadata={"work_type": objective.work_type},
        )


class RecordingExecutor:
    def __init__(self, statuses):
        self.statuses = iter(statuses)
        self.calls = []

    def execute(self, mission_id, objective):
        self.calls.append(objective.objective)
        status, error = next(self.statuses)
        return MissionObjectiveResult(
            objective_id=objective.objective_id,
            objective=objective.objective,
            status=status,
            error=error,
        )


class _FixedPlanOnceThenDone:
    """Returns the given plan once, then an empty plan forever after."""

    def __init__(self, plan):
        self._plan = plan
        self._served = False

    def plan(self, mission_id, goal, *, completed_objectives=(), previous_results=()):
        if not self._served:
            self._served = True
            return self._plan
        return MissionPlan(mission_id=mission_id, goal=goal, objectives=())


def plan(mission_id, goal, objectives):
    return MissionPlan(
        mission_id=mission_id,
        goal=goal,
        objectives=objectives,
    )


EMPTY_PLAN = MissionPlan(
    mission_id="mission-crash-test",
    goal="crash recovery test mission",
    objectives=(),
)


@pytest.fixture
def temp_db_path(tmp_path):
    return tmp_path / "test.sqlite"


def test_mission_persists_events_to_sqlite(tmp_path):
    """Test that mission events are persisted to SQLite."""
    db_path = tmp_path / "test.sqlite"
    connection = sqlite3.connect(db_path, check_same_thread=False)
    events = EventBus(store=SQLiteEventStore(connection))
    
    mission_id = "test-persist"
    from ocean.orchestration.mission_engine import DeterministicMissionPlanner
    planner = DeterministicMissionPlanner()
    executor = RecordingExecutor([("completed", None)])
    
    engine = MissionEngine(planner=planner, executor=executor, events=events, objective_lease_seconds=0.1)
    result = engine.run("test mission", mission_id=mission_id, max_replans=1)
    
    assert result.status == "completed"
    
    connection.close()
    connection2 = sqlite3.connect(db_path)
    cursor = connection2.cursor()
    cursor.execute("SELECT COUNT(*) FROM events")
    count = cursor.fetchone()[0]
    assert count >= 2
    connection2.close()


def test_mission_restart_from_sqlite_recovers_after_lease_timeout(tmp_path):
    """Test that a fresh MissionEngine can resume from SQLite events after lease timeout."""
    db_path = tmp_path / "restart.sqlite"
    connection1 = sqlite3.connect(db_path, check_same_thread=False)
    events1 = EventBus(store=SQLiteEventStore(connection1))
    
    mission_id = "restart-test"
    executor = SharedExecutor(hang_objective_ids={"obj-b"})
    plan_obj = MissionPlan(
        mission_id=mission_id,
        goal="test mission",
        objectives=(
            MissionObjective(objective_id="obj-a", objective="Task A", work_type="implementation"),
            MissionObjective(objective_id="obj-b", objective="Task B", work_type="implementation"),
        ),
    )
    planner = _FixedPlanOnceThenDone(plan_obj)
    
    engine1 = MissionEngine(planner=planner, executor=executor, events=events1, objective_lease_seconds=0.1, max_concurrent_objectives=2)
    result1 = engine1.run("test mission", mission_id=mission_id, max_replans=1)
    
    assert result1.status == "replan_limit_reached"
    assert "obj-a" in result1.completed_objectives
    assert "obj-b" not in result1.completed_objectives
    connection1.close()
    
    # Restart - release hanging thread
    executor._gate.set()
    time.sleep(0.1)
    
    connection2 = sqlite3.connect(db_path, check_same_thread=False)
    events2 = EventBus(store=SQLiteEventStore(connection2))
    
    executor.hang_objective_ids = set()  # No more hanging
    planner2 = _FixedPlanOnceThenDone(plan_obj)
    engine2 = MissionEngine(planner=planner2, executor=executor, events=events2, objective_lease_seconds=0.1, max_concurrent_objectives=2)
    result2 = engine2.run("test mission", mission_id=mission_id, max_replans=3)
    
    assert result2.status == "completed"
    assert set(result2.completed_objectives) == {"obj-a", "obj-b"}


def test_mission_restart_after_failed_objective(tmp_path):
    """Test that a fresh MissionEngine can resume from SQLite events after failure."""
    db_path = tmp_path / "restart_fail.sqlite"
    
    connection1 = sqlite3.connect(db_path, check_same_thread=False)
    events1 = EventBus(store=SQLiteEventStore(connection1))
    
    mission_id = "restart-fail-test"
    plan_obj = MissionPlan(
        mission_id=mission_id,
        goal="fail test",
        objectives=(MissionObjective(objective_id="obj-1", objective="Failing task", work_type="implementation"),),
    )
    planner = _FixedPlanOnceThenDone(plan_obj)
    
    # First run - persistent failure (hang)
    executor1 = SharedExecutor(hang_objective_ids={"obj-1"})
    engine1 = MissionEngine(planner=planner, executor=executor1, events=events1, objective_lease_seconds=0.1)
    result1 = engine1.run("fail test", mission_id=mission_id, max_replans=1)
    
    assert result1.status == "replan_limit_reached"
    assert "obj-1" not in result1.completed_objectives
    connection1.close()
    
    # Restart - executor no longer hangs
    connection2 = sqlite3.connect(db_path, check_same_thread=False)
    events2 = EventBus(store=SQLiteEventStore(connection2))
    
    executor2 = SharedExecutor(hang_objective_ids=set())  # No more hanging
    engine2 = MissionEngine(planner=_FixedPlanOnceThenDone(plan_obj), executor=executor2, events=events2, objective_lease_seconds=0.1)
    
    result2 = engine2.run("fail test", mission_id=mission_id, max_replans=2)
    
    assert result2.status == "completed"
    assert "obj-1" in result2.completed_objectives


def test_mission_contract_evaluation_after_restart(tmp_path):
    """Test contract is correctly evaluated after restart."""
    db_path = tmp_path / "contract_restart.sqlite"
    
    connection1 = sqlite3.connect(db_path, check_same_thread=False)
    events1 = EventBus(store=SQLiteEventStore(connection1))
    
    mission_id = "contract-restart"
    executor = SharedExecutor(hang_objective_ids={"i1"})  # Hang implementation
    planner = _FixedPlanOnceThenDone(
        MissionPlan(
            mission_id=mission_id,
            goal="Research and implement",
            objectives=(
                MissionObjective(objective_id="r1", objective="Research phase", work_type="research"),
                MissionObjective(objective_id="i1", objective="Implementation phase", work_type="implementation"),
            ),
        )
    )
    
    contract = MissionContract(required_work_types=("research", "implementation"))
    engine1 = MissionEngine(planner=planner, executor=executor, events=events1, objective_lease_seconds=0.1)
    result1 = engine1.run("Research and implement", mission_id=mission_id, max_replans=1, contract=contract)
    
    assert result1.status == "replan_limit_reached"
    assert "r1" in result1.completed_objectives
    assert "i1" not in result1.completed_objectives
    connection1.close()
    
    # Restart - implementation now succeeds
    executor.hang_objective_ids = set()  # No more hanging
    connection2 = sqlite3.connect(db_path, check_same_thread=False)
    events2 = EventBus(store=SQLiteEventStore(connection2))
    
    engine2 = MissionEngine(planner=planner, executor=executor, events=events2, objective_lease_seconds=0.1)
    
    result2 = engine2.run("Research and implement", mission_id=mission_id, max_replans=3, contract=contract)
    
    assert result2.status == "completed"
    assert result2.metadata.get("contract_satisfied") is True


def test_duplicate_events_do_not_corrupt_state(tmp_path):
    """Test that duplicate event delivery doesn't corrupt state."""
    db_path = tmp_path / "duplicate.sqlite"
    connection = sqlite3.connect(db_path, check_same_thread=False)
    events = EventBus(store=SQLiteEventStore(connection))
    
    mission_id = "duplicate-test"
    from ocean.orchestration.mission_engine import DeterministicMissionPlanner
    planner = DeterministicMissionPlanner()
    executor = SharedExecutor()
    
    engine = MissionEngine(planner=planner, executor=executor, events=events, objective_lease_seconds=0.1)
    result = engine.run("duplicate test", mission_id=mission_id, max_replans=1)
    
    assert result.status == "completed"
    
    # Manually append duplicate ObjectiveCompleted event
    obj_id = result.completed_objectives[0]
    dup_event = Event(
        type="ObjectiveCompleted",
        payload={
            "mission_id": mission_id,
            "objective_id": obj_id,
            "objective": "duplicate test",
            "status": "completed",
            "work_type": "implementation",
        },
        aggregate_type="mission",
        aggregate_id=mission_id,
        correlation_id=mission_id,
        source="mission_engine",
    )
    # Append directly to store (simulating duplicate delivery)
    events._store.append(dup_event)
    
    connection.close()
    connection2 = sqlite3.connect(db_path, check_same_thread=False)
    events2 = EventBus(store=SQLiteEventStore(connection2))
    
    engine2 = MissionEngine(planner=DeterministicMissionPlanner(), 
                           executor=SharedExecutor(), 
                           events=events2,
                           objective_lease_seconds=0.1)
    result2 = engine2.run("duplicate test", mission_id=mission_id, max_replans=1)
    
    assert result2.status == "completed"
    assert len(result2.completed_objectives) == 1


def test_mission_plan_survives_restart(tmp_path):
    """Test that the mission plan is preserved across restart."""
    db_path = tmp_path / "plan_restart.sqlite"
    
    connection1 = sqlite3.connect(db_path, check_same_thread=False)
    events1 = EventBus(store=SQLiteEventStore(connection1))
    
    mission_id = "plan-restart"
    plan_obj = MissionPlan(
        mission_id=mission_id,
        goal="multi-step mission",
        objectives=(
            MissionObjective(objective_id="o1", objective="Step 1"),
            MissionObjective(objective_id="o2", objective="Step 2"),
            MissionObjective(objective_id="o3", objective="Step 3"),
        ),
    )
    planner = _FixedPlanOnceThenDone(plan_obj)
    executor1 = SharedExecutor()
    
    engine1 = MissionEngine(planner=planner, executor=executor1, events=events1, objective_lease_seconds=0.1)
    result1 = engine1.run("multi-step mission", mission_id=mission_id, max_replans=2)
    
    assert result1.status == "completed"
    assert len(result1.completed_objectives) == 3
    connection1.close()
    
    # Restart - should use same plan, not replan
    connection2 = sqlite3.connect(db_path, check_same_thread=False)
    events2 = EventBus(store=SQLiteEventStore(connection2))
    
    call_count = [0]
    class CountingPlanner:
        def plan(self, mission_id, goal, *, completed_objectives=(), previous_results=()):
            call_count[0] += 1
            if call_count[0] == 1:
                return plan_obj
            return EMPTY_PLAN
    
    engine2 = MissionEngine(planner=CountingPlanner(), 
                           executor=SharedExecutor(),
                           events=events2,
                           objective_lease_seconds=0.1)
    result2 = engine2.run("multi-step mission", mission_id=mission_id, max_replans=2)
    
    assert result2.status == "completed"
    # The planner is NOT called on restart - the plan is restored from events
    # The mission completes successfully, proving the plan was correctly restored
    assert call_count[0] == 0


def test_objective_completed_once_per_restart(tmp_path):
    """Test objective is completed exactly once across restarts."""
    db_path = tmp_path / "once.sqlite"
    
    connection1 = sqlite3.connect(db_path, check_same_thread=False)
    events1 = EventBus(store=SQLiteEventStore(connection1))
    
    mission_id = "once-test"
    plan_obj = MissionPlan(
        mission_id=mission_id,
        goal="once test",
        objectives=(MissionObjective(objective_id="obj-1", objective="Once"),),
    )
    planner = _FixedPlanOnceThenDone(plan_obj)
    executor1 = SharedExecutor()
    
    engine1 = MissionEngine(planner=planner, executor=executor1, events=events1, objective_lease_seconds=0.1)
    result1 = engine1.run("once test", mission_id=mission_id, max_replans=1)
    
    assert result1.status == "completed"
    connection1.close()
    
    connection2 = sqlite3.connect(db_path, check_same_thread=False)
    events2 = EventBus(store=SQLiteEventStore(connection2))
    executor2 = SharedExecutor()  # Should not be called
    
    planner2 = _FixedPlanOnceThenDone(plan_obj)
    engine2 = MissionEngine(planner=planner2, executor=executor2, events=events2, objective_lease_seconds=0.1)
    result2 = engine2.run("once test", mission_id=mission_id, max_replans=1)
    
    assert result2.status == "completed"
    assert executor2.calls == {}


def test_recovery_creates_new_assignment_not_resurrect_old(tmp_path):
    """Test recovery creates new assignment, doesn't resurrect failed one."""
    db_path = tmp_path / "recovery_new.sqlite"
    
    connection1 = sqlite3.connect(db_path, check_same_thread=False)
    events1 = EventBus(store=SQLiteEventStore(connection1))
    
    mission_id = "recovery-new"
    plan_obj = MissionPlan(
        mission_id=mission_id,
        goal="recover test",
        objectives=(MissionObjective(objective_id="obj-1", objective="Recoverable", work_type="implementation"),),
    )
    planner = _FixedPlanOnceThenDone(plan_obj)
    
    # First run - persistent failure (hang)
    executor1 = SharedExecutor(hang_objective_ids={"obj-1"})
    engine1 = MissionEngine(planner=planner, executor=executor1, events=events1, objective_lease_seconds=0.1)
    result1 = engine1.run("recover test", mission_id=mission_id, max_replans=1)
    
    assert result1.status == "replan_limit_reached"
    assert "obj-1" not in result1.completed_objectives
    connection1.close()
    
    # Restart with executor that succeeds
    connection2 = sqlite3.connect(db_path, check_same_thread=False)
    events2 = EventBus(store=SQLiteEventStore(connection2))
    executor2 = SharedExecutor(hang_objective_ids=set())  # No more hanging
    planner2 = _FixedPlanOnceThenDone(plan_obj)
    engine2 = MissionEngine(planner=planner2, executor=executor2, events=events2, objective_lease_seconds=0.1)
    
    result2 = engine2.run("recover test", mission_id=mission_id, max_replans=2)
    
    assert result2.status == "completed"
    assert "obj-1" in result2.completed_objectives


def test_concurrent_objectives_recover_correctly(tmp_path):
    """Test parallel objectives recover correctly after restart."""
    db_path = tmp_path / "parallel_restart.sqlite"
    
    connection1 = sqlite3.connect(db_path, check_same_thread=False)
    events1 = EventBus(store=SQLiteEventStore(connection1))
    
    mission_id = "parallel-restart"
    plan_obj = MissionPlan(
        mission_id=mission_id,
        goal="parallel test",
        objectives=(
            MissionObjective(objective_id="o1", objective="Task 1"),
            MissionObjective(objective_id="o2", objective="Task 2"),
        ),
    )
    planner = _FixedPlanOnceThenDone(plan_obj)
    executor1 = SharedExecutor()
    
    engine1 = MissionEngine(planner=planner, executor=executor1, events=events1, max_concurrent_objectives=2, objective_lease_seconds=0.1)
    result1 = engine1.run("parallel test", mission_id=mission_id, max_replans=2)
    
    assert result1.status == "completed"
    connection1.close()
    
    connection2 = sqlite3.connect(db_path, check_same_thread=False)
    events2 = EventBus(store=SQLiteEventStore(connection2))
    executor2 = SharedExecutor()
    
    planner2 = _FixedPlanOnceThenDone(plan_obj)
    engine2 = MissionEngine(planner=planner2, executor=executor2, events=events2, objective_lease_seconds=0.1)
    result2 = engine2.run("parallel test", mission_id=mission_id, max_replans=2)
    
    assert result2.status == "completed"
    assert executor2.calls == {}


def test_stale_worker_results_discarded_after_restart(tmp_path):
    """Test stale results from crashed worker don't overwrite newer truth."""
    db_path = tmp_path / "stale.sqlite"
    
    connection1 = sqlite3.connect(db_path, check_same_thread=False)
    events1 = EventBus(store=SQLiteEventStore(connection1))
    
    mission_id = "stale-test"
    plan_obj = MissionPlan(
        mission_id=mission_id,
        goal="stale test",
        objectives=(
            MissionObjective(objective_id="obj-1", objective="Stale test"),
        ),
    )
    
    class HangsThenSucceedsExecutor:
        def __init__(self):
            self.calls = 0
            self._gate = threading.Event()
        
        def execute(self, mission_id, objective):
            self.calls += 1
            if self.calls == 1:
                self._gate.wait(timeout=2)
            return MissionObjectiveResult(
                objective_id=objective.objective_id,
                objective=objective.objective,
                status="completed",
            )
    
    executor1 = HangsThenSucceedsExecutor()
    planner = _FixedPlanOnceThenDone(plan_obj)
    
    engine1 = MissionEngine(planner=planner, executor=executor1, events=events1, objective_lease_seconds=0.1)
    result1 = engine1.run("stale test", mission_id=mission_id, max_replans=3)
    
    assert result1.status == "completed"
    assert executor1.calls == 2
    connection1.close()
    
    # Release the hanging thread
    executor1._gate.set()
    time.sleep(0.1)
    
    # Restart - late result should not create duplicate completion
    connection2 = sqlite3.connect(db_path, check_same_thread=False)
    events2 = EventBus(store=SQLiteEventStore(connection2))
    executor2 = SharedExecutor()
    
    planner2 = _FixedPlanOnceThenDone(plan_obj)
    engine2 = MissionEngine(planner=planner2, executor=executor2, events=events2, objective_lease_seconds=0.1)
    result2 = engine2.run("stale test", mission_id=mission_id, max_replans=1)
    
    assert result2.status == "completed"
    assert executor2.calls == {}
    completed_events = [e for e in events2.history("ObjectiveCompleted") 
                       if e.payload.get("objective_id") == "obj-1"]
    assert len(completed_events) == 1


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
