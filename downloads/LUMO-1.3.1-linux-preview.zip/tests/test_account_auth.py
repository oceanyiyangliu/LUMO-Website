import pytest
from pathlib import Path

from ocean.accounts import AccountStore


def test_user_account_password_is_hashed_and_login_works(tmp_path):
    store = AccountStore(tmp_path / "accounts.sqlite3")
    account = store.create_user("Ocean", "Ocean@Example.com", "a-very-strong-password-123")
    assert account["email"] == "ocean@example.com"
    assert account["password_hash"] is not None
    assert "a-very-strong-password-123" not in account["password_hash"]
    assert store.authenticate("OCEAN@example.com", "a-very-strong-password-123")["id"] == account["id"]
    with pytest.raises(PermissionError):
        store.authenticate("ocean@example.com", "wrong-password")
    store.close()


def test_email_verification_token_is_one_time_and_persisted(tmp_path):
    path = tmp_path / "accounts.sqlite3"
    store = AccountStore(path)
    account = store.create_user("Ocean", "ocean@example.com", "a-very-strong-password-123")
    token = store.begin_email_verification(account["id"])
    store.close()
    reopened = AccountStore(path)
    verified = reopened.verify_email(token)
    assert verified["email_verified"] is True
    with pytest.raises(PermissionError):
        reopened.verify_email(token)
    reopened.close()
def test_password_reset_is_single_use_and_changes_password(tmp_path):
    store = AccountStore(tmp_path / "accounts.sqlite3")
    account = store.create_user("Ocean", "ocean@example.com", "old-password-12345")
    result = store.begin_password_reset("ocean@example.com")
    assert result is not None
    account_id, token = result
    assert account_id == account["id"]
    store.reset_password(token, "new-password-12345")
    assert store.authenticate("ocean@example.com", "new-password-12345")["id"] == account["id"]
    with pytest.raises(PermissionError):
        store.reset_password(token, "another-password-12345")
    store.close()


def test_profile_update_and_email_uniqueness(tmp_path):
    store = AccountStore(tmp_path / "accounts.sqlite3")
    first = store.create_user("Ocean", "ocean@example.com", "password-one-12345")
    second = store.create_user("Builder", "builder@example.com", "password-two-12345")
    token = store.begin_email_verification(first["id"])
    store.verify_email(token)
    updated = store.update_profile(first["id"], name="Ocean LUMO", profile_picture_ref="avatar://profile-1")
    assert updated["name"] == "Ocean LUMO"
    assert updated["profile_picture_ref"] == "avatar://profile-1"
    changed = store.update_profile(first["id"], email="new-ocean@example.com")
    assert changed["email_verified"] is False
    with pytest.raises(ValueError):
        store.update_profile(first["id"], email=second["email"])
    store.close()


def test_profile_picture_upload_is_validated_and_persisted(tmp_path):
    import base64
    from ocean.api import LumoAPI
    from ocean.service import OceanService
    service = OceanService(repository_root=tmp_path)
    service.start()
    api = LumoAPI(service)
    png = b"\x89PNG\r\n\x1a\n" + b"\x00" * 32
    result = api.upload_profile_picture("data:image/png;base64," + base64.b64encode(png).decode())
    assert result["profile_picture_ref"].endswith(".png")
    assert Path(result["profile_picture_ref"]).is_file()
    with pytest.raises(ValueError):
        api.upload_profile_picture("data:image/png;base64," + base64.b64encode(b"not-png").decode())
    service.stop()


def test_password_reset_revokes_existing_sessions(tmp_path):
    from ocean.api import LumoAPI
    from ocean.service import OceanService
    service = OceanService(repository_root=tmp_path)
    service.start()
    api = LumoAPI(service)
    account = api.account()
    api._accounts.update_profile(account["id"], email="reset@example.com")
    api._accounts.verify_email(api._accounts.begin_email_verification(account["id"]))
    api._accounts.set_password(account["id"], "old-reset-password")
    token = api._sessions.issue(account["id"])
    result = api._accounts.begin_password_reset("reset@example.com")
    assert result is not None
    _, reset_token = result
    api.complete_password_reset(reset_token, "new-reset-password")
    with pytest.raises(PermissionError):
        api._sessions.verify(token)
    service.stop()


def test_existing_account_database_migrates_before_email_index(tmp_path):
    import sqlite3
    path = tmp_path / "accounts.sqlite3"
    db = sqlite3.connect(path)
    db.execute("CREATE TABLE accounts (id TEXT PRIMARY KEY, name TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)")
    db.execute("INSERT INTO accounts VALUES ('account_old','Old','2026-01-01','2026-01-01')")
    db.commit(); db.close()
    store = AccountStore(path)
    account = store.get("account_old")
    assert account["email"] is None
    store.close()
    db = sqlite3.connect(path)
    assert db.execute("SELECT name FROM sqlite_master WHERE type='index' AND name='idx_accounts_email'").fetchone()
    db.close()


def test_login_bruteforce_limiter_blocks_repeated_failures(tmp_path):
    from ocean.api import LumoAPI
    from ocean.service import OceanService
    service = OceanService(repository_root=tmp_path)
    service.start()
    api = LumoAPI(service)
    account = api._accounts.create_user("Limit", "limit@example.com", "a" * 12)
    api._accounts.verify_email(api._accounts.begin_email_verification(account["id"]))
    for _ in range(5):
        try:
            api.login("limit@example.com", "wrong-password", attempt_key="test-client")
        except PermissionError:
            pass
    try:
        api.login("limit@example.com", "a" * 12, attempt_key="test-client")
    except PermissionError as exc:
        assert "too many" in str(exc)
    else:
        raise AssertionError("login limiter did not block sixth attempt")
    service.stop()


def test_cloud_provider_configuration_is_retired(tmp_path):
    from ocean.api import LumoAPI
    from ocean.service import OceanService
    service = OceanService(repository_root=tmp_path)
    service.start()
    api = LumoAPI(service)
    assert not hasattr(service, "configure_openai_key")
    assert not hasattr(api, "configure_openai")
    service.stop()

def test_account_deletion_removes_identity_and_account_scoped_stores(tmp_path):
    from ocean.api import LumoAPI
    from ocean.service import OceanService
    service = OceanService(repository_root=tmp_path)
    service.start()
    api = LumoAPI(service)
    account = api.account()
    service.devices.register(account["id"], name="Test Device", device_id="delete-device")
    token = api._sessions.issue(account["id"])
    api._accounts.set_password(account["id"], "launch-delete-password")
    result = api.delete_account("launch-delete-password", account["name"])
    assert result["deleted"] is True
    with pytest.raises(PermissionError):
        api._sessions.verify(token)
    with pytest.raises(KeyError):
        api._accounts.get(account["id"])
    assert service.devices.list(account["id"]) == []
    assert service.nodes.list(account["id"]) == []
    service.stop()


def test_account_password_has_no_12_character_minimum(tmp_path):
    store = AccountStore(tmp_path / "accounts.sqlite3")
    account = store.create_user("Short", "short@example.com", "abc")
    assert store.authenticate("short@example.com", "abc")["id"] == account["id"]
    store.set_password(account["id"], "x")
    assert store.authenticate("short@example.com", "x")["id"] == account["id"]
    store.close()
