from dataclasses import dataclass

from persistence.in_memory import InMemoryRepository


@dataclass
class Item:
    id: str
    value: str


def test_save_and_get():
    repo = InMemoryRepository[Item]()
    item = Item(id="item-1", value="hello")

    assert repo.save(item) is item
    assert repo.get("item-1") == item


def test_get_missing_returns_none():
    repo = InMemoryRepository[Item]()

    assert repo.get("missing") is None


def test_save_replaces_existing_entity():
    repo = InMemoryRepository[Item]()
    first = Item(id="item-1", value="first")
    second = Item(id="item-1", value="second")

    repo.save(first)
    repo.save(second)

    assert repo.get("item-1") == second
    assert list(repo.list()) == [second]


def test_delete_existing_entity():
    repo = InMemoryRepository[Item]()
    repo.save(Item(id="item-1", value="hello"))

    assert repo.delete("item-1") is True
    assert repo.get("item-1") is None


def test_delete_missing_entity_returns_false():
    repo = InMemoryRepository[Item]()

    assert repo.delete("missing") is False


def test_list_returns_all_entities():
    repo = InMemoryRepository[Item]()
    first = Item(id="item-1", value="first")
    second = Item(id="item-2", value="second")

    repo.save(first)
    repo.save(second)

    assert list(repo.list()) == [first, second]
import sqlite3

from persistence.serializer import Serializer
from persistence.sqlite import SQLiteRepository


class ItemSerializer(Serializer[Item]):
    def serialize(self, entity: Item) -> dict[str, object]:
        return {"id": entity.id, "value": entity.value}

    def deserialize(self, data: dict[str, object]) -> Item:
        return Item(id=str(data["id"]), value=str(data["value"]))


def test_sqlite_save_and_get():
    connection = sqlite3.connect(":memory:")
    repo = SQLiteRepository(connection, ItemSerializer(), "items")
    item = Item(id="item-1", value="hello")

    repo.save(item)

    assert repo.get("item-1") == item


def test_sqlite_save_replaces_existing_entity():
    connection = sqlite3.connect(":memory:")
    repo = SQLiteRepository(connection, ItemSerializer(), "items")

    repo.save(Item(id="item-1", value="first"))
    repo.save(Item(id="item-1", value="second"))

    assert repo.get("item-1") == Item(id="item-1", value="second")


def test_sqlite_delete():
    connection = sqlite3.connect(":memory:")
    repo = SQLiteRepository(connection, ItemSerializer(), "items")

    repo.save(Item(id="item-1", value="hello"))

    assert repo.delete("item-1") is True
    assert repo.get("item-1") is None
    assert repo.delete("item-1") is False


def test_sqlite_list():
    connection = sqlite3.connect(":memory:")
    repo = SQLiteRepository(connection, ItemSerializer(), "items")

    first = Item(id="item-1", value="first")
    second = Item(id="item-2", value="second")

    repo.save(first)
    repo.save(second)

    assert list(repo.list()) == [first, second]


def test_sqlite_rejects_invalid_table_name():
    connection = sqlite3.connect(":memory:")

    try:
        SQLiteRepository(connection, ItemSerializer(), "items; DROP TABLE users")
    except ValueError:
        pass
    else:
        raise AssertionError("invalid table name was accepted")
def test_sqlite_list_insertion_order():
    connection = sqlite3.connect(":memory:")
    repo = SQLiteRepository(connection, ItemSerializer(), "items")

    first = Item(id="item-z", value="first")
    second = Item(id="item-a", value="second")

    repo.save(first)
    repo.save(second)

    assert list(repo.list_insertion_order()) == [first, second]


def test_in_memory_repository_atomic_admission_returns_existing():
    repo = InMemoryRepository()
    first = Item(id="first", value="a")
    second = Item(id="second", value="b")

    admitted, created = repo.admit(("plan-1", "node-1"), first)
    duplicate, duplicate_created = repo.admit(("plan-1", "node-1"), second)

    assert admitted is first
    assert created is True
    assert duplicate is first
    assert duplicate_created is False
    assert repo.get("second") is None


def test_in_memory_repository_atomic_admission_is_concurrent():
    from concurrent.futures import ThreadPoolExecutor

    repo = InMemoryRepository()

    def admit(index):
        entity = Item(id=f"item-{index}", value=index)
        return repo.admit(("plan-1", "node-1"), entity)

    with ThreadPoolExecutor(max_workers=16) as pool:
        results = list(pool.map(admit, range(16)))

    created = [result for result in results if result[1]]
    admitted = [result[0] for result in results]

    assert len(created) == 1
    assert len(repo.list()) == 1
    assert all(entity is created[0][0] for entity in admitted)
