from dataclasses import replace
import json
from ocean.domain.event import Event
from ocean.event_sourcing.schema import *
import pytest

def test_schema_validation_and_migration():
    r=EventSchemaRegistry(); r.register(EventSchema("Thing",1,("x",))); r.register(EventSchema("Thing",2,("x","y")))
    with pytest.raises(ValueError): r.validate(Event(type="Thing",version=1,payload={}))
    r.add_migration("Thing",1,2,lambda e: replace(e,version=2,payload={**e.payload,"y":1}))
    out=r.migrate(Event(type="Thing",version=1,payload={"x":1}),2); assert out.payload["y"]==1

def test_audit_export_is_hash_chained_and_deterministic():
    e1=Event(type="A",payload={"x":1},sequence=1); e2=Event(type="B",payload={"y":2},sequence=2)
    a=AuditExporter.canonical([e1,e2]); b=AuditExporter.canonical([e1,e2]); assert a==b
    rows=json.loads(a); assert rows[1]["previous_hash"]==rows[0]["hash"]; assert len(AuditExporter.digest([e1,e2]))==64
