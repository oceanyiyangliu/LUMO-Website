from eventing.in_memory_store import InMemoryEventStore
from ocean.domain.event import Event
from ocean.observability.metrics import OperationalMetricsReader

def test_telemetry_summary():
 s=InMemoryEventStore();
 for t in ["WorkerUtilizationSample","WorldCreated","DeviceHealthRecorded","ModelLatencySample","ModelFailed","PowerLeaseAcquired","EventLagSample","DeliveryRetryScheduled"]: s.append(Event(t))
 out=OperationalMetricsReader(s).telemetry_summary(); assert all(v==1 for v in out.values())
