import pytest

from ocean.domain.event import Event

from eventing.in_memory_store import InMemoryEventStore


def test_append_and_get():
    store = InMemoryEventStore()
    event = Event(type="task_created", payload={"task_id": "task_1"})

    assert store.append(event) is event
    assert store.get(event.id) == event


def test_get_missing_returns_none():
    store = InMemoryEventStore()

    assert store.get("missing") is None


def test_list_preserves_append_order():
    store = InMemoryEventStore()
    first = Event(type="first")
    second = Event(type="second")

    store.append(first)
    store.append(second)

    assert list(store.list()) == [first, second]


def test_list_filters_by_event_type():
    store = InMemoryEventStore()
    first = Event(type="task_created")
    second = Event(type="task_failed")
    third = Event(type="task_created")

    store.append(first)
    store.append(second)
    store.append(third)

    assert list(store.list("task_created")) == [first, third]


def test_appending_same_event_id_does_not_duplicate_order():
    store = InMemoryEventStore()
    event = Event(type="task_created")

    store.append(event)
    store.append(event)

    assert list(store.list()) == [event]




def test_event_store_exposes_authoritative_sequence():
    store = InMemoryEventStore()

    first = Event(type="first")
    second = Event(type="second")

    store.append(first)
    store.append(second)

    assert store.sequence(first.id) == 1
    assert store.sequence(second.id) == 2


def test_event_store_sequence_is_not_part_of_event():
    store = InMemoryEventStore()

    event = Event(type="first")
    store.append(event)

    assert event.sequence is None
    assert store.sequence(event.id) == 1


def test_event_store_sequence_is_stable_for_existing_event_id():
    store = InMemoryEventStore()

    event = Event(type="first")
    store.append(event)

    first_sequence = store.sequence(event.id)

    store.append(event)

    assert store.sequence(event.id) == first_sequence


def test_event_store_lists_events_in_authoritative_sequence_order():
    store = InMemoryEventStore()

    first = Event(type="first")
    second = Event(type="second")
    third = Event(type="third")

    store.append(first)
    store.append(second)
    store.append(third)

    assert [store.sequence(event.id) for event in store.list()] == [1, 2, 3]


def test_event_store_can_read_events_after_a_sequence():
    store = InMemoryEventStore()

    events = [
        Event(type="first"),
        Event(type="second"),
        Event(type="third"),
    ]

    for event in events:
        store.append(event)

    assert list(store.list_after_sequence(1)) == [events[1], events[2]]
    assert list(store.list_after_sequence(2)) == [events[2]]
    assert list(store.list_after_sequence(3)) == []


def test_event_store_list_after_sequence_preserves_authoritative_order():
    store = InMemoryEventStore()

    events = [
        Event(type="first"),
        Event(type="second"),
        Event(type="third"),
    ]

    for event in events:
        store.append(event)

    assert [store.sequence(event.id) for event in store.list_after_sequence(0)] == [
        1, 2, 3
    ]
