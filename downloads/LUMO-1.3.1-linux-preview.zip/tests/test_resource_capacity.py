from ocean.domain.capability import CapabilityRegistry, CapabilitySpec, OperationSpec
from ocean.domain.resource import ResourceRequirement
from ocean.domain.event_bus import EventBus
from ocean.resources import ResourceCapacityPlane


def make_plane(event_bus=None):
    capabilities = CapabilityRegistry()
    capabilities.register(
        CapabilitySpec(
            name="compute",
            description="Compute operations",
            operations={
                "run": OperationSpec(
                    name="run",
                    description="Run computation",
                    resource_requirements=[
                        ResourceRequirement("cpu", 2),
                        ResourceRequirement("memory", 4),
                    ],
                ),
                "cpu_only": OperationSpec(
                    name="cpu_only",
                    description="CPU-only operation",
                    resource_requirements=[
                        ResourceRequirement("cpu", 1),
                    ],
                ),
            },
        )
    )

    plane = ResourceCapacityPlane(
        capabilities=capabilities,
        event_bus=event_bus,
    )
    plane.register("cpu", 4)
    plane.register("memory", 8)
    return plane


def request(
    execution_id="exec-1",
    operation="run",
):
    from runtime.types import ExecutionRequest

    return ExecutionRequest(
        task_id="task-1",
        capability="compute",
        operation=operation,
        execution_id=execution_id,
    )


def test_atomic_multi_resource_reservation():
    plane = make_plane()

    result = plane.try_reserve(request())

    assert result.admitted
    assert result.reservation is not None
    assert plane.capacity("cpu").reserved == 2
    assert plane.capacity("memory").reserved == 4


def test_failed_multi_resource_admission_reserves_nothing():
    plane = make_plane()
    plane.set_capacity("memory", 3)

    result = plane.try_reserve(request())

    assert not result.admitted
    assert plane.capacity("cpu").reserved == 0
    assert plane.capacity("memory").reserved == 0


def test_release_restores_capacity():
    plane = make_plane()

    result = plane.try_reserve(request())
    plane.release(result.reservation.reservation_id)

    assert plane.capacity("cpu").reserved == 0
    assert plane.capacity("memory").reserved == 0
    assert plane.reservation_for_execution("exec-1") is None


def test_reservation_is_idempotent_for_same_execution():
    plane = make_plane()

    first = plane.try_reserve(request())
    second = plane.try_reserve(request())

    assert first.reservation == second.reservation
    assert plane.capacity("cpu").reserved == 2


def test_missing_resource_capacity_rejects():
    plane = make_plane()
    capabilities = plane._capabilities
    capabilities.register(
        CapabilitySpec(
            name="network",
            description="Network",
            operations={
                "call": OperationSpec(
                    name="call",
                    description="Call network",
                    resource_requirements=[
                        ResourceRequirement("network", 1),
                    ],
                )
            },
        )
    )

    from runtime.types import ExecutionRequest

    result = plane.try_reserve(
        ExecutionRequest(
            task_id="task-1",
            capability="network",
            operation="call",
            execution_id="exec-network",
        )
    )

    assert not result.admitted
    assert "not registered" in result.reason


def test_duplicate_requirements_are_aggregated():
    plane = make_plane()

    result = plane.try_reserve_requirements(
        execution_id="exec-2",
        requirements=[
            ResourceRequirement("cpu", 1),
            ResourceRequirement("cpu", 1),
        ],
    )

    assert result.admitted
    assert result.reservation.requirements == {"cpu": 2.0}
    assert plane.capacity("cpu").reserved == 2


def test_rebuild_restores_capacity_and_reservations():
    event_bus = EventBus()
    plane = make_plane(event_bus)

    result = plane.try_reserve(request("exec-rebuild"))
    assert result.admitted

    rebuilt = make_plane()
    rebuilt.rebuild(event_bus.history())

    assert rebuilt.capacity("cpu").reserved == 2
    assert rebuilt.capacity("memory").reserved == 4
    assert rebuilt.reservation_for_execution("exec-rebuild") is not None


def test_release_event_is_replayable():
    event_bus = EventBus()
    plane = make_plane(event_bus)

    result = plane.try_reserve(request("exec-release"))
    plane.release(result.reservation.reservation_id)

    rebuilt = make_plane()
    rebuilt.rebuild(event_bus.history())

    assert rebuilt.capacity("cpu").reserved == 0
    assert rebuilt.capacity("memory").reserved == 0
    assert rebuilt.reservation_for_execution("exec-release") is None


def test_event_order_is_reserve_then_release():
    event_bus = EventBus()
    plane = make_plane(event_bus)

    result = plane.try_reserve(request("exec-events"))
    plane.release(result.reservation.reservation_id)

    assert [e.type for e in event_bus.history()] == [
        "ResourceCapacityRegistered",
        "ResourceCapacityRegistered",
        "ResourceReserved",
        "ResourceReleased",
    ]


def test_resource_types_reject_non_finite_values():
    import math
    import pytest
    from ocean.resources.types import ResourceCapacity, ResourceReservation
    for value in (math.nan, math.inf, -math.inf):
        with pytest.raises(ValueError):
            ResourceCapacity("cpu", value)
        with pytest.raises(ValueError):
            ResourceReservation("exec", {"cpu": value})
