from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from ocean.self_improvement.code_modification import CandidateWorkspaceService
from persistence.sqlite import SQLiteRepository
from persistence.serializer import Serializer
import sqlite3


class ItemSerializer(Serializer):
    def serialize(self, entity):
        return {"id": entity["id"], "value": entity["value"]}

    def deserialize(self, data):
        return data


def test_candidate_workspaces_are_unique_under_parallel_creation(tmp_path):
    service = CandidateWorkspaceService()
    source = tmp_path / "repo"
    source.mkdir()
    (source / "x.py").write_text("x = 1\n")

    workspaces = []
    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = [pool.submit(service.create, candidate_id=f"c-{i}", repository_root=source) for i in range(8)]
        workspaces = [future.result() for future in futures]

    try:
        assert len({workspace.root for workspace in workspaces}) == 8
        assert len({workspace.id for workspace in workspaces}) == 8
        assert all((workspace.root / "x.py").exists() for workspace in workspaces)
    finally:
        for workspace in workspaces:
            service.destroy(workspace)


def test_shared_sqlite_connection_is_safe_for_concurrent_repository_access(tmp_path):
    connection = sqlite3.connect(str(tmp_path / "state.sqlite3"), check_same_thread=False)
    repository = SQLiteRepository(connection, ItemSerializer(), "items")

    def save(i):
        repository.save({"id": f"item-{i}", "value": i})

    try:
        with ThreadPoolExecutor(max_workers=12) as pool:
            list(pool.map(save, range(100)))
        assert len(list(repository.list())) == 100
    finally:
        connection.close()
