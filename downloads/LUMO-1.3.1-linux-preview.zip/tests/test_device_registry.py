import pytest
from ocean.device_registry import DeviceRegistry


def test_register_persists_and_lists_by_account(tmp_path):
    registry = DeviceRegistry(tmp_path / "devices.sqlite3")
    device = registry.register("account-a", name="Mac", capabilities={"worlds": True})
    assert device.id.startswith("device_")
    assert registry.get(device.id).name == "Mac"
    assert [item.id for item in registry.list("account-a")] == [device.id]
    assert registry.list("account-b") == []


def test_heartbeat_updates_liveness(tmp_path):
    registry = DeviceRegistry(tmp_path / "devices.sqlite3")
    device = registry.register("account-a")
    updated = registry.heartbeat(device.id, account_id="account-a")
    assert updated.status == "online"
    assert updated.last_seen >= device.last_seen


def test_stale_devices_become_offline(tmp_path):
    registry = DeviceRegistry(tmp_path / "devices.sqlite3")
    device = registry.register("account-a")
    with registry._connect() as db:
        db.execute("UPDATE devices SET last_seen=0 WHERE id=?", (device.id,))
    changed = registry.mark_stale(after_seconds=1)
    assert changed == 1
    assert registry.get(device.id).status == "offline"


def test_default_capabilities_include_local_model_ceiling(tmp_path):
    registry = DeviceRegistry(tmp_path / "devices.sqlite3")
    device = registry.register("account-a")
    assert device.capabilities["local_model_max_gib"] == 10.0
    assert device.capabilities["display_sleep_allowed"] is True


def test_remove_is_account_scoped(tmp_path):
    registry = DeviceRegistry(tmp_path / "devices.sqlite3")
    device = registry.register("account-a")
    try:
        registry.remove("account-b", device.id)
        assert False, "foreign account must not remove device"
    except KeyError:
        pass
    assert registry.get(device.id).account_id == "account-a"
    registry.remove("account-a", device.id)
    try:
        registry.get(device.id)
        assert False, "removed device should be absent"
    except KeyError:
        pass


def test_device_id_cannot_cross_account(tmp_path):
    registry = DeviceRegistry(tmp_path / "devices.sqlite3")
    device = registry.register("account-a", device_id="device-shared")
    assert device.account_id == "account-a"
    with pytest.raises(PermissionError, match="already owned"):
        registry.register("account-b", device_id="device-shared")
    assert registry.get("device-shared").account_id == "account-a"



def test_reported_capabilities_are_not_trusted(tmp_path):
    registry = DeviceRegistry(tmp_path / "devices.sqlite3")
    device = registry.register(
        "account-a",
        capabilities={"local_model_max_gib": 100.0, "cold_boot": True, "worlds": True},
    )
    assert device.capability_source == "reported"
    assert registry.trusted_capabilities(device) == {}


def test_local_detected_capabilities_are_trusted(tmp_path):
    registry = DeviceRegistry(tmp_path / "devices.sqlite3")
    device = registry.register("account-a")
    assert device.capability_source == "measured"
    assert registry.trusted_capabilities(device)["local_model_max_gib"] <= 10.0


def test_account_scoped_heartbeat_cannot_cross_tenant(tmp_path):
    registry = DeviceRegistry(tmp_path / "devices.sqlite3")
    device = registry.register("account-a")
    with pytest.raises(KeyError):
        registry.heartbeat(device.id, account_id="account-b")
    assert registry.get(device.id).account_id == "account-a"


def test_device_lifecycle_control_state_survives_restart(tmp_path):
    from ocean.device_registry import DeviceRegistry, DeviceLifecycleController
    db = tmp_path / "devices.sqlite3"
    reg = DeviceRegistry(db)
    d = reg.register("acct", name="Mac")
    ctl = DeviceLifecycleController(reg)
    ctl.set_mode("acct", d.id, "drain")
    ctl.record_health("acct", d.id, battery_percent=73)
    ctl.revoke("acct", d.id)
    ctl2 = DeviceLifecycleController(DeviceRegistry(db))
    assert ctl2.mode("acct", d.id) == "maintenance"
    assert ctl2.can_schedule("acct", d.id) is False
    assert ctl2.health("acct", d.id)["battery_percent"] == 73
