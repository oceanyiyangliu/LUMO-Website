from datetime import datetime, timezone

from ocean.domain.message import Message
from persistence.serializers.message import MessageSerializer


def test_message_serializer_round_trip():
    at = datetime(2026, 2, 10, 15, 45, tzinfo=timezone.utc)

    message = Message(
        sender_id="agent-1",
        recipient_id="agent-2",
        type="task_assignment",
        payload={
            "task_id": "task-42",
            "priority": 5,
        },
        correlation_id="mission-1",
        id="msg-1",
        at=at,
    )

    serializer = MessageSerializer()

    serialized = serializer.serialize(message)
    restored = serializer.deserialize(serialized)

    assert restored == message


def test_message_serializer_preserves_optional_correlation_id():
    message = Message(
        sender_id="agent-1",
        recipient_id="agent-2",
        type="status_update",
        payload={"status": "idle"},
        id="msg-2",
    )

    serializer = MessageSerializer()

    restored = serializer.deserialize(serializer.serialize(message))

    assert restored.correlation_id is None


def test_message_serializer_preserves_payload():
    message = Message(
        sender_id="agent-a",
        recipient_id="agent-b",
        type="result",
        payload={
            "success": True,
            "items": ["one", "two"],
            "count": 2,
        },
        id="msg-3",
    )

    serializer = MessageSerializer()

    data = serializer.serialize(message)

    assert data["payload"] == {
        "success": True,
        "items": ["one", "two"],
        "count": 2,
    }

    restored = serializer.deserialize(data)

    assert restored.payload == message.payload
