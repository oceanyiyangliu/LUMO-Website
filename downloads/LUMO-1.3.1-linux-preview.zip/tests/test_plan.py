import pytest

from ocean.domain.plan import PlanRevision, PlanStatus


def make_plan(**overrides):
    values = {
        "mission_id": "mission_1",
        "revision": 1,
        "decision_id": "decision_1",
        "graph_id": "graph_1",
    }
    values.update(overrides)
    return PlanRevision(**values)


def test_plan_revision_is_immutable():
    plan = make_plan()

    with pytest.raises(AttributeError):
        plan.status = PlanStatus.ACTIVE


def test_revision_one_has_no_parent():
    assert make_plan().parent_revision_id is None


def test_revision_after_one_requires_parent():
    with pytest.raises(ValueError):
        make_plan(revision=2)

    plan = make_plan(revision=2, parent_revision_id="plan_1")
    assert plan.parent_revision_id == "plan_1"


def test_revision_one_cannot_have_parent():
    with pytest.raises(ValueError):
        make_plan(parent_revision_id="plan_old")


def test_revision_must_be_positive():
    with pytest.raises(ValueError):
        make_plan(revision=0)


def test_plan_validates_required_ids():
    with pytest.raises(ValueError):
        make_plan(mission_id="")
    with pytest.raises(ValueError):
        make_plan(decision_id="")
    with pytest.raises(ValueError):
        make_plan(graph_id="")


def test_plan_freezes_nested_metadata():
    metadata = {"config": {"strategy": {"parallel": True}}}
    plan = make_plan(metadata=metadata)

    with pytest.raises(TypeError):
        plan.metadata["config"]["strategy"]["parallel"] = False


def test_plan_generates_typed_id():
    assert make_plan().id.startswith("plan_")
