from datetime import datetime, timezone

from ocean.domain.event import Event
from persistence.serializers.event import EventSerializer


def test_event_serializer_round_trip():
    at = datetime(2026, 2, 15, 16, 30, tzinfo=timezone.utc)

    event = Event(
        type="task_completed",
        payload={
            "task_id": "task-42",
            "result": "success",
        },
        source="worker-agent",
        correlation_id="mission-1",
        id="evt-1",
        at=at,
    )

    serializer = EventSerializer()

    serialized = serializer.serialize(event)
    restored = serializer.deserialize(serialized)

    assert restored == event


def test_event_serializer_preserves_optional_fields():
    event = Event(
        type="system_started",
        payload={"version": "0.1.0"},
        id="evt-2",
    )

    serializer = EventSerializer()

    restored = serializer.deserialize(serializer.serialize(event))

    assert restored.source is None
    assert restored.correlation_id is None


def test_event_serializer_preserves_payload():
    event = Event(
        type="agent_message",
        payload={
            "message_id": "msg-1",
            "priority": 3,
            "tags": ["coordination", "task"],
        },
        id="evt-3",
    )

    serializer = EventSerializer()

    data = serializer.serialize(event)

    assert data["payload"] == {
        "message_id": "msg-1",
        "priority": 3,
        "tags": ["coordination", "task"],
    }

    restored = serializer.deserialize(data)

    assert restored.payload == event.payload


def test_event_serializer_json_safe_nested_payload():
    from datetime import datetime, timezone

    from ocean.domain.event import Event
    from persistence.serializers.event import EventSerializer

    timestamp = datetime(2026, 9, 5, 12, 0, tzinfo=timezone.utc)

    event = Event(
        type="ResearchFindingRecorded",
        payload={
            "source": {
                "published_at": timestamp,
                "metadata": {
                    "timestamps": [timestamp],
                },
            },
            "at": timestamp,
        },
    )

    data = EventSerializer().serialize(event)

    assert data["payload"]["source"]["published_at"] == timestamp.isoformat()
    assert (
        data["payload"]["source"]["metadata"]["timestamps"][0]
        == timestamp.isoformat()
    )
    assert data["payload"]["at"] == timestamp.isoformat()
