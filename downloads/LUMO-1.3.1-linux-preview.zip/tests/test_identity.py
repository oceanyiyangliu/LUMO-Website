import pytest

from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.event_sourcing.replay import EventReplayer
from ocean.identity import (
    IdentityController,
    Principal,
    PrincipalRegistry,
    PrincipalStatus,
    PrincipalType,
)


def test_principal_has_stable_identity():
    principal = Principal(
        type=PrincipalType.AGENT,
        name="research-agent",
    )

    assert principal.id.startswith("principal_")
    assert principal.type is PrincipalType.AGENT
    assert PrincipalStatus.ACTIVE.value == "active"


def test_registry_registers_and_resolves_principal():
    registry = PrincipalRegistry()
    principal = Principal(
        type=PrincipalType.HUMAN,
        name="operator",
    )

    registry.register(principal)

    assert registry.get(principal.id) is principal
    assert registry.require(principal.id) is principal


def test_registry_rejects_conflicting_duplicate():
    registry = PrincipalRegistry()
    principal = Principal(
        type=PrincipalType.SYSTEM,
        name="system",
    )
    registry.register(principal)

    conflicting = Principal(
        type=PrincipalType.AGENT,
        name="different",
        id=principal.id,
    )

    with pytest.raises(ValueError):
        registry.register(conflicting)


def test_registry_rejects_unknown_principal():
    registry = PrincipalRegistry()

    with pytest.raises(KeyError):
        registry.require("principal_missing")


def test_identity_controller_creates_durable_principal_event():
    events = EventBus()
    controller = IdentityController(event_bus=events)

    principal = controller.create(
        PrincipalType.HUMAN,
        "operator",
        metadata={"source": "local"},
    )

    history = events.history()

    assert len(history) == 1
    assert history[0].type == "PrincipalCreated"
    assert history[0].aggregate_type == "principal"
    assert history[0].aggregate_id == principal.id
    assert history[0].payload["principal_id"] == principal.id
    assert history[0].payload["type"] == "human"


def test_identity_controller_retires_principal_durably():
    events = EventBus()
    controller = IdentityController(event_bus=events)

    principal = controller.create(PrincipalType.AGENT, "worker")
    controller.retire(principal.id)

    assert controller.registry.get(principal.id) is None

    history = events.history()
    assert [event.type for event in history] == [
        "PrincipalCreated",
        "PrincipalRetired",
    ]


def test_registry_rebuilds_active_principals_from_events():
    principal = Principal(
        type=PrincipalType.SYSTEM,
        name="system",
        id="principal-system",
    )

    events = [
        Event(
            type="PrincipalCreated",
            aggregate_type="principal",
            aggregate_id=principal.id,
            payload={
                "principal_id": principal.id,
                "type": principal.type.value,
                "name": principal.name,
                "metadata": dict(principal.metadata),
            },
        )
    ]

    registry = PrincipalRegistry()
    registry.rebuild(events)

    assert registry.require(principal.id) == principal


def test_registry_rebuild_applies_retirement():
    events = [
        Event(
            type="PrincipalCreated",
            aggregate_type="principal",
            aggregate_id="principal-1",
            payload={
                "principal_id": "principal-1",
                "type": "human",
                "name": "operator",
                "metadata": {},
            },
        ),
        Event(
            type="PrincipalRetired",
            aggregate_type="principal",
            aggregate_id="principal-1",
            payload={
                "principal_id": "principal-1",
            },
        ),
    ]

    registry = PrincipalRegistry()
    registry.rebuild(events)

    assert registry.get("principal-1") is None


def test_replayer_replays_principal_creation():
    event = Event(
        type="PrincipalCreated",
        aggregate_type="principal",
        aggregate_id="principal-1",
        payload={
            "principal_id": "principal-1",
            "type": "agent",
            "name": "research-agent",
            "metadata": {"role": "research"},
        },
    )

    state = EventReplayer().replay([event])

    principal = state.principals["principal-1"]
    assert principal.type is PrincipalType.AGENT
    assert principal.name == "research-agent"
    assert principal.metadata == {"role": "research"}


def test_replayer_replays_principal_retirement():
    events = [
        Event(
            type="PrincipalCreated",
            aggregate_type="principal",
            aggregate_id="principal-1",
            payload={
                "principal_id": "principal-1",
                "type": "system",
                "name": "system",
                "metadata": {},
            },
        ),
        Event(
            type="PrincipalRetired",
            aggregate_type="principal",
            aggregate_id="principal-1",
            payload={
                "principal_id": "principal-1",
            },
        ),
    ]

    state = EventReplayer().replay(events)

    assert "principal-1" not in state.principals


def test_replayer_rejects_conflicting_duplicate_principal_creation():
    first = Event(
        type="PrincipalCreated",
        payload={
            "principal_id": "principal-1",
            "type": "human",
            "name": "operator",
            "metadata": {},
        },
    )

    second = Event(
        type="PrincipalCreated",
        payload={
            "principal_id": "principal-1",
            "type": "agent",
            "name": "different",
            "metadata": {},
        },
    )

    with pytest.raises(Exception):
        EventReplayer().replay([first, second])
