from ocean.domain.enums import (
    ApprovalDecision,
    OrchestrationMode,
    RiskLevel,
)
from ocean.domain.policy import PolicyContext, PolicyEngine
from ocean.authorization import (
    AuthorizationEngine,
    StaticAuthorizationPolicy,
)
from ocean.governance import GovernanceEngine, GovernanceRequest


def request(
    *,
    risk=RiskLevel.SAFE,
    mode=OrchestrationMode.STANDARD,
    task_id="task-1",
    agent_id="agent-1",
):
    return GovernanceRequest(
        policy_context=PolicyContext(
            capability="filesystem",
            operation="create_folder",
            risk_level=risk,
        ),
        mode=mode,
        principal_id="principal-1",
        task_id=task_id,
        agent_id=agent_id,
    )


def test_safe_standard_request_is_allowed_and_executable():
    decision = GovernanceEngine(PolicyEngine()).evaluate(request())

    assert decision.allowed is True
    assert decision.approval == ApprovalDecision.AUTOMATIC
    assert decision.orchestration.allowed is True
    assert decision.requires_human is False
    assert decision.executable is True
    assert decision.reasons == ()


def test_human_approval_is_preserved():
    decision = GovernanceEngine(PolicyEngine()).evaluate(
        request(risk=RiskLevel.IMPORTANT)
    )

    assert decision.allowed is True
    assert decision.approval == ApprovalDecision.USER_CONFIRMATION_REQUIRED
    assert decision.requires_human is True
    assert decision.executable is False


def test_explicit_approval_is_preserved():
    decision = GovernanceEngine(PolicyEngine()).evaluate(
        request(risk=RiskLevel.HIGH)
    )

    assert decision.allowed is True
    assert decision.approval == ApprovalDecision.EXPLICIT_APPROVAL_REQUIRED
    assert decision.requires_human is True
    assert decision.executable is False


def test_denied_operation_is_denied():
    policy = PolicyEngine()
    policy.register_override(
        "filesystem",
        "create_folder",
        lambda ctx: ApprovalDecision.DENIED,
    )

    decision = GovernanceEngine(policy).evaluate(request())

    assert decision.allowed is False
    assert decision.approval == ApprovalDecision.DENIED
    assert decision.requires_human is False
    assert decision.executable is False
    assert "operation policy denied execution" in decision.reasons


def test_orchestration_denial_cannot_be_overridden_by_governance():
    class DenyingPolicy:
        mode = OrchestrationMode.STANDARD

        def admission(self, request):
            from ocean.orchestration.policy import AdmissionDecision
            return AdmissionDecision(False, "governance test denial")

        def routing(self, request):
            from ocean.orchestration.policy import RoutingDecision
            return RoutingDecision(request.agent_id)

        def concurrency(self):
            from ocean.orchestration.policy import ConcurrencyPolicy
            return ConcurrencyPolicy()

        def recovery(self):
            from ocean.orchestration.policy import RecoveryPolicy
            return RecoveryPolicy()

    from ocean.orchestration.policy import OrchestrationPolicyRegistry

    registry = OrchestrationPolicyRegistry()
    registry.register(DenyingPolicy())

    decision = GovernanceEngine(
        PolicyEngine(),
        registry,
    ).evaluate(request())

    assert decision.allowed is False
    assert decision.approval == ApprovalDecision.AUTOMATIC
    assert decision.orchestration.allowed is False
    assert decision.executable is False
    assert "governance test denial" in decision.reasons


def test_governance_does_not_consume_resources_or_execute():
    decision = GovernanceEngine(PolicyEngine()).evaluate(
        request(mode=OrchestrationMode.PARALLEL)
    )

    assert decision.allowed is True
    assert decision.executable is True


def test_authorization_is_composed_without_changing_unsecured_compatibility():
    authorization = AuthorizationEngine(
        StaticAuthorizationPolicy(
            {"principal-1": {"filesystem.create"}}
        )
    )
    decision = GovernanceEngine(
        PolicyEngine(),
        authorization=authorization,
    ).evaluate(
        GovernanceRequest(
            policy_context=PolicyContext(
                capability="filesystem",
                operation="create_folder",
                risk_level=RiskLevel.SAFE,
            ),
            principal_id="principal-1",
            mode=OrchestrationMode.STANDARD,
            task_id="task-1",
            agent_id="agent-1",
            required_permissions=frozenset({"filesystem.create"}),
        )
    )

    assert decision.allowed is True
    assert decision.authorization is not None
    assert decision.authorization.allowed is True


def test_authorization_denial_cannot_be_overridden_by_governance():
    authorization = AuthorizationEngine(
        StaticAuthorizationPolicy(
            {"principal-1": {"filesystem.read"}}
        )
    )
    decision = GovernanceEngine(
        PolicyEngine(),
        authorization=authorization,
    ).evaluate(
        GovernanceRequest(
            policy_context=PolicyContext(
                capability="filesystem",
                operation="create_folder",
                risk_level=RiskLevel.SAFE,
            ),
            principal_id="principal-1",
            mode=OrchestrationMode.STANDARD,
            task_id="task-1",
            agent_id="agent-1",
            required_permissions=frozenset({"filesystem.create"}),
        )
    )

    assert decision.allowed is False
    assert decision.executable is False
    assert decision.authorization is not None
    assert decision.authorization.allowed is False


def test_authorization_requires_identity_when_enabled():
    authorization = AuthorizationEngine(
        StaticAuthorizationPolicy()
    )
    decision = GovernanceEngine(
        PolicyEngine(),
        authorization=authorization,
    ).evaluate(
        GovernanceRequest(
            policy_context=PolicyContext(
                capability="filesystem",
                operation="create_folder",
                risk_level=RiskLevel.SAFE,
            ),
            mode=OrchestrationMode.STANDARD,
        )
    )

    assert decision.allowed is False
    assert decision.authorization is not None
    assert decision.authorization.allowed is False
