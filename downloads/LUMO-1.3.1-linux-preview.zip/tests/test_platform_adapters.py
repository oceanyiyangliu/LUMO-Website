from __future__ import annotations

from ocean.platforms import LinuxAdapter, MacOSAdapter, WindowsAdapter, platform_adapter, runtime_state_dir


def test_platform_adapters_use_isolated_user_state():
    for adapter_cls in (MacOSAdapter, WindowsAdapter, LinuxAdapter):
        adapter = adapter_cls()
        assert adapter.app_data_dir() != adapter.cache_dir()
        assert adapter.config_dir().is_absolute()
        assert adapter.capabilities()["filesystem"] is True
        assert adapter.capabilities()["local_models"] is True


def test_windows_adapter_respects_localappdata(monkeypatch, tmp_path):
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "LocalAppData"))
    assert WindowsAdapter().app_data_dir() == tmp_path / "LocalAppData" / "LUMO"


def test_linux_adapter_respects_xdg_directories(monkeypatch, tmp_path):
    monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path / "data"))
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "cache"))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "config"))
    adapter = LinuxAdapter()
    assert adapter.app_data_dir() == tmp_path / "data" / "LUMO"
    assert adapter.cache_dir() == tmp_path / "cache" / "LUMO"
    assert adapter.config_dir() == tmp_path / "config" / "LUMO"


def test_runtime_state_dir_honors_explicit_override(monkeypatch, tmp_path):
    state = tmp_path / "state"
    monkeypatch.setenv("LUMO_STATE_DIR", str(state))
    assert runtime_state_dir() == state
    assert state.is_dir()


def test_current_platform_adapter_is_supported():
    adapter = platform_adapter()
    assert adapter.info.os in {"macos", "windows", "linux"}
    assert adapter.info.architecture
