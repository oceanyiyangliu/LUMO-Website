"""Tests for the lease-expiry sweeper background thread."""

from __future__ import annotations

import threading
import time
from datetime import datetime, timedelta, timezone
from typing import List

import pytest

from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.workforce.lease import AssignmentLeaseCoordinator, AssignmentLeaseState
from ocean.workforce.lease_sweeper import LeaseExpirySweeper


def make_coordinator():
    """Build a minimal lease coordinator for sweeper tests."""
    events = EventBus()
    coordinator = AssignmentLeaseCoordinator(event_bus=events)
    return coordinator, events


# ---------------------------------------------------------------------------
# Constructor validation
# ---------------------------------------------------------------------------


def test_requires_lease_coordinator():
    with pytest.raises(ValueError, match="lease_coordinator is required"):
        LeaseExpirySweeper(lease_coordinator=None)


def test_requires_positive_interval():
    coordinator, _ = make_coordinator()
    with pytest.raises(ValueError, match="interval_seconds must be positive"):
        LeaseExpirySweeper(lease_coordinator=coordinator, interval_seconds=0)


def test_default_interval():
    coordinator, _ = make_coordinator()
    sweeper = LeaseExpirySweeper(lease_coordinator=coordinator)
    assert sweeper.interval_seconds == 10.0


def test_custom_interval():
    coordinator, _ = make_coordinator()
    sweeper = LeaseExpirySweeper(
        lease_coordinator=coordinator, interval_seconds=5.0
    )
    assert sweeper.interval_seconds == 5.0


def test_custom_name():
    coordinator, _ = make_coordinator()
    sweeper = LeaseExpirySweeper(
        lease_coordinator=coordinator, name="custom-sweeper"
    )
    assert sweeper._name == "custom-sweeper"


# ---------------------------------------------------------------------------
# sweep_once
# ---------------------------------------------------------------------------


def test_sweep_once_returns_zero_when_no_leases():
    coordinator, _ = make_coordinator()
    sweeper = LeaseExpirySweeper(lease_coordinator=coordinator)
    count = sweeper.sweep_once()
    assert count == 0


def test_sweep_once_expires_overdue_leases():
    coordinator, _ = make_coordinator()

    lease = coordinator.acquire(
        assignment_id="assignment-1",
        agent_id="agent-1",
        attempt_id="attempt-1",
        lease_seconds=0.01,
    )

    assert lease.state is AssignmentLeaseState.ACTIVE

    time.sleep(0.05)

    sweeper = LeaseExpirySweeper(lease_coordinator=coordinator)
    count = sweeper.sweep_once()
    assert count == 1

    updated = coordinator.get(lease.lease_id)
    assert updated.state is not AssignmentLeaseState.ACTIVE


def test_sweep_once_does_not_expire_active_leases():
    coordinator, _ = make_coordinator()

    lease = coordinator.acquire(
        assignment_id="assignment-1",
        agent_id="agent-1",
        attempt_id="attempt-1",
        lease_seconds=600,
    )

    sweeper = LeaseExpirySweeper(lease_coordinator=coordinator)
    count = sweeper.sweep_once()
    assert count == 0

    updated = coordinator.get(lease.lease_id)
    assert updated.state is AssignmentLeaseState.ACTIVE


def test_sweep_once_expires_multiple_overdue_leases():
    coordinator, _ = make_coordinator()

    for i in range(3):
        coordinator.acquire(
            assignment_id=f"assignment-{i}",
            agent_id="agent-1",
            attempt_id=f"attempt-{i}",
            lease_seconds=0.01,
        )

    time.sleep(0.05)

    sweeper = LeaseExpirySweeper(lease_coordinator=coordinator)
    count = sweeper.sweep_once()
    assert count == 3


def test_sweep_once_after_expire_due():
    coordinator, _ = make_coordinator()

    lease = coordinator.acquire(
        assignment_id="assignment-1",
        agent_id="agent-1",
        attempt_id="attempt-1",
        lease_seconds=0.01,
    )

    time.sleep(0.05)

    sweeper = LeaseExpirySweeper(lease_coordinator=coordinator)

    count = sweeper.sweep_once()
    assert count == 1

    count2 = sweeper.sweep_once()
    assert count2 == 0


# ---------------------------------------------------------------------------
# Background thread lifecycle
# ---------------------------------------------------------------------------


def test_start_and_stop():
    coordinator, _ = make_coordinator()
    sweeper = LeaseExpirySweeper(
        lease_coordinator=coordinator, interval_seconds=0.5
    )

    assert sweeper.is_running is False

    sweeper.start()
    assert sweeper.is_running is True

    sweeper.stop()
    assert sweeper.is_running is False


def test_start_is_idempotent():
    coordinator, _ = make_coordinator()
    sweeper = LeaseExpirySweeper(
        lease_coordinator=coordinator, interval_seconds=0.5
    )

    sweeper.start()
    thread1 = sweeper._thread

    sweeper.start()
    thread2 = sweeper._thread

    assert thread1 is thread2

    sweeper.stop()


def test_stop_is_idempotent():
    coordinator, _ = make_coordinator()
    sweeper = LeaseExpirySweeper(
        lease_coordinator=coordinator, interval_seconds=0.5
    )

    sweeper.stop()
    sweeper.stop()


def test_background_thread_expires_overdue_leases():
    coordinator, _ = make_coordinator()

    sweeper = LeaseExpirySweeper(
        lease_coordinator=coordinator, interval_seconds=0.1
    )

    lease = coordinator.acquire(
        assignment_id="assignment-1",
        agent_id="agent-1",
        attempt_id="attempt-1",
        lease_seconds=0.01,
    )

    sweeper.start()

    deadline = time.monotonic() + 3.0
    expired = False
    while time.monotonic() < deadline:
        current = coordinator.get(lease.lease_id)
        if current is not None and current.state is not AssignmentLeaseState.ACTIVE:
            expired = True
            break
        time.sleep(0.05)

    sweeper.stop()

    assert expired, "background sweeper did not expire the overdue lease"


def test_background_thread_survives_exception():
    coordinator, _ = make_coordinator()

    sweeper = LeaseExpirySweeper(
        lease_coordinator=coordinator, interval_seconds=0.1
    )

    sweeper.start()

    time.sleep(0.3)

    assert sweeper.is_running is True

    sweeper.stop()


# ---------------------------------------------------------------------------
# Concurrent access
# ---------------------------------------------------------------------------


def test_concurrent_start_stop():
    coordinator, _ = make_coordinator()
    sweeper = LeaseExpirySweeper(
        lease_coordinator=coordinator, interval_seconds=0.1
    )

    def start_stop():
        for _ in range(10):
            sweeper.start()
            time.sleep(0.01)
            sweeper.stop()

    threads = [threading.Thread(target=start_stop) for _ in range(3)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=5)

    sweeper.stop()


def test_sweep_during_background_operation():
    coordinator, _ = make_coordinator()
    sweeper = LeaseExpirySweeper(
        lease_coordinator=coordinator, interval_seconds=0.1
    )

    sweeper.start()

    for i in range(5):
        coordinator.acquire(
            assignment_id=f"assignment-{i}",
            agent_id="agent-1",
            attempt_id=f"attempt-{i}",
            lease_seconds=600,
        )

    count = sweeper.sweep_once()

    sweeper.stop()

    assert count == 0
