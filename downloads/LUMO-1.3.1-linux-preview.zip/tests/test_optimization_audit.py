from ocean.optimization_audit import summarize

def test_710_audit_is_bounded_and_machine_readable():
 s=summarize('.')
 assert s.total==710 and 0<=s.evidenced<=710 and s.evidenced+s.partial+s.unevidenced+s.deferred==710
 assert '/ 710 DONE' in s.label()
