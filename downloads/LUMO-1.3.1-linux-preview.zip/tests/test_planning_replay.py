from datetime import datetime, timezone

import pytest

from ocean.domain.event import Event
from ocean.event_sourcing.replay import EventReplayer, ReplayError


def mission_event():
    return Event(
        type="MissionCreated",
        payload={
            "id": "mission-1",
            "goal": "Build an autonomous research system",
            "task_ids": [],
            "metadata": {},
        },
    )


def decision_event():
    return Event(
        type="DecisionCreated",
        payload={
            "id": "decision-1",
            "mission_id": "mission-1",
            "kind": "decomposition",
            "objective": "Parallelize research",
            "rationale": "Independent research streams can run concurrently.",
            "alternatives": ["serial", "parallel"],
            "selected_option": "parallel",
            "confidence": 0.9,
            "evidence": ["constraint-1"],
            "metadata": {"strategy": {"parallel": True}},
        },
    )


def graph_event():
    return Event(
        type="WorkGraphCreated",
        payload={
            "id": "graph-1",
            "mission_id": "mission-1",
            "plan_revision_id": "plan-1",
            "nodes": [
                {
                    "id": "node-1",
                    "kind": "task",
                    "task_id": "task-1",
                    "metadata": {},
                },
                {
                    "id": "node-2",
                    "kind": "task",
                    "task_id": "task-2",
                    "metadata": {},
                },
            ],
            "edges": [
                {
                    "id": "edge-1",
                    "source_node_id": "node-1",
                    "target_node_id": "node-2",
                    "kind": "dependency",
                    "condition": None,
                }
            ],
            "metadata": {},
        },
    )


def plan_event():
    return Event(
        type="PlanRevisionCreated",
        payload={
            "id": "plan-1",
            "mission_id": "mission-1",
            "revision": 1,
            "decision_id": "decision-1",
            "graph_id": "graph-1",
            "status": "draft",
            "metadata": {},
        },
    )


def planning_history():
    return [
        mission_event(),
        decision_event(),
        graph_event(),
        plan_event(),
    ]


def test_replayer_replays_planning_entities():
    state = EventReplayer().replay(planning_history())

    assert "decision-1" in state.decisions
    assert "graph-1" in state.work_graphs
    assert "plan-1" in state.plan_revisions

    assert state.decisions["decision-1"].mission_id == "mission-1"
    assert state.work_graphs["graph-1"].plan_revision_id == "plan-1"
    assert state.plan_revisions["plan-1"].status.value == "draft"


def test_replayer_replays_full_plan_lifecycle():
    events = planning_history()

    events.extend(
        [
            Event(
                type="PlanRevisionProposed",
                payload={"id": "plan-1", "reason": "Ready for review"},
            ),
            Event(
                type="PlanRevisionActivated",
                payload={"id": "plan-1"},
            ),
            Event(
                type="PlanRevisionCompleted",
                payload={"id": "plan-1", "reason": "Mission work completed"},
            ),
        ]
    )

    state = EventReplayer().replay(events)

    plan = state.plan_revisions["plan-1"]

    assert plan.status.value == "completed"
    assert plan.reason == "Mission work completed"
    assert plan.id == "plan-1"
    assert plan.revision == 1


def test_plan_lifecycle_replaces_immutable_revision():
    events = planning_history()

    state = EventReplayer().replay(events)
    draft = state.plan_revisions["plan-1"]

    state = EventReplayer().replay(
        events
        + [Event(type="PlanRevisionProposed", payload={"id": "plan-1"})]
    )
    proposed = state.plan_revisions["plan-1"]

    assert draft.status.value == "draft"
    assert proposed.status.value == "proposed"
    assert draft is not proposed


def test_replayer_rejects_unknown_decision_mission():
    event = Event(
        type="DecisionCreated",
        payload={
            "id": "decision-1",
            "mission_id": "missing",
            "kind": "plan",
            "objective": "Objective",
            "rationale": "Reason",
        },
    )

    with pytest.raises(ReplayError):
        EventReplayer().replay([event])


def test_replayer_rejects_unknown_plan_decision():
    events = [
        mission_event(),
        graph_event(),
        Event(
            type="PlanRevisionCreated",
            payload={
                "id": "plan-1",
                "mission_id": "mission-1",
                "revision": 1,
                "decision_id": "missing-decision",
                "graph_id": "graph-1",
            },
        ),
    ]

    with pytest.raises(ReplayError, match="unknown decision"):
        EventReplayer().replay(events)


def test_replayer_rejects_unknown_plan_graph():
    events = [
        mission_event(),
        decision_event(),
        Event(
            type="PlanRevisionCreated",
            payload={
                "id": "plan-1",
                "mission_id": "mission-1",
                "revision": 1,
                "decision_id": "decision-1",
                "graph_id": "missing-graph",
            },
        ),
    ]

    with pytest.raises(ReplayError, match="unknown work graph"):
        EventReplayer().replay(events)


def test_replayer_rejects_graph_plan_mismatch():
    events = [
        mission_event(),
        decision_event(),
        Event(
            type="WorkGraphCreated",
            payload={
                **graph_event().payload,
                "plan_revision_id": "different-plan",
            },
        ),
        plan_event(),
    ]

    with pytest.raises(ReplayError, match="references plan"):
        EventReplayer().replay(events)


def test_replayer_rejects_invalid_plan_transition():
    events = planning_history() + [
        Event(
            type="PlanRevisionActivated",
            payload={"id": "plan-1"},
        )
    ]

    with pytest.raises(ReplayError, match="cannot transition"):
        EventReplayer().replay(events)


def test_replayer_rejects_unknown_plan_transition():
    with pytest.raises(ReplayError):
        EventReplayer().replay(
            [
                Event(
                    type="PlanRevisionActivated",
                    payload={"id": "missing-plan"},
                )
            ]
        )


def test_replayer_rejects_duplicate_decision():
    events = [
        mission_event(),
        decision_event(),
        decision_event(),
    ]

    with pytest.raises(ReplayError, match="duplicate"):
        EventReplayer().replay(events)


def test_replayer_rejects_duplicate_plan():
    events = planning_history() + [plan_event()]

    with pytest.raises(ReplayError, match="duplicate"):
        EventReplayer().replay(events)


def test_replayer_rejects_invalid_parent_revision():
    events = planning_history() + [
        Event(
            type="PlanRevisionCreated",
            payload={
                "id": "plan-2",
                "mission_id": "mission-1",
                "revision": 2,
                "decision_id": "decision-1",
                "graph_id": "graph-1",
                "parent_revision_id": "missing-plan",
            },
        )
    ]

    with pytest.raises(ReplayError, match="unknown parent"):
        EventReplayer().replay(events)


def test_replayer_rejects_parent_from_wrong_mission():
    events = [
        mission_event(),
        decision_event(),
        graph_event(),
        plan_event(),
        Event(
            type="MissionCreated",
            payload={
                "id": "mission-2",
                "goal": "Other mission",
                "task_ids": [],
                "metadata": {},
            },
        ),
    ]

    # A revision cannot directly point to a plan from another mission.
    # The existing plan is mission-1, so construct a revision whose parent
    # is that plan but whose mission is mission-2.
    events.extend(
        [
            Event(
                type="DecisionCreated",
                payload={
                    "id": "decision-2",
                    "mission_id": "mission-2",
                    "kind": "plan",
                    "objective": "Other objective",
                    "rationale": "Other reason",
                },
            ),
            Event(
                type="WorkGraphCreated",
                payload={
                    "id": "graph-2",
                    "mission_id": "mission-2",
                    "plan_revision_id": "plan-2",
                    "nodes": [],
                    "edges": [],
                    "metadata": {},
                },
            ),
            Event(
                type="PlanRevisionCreated",
                payload={
                    "id": "plan-2",
                    "mission_id": "mission-2",
                    "revision": 2,
                    "decision_id": "decision-2",
                    "graph_id": "graph-2",
                    "parent_revision_id": "plan-1",
                },
            ),
        ]
    )

    with pytest.raises(ReplayError, match="belongs to mission"):
        EventReplayer().replay(events)
