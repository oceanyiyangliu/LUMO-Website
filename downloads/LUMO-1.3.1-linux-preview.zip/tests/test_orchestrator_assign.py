from ocean.domain.agent import Agent
from ocean.domain.assignment import Assignment
from ocean.domain.event_bus import EventBus
from ocean.domain.mission import Mission
from ocean.domain.task import Task
from ocean.orchestration.orchestrator import (
    OrchestrationPorts,
    Orchestrator,
)
from ocean.orchestration.types import AssignmentRequest
from persistence.in_memory import InMemoryRepository


class MissionRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item


class TaskRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item


class AssignmentRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item

    def list(self):
        return list(self.items.values())

    def transaction(self):
        from contextlib import contextmanager

        @contextmanager
        def _tx():
            yield

        return _tx()


class AgentRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item


class RuntimeStub:
    def submit(self, *args, **kwargs):
        raise AssertionError("assign() must not dispatch execution")

    def mark_idle(self, agent_id):
        raise AssertionError("assign() must not change agent state")

    def mark_waiting(self, agent_id, *, task_id=None):
        raise AssertionError("assign() must not change agent state")

    def mark_background(self, agent_id):
        raise AssertionError("assign() must not change agent state")


def build():
    missions = MissionRepo()
    tasks = TaskRepo()
    assignments = AssignmentRepo()
    agents = AgentRepo()

    ports = OrchestrationPorts(
        missions=missions,
        tasks=tasks,
        assignments=assignments,
        agents=agents,
        agent_runtime=RuntimeStub(),
        events=EventBus(),
    )

    return (
        Orchestrator(ports),
        missions,
        tasks,
        assignments,
        agents,
    )


def test_assign_creates_and_queues_assignment():
    orchestrator, missions, tasks, assignments, agents = build()

    mission = Mission(goal="Build a research system")
    task = Task(title="Research architecture", mission_id=mission.id)
    mission.add_task(task.id)

    agent = Agent(
        name="Research Agent",
        role="researcher",
        capabilities={"research"},
    )

    missions.save(mission)
    tasks.save(task)
    agents.save(agent)

    result = orchestrator.assign(
        AssignmentRequest(
            task_id=task.id,
            agent_id=agent.id,
            mission_id=mission.id,
        )
    )

    assert result.success is True
    assert result.assignment_id is not None

    assignment = assignments.get(result.assignment_id)

    assert assignment is not None
    assert assignment.status.value == "queued"
    assert assignment.task_id == task.id
    assert assignment.agent_id == agent.id


def test_assign_emits_created_then_queued():
    orchestrator, missions, tasks, assignments, agents = build()

    mission = Mission(goal="Test orchestration")
    task = Task(title="Test task", mission_id=mission.id)
    mission.add_task(task.id)

    agent = Agent(
        name="Test Agent",
        role="tester",
        capabilities={"test"},
    )

    missions.save(mission)
    tasks.save(task)
    agents.save(agent)

    result = orchestrator.assign(
        AssignmentRequest(
            task_id=task.id,
            agent_id=agent.id,
            mission_id=mission.id,
        )
    )

    events = orchestrator.ports.events.history()

    assert result.success is True
    assert [event.type for event in events] == [
        "TaskAssignmentCreated",
        "TaskAssignmentQueued",
    ]

    assert events[0].payload["assignment_id"] == result.assignment_id
    assert events[1].payload["assignment_id"] == result.assignment_id


def test_assign_rejects_unknown_task():
    orchestrator, missions, tasks, assignments, agents = build()

    result = orchestrator.assign(
        AssignmentRequest(
            task_id="missing-task",
            agent_id="agent-1",
        )
    )

    assert result.success is False
    assert "unknown task" in result.error
    assert assignments.list() == []


def test_assign_rejects_unknown_agent():
    orchestrator, missions, tasks, assignments, agents = build()

    task = Task(title="Task")
    tasks.save(task)

    result = orchestrator.assign(
        AssignmentRequest(
            task_id=task.id,
            agent_id="missing-agent",
        )
    )

    assert result.success is False
    assert "unknown agent" in result.error
    assert assignments.list() == []


def test_assign_rejects_terminal_task():
    orchestrator, missions, tasks, assignments, agents = build()

    task = Task(title="Finished task")
    task.cancel()
    tasks.save(task)

    agent = Agent(
        name="Agent",
        role="worker",
        capabilities={"work"},
    )
    agents.save(agent)

    result = orchestrator.assign(
        AssignmentRequest(
            task_id=task.id,
            agent_id=agent.id,
        )
    )

    assert result.success is False
    assert "terminal task" in result.error
    assert assignments.list() == []


def test_assign_validates_mission_membership():
    orchestrator, missions, tasks, assignments, agents = build()

    mission = Mission(goal="Mission")
    other_mission = Mission(goal="Other")
    task = Task(title="Task", mission_id=mission.id)
    agent = Agent(
        name="Agent",
        role="worker",
        capabilities={"work"},
    )

    missions.save(mission)
    missions.save(other_mission)
    tasks.save(task)
    agents.save(agent)

    result = orchestrator.assign(
        AssignmentRequest(
            task_id=task.id,
            agent_id=agent.id,
            mission_id=other_mission.id,
        )
    )

    assert result.success is False
    assert "does not belong" in result.error
    assert assignments.list() == []


def test_plan_managed_assignment_admission_is_concurrent():
    from concurrent.futures import ThreadPoolExecutor

    missions = MissionRepo()
    tasks = TaskRepo()
    assignments = InMemoryRepository()
    agents = AgentRepo()

    mission = Mission(goal="Admission concurrency test")
    task = Task(title="Concurrent work", mission_id=mission.id)
    mission.add_task(task.id)
    agent = Agent(
        name="Admission Agent",
        role="worker",
        capabilities={"research"},
    )

    missions.save(mission)
    tasks.save(task)
    agents.save(agent)

    ports = OrchestrationPorts(
        missions=missions,
        tasks=tasks,
        assignments=assignments,
        agents=agents,
        agent_runtime=RuntimeStub(),
        events=EventBus(),
    )
    orchestrator = Orchestrator(ports)

    request = AssignmentRequest(
        task_id=task.id,
        agent_id=agent.id,
        mission_id=mission.id,
        metadata={
            "execution_plan_id": "plan-admission",
            "execution_node_id": "node-admission",
        },
    )

    def assign():
        return orchestrator.assign(request)

    with ThreadPoolExecutor(max_workers=16) as pool:
        results = list(pool.map(lambda _: assign(), range(16)))

    successful = [result for result in results if result.success]
    assignment_ids = {result.assignment_id for result in successful}

    assert len(successful) == 16
    assert len(assignment_ids) == 1
    assert len(assignments.list()) == 1
