from pathlib import Path

import pytest

from ocean.self_improvement.code_modification import (
    CandidateWorkspaceService,
    CodeChange,
    CodeModification,
    CodeModificationRequest,
    CodeModificationService,
)


class Provider:
    def __init__(self, modification):
        self.modification = modification
        self.request = None

    def generate(self, request):
        self.request = request
        return self.modification


def test_workspace_isolated_from_source(tmp_path):
    source = tmp_path / "repo"
    source.mkdir()
    (source / "app.py").write_text("VALUE = 1\n")

    service = CandidateWorkspaceService()
    workspace = service.create(
        candidate_id="candidate-1",
        repository_root=source,
    )

    assert workspace.root != source.resolve()
    assert (workspace.root / "app.py").read_text() == "VALUE = 1\n"

    (workspace.root / "app.py").write_text("VALUE = 2\n")

    assert (source / "app.py").read_text() == "VALUE = 1\n"

    service.destroy(workspace)


def test_candidate_workspace_rejects_symlink(tmp_path):
    source = tmp_path / "repo"
    source.mkdir()
    outside = tmp_path / "outside.txt"
    outside.write_text("secret\n")
    (source / "external.txt").symlink_to(outside)

    service = CandidateWorkspaceService()
    with pytest.raises(ValueError, match="symlinks are forbidden"):
        service.create(candidate_id="candidate-symlink", repository_root=source)


def test_candidate_workspace_ignores_virtualenv_symlinks(tmp_path):
    source = tmp_path / "repo"
    source.mkdir()
    venv_bin = source / ".venv" / "bin"
    venv_bin.mkdir(parents=True)
    target = tmp_path / "python3"
    target.write_text("python\n")
    (venv_bin / "python3").symlink_to(target)

    service = CandidateWorkspaceService()
    workspace = service.create(
        candidate_id="candidate-venv",
        repository_root=source,
    )

    assert not (workspace.root / ".venv").exists()
    service.destroy(workspace)


def test_code_provider_writes_only_candidate_workspace(tmp_path):
    source = tmp_path / "repo"
    source.mkdir()
    (source / "app.py").write_text("VALUE = 1\n")

    modification = CodeModification(
        candidate_id="candidate-1",
        changes=(
            CodeChange(
                path="app.py",
                content="VALUE = 2\n",
            ),
        ),
    )
    provider = Provider(modification)

    service = CodeModificationService(
        workspaces=CandidateWorkspaceService()
    )

    workspace, result = service.generate_and_apply(
        request=CodeModificationRequest(
            candidate_id="candidate-1",
            objective="Improve app",
            repository_root=source,
        ),
        provider=provider,
    )

    assert result == modification
    assert provider.request.repository_root == workspace.root
    assert (workspace.root / "app.py").read_text() == "VALUE = 2\n"
    assert (source / "app.py").read_text() == "VALUE = 1\n"

    service._workspaces.destroy(workspace)


def test_provider_is_told_production_mutation_is_forbidden(tmp_path):
    source = tmp_path / "repo"
    source.mkdir()

    provider = Provider(
        CodeModification(
            candidate_id="candidate-1",
            changes=(CodeChange("app.py", "VALUE = 2\\n"),),
        )
    )

    service = CodeModificationService(
        workspaces=CandidateWorkspaceService()
    )

    workspace, _ = service.generate_and_apply(
        request=CodeModificationRequest(
            candidate_id="candidate-1",
            objective="Inspect",
            repository_root=source,
        ),
        provider=provider,
    )

    assert provider.request.constraints["candidate_workspace"] is True
    assert provider.request.constraints["production_mutation_forbidden"] is True

    service._workspaces.destroy(workspace)


@pytest.mark.parametrize(
    "path",
    [
        "/tmp/escape.py",
        "../escape.py",
        "foo/../../escape.py",
    ],
)
def test_code_modification_rejects_unsafe_paths(tmp_path, path):
    source = tmp_path / "repo"
    source.mkdir()

    provider = Provider(
        CodeModification(
            candidate_id="candidate-1",
            changes=(
                CodeChange(path=path, content="bad\n"),
            ),
        )
    )

    service = CodeModificationService(
        workspaces=CandidateWorkspaceService()
    )

    with pytest.raises(ValueError):
        service.generate_and_apply(
            request=CodeModificationRequest(
                candidate_id="candidate-1",
                objective="Unsafe",
                repository_root=source,
            ),
            provider=provider,
        )

    assert not (source / "escape.py").exists()


def test_code_modification_rejects_missing_parent_directories(tmp_path):
    source = tmp_path / "repo"
    source.mkdir()

    provider = Provider(
        CodeModification(
            candidate_id="candidate-1",
            changes=(CodeChange(path="OS/lumo_final", content="not a file\n"),),
        )
    )

    service = CodeModificationService(
        workspaces=CandidateWorkspaceService()
    )

    with pytest.raises(ValueError, match="parent directory does not exist"):
        service.generate_and_apply(
            request=CodeModificationRequest(
                candidate_id="candidate-1",
                objective="Missing parent",
                repository_root=source,
            ),
            provider=provider,
        )


def test_code_modification_rejects_directory_targets(tmp_path):
    source = tmp_path / "repo"
    source.mkdir()
    (source / "Tests").mkdir()

    provider = Provider(
        CodeModification(
            candidate_id="candidate-1",
            changes=(CodeChange(path="Tests", content="not a file\n"),),
        )
    )

    service = CodeModificationService(
        workspaces=CandidateWorkspaceService()
    )

    with pytest.raises(ValueError, match="target is not a file"):
        service.generate_and_apply(
            request=CodeModificationRequest(
                candidate_id="candidate-1",
                objective="Directory target",
                repository_root=source,
            ),
            provider=provider,
        )


def test_code_modification_rejects_wrong_candidate(tmp_path):
    source = tmp_path / "repo"
    source.mkdir()

    provider = Provider(
        CodeModification(
            candidate_id="different-candidate",
            changes=(),
        )
    )

    service = CodeModificationService(
        workspaces=CandidateWorkspaceService()
    )

    with pytest.raises(ValueError):
        service.generate_and_apply(
            request=CodeModificationRequest(
                candidate_id="candidate-1",
                objective="Mismatch",
                repository_root=source,
            ),
            provider=provider,
        )


def test_code_modification_rejects_duplicate_paths(tmp_path):
    source = tmp_path / "repo"
    source.mkdir()

    provider = Provider(
        CodeModification(
            candidate_id="candidate-1",
            changes=(
                CodeChange(path="app.py", content="one\n"),
                CodeChange(path="app.py", content="two\n"),
            ),
        )
    )

    service = CodeModificationService(
        workspaces=CandidateWorkspaceService()
    )

    with pytest.raises(ValueError):
        service.generate_and_apply(
            request=CodeModificationRequest(
                candidate_id="candidate-1",
                objective="Duplicate",
                repository_root=source,
            ),
            provider=provider,
        )

    assert not (source / "app.py").exists()


def test_candidate_diff_does_not_modify_source(tmp_path):
    source = tmp_path / "repo"
    source.mkdir()
    (source / "app.py").write_text("VALUE = 1\n")

    service = CandidateWorkspaceService()
    workspace = service.create(
        candidate_id="candidate-1",
        repository_root=source,
    )

    (workspace.root / "app.py").write_text("VALUE = 2\n")
    (workspace.root / "new.py").write_text("NEW = True\n")

    diff = CodeModificationService(workspaces=service).diff(workspace)

    assert "production/app.py" in diff
    assert "candidate/app.py" in diff
    assert "NEW = True" in diff
    assert (source / "app.py").read_text() == "VALUE = 1\n"
    assert not (source / "new.py").exists()

    service.destroy(workspace)


def test_candidate_workspace_excludes_ocean_state(tmp_path):
    from ocean.self_improvement.code_modification import CandidateWorkspaceService

    repository = tmp_path / "repository"
    repository.mkdir()

    (repository / "source.py").write_text("value = 1\n")

    ocean = repository / ".ocean"
    ocean.mkdir()
    (ocean / "state.sqlite3").write_text("production state")

    service = CandidateWorkspaceService()
    workspace = service.create(
        candidate_id="candidate-isolation",
        repository_root=repository,
    )

    try:
        assert (workspace.root / "source.py").exists()
        assert not (workspace.root / ".ocean").exists()
        assert not (workspace.root / ".ocean" / "state.sqlite3").exists()
    finally:
        service.destroy(workspace)



def test_production_code_promotion_and_rollback(tmp_path):
    from ocean.self_improvement.code_modification import ProductionCodePromotionService

    production = tmp_path / "production"
    candidate = tmp_path / "candidate"
    production.mkdir()
    candidate.mkdir()
    (production / "app.py").write_text("VALUE = 1\n")
    (candidate / "app.py").write_text("VALUE = 2\n")

    service = ProductionCodePromotionService()
    receipt = service.promote(
        candidate_root=candidate,
        production_root=production,
        changed_paths=("app.py",),
        run_id="run-1",
    )

    assert (production / "app.py").read_text() == "VALUE = 2\n"
    service.rollback(receipt)
    assert (production / "app.py").read_text() == "VALUE = 1\n"


class _GovernedRuntime:
    def __init__(self, result):
        self.result = result
        self.calls = []

    def execute(self, request):
        self.calls.append(request)
        return self.result


class _RuntimeResult:
    def __init__(self, *, success=True, result=None, error=None):
        self.success = success
        self.result = result
        self.error = error


def test_governed_runtime_failure_does_not_fallback_to_local_execution(tmp_path):
    from ocean.self_improvement.test_execution import (
        CandidateTestExecutionRequest,
        CandidateTestExecutionService,
    )

    workspace = tmp_path / "candidate"
    workspace.mkdir()
    (workspace / "test.py").write_text("raise RuntimeError('must not run locally')\n")
    runtime = _GovernedRuntime(_RuntimeResult(success=False, result=None, error="runtime unavailable"))
    service = CandidateTestExecutionService(runtime)

    with pytest.raises(RuntimeError, match="unstructured result"):
        service.run(CandidateTestExecutionRequest(
            candidate_id="candidate-1",
            workspace_root=str(workspace),
            command=("python", "test.py"),
        ))

    assert len(runtime.calls) == 1


def test_governed_runtime_requires_structured_exit_code(tmp_path):
    from ocean.self_improvement.test_execution import (
        CandidateTestExecutionRequest,
        CandidateTestExecutionService,
    )

    workspace = tmp_path / "candidate"
    workspace.mkdir()
    runtime = _GovernedRuntime(_RuntimeResult(success=True, result={"stdout": "ok"}))
    service = CandidateTestExecutionService(runtime)

    with pytest.raises(RuntimeError, match="missing exit_code"):
        service.run(CandidateTestExecutionRequest(
            candidate_id="candidate-2",
            workspace_root=str(workspace),
            command=("python", "-c", "pass"),
        ))



def test_governed_runtime_maps_canonical_result(tmp_path):
    from ocean.self_improvement.test_execution import (
        CandidateTestExecutionRequest,
        CandidateTestExecutionService,
    )

    workspace = tmp_path / "candidate"
    workspace.mkdir()
    runtime = _GovernedRuntime(
        _RuntimeResult(
            success=True,
            result={
                "stdout": "all passed",
                "stderr": "",
                "exit_code": 0,
                "timed_out": False,
                "duration_seconds": 1.25,
            },
        )
    )
    service = CandidateTestExecutionService(runtime)

    result = service.run(CandidateTestExecutionRequest(
        candidate_id="candidate-3",
        workspace_root=str(workspace),
        command=("python", "-m", "pytest", "-q"),
        metadata={"mission_id": "mission-1", "objective_id": "objective-1"},
    ))

    assert result.passed is True
    assert result.exit_code == 0
    assert result.timed_out is False
    assert result.stdout == "all passed"
    assert result.metadata["executed_via_runtime"] is True
    assert result.metadata["lumo_evidence"]["result"]["passed"] is True
    assert runtime.calls[0].capability == "test_execution"
    assert runtime.calls[0].operation == "run"


def test_governed_runtime_nonzero_exit_is_not_pass(tmp_path):
    from ocean.self_improvement.test_execution import (
        CandidateTestExecutionRequest,
        CandidateTestExecutionService,
    )

    workspace = tmp_path / "candidate"
    workspace.mkdir()
    runtime = _GovernedRuntime(
        _RuntimeResult(
            success=True,
            result={"stdout": "failure", "stderr": "boom", "exit_code": 1,
                    "timed_out": False, "duration_seconds": 0.5},
        )
    )

    result = CandidateTestExecutionService(runtime).run(
        CandidateTestExecutionRequest(
            candidate_id="candidate-4", workspace_root=str(workspace),
            command=("python", "-c", "raise SystemExit(1)"),
        )
    )

    assert result.passed is False
    assert result.exit_code == 1


def test_production_code_recovery_rolls_back_crashed_promotion(tmp_path):
    from ocean.self_improvement.code_modification import ProductionCodePromotionService

    production = tmp_path / "production"
    candidate = tmp_path / "candidate"
    production.mkdir()
    candidate.mkdir()
    (production / "app.py").write_text("VALUE = 1\n")
    (candidate / "app.py").write_text("VALUE = 2\n")

    service = ProductionCodePromotionService()
    receipt = service.promote(
        candidate_root=candidate,
        production_root=production,
        changed_paths=("app.py",),
        run_id="crashed-run",
    )

    assert (production / "app.py").read_text() == "VALUE = 2\n"
    assert receipt.backup_root.exists()

    recovered = service.recover_incomplete(production)

    assert recovered == ("crashed-run",)
    assert (production / "app.py").read_text() == "VALUE = 1\n"
    assert not receipt.backup_root.exists()


def test_existing_tests_are_immutable(tmp_path):
    source = tmp_path / "repo"
    source.mkdir()
    (source / "tests").mkdir()
    (source / "tests" / "test_existing.py").write_text("def test_existing():\n    assert True\n")

    service = CodeModificationService(workspaces=CandidateWorkspaceService())
    provider = Provider(CodeModification(
        candidate_id="candidate-test-integrity",
        changes=(CodeChange("tests/test_existing.py", "def test_existing():\n    assert False\n"),),
    ))
    with pytest.raises(ValueError, match="existing test modification forbidden"):
        service.generate_and_apply(
            request=CodeModificationRequest(
                candidate_id="candidate-test-integrity",
                objective="improve behavior",
                repository_root=source,
            ),
            provider=provider,
        )


def test_secret_material_is_rejected_inside_candidate(tmp_path):
    source = tmp_path / "repo"
    source.mkdir()
    service = CodeModificationService(workspaces=CandidateWorkspaceService())
    provider = Provider(CodeModification(
        candidate_id="candidate-secret",
        changes=(CodeChange("app.py", "TOKEN = 'OPENAI_API_KEY=secret'\n"),),
    ))
    with pytest.raises(ValueError, match="secret material"):
        service.generate_and_apply(
            request=CodeModificationRequest(
                candidate_id="candidate-secret",
                objective="improve behavior",
                repository_root=source,
            ),
            provider=provider,
        )


def test_autonomous_proposal_rejects_large_rewrite(tmp_path):
    source = tmp_path / "repo"
    source.mkdir()
    (source / "app.py").write_text("VALUE = 1\n")
    service = CodeModificationService(workspaces=CandidateWorkspaceService())
    provider = Provider(CodeModification(
        candidate_id="candidate-large",
        changes=(CodeChange("app.py", "x" * 80_001),),
    ))
    with pytest.raises(ValueError, match="too large"):
        service.generate_and_apply(
            request=CodeModificationRequest(
                candidate_id="candidate-large",
                objective="improve behavior",
                repository_root=source,
            ),
            provider=provider,
        )
