from types import SimpleNamespace

from ocean.kernel_invariants import (
    check_completion_requires_verification,
    check_event_sequence,
    check_no_active_assignments_after_stop,
    check_world_ownership,
)


def test_event_sequences_must_be_monotonic():
    assert check_event_sequence([SimpleNamespace(sequence=1), SimpleNamespace(sequence=2)]) == []
    assert check_event_sequence([SimpleNamespace(sequence=2), SimpleNamespace(sequence=2)])


def test_completion_requires_verification():
    assert check_completion_requires_verification({"state": "completed", "verification_state": "verified"}) == []
    assert check_completion_requires_verification({"state": "completed", "verification_state": "unknown"})


def test_stop_requires_no_active_assignments():
    assert check_no_active_assignments_after_stop([], True) == []
    assert check_no_active_assignments_after_stop([{"state": "running"}], True)


def test_world_ownership_rejects_cross_task_or_account_access():
    assert check_world_ownership({"task_id": "a", "account_id": "x"}, task_id="a", account_id="x") == []
    assert len(check_world_ownership({"task_id": "b", "account_id": "x"}, task_id="a", account_id="x")) == 1
    assert len(check_world_ownership({"task_id": "a", "account_id": "y"}, task_id="a", account_id="x")) == 1
