from datetime import datetime, timezone

from ocean.domain.agent import Agent
from ocean.domain.enums import AgentStatus
from persistence.serializers.agent import AgentSerializer


def test_agent_serializer_round_trip():
    created_at = datetime(2026, 1, 1, 10, 0, tzinfo=timezone.utc)
    updated_at = datetime(2026, 1, 1, 10, 5, tzinfo=timezone.utc)

    agent = Agent(
        name="Ocean Worker",
        role="general",
        capabilities={"filesystem.read", "browser.search"},
        metadata={
            "source": "test",
            "priority": 10,
        },
        id="agent-1",
        status=AgentStatus.RUNNING,
        current_task_id="task-1",
        created_at=created_at,
        updated_at=updated_at,
    )

    serializer = AgentSerializer()

    serialized = serializer.serialize(agent)
    restored = serializer.deserialize(serialized)

    assert restored == agent


def test_agent_serializer_sorts_capabilities():
    agent = Agent(
        name="Test Agent",
        role="tester",
        capabilities={"z-capability", "a-capability", "m-capability"},
        id="agent-2",
    )

    serializer = AgentSerializer()

    data = serializer.serialize(agent)

    assert data["capabilities"] == [
        "a-capability",
        "m-capability",
        "z-capability",
    ]


def test_agent_serializer_preserves_status_and_current_task():
    agent = Agent(
        name="Worker",
        role="worker",
        id="agent-3",
        status=AgentStatus.WAITING,
        current_task_id="task-42",
    )

    serializer = AgentSerializer()

    restored = serializer.deserialize(serializer.serialize(agent))

    assert restored.status == AgentStatus.WAITING
    assert restored.current_task_id == "task-42"
