from dataclasses import dataclass

import pytest

from ocean.execution.compiler import ExecutionPlan, ExecutionStep
from ocean.orchestration.execution_plan_runner import (
    ExecutionAgentResolver,
    ExecutionPlanRunner,
)
from ocean.orchestration.types import ExecutionIntent, OrchestrationMode


@dataclass
class FakeOrchestrationResult:
    success: bool
    assignment_id: str | None = None
    execution_id: str | None = None
    error: str | None = None


class FakeOrchestrator:
    def __init__(self):
        self.assignments = []
        self.dispatches = []

    def assign(self, request):
        assignment_id = f"assignment-{len(self.assignments) + 1}"
        self.assignments.append((assignment_id, request))
        return FakeOrchestrationResult(
            success=True,
            assignment_id=assignment_id,
        )

    def dispatch(
        self,
        assignment_id,
        intent,
        *,
        dependency_execution_ids=None,
    ):
        execution_id = f"execution-{len(self.dispatches) + 1}"
        self.dispatches.append(
            (
                assignment_id,
                intent,
                set(dependency_execution_ids or ()),
            )
        )
        return FakeOrchestrationResult(
            success=True,
            assignment_id=assignment_id,
            execution_id=execution_id,
        )


class FakeAgentResolver(ExecutionAgentResolver):
    def resolve(self, step):
        return f"agent-for-{step.node_id}"


def make_step(node_id, task_id, *dependencies):
    return ExecutionStep(
        node_id=node_id,
        task_id=task_id,
        intent=ExecutionIntent(
            capability="test",
            operation="run",
            arguments={"node": node_id},
        ),
        depends_on_node_ids=dependencies,
    )


def make_plan(*steps):
    return ExecutionPlan(
        mission_id="mission-1",
        plan_revision_id="plan-1",
        steps=steps,
    )


def test_runner_requires_orchestrator():
    with pytest.raises(ValueError, match="orchestrator is required"):
        ExecutionPlanRunner(None, FakeAgentResolver())


def test_runner_requires_agent_resolver():
    with pytest.raises(ValueError, match="agent_resolver is required"):
        ExecutionPlanRunner(FakeOrchestrator(), None)


def test_runner_rejects_missing_plan():
    runner = ExecutionPlanRunner(
        FakeOrchestrator(),
        FakeAgentResolver(),
    )

    with pytest.raises(ValueError, match="execution plan is required"):
        runner.start(None)


def test_runner_rejects_negative_priority():
    runner = ExecutionPlanRunner(
        FakeOrchestrator(),
        FakeAgentResolver(),
    )

    with pytest.raises(ValueError, match="priority must be non-negative"):
        runner.start(make_plan(make_step("node-a", "task-a")), priority=-1)


def test_runner_starts_initial_frontier():
    orchestrator = FakeOrchestrator()
    runner = ExecutionPlanRunner(
        orchestrator,
        FakeAgentResolver(),
    )

    result = runner.start(
        make_plan(
            make_step("node-a", "task-a"),
            make_step("node-b", "task-b"),
        )
    )

    assert result.success is True
    assert result.plan_revision_id == "plan-1"
    assert result.queued_node_ids == ("node-a", "node-b")
    assert result.blocked_node_ids == ()
    assert set(result.assignment_ids) == {"node-a", "node-b"}
    assert set(result.execution_ids) == {"node-a", "node-b"}
    assert len(orchestrator.assignments) == 2
    assert len(orchestrator.dispatches) == 2


def test_runner_does_not_start_dependent_frontier_until_dependency_is_completed():
    orchestrator = FakeOrchestrator()
    runner = ExecutionPlanRunner(
        orchestrator,
        FakeAgentResolver(),
    )

    plan = make_plan(
        make_step("node-a", "task-a"),
        make_step("node-b", "task-b", "node-a"),
    )

    first = runner.start(plan)

    assert first.queued_node_ids == ("node-a",)
    assert first.blocked_node_ids == ("node-b",)
    assert len(orchestrator.dispatches) == 1


def test_runner_starts_next_frontier_with_runtime_dependency_ids():
    orchestrator = FakeOrchestrator()
    runner = ExecutionPlanRunner(
        orchestrator,
        FakeAgentResolver(),
    )

    plan = make_plan(
        make_step("node-a", "task-a"),
        make_step("node-b", "task-b", "node-a"),
    )

    first = runner.start(plan)

    second = runner.start_frontier(
        plan,
        completed_node_ids={"node-a"},
        node_execution_ids={
            "node-a": first.execution_id_for("node-a"),
        },
    )

    assert second.success is True
    assert second.queued_node_ids == ("node-b",)
    assert second.execution_id_for("node-b") == "execution-2"

    assignment_id, _, dependencies = orchestrator.dispatches[1]

    assert assignment_id == second.assignment_id_for("node-b")
    assert dependencies == {"execution-1"}


def test_runner_supports_parallel_frontier():
    orchestrator = FakeOrchestrator()
    runner = ExecutionPlanRunner(
        orchestrator,
        FakeAgentResolver(),
    )

    plan = make_plan(
        make_step("node-a", "task-a"),
        make_step("node-b", "task-b", "node-a"),
        make_step("node-c", "task-c", "node-a"),
    )

    first = runner.start(plan)

    second = runner.start_frontier(
        plan,
        completed_node_ids={"node-a"},
        node_execution_ids={
            "node-a": first.execution_id_for("node-a"),
        },
        mode=OrchestrationMode.PARALLEL,
    )

    assert second.success is True
    assert second.queued_node_ids == ("node-b", "node-c")
    assert len(orchestrator.dispatches) == 3

    assert orchestrator.dispatches[1][2] == {"execution-1"}
    assert orchestrator.dispatches[2][2] == {"execution-1"}


def test_runner_rejects_missing_dependency_execution_id():
    orchestrator = FakeOrchestrator()
    runner = ExecutionPlanRunner(
        orchestrator,
        FakeAgentResolver(),
    )

    plan = make_plan(
        make_step("node-a", "task-a"),
        make_step("node-b", "task-b", "node-a"),
    )

    result = runner.start_frontier(
        plan,
        completed_node_ids={"node-a"},
        node_execution_ids={},
    )

    assert result.success is False
    assert "node-b" in result.errors
    assert "node-a" in result.errors["node-b"]
    assert orchestrator.dispatches == []


def test_runner_propagates_assignment_failure():
    class FailingOrchestrator(FakeOrchestrator):
        def assign(self, request):
            return FakeOrchestrationResult(
                success=False,
                error="admission denied",
            )

    runner = ExecutionPlanRunner(
        FailingOrchestrator(),
        FakeAgentResolver(),
    )

    result = runner.start(
        make_plan(make_step("node-a", "task-a"))
    )

    assert result.success is False
    assert result.errors["node-a"] == "admission denied"


def test_runner_propagates_dispatch_failure():
    class FailingOrchestrator(FakeOrchestrator):
        def dispatch(
            self,
            assignment_id,
            intent,
            *,
            dependency_execution_ids=None,
        ):
            return FakeOrchestrationResult(
                success=False,
                error="dispatch failed",
            )

    runner = ExecutionPlanRunner(
        FailingOrchestrator(),
        FakeAgentResolver(),
    )

    result = runner.start(
        make_plan(make_step("node-a", "task-a"))
    )

    assert result.success is False
    assert result.errors["node-a"] == "dispatch failed"


def test_runner_passes_plan_metadata_into_assignment():
    orchestrator = FakeOrchestrator()
    runner = ExecutionPlanRunner(
        orchestrator,
        FakeAgentResolver(),
    )

    result = runner.start(
        make_plan(make_step("node-a", "task-a"))
    )

    assert result.success is True

    _, request = orchestrator.assignments[0]

    assert request.task_id == "task-a"
    assert request.mission_id == "mission-1"
    assert request.metadata["execution_plan_id"] == "plan-1"
    assert request.metadata["execution_node_id"] == "node-a"


