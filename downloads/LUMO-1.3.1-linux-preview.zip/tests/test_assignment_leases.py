from datetime import datetime, timedelta, timezone

import pytest

from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.workforce import (
    AssignmentLeaseCoordinator,
    AssignmentLeaseState,
    StaleAssignmentLeaseError,
)


START = datetime(2026, 9, 7, tzinfo=timezone.utc)


class CancellationProbe:
    def __init__(self):
        self.calls = 0

    def cancel(self):
        self.calls += 1


def _acquire(coordinator, **overrides):
    values = {
        "assignment_id": "assignment-1",
        "agent_id": "agent-1",
        "attempt_id": "attempt-1",
        "execution_id": "execution-1",
        "lease_seconds": 10,
        "at": START,
    }
    values.update(overrides)
    return coordinator.acquire(**values)


def test_lease_acquire_heartbeat_release_and_idempotency():
    events = EventBus()
    coordinator = AssignmentLeaseCoordinator(event_bus=events)
    lease = _acquire(coordinator)

    heartbeat_at = START + timedelta(seconds=2)
    updated = coordinator.heartbeat(
        lease.lease_id,
        attempt_id="attempt-1",
        agent_id="agent-1",
        expires_at=START + timedelta(seconds=12),
        at=heartbeat_at,
    )
    duplicate = coordinator.heartbeat(
        lease.lease_id,
        attempt_id="attempt-1",
        agent_id="agent-1",
        expires_at=START + timedelta(seconds=12),
        at=heartbeat_at,
    )
    released = coordinator.release(
        lease.lease_id,
        attempt_id="attempt-1",
        agent_id="agent-1",
        at=START + timedelta(seconds=3),
    )

    assert updated.heartbeat_at == heartbeat_at
    assert duplicate.heartbeat_at == heartbeat_at
    assert released.state is AssignmentLeaseState.RELEASED
    assert coordinator.release(
        lease.lease_id,
        attempt_id="attempt-1",
        agent_id="agent-1",
    ).state is AssignmentLeaseState.RELEASED
    assert len(events.history("AssignmentLeaseHeartbeat")) == 1
    assert len(events.history("AssignmentLeaseReleased")) == 1


def test_expiry_cancels_execution_releases_reservation_and_rejects_stale_attempt():
    events = EventBus()
    cancellation = CancellationProbe()
    released_reservations = []
    failed_assignments = []
    coordinator = AssignmentLeaseCoordinator(
        event_bus=events,
        reservation_releaser=released_reservations.append,
        assignment_failure_handler=lambda assignment_id, reason: failed_assignments.append(
            (assignment_id, reason)
        ),
    )
    lease = _acquire(
        coordinator,
        execution_handle=cancellation,
        reservation_id="reservation-1",
        lease_seconds=1,
    )

    expired = coordinator.expire(
        lease.lease_id,
        attempt_id="attempt-1",
        agent_id="agent-1",
        at=START + timedelta(seconds=1),
    )

    assert expired.state is AssignmentLeaseState.EXPIRED
    assert cancellation.calls == 1
    assert released_reservations == ["reservation-1"]
    assert failed_assignments == [("assignment-1", "lease heartbeat expired")]
    assert coordinator.expire(
        lease.lease_id,
        attempt_id="attempt-1",
        agent_id="agent-1",
        at=START + timedelta(seconds=2),
    ).state is AssignmentLeaseState.EXPIRED
    assert cancellation.calls == 1
    assert len(events.history("AssignmentLeaseExpired")) == 1

    with pytest.raises(StaleAssignmentLeaseError):
        coordinator.heartbeat(
            lease.lease_id,
            attempt_id="attempt-1",
            agent_id="agent-1",
            at=START + timedelta(seconds=2),
        )


def test_replay_reconstructs_active_and_terminal_leases_without_side_effects():
    events = EventBus()
    original = AssignmentLeaseCoordinator(event_bus=events)
    active = _acquire(original, lease_id="lease-active", lease_seconds=100)
    expired = _acquire(
        original,
        assignment_id="assignment-2",
        agent_id="agent-2",
        attempt_id="attempt-2",
        execution_id="execution-2",
        lease_id="lease-expired",
        lease_seconds=1,
    )
    original.expire(
        expired.lease_id,
        attempt_id="attempt-2",
        agent_id="agent-2",
        at=START + timedelta(seconds=1),
    )

    cancellation = CancellationProbe()
    rebuilt = AssignmentLeaseCoordinator(event_bus=events)
    rebuilt.rebuild(events.history())

    assert rebuilt.get(active.lease_id).state is AssignmentLeaseState.ACTIVE
    assert rebuilt.get(expired.lease_id).state is AssignmentLeaseState.EXPIRED
    assert cancellation.calls == 0
    assert rebuilt.expire_due(at=START + timedelta(seconds=20)) == ()


def test_stale_attempt_cannot_complete_replacement_lease():
    events = EventBus()
    coordinator = AssignmentLeaseCoordinator(event_bus=events)
    old = _acquire(coordinator, lease_id="lease-old", lease_seconds=1)
    coordinator.expire(
        old.lease_id,
        attempt_id="attempt-1",
        agent_id="agent-1",
        at=START + timedelta(seconds=1),
    )
    coordinator.record_reassignment(
        source_lease_id=old.lease_id,
        replacement_assignment_id="assignment-2",
        replacement_agent_id="agent-2",
        replacement_attempt_id="attempt-2",
    )
    replacement = _acquire(
        coordinator,
        assignment_id="assignment-2",
        agent_id="agent-2",
        attempt_id="attempt-2",
        execution_id="execution-2",
        lease_id="lease-new",
    )

    assert coordinator.can_complete(
        old.lease_id,
        attempt_id="attempt-1",
        agent_id="agent-1",
    ) is False
    assert coordinator.can_complete(
        replacement.lease_id,
        attempt_id="attempt-2",
        agent_id="agent-2",
    ) is True
    with pytest.raises(StaleAssignmentLeaseError):
        coordinator.heartbeat(
            old.lease_id,
            attempt_id="attempt-1",
            agent_id="agent-1",
            at=START + timedelta(seconds=2),
        )


def test_assignment_terminal_events_release_active_lease():
    events = EventBus()
    coordinator = AssignmentLeaseCoordinator(event_bus=events)
    success = _acquire(coordinator, lease_id="lease-success")
    failure = _acquire(
        coordinator,
        assignment_id="assignment-2",
        agent_id="agent-2",
        attempt_id="attempt-2",
        execution_id="execution-2",
        lease_id="lease-failure",
    )

    events.publish(
        Event(
            type="TaskAssignmentCompleted",
            payload={
                "assignment_id": success.assignment_id,
                "execution_id": success.execution_id,
            },
            aggregate_type="assignment",
            aggregate_id=success.assignment_id,
        )
    )
    events.publish(
        Event(
            type="TaskAssignmentFailed",
            payload={
                "assignment_id": failure.assignment_id,
                "execution_id": failure.execution_id,
            },
            aggregate_type="assignment",
            aggregate_id=failure.assignment_id,
        )
    )

    assert coordinator.get(success.lease_id).state is AssignmentLeaseState.RELEASED
    assert coordinator.get(failure.lease_id).state is AssignmentLeaseState.RELEASED


def test_expire_due_is_deterministic_and_independent_across_missions():
    events = EventBus()
    coordinator = AssignmentLeaseCoordinator(event_bus=events)
    first = _acquire(coordinator, lease_id="lease-a", assignment_id="assignment-a")
    second = _acquire(
        coordinator,
        lease_id="lease-b",
        assignment_id="assignment-b",
        agent_id="agent-b",
        attempt_id="attempt-b",
    )

    expired = coordinator.expire_due(at=START + timedelta(seconds=10))

    assert [lease.lease_id for lease in expired] == ["lease-a", "lease-b"]
    assert coordinator.get(first.lease_id).state is AssignmentLeaseState.EXPIRED
    assert coordinator.get(second.lease_id).state is AssignmentLeaseState.EXPIRED
    assert len(events.history("AssignmentLeaseExpired")) == 2