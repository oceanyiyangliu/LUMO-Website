from ocean.authorization import (
    AuthorizationEngine,
    AuthorizationRequest,
    StaticAuthorizationPolicy,
)


def test_authorization_allows_when_all_permissions_are_granted():
    engine = AuthorizationEngine(
        StaticAuthorizationPolicy(
            {
                "principal_1": {
                    "repo.read",
                    "repo.write",
                }
            }
        )
    )

    decision = engine.authorize(
        AuthorizationRequest(
            principal_id="principal_1",
            capability="repository",
            operation="read",
            required_permissions=frozenset({"repo.read"}),
        )
    )

    assert decision.allowed
    assert not decision.denied
    assert decision.reasons == ()


def test_authorization_denies_missing_permission():
    engine = AuthorizationEngine(
        StaticAuthorizationPolicy(
            {
                "principal_1": {"repo.read"},
            }
        )
    )

    decision = engine.authorize(
        AuthorizationRequest(
            principal_id="principal_1",
            capability="repository",
            operation="write",
            required_permissions=frozenset({"repo.write"}),
        )
    )

    assert decision.denied
    assert "repo.write" in decision.reasons[0]


def test_unknown_principal_has_no_permissions():
    engine = AuthorizationEngine(StaticAuthorizationPolicy())

    decision = engine.authorize(
        AuthorizationRequest(
            principal_id="principal_missing",
            capability="repository",
            operation="read",
            required_permissions=frozenset({"repo.read"}),
        )
    )

    assert decision.denied


def test_no_required_permissions_is_allowed():
    engine = AuthorizationEngine(StaticAuthorizationPolicy())

    decision = engine.authorize(
        AuthorizationRequest(
            principal_id="principal_1",
            capability="local",
            operation="inspect",
        )
    )

    assert decision.allowed
