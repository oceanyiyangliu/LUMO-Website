import pytest

from ocean.core.errors import InvalidStateTransition
from ocean.domain.enums import ExecutionStatus
from ocean.domain.execution import Execution
from ocean.domain.verification import Verification


def test_execution_lifecycle_success():
    e = Execution(task_id="task_1", capability="applications", operation="open")
    e.start()
    assert e.status == ExecutionStatus.RUNNING
    assert e.started_at is not None
    e.succeed(result={"pid": 1234})
    assert e.status == ExecutionStatus.SUCCEEDED
    assert e.raw_result == {"pid": 1234}
    assert e.ended_at is not None


def test_execution_lifecycle_failure():
    e = Execution(task_id="task_1", capability="applications", operation="open")
    e.start()
    e.fail("process exited immediately")
    assert e.status == ExecutionStatus.FAILED
    assert e.error == "process exited immediately"


def test_cannot_succeed_without_starting():
    e = Execution(task_id="task_1", capability="applications", operation="open")
    with pytest.raises(InvalidStateTransition):
        e.succeed()


def test_cannot_start_twice():
    e = Execution(task_id="task_1", capability="applications", operation="open")
    e.start()
    with pytest.raises(InvalidStateTransition):
        e.start()


def test_execution_success_is_not_the_same_thing_as_task_success():
    """The core RULE 11 guarantee, demonstrated end-to-end: a successful
    Execution produces no Verification on its own. Something else -- a
    verifier agent, an observer -- has to look at the world and say so."""
    e = Execution(task_id="task_1", capability="applications", operation="open")
    e.start()
    e.succeed(result={"pid": 1234})

    # execution succeeding does NOT, by itself, produce a passing verification
    unverified = Verification(task_id="task_1", method="none", passed=False, evidence=["not yet checked"])
    assert not unverified.passed

    # only an explicit, evidence-carrying verification can mark the task done
    checked = Verification(
        task_id="task_1",
        method="accessibility_tree_check",
        passed=True,
        evidence=["Calculator window found in accessibility tree"],
        execution_id=e.id,
    )
    assert checked.passed
    assert "PASSED" in checked.explain()
