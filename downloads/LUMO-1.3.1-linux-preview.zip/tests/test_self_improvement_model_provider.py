import json

import pytest

from ocean.self_improvement.code_modification import CodeChange, CodeModification
from ocean.self_improvement.model_provider import (
    DeterministicModelProvider,
    ImprovementModelRequest,
    ImprovementModelProposal,
    ModelProviderBoundary,
)
from ocean.self_improvement.types import ImprovementHypothesis


def hypothesis(candidate_id="candidate-1"):
    return ImprovementHypothesis(
        objective="improve scheduler throughput",
        hypothesis="reduce unnecessary scheduler work",
        rationale="reduce unnecessary scheduler work",
        success_criteria=("lower latency",),
        constraints={"candidate_id": candidate_id},
    )


def modification(candidate_id="candidate-1"):
    return CodeModification(
        candidate_id=candidate_id,
        changes=(
            CodeChange(
                path="ocean/example.py",
                content="VALUE = 2\n",
            ),
        ),
        rationale="optimize implementation",
        metadata={
            "candidate_workspace": "/tmp/candidate",
            "source_repository": "/tmp/source",
            "production_mutation_forbidden": True,
        },
    )


def request(candidate_id="candidate-1"):
    return ImprovementModelRequest(
        candidate_id=candidate_id,
        objective="improve scheduler throughput",
        constraints=(
            "do not mutate production",
            "preserve public APIs",
        ),
        research_evidence=("scheduler profiling",),
        baseline_metrics={"latency_ms": 100.0},
    )


def test_model_request_validates_identity_and_objective():
    with pytest.raises(ValueError):
        ImprovementModelRequest(
            candidate_id="",
            objective="objective",
        )

    with pytest.raises(ValueError):
        ImprovementModelRequest(
            candidate_id="candidate-1",
            objective="",
        )

    with pytest.raises(ValueError):
        ImprovementModelRequest(
            candidate_id="candidate-1",
            objective="objective",
            constraints=("valid", ""),
        )


def test_deterministic_provider_produces_valid_proposal():
    provider = DeterministicModelProvider(
        hypothesis=hypothesis(),
        code_modification=modification(),
    )

    proposal = ModelProviderBoundary(provider).propose(request())

    assert proposal.candidate_id == "candidate-1"
    assert proposal.hypothesis.constraints["candidate_id"] == "candidate-1"
    assert proposal.code_modification.candidate_id == "candidate-1"
    assert proposal.rationale


def test_wrong_proposal_candidate_is_rejected():
    class Provider:
        def propose(self, request):
            return ImprovementModelProposal(
                candidate_id="candidate-2",
                hypothesis=hypothesis("candidate-2"),
                code_modification=modification("candidate-2"),
                rationale="invalid",
            )

    with pytest.raises(ValueError, match="different candidate"):
        ModelProviderBoundary(Provider()).propose(request())


def test_wrong_hypothesis_candidate_is_rejected():
    class Provider:
        def propose(self, request):
            return ImprovementModelProposal(
                candidate_id="candidate-1",
                hypothesis=hypothesis("candidate-2"),
                code_modification=modification(),
                rationale="invalid",
            )

    with pytest.raises(ValueError, match="hypothesis"):
        ModelProviderBoundary(Provider()).propose(request())


def test_wrong_code_modification_candidate_is_rejected():
    class Provider:
        def propose(self, request):
            return ImprovementModelProposal(
                candidate_id="candidate-1",
                hypothesis=hypothesis(),
                code_modification=modification("candidate-2"),
                rationale="invalid",
            )

    with pytest.raises(ValueError, match="code modification"):
        ModelProviderBoundary(Provider()).propose(request())


def test_empty_rationale_is_rejected():
    provider = DeterministicModelProvider(
        hypothesis=hypothesis(),
        code_modification=modification(),
        rationale=" ",
    )

    with pytest.raises(ValueError, match="rationale"):
        ModelProviderBoundary(provider).propose(request())


def test_empty_code_change_set_is_rejected():
    class Provider:
        def propose(self, request):
            return ImprovementModelProposal(
                candidate_id="candidate-1",
                hypothesis=hypothesis(),
                code_modification=CodeModification(
                    candidate_id="candidate-1",
                    changes=(),
                    rationale="nothing",
                    metadata={
                        "production_mutation_forbidden": True,
                    },
                ),
                rationale="valid",
            )

    with pytest.raises(ValueError, match="at least one"):
        ModelProviderBoundary(Provider()).propose(request())


def test_model_cannot_disable_production_protection():
    class Provider:
        def propose(self, request):
            return ImprovementModelProposal(
                candidate_id="candidate-1",
                hypothesis=hypothesis(),
                code_modification=CodeModification(
                    candidate_id="candidate-1",
                    changes=(
                        CodeChange(
                            path="ocean/example.py",
                            content="VALUE = 2\n",
                        ),
                    ),
                    rationale="unsafe",
                    metadata={
                        "production_mutation_forbidden": False,
                    },
                ),
                rationale="unsafe",
            )

    with pytest.raises(ValueError, match="production mutation"):
        ModelProviderBoundary(Provider()).propose(request())


def test_non_string_workspace_metadata_is_rejected():
    class Provider:
        def propose(self, request):
            return ImprovementModelProposal(
                candidate_id="candidate-1",
                hypothesis=hypothesis(),
                code_modification=CodeModification(
                    candidate_id="candidate-1",
                    changes=(
                        CodeChange(
                            path="ocean/example.py",
                            content="VALUE = 2\n",
                        ),
                    ),
                    rationale="invalid metadata",
                    metadata={
                        "candidate_workspace": 123,
                    },
                ),
                rationale="invalid",
            )

    with pytest.raises(ValueError, match="candidate_workspace"):
        ModelProviderBoundary(Provider()).propose(request())


def test_source_repository_metadata_must_be_string():
    class Provider:
        def propose(self, request):
            return ImprovementModelProposal(
                candidate_id="candidate-1",
                hypothesis=hypothesis(),
                code_modification=CodeModification(
                    candidate_id="candidate-1",
                    changes=(
                        CodeChange(
                            path="ocean/example.py",
                            content="VALUE = 2\n",
                        ),
                    ),
                    rationale="invalid metadata",
                    metadata={
                        "source_repository": 123,
                    },
                ),
                rationale="invalid",
            )

    with pytest.raises(ValueError, match="source_repository"):
        ModelProviderBoundary(Provider()).propose(request())


def test_model_request_can_carry_baseline_metrics():
    request_value = request()

    assert request_value.baseline_metrics == {
        "latency_ms": 100.0
    }


def test_boundary_preserves_provider_proposal_without_authority():
    provider = DeterministicModelProvider(
        hypothesis=hypothesis(),
        code_modification=modification(),
        rationale="proposal",
    )

    proposal = ModelProviderBoundary(provider).propose(request())

    assert proposal.rationale == "proposal"
    assert proposal.code_modification.changes[0].path == "ocean/example.py"


class _FakeResponse:
    def __init__(self, payload):
        self.output_text = json.dumps(payload)


class _FakeResponses:
    def __init__(self, payload):
        self.payload = payload
        self.calls = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        return _FakeResponse(self.payload)


class _FakeClient:
    def __init__(self, payload):
        self.responses = _FakeResponses(payload)
