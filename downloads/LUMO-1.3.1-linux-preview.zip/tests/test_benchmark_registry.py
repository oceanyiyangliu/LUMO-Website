import pytest
from ocean.self_improvement.benchmark_registry import *

def test_versioned_registry_is_immutable():
 r=BenchmarkRegistry(); s=BenchmarkSpec("core","1",("pytest",),("pass_rate",)); r.register(s); r.register(s); assert r.get("core","1")==s
 with pytest.raises(ValueError): r.register(BenchmarkSpec("core","1",("other",),("pass_rate",)))

def test_anti_gaming_gate():
 ok,errors=AntiGamingGate().validate({"a":1},{"a":2},("a",)); assert ok and not errors
 ok,errors=AntiGamingGate().validate({"a":1},{"b":2},("a",)); assert not ok
