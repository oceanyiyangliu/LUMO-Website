from pathlib import Path

from ocean.capabilities.filesystem import FilesystemExecutor, filesystem_spec
from runtime.types import ExecutionRequest


def test_filesystem_spec():
    spec = filesystem_spec()

    assert spec.name == "filesystem"
    assert set(spec.operations) == {"read_file", "list_directory", "file_exists", "search_files"}

    assert spec.execution_strategy == "deterministic_local"
    assert spec.requires_permissions == {"filesystem.read"}


def test_read_file(tmp_path: Path):
    path = tmp_path / "hello.txt"
    path.write_text("hello ocean", encoding="utf-8")

    request = ExecutionRequest(
        task_id="task-1",
        capability="filesystem",
        operation="read_file",
        agent_id="agent-1",
        arguments={"path": str(path)},
    )

    result = FilesystemExecutor().execute(request, None)

    assert result.success is True
    assert result.result["content"] == "hello ocean"
    assert result.result["path"] == str(path)


def test_list_directory(tmp_path: Path):
    (tmp_path / "a.txt").write_text("a", encoding="utf-8")
    (tmp_path / "b.txt").write_text("b", encoding="utf-8")

    request = ExecutionRequest(
        task_id="task-1",
        capability="filesystem",
        operation="list_directory",
        agent_id="agent-1",
        arguments={"path": str(tmp_path)},
    )

    result = FilesystemExecutor().execute(request, None)

    assert result.success is True
    assert [entry["name"] for entry in result.result["entries"]] == [
        "a.txt",
        "b.txt",
    ]


def test_read_missing_file_fails(tmp_path: Path):
    request = ExecutionRequest(
        task_id="task-1",
        capability="filesystem",
        operation="read_file",
        agent_id="agent-1",
        arguments={"path": str(tmp_path / "missing.txt")},
    )

    result = FilesystemExecutor().execute(request, None)

    assert result.success is False


def test_filesystem_read_through_execution_runtime(tmp_path: Path):
    from ocean.domain.capability import CapabilityRegistry
    from ocean.domain.policy import PolicyEngine
    from runtime import ExecutionRuntime, ExecutorRegistry

    capabilities = CapabilityRegistry()
    capabilities.register(filesystem_spec())

    executors = ExecutorRegistry()
    executors.register("deterministic_local", FilesystemExecutor())

    runtime = ExecutionRuntime(
        capabilities=capabilities,
        policy=PolicyEngine(),
        executors=executors,
    )

    path = tmp_path / "runtime.txt"
    path.write_text("hello through runtime", encoding="utf-8")

    request = ExecutionRequest(
        task_id="task-runtime",
        capability="filesystem",
        operation="read_file",
        agent_id="agent-runtime",
        arguments={"path": str(path)},
        execution_id="exec-runtime",
    )

    result = runtime.execute(request)

    assert result.success is True
    assert result.result["content"] == "hello through runtime"
    assert result.result["path"] == str(path)


def test_file_exists(tmp_path: Path):
    path = tmp_path / "exists.txt"
    path.write_text("hello", encoding="utf-8")

    request = ExecutionRequest(
        task_id="task-1",
        capability="filesystem",
        operation="file_exists",
        agent_id="agent-1",
        arguments={"path": str(path)},
    )

    result = FilesystemExecutor().execute(request, None)

    assert result.success is True
    assert result.result == {
        "path": str(path),
        "exists": True,
    }


def test_file_exists_returns_false_for_missing_path(tmp_path: Path):
    request = ExecutionRequest(
        task_id="task-1",
        capability="filesystem",
        operation="file_exists",
        agent_id="agent-1",
        arguments={"path": str(tmp_path / "missing.txt")},
    )

    result = FilesystemExecutor().execute(request, None)

    assert result.success is True
    assert result.result["exists"] is False

def test_search_files_recursively_finds_query(tmp_path: Path):
    nested = tmp_path / "src" / "nested"
    nested.mkdir(parents=True)
    (tmp_path / "top.txt").write_text("nothing here", encoding="utf-8")
    target = nested / "target.py"
    target.write_text("first line\nhello ocean\nthird line\n", encoding="utf-8")

    request = ExecutionRequest(
        task_id="task-search",
        capability="filesystem",
        operation="search_files",
        agent_id="agent-1",
        arguments={
            "path": str(tmp_path),
            "query": "hello ocean",
        },
    )

    result = FilesystemExecutor().execute(request, None)

    assert result.success is True
    assert result.result["matches"] == [
        {
            "path": str(target),
            "line": 2,
            "text": "hello ocean",
        }
    ]
    assert result.result["truncated"] is False


def test_search_files_respects_filename_pattern(tmp_path: Path):
    (tmp_path / "match.py").write_text("needle", encoding="utf-8")
    (tmp_path / "ignored.txt").write_text("needle", encoding="utf-8")

    request = ExecutionRequest(
        task_id="task-search",
        capability="filesystem",
        operation="search_files",
        agent_id="agent-1",
        arguments={
            "path": str(tmp_path),
            "query": "needle",
            "pattern": "*.py",
        },
    )

    result = FilesystemExecutor().execute(request, None)

    assert result.success is True
    assert len(result.result["matches"]) == 1
    assert result.result["matches"][0]["path"] == str(tmp_path / "match.py")


def test_search_files_respects_max_results(tmp_path: Path):
    for index in range(3):
        (tmp_path / f"{index}.txt").write_text("needle\n", encoding="utf-8")

    request = ExecutionRequest(
        task_id="task-search",
        capability="filesystem",
        operation="search_files",
        agent_id="agent-1",
        arguments={
            "path": str(tmp_path),
            "query": "needle",
            "max_results": 2,
        },
    )

    result = FilesystemExecutor().execute(request, None)

    assert result.success is True
    assert len(result.result["matches"]) == 2
    assert result.result["truncated"] is True

def test_filesystem_search_through_execution_runtime(tmp_path: Path):
    from ocean.domain.capability import CapabilityRegistry
    from ocean.domain.policy import PolicyEngine
    from runtime import ExecutionRuntime, ExecutorRegistry

    capabilities = CapabilityRegistry()
    capabilities.register(filesystem_spec())

    executors = ExecutorRegistry()
    executors.register("deterministic_local", FilesystemExecutor())

    runtime = ExecutionRuntime(
        capabilities=capabilities,
        policy=PolicyEngine(),
        executors=executors,
    )

    nested = tmp_path / "src"
    nested.mkdir()
    target = nested / "code.py"
    target.write_text("def ocean():\n    return 'autonomous'\n", encoding="utf-8")

    request = ExecutionRequest(
        task_id="task-search-runtime",
        capability="filesystem",
        operation="search_files",
        agent_id="agent-runtime",
        arguments={
            "path": str(tmp_path),
            "query": "autonomous",
            "pattern": "*.py",
        },
        execution_id="exec-search-runtime",
    )

    result = runtime.execute(request)

    assert result.success is True
    assert result.result["matches"] == [
        {
            "path": str(target),
            "line": 2,
            "text": "    return 'autonomous'",
        }
    ]
    assert result.result["truncated"] is False

def test_search_files_requires_query(tmp_path: Path):
    request = ExecutionRequest(
        task_id="task-search",
        capability="filesystem",
        operation="search_files",
        agent_id="agent-1",
        arguments={"path": str(tmp_path)},
    )

    result = FilesystemExecutor().execute(request, None)

    assert result.success is False
    assert result.error == "query must be a non-empty string"


def test_search_files_rejects_invalid_max_results(tmp_path: Path):
    request = ExecutionRequest(
        task_id="task-search",
        capability="filesystem",
        operation="search_files",
        agent_id="agent-1",
        arguments={
            "path": str(tmp_path),
            "query": "needle",
            "max_results": 0,
        },
    )

    result = FilesystemExecutor().execute(request, None)

    assert result.success is False
    assert result.error == "max_results must be a positive integer"


def test_search_files_rejects_missing_root(tmp_path: Path):
    missing = tmp_path / "missing"

    request = ExecutionRequest(
        task_id="task-search",
        capability="filesystem",
        operation="search_files",
        agent_id="agent-1",
        arguments={
            "path": str(missing),
            "query": "needle",
        },
    )

    result = FilesystemExecutor().execute(request, None)

    assert result.success is False
    assert result.error == f"path does not exist: {missing}"
