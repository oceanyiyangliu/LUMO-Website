import threading
import time

import pytest

from runtime import (
    ExecutionRequest,
    ExecutionResult,
    ExecutionSupervisor,
    Scheduler,
    ScheduledExecution,
    SchedulingState,
)
from runtime.executor import CapabilityExecutor
from runtime.resources import ExecutionResourceLimits
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.domain.enums import OrchestrationMode


class SuccessfulExecutor(CapabilityExecutor):
    def execute(self, request, context):
        return ExecutionResult.succeeded(
            {"execution_id": request.execution_id}
        )


class FailingExecutor(CapabilityExecutor):
    def execute(self, request, context):
        return ExecutionResult.failed("controlled failure")


class BlockingExecutor(CapabilityExecutor):
    def __init__(self):
        self.started = threading.Event()
        self.release = threading.Event()

    def execute(self, request, context):
        self.started.set()

        while not self.release.wait(timeout=0.01):
            context.check()

        return ExecutionResult.succeeded("done")


def make_runtime(executor):
    from tests.test_runtime import make_runtime as build_runtime

    return build_runtime(executor)


def make_request(execution_id=None, *, agent_id=None):
    return ExecutionRequest(
        task_id="task-1",
        capability="test",
        operation="run",
        execution_id=execution_id,
        agent_id=agent_id,
    )


def make_supervisor(executor, max_workers=4):
    return ExecutionSupervisor(
        make_runtime(executor),
        max_workers=max_workers,
    )


def test_scheduler_generates_execution_id():
    supervisor = make_supervisor(SuccessfulExecutor())
    scheduler = Scheduler(supervisor)

    try:
        item = scheduler.enqueue(make_request())

        assert item.execution_id is not None
        assert item.request.execution_id == item.execution_id
    finally:
        supervisor.shutdown()



def test_scheduler_restores_durable_queue_with_resource_limits_and_terminal_state():
    supervisor = make_supervisor(SuccessfulExecutor())
    bus = EventBus()
    first = Scheduler(supervisor, event_bus=bus)
    limits = ExecutionResourceLimits(
        timeout_seconds=12.5,
        memory_bytes=64_000_000,
        cpu_seconds=7.25,
        max_output_bytes=32_000,
        max_worker_lifetime_seconds=30.0,
    )
    request = ExecutionRequest(
        task_id="task-durable",
        capability="test",
        operation="run",
        execution_id="exec-durable",
        mode=OrchestrationMode.BACKGROUND,
        resource_limits=limits,
    )

    try:
        item = first.enqueue(request, priority=7, dependencies={"exec-prerequisite"})
        bus.publish(Event(
            type="ScheduledExecutionCompleted",
            payload={"id": item.execution_id},
            aggregate_type="scheduled_execution",
            aggregate_id=item.execution_id,
        ))

        restored = Scheduler(supervisor, event_bus=bus)
        recovered = restored.get("exec-durable")

        assert recovered is not None
        assert recovered.state == SchedulingState.COMPLETED
        assert recovered.priority == 7
        assert recovered.dependencies == {"exec-prerequisite"}
        assert recovered.request.mode.value == "background"
        assert recovered.request.resource_limits == limits
        assert restored._sequence == 1
        assert "exec-durable" in restored._completed
    finally:
        supervisor.shutdown()

def test_scheduler_enqueues_execution():
    supervisor = make_supervisor(SuccessfulExecutor())
    scheduler = Scheduler(supervisor)

    try:
        item = scheduler.enqueue(make_request("exec-1"))

        assert isinstance(item, ScheduledExecution)
        assert item.execution_id == "exec-1"
        assert item.state == SchedulingState.QUEUED
        assert scheduler.get("exec-1") is item
    finally:
        supervisor.shutdown()


def test_eligibility_is_derived_and_does_not_mutate_state():
    supervisor = make_supervisor(SuccessfulExecutor())
    scheduler = Scheduler(supervisor)

    try:
        scheduler.enqueue(
            make_request("exec-1"),
            priority=10,
        )

        eligible = scheduler.eligible()

        assert [item.execution_id for item in eligible] == ["exec-1"]
        assert scheduler.get("exec-1").state == SchedulingState.QUEUED

        dispatched = scheduler.dispatch_next()

        assert dispatched is not None
        assert dispatched.execution_id == "exec-1"
        assert dispatched.state == SchedulingState.DISPATCHED
    finally:
        supervisor.shutdown()


def test_scheduler_orders_by_priority():
    supervisor = make_supervisor(SuccessfulExecutor())
    scheduler = Scheduler(supervisor)

    try:
        scheduler.enqueue(make_request("low"), priority=1)
        scheduler.enqueue(make_request("high"), priority=10)
        scheduler.enqueue(make_request("medium"), priority=5)

        eligible = scheduler.eligible()

        assert [item.execution_id for item in eligible] == [
            "high",
            "medium",
            "low",
        ]
    finally:
        supervisor.shutdown()


def test_scheduler_uses_enqueue_sequence_as_deterministic_tiebreaker():
    supervisor = make_supervisor(SuccessfulExecutor())
    scheduler = Scheduler(supervisor)

    try:
        scheduler.enqueue(make_request("first"), priority=5)
        scheduler.enqueue(make_request("second"), priority=5)

        eligible = scheduler.eligible()

        assert [item.execution_id for item in eligible] == [
            "first",
            "second",
        ]
    finally:
        supervisor.shutdown()


def test_scheduler_respects_dependencies():
    supervisor = make_supervisor(SuccessfulExecutor())
    scheduler = Scheduler(supervisor)

    try:
        scheduler.enqueue(make_request("first"))
        scheduler.enqueue(
            make_request("second"),
            dependencies={"first"},
        )

        eligible = scheduler.eligible()

        assert [item.execution_id for item in eligible] == ["first"]
    finally:
        supervisor.shutdown()


def test_scheduler_unlocks_dependency_after_completion():
    supervisor = make_supervisor(SuccessfulExecutor())
    scheduler = Scheduler(supervisor)

    try:
        scheduler.enqueue(make_request("first"))
        scheduler.enqueue(
            make_request("second"),
            dependencies={"first"},
        )

        first = scheduler.dispatch_next()

        assert first is not None
        assert first.execution_id == "first"

        future = supervisor.future("first")
        assert future is not None
        result = future.result(timeout=2)
        assert result.success is True

        scheduler.reconcile("first")

        second = scheduler.dispatch_next()

        assert second is not None
        assert second.execution_id == "second"
    finally:
        supervisor.shutdown()


def test_scheduler_serializes_work_per_agent_while_preserving_global_concurrency():
    executor = BlockingExecutor()
    supervisor = make_supervisor(executor, max_workers=2)
    scheduler = Scheduler(supervisor, max_concurrent=2)

    try:
        first = scheduler.enqueue(
            make_request("agent-1-exec", agent_id="agent-1"),
        )
        second = scheduler.enqueue(
            make_request("agent-1-exec-2", agent_id="agent-1"),
        )
        third = scheduler.enqueue(
            make_request("agent-2-exec", agent_id="agent-2"),
        )

        dispatched = scheduler.dispatch_available()

        assert [item.execution_id for item in dispatched] == [
            "agent-1-exec",
            "agent-2-exec",
        ]
        assert scheduler.dispatch_next() is None
        assert second.state is SchedulingState.QUEUED
        assert second not in scheduler.eligible()
    finally:
        executor.release.set()
        supervisor.shutdown()


def test_scheduler_enforces_concurrency_limit():
    executor = BlockingExecutor()
    supervisor = make_supervisor(executor, max_workers=2)
    scheduler = Scheduler(
        supervisor,
        max_concurrent=1,
    )

    try:
        scheduler.enqueue(make_request("first"))
        scheduler.enqueue(make_request("second"))

        first = scheduler.dispatch_next()

        assert first is not None
        assert scheduler.running == 1
        assert scheduler.dispatch_next() is None

        assert executor.started.wait(timeout=2)

        executor.release.set()

        future = supervisor.future("first")
        assert future is not None
        result = future.result(timeout=2)
        assert result.success is True

        scheduler.reconcile("first")

        second = scheduler.dispatch_next()

        assert second is not None
        assert second.execution_id == "second"
    finally:
        executor.release.set()
        supervisor.shutdown()


def test_scheduler_cancels_queued_execution():
    supervisor = make_supervisor(SuccessfulExecutor())
    scheduler = Scheduler(supervisor)

    try:
        scheduler.enqueue(make_request("exec-1"))

        assert scheduler.cancel("exec-1") is True

        item = scheduler.get("exec-1")

        assert item is not None
        assert item.state == SchedulingState.CANCELLED
        assert scheduler.dispatch_next() is None
    finally:
        supervisor.shutdown()


def test_scheduler_rejects_cancelling_dispatched_execution():
    executor = BlockingExecutor()
    supervisor = make_supervisor(executor)
    scheduler = Scheduler(supervisor)

    try:
        scheduler.enqueue(make_request("exec-1"))
        item = scheduler.dispatch_next()

        assert item is not None
        assert executor.started.wait(timeout=2)

        with pytest.raises(ValueError):
            scheduler.cancel("exec-1")
    finally:
        executor.release.set()
        supervisor.shutdown()


def test_scheduler_reprioritises_queued_execution():
    supervisor = make_supervisor(SuccessfulExecutor())
    scheduler = Scheduler(supervisor)

    try:
        scheduler.enqueue(
            make_request("low"),
            priority=1,
        )
        scheduler.enqueue(
            make_request("other"),
            priority=5,
        )

        scheduler.reprioritize("low", 10)

        assert scheduler.dispatch_next().execution_id == "low"
    finally:
        supervisor.shutdown()


def test_scheduler_rejects_negative_priority():
    supervisor = make_supervisor(SuccessfulExecutor())
    scheduler = Scheduler(supervisor)

    try:
        with pytest.raises(ValueError):
            scheduler.enqueue(
                make_request("exec-1"),
                priority=-1,
            )
    finally:
        supervisor.shutdown()


def test_scheduler_rejects_duplicate_execution_id():
    supervisor = make_supervisor(SuccessfulExecutor())
    scheduler = Scheduler(supervisor)

    try:
        scheduler.enqueue(make_request("exec-1"))

        with pytest.raises(ValueError):
            scheduler.enqueue(make_request("exec-1"))
    finally:
        supervisor.shutdown()


def test_scheduler_rejects_self_dependency():
    supervisor = make_supervisor(SuccessfulExecutor())
    scheduler = Scheduler(supervisor)

    try:
        with pytest.raises(ValueError):
            scheduler.enqueue(
                make_request("exec-1"),
                dependencies={"exec-1"},
            )
    finally:
        supervisor.shutdown()


def test_scheduler_dispatches_through_supervisor():
    executor = BlockingExecutor()
    supervisor = make_supervisor(executor)
    scheduler = Scheduler(supervisor)

    try:
        item = scheduler.enqueue(make_request("exec-1"))
        dispatched = scheduler.dispatch_next()

        assert dispatched is item
        assert item.handle is not None
        assert executor.started.wait(timeout=2)
        assert supervisor.active_executions.get("exec-1") is item.handle
    finally:
        executor.release.set()
        supervisor.shutdown()


def test_scheduler_reconciles_success():
    supervisor = make_supervisor(SuccessfulExecutor())
    scheduler = Scheduler(supervisor)

    try:
        scheduler.enqueue(make_request("exec-1"))
        item = scheduler.dispatch_next()

        assert item is not None

        future = supervisor.future("exec-1")
        assert future is not None
        result = future.result(timeout=2)

        assert result.success is True

        scheduler.reconcile("exec-1")

        assert item.state == SchedulingState.COMPLETED
        assert scheduler.running == 0
    finally:
        supervisor.shutdown()


def test_scheduler_reconciles_failure():
    supervisor = make_supervisor(FailingExecutor())
    scheduler = Scheduler(supervisor)

    try:
        scheduler.enqueue(make_request("exec-1"))
        item = scheduler.dispatch_next()

        assert item is not None

        future = supervisor.future("exec-1")
        assert future is not None
        result = future.result(timeout=2)

        assert result.success is False
        assert result.error == "controlled failure"

        scheduler.reconcile("exec-1")

        assert item.state == SchedulingState.FAILED
        assert scheduler.running == 0
    finally:
        supervisor.shutdown()


def test_scheduler_rejects_reconciling_incomplete_execution():
    executor = BlockingExecutor()
    supervisor = make_supervisor(executor)
    scheduler = Scheduler(supervisor)

    try:
        scheduler.enqueue(make_request("exec-1"))
        scheduler.dispatch_next()

        assert executor.started.wait(timeout=2)

        with pytest.raises(RuntimeError):
            scheduler.reconcile("exec-1")
    finally:
        executor.release.set()
        supervisor.shutdown()


def test_scheduler_aging_prevents_permanent_starvation():
    supervisor = make_supervisor(SuccessfulExecutor())
    scheduler = Scheduler(
        supervisor,
        aging_interval=2,
    )

    try:
        scheduler.enqueue(
            make_request("old"),
            priority=0,
        )
        scheduler.enqueue(
            make_request("new-1"),
            priority=1,
        )
        scheduler.enqueue(
            make_request("new-2"),
            priority=1,
        )

        eligible = scheduler.eligible()

        assert eligible[0].execution_id == "old"
    finally:
        supervisor.shutdown()


def test_scheduler_emits_events():
    from ocean.domain.event_bus import EventBus

    supervisor = make_supervisor(SuccessfulExecutor())
    event_bus = EventBus()
    scheduler = Scheduler(
        supervisor,
        event_bus=event_bus,
    )

    try:
        scheduler.enqueue(make_request("exec-1"))

        events = event_bus.history()

        assert [event.type for event in events] == [
            "ScheduledExecutionQueued",
        ]
    finally:
        supervisor.shutdown()


def test_scheduler_background_mode_dispatches():
    supervisor = make_supervisor(SuccessfulExecutor())
    scheduler = Scheduler(supervisor)

    try:
        scheduler.enqueue(make_request("exec-1"))
        scheduler.start()

        deadline = time.monotonic() + 2

        while time.monotonic() < deadline:
            item = scheduler.get("exec-1")

            if item is not None and item.state == SchedulingState.COMPLETED:
                break

            time.sleep(0.01)

        item = scheduler.get("exec-1")

        assert item is not None
        assert item.state == SchedulingState.COMPLETED
    finally:
        scheduler.stop()
        supervisor.shutdown()


def test_scheduler_start_is_idempotent():
    supervisor = make_supervisor(SuccessfulExecutor())
    scheduler = Scheduler(supervisor)

    try:
        scheduler.start()
        first = scheduler._worker

        scheduler.start()
        second = scheduler._worker

        assert first is second
    finally:
        scheduler.stop()
        supervisor.shutdown()


def test_scheduler_stop_is_idempotent():
    supervisor = make_supervisor(SuccessfulExecutor())
    scheduler = Scheduler(supervisor)

    scheduler.start()
    scheduler.stop()
    scheduler.stop()

    supervisor.shutdown()


def test_restore_is_idempotent_and_preserves_reprioritization(tmp_path):
    from ocean.domain.event import Event
    from ocean.domain.event_bus import EventBus
    from runtime.scheduler import Scheduler, SchedulingState
    from runtime.types import ExecutionRequest

    bus = EventBus()
    supervisor = make_supervisor(SuccessfulExecutor())
    scheduler = Scheduler(supervisor, event_bus=bus)
    request = ExecutionRequest(task_id="t", capability="cap", operation="op", execution_id="exec-restore")
    scheduler.enqueue(request, priority=2, dependencies={"dep"})
    scheduler.reprioritize("exec-restore", 5)
    bus.publish(Event(type="ScheduledExecutionCompleted", aggregate_type="scheduled_execution", aggregate_id="dep", payload={"id":"dep"}))
    scheduler.restore_from_events()
    scheduler.restore_from_events()
    item = scheduler.get("exec-restore")
    assert item is not None
    assert item.priority == 5
    assert item.state is SchedulingState.QUEUED
    assert scheduler._sequence == 1
    assert scheduler.dependencies_satisfied(item)
    supervisor.shutdown()


def test_restore_requeues_dispatched_execution_after_restart():
    from ocean.domain.event import Event
    from ocean.domain.event_bus import EventBus
    from runtime.scheduler import Scheduler, SchedulingState
    from runtime.types import ExecutionRequest

    bus = EventBus()
    supervisor = make_supervisor(SuccessfulExecutor())
    request = ExecutionRequest(
        task_id="restart-task",
        capability="cap",
        operation="op",
        execution_id="exec-restart",
        mission_id="mission-restart",
    )
    bus.publish(Event(
        type="ScheduledExecutionQueued",
        aggregate_type="scheduled_execution",
        aggregate_id="exec-restart",
        payload={
            "id": "exec-restart",
            "task_id": "restart-task",
            "capability": "cap",
            "operation": "op",
            "agent_id": None,
            "principal_id": None,
            "mission_id": "mission-restart",
            "mode": "standard",
            "arguments": {},
            "priority": 3,
            "enqueue_sequence": 1,
            "dependencies": [],
            "resource_limits": {},
        },
    ))
    bus.publish(Event(
        type="ScheduledExecutionDispatched",
        aggregate_type="scheduled_execution",
        aggregate_id="exec-restart",
        payload={"id": "exec-restart", "state": "dispatched"},
    ))

    scheduler = Scheduler(supervisor, event_bus=bus)
    item = scheduler.get("exec-restart")
    assert item is not None
    assert item.state is SchedulingState.QUEUED
    assert scheduler.running == 0
    assert scheduler.dispatch_next() is item
    assert item.state is SchedulingState.DISPATCHED
    scheduler.stop()
    supervisor.shutdown()
