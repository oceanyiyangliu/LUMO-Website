
from pathlib import Path

import pytest

from ocean.self_improvement.coordinator import (
    AutonomousImprovementCoordinator,
    AutonomousImprovementRequest,
)
from ocean.self_improvement.types import ImprovementHypothesis


def test_coordinator_module_imports():
    assert AutonomousImprovementCoordinator is not None
    assert AutonomousImprovementRequest is not None


def test_request_rejects_empty_mission():
    with pytest.raises(ValueError, match="mission_id"):
        AutonomousImprovementRequest(
            mission_id="",
            objective="improve scheduler",
            hypothesis=ImprovementHypothesis(
                objective="improve scheduler",
                hypothesis="reduce overhead",
                rationale="reduce overhead",
            ),
            planner=None,
            model_provider=None,
            research_provider=None,
            benchmark_provider=None,
            repository_root=Path("."),
            baseline_root=Path("."),
        )


def test_request_rejects_empty_objective():
    with pytest.raises(ValueError, match="objective"):
        AutonomousImprovementRequest(
            mission_id="mission-1",
            objective="",
            hypothesis=ImprovementHypothesis(
                objective="improve scheduler",
                hypothesis="reduce overhead",
                rationale="reduce overhead",
            ),
            planner=None,
            model_provider=None,
            research_provider=None,
            benchmark_provider=None,
            repository_root=Path("."),
            baseline_root=Path("."),
        )


def test_request_rejects_missing_repository(tmp_path):
    missing = tmp_path / "missing"

    with pytest.raises(ValueError, match="repository_root"):
        AutonomousImprovementCoordinator._validate_request(
            AutonomousImprovementRequest(
                mission_id="mission-1",
                objective="improve scheduler",
                hypothesis=ImprovementHypothesis(
                    objective="improve scheduler",
                    hypothesis="reduce overhead",
                    rationale="reduce overhead",
                ),
                planner=None,
                model_provider=None,
                research_provider=None,
                benchmark_provider=None,
                repository_root=missing,
                baseline_root=tmp_path,
            )
        )


def test_candidate_task_mapping_requires_mapping():
    candidate = type(
        "Candidate",
        (),
        {
            "metadata": {},
        },
    )()

    with pytest.raises(ValueError, match="isolated task mapping"):
        AutonomousImprovementCoordinator._candidate_task_for_verification(
            candidate
        )


def test_candidate_task_mapping_extracts_candidate_task():
    candidate = type(
        "Candidate",
        (),
        {
            "metadata": {
                "candidate_task_mappings": [
                    {
                        "source_task_id": "task-1",
                        "candidate_task_id": "candidate-task-1",
                    }
                ]
            }
        },
    )()

    assert (
        AutonomousImprovementCoordinator._candidate_task_for_verification(
            candidate
        )
        == "candidate-task-1"
    )


def test_test_evidence_contains_execution_state():
    result = type(
        "Result",
        (),
        {
            "passed": True,
            "exit_code": 0,
            "timed_out": False,
            "duration_seconds": 0.25,
            "stdout": "all good",
            "stderr": "",
        },
    )()

    evidence = AutonomousImprovementCoordinator._test_evidence(result)

    assert "candidate tests passed=True" in evidence
    assert "exit_code=0" in evidence
    assert "stdout=all good" in evidence


class _CoordinatorPlanner:
    def plan(self, request):
        from ocean.domain.decision import Decision
        from ocean.planning.planner import PlanningResult

        return PlanningResult(
            decision=Decision(
                mission_id=request.mission_id,
                kind="improvement",
                objective=request.objective,
                rationale="coordinator integration test",
            ),
            nodes=(),
            edges=(),
            metadata={"coordinator_integration_test": True},
        )


class _CoordinatorResearchProvider:
    def research(self, request):
        from ocean.self_improvement.research import (
            ResearchFinding,
            ResearchReport,
            ResearchSource,
        )

        return ResearchReport(
            candidate_id=request.candidate_id,
            findings=(
                ResearchFinding(
                    candidate_id=request.candidate_id,
                    claim="candidate change should reduce unnecessary work",
                    source=ResearchSource(
                        title="Coordinator test source",
                        uri="test://coordinator",
                        source_type="test",
                        publisher="Ocean",
                    ),
                    confidence=1.0,
                    evidence=("coordinator integration evidence",),
                ),
            ),
            queries=request.queries,
        )


class _CoordinatorModelProvider:
    def propose(self, request):
        from ocean.self_improvement.code_modification import (
            CodeChange,
            CodeModification,
        )
        from ocean.self_improvement.types import ImprovementHypothesis
        from ocean.self_improvement.model_provider import ImprovementModelProposal

        hypothesis = ImprovementHypothesis(
            objective=request.objective,
            hypothesis="replace the candidate marker with an improved value",
            rationale="coordinator integration test",
            success_criteria=("candidate tests pass",),
            constraints={"candidate_id": request.candidate_id},
        )

        return ImprovementModelProposal(
            candidate_id=request.candidate_id,
            hypothesis=hypothesis,
            code_modification=CodeModification(
                candidate_id=request.candidate_id,
                changes=(
                    CodeChange(
                        path="candidate_marker.txt",
                        content="improved\n",
                    ),
                ),
                rationale="coordinator integration test modification",
            ),
            rationale="coordinator integration test proposal",
        )


class _CoordinatorBenchmarkProvider:
    def benchmark(self, request):
        from ocean.self_improvement.benchmark import (
            BenchmarkReport,
            BenchmarkResult,
        )

        is_baseline = request.workspace_root == request.baseline_root

        return BenchmarkReport(
            candidate_id=request.candidate_id,
            results=(
                BenchmarkResult(
                    name="quality",
                    value=1.0 if is_baseline else 2.0,
                    unit="score",
                    higher_is_better=True,
                ),
            ),
        )


def test_coordinator_runs_end_to_end_through_promotion(tmp_path):
    from ocean.domain.event_bus import EventBus
    from ocean.domain.mission import Mission
    from ocean.domain.task import Task
    from ocean.domain.work_graph import WorkNode, WorkNodeKind
    from ocean.planning.service import PlanningService
    from ocean.self_improvement.benchmark import BenchmarkService
    from ocean.self_improvement.code_modification import (
        CandidateWorkspaceService,
        CodeModificationService,
    )
    from ocean.self_improvement.coordinator import (
        AutonomousImprovementCoordinator,
        AutonomousImprovementRequest,
    )
    from ocean.self_improvement.decision import ImprovementDecisionService
    from ocean.self_improvement.engine import SelfImprovementEngine
    from ocean.self_improvement.model_provider import ModelProviderBoundary
    from ocean.self_improvement.research import ResearchService
    from ocean.self_improvement.test_execution import CandidateTestExecutionService
    from ocean.self_improvement.verification import CandidateVerificationService
    from persistence.in_memory import InMemoryRepository

    events = EventBus()

    missions = InMemoryRepository()
    decisions = InMemoryRepository()
    tasks = InMemoryRepository()
    work_graphs = InMemoryRepository()
    plans = InMemoryRepository()
    runs = InMemoryRepository()
    verifications = InMemoryRepository()
    findings = InMemoryRepository()

    planning = PlanningService(
        missions=missions,
        decisions=decisions,
        tasks=tasks,
        work_graphs=work_graphs,
        plan_revisions=plans,
        events=events,
    )

    mission = Mission(goal="coordinator integration")
    missions.save(mission)

    source_decision = planning.create_decision(
        mission_id=mission.id,
        kind="baseline",
        objective="improve coordinator integration",
        rationale="baseline",
    )

    task = Task(
        title="coordinator integration task",
        mission_id=mission.id,
    )
    tasks.save(task)
    mission.add_task(task.id)
    missions.save(mission)

    source_plan, _ = planning.create_plan(
        mission_id=mission.id,
        decision_id=source_decision.id,
        nodes=(WorkNode(kind=WorkNodeKind.TASK, task_id=task.id),),
    )
    source_plan = planning.propose(source_plan.id, reason="baseline")
    source_plan = planning.activate(source_plan.id, reason="baseline")

    repository_root = tmp_path / "repository"
    repository_root.mkdir()
    marker = repository_root / "candidate_marker.txt"
    marker.write_text("baseline\n")
    baseline_root = repository_root

    research = ResearchService(
        findings=findings,
        events=events,
    )

    verification = CandidateVerificationService(
        verifications=verifications,
        events=events,
    )

    engine = SelfImprovementEngine(
        missions=missions,
        plan_revisions=plans,
        runs=runs,
        planning=planning,
        events=events,
        decisions=decisions,
        work_graphs=work_graphs,
        verifications=verifications,
    )

    code_modification = CodeModificationService(
        workspaces=CandidateWorkspaceService(),
    )

    coordinator = AutonomousImprovementCoordinator(
        engine=engine,
        research=research,
        model=ModelProviderBoundary(provider=_CoordinatorModelProvider()),
        code_modification=code_modification,
        test_execution=CandidateTestExecutionService(),
        verification=verification,
        benchmark=BenchmarkService(),
        decision=ImprovementDecisionService(),
        events=events,
    )

    request = AutonomousImprovementRequest(
        mission_id=mission.id,
        objective="improve coordinator integration",
        hypothesis=ImprovementHypothesis(
            objective="improve coordinator integration",
            hypothesis="replace the baseline marker with an improved value",
            rationale="integration test",
            success_criteria=("candidate tests pass",),
        ),
        planner=_CoordinatorPlanner(),
        model_provider=_CoordinatorModelProvider(),
        research_provider=_CoordinatorResearchProvider(),
        benchmark_provider=_CoordinatorBenchmarkProvider(),
        repository_root=repository_root,
        baseline_root=baseline_root,
        test_command=(
            "python",
            "-c",
            "from pathlib import Path; assert Path('candidate_marker.txt').read_text() == 'improved\\n'",
        ),
    )

    result = coordinator.run(request)

    assert result.status == "promoted"
    assert result.candidate_tests_passed is True
    assert result.decision is not None
    assert result.decision.passed is True
    assert result.benchmark is not None
    assert result.benchmark.passed is True
    assert result.promoted_plan_revision_id is not None
    assert marker.read_text() == "baseline\n"
    assert not Path(result.workspace_root).exists()

    promoted_run = [
        run for run in runs.list()
        if run.id == result.run_id
    ][0]
    assert promoted_run.status.value == "promoted"
    assert promoted_run.promoted_plan_revision_id == result.promoted_plan_revision_id
    assert promoted_run.metadata["recovery_checkpoint"]["phase"] == "promoted"

    checkpoint_phases = [
        event.payload["phase"]
        for event in events.history("ImprovementCheckpointCreated")
        if event.payload["run_id"] == result.run_id
    ]
    assert checkpoint_phases == [
        "candidate_created",
        "modification_applied",
        "test_completed",
        "verification_recorded",
        "decision_recorded",
        "promoted",
    ]


def test_coordinator_candidate_test_failure_diagnostics_are_durable(tmp_path):
    from ocean.domain.mission import Mission
    from ocean.domain.task import Task
    from ocean.domain.work_graph import WorkNode, WorkNodeKind
    from ocean.domain.event_bus import EventBus
    from ocean.planning.service import PlanningService
    from ocean.self_improvement.benchmark import BenchmarkService
    from ocean.self_improvement.code_modification import (
        CandidateWorkspaceService,
        CodeModificationService,
    )
    from ocean.self_improvement.coordinator import (
        AutonomousImprovementCoordinator,
        AutonomousImprovementRequest,
    )
    from ocean.self_improvement.decision import ImprovementDecisionService
    from ocean.self_improvement.engine import SelfImprovementEngine
    from ocean.self_improvement.model_provider import ModelProviderBoundary
    from ocean.self_improvement.research import ResearchService
    from ocean.self_improvement.test_execution import CandidateTestExecutionService
    from ocean.self_improvement.verification import CandidateVerificationService
    from ocean.self_improvement.types import ImprovementHypothesis
    from persistence.in_memory import InMemoryRepository

    events = EventBus()
    missions = InMemoryRepository()
    decisions = InMemoryRepository()
    tasks = InMemoryRepository()
    work_graphs = InMemoryRepository()
    plans = InMemoryRepository()
    runs = InMemoryRepository()
    verifications = InMemoryRepository()
    findings = InMemoryRepository()

    planning = PlanningService(
        missions=missions,
        decisions=decisions,
        tasks=tasks,
        work_graphs=work_graphs,
        plan_revisions=plans,
        events=events,
    )

    mission = Mission(goal="diagnostic propagation")
    missions.save(mission)

    source_decision = planning.create_decision(
        mission_id=mission.id,
        kind="baseline",
        objective="diagnostic propagation",
        rationale="baseline",
    )

    task = Task(title="diagnostic task", mission_id=mission.id)
    tasks.save(task)
    mission.add_task(task.id)
    missions.save(mission)

    source_plan, _ = planning.create_plan(
        mission_id=mission.id,
        decision_id=source_decision.id,
        nodes=(WorkNode(kind=WorkNodeKind.TASK, task_id=task.id),),
    )
    source_plan = planning.propose(source_plan.id, reason="baseline")
    planning.activate(source_plan.id, reason="baseline")

    repository_root = tmp_path / "repository"
    repository_root.mkdir()
    marker = repository_root / "candidate_marker.txt"
    marker.write_text("baseline\n")

    research = ResearchService(findings=findings, events=events)
    verification = CandidateVerificationService(
        verifications=verifications,
        events=events,
    )

    engine = SelfImprovementEngine(
        missions=missions,
        plan_revisions=plans,
        runs=runs,
        planning=planning,
        events=events,
        decisions=decisions,
        work_graphs=work_graphs,
        verifications=verifications,
    )

    class ModelProvider(_CoordinatorModelProvider):
        pass

    planner = _CoordinatorPlanner()

    class ResearchProvider(_CoordinatorResearchProvider):
        pass

    coordinator = AutonomousImprovementCoordinator(
        engine=engine,
        research=research,
        model=ModelProviderBoundary(provider=ModelProvider()),
        code_modification=CodeModificationService(
            workspaces=CandidateWorkspaceService(),
        ),
        test_execution=CandidateTestExecutionService(),
        verification=verification,
        benchmark=BenchmarkService(),
        decision=ImprovementDecisionService(),
        events=events,
    )

    request = AutonomousImprovementRequest(
        mission_id=mission.id,
        objective="diagnostic propagation",
        hypothesis=ImprovementHypothesis(
            objective="diagnostic propagation",
            hypothesis="candidate changes the marker",
            rationale="diagnostic propagation test",
            success_criteria=("candidate tests pass",),
        ),
        planner=planner,
        model_provider=ModelProvider(),
        research_provider=ResearchProvider(),
        benchmark_provider=_CoordinatorBenchmarkProvider(),
        repository_root=repository_root,
        baseline_root=repository_root,
        test_command=(
            "python",
            "-c",
            "import sys; print('DIAGNOSTIC_STDOUT'); "
            "print('DIAGNOSTIC_STDERR', file=sys.stderr); sys.exit(7)",
        ),
    )

    result = coordinator.run(request)

    assert result.status == "rejected"
    assert result.candidate_tests_passed is False

    rejected_run = next(run for run in runs.list() if run.id == result.run_id)

    diagnostics = rejected_run.metadata["test_result"]
    assert diagnostics["command"] == list(request.test_command)
    assert diagnostics["exit_code"] == 7
    assert diagnostics["timed_out"] is False
    assert "DIAGNOSTIC_STDOUT" in diagnostics["stdout"]
    assert "DIAGNOSTIC_STDERR" in diagnostics["stderr"]
    assert diagnostics["workspace_root"]

    rejected_events = [
        event for event in events.history()
        if event.type == "ImprovementRejected"
    ]
    assert rejected_events

    event_metadata = rejected_events[-1].payload["metadata"]["test_result"]
    assert event_metadata["exit_code"] == 7
    assert "DIAGNOSTIC_STDOUT" in event_metadata["stdout"]
    assert "DIAGNOSTIC_STDERR" in event_metadata["stderr"]
