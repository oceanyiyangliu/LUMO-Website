import time

import pytest

from ocean.node import NodeRegistry, RootAuthority


def test_root_identity_is_stable_and_signatures_verify(tmp_path):
    root = RootAuthority(tmp_path)
    root_id = root.root_id
    key_id, signature = root.sign({"action": "admit", "node": "n1"})
    assert root.root_id == root_id
    assert root.verify({"action": "admit", "node": "n1"}, key_id, signature)
    assert not root.verify({"action": "admit", "node": "n2"}, key_id, signature)


def test_node_enrollment_is_one_time_and_account_bound(tmp_path):
    root = RootAuthority(tmp_path)
    registry = NodeRegistry(tmp_path / "nodes.sqlite3", root)
    token = registry.issue_enrollment("acct")
    with pytest.raises(PermissionError):
        registry.enroll("other", token)
    node = registry.enroll("acct", token, name="iPhone")
    assert node.status == "online"
    assert node.trust == "trusted"
    with pytest.raises(PermissionError):
        registry.enroll("acct", token, name="again")


def test_node_lease_controls_execution_and_survives_expiry(tmp_path):
    root = RootAuthority(tmp_path)
    registry = NodeRegistry(tmp_path / "nodes.sqlite3", root)
    node = registry.enroll("acct", registry.issue_enrollment("acct"), name="Mac")
    assert not registry.can_execute("acct", node.id)
    lease = registry.renew_lease("acct", node.id, ttl_seconds=60)
    assert root.verify_lease(lease)
    assert registry.can_execute("acct", node.id)
    assert not registry.can_execute("acct", node.id, now=lease.expires_at + 1)
    registry.mark_offline_expired(now=lease.expires_at + 1)
    assert registry.get(node.id).status == "offline"


def test_revoked_node_cannot_execute_or_renew(tmp_path):
    root = RootAuthority(tmp_path)
    registry = NodeRegistry(tmp_path / "nodes.sqlite3", root)
    node = registry.enroll("acct", registry.issue_enrollment("acct"))
    registry.revoke("acct", node.id)
    assert not registry.can_execute("acct", node.id)
    with pytest.raises(PermissionError):
        registry.renew_lease("acct", node.id)


def test_foreign_account_cannot_control_node(tmp_path):
    root = RootAuthority(tmp_path)
    registry = NodeRegistry(tmp_path / "nodes.sqlite3", root)
    node = registry.enroll("acct-a", registry.issue_enrollment("acct-a"))
    with pytest.raises(PermissionError):
        registry.renew_lease("acct-b", node.id)


def test_root_recovery_round_trip_preserves_identity_and_requires_password(tmp_path):
    from ocean.node import export_root_recovery, restore_root_recovery
    root = RootAuthority(tmp_path / "original")
    root_id = root.root_id
    key_id, signature = root.sign({"critical": "authority"})
    bundle = export_root_recovery(root, tmp_path / "root.lumo-recovery", "correct horse battery staple")
    restored = RootAuthority(tmp_path / "restored")
    with pytest.raises(Exception):
        restore_root_recovery(restored, bundle, "wrong password")
    assert restore_root_recovery(restored, bundle, "correct horse battery staple") == root_id
    assert restored.root_id == root_id
    assert restored.verify({"critical": "authority"}, key_id, signature)
