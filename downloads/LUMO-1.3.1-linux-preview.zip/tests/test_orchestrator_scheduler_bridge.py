import time
from ocean.domain.agent import Agent
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.domain.task import Task
from ocean.orchestration.orchestrator import OrchestrationPorts, Orchestrator
from ocean.orchestration.types import AssignmentRequest, ExecutionIntent


class TaskRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item


class AssignmentRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item

    def list(self):
        return list(self.items.values())

    def transaction(self):
        from contextlib import contextmanager

        @contextmanager
        def _tx():
            yield

        return _tx()


class AgentRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)


class MissionRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)


class RuntimeStub:
    def __init__(self, execution_id=None):
        self.execution_id = execution_id

    def submit(
        self,
        agent_id,
        request,
        *,
        priority=0,
        dependencies=None,
    ):
        class Scheduled:
            pass

        scheduled = Scheduled()
        scheduled.execution_id = request.execution_id if self.execution_id is None else self.execution_id
        return scheduled

    def mark_idle(self, agent_id):
        raise AssertionError("bridge must not manage agent lifecycle")

    def mark_waiting(self, agent_id, *, task_id=None):
        raise AssertionError("bridge must not manage agent lifecycle")

    def mark_background(self, agent_id):
        raise AssertionError("bridge must not manage agent lifecycle")


def build():
    tasks = TaskRepo()
    assignments = AssignmentRepo()
    agents = AgentRepo()
    missions = MissionRepo()
    events = EventBus()
    runtime = RuntimeStub()

    ports = OrchestrationPorts(
        missions=missions,
        tasks=tasks,
        assignments=assignments,
        agents=agents,
        agent_runtime=runtime,
        events=events,
    )

    return (
        Orchestrator(ports),
        tasks,
        assignments,
        agents,
        events,
    )


def make_assignment():
    (
        orchestrator,
        tasks,
        assignments,
        agents,
        events,
    ) = build()

    agent = Agent(
        id="agent-bridge",
        name="Bridge Agent",
        role="worker",
        capabilities={"test"},
    )
    agents.items[agent.id] = agent

    task = Task(title="Bridge task")
    tasks.save(task)

    created = orchestrator.assign(
        AssignmentRequest(
            task_id=task.id,
            agent_id=agent.id,
            metadata={"origin": "bridge-test"},
        )
    )
    assert created.success

    dispatched = orchestrator.dispatch(
        created.assignment_id,
        ExecutionIntent(
            capability="test",
            operation="run",
        ),
    )
    assert dispatched.success
    assert dispatched.execution_id == assignments.get(created.assignment_id).execution_id

    assignment = assignments.items[created.assignment_id]

    dispatch_event = Event(
        type="ScheduledExecutionDispatched",
        payload={
            "id": assignment.execution_id,
            "task_id": task.id,
            "agent_id": agent.id,
            "priority": assignment.priority,
            "state": "dispatched",
        },
        aggregate_type="scheduled_execution",
        aggregate_id=assignment.execution_id,
        causation_id=created.assignment_id,
        source="scheduler",
    )

    failures = events.publish(dispatch_event)
    assert failures == []

    return (
        orchestrator,
        tasks,
        assignments,
        events,
        created.assignment_id,
    )


def completion_event(assignment_id, task_id, assignments, execution_id=None):
    return Event(
        type="ScheduledExecutionCompleted",
        payload={
            "id": execution_id or assignments.get(assignment_id).execution_id,
            "task_id": task_id,
            "priority": 0,
            "state": "completed",
            "success": True,
            "error": None,
        },
        aggregate_type="scheduled_execution",
        aggregate_id=execution_id or assignments.get(assignment_id).execution_id,
        causation_id=assignment_id,
        source="scheduler",
    )


def failure_event(assignment_id, task_id, assignments, execution_id=None):
    return Event(
        type="ScheduledExecutionFailed",
        payload={
            "id": execution_id or assignments.get(assignment_id).execution_id,
            "task_id": task_id,
            "priority": 0,
            "state": "failed",
            "success": False,
            "error": "execution failed",
        },
        aggregate_type="scheduled_execution",
        aggregate_id=execution_id or assignments.get(assignment_id).execution_id,
        causation_id=assignment_id,
        source="scheduler",
    )


def test_scheduler_completion_event_completes_assignment():
    (
        orchestrator,
        tasks,
        assignments,
        events,
        assignment_id,
    ) = make_assignment()

    task_id = assignments.items[assignment_id].task_id

    failures = events.publish(
        completion_event(assignment_id, task_id, assignments)
    )

    assert failures == []
    assert assignments.items[assignment_id].status.value == "completed"


def test_scheduler_failure_event_fails_assignment():
    (
        orchestrator,
        tasks,
        assignments,
        events,
        assignment_id,
    ) = make_assignment()

    task_id = assignments.items[assignment_id].task_id

    failures = events.publish(
        failure_event(assignment_id, task_id, assignments)
    )

    assert failures == []
    assert assignments.items[assignment_id].status.value == "failed"


def test_scheduler_completion_event_emits_assignment_completed():
    (
        orchestrator,
        tasks,
        assignments,
        events,
        assignment_id,
    ) = make_assignment()

    task_id = assignments.items[assignment_id].task_id

    events.publish(
        completion_event(assignment_id, task_id, assignments)
    )

    event_types = [event.type for event in events.history()]

    assert event_types[-1] == "TaskAssignmentCompleted"


def test_scheduler_failure_event_emits_assignment_failed():
    (
        orchestrator,
        tasks,
        assignments,
        events,
        assignment_id,
    ) = make_assignment()

    task_id = assignments.items[assignment_id].task_id

    events.publish(
        failure_event(assignment_id, task_id, assignments)
    )

    event_types = [event.type for event in events.history()]

    assert event_types[-1] == "TaskAssignmentFailed"


def test_scheduler_event_with_unknown_assignment_is_rejected():
    (
        orchestrator,
        tasks,
        assignments,
        agents,
        events,
    ) = build()

    failures = events.publish(
        completion_event(
            "assignment-missing",
            "task-missing",
            assignments,
            "exec-missing",
        )
    )

    assert len(failures) == 1


def test_scheduler_event_with_execution_mismatch_is_rejected():
    (
        orchestrator,
        tasks,
        assignments,
        events,
        assignment_id,
    ) = make_assignment()

    task_id = assignments.items[assignment_id].task_id

    event = Event(
        type="ScheduledExecutionCompleted",
        payload={
            "id": "exec-WRONG",
            "task_id": task_id,
            "priority": 0,
            "state": "completed",
            "success": True,
            "error": None,
        },
        aggregate_type="scheduled_execution",
        aggregate_id="exec-WRONG",
        causation_id=assignment_id,
        source="scheduler",
    )

    failures = events.publish(event)

    assert len(failures) == 1
    assert assignments.items[assignment_id].status.value == "active"


def test_duplicate_scheduler_completion_is_idempotent():
    (
        orchestrator,
        tasks,
        assignments,
        events,
        assignment_id,
    ) = make_assignment()

    task_id = assignments.items[assignment_id].task_id
    event = completion_event(assignment_id, task_id, assignments)

    first_failures = events.publish(event)
    second_failures = events.publish(event)

    assert first_failures == []
    assert second_failures == []
    assert assignments.items[assignment_id].status.value == "completed"


def test_scheduler_bridge_does_not_complete_task():
    (
        orchestrator,
        tasks,
        assignments,
        events,
        assignment_id,
    ) = make_assignment()

    task = tasks.items[assignments.items[assignment_id].task_id]

    events.publish(
        completion_event(assignment_id, task.id, assignments)
    )

    assert task.status.value != "completed"


def test_assignment_created_event_preserves_metadata():
    (
        orchestrator,
        tasks,
        assignments,
        agents,
        events,
    ) = build()

    agent = Agent(
        id="agent-metadata",
        name="Metadata Agent",
        role="worker",
        capabilities={"test"},
    )
    agents.items[agent.id] = agent

    task = Task(title="Metadata task")
    tasks.save(task)

    result = orchestrator.assign(
        AssignmentRequest(
            task_id=task.id,
            agent_id=agent.id,
            metadata={
                "origin": "test",
                "priority_class": "critical",
            },
        )
    )

    assert result.success

    created_event = next(
        event
        for event in events.history()
        if event.type == "TaskAssignmentCreated"
    )

    assert created_event.payload["metadata"] == {
        "origin": "test",
        "priority_class": "critical",
    }


def _wait_for_handle_result(handle, timeout=2.0):
    deadline = time.monotonic() + timeout
    while handle.result is None:
        if time.monotonic() >= deadline:
            raise AssertionError(
                f"execution {handle.execution_id!r} did not complete "
                f"within {timeout} seconds"
            )
        time.sleep(0.001)
    return handle.result


def test_real_scheduler_execution_reconciles_assignment_success():
    from ocean.domain.capability import (
        CapabilityRegistry,
        CapabilitySpec,
        OperationSpec,
    )
    from ocean.domain.enums import RiskLevel
    from ocean.domain.policy import PolicyEngine
    from runtime import (
        AgentRuntime,
        ExecutionRuntime,
        ExecutionSupervisor,
        ExecutorRegistry,
        Scheduler,
)
    from runtime.executor import CapabilityExecutor
    from runtime.types import ExecutionResult
    from ocean.core.ids import new_id

    class SuccessfulExecutor(CapabilityExecutor):
        def execute(self, request, context):
            return ExecutionResult.succeeded(
                {"execution_id": request.execution_id}
            )

    events = EventBus()

    capabilities = CapabilityRegistry()
    capabilities.register(
        CapabilitySpec(
            name="test",
            description="Test capability",
            execution_strategy="test_executor",
            operations={
                "run": OperationSpec(
                    name="run",
                    description="Run test operation",
                    risk_level=RiskLevel.SAFE,
                ),
            },
        )
    )

    executors = ExecutorRegistry()
    executors.register(
        "test_executor",
        SuccessfulExecutor(),
    )

    execution_runtime = ExecutionRuntime(
        capabilities=capabilities,
        policy=PolicyEngine(),
        executors=executors,
        event_bus=events,
    )

    supervisor = ExecutionSupervisor(execution_runtime)
    scheduler = Scheduler(
        supervisor,
        event_bus=events,
    )
    agent_runtime = AgentRuntime(scheduler)

    tasks = TaskRepo()
    assignments = AssignmentRepo()
    agents = AgentRepo()
    missions = MissionRepo()

    ports = OrchestrationPorts(
        missions=missions,
        tasks=tasks,
        assignments=assignments,
        agents=agents,
        agent_runtime=agent_runtime,
        events=events,
    )

    orchestrator = Orchestrator(ports)

    try:
        agent = Agent(
            id="agent-real-success",
            name="Real Success Agent",
            role="worker",
            capabilities={"test"},
        )
        agents.items[agent.id] = agent
        agent_runtime.register(agent)

        task = Task(title="Real scheduler success")
        tasks.save(task)

        created = orchestrator.assign(
            AssignmentRequest(
                task_id=task.id,
                agent_id=agent.id,
            )
        )
        assert created.success

        dispatched = orchestrator.dispatch(
            created.assignment_id,
            ExecutionIntent(
                capability="test",
                operation="run",
            ),
        )
        assert dispatched.success
        assert dispatched.execution_id is not None

        scheduled = scheduler.dispatch_next()

        assert scheduled is not None
        assert scheduled.state.value == "dispatched"

        result = _wait_for_handle_result(scheduled.handle)
        assert result.success is True

        reconciled = scheduler.reconcile(
            dispatched.execution_id
        )

        assert reconciled.state.value == "completed"

        assignment = assignments.items[created.assignment_id]

        assert assignment.status.value == "completed"
        assert assignment.execution_id == dispatched.execution_id

        event_types = [event.type for event in events.history()]

        assert "ScheduledExecutionQueued" in event_types
        assert "ScheduledExecutionDispatched" in event_types
        assert "ExecutionCreated" in event_types
        assert "ExecutionStarted" in event_types
        assert "ExecutionSucceeded" in event_types
        assert "ScheduledExecutionCompleted" in event_types
        assert "TaskAssignmentCompleted" in event_types

        assert event_types.index(
            "ScheduledExecutionCompleted"
        ) < event_types.index(
            "TaskAssignmentCompleted"
        )

    finally:
        scheduler.stop()
        supervisor.shutdown()


def test_real_scheduler_execution_reconciles_assignment_failure():
    from ocean.domain.capability import (
        CapabilityRegistry,
        CapabilitySpec,
        OperationSpec,
    )
    from ocean.domain.enums import RiskLevel
    from ocean.domain.policy import PolicyEngine
    from runtime import (
        AgentRuntime,
        ExecutionRuntime,
        ExecutionSupervisor,
        ExecutorRegistry,
        Scheduler,
)
    from runtime.executor import CapabilityExecutor
    from runtime.types import ExecutionResult

    class FailingExecutor(CapabilityExecutor):
        def execute(self, request, context):
            return ExecutionResult.failed("controlled failure")

    events = EventBus()

    capabilities = CapabilityRegistry()
    capabilities.register(
        CapabilitySpec(
            name="test",
            description="Test capability",
            execution_strategy="test_executor",
            operations={
                "run": OperationSpec(
                    name="run",
                    description="Run test operation",
                    risk_level=RiskLevel.SAFE,
                ),
            },
        )
    )

    executors = ExecutorRegistry()
    executors.register(
        "test_executor",
        FailingExecutor(),
    )

    execution_runtime = ExecutionRuntime(
        capabilities=capabilities,
        policy=PolicyEngine(),
        executors=executors,
        event_bus=events,
    )

    supervisor = ExecutionSupervisor(execution_runtime)
    scheduler = Scheduler(
        supervisor,
        event_bus=events,
    )
    agent_runtime = AgentRuntime(scheduler)

    tasks = TaskRepo()
    assignments = AssignmentRepo()
    agents = AgentRepo()
    missions = MissionRepo()

    ports = OrchestrationPorts(
        missions=missions,
        tasks=tasks,
        assignments=assignments,
        agents=agents,
        agent_runtime=agent_runtime,
        events=events,
    )

    orchestrator = Orchestrator(ports)

    try:
        agent = Agent(
            id="agent-real-failure",
            name="Real Failure Agent",
            role="worker",
            capabilities={"test"},
        )
        agents.items[agent.id] = agent
        agent_runtime.register(agent)

        task = Task(title="Real scheduler failure")
        tasks.save(task)

        created = orchestrator.assign(
            AssignmentRequest(
                task_id=task.id,
                agent_id=agent.id,
            )
        )
        assert created.success

        dispatched = orchestrator.dispatch(
            created.assignment_id,
            ExecutionIntent(
                capability="test",
                operation="run",
            ),
        )
        assert dispatched.success
        assert dispatched.execution_id is not None

        scheduled = scheduler.dispatch_next()

        assert scheduled is not None
        assert scheduled.state.value == "dispatched"

        result = _wait_for_handle_result(scheduled.handle)
        assert result.success is False
        assert result.error == "controlled failure"

        reconciled = scheduler.reconcile(
            dispatched.execution_id
        )

        assert reconciled.state.value == "failed"

        assignment = assignments.items[created.assignment_id]

        assert assignment.status.value == "failed"
        assert assignment.execution_id == dispatched.execution_id

        event_types = [event.type for event in events.history()]

        assert "ExecutionFailed" in event_types
        assert "ScheduledExecutionFailed" in event_types
        assert "TaskAssignmentFailed" in event_types

        assert event_types.index(
            "ScheduledExecutionFailed"
        ) < event_types.index(
            "TaskAssignmentFailed"
        )

    finally:
        scheduler.stop()
        supervisor.shutdown()
