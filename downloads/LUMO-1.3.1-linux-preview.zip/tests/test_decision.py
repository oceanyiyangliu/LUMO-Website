import pytest

from ocean.domain.decision import Decision


def test_decision_is_immutable():
    decision = Decision(
        mission_id="mission_1",
        kind="initial_plan",
        objective="Build a research system",
        rationale="Parallel research reduces elapsed time.",
    )

    with pytest.raises(AttributeError):
        decision.objective = "changed"


def test_decision_validates_required_fields():
    with pytest.raises(ValueError):
        Decision("", "plan", "objective", "reason")
    with pytest.raises(ValueError):
        Decision("m1", "", "objective", "reason")
    with pytest.raises(ValueError):
        Decision("m1", "plan", "", "reason")
    with pytest.raises(ValueError):
        Decision("m1", "plan", "objective", "")


def test_decision_validates_confidence():
    with pytest.raises(ValueError):
        Decision("m1", "plan", "objective", "reason", confidence=-0.1)
    with pytest.raises(ValueError):
        Decision("m1", "plan", "objective", "reason", confidence=1.1)


def test_decision_freezes_nested_metadata():
    metadata = {"config": {"timeout": 30}}
    decision = Decision(
        "m1",
        "plan",
        "objective",
        "reason",
        metadata=metadata,
    )

    with pytest.raises(TypeError):
        decision.metadata["config"]["timeout"] = 60


def test_decision_generates_typed_id():
    decision = Decision("m1", "plan", "objective", "reason")
    assert decision.id.startswith("decision_")
