from dataclasses import replace

import pytest

from ocean.domain.event_bus import EventBus
from ocean.domain.verification import Verification
from ocean.self_improvement.verification import (
    CandidateVerificationError,
    CandidateVerificationService,
)
from persistence.repository import Repository


class MemoryRepository(Repository):
    def __init__(self):
        self.items = {}

    def save(self, entity):
        self.items[entity.id] = entity
        return entity

    def get(self, entity_id):
        return self.items.get(entity_id)

    def list(self):
        return list(self.items.values())

    def delete(self, entity_id):
        return self.items.pop(entity_id, None) is not None


def test_passing_candidate_verification_requires_evidence():
    service = CandidateVerificationService(
        verifications=MemoryRepository(),
        events=EventBus(),
    )

    with pytest.raises(
        CandidateVerificationError,
        match="passing candidate verification requires evidence",
    ):
        service.record(
            candidate_id="candidate-1",
            candidate_mission_id="mission-candidate",
            candidate_plan_revision_id="plan-candidate",
            task_id="task-candidate",
            passed=True,
        )


def test_candidate_verification_records_authoritative_evidence():
    verifications = MemoryRepository()
    events = EventBus()

    service = CandidateVerificationService(
        verifications=verifications,
        events=events,
    )

    context = service.record(
        candidate_id="candidate-1",
        candidate_mission_id="mission-candidate",
        candidate_plan_revision_id="plan-candidate",
        task_id="task-candidate",
        execution_id="execution-1",
        method="benchmark",
        passed=True,
        evidence=("latency=12ms", "throughput=100"),
        metadata={"benchmark": "candidate-v1"},
    )

    verification = verifications.get(context.verification_id)

    assert verification is not None
    assert verification.task_id == "task-candidate"
    assert verification.execution_id == "execution-1"
    assert verification.passed is True
    assert verification.evidence == ["latency=12ms", "throughput=100"]

    recorded = events.history("VerificationRecorded")
    assert len(recorded) == 1
    assert recorded[0].payload["verification_id"] == verification.id
    assert recorded[0].payload["candidate_id"] == "candidate-1"
    assert recorded[0].payload["candidate_plan_revision_id"] == "plan-candidate"
    assert recorded[0].payload["evidence"] == [
        "latency=12ms",
        "throughput=100",
    ]


def test_failed_candidate_verification_can_record_failure_evidence():
    service = CandidateVerificationService(
        verifications=MemoryRepository(),
        events=EventBus(),
    )

    context = service.record(
        candidate_id="candidate-1",
        candidate_mission_id="mission-candidate",
        candidate_plan_revision_id="plan-candidate",
        task_id="task-candidate",
        passed=False,
        evidence=("regression detected",),
    )

    assert context.passed is False
    assert context.evidence == ("regression detected",)


def test_candidate_verification_requires_task_identity():
    service = CandidateVerificationService(
        verifications=MemoryRepository(),
        events=EventBus(),
    )

    with pytest.raises(
        CandidateVerificationError,
        match="task_id must be non-empty",
    ):
        service.record(
            candidate_id="candidate-1",
            candidate_mission_id="mission-candidate",
            candidate_plan_revision_id="plan-candidate",
            task_id="",
            passed=False,
        )
