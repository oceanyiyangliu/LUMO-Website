from datetime import datetime

import pytest

from ocean.domain.assignment import (
    ASSIGNMENT_TERMINAL,
    ASSIGNMENT_TRANSITIONS,
    Assignment,
)
from ocean.domain.enums import AssignmentStatus, OrchestrationMode


def test_assignment_defaults():
    assignment = Assignment(
        task_id="task-1",
        agent_id="agent-1",
    )

    assert assignment.task_id == "task-1"
    assert assignment.agent_id == "agent-1"
    assert assignment.mission_id is None
    assert assignment.mode is OrchestrationMode.STANDARD
    assert assignment.priority == 0
    assert assignment.status is AssignmentStatus.CREATED
    assert assignment.execution_id is None
    assert assignment.parent_assignment_id is None
    assert assignment.reason is None
    assert assignment.metadata == {}
    assert assignment.id.startswith("assignment_")
    assert isinstance(assignment.created_at, datetime)
    assert isinstance(assignment.updated_at, datetime)


def test_assignment_accepts_full_configuration():
    assignment = Assignment(
        task_id="task-1",
        agent_id="agent-1",
        mission_id="mission-1",
        mode=OrchestrationMode.PARALLEL,
        priority=10,
        execution_id="execution-1",
        parent_assignment_id="assignment-parent",
        reason="recovery",
        metadata={"attempt": 2},
        id="assignment-1",
    )

    assert assignment.task_id == "task-1"
    assert assignment.agent_id == "agent-1"
    assert assignment.mission_id == "mission-1"
    assert assignment.mode is OrchestrationMode.PARALLEL
    assert assignment.priority == 10
    assert assignment.execution_id == "execution-1"
    assert assignment.parent_assignment_id == "assignment-parent"
    assert assignment.reason == "recovery"
    assert assignment.metadata == {"attempt": 2}
    assert assignment.id == "assignment-1"


@pytest.mark.parametrize(
    "kwargs",
    [
        {"task_id": "", "agent_id": "agent-1"},
        {"task_id": "task-1", "agent_id": ""},
        {"task_id": "task-1", "agent_id": "agent-1", "priority": -1},
        {"task_id": "task-1", "agent_id": "agent-1", "id": ""},
    ],
)
def test_assignment_rejects_invalid_construction(kwargs):
    with pytest.raises(ValueError):
        Assignment(**kwargs)


def test_assignment_rejects_self_parent():
    with pytest.raises(ValueError, match="cannot reference itself"):
        Assignment(
            task_id="task-1",
            agent_id="agent-1",
            id="assignment-1",
            parent_assignment_id="assignment-1",
        )


def test_assignment_rejects_empty_execution_id():
    with pytest.raises(ValueError, match="execution_id"):
        Assignment(
            task_id="task-1",
            agent_id="agent-1",
            execution_id="",
        )


def test_assignment_rejects_empty_mission_id():
    with pytest.raises(ValueError, match="mission_id"):
        Assignment(
            task_id="task-1",
            agent_id="agent-1",
            mission_id="",
        )


def test_created_can_transition_to_queued():
    assignment = Assignment("task-1", "agent-1")

    assignment.queue()

    assert assignment.status is AssignmentStatus.QUEUED


def test_queued_can_transition_to_active():
    assignment = Assignment("task-1", "agent-1")

    assignment.queue()
    assignment.activate(execution_id="execution-1")

    assert assignment.status is AssignmentStatus.ACTIVE
    assert assignment.execution_id == "execution-1"


def test_active_can_complete():
    assignment = Assignment("task-1", "agent-1")

    assignment.queue()
    assignment.activate(execution_id="execution-1")
    assignment.complete(reason="execution succeeded")

    assert assignment.status is AssignmentStatus.COMPLETED
    assert assignment.reason == "execution succeeded"
    assert assignment.is_terminal()


def test_active_can_fail():
    assignment = Assignment("task-1", "agent-1")

    assignment.queue()
    assignment.activate(execution_id="execution-1")
    assignment.fail(reason="execution failed")

    assert assignment.status is AssignmentStatus.FAILED
    assert assignment.reason == "execution failed"
    assert assignment.is_failed()
    assert assignment.is_terminal()


def test_active_can_be_superseded():
    assignment = Assignment("task-1", "agent-1")

    assignment.queue()
    assignment.activate(execution_id="execution-1")
    assignment.supersede(reason="handoff")

    assert assignment.status is AssignmentStatus.SUPERSEDED
    assert assignment.reason == "handoff"
    assert assignment.is_superseded()
    assert assignment.is_terminal()


def test_created_can_be_cancelled():
    assignment = Assignment("task-1", "agent-1")

    assignment.cancel(reason="mission cancelled")

    assert assignment.status is AssignmentStatus.CANCELLED
    assert assignment.reason == "mission cancelled"
    assert assignment.is_terminal()


def test_queued_can_be_cancelled():
    assignment = Assignment("task-1", "agent-1")

    assignment.queue()
    assignment.cancel()

    assert assignment.status is AssignmentStatus.CANCELLED
    assert assignment.is_terminal()


def test_queued_can_be_superseded():
    assignment = Assignment("task-1", "agent-1")

    assignment.queue()
    assignment.supersede(reason="replacement")

    assert assignment.status is AssignmentStatus.SUPERSEDED
    assert assignment.is_terminal()


def test_active_can_be_cancelled():
    assignment = Assignment("task-1", "agent-1")

    assignment.queue()
    assignment.activate()
    assignment.cancel(reason="operator cancellation")

    assert assignment.status is AssignmentStatus.CANCELLED
    assert assignment.is_terminal()


def test_terminal_states_have_no_outgoing_transitions():
    for status in ASSIGNMENT_TERMINAL:
        assert ASSIGNMENT_TRANSITIONS[status] == set()


@pytest.mark.parametrize(
    "initial_status, operation",
    [
        (AssignmentStatus.CREATED, "activate"),
        (AssignmentStatus.CREATED, "complete"),
        (AssignmentStatus.CREATED, "fail"),
        (AssignmentStatus.CREATED, "supersede"),
        (AssignmentStatus.QUEUED, "complete"),
        (AssignmentStatus.QUEUED, "fail"),
        (AssignmentStatus.ACTIVE, "queue"),
        (AssignmentStatus.ACTIVE, "activate"),
        (AssignmentStatus.COMPLETED, "queue"),
        (AssignmentStatus.COMPLETED, "activate"),
        (AssignmentStatus.COMPLETED, "complete"),
        (AssignmentStatus.COMPLETED, "fail"),
        (AssignmentStatus.COMPLETED, "cancel"),
        (AssignmentStatus.FAILED, "queue"),
        (AssignmentStatus.FAILED, "activate"),
        (AssignmentStatus.FAILED, "complete"),
        (AssignmentStatus.FAILED, "cancel"),
        (AssignmentStatus.SUPERSEDED, "queue"),
        (AssignmentStatus.SUPERSEDED, "activate"),
        (AssignmentStatus.SUPERSEDED, "complete"),
        (AssignmentStatus.SUPERSEDED, "fail"),
        (AssignmentStatus.SUPERSEDED, "cancel"),
        (AssignmentStatus.CANCELLED, "queue"),
        (AssignmentStatus.CANCELLED, "activate"),
        (AssignmentStatus.CANCELLED, "complete"),
        (AssignmentStatus.CANCELLED, "fail"),
        (AssignmentStatus.CANCELLED, "supersede"),
    ],
)
def test_invalid_transitions_are_rejected(initial_status, operation):
    assignment = Assignment(
        task_id="task-1",
        agent_id="agent-1",
        status=initial_status,
    )

    with pytest.raises(ValueError, match="invalid assignment transition"):
        getattr(assignment, operation)()


def test_bind_execution():
    assignment = Assignment("task-1", "agent-1")

    assignment.bind_execution("execution-1")

    assert assignment.execution_id == "execution-1"


def test_bind_execution_is_idempotent_for_same_execution():
    assignment = Assignment(
        "task-1",
        "agent-1",
        execution_id="execution-1",
    )

    assignment.bind_execution("execution-1")

    assert assignment.execution_id == "execution-1"


def test_bind_execution_rejects_different_execution():
    assignment = Assignment(
        "task-1",
        "agent-1",
        execution_id="execution-1",
    )

    with pytest.raises(ValueError, match="already bound"):
        assignment.bind_execution("execution-2")


def test_bind_execution_rejects_empty_id():
    assignment = Assignment("task-1", "agent-1")

    with pytest.raises(ValueError, match="execution_id"):
        assignment.bind_execution("")


def test_activate_can_bind_execution():
    assignment = Assignment("task-1", "agent-1")

    assignment.queue()
    assignment.activate(execution_id="execution-1")

    assert assignment.execution_id == "execution-1"


def test_activate_without_execution_keeps_existing_binding():
    assignment = Assignment(
        "task-1",
        "agent-1",
        execution_id="execution-1",
    )

    assignment.queue()
    assignment.activate()

    assert assignment.execution_id == "execution-1"


def test_activate_rejects_different_execution_when_already_bound():
    assignment = Assignment(
        "task-1",
        "agent-1",
        execution_id="execution-1",
    )

    assignment.queue()

    with pytest.raises(ValueError, match="already bound"):
        assignment.activate(execution_id="execution-2")


def test_status_helpers():
    created = Assignment("task-1", "agent-1")

    assert not created.is_terminal()
    assert not created.is_active()
    assert not created.is_queued()
    assert not created.is_failed()
    assert not created.is_superseded()

    created.queue()

    assert not created.is_terminal()
    assert not created.is_active()
    assert created.is_queued()

    created.activate()

    assert not created.is_terminal()
    assert created.is_active()

    created.fail()

    assert created.is_terminal()
    assert created.is_failed()
    assert not created.is_active()
    assert not created.is_queued()


def test_transition_updates_reason_when_provided():
    assignment = Assignment("task-1", "agent-1")

    assignment.queue(reason="waiting for scheduler")

    assert assignment.reason == "waiting for scheduler"


def test_transition_preserves_existing_reason_when_reason_omitted():
    assignment = Assignment("task-1", "agent-1")

    assignment.queue(reason="initial reason")
    assignment.activate()

    assert assignment.reason == "initial reason"


def test_metadata_is_not_shared_between_instances():
    first = Assignment("task-1", "agent-1")
    second = Assignment("task-2", "agent-2")

    first.metadata["key"] = "value"

    assert second.metadata == {}


def test_ids_are_unique_by_default():
    first = Assignment("task-1", "agent-1")
    second = Assignment("task-1", "agent-1")

    assert first.id != second.id


def test_assignment_preserves_lineage():
    parent = Assignment(
        task_id="task-1",
        agent_id="agent-a",
        id="assignment-parent",
    )

    child = Assignment(
        task_id="task-1",
        agent_id="agent-b",
        parent_assignment_id=parent.id,
    )

    assert child.parent_assignment_id == parent.id
    assert child.task_id == parent.task_id
    assert child.agent_id != parent.agent_id


def test_handoff_lineage_can_be_represented():
    first = Assignment(
        task_id="task-1",
        agent_id="agent-a",
        id="assignment-1",
    )
    first.queue()
    first.activate(execution_id="execution-1")
    first.supersede(reason="handoff")

    second = Assignment(
        task_id="task-1",
        agent_id="agent-b",
        parent_assignment_id=first.id,
        id="assignment-2",
    )

    assert first.status is AssignmentStatus.SUPERSEDED
    assert second.parent_assignment_id == first.id
    assert second.task_id == first.task_id


def test_assignment_mode_is_preserved():
    for mode in OrchestrationMode:
        assignment = Assignment(
            task_id="task-1",
            agent_id="agent-1",
            mode=mode,
        )

        assert assignment.mode is mode


def test_assignment_status_is_preserved_when_deserialized_style_constructed():
    assignment = Assignment(
        task_id="task-1",
        agent_id="agent-1",
        status=AssignmentStatus.QUEUED,
    )

    assert assignment.status is AssignmentStatus.QUEUED
