from datetime import datetime, timezone

from ocean.domain.assignment import Assignment
from ocean.domain.enums import AssignmentStatus, OrchestrationMode
from persistence.serializers.assignment import AssignmentSerializer


def test_assignment_serializer_round_trip():
    created_at = datetime(2026, 1, 1, 10, 0, tzinfo=timezone.utc)
    updated_at = datetime(2026, 1, 1, 10, 5, tzinfo=timezone.utc)

    assignment = Assignment(
        task_id="task-1",
        agent_id="agent-1",
        mission_id="mission-1",
        mode=OrchestrationMode.PARALLEL,
        priority=10,
        status=AssignmentStatus.ACTIVE,
        execution_id="execution-1",
        parent_assignment_id="assignment-parent",
        reason="execution dispatched",
        metadata={"attempt": 2, "source": "test"},
        id="assignment-1",
        created_at=created_at,
        updated_at=updated_at,
    )

    serializer = AssignmentSerializer()
    serialized = serializer.serialize(assignment)
    restored = serializer.deserialize(serialized)

    assert restored == assignment


def test_assignment_serializer_produces_json_safe_data():
    assignment = Assignment(
        task_id="task-1",
        agent_id="agent-1",
        id="assignment-json",
        mode=OrchestrationMode.BACKGROUND,
        priority=7,
    )

    data = AssignmentSerializer().serialize(assignment)

    assert data["id"] == "assignment-json"
    assert data["task_id"] == "task-1"
    assert data["agent_id"] == "agent-1"
    assert data["mode"] == OrchestrationMode.BACKGROUND.value
    assert data["priority"] == 7
    assert data["status"] == AssignmentStatus.CREATED.value
    assert data["execution_id"] is None
    assert isinstance(data["created_at"], str)
    assert isinstance(data["updated_at"], str)


def test_assignment_serializer_preserves_terminal_state():
    assignment = Assignment(
        task_id="task-1",
        agent_id="agent-1",
        id="assignment-terminal",
        status=AssignmentStatus.ACTIVE,
        execution_id="execution-1",
    )
    assignment.complete(reason="done")

    restored = AssignmentSerializer().deserialize(
        AssignmentSerializer().serialize(assignment)
    )

    assert restored.status is AssignmentStatus.COMPLETED
    assert restored.execution_id == "execution-1"
    assert restored.reason == "done"


def test_assignment_serializer_preserves_metadata_and_lineage():
    assignment = Assignment(
        task_id="task-1",
        agent_id="agent-2",
        mission_id="mission-1",
        parent_assignment_id="assignment-parent",
        metadata={
            "attempt": 3,
            "recovery": True,
            "nested": {"key": "value"},
        },
        id="assignment-child",
    )

    restored = AssignmentSerializer().deserialize(
        AssignmentSerializer().serialize(assignment)
    )

    assert restored.parent_assignment_id == "assignment-parent"
    assert restored.metadata == {
        "attempt": 3,
        "recovery": True,
        "nested": {"key": "value"},
    }


def test_assignment_serializer_preserves_all_modes():
    serializer = AssignmentSerializer()

    for mode in OrchestrationMode:
        assignment = Assignment(
            task_id="task-1",
            agent_id="agent-1",
            mode=mode,
        )

        restored = serializer.deserialize(serializer.serialize(assignment))

        assert restored.mode is mode
