from pathlib import Path
import time

from ocean.email_outbox import EmailOutbox


class FakeDelivery:
    provider = "test"
    configured = True

    def __init__(self):
        self.calls = []
        self.fail = False

    def send(self, **kwargs):
        self.calls.append(kwargs)
        if self.fail:
            raise RuntimeError("temporary provider failure")

    def status(self):
        return {"provider": self.provider, "configured": self.configured}


class FakeSecure:
    def __init__(self):
        self.data = {}

    def set(self, key, value):
        self.data[key] = value

    def get(self, key):
        return self.data.get(key)

    def delete(self, key):
        self.data.pop(key, None)


def make_outbox(tmp_path, monkeypatch):
    secure = FakeSecure()
    monkeypatch.setattr("ocean.email_outbox.KeychainTokenStore", lambda service: secure)
    return EmailOutbox(tmp_path / "mail.sqlite3", FakeDelivery(), start_worker=False)


def test_outbox_delivers_and_removes_sensitive_payload(tmp_path, monkeypatch):
    outbox = make_outbox(tmp_path, monkeypatch)
    try:
        result = outbox.enqueue(
            to="user@example.com",
            subject="Verify",
            template="verify-email",
            variables={"token": "secret"},
            deliver_now=True,
        )
        assert result["sent"] is True
        assert outbox.status()["sent"] == 1
        assert not outbox._secure.data
        assert outbox.delivery.calls[0]["variables"]["token"] == "secret"
    finally:
        outbox.close()


def test_outbox_retries_and_eventually_marks_terminal_failure(tmp_path, monkeypatch):
    outbox = make_outbox(tmp_path, monkeypatch)
    outbox.delivery.fail = True
    try:
        result = outbox.enqueue(
            to="user@example.com",
            subject="Verify",
            template="verify-email",
            variables={"token": "secret"},
            deliver_now=True,
        )
        assert result["queued"] is True
        assert outbox.status()["pending"] == 1
        for _ in range(outbox.MAX_ATTEMPTS - 1):
            with outbox._lock:
                outbox._db.execute("UPDATE email_outbox SET next_attempt_at=? WHERE id=?", (0, result["id"]))
                outbox._db.commit()
            outbox.process_pending(limit=1)
        assert outbox.status()["failed"] == 1
    finally:
        outbox.close()


def test_outbox_rejects_invalid_recipient(tmp_path, monkeypatch):
    outbox = make_outbox(tmp_path, monkeypatch)
    try:
        try:
            outbox.enqueue(to="not-an-email", subject="x", template="notification", variables={})
        except ValueError:
            pass
        else:
            raise AssertionError("invalid recipient was accepted")
    finally:
        outbox.close()
