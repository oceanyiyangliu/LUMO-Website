from ocean.domain.event_bus import EventBus
from ocean.domain.mission import Mission
from ocean.domain.task import Task
from ocean.self_improvement.isolation import (
    CandidateIsolationError,
    CandidateIsolationService,
)
from persistence.in_memory import InMemoryRepository


def build():
    return (
        InMemoryRepository(),
        InMemoryRepository(),
        EventBus(),
    )


def test_candidate_isolation_creates_distinct_mission_and_tasks():
    missions, tasks, events = build()

    source = Mission(goal="Improve planner")
    first = Task(title="Research", mission_id=source.id)
    second = Task(
        title="Benchmark",
        mission_id=source.id,
        depends_on={first.id},
    )
    source.add_task(first.id)
    source.add_task(second.id)

    missions.save(source)
    tasks.save(first)
    tasks.save(second)

    isolation = CandidateIsolationService(
        missions=missions,
        tasks=tasks,
        events=events,
    ).create(
        source_mission=source,
        task_ids=source.task_ids,
    )

    assert isolation.candidate_mission_id != source.id
    assert isolation.source_mission_id == source.id

    candidate = missions.get(isolation.candidate_mission_id)
    assert candidate is not None
    assert candidate.id != source.id
    assert candidate.goal == source.goal
    assert candidate.task_ids != source.task_ids

    candidate_first = tasks.get(
        isolation.candidate_task_for(first.id)
    )
    candidate_second = tasks.get(
        isolation.candidate_task_for(second.id)
    )

    assert candidate_first is not None
    assert candidate_second is not None

    assert candidate_first.id != first.id
    assert candidate_second.id != second.id

    assert candidate_first.mission_id == candidate.id
    assert candidate_second.mission_id == candidate.id

    assert candidate_second.depends_on == {candidate_first.id}

    assert first.mission_id == source.id
    assert second.mission_id == source.id
    assert second.depends_on == {first.id}


def test_candidate_isolation_preserves_production_objects():
    missions, tasks, _ = build()

    source = Mission(goal="Production")
    task = Task(title="Production task", mission_id=source.id)
    source.add_task(task.id)

    missions.save(source)
    tasks.save(task)

    CandidateIsolationService(
        missions=missions,
        tasks=tasks,
    ).create(
        source_mission=source,
        task_ids=[task.id],
    )

    assert missions.get(source.id) is source
    assert tasks.get(task.id) is task
    assert source.task_ids == [task.id]


def test_candidate_isolation_rejects_task_from_other_mission():
    missions, tasks, _ = build()

    source = Mission(goal="Source")
    other = Mission(goal="Other")
    task = Task(title="Wrong task", mission_id=other.id)

    missions.save(source)
    missions.save(other)
    tasks.save(task)

    service = CandidateIsolationService(
        missions=missions,
        tasks=tasks,
    )

    try:
        service.create(
            source_mission=source,
            task_ids=[task.id],
        )
    except CandidateIsolationError as exc:
        assert "does not belong" in str(exc)
    else:
        raise AssertionError("expected CandidateIsolationError")


def test_candidate_isolation_emits_durable_boundary_events():
    missions, tasks, events = build()

    source = Mission(goal="Event test")
    task = Task(title="Task", mission_id=source.id)
    source.add_task(task.id)

    missions.save(source)
    tasks.save(task)

    CandidateIsolationService(
        missions=missions,
        tasks=tasks,
        events=events,
    ).create(
        source_mission=source,
        task_ids=[task.id],
    )

    assert [event.type for event in events.history()] == [
        "CandidateMissionCreated",
        "CandidateTaskCreated",
    ]
