from ocean.domain.agent import Agent
from ocean.domain.assignment import Assignment
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.domain.mission import Mission
from ocean.domain.task import Task
from ocean.orchestration.orchestrator import OrchestrationPorts, Orchestrator
from ocean.orchestration.types import AssignmentRequest, ExecutionIntent


class MissionRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item


class TaskRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item


class AssignmentRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item

    def list(self):
        return list(self.items.values())

    def transaction(self):
        from contextlib import contextmanager

        @contextmanager
        def _tx():
            yield

        return _tx()


class AgentRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item


class RuntimeStub:
    def __init__(self):
        self.calls = []

    def submit(self, agent_id, request, *, priority=0, dependencies=None):
        self.calls.append(
            {
                "agent_id": agent_id,
                "request": request,
                "priority": priority,
                "dependencies": set(dependencies or ()),
            }
        )

        class Item:
            execution_id = request.execution_id or "exec-dispatched"

        return Item()

    def mark_idle(self, agent_id):
        raise AssertionError("dispatch test must not use mark_idle")

    def mark_waiting(self, agent_id, *, task_id=None):
        raise AssertionError("dispatch test must not use mark_waiting")

    def mark_background(self, agent_id):
        raise AssertionError("dispatch test must not use mark_background")


def build():
    missions = MissionRepo()
    tasks = TaskRepo()
    assignments = AssignmentRepo()
    agents = AgentRepo()
    runtime = RuntimeStub()

    ports = OrchestrationPorts(
        missions=missions,
        tasks=tasks,
        assignments=assignments,
        agents=agents,
        agent_runtime=runtime,
        events=EventBus(),
    )

    return (
        Orchestrator(ports),
        missions,
        tasks,
        assignments,
        agents,
        runtime,
    )


def make_agent(agent_id="agent-1"):
    return Agent(
        id=agent_id,
        name="Agent",
        role="worker",
        capabilities={"research"},
    )


def test_dispatch_requires_queued_assignment():
    orchestrator, missions, tasks, assignments, agents, runtime = build()

    task = Task(title="Research")
    tasks.save(task)
    agent = make_agent()
    agents.save(agent)

    assignment = Assignment(
        task_id=task.id,
        agent_id=agent.id,
    )
    assignments.save(assignment)

    result = orchestrator.dispatch(
        assignment.id,
        ExecutionIntent(
            capability="research",
            operation="search",
        ),
    )

    assert result.success is False
    assert "queued" in result.error
    assert runtime.calls == []


def test_dispatch_submits_execution_and_keeps_assignment_queued_until_scheduler_dispatch():
    orchestrator, missions, tasks, assignments, agents, runtime = build()

    task = Task(title="Research")
    tasks.save(task)
    agent = make_agent()
    agents.save(agent)

    assignment = Assignment(
        task_id=task.id,
        agent_id=agent.id,
    )
    assignment.queue()
    assignments.save(assignment)

    result = orchestrator.dispatch(
        assignment.id,
        ExecutionIntent(
            capability="research",
            operation="search",
            arguments={"query": "quantum computing"},
        ),
    )

    assert result.success is True
    assert result.assignment_id == assignment.id
    assert result.execution_id == assignment.execution_id
    assert result.execution_id is not None

    stored = assignments.get(assignment.id)
    assert stored.status.value == "queued"
    assert stored.execution_id == assignment.execution_id

    assert len(runtime.calls) == 1
    call = runtime.calls[0]
    assert call["agent_id"] == agent.id
    assert call["request"].task_id == task.id
    assert call["request"].capability == "research"
    assert call["request"].operation == "search"
    assert call["request"].arguments == {"query": "quantum computing"}
    assert call["request"].agent_id == agent.id
    assert call["priority"] == assignment.priority


def test_scheduler_dispatch_event_activates_assignment():
    orchestrator, missions, tasks, assignments, agents, runtime = build()

    task = Task(title="Research")
    tasks.save(task)
    agent = make_agent()
    agents.save(agent)

    assignment = Assignment(
        task_id=task.id,
        agent_id=agent.id,
    )
    assignment.queue()
    assignments.save(assignment)

    result = orchestrator.dispatch(
        assignment.id,
        ExecutionIntent(
            capability="research",
            operation="search",
        ),
    )

    assert result.success is True
    assert assignments.get(assignment.id).status.value == "queued"

    execution_event = Event(
        type="ScheduledExecutionDispatched",
        payload={
            "id": assignment.execution_id,
            "task_id": task.id,
            "agent_id": agent.id,
            "priority": assignment.priority,
            "state": "dispatched",
        },
        aggregate_type="scheduled_execution",
        aggregate_id=assignment.execution_id,
        causation_id=assignment.id,
        source="scheduler",
    )

    failures = orchestrator.ports.events.publish(execution_event)
    assert failures == []

    stored = assignments.get(assignment.id)
    assert stored.status.value == "active"

    events = orchestrator.ports.events.history()
    assert events[-1].type == "TaskAssignmentActivated"
    assert events[-1].payload["assignment_id"] == assignment.id
    assert events[-1].payload["execution_id"] == assignment.execution_id


def test_dispatch_rejects_unknown_assignment():
    orchestrator, missions, tasks, assignments, agents, runtime = build()

    result = orchestrator.dispatch(
        "missing-assignment",
        ExecutionIntent(
            capability="research",
            operation="search",
        ),
    )

    assert result.success is False
    assert "unknown assignment" in result.error
    assert runtime.calls == []


def test_dispatch_passes_scheduler_dependencies():
    orchestrator, missions, tasks, assignments, agents, runtime = build()

    dependency_task = Task(title="Dependency")
    task = Task(
        title="Research",
        depends_on={dependency_task.id},
    )

    tasks.save(dependency_task)
    tasks.save(task)

    agent = make_agent()
    agents.save(agent)

    dependency_assignment = Assignment(
        task_id=dependency_task.id,
        agent_id=agent.id,
        execution_id="exec-dependency",
    )
    dependency_assignment.queue()
    assignments.save(dependency_assignment)

    assignment = Assignment(
        task_id=task.id,
        agent_id=agent.id,
    )
    assignment.queue()
    assignments.save(assignment)

    result = orchestrator.dispatch(
        assignment.id,
        ExecutionIntent(
            capability="research",
            operation="search",
        ),
    )

    assert result.success is True
    assert runtime.calls[0]["dependencies"] == {"exec-dependency"}


def test_dispatch_rejects_unresolved_dependency():
    orchestrator, missions, tasks, assignments, agents, runtime = build()

    dependency_task = Task(title="Dependency")
    task = Task(
        title="Research",
        depends_on={dependency_task.id},
    )

    tasks.save(dependency_task)
    tasks.save(task)

    agent = make_agent()
    agents.save(agent)

    assignment = Assignment(
        task_id=task.id,
        agent_id=agent.id,
    )
    assignment.queue()
    assignments.save(assignment)

    result = orchestrator.dispatch(
        assignment.id,
        ExecutionIntent(
            capability="research",
            operation="search",
        ),
    )

    assert result.success is False
    assert "dependency" in result.error.lower()
    assert runtime.calls == []
    assert assignments.get(assignment.id).status.value == "queued"

class FailingRuntimeStub(RuntimeStub):
    def __init__(self):
        super().__init__()
        self.failures_remaining = 1

    def submit(self, agent_id, request, *, priority=0, dependencies=None):
        self.calls.append({
            "agent_id": agent_id,
            "request": request,
            "priority": priority,
            "dependencies": set(dependencies or ()),
        })
        if self.failures_remaining:
            self.failures_remaining -= 1
            raise RuntimeError("simulated scheduler failure")

        class Item:
            execution_id = request.execution_id

        return Item()


class QueuedThenLostRuntimeStub(RuntimeStub):
    def __init__(self, event_bus):
        super().__init__()
        self.event_bus = event_bus

    def submit(self, agent_id, request, *, priority=0, dependencies=None):
        self.calls.append({"agent_id": agent_id, "request": request, "priority": priority, "dependencies": set(dependencies or ())})
        self.event_bus.publish(Event(type="ScheduledExecutionQueued", payload={"id": request.execution_id, "task_id": request.task_id, "agent_id": request.agent_id, "priority": priority, "state": "queued"}, aggregate_type="scheduled_execution", aggregate_id=request.execution_id, correlation_id=request.correlation_id, causation_id=request.causation_id, source="scheduler"))
        raise RuntimeError("result lost after scheduler admission")


def test_dispatch_reconciles_when_scheduler_admitted_before_result_loss():
    orchestrator, missions, tasks, assignments, agents, runtime = build()
    runtime = QueuedThenLostRuntimeStub(orchestrator.ports.events)
    orchestrator.ports.agent_runtime = runtime
    task = Task(title="Research")
    tasks.save(task)
    agent = make_agent()
    agents.save(agent)
    assignment = Assignment(task_id=task.id, agent_id=agent.id)
    assignment.queue()
    assignments.save(assignment)
    first = orchestrator.dispatch(assignment.id, ExecutionIntent(capability="research", operation="search"))
    assert first.success is False
    execution_id = assignments.get(assignment.id).execution_id
    assert execution_id is not None
    assert len(runtime.calls) == 1
    second = orchestrator.dispatch(assignment.id, ExecutionIntent(capability="research", operation="search"))
    assert second.success is True
    assert second.execution_id == execution_id
    assert second.metadata["reconciled"] is True
    assert second.metadata["scheduler_event_type"] == "ScheduledExecutionQueued"
    assert len(runtime.calls) == 1

def test_dispatch_persists_execution_id_before_runtime_failure():
    orchestrator, missions, tasks, assignments, agents, runtime = build()
    runtime = FailingRuntimeStub()
    orchestrator.ports.agent_runtime = runtime

    task = Task(title="Research")
    tasks.save(task)
    agent = make_agent()
    agents.save(agent)

    assignment = Assignment(task_id=task.id, agent_id=agent.id)
    assignment.queue()
    assignments.save(assignment)

    result = orchestrator.dispatch(
        assignment.id,
        ExecutionIntent(capability="research", operation="search"),
    )

    assert result.success is False
    assert "simulated scheduler failure" in result.error

    stored = assignments.get(assignment.id)
    assert stored.execution_id is not None
    assert stored.execution_id.startswith("exec_")


def test_dispatch_retry_reuses_same_execution_id():
    orchestrator, missions, tasks, assignments, agents, runtime = build()
    runtime = FailingRuntimeStub()
    orchestrator.ports.agent_runtime = runtime

    task = Task(title="Research")
    tasks.save(task)
    agent = make_agent()
    agents.save(agent)

    assignment = Assignment(task_id=task.id, agent_id=agent.id)
    assignment.queue()
    assignments.save(assignment)

    first = orchestrator.dispatch(
        assignment.id,
        ExecutionIntent(capability="research", operation="search"),
    )
    assert first.success is False

    execution_id = assignments.get(assignment.id).execution_id
    assert execution_id is not None

    second = orchestrator.dispatch(
        assignment.id,
        ExecutionIntent(capability="research", operation="search"),
    )

    assert second.success is True
    assert second.execution_id == execution_id
    assert len(runtime.calls) == 2
    assert runtime.calls[0]["request"].execution_id == execution_id
    assert runtime.calls[1]["request"].execution_id == execution_id
    assert assignments.get(assignment.id).execution_id == execution_id

