import pytest

from ocean.orchestration.types import ExecutionIntent


def test_execution_intent_requires_capability_and_operation():
    intent = ExecutionIntent(
        capability="research",
        operation="search",
    )

    assert intent.capability == "research"
    assert intent.operation == "search"


def test_execution_intent_defaults_arguments_and_resource_limits():
    intent = ExecutionIntent(
        capability="research",
        operation="search",
    )

    assert intent.arguments == {}
    assert intent.resource_limits is not None


def test_execution_intent_copies_arguments():
    arguments = {"query": "quantum computing"}

    intent = ExecutionIntent(
        capability="research",
        operation="search",
        arguments=arguments,
    )

    assert intent.arguments == arguments
    assert intent.arguments is not arguments


def test_execution_intent_rejects_empty_capability():
    with pytest.raises(ValueError):
        ExecutionIntent(
            capability="",
            operation="search",
        )


def test_execution_intent_rejects_empty_operation():
    with pytest.raises(ValueError):
        ExecutionIntent(
            capability="research",
            operation="",
        )


def test_execution_intent_is_immutable():
    intent = ExecutionIntent(
        capability="research",
        operation="search",
    )

    with pytest.raises(AttributeError):
        intent.capability = "other"
