from eventing.in_memory_store import InMemoryEventStore
from ocean.domain.event import Event
from ocean.observability import AuditReader, MetricsReader, TraceReader


def build_store():
    store = InMemoryEventStore()
    root = Event(type="MissionCreated", aggregate_type="mission", aggregate_id="m1", correlation_id="m1", source="mission")
    child = Event(type="TaskCreated", aggregate_type="task", aggregate_id="t1", correlation_id="m1", causation_id=root.id, source="planning")
    grandchild = Event(type="ExecutionStarted", aggregate_type="execution", aggregate_id="e1", correlation_id="m1", causation_id=child.id, source="runtime")
    sibling = Event(type="Other", source="other")
    for event in (root, child, grandchild, sibling):
        store.append(event)
    return store, root, child, grandchild, sibling


def test_audit_reader_preserves_authoritative_sequence():
    store, root, child, grandchild, sibling = build_store()
    audit = AuditReader(store)
    assert [item.sequence for item in audit.all_events()] == [1, 2, 3, 4]
    assert [item.id for item in audit.after_sequence(2)] == [grandchild.id, sibling.id]


def test_audit_queries():
    store, root, child, grandchild, sibling = build_store()
    audit = AuditReader(store)
    assert [x.id for x in audit.by_type("TaskCreated")] == [child.id]
    assert [x.id for x in audit.by_aggregate("task", "t1")] == [child.id]
    assert [x.id for x in audit.by_correlation("m1")] == [root.id, child.id, grandchild.id]
    assert [x.id for x in audit.by_causation(root.id)] == [child.id]
    assert [x.id for x in audit.by_source("runtime")] == [grandchild.id]


def test_causal_chain_reconstructs_root_to_event():
    store, root, child, grandchild, sibling = build_store()
    trace = TraceReader(store)
    assert [x.id for x in trace.causal_chain(grandchild.id)] == [root.id, child.id, grandchild.id]
    assert trace.causal_chain("missing") == []


def test_causally_related_reconstructs_descendants():
    store, root, child, grandchild, sibling = build_store()
    trace = TraceReader(store)
    assert [x.id for x in trace.causally_related(root.id)] == [root.id, child.id, grandchild.id]


def test_correlated_trace():
    store, root, child, grandchild, sibling = build_store()
    trace = TraceReader(store)
    assert [x.id for x in trace.correlated_events("m1")] == [root.id, child.id, grandchild.id]


def test_metrics_are_derived_from_history():
    store, root, child, grandchild, sibling = build_store()
    metrics = MetricsReader(store)
    assert metrics.type_counts() == {"MissionCreated": 1, "TaskCreated": 1, "ExecutionStarted": 1, "Other": 1}
    assert metrics.source_counts() == {"mission": 1, "planning": 1, "runtime": 1, "other": 1}
    assert [(x.key, x.count) for x in metrics.event_counts()] == [("ExecutionStarted", 1), ("MissionCreated", 1), ("Other", 1), ("TaskCreated", 1)]
