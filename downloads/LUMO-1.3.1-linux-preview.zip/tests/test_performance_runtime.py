from ocean.performance_runtime import Deadline,CancellationToken,Circuit,AdaptivePoller,ConcurrencyController

def test_deadline():
 d=Deadline(0,1); assert d.remaining(0.5)==.5 and not d.expired(0.5) and d.expired(1)
def test_cancel():
 c=CancellationToken();assert not c.cancelled;c.cancel();assert c.cancelled
 try:c.raise_if_cancelled()
 except RuntimeError:pass
 else:raise AssertionError
def test_circuit():
 c=Circuit(2,5);assert c.allow(0);assert not c.failure(0);assert c.failure(1);assert not c.allow(2);assert c.allow(6);c.success();assert c.allow(2)
def test_poller():
 p=AdaptivePoller(.1,.4);assert p.step(False)==.2;assert p.step(False)==.4;assert p.step(True)==.1
def test_concurrency():assert ConcurrencyController(8).workers(8,cpu=.5)==5

def test_fast_path_requires_independent_verification():
 from ocean.performance_runtime import run_fast_path
 assert run_fast_path(lambda: 4, allowed=True, verifier=lambda x: x == 4) == 4
 try: run_fast_path(lambda: 4, allowed=True)
 except RuntimeError: pass
 else: raise AssertionError
