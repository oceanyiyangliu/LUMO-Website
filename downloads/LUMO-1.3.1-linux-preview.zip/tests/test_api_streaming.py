import json
import sqlite3
import threading
import urllib.request

from ocean.api import LumoAPIServer
from ocean.domain.event import Event
from ocean.service import OceanService


def test_event_ndjson_and_mission_sse_streams(tmp_path):
    service=OceanService(repository_root=tmp_path); service.start()
    from ocean.accounts import AccountStore
    account=AccountStore(service._state_dir / "accounts.sqlite3").ensure_default()["id"]
    service.events.publish(Event(type="MissionSubmissionAccepted",aggregate_type="mission_submission",aggregate_id="m-stream",payload={"mission_id":"m-stream","account_id":account}))
    service.events.publish(Event(type="MissionStarted",aggregate_type="mission",aggregate_id="m-stream",payload={"mission_id":"m-stream"}))
    server=LumoAPIServer(service,port=0); thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
    base=f"http://{server.address[0]}:{server.address[1]}"
    try:
        with urllib.request.urlopen(base+"/api/events/stream?mission_id=m-stream",timeout=2) as response:
            assert response.headers["Content-Type"].startswith("application/x-ndjson")
            rows=[json.loads(line) for line in response.read().decode().splitlines() if line]
            assert [row["type"] for row in rows] == ["MissionSubmissionAccepted","MissionStarted"]
        with urllib.request.urlopen(base+"/api/missions/m-stream/stream",timeout=2) as response:
            assert response.headers["Content-Type"].startswith("text/event-stream")
            body=response.read().decode()
            assert "event" not in body
            assert "MissionStarted" in body
    finally:
        server.shutdown(); thread.join(timeout=2); service.stop()
