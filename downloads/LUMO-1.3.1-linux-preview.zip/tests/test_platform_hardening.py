from datetime import datetime, timedelta, timezone
from pathlib import Path
import tempfile

import pytest

from ocean.platform_hardening import (
    ArtifactVerifier,
    CleanupStack,
    FaultInjector,
    IdempotencyLedger,
    LeaseState,
    PermissionBoundary,
    WorkerLeaseBook,
)


def test_worker_leases_block_competing_workers_and_expire():
    book = WorkerLeaseBook()
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    lease = book.acquire("task", "worker-a", 10, lease_id="lease-a", now=now)
    assert lease.state is LeaseState.ACTIVE
    with pytest.raises(RuntimeError):
        book.acquire("task", "worker-b", 10, lease_id="lease-b", now=now + timedelta(seconds=1))
    book.heartbeat("lease-a", "worker-a", 10, now=now + timedelta(seconds=5))
    assert not book.expire_due(now=now + timedelta(seconds=10))
    expired = book.expire_due(now=now + timedelta(seconds=16))
    assert [x.lease_id for x in expired] == ["lease-a"]
    assert lease.state is LeaseState.EXPIRED


def test_idempotency_rejects_key_reuse_with_different_operation():
    ledger = IdempotencyLedger()
    fp = ledger.fingerprint("click", {"title": "Save"})
    assert ledger.commit("k", fp, {"ok": True}) == {"ok": True}
    assert ledger.get("k", fp) == {"ok": True}
    with pytest.raises(RuntimeError):
        ledger.get("k", ledger.fingerprint("delete", {"title": "Save"}))


def test_permission_boundary_supports_expiry_and_one_shot():
    boundary = PermissionBoundary()
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    boundary.grant("submit", scope="example.com", expires_at=now + timedelta(seconds=5), one_shot=True)
    assert boundary.allowed("submit", "example.com", now=now)
    assert not boundary.allowed("submit", "example.com", now=now)
    boundary.grant("read", expires_at=now + timedelta(seconds=1))
    assert not boundary.allowed("read", now=now + timedelta(seconds=2))


def test_artifact_verifier_records_concrete_file_evidence():
    with tempfile.TemporaryDirectory() as d:
        path = Path(d) / "result.txt"
        path.write_text("verified")
        result = ArtifactVerifier.file_exists(str(path))
        assert result.passed
        assert result.evidence[0]["size"] == 8
        assert len(result.evidence[0]["sha256"]) == 64


def test_cleanup_stack_runs_lifo_and_collects_failures():
    order = []
    cleanup = CleanupStack()
    cleanup.push("first", lambda: order.append("first"))
    cleanup.push("bad", lambda: (_ for _ in ()).throw(RuntimeError("boom")))
    cleanup.push("last", lambda: order.append("last"))
    errors = cleanup.close()
    assert order == ["last", "first"]
    assert errors == [{"name": "bad", "error": "boom"}]


def test_fault_injector_is_deterministic():
    injector = FaultInjector(["after_commit"])
    assert injector.enabled("after_commit")
    with pytest.raises(RuntimeError, match="after_commit"):
        injector.trip("after_commit")
    injector.trip("other")
