from datetime import datetime, timezone

from ocean.domain.decision import Decision
from ocean.domain.plan import PlanRevision, PlanStatus
from ocean.domain.work_graph import (
    WorkEdge,
    WorkEdgeKind,
    WorkGraph,
    WorkNode,
    WorkNodeKind,
)
from persistence.serializers.decision import DecisionSerializer
from persistence.serializers.plan import PlanRevisionSerializer
from persistence.serializers.work_graph import WorkGraphSerializer


def test_decision_serializer_round_trip():
    created_at = datetime(2026, 1, 1, 10, 0, tzinfo=timezone.utc)

    decision = Decision(
        mission_id="mission-1",
        kind="decomposition",
        objective="Build a research system",
        rationale="Parallel work reduces elapsed time.",
        alternatives=("serial", "parallel"),
        selected_option="parallel",
        confidence=0.92,
        evidence=("benchmark-1", "constraint-2"),
        metadata={"strategy": {"parallel": True}},
        id="decision-1",
        created_at=created_at,
    )

    restored = DecisionSerializer().deserialize(
        DecisionSerializer().serialize(decision)
    )

    assert restored == decision


def test_plan_serializer_round_trip():
    created_at = datetime(2026, 1, 1, 10, 0, tzinfo=timezone.utc)

    plan = PlanRevision(
        mission_id="mission-1",
        revision=2,
        decision_id="decision-2",
        graph_id="graph-2",
        parent_revision_id="plan-1",
        status=PlanStatus.ACTIVE,
        reason="Improved after new evidence.",
        metadata={"policy": {"parallelism": 8}},
        id="plan-2",
        created_at=created_at,
    )

    restored = PlanRevisionSerializer().deserialize(
        PlanRevisionSerializer().serialize(plan)
    )

    assert restored == plan


def test_work_graph_serializer_round_trip():
    task_node = WorkNode(
        kind=WorkNodeKind.TASK,
        task_id="task-1",
        metadata={"role": {"specialist": True}},
        id="node-1",
    )
    condition = WorkNode(
        kind=WorkNodeKind.CONDITION,
        id="node-2",
    )
    edge = WorkEdge(
        source_node_id="node-1",
        target_node_id="node-2",
        kind=WorkEdgeKind.CONDITIONAL,
        condition="result == success",
        id="edge-1",
    )

    graph = WorkGraph(
        mission_id="mission-1",
        plan_revision_id="plan-1",
        nodes=(task_node, condition),
        edges=(edge,),
        metadata={"execution": {"parallel": True}},
        id="graph-1",
    )

    restored = WorkGraphSerializer().deserialize(
        WorkGraphSerializer().serialize(graph)
    )

    assert restored == graph
