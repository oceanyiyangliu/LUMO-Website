from datetime import datetime, timezone, timedelta
import sqlite3
from eventing.store import EventStore
from eventing.in_memory_store import InMemoryEventStore
from ocean.domain.event import Event
from ocean.observability.metrics import OperationalMetricsReader

def test_latency_queue_and_provider_metrics():
    s=InMemoryEventStore(); t=datetime.now(timezone.utc)
    s.append(Event("MissionStarted",aggregate_id="m",at=t,sequence=1)); s.append(Event("MissionCompleted",aggregate_id="m",at=t+timedelta(seconds=3),sequence=2))
    s.append(Event("ScheduledExecutionQueued",aggregate_id="e",payload={"provider":"x"},sequence=3))
    s.append(Event("ExecutionFailed",aggregate_id="f",payload={"provider":"x"},sequence=4))
    r=OperationalMetricsReader(s); m=r.latencies()[0]; assert m.key=="mission" and m.average_seconds==3; assert r.queue_depth()==1; assert r.provider_health()["x"]["failure"]==1
