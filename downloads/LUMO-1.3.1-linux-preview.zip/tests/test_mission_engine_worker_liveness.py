"""Deterministic tests for MissionEngine worker liveness / stale-work handling.

Background (see review report): MissionEngine.run() previously waited on
`future.result()` with NO timeout when dispatching objectives to a
ThreadPoolExecutor. A worker (thread) that remained technically alive but
never returned -- e.g. blocked forever in an untrusted model call or a hung
subprocess wait -- would block the entire mission forever, with no
detection, no recovery, and no durable evidence.

The fix adds an opt-in `objective_lease_seconds` bound. When set:
  * `ObjectiveLeaseAcquired` is published when an attempt starts.
  * if the attempt does not finish within the lease, `ObjectiveLeaseExpired`
    is published and the objective is treated as a retryable "stale"
    failure, feeding the SAME bounded retry/replan path used for any other
    retryable failure (no new unbounded retry loop).
  * a late/superseded result from the original (still-running) worker
    thread is recorded as durable evidence (`ObjectiveStaleAttemptDiscarded`)
    but is never re-applied -- no double ObjectiveCompleted, no double
    promotion, no re-running of already-completed work.

None of these tests use long/arbitrary sleeps to fake elapsed time: lease
windows are kept intentionally tiny (tens of milliseconds), all
synchronization between test code and background workers uses
`threading.Event`, and any simulated "hang" is itself bounded so no test can
leave a genuinely eternal non-daemon thread behind at interpreter exit.
"""
from __future__ import annotations

import threading
import time
import os

from ocean.domain.event_bus import EventBus
from ocean.domain.capability import CapabilityRegistry, CapabilitySpec, OperationSpec
from ocean.domain.enums import RiskLevel
from ocean.orchestration.mission_engine import (
    MissionEngine,
    MissionObjective,
    MissionObjectiveResult,
    MissionPlan,
)
from ocean.orchestration.runtime_adapter import ExecutionRuntimeMissionObjectiveAdapter
from runtime import ExecutionRuntime, ExecutorRegistry, ExecutionRequest, ExecutionResult
from runtime.isolation import ProcessIsolationBackend
from runtime.control import CancellationToken

LEASE_SECONDS = 0.05
# Upper bound on any simulated "hang" so a leaked background thread always
# terminates on its own well before the test process exits.
MAX_SIMULATED_HANG_SECONDS = 2.0


class LeaseIntegrationExecutor:
    def execute(self, request, context):
        if request.arguments["attempt"] == 1:
            with open(request.arguments["pid_path"], "w", encoding="utf-8") as handle:
                handle.write(str(os.getpid()))
            while True:
                time.sleep(0.01)
        return ExecutionResult.succeeded({"attempt": request.arguments["attempt"]})


class _FixedPlanOnceThenDone:
    """Returns the given plan once, then an empty plan forever after."""

    def __init__(self, plan: MissionPlan) -> None:
        self._plan = plan
        self._served = False

    def plan(self, mission_id, goal, *, completed_objectives=(), previous_results=()):
        if not self._served:
            self._served = True
            return self._plan
        return MissionPlan(mission_id=mission_id, goal=goal, objectives=())


def _single_objective_plan(mission_id: str, objective_id: str = "obj-1") -> MissionPlan:
    return MissionPlan(
        mission_id=mission_id,
        goal="do the thing",
        objectives=(
            MissionObjective(objective_id=objective_id, objective="do the thing"),
        ),
    )


def _poll_until(predicate, *, timeout: float = 1.0, interval: float = 0.005) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return True
        time.sleep(interval)
    return predicate()


def test_healthy_worker_completes_within_lease_no_stale_events():
    events = EventBus()
    mission_id = "m-healthy"
    plan = _single_objective_plan(mission_id)

    class InstantExecutor:
        def __init__(self):
            self.calls = 0

        def execute(self, _mission_id, objective):
            self.calls += 1
            return MissionObjectiveResult(
                objective_id=objective.objective_id,
                objective=objective.objective,
                status="completed",
                metadata={"work_type": objective.work_type},
            )

    executor = InstantExecutor()
    engine = MissionEngine(
        planner=_FixedPlanOnceThenDone(plan),
        executor=executor,
        events=events,
        objective_lease_seconds=LEASE_SECONDS,
    )

    result = engine.run("do the thing", mission_id=mission_id)

    assert result.status == "completed"
    assert executor.calls == 1
    assert not events.history("ObjectiveLeaseExpired")
    assert not events.history("ObjectiveStaleAttemptDiscarded")
    assert len(events.history("ObjectiveCompleted")) == 1


def test_stale_worker_is_detected_and_recovered_by_retry():
    events = EventBus()
    mission_id = "m-stale"
    plan = _single_objective_plan(mission_id)

    class HangsOnceThenSucceedsExecutor:
        """First call blocks past the lease; every later call succeeds
        immediately. The first call's block is itself bounded so the
        background thread cannot outlive the test process."""

        def __init__(self):
            self.calls = 0
            self._first_call_gate = threading.Event()

        def execute(self, _mission_id, objective):
            self.calls += 1
            if self.calls == 1:
                # Blocks well past LEASE_SECONDS, but never forever.
                self._first_call_gate.wait(timeout=MAX_SIMULATED_HANG_SECONDS)
                return MissionObjectiveResult(
                    objective_id=objective.objective_id,
                    objective=objective.objective,
                    status="completed",
                    metadata={"work_type": objective.work_type, "late": True},
                )
            return MissionObjectiveResult(
                objective_id=objective.objective_id,
                objective=objective.objective,
                status="completed",
                metadata={"work_type": objective.work_type},
            )

    executor = HangsOnceThenSucceedsExecutor()
    engine = MissionEngine(
        planner=_FixedPlanOnceThenDone(plan),
        executor=executor,
        events=events,
        objective_lease_seconds=LEASE_SECONDS,
        max_concurrent_objectives=1,
    )

    result = engine.run("do the thing", mission_id=mission_id, max_replans=3)

    assert result.status == "completed"
    assert result.completed_objectives == ("obj-1",)
    assert executor.calls == 2  # stale attempt + one successful retry
    assert len(events.history("ObjectiveLeaseExpired")) == 1
    # Only the retry's completion counts -- not two.
    assert len(events.history("ObjectiveCompleted")) == 1

    # Let the original stale worker thread finish so it doesn't leak past
    # this test.
    executor._first_call_gate.set()


def test_duplicate_recovery_race_never_double_applies_late_result():
    events = EventBus()
    mission_id = "m-race"
    plan = _single_objective_plan(mission_id)
    release_stale_worker = threading.Event()

    class HangsThenBothEventuallySucceedExecutor:
        def __init__(self):
            self.calls = 0

        def execute(self, _mission_id, objective):
            self.calls += 1
            if self.calls == 1:
                # The original attempt: goes stale, but is later released by
                # the test (simulating it eventually finishing on its own,
                # in the background, after being superseded).
                release_stale_worker.wait(timeout=MAX_SIMULATED_HANG_SECONDS)
                return MissionObjectiveResult(
                    objective_id=objective.objective_id,
                    objective=objective.objective,
                    status="completed",
                    metadata={"work_type": objective.work_type, "late": True},
                )
            # The retry: succeeds immediately.
            return MissionObjectiveResult(
                objective_id=objective.objective_id,
                objective=objective.objective,
                status="completed",
                metadata={"work_type": objective.work_type},
            )

    executor = HangsThenBothEventuallySucceedExecutor()
    engine = MissionEngine(
        planner=_FixedPlanOnceThenDone(plan),
        executor=executor,
        events=events,
        objective_lease_seconds=LEASE_SECONDS,
        max_concurrent_objectives=1,
    )

    # The mission completes via the retry while the original stale attempt
    # is still blocked (not yet released).
    result = engine.run("do the thing", mission_id=mission_id, max_replans=3)
    assert result.status == "completed"
    assert result.completed_objectives == ("obj-1",)
    assert len(events.history("ObjectiveCompleted")) == 1

    # Now let the original, superseded worker finish -- a genuine race
    # between "recovery already happened" and "the stale worker finally
    # returns".
    release_stale_worker.set()
    assert _poll_until(
        lambda: len(events.history("ObjectiveStaleAttemptDiscarded")) == 1,
        timeout=MAX_SIMULATED_HANG_SECONDS + 0.5,
    )

    # The late result must never have produced a second ObjectiveCompleted.
    assert len(events.history("ObjectiveCompleted")) == 1
    discarded = events.history("ObjectiveStaleAttemptDiscarded")[0]
    assert discarded.payload["objective_id"] == "obj-1"
    assert discarded.payload["superseding_attempt_id"] is not None
    assert discarded.payload["superseding_attempt_id"] != discarded.payload["attempt_id"]


def test_completed_objective_is_never_rerun_after_lease_recovery():
    events = EventBus()
    mission_id = "m-no-rerun"
    plan = _single_objective_plan(mission_id)

    class HangsOnceThenSucceedsExecutor:
        def __init__(self):
            self.calls = 0
            self._gate = threading.Event()

        def execute(self, _mission_id, objective):
            self.calls += 1
            if self.calls == 1:
                self._gate.wait(timeout=MAX_SIMULATED_HANG_SECONDS)
            return MissionObjectiveResult(
                objective_id=objective.objective_id,
                objective=objective.objective,
                status="completed",
                metadata={"work_type": objective.work_type},
            )

    executor = HangsOnceThenSucceedsExecutor()
    engine = MissionEngine(
        planner=_FixedPlanOnceThenDone(plan),
        executor=executor,
        events=events,
        objective_lease_seconds=LEASE_SECONDS,
        max_concurrent_objectives=1,
    )

    result = engine.run("do the thing", mission_id=mission_id, max_replans=3)

    assert result.status == "completed"
    # Exactly one objective in the final ledger -- not duplicated.
    assert result.completed_objectives == ("obj-1",)
    assert result.objective_results.count  # sanity: attribute exists
    completed_ids = [
        e.payload["objective_id"] for e in events.history("ObjectiveCompleted")
    ]
    assert completed_ids == ["obj-1"]

    executor._gate.set()


def test_restart_during_stale_execution_resumes_without_rerunning_completed_work():
    """Simulates a process restart: a fresh MissionEngine, sharing only the
    persisted event history (here: the same in-memory EventBus a durable
    store would replay), must resume the mission using the SAME persisted
    plan, must not rerun the objective that already completed, and must
    recover the objective that was stale/unresolved at the moment of
    "crash" without ever double-counting it.
    """
    events = EventBus()
    mission_id = "m-restart"
    plan = MissionPlan(
        mission_id=mission_id,
        goal="two independent objectives",
        objectives=(
            MissionObjective(objective_id="obj-a", objective="research the payments module"),
            MissionObjective(objective_id="obj-b", objective="harden the terminal capability sandbox"),
        ),
    )

    class SharedExecutor:
        """obj-a always succeeds instantly. obj-b hangs past its lease on
        every call made through `engine1` (simulating a stall that outlives
        the crashed process) and succeeds instantly on `engine2` (simulating
        that whatever caused the stall is gone after restart)."""

        def __init__(self):
            self.calls_a = 0
            self.calls_b = 0
            self.obj_b_should_hang = True
            self._gate = threading.Event()

        def execute(self, _mission_id, objective):
            if objective.objective_id == "obj-a":
                self.calls_a += 1
                return MissionObjectiveResult(
                    objective_id="obj-a",
                    objective=objective.objective,
                    status="completed",
                    metadata={"work_type": objective.work_type},
                )

            self.calls_b += 1
            if self.obj_b_should_hang:
                self._gate.wait(timeout=MAX_SIMULATED_HANG_SECONDS)
            return MissionObjectiveResult(
                objective_id="obj-b",
                objective=objective.objective,
                status="completed",
                metadata={"work_type": objective.work_type},
            )

    executor = SharedExecutor()

    engine1 = MissionEngine(
        planner=_FixedPlanOnceThenDone(plan),
        executor=executor,
        events=events,
        objective_lease_seconds=LEASE_SECONDS,
        max_concurrent_objectives=2,
    )
    # obj-b keeps going stale on every attempt made through engine1 -- model
    # the process being killed while obj-b is durably unresolved.
    result1 = engine1.run("two independent objectives", mission_id=mission_id, max_replans=1)

    assert result1.status in {"replan_limit_reached"}
    assert "obj-a" in result1.completed_objectives
    assert "obj-b" not in result1.completed_objectives
    assert executor.calls_a == 1  # obj-a completed once, never retried

    # "Restart": whatever caused obj-b to hang is resolved now.
    executor.obj_b_should_hang = False

    engine2 = MissionEngine(
        planner=_FixedPlanOnceThenDone(plan),
        executor=executor,
        events=events,  # same durable event history, simulating replay
        objective_lease_seconds=LEASE_SECONDS,
        max_concurrent_objectives=2,
    )
    result2 = engine2.run("two independent objectives", mission_id=mission_id, max_replans=3)

    assert result2.status == "completed"
    assert set(result2.completed_objectives) == {"obj-a", "obj-b"}
    # obj-a must not have been re-executed after restart.
    assert executor.calls_a == 1
    assert len(events.history("ObjectiveCompleted")) == len(
        [e for e in events.history("ObjectiveCompleted") if e.payload["objective_id"] == "obj-a"]
    ) + len([e for e in events.history("ObjectiveCompleted") if e.payload["objective_id"] == "obj-b"])
    completed_a_events = [
        e for e in events.history("ObjectiveCompleted") if e.payload["objective_id"] == "obj-a"
    ]
    assert len(completed_a_events) == 1

    # Release any leaked stale worker thread from engine1's attempts.
    executor._gate.set()


def test_mission_lease_terminates_process_and_retries_through_runtime(tmp_path):
    events = EventBus()
    mission_id = "m-process-runtime"
    plan = _single_objective_plan(mission_id)
    capabilities = CapabilityRegistry()
    capabilities.register(
        CapabilitySpec(
            name="test",
            description="test",
            execution_strategy="test_executor",
            operations={
                "run": OperationSpec(
                    name="run",
                    description="run",
                    risk_level=RiskLevel.SAFE,
                ),
            },
        )
    )
    executors = ExecutorRegistry()
    executors.register("test_executor", LeaseIntegrationExecutor())
    runtime = ExecutionRuntime(
        capabilities=capabilities,
        policy=__import__("ocean.domain.policy", fromlist=["PolicyEngine"]).PolicyEngine(),
        executors=executors,
        isolation=ProcessIsolationBackend(),
    )

    attempts = []
    pid_path = tmp_path / "mission-worker.pid"

    def request_factory(current_mission_id, objective):
        attempts.append(objective.objective_id)
        return ExecutionRequest(
            task_id=objective.objective_id,
            capability="test",
            operation="run",
            mission_id=current_mission_id,
            execution_id=f"execution-{len(attempts)}",
            arguments={
                "attempt": len(attempts),
                "pid_path": str(pid_path),
            },
        )

    adapter = ExecutionRuntimeMissionObjectiveAdapter(
        runtime=runtime,
        request_factory=request_factory,
    )
    engine = MissionEngine(
        planner=_FixedPlanOnceThenDone(plan),
        executor=object(),
        events=events,
        objective_lease_seconds=0.75,
        max_concurrent_objectives=1,
        execution_adapter=adapter,
    )

    result = engine.run("do the thing", mission_id=mission_id, max_replans=3)

    assert result.status == "completed"
    assert attempts == ["obj-1", "obj-1"]
    assert len(events.history("ObjectiveLeaseExpired")) == 1
    assert len(events.history("ObjectiveCompleted")) == 1
    worker_pid = int(pid_path.read_text(encoding="utf-8"))
    assert not __import__("psutil").pid_exists(worker_pid)


def test_mission_cancellation_does_not_wait_for_hung_objective():
    events = EventBus()
    mission_id = "m-cancel-live"
    plan = _single_objective_plan(mission_id)
    release = threading.Event()

    class HungExecutor:
        def execute(self, _mission_id, _objective):
            release.wait(timeout=0.5)
            return MissionObjectiveResult(
                objective_id="obj-1",
                objective="do the thing",
                status="completed",
                metadata={"work_type": "implementation"},
            )

    cancelled = threading.Event()
    threading.Timer(0.05, cancelled.set).start()
    started = time.monotonic()
    result = MissionEngine(
        planner=_FixedPlanOnceThenDone(plan),
        executor=HungExecutor(),
        events=events,
        objective_lease_seconds=1.0,
    ).run("do the thing", mission_id=mission_id, cancelled=cancelled.is_set)
    elapsed = time.monotonic() - started
    release.set()

    assert result.status == "cancelled"
    assert result.metadata["cancelled"] is True
    assert elapsed < 0.5
    assert len(events.history("MissionCancelled")) == 1
    assert not events.history("ObjectiveCompleted")
