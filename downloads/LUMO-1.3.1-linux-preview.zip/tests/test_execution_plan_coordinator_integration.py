import time

from ocean.domain.agent import Agent
from ocean.domain.event import Event
from ocean.domain.event_bus import EventBus
from ocean.domain.task import Task
from ocean.domain.mission import Mission
from ocean.domain.plan import PlanRevision
from ocean.domain.work_graph import (
    WorkEdge,
    WorkEdgeKind,
    WorkGraph,
    WorkNode,
    WorkNodeKind,
)
from ocean.domain.enums import AssignmentStatus, RiskLevel
from ocean.execution.compiler import ExecutionIntentResolver, PlanExecutionCompiler
from ocean.orchestration.execution_plan_coordinator import (
    ExecutionPlanCoordinator,
)
from ocean.orchestration.execution_plan_provider import (
    RepositoryExecutionPlanProvider,
)
from ocean.orchestration.execution_plan_runner import ExecutionPlanRunner
from ocean.orchestration.orchestrator import (
    OrchestrationPorts,
    Orchestrator,
)
from ocean.orchestration.types import ExecutionIntent
from ocean.domain.capability import CapabilityRegistry, CapabilitySpec, OperationSpec
from ocean.domain.policy import PolicyEngine
from runtime import (
    AgentRuntime,
    ExecutionSupervisor,
    Scheduler,
)
from runtime.executor import CapabilityExecutor
from runtime.types import ExecutionRequest, ExecutionResult
from runtime.agent_execution_lifecycle import AgentExecutionLifecycle
from persistence.in_memory import InMemoryRepository


class SuccessfulExecutor(CapabilityExecutor):
    def execute(self, request, context):
        return ExecutionResult.succeeded(
            {"execution_id": request.execution_id}
        )


class IntentResolver(ExecutionIntentResolver):
    def resolve(self, task):
        return ExecutionIntent(
            capability="test",
            operation="run",
            arguments={"task_id": task.id},
        )


class AgentResolver:
    def __init__(self, agent_id):
        self.agent_id = agent_id

    def resolve(self, step):
        return self.agent_id


class PlanProvider:
    def __init__(self, plan):
        self.plan = plan

    def get(self, plan_revision_id):
        if plan_revision_id != self.plan.plan_revision_id:
            raise KeyError(plan_revision_id)
        return self.plan


def wait_until(predicate, timeout=3.0):
    deadline = time.monotonic() + timeout

    while time.monotonic() < deadline:
        if predicate():
            return True
        time.sleep(0.01)

    return False


def build():
    events = EventBus()

    capabilities = CapabilityRegistry()
    capabilities.register(
        CapabilitySpec(
            name="test",
            description="Integration test capability",
            execution_strategy="test_executor",
            operations={
                "run": OperationSpec(
                    name="run",
                    description="Run integration operation",
                    risk_level=RiskLevel.SAFE,
                )
            },
        )
    )

    from runtime.executor import ExecutorRegistry

    executors = ExecutorRegistry()
    executors.register("test_executor", SuccessfulExecutor())

    from runtime.runtime import ExecutionRuntime

    execution_runtime = ExecutionRuntime(
        capabilities=capabilities,
        policy=PolicyEngine(),
        executors=executors,
        event_bus=events,
    )

    supervisor = ExecutionSupervisor(execution_runtime)

    scheduler = Scheduler(
        supervisor,
        event_bus=events,
        max_concurrent=4,
    )

    agent_runtime = AgentRuntime(scheduler)

    missions = InMemoryRepository()
    tasks = InMemoryRepository()
    assignments = InMemoryRepository()
    agents = InMemoryRepository()
    plan_revisions = InMemoryRepository()
    work_graphs = InMemoryRepository()

    missions.save(
        Mission(
            id="mission-1",
            goal="Integration test mission",
        )
    )

    AgentExecutionLifecycle(
        event_bus=events,
        registry=agent_runtime.registry,
        controller=agent_runtime.controller,
    )

    ports = OrchestrationPorts(
        missions=missions,
        tasks=tasks,
        assignments=assignments,
        agents=agents,
        agent_runtime=agent_runtime,
        events=events,
    )

    orchestrator = Orchestrator(ports)

    return (
        events,
        supervisor,
        scheduler,
        agent_runtime,
        missions,
        tasks,
        assignments,
        agents,
        plan_revisions,
        work_graphs,
        orchestrator,
    )


def make_plan(task_a, task_b):
    node_a = WorkNode(
        id="node-a",
        kind=WorkNodeKind.TASK,
        task_id=task_a.id,
    )
    node_b = WorkNode(
        id="node-b",
        kind=WorkNodeKind.TASK,
        task_id=task_b.id,
    )

    graph = WorkGraph(
        mission_id="mission-1",
        plan_revision_id="plan-1",
        nodes=(node_a, node_b),
        edges=(
            WorkEdge(
                id="edge-a-b",
                source_node_id="node-a",
                target_node_id="node-b",
                kind=WorkEdgeKind.DEPENDENCY,
            ),
        ),
    )

    compiler = PlanExecutionCompiler()

    execution_plan = compiler.compile(
        graph,
        (task_a, task_b),
        IntentResolver(),
    )

    return execution_plan, graph


def test_completion_event_drives_next_frontier_and_duplicate_completion_is_idempotent():
    (
        events,
        supervisor,
        scheduler,
        agent_runtime,
        missions,
        tasks,
        assignments,
        agents,
        plan_revisions,
        work_graphs,
        orchestrator,
    ) = build()

    try:
        agent = Agent(
            id="agent-integration",
            name="Integration Agent",
            role="worker",
            capabilities={"test"},
        )

        agents.save(agent)
        agent_runtime.register(agent)

        task_a = Task(
            id="task-a",
            title="First task",
            mission_id="mission-1",
        )
        task_b = Task(
            id="task-b",
            title="Second task",
            mission_id="mission-1",
        )

        tasks.save(task_a)
        tasks.save(task_b)

        mission = missions.get("mission-1")
        if mission is None:
            raise AssertionError("integration mission was not created")
        mission.add_task(task_a.id)
        mission.add_task(task_b.id)
        missions.save(mission)

        plan, graph = make_plan(task_a, task_b)

        runner = ExecutionPlanRunner(
            orchestrator,
            AgentResolver(agent.id),
        )

        coordinator = ExecutionPlanCoordinator(
            events=events,
            assignments=assignments,
            plan_provider=PlanProvider(plan),
            runner=runner,
        )

        first = runner.start(plan)

        assert first.success is True
        assert first.queued_node_ids == ("node-a",)
        assert first.blocked_node_ids == ("node-b",)

        first_execution_id = first.execution_id_for("node-a")

        scheduler.start()

        assert wait_until(
            lambda: assignments.get(
                first.assignment_id_for("node-a")
            ).status is AssignmentStatus.COMPLETED
        )

        assert wait_until(
            lambda: any(
                assignment.metadata.get("execution_node_id") == "node-b"
                and assignment.execution_id is not None
                for assignment in assignments.list()
            )
        )

        node_b_assignment = [
            assignment
            for assignment in assignments.list()
            if assignment.metadata.get("execution_node_id") == "node-b"
        ][0]

        assert node_b_assignment.execution_id is not None

        scheduled_b = scheduler.get(node_b_assignment.execution_id)

        assert scheduled_b is not None
        assert first_execution_id in scheduled_b.dependencies

        completion_events = [
            event
            for event in events.history()
            if event.type == "TaskAssignmentCompleted"
            and event.aggregate_id == first.assignment_id_for("node-a")
        ]

        assert completion_events

        failures = events.publish(completion_events[-1])

        assert failures == []

        node_b_assignments_after_duplicate = [
            assignment
            for assignment in assignments.list()
            if assignment.metadata.get("execution_node_id") == "node-b"
        ]

        assert len(node_b_assignments_after_duplicate) == 1

        assert wait_until(
            lambda: assignments.get(node_b_assignment.id).status
            is AssignmentStatus.COMPLETED
        )

    finally:
        scheduler.stop()
        supervisor.shutdown()


def test_coordinator_reconstructs_frontier_after_restart_without_duplicate_submission():
    (
        events,
        supervisor,
        scheduler,
        agent_runtime,
        missions,
        tasks,
        assignments,
        agents,
        plan_revisions,
        work_graphs,
        orchestrator,
    ) = build()

    try:
        agent = Agent(
            id="agent-restart",
            name="Restart Agent",
            role="worker",
            capabilities={"test"},
        )
        agents.save(agent)
        agent_runtime.register(agent)

        task_a = Task(
            id="restart-task-a",
            title="Restart first task",
            mission_id="mission-1",
        )
        task_b = Task(
            id="restart-task-b",
            title="Restart second task",
            mission_id="mission-1",
        )

        tasks.save(task_a)
        tasks.save(task_b)

        mission = missions.get("mission-1")
        if mission is None:
            raise AssertionError("integration mission was not created")

        mission.add_task(task_a.id)
        mission.add_task(task_b.id)
        missions.save(mission)

        plan, graph = make_plan(task_a, task_b)

        plan_revisions.save(
            PlanRevision(
                id=plan.plan_revision_id,
                mission_id="mission-1",
                revision=1,
                decision_id="decision-restart",
                graph_id=graph.id,
            )
        )
        work_graphs.save(graph)

        provider_before_restart = RepositoryExecutionPlanProvider(
            plan_revisions=plan_revisions,
            work_graphs=work_graphs,
            tasks=tasks,
            resolver=IntentResolver(),
        )

        runner_before_restart = ExecutionPlanRunner(
            orchestrator,
            AgentResolver(agent.id),
        )

        coordinator_before_restart = ExecutionPlanCoordinator(
            events=events,
            assignments=assignments,
            plan_provider=provider_before_restart,
            runner=runner_before_restart,
        )

        first = runner_before_restart.start(
            provider_before_restart.get(plan.plan_revision_id)
        )

        assert first.success is True
        assert first.queued_node_ids == ("node-a",)

        scheduler.start()

        node_a_assignment_id = first.assignment_id_for("node-a")

        assert wait_until(
            lambda: assignments.get(node_a_assignment_id).status
            is AssignmentStatus.COMPLETED
        )

        assert wait_until(
            lambda: any(
                assignment.metadata.get("execution_node_id") == "node-b"
                and assignment.execution_id is not None
                for assignment in assignments.list()
            )
        )

        node_b_assignments_before_restart = [
            assignment
            for assignment in assignments.list()
            if assignment.metadata.get("execution_node_id") == "node-b"
        ]

        assert len(node_b_assignments_before_restart) == 1

        node_b_before_restart = node_b_assignments_before_restart[0]
        assert node_b_before_restart.execution_id is not None

        node_a_execution_id = first.execution_id_for("node-a")

        scheduled_b = scheduler.get(node_b_before_restart.execution_id)

        assert scheduled_b is not None
        assert node_a_execution_id in scheduled_b.dependencies

        # Simulate process restart:
        #
        # - old coordinator/provider are discarded;
        # - repositories remain durable;
        # - new coordinator/provider must reconstruct progress.
        del coordinator_before_restart
        del provider_before_restart
        del runner_before_restart

        provider_after_restart = RepositoryExecutionPlanProvider(
            plan_revisions=plan_revisions,
            work_graphs=work_graphs,
            tasks=tasks,
            resolver=IntentResolver(),
        )

        runner_after_restart = ExecutionPlanRunner(
            orchestrator,
            AgentResolver(agent.id),
        )

        coordinator_after_restart = ExecutionPlanCoordinator(
            events=events,
            assignments=assignments,
            plan_provider=provider_after_restart,
            runner=runner_after_restart,
        )

        recovered = coordinator_after_restart.advance(
            plan.plan_revision_id
        )

        assert recovered.success is True
        assert recovered.queued_node_ids == ()
        assert recovered.assignment_ids == {}
        assert recovered.execution_ids == {}

        node_b_assignments_after_restart = [
            assignment
            for assignment in assignments.list()
            if assignment.metadata.get("execution_node_id") == "node-b"
        ]

        assert len(node_b_assignments_after_restart) == 1

        assert (
            node_b_assignments_after_restart[0].id
            == node_b_before_restart.id
        )
        assert (
            node_b_assignments_after_restart[0].execution_id
            == node_b_before_restart.execution_id
        )

    finally:
        scheduler.stop()
        supervisor.shutdown()
