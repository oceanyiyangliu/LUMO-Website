from __future__ import annotations

import json
from types import SimpleNamespace

from ocean.computer_agent import COMPUTER_TOOLS, ComputerUseAgent
from runtime.types import ExecutionResult


def test_computer_tools_are_strict_function_contracts():
    names = {tool["name"] for tool in COMPUTER_TOOLS}
    assert names == {
        "screenshot", "open_url", "launch_app", "click", "double_click",
        "drag", "move", "accessibility_snapshot", "click_element", "type_text", "key_press", "hotkey", "scroll", "action_batch", "wait",
    }
    assert all(tool["strict"] is True for tool in COMPUTER_TOOLS)


def test_agent_executes_local_model_function_calls_and_stops(monkeypatch, tmp_path):
    image = tmp_path / "screen.png"
    image.write_bytes(b"png")

    class FakeResponse:
        def __init__(self, output, text="done"):
            self.id = "resp-2"
            self.output = output
            self.output_text = text

    call = SimpleNamespace(
        type="function_call",
        name="wait",
        arguments=json.dumps({"seconds": 0}),
        call_id="call-1",
    )
    responses = [FakeResponse([call]), FakeResponse([], "COMPLETED: finished")]
    created = []

    class FakeClient:
        def __init__(self, *args, **kwargs):
            pass
        def create(self, **kwargs):
            created.append(kwargs)
            return responses.pop(0)

    monkeypatch.setattr("ocean.local_model_client.LocalOllamaResponsesClient", FakeClient)
    agent = ComputerUseAgent(api_key="ignored", model="qwen2.5vl:7b", max_steps=4)
    calls = []
    statuses = []

    def fake_execute(name, arguments, *, task_id, geometry=None):
        calls.append((name, arguments, task_id))
        if name == "screenshot":
            return ExecutionResult.succeeded({"path": image})
        return ExecutionResult.succeeded({"seconds": 0})

    monkeypatch.setattr(agent, "_execute", fake_execute)
    agent.on_status = statuses.append
    result = agent.run("finish the task")

    assert result.status == "completed"
    assert result.steps == 1
    assert calls[0][0] == "screenshot"
    assert calls[1][0] == "wait"
    assert calls[2][0] == "screenshot"
    assert len(created) == 2
    assert all(call["parallel_tool_calls"] is False for call in created)
    assert agent._reasoning_effort(escalation=False, objective="create a polished presentation") == "low"
    assert any(item["phase"] == "observing" for item in statuses)
    assert any(item["phase"] == "reasoning" for item in statuses)
    assert any(item["phase"] == "verifying" for item in statuses)
    assert statuses[-1]["phase"] == "completed"


def test_agent_translates_window_relative_coordinates(monkeypatch, tmp_path):
    agent = ComputerUseAgent(api_key="test", max_steps=1)
    translated = agent._translate_action(
        "click",
        {"x": 100, "y": 50},
        {"origin_x": 120, "origin_y": 80, "capture_width": 800, "capture_height": 600, "image_width": 1600, "image_height": 1200},
    )
    assert translated["x"] == 170
    assert translated["y"] == 105


def test_computer_action_batch_contract_is_bounded():
    batch = next(tool for tool in COMPUTER_TOOLS if tool["name"] == "action_batch")
    actions = batch["parameters"]["properties"]["actions"]
    assert actions["minItems"] == 1
    assert actions["maxItems"] == 12
    assert actions["items"]["additionalProperties"] is False


def test_computer_task_rebuild_includes_checkpoint(tmp_path):
    from ocean.api import LumoAPI
    from ocean.domain.event import Event
    api = object.__new__(LumoAPI)
    api._lock = __import__('threading').RLock()
    api._computer_tasks = {}
    api._active_account_id = 'acct'
    class Events:
        def history(self):
            return [
                Event(type='ComputerTaskStarted', aggregate_type='computer_task', aggregate_id='t', payload={'task_id':'t','account_id':'acct','objective':'x','max_steps':10}, source='test'),
                Event(type='ComputerTaskCheckpointed', aggregate_type='computer_task', aggregate_id='t', payload={'task_id':'t','account_id':'acct','checkpoint':{'task_id':'t','created_at':'now','actions':[]}}, source='test'),
            ]
    api.service = SimpleNamespace(events=Events())
    rebuilt = api._rebuild_computer_task('t')
    assert rebuilt['checkpoint']['task_id'] == 't'
    assert rebuilt['checkpoint_at'] == 'now'
