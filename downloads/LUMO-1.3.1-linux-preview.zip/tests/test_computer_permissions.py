import pytest


def test_browser_per_domain_permission():
    from ocean.capabilities.browser import PlaywrightBrowserExecutor
    PlaywrightBrowserExecutor._assert_domain_allowed("https://example.com/a", {"allowed_domains":["example.com"]})
    with pytest.raises(PermissionError):
        PlaywrightBrowserExecutor._assert_domain_allowed("https://other.example.net", {"allowed_domains":["example.com"]})


def test_desktop_per_application_permission():
    from ocean.worlds.desktop import DesktopWorldExecutor
    DesktopWorldExecutor._assert_application_allowed("Safari", {"allowed_applications":["Safari"]})
    with pytest.raises(PermissionError):
        DesktopWorldExecutor._assert_application_allowed("Terminal", {"allowed_applications":["Safari"]})


def test_real_computer_clipboard_requires_explicit_approval():
    from ocean.capabilities.computer import MacOSComputerExecutor
    from runtime.types import ExecutionRequest
    request=ExecutionRequest(task_id="t",capability="computer",operation="type_text",arguments={"text":"hello"})
    result=MacOSComputerExecutor().execute(request,None)
    assert result.success is False
    assert "clipboard access" in (result.error or "")
