from ocean.device_registry import DeviceLifecycleController, DeviceRegistry
from ocean.device_scheduler import DeviceWorkloadScheduler


def test_device_scheduler_uses_only_measured_capabilities(tmp_path):
    registry = DeviceRegistry(tmp_path / "devices.sqlite3")
    measured = registry.register("a", name="Mac", capabilities=None)
    reported = registry.register("a", name="Remote", capabilities={"worlds": True})
    lifecycle = DeviceLifecycleController(registry)
    scheduler = DeviceWorkloadScheduler(registry, lifecycle)
    assert scheduler.place("a").device_id == measured.id
    assert reported.id not in [d.id for d in scheduler.eligible("a") if not registry.trusted_capabilities(d)]


def test_device_scheduler_skips_drained_and_revoked_devices(tmp_path):
    registry = DeviceRegistry(tmp_path / "devices.sqlite3")
    first = registry.register("a", name="First", capabilities=None)
    second = registry.register("a", name="Second", capabilities=None)
    lifecycle = DeviceLifecycleController(registry)
    lifecycle.set_mode("a", first.id, "drain")
    scheduler = DeviceWorkloadScheduler(registry, lifecycle)
    assert scheduler.place("a").device_id == second.id
    lifecycle.revoke("a", second.id)
    try:
        scheduler.place("a")
    except RuntimeError as exc:
        assert "no eligible device" in str(exc)
    else:
        raise AssertionError("revoked device was scheduled")


def test_device_failover_excludes_failed_device(tmp_path):
    registry = DeviceRegistry(tmp_path / "devices.sqlite3")
    first = registry.register("a", name="First", capabilities=None)
    second = registry.register("a", name="Second", capabilities=None)
    lifecycle = DeviceLifecycleController(registry)
    scheduler = DeviceWorkloadScheduler(registry, lifecycle)
    assert scheduler.failover("a", first.id).device_id == second.id
