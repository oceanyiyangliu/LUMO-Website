from ocean.self_improvement.benchmark import BenchmarkComparisonReport
from ocean.self_improvement.decision import ImprovementDecisionRequest, ImprovementDecisionService
from ocean.self_improvement.objective import EvidenceKind, ObjectiveContract
from ocean.self_improvement.verification import CandidateVerificationContext


def verification(candidate_id: str):
    return CandidateVerificationContext(
        verification_id="verification-1",
        candidate_id=candidate_id,
        candidate_mission_id="mission-1",
        candidate_plan_revision_id="plan-1",
        task_id="task-1",
        passed=True,
        evidence=("tests passed",),
        execution_id=None,
        metadata={},
    )


def empty_benchmark(candidate_id: str):
    return BenchmarkComparisonReport(
        candidate_id=candidate_id,
        comparisons=(),
        improved_count=0,
        regressed_count=0,
        unchanged_count=0,
        passed=True,
        metadata={},
    )


def test_non_benchmark_objective_can_pass_with_required_evidence():
    contract = ObjectiveContract(
        objective_id="obj-concurrency",
        objective="Harden concurrent execution",
        work_type="implementation",
        acceptance_criteria=("candidate tests pass",),
        evidence_policy=(EvidenceKind.TESTS, EvidenceKind.CONCURRENCY),
        required_evidence=("concurrency proof",),
    )
    decision = ImprovementDecisionService().decide(
        ImprovementDecisionRequest(
            candidate_id="candidate-1",
            verification=verification("candidate-1"),
            benchmark=empty_benchmark("candidate-1"),
            required_evidence=("concurrency proof",),
            research_evidence=("concurrency proof",),
            objective_contract=contract,
        )
    )
    assert decision.passed


def test_benchmark_contract_still_requires_improvement():
    contract = ObjectiveContract(
        objective_id="obj-performance",
        objective="Improve performance",
        acceptance_criteria=("tests pass",),
        evidence_policy=(EvidenceKind.TESTS, EvidenceKind.BENCHMARK),
        minimum_improvements=1,
    )
    decision = ImprovementDecisionService().decide(
        ImprovementDecisionRequest(
            candidate_id="candidate-1",
            verification=verification("candidate-1"),
            benchmark=empty_benchmark("candidate-1"),
            objective_contract=contract,
        )
    )
    assert not decision.passed
    assert "benchmark comparison contains no metrics" in decision.reasons


def test_skipped_benchmark_does_not_trigger_minimum_improvement_gate_for_tests_only_contract():
    contract = ObjectiveContract(
        objective_id="obj-eventbus",
        objective="Implement EventBus observability API",
        work_type="implementation",
        acceptance_criteria=("candidate tests pass",),
        evidence_policy=(EvidenceKind.TESTS,),
        minimum_improvements=0,
    )
    benchmark = empty_benchmark("candidate-1")
    benchmark = BenchmarkComparisonReport(
        candidate_id=benchmark.candidate_id,
        comparisons=benchmark.comparisons,
        improved_count=0,
        regressed_count=0,
        unchanged_count=0,
        passed=True,
        metadata={"skipped": True, "reason": "objective evidence policy"},
    )
    decision = ImprovementDecisionService().decide(
        ImprovementDecisionRequest(
            candidate_id="candidate-1",
            verification=verification("candidate-1"),
            benchmark=benchmark,
            minimum_improvements=1,
            objective_contract=contract,
        )
    )
    assert decision.passed
    assert "candidate does not meet minimum improvement requirement" not in decision.reasons
