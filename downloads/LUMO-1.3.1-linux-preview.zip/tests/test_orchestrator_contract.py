from ocean.domain.event_bus import EventBus
from ocean.orchestration.orchestrator import (
    AgentPort,
    AgentRuntimePort,
    AssignmentPort,
    MissionPort,
    OrchestrationPorts,
    Orchestrator,
    TaskPort,
)


class FakeMissionPort:
    def get(self, mission_id):
        return None

    def save(self, mission):
        pass


class FakeTaskPort:
    def get(self, task_id):
        return None

    def save(self, task):
        pass


class FakeAssignmentPort:
    def get(self, assignment_id):
        return None

    def save(self, assignment):
        pass

    def list(self):
        return []


class FakeAgentPort:
    def get(self, agent_id):
        return None


class FakeAgentRuntimePort:
    def submit(
        self,
        agent_id,
        request,
        *,
        priority=0,
        dependencies=None,
    ):
        return None

    def mark_idle(self, agent_id):
        return None

    def mark_waiting(self, agent_id, *, task_id=None):
        return None

    def mark_background(self, agent_id):
        return None


def test_orchestration_ports_hold_dependencies():
    events = EventBus()

    ports = OrchestrationPorts(
        missions=FakeMissionPort(),
        tasks=FakeTaskPort(),
        assignments=FakeAssignmentPort(),
        agents=FakeAgentPort(),
        agent_runtime=FakeAgentRuntimePort(),
        events=events,
    )

    assert ports.missions is not None
    assert ports.tasks is not None
    assert ports.assignments is not None
    assert ports.agents is not None
    assert ports.agent_runtime is not None
    assert ports.events is events


def test_orchestrator_constructs_with_dependency_ports():
    ports = OrchestrationPorts(
        missions=FakeMissionPort(),
        tasks=FakeTaskPort(),
        assignments=FakeAssignmentPort(),
        agents=FakeAgentPort(),
        agent_runtime=FakeAgentRuntimePort(),
        events=EventBus(),
    )

    orchestrator = Orchestrator(ports)

    assert orchestrator.ports is ports
    assert orchestrator.policies is not None
