import time

from ocean.domain.agent import Agent
from ocean.domain.event_bus import EventBus
from ocean.domain.task import Task
from ocean.orchestration.orchestrator import OrchestrationPorts, Orchestrator
from ocean.orchestration.types import AssignmentRequest, ExecutionIntent
from runtime import (
    AgentRuntime,
    ExecutionRequest,
    ExecutionResult,
    ExecutionSupervisor,
    Scheduler,
)
from runtime.executor import CapabilityExecutor


class SuccessfulExecutor(CapabilityExecutor):
    def execute(self, request, context):
        return ExecutionResult.succeeded(
            {
                "execution_id": request.execution_id,
                "operation": request.operation,
            }
        )


class TaskRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item


class AssignmentRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item

    def list(self):
        return list(self.items.values())

    def transaction(self):
        from contextlib import contextmanager

        @contextmanager
        def _tx():
            yield

        return _tx()


class AgentRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item


class MissionRepo:
    def __init__(self):
        self.items = {}

    def get(self, item_id):
        return self.items.get(item_id)

    def save(self, item):
        self.items[item.id] = item


def make_runtime(executor):
    from tests.test_runtime import make_runtime as build_runtime

    return build_runtime(executor)


def build_runtime_stack():
    execution_runtime = make_runtime(SuccessfulExecutor())
    supervisor = ExecutionSupervisor(execution_runtime)
    scheduler = Scheduler(supervisor)
    agent_runtime = AgentRuntime(scheduler)

    return execution_runtime, supervisor, scheduler, agent_runtime


def build_orchestrator(agent_runtime):
    tasks = TaskRepo()
    assignments = AssignmentRepo()
    agents = AgentRepo()
    missions = MissionRepo()
    events = EventBus()

    ports = OrchestrationPorts(
        missions=missions,
        tasks=tasks,
        assignments=assignments,
        agents=agents,
        agent_runtime=agent_runtime,
        events=events,
    )

    return (
        Orchestrator(ports),
        tasks,
        assignments,
        agents,
        missions,
        events,
    )


def make_agent(agent_runtime, agent_id):
    agent = Agent(
        id=agent_id,
        name="Integration Agent",
        role="worker",
        capabilities={"test"},
    )
    agent_runtime.register(agent)
    return agent


def test_orchestrator_dispatch_reaches_real_scheduler():
    (
        execution_runtime,
        supervisor,
        scheduler,
        agent_runtime,
    ) = build_runtime_stack()

    try:
        (
            orchestrator,
            tasks,
            assignments,
            agents,
            missions,
            events,
        ) = build_orchestrator(agent_runtime)

        agent = make_agent(agent_runtime, "agent-integration")
        agents.save(agent)

        task = Task(title="Integration execution")
        tasks.save(task)

        created = orchestrator.assign(
            AssignmentRequest(
                task_id=task.id,
                agent_id=agent.id,
            )
        )

        assert created.success is True

        dispatched = orchestrator.dispatch(
            created.assignment_id,
            ExecutionIntent(
                capability="test",
                operation="run",
                arguments={"value": 42},
            ),
        )

        assert dispatched.success is True
        assert dispatched.assignment_id == created.assignment_id
        assert dispatched.execution_id is not None

        scheduled = scheduler.get(dispatched.execution_id)

        assert scheduled is not None
        assert scheduled.request.task_id == task.id
        assert scheduled.request.agent_id == agent.id
        assert scheduled.request.capability == "test"
        assert scheduled.request.operation == "run"
        assert scheduled.request.arguments == {"value": 42}
        assert scheduled.state.value == "queued"

    finally:
        scheduler.stop()
        supervisor.shutdown()


def test_orchestrator_dispatch_preserves_correlation_into_scheduler():
    (
        execution_runtime,
        supervisor,
        scheduler,
        agent_runtime,
    ) = build_runtime_stack()

    try:
        (
            orchestrator,
            tasks,
            assignments,
            agents,
            missions,
            events,
        ) = build_orchestrator(agent_runtime)

        agent = make_agent(agent_runtime, "agent-correlation")
        agents.save(agent)

        task = Task(title="Correlation execution")
        tasks.save(task)

        created = orchestrator.assign(
            AssignmentRequest(
                task_id=task.id,
                agent_id=agent.id,
            )
        )

        dispatched = orchestrator.dispatch(
            created.assignment_id,
            ExecutionIntent(
                capability="test",
                operation="run",
            ),
        )

        assert dispatched.success is True

        scheduled = scheduler.get(dispatched.execution_id)

        assert scheduled.request.causation_id == created.assignment_id
        assert scheduled.request.source == "orchestrator"

    finally:
        scheduler.stop()
        supervisor.shutdown()
