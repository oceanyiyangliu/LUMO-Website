from dataclasses import FrozenInstanceError

import pytest

from ocean.domain.mission import Mission
from ocean.domain.task import Task
from ocean.domain.work_graph import (
    WorkEdge,
    WorkEdgeKind,
    WorkGraph,
    WorkNode,
    WorkNodeKind,
)
from ocean.execution.compiler import (
    ExecutionPlan,
    ExecutionStep,
    PlanExecutionCompiler,
)
from ocean.orchestration.types import ExecutionIntent


class FakeResolver:
    def __init__(self):
        self.calls = []

    def resolve(self, task):
        self.calls.append(task.id)
        return ExecutionIntent(
            capability="compute",
            operation="run",
            arguments={"task_id": task.id},
        )


def make_graph(mission_id, nodes, edges=()):
    return WorkGraph(
        mission_id=mission_id,
        plan_revision_id="plan-1",
        nodes=tuple(nodes),
        edges=tuple(edges),
        id="graph-1",
    )


def make_task(task_id, mission_id):
    return Task(
        id=task_id,
        title=task_id,
        mission_id=mission_id,
    )


def test_compiles_task_node():
    mission = Mission(id="mission-1", goal="do work")
    task = make_task("task-1", mission.id)
    node = WorkNode(
        id="node-task-1",
        kind=WorkNodeKind.TASK,
        task_id=task.id,
    )

    resolver = FakeResolver()
    plan = PlanExecutionCompiler().compile(
        make_graph(mission.id, [node]),
        [task],
        resolver,
    )

    assert isinstance(plan, ExecutionPlan)
    assert plan.mission_id == mission.id
    assert plan.plan_revision_id == "plan-1"
    assert len(plan.steps) == 1
    assert plan.steps[0].node_id == node.id
    assert plan.steps[0].task_id == task.id
    assert plan.steps[0].intent.operation == "run"
    assert resolver.calls == [task.id]


def test_preserves_dependencies_as_node_ids():
    mission = Mission(id="mission-1", goal="do work")
    task_a = make_task("task-a", mission.id)
    task_b = make_task("task-b", mission.id)

    node_a = WorkNode(
        id="node-a",
        kind=WorkNodeKind.TASK,
        task_id=task_a.id,
    )
    node_b = WorkNode(
        id="node-b",
        kind=WorkNodeKind.TASK,
        task_id=task_b.id,
    )

    edge = WorkEdge(
        id="edge-a-b",
        source_node_id=node_a.id,
        target_node_id=node_b.id,
        kind=WorkEdgeKind.DEPENDENCY,
    )

    plan = PlanExecutionCompiler().compile(
        make_graph(mission.id, [node_b, node_a], [edge]),
        [task_b, task_a],
        FakeResolver(),
    )

    assert [step.node_id for step in plan.steps] == [
        "node-a",
        "node-b",
    ]
    assert plan.steps[0].depends_on_node_ids == ()
    assert plan.steps[1].depends_on_node_ids == ("node-a",)


def test_independent_tasks_have_no_dependencies():
    mission = Mission(id="mission-1", goal="do work")
    tasks = [
        make_task("task-b", mission.id),
        make_task("task-a", mission.id),
    ]
    nodes = [
        WorkNode(
            id="node-b",
            kind=WorkNodeKind.TASK,
            task_id="task-b",
        ),
        WorkNode(
            id="node-a",
            kind=WorkNodeKind.TASK,
            task_id="task-a",
        ),
    ]

    plan = PlanExecutionCompiler().compile(
        make_graph(mission.id, nodes),
        tasks,
        FakeResolver(),
    )

    assert [step.node_id for step in plan.steps] == [
        "node-a",
        "node-b",
    ]
    assert all(
        step.depends_on_node_ids == ()
        for step in plan.steps
    )


def test_rejects_task_from_wrong_mission():
    graph = make_graph(
        "mission-1",
        [
            WorkNode(
                id="node-1",
                kind=WorkNodeKind.TASK,
                task_id="task-1",
            )
        ],
    )

    task = make_task("task-1", "mission-2")

    with pytest.raises(ValueError, match="belongs to mission"):
        PlanExecutionCompiler().compile(
            graph,
            [task],
            FakeResolver(),
        )


def test_rejects_unknown_task_reference():
    graph = make_graph(
        "mission-1",
        [
            WorkNode(
                id="node-1",
                kind=WorkNodeKind.TASK,
                task_id="missing-task",
            )
        ],
    )

    with pytest.raises(ValueError, match="references unknown task"):
        PlanExecutionCompiler().compile(
            graph,
            [],
            FakeResolver(),
        )


def test_rejects_duplicate_tasks():
    task = make_task("task-1", "mission-1")

    graph = make_graph(
        "mission-1",
        [
            WorkNode(
                id="node-1",
                kind=WorkNodeKind.TASK,
                task_id=task.id,
            )
        ],
    )

    with pytest.raises(ValueError, match="duplicate task"):
        PlanExecutionCompiler().compile(
            graph,
            [task, task],
            FakeResolver(),
        )


@pytest.mark.parametrize(
    "kind",
    [
        WorkNodeKind.CONDITION,
        WorkNodeKind.JOIN,
        WorkNodeKind.WAIT,
        WorkNodeKind.HUMAN_APPROVAL,
        WorkNodeKind.REPLAN,
    ],
)
def test_rejects_unsupported_structural_nodes(kind):
    graph = make_graph(
        "mission-1",
        [
            WorkNode(
                id="node-1",
                kind=kind,
            )
        ],
    )

    with pytest.raises(ValueError, match="unsupported structural"):
        PlanExecutionCompiler().compile(
            graph,
            [],
            FakeResolver(),
        )


def test_rejects_conditional_edges():
    node_a = WorkNode(
        id="node-a",
        kind=WorkNodeKind.TASK,
        task_id="task-a",
    )
    node_b = WorkNode(
        id="node-b",
        kind=WorkNodeKind.TASK,
        task_id="task-b",
    )

    graph = make_graph(
        "mission-1",
        [node_a, node_b],
        [
            WorkEdge(
                id="edge-conditional",
                source_node_id=node_a.id,
                target_node_id=node_b.id,
                kind=WorkEdgeKind.CONDITIONAL,
                condition="result == true",
            )
        ],
    )

    tasks = [
        make_task("task-a", "mission-1"),
        make_task("task-b", "mission-1"),
    ]

    with pytest.raises(ValueError, match="conditional"):
        PlanExecutionCompiler().compile(
            graph,
            tasks,
            FakeResolver(),
        )


def test_rejects_non_execution_intent_from_resolver():
    class BadResolver:
        def resolve(self, task):
            return "not an execution intent"

    task = make_task("task-1", "mission-1")
    node = WorkNode(
        id="node-1",
        kind=WorkNodeKind.TASK,
        task_id=task.id,
    )

    with pytest.raises(TypeError, match="ExecutionIntent"):
        PlanExecutionCompiler().compile(
            make_graph("mission-1", [node]),
            [task],
            BadResolver(),
        )


def test_empty_graph_produces_empty_execution_plan():
    plan = PlanExecutionCompiler().compile(
        make_graph("mission-1", []),
        [],
        FakeResolver(),
    )

    assert plan.steps == ()


def test_compilation_does_not_mutate_inputs():
    task = make_task("task-1", "mission-1")
    node = WorkNode(
        id="node-1",
        kind=WorkNodeKind.TASK,
        task_id=task.id,
    )
    graph = make_graph("mission-1", [node])

    original_nodes = graph.nodes
    original_tasks = [task]

    PlanExecutionCompiler().compile(
        graph,
        original_tasks,
        FakeResolver(),
    )

    assert graph.nodes == original_nodes
    assert original_tasks == [task]


def test_execution_step_is_immutable():
    step = ExecutionStep(
        node_id="node-1",
        task_id="task-1",
        intent=ExecutionIntent(
            capability="compute",
            operation="run",
        ),
    )

    with pytest.raises(FrozenInstanceError):
        step.node_id = "other"


def test_execution_plan_is_immutable():
    plan = ExecutionPlan(
        mission_id="mission-1",
        plan_revision_id="plan-1",
    )

    with pytest.raises(FrozenInstanceError):
        plan.mission_id = "other"


def make_diamond_plan():
    mission = Mission(id="mission-1", goal="diamond")

    tasks = [
        make_task("task-a", mission.id),
        make_task("task-b", mission.id),
        make_task("task-c", mission.id),
        make_task("task-d", mission.id),
    ]

    nodes = [
        WorkNode(id="node-a", kind=WorkNodeKind.TASK, task_id="task-a"),
        WorkNode(id="node-b", kind=WorkNodeKind.TASK, task_id="task-b"),
        WorkNode(id="node-c", kind=WorkNodeKind.TASK, task_id="task-c"),
        WorkNode(id="node-d", kind=WorkNodeKind.TASK, task_id="task-d"),
    ]

    edges = [
        WorkEdge(
            id="edge-a-b",
            source_node_id="node-a",
            target_node_id="node-b",
            kind=WorkEdgeKind.DEPENDENCY,
        ),
        WorkEdge(
            id="edge-a-c",
            source_node_id="node-a",
            target_node_id="node-c",
            kind=WorkEdgeKind.DEPENDENCY,
        ),
        WorkEdge(
            id="edge-b-d",
            source_node_id="node-b",
            target_node_id="node-d",
            kind=WorkEdgeKind.DEPENDENCY,
        ),
        WorkEdge(
            id="edge-c-d",
            source_node_id="node-c",
            target_node_id="node-d",
            kind=WorkEdgeKind.DEPENDENCY,
        ),
    ]

    return PlanExecutionCompiler().compile(
        make_graph(mission.id, nodes, edges),
        tasks,
        FakeResolver(),
    )


def test_step_returns_requested_step():
    plan = make_diamond_plan()

    assert plan.step("node-b").task_id == "task-b"


def test_step_rejects_unknown_node():
    plan = make_diamond_plan()

    with pytest.raises(KeyError, match="unknown execution step"):
        plan.step("missing")


def test_dependencies_are_deterministic():
    plan = make_diamond_plan()

    assert plan.dependencies("node-d") == (
        "node-b",
        "node-c",
    )


def test_dependents_are_deterministic():
    plan = make_diamond_plan()

    assert plan.dependents("node-a") == (
        "node-b",
        "node-c",
    )
    assert plan.dependents("node-d") == ()


def test_dependents_reject_unknown_node():
    plan = make_diamond_plan()

    with pytest.raises(KeyError, match="unknown execution step"):
        plan.dependents("missing")


def test_initial_ready_steps_are_independent_roots():
    plan = make_diamond_plan()

    assert tuple(
        step.node_id for step in plan.ready_steps()
    ) == ("node-a",)


def test_ready_steps_exposes_parallel_frontier():
    plan = make_diamond_plan()

    ready = plan.ready_steps({"node-a"})

    assert tuple(step.node_id for step in ready) == (
        "node-b",
        "node-c",
    )


def test_ready_steps_only_unlocks_join_after_all_dependencies():
    plan = make_diamond_plan()

    assert tuple(
        step.node_id
        for step in plan.ready_steps({"node-a", "node-b"})
    ) == ("node-c",)

    assert tuple(
        step.node_id
        for step in plan.ready_steps(
            {"node-a", "node-b", "node-c"}
        )
    ) == ("node-d",)


def test_ready_steps_excludes_completed_steps():
    plan = make_diamond_plan()

    assert tuple(
        step.node_id
        for step in plan.ready_steps(
            {"node-a", "node-b", "node-c", "node-d"}
        )
    ) == ()


def test_ready_steps_rejects_unknown_completed_node():
    plan = make_diamond_plan()

    with pytest.raises(ValueError, match="unknown execution steps"):
        plan.ready_steps({"node-a", "missing"})
