from pathlib import Path
import sqlite3

from ocean.backup import backup_database, restore_database, verify_database
from ocean.production_readiness import production_config_gates


def test_backup_restore_roundtrip(tmp_path: Path):
    source = tmp_path / "source.sqlite3"
    backup = tmp_path / "backup.sqlite3"
    restored = tmp_path / "restored.sqlite3"
    db = sqlite3.connect(source)
    db.execute("CREATE TABLE data(value TEXT NOT NULL)")
    db.execute("INSERT INTO data VALUES ('lumo')")
    db.commit(); db.close()
    backup_database(source, backup)
    assert verify_database(backup)
    restore_database(backup, restored)
    db = sqlite3.connect(restored)
    assert db.execute("SELECT value FROM data").fetchone() == ("lumo",)
    db.close()


def test_production_tenant_store_is_explicit():
    env = {
        "LUMO_API_AUTH_REQUIRED": "1",
        "LUMO_API_SESSION_SECRET": "x" * 32,
        "LUMO_API_SESSION_BOOTSTRAP_SECRET": "y" * 16,
        "LUMO_TENANCY_STORE": "/var/lib/lumo/tenancy.sqlite3",
        "LUMO_TLS_CERT_FILE": "/etc/lumo/fullchain.pem",
        "LUMO_TLS_KEY_FILE": "/etc/lumo/privkey.pem",
        "LUMO_HEALTH_URL": "https://lumo.example/health",
        "LUMO_ALERT_FILE": "/var/log/lumo/alerts.jsonl",
            "LUMO_EMAIL_WEBHOOK_URL": "https://mail.example/lumo",
            "LUMO_EMAIL_WEBHOOK_SECRET": "e" * 16,
    }
    assert production_config_gates(env) == {
        "production_auth": True,
        "production_secrets": True,
        "production_tenant_store": True,
        "https_gateway": True,
        "monitoring_alerts": True,
        "email_delivery": True,
    }
