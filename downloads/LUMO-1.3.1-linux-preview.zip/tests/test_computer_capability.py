from __future__ import annotations

from pathlib import Path

import pytest

from ocean.capabilities.computer import MacOSComputerExecutor, computer_spec
from runtime.types import ExecutionRequest


def request(operation: str, **arguments):
    return ExecutionRequest(task_id="computer-task", capability="computer", operation=operation, arguments=arguments)

@pytest.fixture(autouse=True)
def screen_recording_granted(monkeypatch):
    # Capability tests exercise the already-authorized path; the production
    # executor itself fails closed when the signed host preflight is absent.
    monkeypatch.setenv("LUMO_SCREEN_TRUSTED", "1")


def test_core_graphics_path_is_runtime_resolved():
    import os
    from ocean.capabilities.computer import MacOSComputerExecutor
    expected = os.path.join("/System/Library/Frameworks", "CoreGraphics.framework", "CoreGraphics")
    assert MacOSComputerExecutor._core_graphics()._name == expected


def test_computer_spec_exposes_governed_gui_primitives():
    spec = computer_spec()
    assert spec.name == "computer"
    assert spec.execution_strategy == "computer_macos"
    assert spec.requires_permissions == {"computer.use"}
    assert spec.execution_policy.process_isolated is True
    assert set(spec.operations) == {
        "screenshot", "open_url", "launch_app", "click", "double_click",
        "drag", "move", "accessibility_snapshot", "click_element", "type_text", "key_press", "hotkey", "scroll", "wait",
    }
    assert spec.operations["open_url"].risk_level.value == "high"


def test_computer_screenshot_uses_screencapture(monkeypatch, tmp_path: Path):
    executor = MacOSComputerExecutor()
    target = tmp_path / "screen.png"
    calls = []

    def fake_run(args, *, timeout):
        calls.append((args, timeout))
        target.write_bytes(b"fake")
        return "", ""

    monkeypatch.setattr(executor, "_run", fake_run)
    result = executor.execute(request("screenshot", path=str(target)), None)
    assert result.success is True
    assert result.result["path"] == str(target.resolve())
    capture_calls = [args for args, _ in calls if args[:2] == ["/usr/sbin/screencapture", "-x"]]
    assert capture_calls


def test_computer_open_url_uses_no_shell(monkeypatch):
    executor = MacOSComputerExecutor()
    calls = []
    monkeypatch.setattr(executor, "_run", lambda args, *, timeout: calls.append(args) or ("", ""))
    result = executor.execute(request("open_url", url="https://www.canva.com/"), None)
    assert result.success is True
    assert calls == [["/usr/bin/open", "https://www.canva.com/"]]


def test_computer_click_rejects_negative_coordinates():
    result = MacOSComputerExecutor().execute(request("click", x=-1, y=20), None)
    assert result.success is False
    assert "non-negative" in result.error


def test_computer_type_text_rejects_oversized_payload():
    result = MacOSComputerExecutor().execute(request("type_text", text="x" * 100_001), None)
    assert result.success is False
    assert "100000" in result.error


def test_computer_key_press_and_hotkey_generate_system_events(monkeypatch):
    executor = MacOSComputerExecutor()
    calls = []
    monkeypatch.setattr(executor, "_run", lambda args, *, timeout: calls.append(args) or ("", ""))
    assert executor.execute(request("key_press", key="return"), None).success
    assert executor.execute(request("hotkey", keys=["command", "a"]), None).success
    scripts = [call[-1] for call in calls]
    assert "key code 36" in scripts[0]
    assert "keystroke \"a\" using {command down}" in scripts[1]


def test_screenshot_reports_window_geometry(monkeypatch, tmp_path: Path):
    executor = MacOSComputerExecutor()
    target = tmp_path / "screen.png"
    monkeypatch.setattr(executor, "_frontmost_window_bounds", lambda *, timeout: (120, 80, 800, 600))
    monkeypatch.setattr(executor, "_frontmost_context", lambda *, timeout: {"application": "Chrome", "window": "Canva"})
    monkeypatch.setattr(executor, "_run", lambda args, *, timeout: (target.write_bytes(b"fake") or "", ""))
    result = executor.execute(request("screenshot", path=str(target)), None)
    assert result.success
    assert result.result["origin_x"] == 120
    assert result.result["origin_y"] == 80
    assert result.result["capture_width"] == 800
    assert result.result["capture_height"] == 600
    assert result.result["application"] == "Chrome"
    assert result.result["window"] == "Canva"

def test_screenshot_fails_closed_without_host_screen_preflight(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("LUMO_SCREEN_TRUSTED", "0")
    executor = MacOSComputerExecutor()
    called = False
    def forbidden_run(args, *, timeout):
        nonlocal called
        called = True
        raise AssertionError("screencapture must not run without host preflight")
    monkeypatch.setattr(executor, "_run", forbidden_run)
    result = executor.execute(request("screenshot", path=str(tmp_path / "screen.png")), None)
    assert result.success is False
    assert "Screen Recording is not currently authorized" in result.error
    assert called is False
