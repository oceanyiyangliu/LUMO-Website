import pytest

from ocean.orchestration.admission import ExecutionAdmissionKey


def test_admission_key_is_deterministic():
    first = ExecutionAdmissionKey("plan-1", "node-1")
    second = ExecutionAdmissionKey("plan-1", "node-1")

    assert first == second
    assert first.value == "plan-1:node-1"


def test_admission_key_distinguishes_plan_revisions():
    assert ExecutionAdmissionKey("plan-1", "node-1") != ExecutionAdmissionKey(
        "plan-2", "node-1"
    )


def test_admission_key_distinguishes_nodes():
    assert ExecutionAdmissionKey("plan-1", "node-1") != ExecutionAdmissionKey(
        "plan-1", "node-2"
    )


@pytest.mark.parametrize(
    "plan_revision_id,execution_node_id",
    [
        ("", "node-1"),
        ("   ", "node-1"),
        ("plan-1", ""),
        ("plan-1", "   "),
    ],
)
def test_admission_key_requires_identity(plan_revision_id, execution_node_id):
    with pytest.raises(ValueError):
        ExecutionAdmissionKey(plan_revision_id, execution_node_id)


def test_admission_key_from_unmanaged_assignment_returns_none():
    assert ExecutionAdmissionKey.from_assignment_metadata({}) is None


def test_admission_key_from_managed_assignment():
    key = ExecutionAdmissionKey.from_assignment_metadata(
        {
            "execution_plan_id": "plan-1",
            "execution_node_id": "node-7",
        }
    )

    assert key == ExecutionAdmissionKey("plan-1", "node-7")


@pytest.mark.parametrize(
    "metadata",
    [
        {"execution_plan_id": "plan-1"},
        {"execution_node_id": "node-1"},
    ],
)
def test_managed_assignment_metadata_requires_both_identity_fields(metadata):
    with pytest.raises(ValueError):
        ExecutionAdmissionKey.from_assignment_metadata(metadata)
