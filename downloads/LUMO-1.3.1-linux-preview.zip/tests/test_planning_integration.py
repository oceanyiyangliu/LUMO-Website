from ocean.domain.event_bus import EventBus
from ocean.domain.mission import Mission
from ocean.domain.task import Task
from ocean.domain.decision import Decision
from ocean.domain.work_graph import WorkNode, WorkNodeKind
from ocean.planning.planner import PlanningContext, PlanningRequest, PlanningResult
from ocean.planning.service import PlanningService
from persistence.in_memory import InMemoryRepository


class FakePlanner:
    def __init__(self, result):
        self.result = result
        self.requests = []

    def plan(self, request):
        self.requests.append(request)
        return self.result


def build():
    missions = InMemoryRepository()
    decisions = InMemoryRepository()
    tasks = InMemoryRepository()
    graphs = InMemoryRepository()
    plans = InMemoryRepository()
    events = EventBus()

    service = PlanningService(
        missions=missions,
        decisions=decisions,
        tasks=tasks,
        work_graphs=graphs,
        plan_revisions=plans,
        events=events,
    )

    mission = Mission(
        id="mission-1",
        goal="Build autonomous research infrastructure",
    )
    missions.save(mission)

    return service, mission, decisions, tasks, graphs, plans, events


def make_request(mission):
    return PlanningRequest(
        mission_id=mission.id,
        objective=mission.goal,
        context=PlanningContext(mission=mission),
    )


def test_plan_runs_planner_and_persists_result():
    service, mission, decisions, tasks, graphs, plans, events = build()

    decision = Decision(
        id="decision-1",
        mission_id=mission.id,
        kind="strategy",
        objective=mission.goal,
        rationale="Parallel execution is appropriate.",
    )

    planner = FakePlanner(
        PlanningResult(
            decision=decision,
        )
    )

    plan, graph = service.plan(make_request(mission), planner)

    assert planner.requests
    assert planner.requests[0].mission_id == mission.id
    assert decisions.get(decision.id) is decision
    assert graphs.get(graph.id) is graph
    assert plans.get(plan.id) is plan


def test_plan_creates_cross_references():
    service, mission, decisions, tasks, graphs, plans, events = build()

    decision = Decision(
        id="decision-2",
        mission_id=mission.id,
        kind="strategy",
        objective=mission.goal,
        rationale="Use staged execution.",
    )

    planner = FakePlanner(
        PlanningResult(
            decision=decision,
            nodes=(),
        )
    )

    plan, graph = service.plan(make_request(mission), planner)

    assert plan.graph_id == graph.id
    assert graph.plan_revision_id == plan.id
    assert plan.decision_id == decision.id
    assert plan.revision == 1


def test_plan_revision_numbers_increment():
    service, mission, decisions, tasks, graphs, plans, events = build()

    tasks.save(
        Task(
            id="task-2",
            title="Execute research",
            mission_id=mission.id,
        )
    )

    for index in (1, 2):
        decision = Decision(
            id=f"decision-{index}",
            mission_id=mission.id,
            kind="strategy",
            objective=mission.goal,
            rationale=f"Revision {index}.",
        )

        planner = FakePlanner(
            PlanningResult(
                decision=decision,
                nodes=(),
            )
        )

        plan, _ = service.plan(make_request(mission), planner)

        if index == 1:
            first = plan
        else:
            assert plan.revision == 2
            assert plan.parent_revision_id == first.id


def test_planner_cannot_return_decision_for_another_mission():
    service, mission, _, _, _, _, _ = build()

    decision = Decision(
        id="decision-wrong",
        mission_id="mission-other",
        kind="strategy",
        objective="Other objective",
        rationale="Wrong mission.",
    )

    planner = FakePlanner(
        PlanningResult(
            decision=decision,
            nodes=(),
        )
    )

    import pytest

    with pytest.raises(ValueError, match="different mission"):
        service.plan(make_request(mission), planner)
