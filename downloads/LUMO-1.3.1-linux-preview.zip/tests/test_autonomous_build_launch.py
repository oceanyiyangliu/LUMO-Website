import sqlite3

from eventing.sqlite_store import SQLiteEventStore
from ocean.domain.event_bus import EventBus
from ocean.observability.status import OperationalStatusProjector
from ocean.orchestration.mission_engine import (
    DeterministicMissionPlanner,
    MissionEngine,
    MissionObjectiveResult,
)


def test_autonomous_build_mission_has_persisted_lifecycle_and_terminal_evidence():
    connection = sqlite3.connect(":memory:")
    store = SQLiteEventStore(connection)
    events = EventBus(store=store)

    planner = DeterministicMissionPlanner()

    class Executor:
        def execute(self, mission_id, objective):
            return MissionObjectiveResult(
                objective_id=objective.objective_id,
                objective=objective.objective,
                status="completed",
                metadata={
                    "evidence": "deterministic launch harness passed",
                },
            )

    engine = MissionEngine(
        planner=planner,
        executor=Executor(),
        events=events,
    )

    result = engine.run(
        "Launch autonomous build mission",
        mission_id="autonomous-build-launch-test",
    )

    assert result.status == "completed"
    assert result.completed_objectives
    assert result.remaining_objectives == ()

    persisted_events = events.history()

    assert any(event.type == "MissionStarted" for event in persisted_events)
    assert any(event.type == "ObjectiveCompleted" for event in persisted_events)
    assert any(event.type == "MissionCompleted" for event in persisted_events)

    status = OperationalStatusProjector.from_events(
        result.mission_id,
        persisted_events,
    )

    assert status.status == "completed"
    assert status.progress == 1.0
    assert status.completed_objectives == 1
    assert status.active_objectives == 0
    assert status.queued_objectives == 0
