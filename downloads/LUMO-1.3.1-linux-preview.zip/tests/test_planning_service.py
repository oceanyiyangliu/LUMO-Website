import pytest

from ocean.domain.event_bus import EventBus
from ocean.domain.mission import Mission
from ocean.domain.work_graph import WorkEdge, WorkEdgeKind, WorkNode, WorkNodeKind
from ocean.planning import PlanningService
from persistence.in_memory import InMemoryRepository


def service():
    missions = InMemoryRepository()
    decisions = InMemoryRepository()
    tasks = InMemoryRepository()
    graphs = InMemoryRepository()
    plans = InMemoryRepository()
    events = EventBus()

    mission = Mission(
        goal="Build autonomous research system",
        id="mission-1",
    )
    missions.save(mission)

    return (
        PlanningService(
            missions=missions,
            decisions=decisions,
            tasks=tasks,
            work_graphs=graphs,
            plan_revisions=plans,
            events=events,
        ),
        decisions,
        graphs,
        plans,
        events,
    )


def nodes_and_edges():
    n1 = WorkNode(
        kind=WorkNodeKind.TASK,
        task_id="task-1",
        id="node-1",
    )
    n2 = WorkNode(
        kind=WorkNodeKind.TASK,
        task_id="task-2",
        id="node-2",
    )
    edge = WorkEdge(
        source_node_id="node-1",
        target_node_id="node-2",
        kind=WorkEdgeKind.DEPENDENCY,
        id="edge-1",
    )
    return (n1, n2), (edge,)


def test_create_decision_persists_and_publishes():
    service_, decisions, _, _, events = service()

    decision = service_.create_decision(
        mission_id="mission-1",
        kind="decomposition",
        objective="Parallelize research",
        rationale="Independent streams can run concurrently.",
        alternatives=("serial", "parallel"),
        selected_option="parallel",
    )

    assert decisions.get(decision.id) == decision
    assert events.history("DecisionCreated")[0].payload["id"] == decision.id


def test_create_plan_builds_cross_referenced_graph_and_revision():
    service_, _, graphs, plans, events = service()

    decision = service_.create_decision(
        mission_id="mission-1",
        kind="decomposition",
        objective="Parallelize research",
        rationale="Parallel execution reduces elapsed time.",
    )

    nodes, edges = nodes_and_edges()
    plan, graph = service_.create_plan(
        mission_id="mission-1",
        decision_id=decision.id,
        nodes=nodes,
        edges=edges,
    )

    assert plan.graph_id == graph.id
    assert graph.plan_revision_id == plan.id
    assert plans.get(plan.id) == plan
    assert graphs.get(graph.id) == graph
    assert [e.type for e in events.history()] == [
        "DecisionCreated",
        "WorkGraphCreated",
        "PlanRevisionCreated",
    ]


def test_revision_numbers_are_automatic_and_parented():
    service_, _, _, _, _ = service()

    decision = service_.create_decision(
        mission_id="mission-1",
        kind="strategy",
        objective="Research",
        rationale="Best approach.",
    )

    nodes, edges = nodes_and_edges()
    plan1, _ = service_.create_plan(
        mission_id="mission-1",
        decision_id=decision.id,
        nodes=nodes,
        edges=edges,
    )

    plan2, _ = service_.create_plan(
        mission_id="mission-1",
        decision_id=decision.id,
        nodes=nodes,
        edges=edges,
        parent_revision_id=plan1.id,
    )

    assert plan1.revision == 1
    assert plan2.revision == 2
    assert plan2.parent_revision_id == plan1.id


def test_plan_lifecycle():
    service_, _, _, plans, events = service()

    decision = service_.create_decision(
        mission_id="mission-1",
        kind="strategy",
        objective="Research",
        rationale="Best approach.",
    )
    nodes, edges = nodes_and_edges()
    plan, _ = service_.create_plan(
        mission_id="mission-1",
        decision_id=decision.id,
        nodes=nodes,
        edges=edges,
    )

    assert service_.propose(plan.id).status.value == "proposed"
    assert service_.activate(plan.id).status.value == "active"
    assert service_.complete(plan.id).status.value == "completed"

    assert plans.get(plan.id).status.value == "completed"
    assert [
        event.type for event in events.history()
    ] == [
        "DecisionCreated",
        "WorkGraphCreated",
        "PlanRevisionCreated",
        "PlanRevisionProposed",
        "PlanRevisionActivated",
        "PlanRevisionCompleted",
    ]


def test_only_one_active_plan_per_mission():
    service_, _, _, _, _ = service()

    decision = service_.create_decision(
        mission_id="mission-1",
        kind="strategy",
        objective="Research",
        rationale="Best approach.",
    )
    nodes, edges = nodes_and_edges()

    plan1, _ = service_.create_plan(
        mission_id="mission-1",
        decision_id=decision.id,
        nodes=nodes,
        edges=edges,
    )
    service_.propose(plan1.id)
    service_.activate(plan1.id)

    plan2, _ = service_.create_plan(
        mission_id="mission-1",
        decision_id=decision.id,
        nodes=nodes,
        edges=edges,
        parent_revision_id=plan1.id,
    )
    service_.propose(plan2.id)

    with pytest.raises(ValueError, match="already has an active"):
        service_.activate(plan2.id)


def test_cannot_plan_from_unknown_decision():
    service_, _, _, _, _ = service()

    nodes, edges = nodes_and_edges()

    with pytest.raises(ValueError, match="unknown decision"):
        service_.create_plan(
            mission_id="mission-1",
            decision_id="missing",
            nodes=nodes,
            edges=edges,
        )


def test_cannot_create_revision_with_invalid_parent():
    service_, _, _, _, _ = service()

    decision = service_.create_decision(
        mission_id="mission-1",
        kind="strategy",
        objective="Research",
        rationale="Best approach.",
    )
    nodes, edges = nodes_and_edges()

    with pytest.raises(ValueError, match="unknown parent"):
        service_.create_plan(
            mission_id="mission-1",
            decision_id=decision.id,
            nodes=nodes,
            edges=edges,
            revision=2,
            parent_revision_id="missing",
        )
