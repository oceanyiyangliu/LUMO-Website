"""Deterministic API payload fuzzing without external fuzzing dependencies."""
from __future__ import annotations

import random

from ocean.api import LumoAPI
from ocean.service import OceanService


def _value(rng: random.Random, depth: int = 0):
    if depth >= 3:
        return rng.choice([None, True, False, 0, 1, -1, "", "x", [], {}])
    choice = rng.randrange(8)
    if choice == 0:
        return None
    if choice == 1:
        return rng.choice([True, False])
    if choice == 2:
        return rng.randint(-1000, 1000)
    if choice == 3:
        return rng.uniform(-1000, 1000)
    if choice == 4:
        return "".join(rng.choice("abcXYZ012-_:/") for _ in range(rng.randrange(0, 80)))
    if choice == 5:
        return [_value(rng, depth + 1) for _ in range(rng.randrange(0, 8))]
    return {str(i): _value(rng, depth + 1) for i in range(rng.randrange(0, 8))}


def test_api_payload_fuzz_does_not_escape_expected_error_taxonomy(tmp_path):
    service = OceanService(repository_root=tmp_path)
    service.start()
    try:
        api = LumoAPI(service)
        rng = random.Random(0x1A20)
        for _ in range(500):
            body = _value(rng)
            for operation in (
                lambda: api.create_world(body),
                lambda: api.register_device(body),
            ):
                try:
                    operation()
                except (TypeError, ValueError, KeyError, PermissionError, RuntimeError):
                    pass
                except Exception as exc:
                    raise AssertionError(f"unexpected exception during fuzz case: {type(exc).__name__}: {exc}") from exc
    finally:
        service.stop()
