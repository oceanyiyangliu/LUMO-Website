import { NextResponse } from "next/server";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
const execFileAsync=promisify(execFile);
const API=process.env.LUMO_API_URL??"http://127.0.0.1:8765";
async function secret(){const {stdout}=await execFileAsync("/usr/bin/security",["find-generic-password","-a",process.env.LUMO_ROOT_ID??"","-s","LUMO Root Console","-w"]);return stdout.trim()}
export async function GET(){try{const s=await secret();const r=await fetch(`${API}/api/root/operator`,{headers:{"X-LUMO-Root-Console-Secret":s},cache:"no-store"});return new NextResponse(await r.text(),{status:r.status,headers:{"content-type":"application/json"}})}catch(e){return NextResponse.json({error:"Root Console authorization or LUMO connection failed"},{status:503})}}

export async function POST(req: Request){try{const s=await secret();const body=await req.text();const action=req.headers.get("x-root-action")||"export";const path=action==="restore"?"/api/root/recovery/restore":action==="email-config"?"/api/email/smtp":action==="email-test"?"/api/email/test":"/api/root/recovery/export";const r=await fetch(`${API}${path}`,{method:"POST",headers:{"X-LUMO-Root-Console-Secret":s,"Content-Type":"application/json"},body,cache:"no-store"});return new NextResponse(await r.text(),{status:r.status,headers:{"content-type":"application/json"}})}catch(e){return NextResponse.json({error:"Root recovery request failed"},{status:503})}}
