import type { ReactNode } from "react";
import "./globals.css";
export const metadata={title:"LUMO Root Control Center",description:"Private LUMO Root operations console"};
export default function RootLayout({children}:{children:ReactNode}){return <html lang="en"><body>{children}</body></html>}
