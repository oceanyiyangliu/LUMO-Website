#!/bin/zsh
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT_ID=$(.venv/bin/python - <<'PY'
from pathlib import Path
from ocean.service import OceanService
from ocean.api import LumoAPI
s=OceanService(repository_root=Path.cwd())
a=LumoAPI(s)
print(s.root_authority.root_id)
a.root_console_secret()
PY
)
export LUMO_ROOT_ID="$ROOT_ID"
export LUMO_API_URL="${LUMO_API_URL:-http://127.0.0.1:8765}"
exec npm --prefix root-console run start
