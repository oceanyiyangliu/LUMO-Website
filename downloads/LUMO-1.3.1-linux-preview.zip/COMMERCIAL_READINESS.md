# LUMO commercial readiness

LUMO now has a provider-neutral commercial layer. The control plane remains the authority for entitlements; payment providers only report subscription state.

## Plans

| Plan | Price | Missions / month | World runs / month | Active Worlds | Seats |
|---|---:|---:|---:|---:|---:|
| Free | $0 | 25 | 5 | 1 | 1 |
| Pro | $29/mo | 500 | 100 | 3 | 1 |
| Team | $99/mo | 2,500 | 500 | 10 | 5 |
| Business | $299/mo | 10,000 | 2,000 | 50 | 25 |
| Enterprise | Custom | Custom | Custom | Custom | Custom |

Prices are product defaults, not a legal or accounting commitment. Change them in `ocean/billing.py` before public launch.

## What is implemented

- Durable subscription state per LUMO account.
- Durable monthly usage meters.
- Fail-closed entitlement checks before mission and computer execution.
- Per-account World ownership and World-capacity limits.
- Duplicate-safe billing webhook ingestion.
- Signed webhook verification using an HMAC boundary.
- Hosted-checkout and customer-portal URL adapters.
- HQ Plans screen with live usage meters.
- Upgrade and billing-management actions.
- Billing state survives control-plane restarts.

## Configure a payment provider

Set hosted checkout URLs in the production environment:

```text
LUMO_CHECKOUT_URL_PRO=...
LUMO_CHECKOUT_URL_TEAM=...
LUMO_CHECKOUT_URL_BUSINESS=...
LUMO_BILLING_PORTAL_URL=...
LUMO_BILLING_WEBHOOK_SECRET=...
```

The hosted checkout must return the LUMO account identifier supplied as `lumo_account`. Your server-side provider adapter should translate provider subscription events into the provider-neutral webhook payload accepted by `/api/billing/webhook`.

Example logical webhook payload:

```json
{
  "id": "evt_unique",
  "type": "subscription.updated",
  "account_id": "account_...",
  "plan_id": "pro",
  "data": {
    "status": "active",
    "customer_id": "customer_...",
    "subscription_id": "subscription_..."
  }
}
```

Sign the exact request body with HMAC-SHA256 using `LUMO_BILLING_WEBHOOK_SECRET` and send the hex digest in `X-LUMO-Billing-Signature`.

## Public SaaS requirements before taking customer data

The current LUMO server is intentionally localhost-first. A real hosted service needs, at minimum:

1. Real user authentication and session management.
2. Tenant-scoped remote persistence rather than local SQLite as the primary customer database.
3. TLS and secret management.
4. A hosted payment processor and legally compliant business/payment account.
5. Terms of service, privacy policy, acceptable-use policy, refund policy, and support contact.
6. Data retention/deletion controls and customer export.
7. Production monitoring, backups, rate limiting, abuse prevention, and incident response.
8. A separate hosted World execution fleet with resource isolation and per-tenant quotas.
9. Provider-specific webhook adapter and reconciliation jobs.
10. Human review of pricing, taxes, contracts, and applicable laws before launch.

Do not expose the current localhost control plane directly to the public internet.
