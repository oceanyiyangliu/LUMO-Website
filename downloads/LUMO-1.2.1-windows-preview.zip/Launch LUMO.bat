@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo LUMO needs Python 3.10 or newer. Install Python from python.org, then run this file again.
  pause
  exit /b 1
)
py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)"
if errorlevel 1 (
  echo LUMO needs Python 3.10 or newer.
  pause
  exit /b 1
)
if not exist ".lumo-preview\Scripts\python.exe" py -3 -m venv .lumo-preview
.lumo-preview\Scripts\python.exe -m pip install --upgrade pip
.lumo-preview\Scripts\python.exe -m pip install .
.lumo-preview\Scripts\python.exe -m lumo %*
endlocal
